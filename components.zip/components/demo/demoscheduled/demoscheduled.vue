<template>
    <!-- <span class="material-symbols-outlined">&#xE8B6;</span> -->
  <div class="schedule-wrapper">
    <div class="mb30 text-center"><a :href="JS_WORDPRESS_URL"><img :src="JS_APP_URL + '/images/logo_header.png'"  alt=""  title="" width="140" height="54"/></a></div>
    <h4 class="mb15 flex items-center justify-center">
      <span class="material-symbols-outlined done-icon mr6">check_circle</span>
      <span class="font-30 font_bold dark--text">You are scheduled</span>
    </h4>
    <p class="font-16 dark--text mb4 text-center">A calendar invitation has been sent to your email address</p>
    <div class="schedule-demo">
      <h4 class="font-20 font_bold dark--text mb15">Abyde Demo</h4>
      <p class="flex items-center font_bold schedule-demo-item mb10"><span class="material-symbols-outlined demo-icon mr6">person</span> {{ ASSIGNED_TO }}</p>
      <p class="flex items-center font_bold schedule-demo-item mb10"><span class="material-symbols-outlined mr6">calendar_today</span> {{timeFormat(event_start_time, event_end_time)}}, {{ dateFormat(event_start_time) }}</p>
      <!-- <p class="flex items-center font_bold schedule-demo-item mb10"><span class="material-symbols-outlined mr6">public</span> Estern Time - US &amp; Canada</p> -->
      <p class="flex items-center font_bold schedule-demo-item mb10"><span class="material-symbols-outlined mr6">videocam</span> Web conferencing details to follow.</p>
    </div>
  </div>
</template>
  

<script scoped>
import moment from "moment";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      ASSIGNED_TO: ASSIGNED_TO,
      is_full_page_loader_shown: false,
      event_start_time: event_start_time,
      event_end_time: event_end_time
    };
  },
  mounted() {
  },
  components: {

  },
  methods: {
    dateFormat(date) {
      return moment(date).format("dddd, MMMM DD, YYYY");
    },
    timeFormat(start_date, end_date) {
      let start_time = moment(start_date).format("h:mm a");
      let end_time = moment(end_date).format("h:mm a");

      return start_time + " - " + end_time;
    },
  }
};
</script>