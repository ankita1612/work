import { createApp } from "vue";
import demoscheduled from './demoscheduled.vue';
const app = createApp(demoscheduled)
app.mount("#demoscheduled_app")
