<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
            <a v-if="!is_processing" @click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </a>
            <h2
                class="
                font-24 font_semibold
                blueog--text
                line-normal
                text-center
                mb20
                mt20
                "
            >
                Thank you for signing up for HIPAA CE!
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb10">
                We have sent a confirmation email containing a link to your registered email address
            </p>
            <p class="text-center font-16 gray_checkmark--text line-normal mb10">
                ( If you do not find the email in your inbox, please check your spam folder or junk email folder )
            </p>
            <p class="text-center font-18 blueog--text line-normal mb20 mt20 word-break">
                {{email}}
            </p>
            <p class="text-center font-16 gray_checkmark--text line-normal mb20">
                Please confirm your email address.
            </p>
            <div class="flex flex-wrap items-center justify-center pb20">
                <button :disabled="is_processing" @click="resendEmailVerification" class="btn-blue h-32">
                RESEND EMAIL
                </button>
            </div>
            <div class="flex flex-wrap items-center justify-center pb20">
                <button :disabled="is_processing" @click="$emit('show-additional-products')" class="btn-blue h-32">
                SELECT ADDITIONAL PRODUCT(S)
                </button>
            </div>
            <div class="flex flex-wrap items-center justify-center pb20">
                <button :disabled="is_processing" @click="closeModal" class="btn-primary-outline h-32">
                DONE
                </button>
            </div>
            </div>
        </div>
        </div>
    </transition>
   </Teleport>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import closeIcon from "../common/icons/closeIcon.vue";

export default {
  components: { closeIcon },
  props: {
    email: String,
    chargebee_invoice_id: String
  },
  data() {
    return {
      is_processing: false,
      SUPPORT_EMAIL: SUPPORT_EMAIL,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  emits: ["show-additional-products", "close-model"],
  methods: {
    closeModal() {
      this.$emit("close-model");
    },
    resendEmailVerification(){
      if(this.email){
        NProgress.start();
        this.is_processing = true;
        axios
          .post(JS_APP_URL + "/signup/resend-email-verification", {
            email: this.email,
            chargebee_invoice_id: this.chargebee_invoice_id,
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              toastr.success(response["data"]['message'], 'Success!');
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
          })
          .then(() => {
            NProgress.done();
            this.is_processing = false;
          });
      }
    },
  },
  created() {
    // document.body.classList.add('modal-open');
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
