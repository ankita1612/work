<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
            <a  @click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </a>
            <div class="text-center mlr-auto mb20">
                <img :src="JS_APP_URL + '/images/header_pop_contact.png'" alt="" title="" class="warning-icon-modal" style="max-width:75px" />
            </div>
            <h2
                class="
                font-24 font_semibold
                blueog--text
                line-normal
                text-center
                mb20
                "
            >
                CONTACT US!
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">
                More than 500 locations? Reach out to us at<br/>
                <a :href="'mailto:'+SUPPORT_EMAIL" class="font-16 font_semibold green--text"> {{SUPPORT_EMAIL}}</a> to receive pricing.
            </p>
            <div class="flex flex-wrap items-center justify-center pb20">
                <button @click="closeModal" class="btn-primary-outline h-32">
                GOT IT!
                </button>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";

export default {
  components: { closeIcon },
  data() {
    return {
      SUPPORT_EMAIL: SUPPORT_EMAIL,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  emits: ["close-model"],
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
  },
  created() {
    // document.body.classList.add('modal-open');
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
