<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
            <a v-if="!is_processing" @click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </a>
            <form @submit.prevent="saveProductToken">
            <h2
                class="
                font-24 font_semibold
                blueog--text
                line-normal
                text-center
                mb20
                mt20
                "
            >
                Confirm Your Next Product
            </h2>
            <div class="flex flex-wrap items-center justify-center mb20">
                <button type="button" v-on:click="selectProduct(product.id)" v-for="product in addition_product_list" :key="product.id" class="billing-card-btn font-16 with-transition mb10" :class="{'active' : selected_product == product.id}">{{product.full_name}}</button>
            </div>
            <div class="flex flex-wrap items-center justify-center pb20">
                <button type="submit" class="btn-primary h-32" :disabled="selected_product == '' || is_processing">
                CONFIRM
                </button>
            </div>
            </form>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import closeIcon from "../common/icons/closeIcon.vue";

export default {
  components: { closeIcon },
  props: {
    action: String,
    email: String,
    addition_product_list: Array
  },
  data() {
    return {
      selected_product: '',
      is_processing: false,
      SUPPORT_EMAIL: SUPPORT_EMAIL,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  emits: ["show-additional-products"],
  methods: {
    closeModal() {
      this.$emit("show-additional-products");
    },
    selectProduct(product){
      this.selected_product = product;
    },
    saveProductToken(){
      if(this.selected_product && this.email){
        NProgress.start();
        this.is_processing = true;
        axios
          .post(JS_APP_URL + "/signup/save-product-token", {
            email: this.email,
            product: this.selected_product
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              if(this.selected_product == 'oshahc'){
                window.open(JS_OSHA_HC_APP_URL + '/signup-existing-product?t='+response["data"]["data"]['token']+'&p=hipaace&a='+this.action+'&u='+(response["data"]["data"]['is_admin_panel_login']==true ? 1 : 0 ), "_blank");
              }
              this.$emit("show-additional-products");
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
          })
          .then(() => {
            NProgress.done();
            this.is_processing = false;
          });
      }

    },
  },
  created() {
    // document.body.classList.add('modal-open');
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
