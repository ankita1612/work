import { createApp } from 'vue'
import login from "./signup_new_product.vue";
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.css';
import FloatingVue from 'floating-vue'
import 'floating-vue/dist/style.css'
import VueMask from '@devindex/vue-mask';

const app = createApp(login);
app.component('multiselect', Multiselect);
app.use(VueMask);
app.use(FloatingVue);
app.mount('#signup_new_product_app');
