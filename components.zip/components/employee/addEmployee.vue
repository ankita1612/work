<template>
  <div>
    <form @submit.prevent="addEmployeeSubmit">
      <input type="hidden" id="gclid_field" name="gclid_field" value="">
      <div class="add-employee-row row -mx-10 mb30">
          <div class="col-12 col-md-3 col-lg-3 col-xl-3 col-20 px10">
            <div class="form-group" :class="{ 'form-group--error': v$.first_name.$error }">
                <input class="form-input location-input-box" :class="{ 'form-error': v$.first_name.$error }" type="text" name="first_name" v-model.trim="v$.first_name.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.first_name.$model }">First Name</label>
                <div v-if="v$.first_name.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.first_name.$errors[0].$message }}
                  </div>
                </div>
            </div>
          </div>
          <div class="col-12 col-md-3 col-lg-3 col-xl-3 col-20 px10">
            <div class="form-group" :class="{ 'form-group--error': v$.last_name.$error }">
                <input class="form-input location-input-box" :class="{ 'form-error': v$.last_name.$error }" type="text" name="last_name" v-model.trim="v$.last_name.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.last_name.$model }">Last Name</label>
                <div v-if="v$.last_name.$errors.length > 0">
                    <div class="form-error-text">
                    {{ v$.last_name.$errors[0].$message }}
                    </div>
                </div>
            </div>
          </div>
          <div class="col-12 col-md-3 col-lg-3 col-xl-3 col-20 px10">
            <div class="form-group" :class="{ 'form-group--error': v$.email.$errors.length }">
                <input class="form-input location-input-box" :class="{ 'form-error': v$.email.$errors.length }" type="text" name="email" v-model.trim="v$.email.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.email.$model }">Email</label>
                <div v-if="v$.email.$errors.length > 0">
                    <div class="form-error-text">
                    {{ v$.email.$errors[0].$message }}
                    </div>
                </div>
            </div>
          </div>
          <div class="col-12 col-md-3 col-lg-3 col-xl-3 col-20 px10">
            <div class="form-group" :class="{ 'form-group--error': v$.phone_number.$error }">
                <input v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent class="form-input location-input-box" :class="{ 'form-error': v$.phone_number.$error }" type="text" name="phone_number" v-model.trim="v$.phone_number.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.phone_number.$model }">Phone Number</label>
                <div v-if="v$.phone_number.$errors.length > 0">
                    <div class="form-error-text">
                    {{ v$.phone_number.$errors[0].$message }}
                    </div>
                </div>
            </div>
          </div>
          <div v-if="all_location_list.length > 1" class="col-12 col-md-4 col-lg-3 col-xl-3 col-20 px10">
            <div class="form-group" :class="{ 'form-group--error': v$.selected_primary_work_location.$error }">
                <multiselect
                v-model="selected_primary_work_location"
                :options="all_location_list"
                :close-on-select="true"
                tag-placeholder=""
                placeholder=""
                label="location_nickname"
                track-by="id"
                :searchable="true"
                :showLabels="false"
                :taggable="false"
                >
                <template #noResult>
                    <div class="multiselect__noResult text-center">
                        No results found
                    </div>
                </template>
                </multiselect>
                <label class="label label-select" :class="{ 'label-float': (selected_primary_work_location != null) }">Primary Work Location</label>
                <div v-if="v$.selected_primary_work_location.$errors.length > 0">
                <div class="form-error-text">
                    {{ v$.selected_primary_work_location.$errors[0].$message }}
                </div>
                </div>
            </div>
          </div>
          <div v-if="all_location_list.length > 1" class="col-12 col-md-4 col-lg-3 col-xl-3 col-20 px10 mb-sm-10">
            <div class="form-group mb-0" :class="{ 'form-group--error': v$.selected_secondary_work_locations.$error }">
              <multiselect
              class="select-all-dropdown"
              v-model="v$.selected_secondary_work_locations.$model"
              tag-placeholder=""
              :disabled="is_secondary_work_location_applicable"
              placeholder=""
              label="location_nickname"
              track-by="id"
              :options="all_location_list_for_secondary"
              group-values="group_option_list"
              group-label="select_all"
              :group-select="true"
              :multiple="true"
              :close-on-select="false"
              :showLabels="false"
              :taggable="false">
                <template #noResult>
                    <div class="multiselect__noResult text-center">
                        No results found
                    </div>
                </template>
                <template #noOptions>
                    <div class="multiselect__noOptions text-center">
                        No data available
                    </div>
                </template>
                <template #selection>
                    <div class="multiselect__tags-wrap" v-if="v$.selected_secondary_work_locations.$model.length > 1">
                        <span class="multiselect__tag">
                        <span>{{ v$.selected_secondary_work_locations.$model.length }} Locations Selected</span>
                        </span>
                    </div>
                </template>
              </multiselect>
              <label class="label label-select" :class="{ 'label-float': (selected_secondary_work_locations.length > 0) }">Secondary Work Location(s)</label>
              <div v-if="v$.selected_secondary_work_locations.$errors.length > 0">
                <div class="form-error-text">
                    {{ v$.selected_secondary_work_locations.$errors[0].$message }}
                </div>
              </div>
            </div>
          </div>
          <div v-if="all_location_list.length > 1" class="col-12 col-md-3 col-lg-2 col-xl-3 col-12-percent px10">
            <div class="checkbox pb20 mt9">
              <input v-model.trim="is_secondary_work_location_applicable" id="add_is_secondary_work_location_applicable" name="add_is_secondary_work_location_applicable" type="checkbox">
              <label for="add_is_secondary_work_location_applicable"  class="checkbox-label font-14 font-light gray_checkmark--text">Not Applicable</label>
            </div>
          </div>
          <div class="col-12 col-md-5 col-lg-4 col-xl-3 px10">
            <div class="checkbox pb20 mt9">
              <input v-model.trim="is_send_confidentiality_agreement" id="is_send_confidentiality_agreement" name="is_send_confidentiality_agreement" type="checkbox">
              <label for="is_send_confidentiality_agreement"  class="checkbox-label font-14 font-light gray_checkmark--text">Send Confidentiality Agreement</label>
            </div>
          </div>
          <div class="col-12 col-md-12 col-lg-5 col-xl-3 col-15 px10">
            <div class="flex items-center flex-wrap justify-between submit-cancel-buttons">
              <button
                  :disabled="disable_addemployee_submit_btn"
                  type="submit"
                  class="btn-primary"
                  id="btn-add-employee"
              >
                  <span>Submit</span>
              </button>
              <button
                  :disabled="disable_addemployee_submit_btn"
                  type="button"
                  class="btn-cancel-outline"
                  @click="cancelAddEmployee()"
              >
                  <span>Cancel</span>
              </button>
            </div>
          </div>
      </div>
    </form>
    <employee-limit-reached-modal
    v-if="is_employeelimitreachedmodal_shown"
    @close-model="employeeLimitReachedModalToggle"
    ></employee-limit-reached-modal>
  </div>
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, requiredIf, email, minLength, maxLength, helpers } from "@vuelidate/validators";
import _ from 'lodash';
import infoIcon from "../common/icons/infoIcon.vue"
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
import employeeLimitReachedModal from './employeeLimitReachedModal.vue';
import { checkSpecialChars, checkSpecialCharsErrorMessage } from "../common/customValidation";
const { withAsync } = helpers
export default {
  data() {
    return {
      first_name: '',
      last_name: '',
      email: '',
      phone_number: '',
      selected_secondary_work_locations: [],
      selected_primary_work_location: null,
      disable_addemployee_submit_btn: false,
      check_emp_available_timer: null,
      add_employee_change_email_timer: null,
      is_secondary_work_location_applicable: false,
      is_send_confidentiality_agreement:false,
      is_employeelimitreachedmodal_shown: false,
      fetched_account_user: {},
      all_location_list_for_secondary: [],
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
      APP_ENV: APP_ENV
    };
  },
  setup: () => ({ v$: useVuelidate() }),
  props: {
    all_location_list:{
      type: Array,
      default: () => []
    }
  },
  components: {
    infoIcon,
    clearDropdownIcon,
    employeeLimitReachedModal
  },
  emits: ["add-employee-form-toggle", "reset-all-filter", "load-location-data", "set-employeeid-for-send-agreement", "load-employee-list"],
  validations() {
    var validationArray = {
        first_name: {
            required: helpers.withMessage('Please enter a first name', required),
            maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        },
        last_name: {
            required: helpers.withMessage('Please enter a last name', required),
            maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        },
        email: {
            required: helpers.withMessage('Please enter an email', required),
            email: helpers.withMessage('Please enter a valid email', email),
            maxLength: helpers.withMessage('Max 100 characters allowed', maxLength(100)),
            isUnique: helpers.withMessage('Email address already in use', withAsync(async (value) => {
                if (!value) return true;
                if (!this.v$.email.required || !this.v$.email.email) return true;
                this.disable_addemployee_submit_btn = true;
                let check_promise = new Promise((resolve, reject) => {
                    if (this.check_emp_available_timer) {
                        clearTimeout(this.check_emp_available_timer)
                        this.check_emp_available_timer = null
                    }
                    this.check_emp_available_timer = setTimeout(() => {
                        return fetch(JS_APP_URL + `/employee/check-unique-email-employee/${value}`).then(response => {
                            if (response.ok) {
                                resolve(response.text())
                            } else {
                                resolve(new Error('error'))
                            }
                        }, error => {
                            resolve(new Error('error'))
                        })
                    }, 500);
                });
                var response = await check_promise;
                this.disable_addemployee_submit_btn = false;
                return Boolean((response == 'available') ? false : true);
            }))
        },
        phone_number: {
            required: helpers.withMessage('Please enter a phone number', required),
            minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
            maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
        },
    };
    if (this.all_location_list.length > 1) {
        validationArray.selected_primary_work_location = {
            required: helpers.withMessage('Please select a primary work location', required)
        };
        validationArray.selected_secondary_work_locations = {
            required: helpers.withMessage('Please select secondary work location(s)', requiredIf(() => {
                return !this.is_secondary_work_location_applicable
            }))
        };
    }
    return validationArray;
  },
  watch:{
    selected_primary_work_location(){
      if(this.selected_primary_work_location != null){
        this.selected_secondary_work_locations = [];
        this.all_location_list_for_secondary = [{
          'select_all': 'Select All',
          'group_option_list': [...this.all_location_list]
        }];
        var found_index = _.findIndex(this.all_location_list_for_secondary[0]['group_option_list'] , (o) => { return o.id === this.selected_primary_work_location.id; });
        if(found_index >= 0){
          this.all_location_list_for_secondary[0]['group_option_list'].splice(found_index, 1);
        }
      }
    },
    is_secondary_work_location_applicable(){
      this.selected_secondary_work_locations = [];
    }
  },
  methods:{
    employeeLimitReachedModalToggle(status = true){
        this.is_employeelimitreachedmodal_shown = status;
    },
    async addEmployeeSubmit(){
      this.v$.$touch();
        const is_valid = !this.v$.$invalid;
        if (is_valid) {
            this.disable_addemployee_submit_btn = true;
            var location_list = new Array();
            _.forEach(this.selected_secondary_work_locations, (value) =>  {
                   location_list.push({"location_id": value.id});
            });
            NProgress.start();
            axios
            .post(JS_APP_URL + "/employee/add-employee", {
              first_name: this.first_name,
              last_name: this.last_name,
              email: this.email,
              phone_number: this.phone_number,
              primary_work_location_id: (this.all_location_list.length == 1)? this.all_location_list[0].id :this.selected_primary_work_location.id,
              location_list: location_list,
            })
            .then((response) =>  {
                if (response["data"]["status"] == "Error") {
                  if(Object.keys(response["data"]["data"]).length > 0 && response["data"]["data"]['reason'] == 'employee_limit_reached'){
                    this.employeeLimitReachedModalToggle();
                  }else{
                    if(response["data"]['data'].length > 0){
                        toastr.error(response["data"]['data'].join('</br>'), "Error");
                    }else{
                        toastr.error(response["data"]["message"], "Error");
                    }
                  }
                } else {
                    toastr.success(response["data"]["message"], "Success");
                    setTimeout(() => {
                      if(APP_ENV == 'production') {
                        var metadata = {
                          first_time_employee_added: response['data']['data']['first_employee_added'],
                          total_employee_added: response['data']['data']['total_employee_added'],
                          user_locations_number: this.all_location_list.length
                        };
                        Intercom('trackEvent', 'employee-status', metadata);
                      }
                        this.$emit("add-employee-form-toggle", false);
                        this.$emit("reset-all-filter");
                        if(this.is_send_confidentiality_agreement == true){
                          this.$emit('set-employeeid-for-send-agreement',response["data"]["data"]['employee_created']["id"])
                        }
                        this.$emit("load-employee-list", true);
                    }, 100);
                }
            })
            .catch((error) =>  {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                   window.location = JS_APP_URL + "/login";
                }
            })
            .then(() =>  {
                NProgress.done();
                this.disable_addemployee_submit_btn = false;
            });
      }
    },
    cancelAddEmployee(){
      this.$emit("add-employee-form-toggle", false);
    }
  },
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("add-employee-form-toggle", false);
      }
    });
  }
};
 </script>
