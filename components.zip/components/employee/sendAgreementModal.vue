<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
            <button v-if="!disable_agreement_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto pt20 pt20" style="min-height:77px">
                <img v-if="!send_agreement_employee_data.employee_agreement || Object.keys(send_agreement_employee_data.employee_agreement).length === 0" :src="JS_APP_URL +'/images/envelop-upload.svg'" class="warning-icon-modal" alt="" title="">
                <img v-if="send_agreement_employee_data.employee_agreement && Object.keys(send_agreement_employee_data.employee_agreement).length > 0 && send_agreement_employee_data.employee_agreement.signature === null" :src="JS_APP_URL +'/images/envelop-process.svg'" class="warning-icon-modal" alt="" title="">
                <img v-if="send_agreement_employee_data.employee_agreement && Object.keys(send_agreement_employee_data.employee_agreement).length > 0 && send_agreement_employee_data.employee_agreement.signature !== null" :src="JS_APP_URL +'/images/envelop-done.svg'" class="warning-icon-modal" alt="" title="">
            </div>

            <h2 v-if="!send_agreement_employee_data.employee_agreement || Object.keys(send_agreement_employee_data.employee_agreement).length === 0" class="font-24 font_semibold blueog--text line-normal text-center mb30">
                Send Employee Confidentiality Agreement
            </h2>
            <h2 v-if="send_agreement_employee_data.employee_agreement && Object.keys(send_agreement_employee_data.employee_agreement).length > 0 && send_agreement_employee_data.employee_agreement.signature === null" class="font-24 font_semibold blueog--text line-normal text-center mb10">
                Send a reminder to sign the Employee Confidentiality Agreement
            </h2>
            <h2 v-if="send_agreement_employee_data.employee_agreement && Object.keys(send_agreement_employee_data.employee_agreement).length > 0 && send_agreement_employee_data.employee_agreement.signature !== null" class="font-24 font_semibold blueog--text line-normal text-center mb20">
                Signed, sealed, delivered!
            </h2>

            <p v-if="!send_agreement_employee_data.employee_agreement || Object.keys(send_agreement_employee_data.employee_agreement).length === 0" class="text-center font-16 text-999 line-normal mb15">To email {{send_agreement_employee_data.employee_primary_work_location.company_name}}'s employee confidentiality agreement to {{send_agreement_employee_data.first_name}} {{send_agreement_employee_data.last_name}}, <br/>accept the terms below and hit the ‘Send Email’ button.</p>
            <p v-if="!send_agreement_employee_data.employee_agreement || Object.keys(send_agreement_employee_data.employee_agreement).length === 0" class="text-center font-16 text-999 line-normal mb25">{{send_agreement_employee_data.first_name}} {{send_agreement_employee_data.last_name}} will receive a link via email to sign the agreement, which affirms they will follow all appropriate confidentiality, privacy, and security policies in the course of their work.</p>


            <p v-if="send_agreement_employee_data.employee_agreement && Object.keys(send_agreement_employee_data.employee_agreement).length > 0 && send_agreement_employee_data.employee_agreement.signature === null" class="text-center font-16 text-999 line-normal mb30">You’ve sent the Employee Confidentiality Agreement to {{send_agreement_employee_data.first_name}} {{send_agreement_employee_data.last_name}} but are still awaiting a signature. If you’d like to send a reminder email, just click the button below!</p>


            <p v-if="send_agreement_employee_data.employee_agreement && Object.keys(send_agreement_employee_data.employee_agreement).length > 0 && send_agreement_employee_data.employee_agreement.signature !== null" class="text-center font-16 text-999 line-normal mb30">{{send_agreement_employee_data.first_name}} {{send_agreement_employee_data.last_name}} has successfully signed the Employee Confidentiality Agreement. If you’d like to download a copy of the signed document, click the download button below!</p>

            <div class="checkbox pb20 border-bottom" v-if="!send_agreement_employee_data.employee_agreement || Object.keys(send_agreement_employee_data.employee_agreement).length === 0">
                <input v-model.trim="is_accept_btn" id="is_accept_btn" name="is_accept_btn" type="checkbox">
                <label for="is_accept_btn"  class="checkbox-label font-14 font_light gray_checkmark--text">I accept the <a :href="JS_APP_URL + '/site-policies'" class="font-14 font_semibold green--text text-decoration-underline" target="_blanck">Terms &amp; Conditions</a></label>
            </div>

            <div class="checkbox pb20 pt20" v-if="!send_agreement_employee_data.employee_agreement || Object.keys(send_agreement_employee_data.employee_agreement).length === 0">
                <input v-model.trim="is_send_to_all_employee" id="is_send_to_all_employee_option" name="is_send_to_all_employee_option" type="checkbox">
                <label for="is_send_to_all_employee_option"  class="checkbox-label font-14 font_light gray_checkmark--text">Send to all Added Employees</label>
            </div>

            <p v-if="!send_agreement_employee_data.employee_agreement || Object.keys(send_agreement_employee_data.employee_agreement).length === 0" class="text-center font-14 font-italic font_light gray_checkmark--text line-normal mb20"> To send all employees their confidentiality <br/> agreements at once, check the box above.</p>

            <div class="flex flex-wrap items-center justify-center pb10">
                <button :disabled="isDisabledSubmitBtn" v-on:click="sendEmail" v-if="!send_agreement_employee_data.employee_agreement || Object.keys(send_agreement_employee_data.employee_agreement).length === 0" class="btn-primary-outline mx5">SEND EMAIL</button>
                <button :disabled="disable_agreement_submit_btn" v-on:click="sendReminderEmail" v-if="send_agreement_employee_data.employee_agreement && Object.keys(send_agreement_employee_data.employee_agreement).length > 0 && send_agreement_employee_data.employee_agreement.signature === null" class="btn-primary-outline mx5">SEND REMINDER</button>
                <button v-on:click="downloadAgreement" v-if="send_agreement_employee_data.employee_agreement && Object.keys(send_agreement_employee_data.employee_agreement).length > 0 && send_agreement_employee_data.employee_agreement.signature !== null" class="btn-blue-outline btn-left-padding"><div class="next-arrow-icon pdf-icon"> <pdf-icon></pdf-icon></div> DOWNLOAD</button>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from '../common/icons/closeIcon.vue';
import pdfIcon from '../common/icons/pdfIcon.vue';
export default {
  props: {
    send_agreement_employee_data:{
      type: Object,
      default: () => {}
    },
    disable_agreement_submit_btn:{
      type: Boolean,
      default: () => false
    },
  },
  components:{closeIcon,pdfIcon},
  data() {
    return {
      is_send_to_all_employee: false,
      is_accept_btn:false,
      JS_APP_URL: JS_APP_URL,
    };
  },
  computed: {
  	isDisabledSubmitBtn(){
      if(this.disable_agreement_submit_btn == false && this.is_accept_btn == true){
        return false
      }else{
        return true
      }
    }
  },
  emits: ["close-model", "send-reminder-email", "send-agreement-email"],
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
    sendEmail(){
      this.$emit("send-agreement-email", this.is_send_to_all_employee);
    },
    sendReminderEmail(){
      this.$emit("send-reminder-email");
    },
    downloadAgreement() {
      var link = document.createElement("a");
      link.download = this.send_agreement_employee_data.employee_agreement.signature;
      link.href = this.send_agreement_employee_data.employee_agreement.file_name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      this.$emit("close-model", false);
    }
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.disable_agreement_submit_btn) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
