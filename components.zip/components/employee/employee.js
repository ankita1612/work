import { createApp } from 'vue';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import InfiniteLoading from "v3-infinite-loading";
import VueMask from '@devindex/vue-mask';
import employee from "./employee.vue";

const app = createApp(employee);
app.use(FloatingVue);
app.use(VueMask);
app.component('multiselect', Multiselect);
app.component('InfiniteLoading', InfiniteLoading);
app.mount('#employee_app');
