<template>
    <div>
        <transition name="simple-fade-transition" mode="out-in">
            <div
                v-if="!is_employee_editing"
                key="saved"
                class="user-detail-card py10 px15 mb15 light"
            >
                <div class="row flex-auto -mx-10 items-center">
                    <div class="col-12 col-md-12 col-lg-5 col-xl-6 px10">
                        <div class="row flex-auto -mx-10">
                            <div class="col-12 col-md-6 col-lg-6 col-xl-7 px10">
                                <div
                                    class="user-detail-text font-14 gray_checkmark--text mb10"
                                    v-text="employee_item.first_name"
                                ></div>
                            </div>
                            <div class="col-12 col-md-6 col-lg-6 col-xl-5 px10">
                                <div
                                    class="user-detail-text font-14 gray_checkmark--text mb10"
                                    v-text="employee_item.last_name"
                                ></div>
                            </div>
                            <div class="col-12 col-md-6 col-lg-6 col-xl-7 px10">
                                <div
                                    class="user-detail-text font-14 gray_checkmark--text mb10"
                                    v-text="employee_item.email"
                                ></div>
                            </div>
                            <div class="col-12 col-md-6 col-lg-6 col-xl-5 px10">
                                <div
                                    class="user-detail-text font-14 gray_checkmark--text"
                                    v-text="employee_item.phone_number"
                                ></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-7 col-xl-6 px10">
                        <div class="row flex-auto -mx-10 items-center">
                            <div
                                class="col-12 col-sm-5 col-md-6 col-lg-4 col-xl-5 px10"
                            >
                                <div
                                    class="flex items-center justify-between employee-location-icon"
                                >
                                    <div class="flex flex-auto items-center">
                                        <div class="col-8 col-sm-7 px4">
                                            <div
                                                class="user-detail-text font-12 gray_checkmark--text text-center uppercase word-break text-truncate white-no-wrap tuncate-location-width"
                                                v-if="
                                                    employee_item.employee_primary_work_location &&
                                                    Object.keys(
                                                        employee_item.employee_primary_work_location
                                                    ).length > 0 &&
                                                    all_location_list.length > 1
                                                "
                                                v-text="
                                                    employee_item
                                                        .employee_primary_work_location
                                                        .location_nickname
                                                "
                                                :title="employee_item.employee_primary_work_location.location_nickname"
                                            ></div>
                                        </div>
                                        <div
                                            class="col-4 col-sm-5 px2 text-center"
                                        >
                                            <button
                                                v-if="
                                                    all_location_list.length > 1
                                                "
                                                type="button"
                                                class="user-location-icon ml60"
                                            >
                                                <VTooltip
                                                    v-if="
                                                        employee_item
                                                            .employee_secondary_work_location
                                                            .length > 0
                                                    "
                                                    :triggers="['hover']"
                                                    :popperTriggers="['hover']"
                                                >
                                                    <img
                                                        :src="
                                                            JS_APP_URL +
                                                            '/images/location.svg'
                                                        "
                                                        alt=""
                                                        title=""
                                                        class="cursor-pointer"
                                                    />
                                                    <template #popper>
                                                        <div
                                                            class="white--text font-12 font_semibold mb2 text-center pb5 pt5"
                                                        >
                                                            WORK LOCATION(S)
                                                        </div>
                                                        <div
                                                            class="text-center seperator-line pt3 pb"
                                                            v-for="(
                                                                each_location,
                                                                each_location_index
                                                            ) in employee_item.employee_secondary_work_location"
                                                            v-bind:key="
                                                                each_location_index
                                                            "
                                                            v-text="
                                                                each_location
                                                                    .location
                                                                    .location_nickname
                                                            "
                                                        ></div>
                                                    </template>
                                                </VTooltip>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="col-12 col-sm-7 col-md-6 col-lg-8 col-xl-7 px10"
                            >
                                <div
                                    class="flex flex-wrap items-center justify-between user-detail-action"
                                >
                                    <div
                                        class="flex flex-wrap items-center justify-end employee-acion-buttons ml-auto flex-auto"
                                    >
                                        <div
                                            class="action-sept ml20 mr-auto"
                                        ></div>
                                        <VTooltip
                                            :triggers="['hover']"
                                            :popperTriggers="['hover']"
                                            v-if="
                                                employee_item
                                                    .employee_secondary_work_location
                                                    .length +
                                                    1 !=
                                                employee_access_rights_count
                                            "
                                            class="mr-auto ml20 employee-item-access-btn"
                                        >
                                            <button
                                                @click="
                                                    accessRightModalToggle(true)
                                                "
                                                type="button"
                                                class="btn-primary-small cursor-pointer"
                                            >
                                                Access
                                            </button>
                                            <template #popper>
                                                Access Rights
                                            </template>
                                        </VTooltip>
                                        <VTooltip
                                            :triggers="['hover']"
                                            :popperTriggers="['hover']"
                                            v-else
                                            class="mr-auto employee-item-access-btn ml20"
                                        >
                                            <button
                                                @click="
                                                    accessRightModalToggle(true)
                                                "
                                                type="button"
                                                class="action-icon-btn action-icon-btn-key cursor-pointer"
                                            >
                                                <img
                                                    :src="
                                                        JS_APP_URL +
                                                        '/images/key-employee.svg'
                                                    "
                                                    alt=""
                                                    title=""
                                                />
                                            </button>
                                            <template #popper>
                                                Access Rights
                                            </template>
                                        </VTooltip>
                                        <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml10"
                                            v-if="agreementStatus == 'pending' || agreementStatus == 'send'">
                                            <button @click="downloadAgreementWithoutSignature(employee_item.id)" type="button"
                                                class="action-icon-btn action-btn-blue cursor-pointer complete-action-btn pdf-round-btn">
                                                <span
                                                class="pending-svg-icon inline-flex items-center justify-center"><pdf-icon></pdf-icon></span>
                                            </button>
                                            <template #popper>
                                                Confidentiality agreement
                                            </template>
                                        </VTooltip>
                                        <div class="ml10" v-else>
                                            <button disabled type="button"
                                                class="action-icon-btn action-btn-blue cursor-pointer complete-action-btn pdf-round-btn pdf-round-disable">
                                                <span
                                                class="pending-svg-icon inline-flex items-center justify-center"><pdf-icon></pdf-icon></span>
                                            </button>
                                        </div>                                        
                                       
                                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml7">
                                            <button  type="button" class="action-icon-btn action-btn-blue cursor-pointer" :class="agreement_btn_class">
                                                <span @click="sendEmployeeAgreementToggle()" class="pending-svg-icon inline-flex items-center justify-center" v-if="agreementStatus == 'send'"><send-icon></send-icon></span>
                                                <span @click="sendEmployeeAgreementToggle()" class="pending-svg-icon inline-flex items-center justify-center" v-if="agreementStatus == 'pending'" ><pendingfile-icon></pendingfile-icon></span>
                                                <!-- <span @click="selectLocationForAgreementToggle(true)" class="pending-svg-icon inline-flex items-center justify-center" v-if="agreementStatus == 'pending-pre-ba'" ><pendingfile-icon></pendingfile-icon></span> -->
                                                <span @click="completeAgreementToggle(true)" class="pending-svg-icon inline-flex items-center justify-center" v-if="agreementStatus == 'complete'">
                                                    <complete-icon></complete-icon>
                                                </span>
                                            </button>
                                            <template #popper>
                                                Confidentiality Agreement
                                            </template>
                                        </VTooltip>
                                        <VTooltip
                                            :triggers="['hover']"
                                            :popperTriggers="['hover']"
                                            class="ml7"
                                        >
                                            <button
                                                v-on:click="editEmployee"
                                                type="button"
                                                class="action-icon-btn action-btn-blueog cursor-pointer"
                                            >
                                                <img
                                                    :src="
                                                        JS_APP_URL +
                                                        '/images/pencil.svg'
                                                    "
                                                    alt=""
                                                    title=""
                                                />
                                            </button>
                                            <template #popper> Edit </template>
                                        </VTooltip>
                                        <VTooltip
                                            :triggers="['hover']"
                                            :popperTriggers="['hover']"
                                            class="ml7"
                                        >
                                            <button
                                                v-on:click="
                                                    deleteEmployeeToggle
                                                "
                                                type="button"
                                                class="delete-location-btn cursor-pointer"
                                            >
                                                <img
                                                    :src="
                                                        JS_APP_URL +
                                                        '/images/bin.svg'
                                                    "
                                                    alt=""
                                                    title=""
                                                    class="mlr-auto"
                                                />
                                            </button>
                                            <template #popper>
                                                Delete
                                            </template>
                                        </VTooltip>
                                        <VTooltip
                                            :triggers="['hover']"
                                            :popperTriggers="['hover']"
                                            class="ml7"
                                        >
                                            <button
                                                v-on:click="
                                                    is_pause_unpause_modal_shown = true
                                                "
                                                type="button"
                                                class="action-icon-btn action-btn-blueog cursor-pointer"
                                            >
                                                <img
                                                    :src="(employee_item.status == 'active')?
                                                        JS_APP_URL +
                                                        '/images/unpause.svg':JS_APP_URL +
                                                        '/images/pause.svg'
                                                    "
                                                    alt=""
                                                    title=""
                                                    class="mlr-auto img-fluid"
                                                    :class="[(employee_item.status == 'active') ? 'unpause_class' : 'pause_class']"
                                                />
                                            </button>
                                            <template #popper>
                                                Click the Pause button to stop an employee from receiving training emails and notifications from Abyde. Click the Play button to resume.
                                            </template>
                                        </VTooltip>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div
                v-else
                key="editing"
                class="user-detail-card py20 pb26 px15 light mb15"
            >
                <form @submit.prevent="editEmployeeSubmit">
                    <div class="row flex-auto -mx-10">
                        <div
                            class="col-12 col-md-6 col-lg-3 col-xl-3 col-20 px10"
                        >
                            <div
                                class="form-group"
                                :class="{
                                    'form-group--error': v$.first_name.$error,
                                }"
                            >
                                <input
                                    class="form-input location-input-box"
                                    :class="{
                                        'form-error': v$.first_name.$error,
                                    }"
                                    type="text"
                                    name="first_name"
                                    v-model.trim="v$.first_name.$model"
                                />
                                <label
                                    class="label location-input-label"
                                    :class="{
                                        'label-float': v$.first_name.$model,
                                    }"
                                    >First Name</label
                                >
                                <div v-if="v$.first_name.$errors.length > 0">
                                    <div class="form-error-text">
                                    {{ v$.first_name.$errors[0].$message }}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="col-12 col-md-6 col-lg-3 col-xl-3 px10 col-20"
                        >
                            <div
                                class="form-group"
                                :class="{
                                    'form-group--error': v$.last_name.$error,
                                }"
                            >
                                <input
                                    class="form-input location-input-box"
                                    :class="{
                                        'form-error': v$.last_name.$error,
                                    }"
                                    type="text"
                                    name="last_name"
                                    v-model.trim="v$.last_name.$model"
                                />
                                <label
                                    class="label location-input-label"
                                    :class="{
                                        'label-float': v$.last_name.$model,
                                    }"
                                    >Last Name</label
                                >
                                <div v-if="v$.last_name.$errors.length > 0">
                                  <div class="form-error-text">
                                    {{ v$.last_name.$errors[0].$message }}
                                </div>
                          </div>
                            </div>
                        </div>
                        <div
                            class="col-12 col-md-6 col-lg-3 col-xl-3 px10 col-20"
                        >
                            <div
                                class="form-group"
                                :class="{
                                    'form-group--error': v$.email.$errors.length,
                                }"
                            >
                                <input
                                    class="form-input location-input-box"
                                    :class="{ 'form-error': v$.email.$errors.length }"
                                    type="text"
                                    name="email"
                                    v-model.trim="v$.email.$model"
                                />
                                <label
                                    class="label location-input-label"
                                    :class="{ 'label-float': v$.email.$model }"
                                    >Email</label
                                >
                                 <div v-if="v$.email.$errors.length > 0">
                                    <div class="form-error-text">
                                        {{ v$.email.$errors[0].$message }}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="col-12 col-md-6 col-lg-3 col-xl-3 px10 col-20"
                        >
                            <div
                                class="form-group"
                                :class="{
                                    'form-group--error': v$.phone_number.$error,
                                }"
                            >
                                <input
                                    v-mask="'000-000-0000'"
                                    @click.right.prevent
                                    @copy.prevent
                                    @paste.prevent
                                    class="form-input location-input-box"
                                    :class="{
                                        'form-error': v$.phone_number.$error,
                                    }"
                                    type="text"
                                    name="phone_number"
                                    v-model.trim="v$.phone_number.$model"
                                />
                                <label
                                    class="label location-input-label"
                                    :class="{
                                        'label-float': v$.phone_number.$model,
                                    }"
                                    >Phone Number</label
                                >
                                <div v-if="v$.phone_number.$errors.length > 0">
                                    <div class="form-error-text">
                                        {{ v$.phone_number.$errors[0].$message }}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div
                            v-if="all_location_list.length > 1"
                            class="col-12 col-md-6 col-lg-3 col-xl-3 px10 col-20"
                        >
                            <div class="form-group" :class="{'form-group--error':v$.selected_primary_work_location.$error}">
                                <multiselect
                                    v-model="selected_primary_work_location"
                                    :options="all_location_list"
                                    :close-on-select="true"
                                    tag-placeholder=""
                                    placeholder=""
                                    label="location_nickname"
                                    :searchable="true"
                                    track-by="id"
                                    :showLabels="false"
                                    @update:model-value="onChangePrimaryWorkLocation"
                                    :taggable="false"
                                >
                                    <template #noResult>
                                        <div class="multiselect__noResult text-center">
                                        No results found
                                        </div>
                                    </template>
                                </multiselect>
                                <label class="label label-select" :class="{'label-float':selected_primary_work_location !=null,}">Primary Work Location</label>
                                <div v-if="v$.selected_primary_work_location.$errors.length > 0">
                                    <div class="form-error-text">
                                        {{ v$.selected_primary_work_location.$errors[0].$message }}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div
                            v-if="all_location_list.length > 1"
                            class="col-12 col-md-6 col-lg-4 col-xl-3 px10 mb-sm-10 col-20"
                        >
                            <div
                                class="form-group mb-0"
                                :class="{
                                    'form-group--error':
                                        v$.selected_secondary_work_locations
                                            .$error,
                                }"
                            >
                                <multiselect
                                    class="select-all-dropdown"
                                    v-model="
                                        v$.selected_secondary_work_locations
                                            .$model
                                    "
                                    tag-placeholder=""
                                    placeholder=""
                                    :disabled="
                                        is_secondary_work_location_applicable
                                    "
                                    label="location_nickname"
                                    track-by="id"
                                    :options="all_location_list_for_secondary"
                                    group-values="group_option_list"
                                    group-label="select_all"
                                    :group-select="true"
                                    :multiple="true"
                                    :close-on-select="false"
                                    :showLabels="false"
                                    :taggable="false"
                                >
                                    <template #noResult>
                                        <div class="multiselect__noResult text-center">
                                        No results found
                                        </div>
                                    </template>
                                    <template #noOptions>
                                        <div class="multiselect__noOptions text-center">
                                        No data available
                                        </div>
                                    </template>
                                    <template #selection>
                                        <div class="multiselect__tags-wrap" v-if="v$.selected_secondary_work_locations.$model.length > 1">
                                            <span class="multiselect__tag">
                                                <span>{{ v$.selected_secondary_work_locations.$model.length }} Locations Selected</span>
                                            </span>
                                        </div>
                                    </template>
                                </multiselect>
                                <label
                                    class="label label-select"
                                    :class="{
                                        'label-float':
                                            selected_secondary_work_locations.length >
                                            0,
                                    }"
                                    >Secondary Work Location(s)</label
                                >
                                <div v-if="v$.selected_secondary_work_locations.$errors.length > 0">
                                    <div class="form-error-text">
                                    {{ v$.selected_secondary_work_locations.$errors[0].$message }}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div
                            v-if="all_location_list.length > 1"
                            class="col-12 col-md-4 col-lg-3 col-xl-3 col-12-percent px10"
                        >
                            <div class="checkbox pb10 mt10">
                                <input
                                    v-model.trim="
                                        is_secondary_work_location_applicable
                                    "
                                    :id="
                                        'edit_is_secondary_work_location_applicable_' +
                                        employee_item.id
                                    "
                                    :name="
                                        'edit_is_secondary_work_location_applicable_' +
                                        employee_item.id
                                    "
                                    type="checkbox"
                                />
                                <label
                                    :for="
                                        'edit_is_secondary_work_location_applicable_' +
                                        employee_item.id
                                    "
                                    class="checkbox-label font-14 font-light gray_checkmark--text"
                                    >Not Applicable</label
                                >
                            </div>
                        </div>
                        <div
                            class="col-12 col-md-12 col-lg-5 col-xl-3 pl10 pr0 col-15"
                        >
                            <div
                                class="flex items-center flex-wrap justify-between submit-cancel-buttons"
                            >
                                <button
                                    :disabled="disable_editemployee_submit_btn"
                                    type="submit"
                                    class="btn-primary"
                                >
                                    <span>Submit</span>
                                </button>
                                <button
                                    :disabled="disable_editemployee_submit_btn"
                                    type="button"
                                    class="btn-cancel-outline"
                                    @click="cancelEditEmployee"
                                >
                                    <span>Cancel</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </transition>
        <delete-employee-modal
            v-if="is_deleteemployeemodal_shown"
            @delete-employee="deleteEmployeeSubmit"
            :employee_access_rights="employee_access_rights_count"
            :employee_id="deleteemployeemodal_employee_id"
            @close-model="deleteEmployeeToggle"
            @open-access-updated-modal="openAccessUpdatedModal"
        ></delete-employee-modal>
        <has-access-been-updated-modal
            v-if="is_has_access_updated_model_shown"
            :employee_id="deleteemployeemodal_employee_id"
            @close-model="deleteEmployeeToggle"
            @close-access-update-reminder="
                is_has_access_updated_model_shown = false
            "
            @delete-employee="deleteEmployeeSubmit"
        ></has-access-been-updated-modal>
        <send-employee-agreement-modal
            v-if="is_send_employee_agreement_modal_shown"
            :send_agreement_employee_data="employee_item"
            :disable_agreement_submit_btn="disable_agreement_submit_btn"
            @close-model="sendEmployeeAgreementToggle"
            @open-send-employee-agrrement-modal="sendAgreementToggle"
            @upload-file-for-agreement = "uploadFileUrlForAgreementToggle"
        ></send-employee-agreement-modal>
        <send-agreement-modal
            v-if="is_sendagreementmodal_shown"
            :send_agreement_employee_data="employee_item"
            :disable_agreement_submit_btn="disable_agreement_submit_btn"
            @close-model="sendAgreementToggle"
            @send-agreement-email="sendAgreementEmail"
            @send-reminder-email="sendReminderEmail"
        ></send-agreement-modal>
        <upload-file-for-agreement-modal
            v-if="is_upload_file_for_agreement_modal_shown"
            :employee_id="employee_item.id"
            @load-employee-list="loadEmployeeList"
            @close-model="uploadFileUrlForAgreementToggle"
            />
        <complete-agreement-modal
            v-if="is_complete_agreement_modal_shown"
            :send_agreement_employee_data="employee_item"
            :disable_agreement_submit_btn="disable_agreement_submit_btn"
            @close-model="completeAgreementToggle"
             />
        <access-right-modal
            v-if="show_access_right_modal"
            :employee_data="employee_item"
            :all_locations="all_location_list_for_access_rights"
            @close-model="accessRightModalToggle"
            @load-location-data="accessRightModalToggle"
            @change-access-rights-count="changeAccessRightsCount"
        ></access-right-modal>
        <pause-unpause-modal
            v-if="is_pause_unpause_modal_shown"
            :employee_data="employee_item"
            @close-model="pauseUnpauseModalToggle"
            @change-employee-status="updateEmployeeStatus"
        ></pause-unpause-modal>

        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from "lodash";
import { useVuelidate } from '@vuelidate/core';
import {required, requiredIf, email, minLength,maxLength, helpers } from "@vuelidate/validators";
import deleteEmployeeModal from "./deleteEmployeeModal.vue";
import sendAgreementModal from "./sendAgreementModal.vue";
import clearDropdownIcon from "../common/icons/clearDropdownIcon.vue";
import userCard from "../common/icons/userCard.vue";
import pendingfileIcon from "../common/icons/pendingfileIcon.vue";
import completeIcon from "../common/icons/completeIcon.vue";
import sendIcon from "../common/icons/sendIcon.vue";
import infoIcon from "../common/icons/infoIcon.vue";
import {
    checkSpecialChars,
    checkSpecialCharsErrorMessage,
} from "../common/customValidation";
import AccessRightModal from "./AccessRightModal.vue";
import fullPageLoader from "../common/fullPageLoader.vue";
import hasAccessBeenUpdatedModal from "./hasAccessBeenUpdatedModal.vue";
import pauseUnpauseModal from "./PauseUnpauseModal.vue";
import pdfIcon from "../common/icons/pdfIcon.vue";
import sendEmployeeAgreementModal from "./sendEmployeeAgreementModal.vue";
import uploadFileForAgreementModal from "./uploadFileForAgreementModal.vue";
import completeAgreementModal from "./completeAgreementModal.vue"
const { withAsync } = helpers
import mitt from 'mitt'
const emitter = mitt()

export default {
    data() {
        return {
            employee_id: "",
            first_name: "",
            last_name: "",
            email: "",
            phone_number: "",
            agreement_btn_class:'',
            selected_secondary_work_locations: [],
            all_location_list_for_secondary: [],
            selected_primary_work_location: null,
            is_employee_editing: false,
            disable_editemployee_submit_btn: false,
            check_emp_available_timer: null,
            edit_employee_change_email_timer: null,
            fetched_account_user: {},
            is_deleteemployeemodal_shown: false,
            deleteemployeemodal_employee_id: "",
            is_sendagreementmodal_shown: false,
            disable_agreement_submit_btn: false,
            is_secondary_work_location_applicable: false,
            JS_APP_URL: JS_APP_URL,
            checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
            show_access_right_modal: false,
            all_location_list_for_access_rights: [],
            employee_access_rights_count:
                this.employee_item.employee_access_rights_count,
            is_full_page_loader_shown: false,
            is_has_access_updated_model_shown: false,
            is_pause_unpause_modal_shown: false,
            is_send_employee_agreement_modal_shown: false,
            is_upload_file_for_agreement_modal_shown: false,
            is_complete_agreement_modal_shown: false

        };
    },
    emits: ["set-employeeid-for-send-agreement", "close_other_employee_edit", "updated-employee", "load-employee-list","deleted-employee"],
    setup: () => ({ v$: useVuelidate() }),
    validations() {
        var validationArray = {
            first_name: {
                required: helpers.withMessage('Please enter a first name', required),
                maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
           last_name: {
                required: helpers.withMessage('Please enter a last name', required),
                maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            email: {
                required: helpers.withMessage('Please enter an email', required),
                email: helpers.withMessage('Please enter a valid email', email),
                maxLength: helpers.withMessage('Max 100 characters allowed', maxLength(100)),
                 isUnique: helpers.withMessage('Email address already in use', helpers.withAsync(async (value) => {
                    if (!value) return true;
                    if (!this.v$.email.required || !this.v$.email.email) return true;
                    this.disable_editemployee_submit_btn = true;
                    let check_promise = new Promise((resolve, reject) => {
                        if (this.check_emp_available_timer) {
                            clearTimeout(this.check_emp_available_timer)
                            this.check_emp_available_timer = null
                        }
                        this.check_emp_available_timer = setTimeout(() => {
                            return fetch(JS_APP_URL + `/employee/check-unique-email-employee/${value}/` + this.employee_id).then(response => {
                                if (response.ok) {
                                    resolve(response.text())
                                } else {
                                    resolve(new Error('error'))
                                }
                            }, error => {
                                resolve(new Error('error'))
                            })
                        }, 500);
                    });
                    var response = await check_promise;
                    this.disable_editemployee_submit_btn = false;
                    return Boolean((response == 'available') ? false : true);
                }))
            },
            phone_number: {
                required: helpers.withMessage('Please enter a phone number', required),
                minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
                maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
            },
        };
        if (this.all_location_list.length > 1) {
            validationArray.selected_primary_work_location = {
                required: helpers.withMessage('Please select a primary work location', required)
            };
            validationArray.selected_secondary_work_locations = {
                required: helpers.withMessage('Please select secondary work location(s)', requiredIf(() => {
                    return !this.is_secondary_work_location_applicable
                }))
            };
        }
        return validationArray;
    },
    props: {
        employee_item: {
            type: Object,
            default: () => {},
        },
        all_location_list: {
            type: Array,
            default: () => [],
        },
        employee_id_for_open_send_agreement: {
            type: Number,
        },
    },
    components: {
        deleteEmployeeModal,
        hasAccessBeenUpdatedModal,
        clearDropdownIcon,
        sendAgreementModal,
        userCard,
        pendingfileIcon,
        completeIcon,
        sendIcon,
        infoIcon,
        AccessRightModal,
        fullPageLoader,
        pauseUnpauseModal,
        pdfIcon,
        sendEmployeeAgreementModal,
        uploadFileForAgreementModal,
        completeAgreementModal
    },
    watch: {
        is_secondary_work_location_applicable() {
            if (this.is_secondary_work_location_applicable) {
                this.selected_secondary_work_locations = [];
            }
        },
        employee_item () {
            this.employee_access_rights_count =
                this.employee_item.employee_access_rights_count;
        },
    },
    computed:{
        agreementStatus(){
            if(!this.employee_item.employee_agreement || Object.keys(this.employee_item.employee_agreement).length === 0){
                this.agreement_btn_class = 'send-action-btn'
                return 'send';
            }
            if(this.employee_item.employee_agreement && Object.keys(this.employee_item.employee_agreement).length > 0){
                if(this.employee_item.employee_agreement.agreement_type === 'system'){
                    if(this.employee_item.employee_agreement.signature === null ||  this.employee_item.employee_agreement.file_name === null){
                        this.agreement_btn_class = 'pending-action-btn'
                        return 'pending';
                    }
                    if(this.employee_item.employee_agreement.signature !== null &&  this.employee_item.employee_agreement.file_name !== null){
                        this.agreement_btn_class = 'complete-action-btn'
                        return 'complete';
                    }
                }
                if(this.employee_item.employee_agreement.agreement_type === 'doc'){
                    if(this.employee_item.employee_agreement.file_name !== null){
                        this.agreement_btn_class = 'complete-action-btn'
                        return 'complete';
                    }
                }
            }
        }
    },
    mounted () {
        if (
            this.employee_id_for_open_send_agreement != null &&
            this.employee_id_for_open_send_agreement == this.employee_item.id
        ) {
            this.sendAgreementToggle();
            this.$emit("set-employeeid-for-send-agreement", null);
        }
        emitter.on("close_other_employee_edit", (employee_id) => {
            if (employee_id !== this.employee_item.id) {
                this.is_employee_editing = false;
            }
        });
    },
    methods: {
        completeAgreementToggle(status = true){
            this.is_complete_agreement_modal_shown = status;
        },
        uploadFileUrlForAgreementToggle(status = true){
            this.is_sendagreementmodal_shown = false;
            this.is_send_employee_agreement_modal_shown = false;
            this.is_upload_file_for_agreement_modal_shown = status
        },
        loadEmployeeList(){
            this.$emit("load-employee-list", true);
        },
        updateEmployeeStatus($status) {
            NProgress.start();
            axios
                .post(JS_APP_URL + "/employee/change-employee-status", {
                    employee_id: this.employee_item.id,
                    type: $status,
                })
                .then((response) =>  {
                    if (response["data"]["status"] == "Error") {
                        if (response["data"]["data"].length > 0) {
                            toastr.error(
                                response["data"]["data"].join("</br>"),
                                "Error"
                            );
                        } else {
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        toastr.success(response["data"]["message"], "Success");
                        this.$emit("updated-employee", response["data"]["data"]);
                        this.is_pause_unpause_modal_shown = false;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                });
        },
        pauseUnpauseModalToggle(status = true) {
            this.is_pause_unpause_modal_shown = status;
        },
        openAccessUpdatedModal(){
            this.is_deleteemployeemodal_shown = false;
            this.is_has_access_updated_model_shown = true;
        },
        onChangePrimaryWorkLocation() {
            if (this.selected_primary_work_location != null) {
                this.selected_secondary_work_locations = [];
                if (this.all_location_list.length > 0) {
                    this.all_location_list_for_secondary = [{
                        'select_all': 'Select All',
                        'group_option_list': [...this.all_location_list],
                    }];
                    var found_index = _.findIndex(this.all_location_list_for_secondary[0]['group_option_list'], (o) => { return o.id === this.selected_primary_work_location.id; });
                    if (found_index >= 0) {
                        this.all_location_list_for_secondary[0]['group_option_list'].splice(found_index, 1);
                    }
                }
            }
        },
        editEmployee() {
            this.employee_id = this.employee_item.id;
            this.first_name = this.employee_item.first_name;
            this.last_name = this.employee_item.last_name;
            this.email = this.employee_item.email;
            this.phone_number = this.employee_item.phone_number;
            this.selected_primary_work_location =this.employee_item.employee_primary_work_location;
            this.selected_secondary_work_locations = [];
            _.forEach(this.employee_item.employee_secondary_work_location, (value) => {
                var is_found_location = _.find(this.all_location_list, (o) => { return o.id === value.location.id; });
                if (!_.isUndefined(is_found_location)) {
                    this.selected_secondary_work_locations.push(is_found_location);
                }
            });
            if (this.selected_secondary_work_locations.length == 0) {
                this.is_secondary_work_location_applicable = true;
            } else {
                this.is_secondary_work_location_applicable = false;
            }
            if (this.all_location_list.length > 0) {
              this.all_location_list_for_secondary = [{
                select_all: "Select All",
                group_option_list: [...this.all_location_list],
            },];
            var found_index = _.findIndex(this.all_location_list_for_secondary[0]['group_option_list'], (o) => { return o.id === this.selected_primary_work_location.id; });
            if (found_index >= 0) {
                this.all_location_list_for_secondary[0]['group_option_list'].splice(found_index, 1);
            }
          }
          setTimeout(() => {
            this.is_employee_editing = true;
            this.$root.$emit("close_other_employee_edit", this.employee_id);
          }, 100);
        },
        editEmployeeSubmit() {
            this.v$.$touch();
            if (!this.v$.$invalid) {
                var location_work_new = new Array();
                var location_work_removed = new Array();
                if (this.all_location_list.length > 1) {
                  _.forEach(this.selected_secondary_work_locations, (value) => {
                    if (_.isUndefined(_.find(this.employee_item.employee_secondary_work_location, (o) => { return o.location.id == value.id; }))) {
                        location_work_new.push({ "location_id": value.id });
                    }
                  });
                  _.forEach(this.employee_item.employee_secondary_work_location, (value) => {
                    if (_.isUndefined(_.find(this.selected_secondary_work_locations, (o) => { return o.id == value.location.id; }))) {
                        location_work_removed.push({ "location_id": value.location.id });
                    }
                  });
                }
                NProgress.start();
                this.disable_editemployee_submit_btn = true;
                axios
                    .post(JS_APP_URL + "/employee/edit-employee", {
                        employee_id: this.employee_id,
                        first_name: this.first_name,
                        last_name: this.last_name,
                        email: this.email,
                        phone_number: this.phone_number,
                        primary_work_location_id:
                            this.all_location_list.length == 1
                                ? this.all_location_list[0].id
                                : this.selected_primary_work_location.id,
                        location_work_new: location_work_new,
                        location_work_removed: location_work_removed,
                    })
                    .then((response) => {
                        if (response["data"]["status"] == "Error") {
                            if (response["data"]["data"].length > 0) {
                                toastr.error(
                                    response["data"]["data"].join("</br>"),
                                    "Error"
                                );
                            } else {
                                toastr.error(
                                    response["data"]["message"],
                                    "Error"
                                );
                            }
                        } else {
                            toastr.success(
                                response["data"]["message"],
                                "Success"
                            );
                            setTimeout(() => {
                                this.is_employee_editing = false;
                                this.$emit(
                                    "updated-employee",
                                    response["data"]["data"]
                                );
                            }, 100);
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        NProgress.done();
                        this.disable_editemployee_submit_btn = false;
                    });
            }
        },
        deleteEmployeeToggle(status = true) {
            this.deleteemployeemodal_employee_id = this.employee_item.id;
            this.is_deleteemployeemodal_shown = status;
            setTimeout(() => {
                this.$root.$emit(
                    "close_other_employee_edit",
                    this.employee_item.id
                );
            }, 100);
        },
        deleteEmployeeSubmit() {
            if (this.deleteemployeemodal_employee_id) {
                NProgress.start();
                axios
                    .post(JS_APP_URL + "/employee/delete-employee", {
                        employee_id: this.deleteemployeemodal_employee_id,
                    })
                    .then((response) => {
                        if (response["data"]["status"] == "Error") {
                            if (response["data"]["data"].length > 0) {
                                toastr.error(
                                    response["data"]["data"].join("</br>"),
                                    "Error"
                                );
                            } else {
                                toastr.error(
                                    response["data"]["message"],
                                    "Error"
                                );
                            }
                        } else {
                            toastr.success(
                                response["data"]["message"],
                                "Success"
                            );
                            setTimeout(() => {
                                this.$emit(
                                    "deleted-employee",
                                    this.deleteemployeemodal_employee_id
                                );
                            }, 100);
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        NProgress.done();
                        this.is_deleteemployeemodal_shown = false;
                        this.is_has_access_updated_model_shown = false;
                    });
            }
        },
        sendEmployeeAgreementToggle(){
            if(this.is_send_employee_agreement_modal_shown == false){
                this.is_send_employee_agreement_modal_shown = true;
            }else{
                this.is_send_employee_agreement_modal_shown = false;
            }
        },
        sendAgreementToggle(status = true) {
            if(status == true){
                let check_location_found = _.find(this.all_location_list, (location) => {
                    if (location.id == this.employee_item.primary_work_location_id) {
                        return true;
                    }
                });
                if(typeof check_location_found === "undefined"){
                    toastr.error('Please complete company information and HCO.',"Error");
                }else{
                    this.is_sendagreementmodal_shown = true;
                }
            }else{
                // get latest emp data and replace in array for better logic
                this.is_sendagreementmodal_shown = false;
                this.is_send_employee_agreement_modal_shown = false;
            }

        },
        sendAgreementEmail(is_send_to_all_employee = false) {
            NProgress.start();
            this.disable_agreement_submit_btn = true;
            axios
                .post(JS_APP_URL + "/employee/send-agreement-email", {
                    employee_id: this.employee_item.id,
                    is_send_to_all_employee: is_send_to_all_employee,
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if (response["data"]["data"].length > 0) {
                            toastr.error(
                                response["data"]["data"].join("</br>"),
                                "Error"
                            );
                        } else {
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        toastr.success(response["data"]["message"], "Success");
                        this.$emit("load-employee-list", true);
                        this.sendAgreementToggle(false);
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.disable_agreement_submit_btn = false;
                });
        },
        sendReminderEmail(){
            NProgress.start();
            this.disable_agreement_submit_btn = true;
            axios
                .post(JS_APP_URL + "/employee/send-reminder-email", {
                    employee_id: this.employee_item.id,
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if (response["data"]["data"].length > 0) {
                            toastr.error(
                                response["data"]["data"].join("</br>"),
                                "Error"
                            );
                        } else {
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        toastr.success(response["data"]["message"], "Success");
                        this.sendAgreementToggle(false);
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.disable_agreement_submit_btn = false;
                });
        },
        cancelEditEmployee() {
            this.is_employee_editing = false;
        },
        accessRightModalToggle(status = true) {
            if (status == true) {
                this.is_full_page_loader_shown = true;
                axios
                    .get(
                        JS_APP_URL +
                            "/employee/get-work-locations?employee_id=" +
                            this.employee_item.id
                    )
                    .then((response) => {
                        if (response["data"]["status"] == "Success") {
                            this.all_location_list_for_access_rights =
                                response["data"]["data"];
                            this.show_access_right_modal = true;
                        } else {
                            if (response["data"]["data"].length > 0) {
                                toastr.error(
                                    response["data"]["data"].join("</br>"),
                                    "Error"
                                );
                            } else {
                                toastr.error(
                                    response["data"]["message"],
                                    "Error"
                                );
                            }
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        this.is_full_page_loader_shown = false;
                    });
            } else {
                this.show_access_right_modal = false;
            }
        },
        changeAccessRightsCount(count) {
            this.employee_access_rights_count = count;
        },
        downloadAgreementWithoutSignature(employee_id) {
            NProgress.start();
            axios
                .get(JS_APP_URL + "/employee/download-agreement-without-signature?employee_id=" + employee_id)
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        var link = document.createElement("a");
                        link.setAttribute("href", response["data"]['data']['download_url']);
                        link.setAttribute("download", response["data"]['data']['file_name']);
                        link.setAttribute("target", '_blank');
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    setTimeout(() => {
                        NProgress.done();
                    }, 100);
                });
        },
    },
    created() {
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.is_employee_editing = false;
            }
        });
    },
};
</script>
