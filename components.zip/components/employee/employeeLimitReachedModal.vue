<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
            <button v-on:click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb15 pt20">
                <img :src="JS_APP_URL + '/images/triangle-warning.svg'" alt="" title="" class="warning-icon-modal" />
            </div>
            <h2
                class="
                font-24 font_semibold blueog--text line-normal text-center mb20
                "
            >
                Employee limit reached!
            </h2>
            <p v-if="AUTH_USER.user_type == 'PCO'" class="text-center font-16 gray_checkmark--text line-normal mb30">Looks like you've reached the maximum amount of employees for your account. If you'd like to add additional employees, please visit the <i>Upgrade</i> page by clicking the button below!</p>
            <p v-if="AUTH_USER.user_type != 'PCO'" class="text-center font-16 gray_checkmark--text line-normal mb30">Looks like you've reached the maximum amount of employees for your account. Reach out to your Primary Compliance Officer, {{pco_user_data.first_name}} {{ pco_user_data.last_name}}, to let them know the account needs to be upgraded.</p>
            <div v-if="AUTH_USER.user_type == 'PCO'" class="flex flex-wrap items-center justify-center pb40">
                <button @click="upgrade()" class="btn-primary-outline h-32 mx5">UPGRADE</button>
            </div>
            <div v-else class="flex flex-wrap items-center justify-center pb40">
                <button v-on:click="closeModal()" class="btn-primary-outline h-32 mx5">GOT IT!</button>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";
import axios from "axios";
import fullPageLoader from '../common/fullPageLoader.vue';
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;

export default {
  props: {
  },
  components:{
    closeIcon,
    fullPageLoader,
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      AUTH_USER: AUTH_USER,
      pco_user_data: {}
    };
  },
  mounted() {
    this.getPcoData();
  },
  emits: ["close-model"],
  methods: {
    getPcoData() {
      axios.get(JS_APP_URL + '/general/get-main-user-data')
      .then((response) => {
        this.pco_user_data = response.data.data
      })
      .catch((error) => {
      })
    },
    closeModal() {
      this.$emit("close-model", false);
    },
    upgrade() {
      window.location = JS_APP_URL + '/upgrade'
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
