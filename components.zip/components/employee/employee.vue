<template>
  <div>
    <header-after-login></header-after-login>
    <div class="container pt30 pb60">
      <h1 class="page-center-title text-center font-24 font_semibold blueog--text line-normal mb40">Employees</h1>

      <filter-employee
      :key="filter_component_key"
      :all_location_list="all_location_list"
      :is_add_employee_shown="is_add_employee_shown"
      :is_refresh_btn_shown="is_refresh_btn_shown"
      :sample_import_file_link="sample_import_file_link"
      @add-employee-form-toggle="addEmployeeFormToggle"
      @apply-filter="applyFilter"
      @reset-all-filter="resetAllFilter"
      @load-employee-list="loadEmployeeList"
      @open-import-modal="openCloseImportModal"
      >
      </filter-employee>

      <transition name="simple-fade-transition">
      <add-employee v-if="is_add_employee_shown" :all_location_list="all_location_list" @add-employee-form-toggle="addEmployeeFormToggle" @load-employee-list="loadEmployeeList" @reset-all-filter="resetAllFilter" @set-employeeid-for-send-agreement="setEmployeeIdForSendAgreementPopup"></add-employee>
      </transition>

      <div >
        <employee-item v-for="(emp_item, index) in employee_list" v-bind:key="index" :employee_item="emp_item" :all_location_list="all_location_list"
        :employee_id_for_open_send_agreement="employee_id_for_open_send_agreement" @load-employee-list="loadEmployeeList" @deleted-employee="deleteEmployee" @updated-employee="updatedEmployee" @set-employeeid-for-send-agreement="setEmployeeIdForSendAgreementPopup"></employee-item>
        <div v-if="!is_full_page_loader_shown && employee_list.length === 0" class="">
          <div class="user-detail-text font-14 gray_checkmark--text text-center">
            <no-data-icon></no-data-icon>
            <div class="font-14 text-center blueog--text">No employee(s) available.</div>
          </div>
        </div>
      </div>
      <InfiniteLoading @infinite="loadEmployeeList(false)" />
      <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>

    </div>
       <import-error-modal 
          v-if="is_import_error_modal"
          :import_errors="import_errors_data"
          @close-model="openCloseImportModal"
        />
  </div>
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from '../common/fullPageLoader.vue';
import addEmployee from "./addEmployee.vue"
import filterEmployee from "./filterEmployee.vue"
import employeeItem from "./employeeItem.vue"
import noDataIcon from '../common/icons/noDataIcon.vue';
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import importErrorModal from "../common/includes/importErrorModal.vue";
import _ from "lodash";
export default {
  data() {
    return {
      employee_list: [],
      is_list_loading: false,
      per_page_records: 10,
      current_page: 1,
      total_page: 1,
      all_location_list: [],
      is_add_employee_shown: false,
      is_full_page_loader_shown: false,
      is_refresh_btn_shown: false,
      employee_id_for_open_send_agreement:null,
      sort_by: '',
      sort_by_dir: '',
      filter_by_location: [],
      search_query: "",
      filter_component_key: Math.random(),
      sample_import_file_link: '',
		  JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      is_import_error_modal: false,
      import_errors_data: [],
      call_ajax: 1
    };
  },
  components: {
    addEmployee,
    filterEmployee,
    employeeItem,
    fullPageLoader,
    noDataIcon,
    headerAfterLogin,
    importErrorModal
  },
  mounted() {
	  this.loadLocationList();
  },
  watch: {
  },
  computed: {

  },
  methods:{
    addEmployeeFormToggle(status = true){
      this.is_add_employee_shown = status;
    },
    applyFilter(search_params = {}){
      this.filter_by_location = search_params.filter_by_location;
      this.sort_by = search_params.sort_by;
      this.sort_by_dir = search_params.sort_by_dir;
      this.search_query = search_params.search_query;
      setTimeout(() => {
        this.loadEmployeeList(true);
      }, 100);
    },
    resetAllFilter(){
      this.sort_by = '';
      this.sort_by_dir = '';
      this.filter_by_location = [];
      this.search_query = "";
      this.filter_component_key = Math.random();
    },
    deleteEmployee(employee_id = ''){
      if(employee_id){
        var found_index = _.findIndex(this.employee_list, (o) =>  { return o.id === employee_id; });
        if(found_index >= 0){
          this.employee_list.splice(found_index, 1);
          if(this.employee_list.length == 0){
            this.showRefreshListButton();
          }
        }
      }
    },
    updatedEmployee(employee_updated = {}) {
      if (!_.isEmpty(employee_updated)) {
        var found_index = _.findIndex(this.employee_list, (o) => { return o.id === employee_updated.id; });
        if (found_index >= 0) {
          this.employee_list[found_index] = employee_updated
          this.showRefreshListButton();
        }
      }
    },
    loadLocationList(){
      this.is_full_page_loader_shown = true;
      axios
      .get(JS_APP_URL + "/general/get-employee-module-location-list")
      .then((response) => {
        if (response["data"]["status"] == "Success") {
          this.all_location_list = response["data"]["data"];
          if(this.all_location_list.length == 0){
            window.location = JS_APP_URL + "/dashboard";
          }
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";
        }
      })
      .then(() => {
        // this.is_full_page_loader_shown = false;
      });
    },
    loadEmployeeList(need_pagination_reset = false){
      if(need_pagination_reset){
        this.current_page = 1;
        this.total_page = 1;
        this.employee_list = [];
      }
      if (this.current_page <= this.total_page && this.call_ajax == 1) {
        this.is_list_loading = true;
        this.is_full_page_loader_shown = true;
        this.call_ajax = 0;
        axios
          .post(JS_APP_URL + "/employee/get-employee-list", {
            filter_by_location: _.map(this.filter_by_location, 'id'),
            sort_by: this.sort_by,
            sort_by_dir: this.sort_by_dir,
            search_query: this.search_query,
            per_page: this.per_page_records,
            page: this.current_page
          })
          .then((response) => {
            if (response["data"]["status"] == "Success") {
              var employee_data = response["data"]["data"]['employee_list'];
              this.sample_import_file_link = response["data"]["data"]['sample_import_file_link'];
              this.employee_list.push(...employee_data.data);
              this.total_page = employee_data.last_page;
              if(this.employee_list.length == 0 && this.search_query == '' && this.filter_by_location.length  == 0 && this.sort_by == ''){
                this.is_add_employee_shown = true;
              }
              this.current_page = this.current_page + 1;
              this.is_list_loading = false;
              this.is_refresh_btn_shown = false;
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            setTimeout(() => {
              this.call_ajax = 1;
              this.is_full_page_loader_shown = false;
            }, 100);
          });
      }
    },
    showRefreshListButton(){
      if(this.sort_by != "" || this.filter_by_location.length > 0 || this.search_query != ""){
        this.is_refresh_btn_shown = true;
      }
    },
    setEmployeeIdForSendAgreementPopup(id) {
      this.employee_id_for_open_send_agreement = id
    },
    openCloseImportModal(import_errors) {
      if(!this.is_import_error_modal) {
        this.is_import_error_modal = true
        this.import_errors_data = import_errors;
      } else {
        this.is_import_error_modal = false
      }
    },
  }
};
 </script>