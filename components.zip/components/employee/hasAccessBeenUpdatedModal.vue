<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
            <div class="modal-wrapper animate__animated animate__zoomIn">
                <div class="modal-container Whoa-modal">
                    <div class="text-center mlr-auto mb30 pt20">
                        <img
                            :src="JS_APP_URL + '/images/access_updated.png'"
                            alt=""
                            title=""
                            class="warning-icon-modal"
                        />
                    </div>
                    <h2
                        class="font-24 font_semibold blueog--text line-normal text-center mb20"
                    >
                        Has access been updated?
                    </h2>
                    <p
                        class="text-center font-16 gray_checkmark--text line-normal mb30"
                    >
                        When terminating an employee, you must remove or revoke
                        their access to your facility and software including any
                        login information, key cards, or other unique access
                        methods. Have you completed all necessary updates to
                        this employee's access?
                    </p>
                    <div
                        class="flex flex-wrap items-center justify-center pb40"
                    >
                        <button
                            :disabled="is_btn_disabled"
                            v-on:click="addAccessUpdateReminder"
                            class="btn-cancel-outline mx5"
                        >
                            REMIND ME LATER
                        </button>
                        <button
                            :disabled="is_btn_disabled"
                            v-on:click.once="deleteEmployeeSubmit"
                            class="btn-primary btn-width-136 mx5 px30 mt-xs-20"
                        >
                            ALREADY DONE!
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;

export default {
    props: {
        employee_id: {
            type: Number,
            default: () => 0,
        },
    },
    components: {},
    emits: ["delete-employee", "close-access-update-reminder","close-model"],

    data() {
        return {
            is_btn_disabled: false,
            JS_APP_URL: JS_APP_URL,
        };
    },
    methods: {
        addAccessUpdateReminder() {
            this.is_btn_disabled = true;
            NProgress.start();
            axios
                .post(JS_APP_URL + "/employee/add-access-update-reminder", {
                    employee_id: this.employee_id,
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if (response["data"]["data"].length > 0) {
                            toastr.error(
                                response["data"]["data"].join("</br>"),
                                "Error"
                            );
                        } else {
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                            this.$emit("delete-employee");
                            this.$emit("close-access-update-reminder");
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.$emit("close-access-update-reminder");
                    this.is_btn_disabled = false;
                });
        },
        deleteEmployeeSubmit() {
            this.is_btn_disabled = true;
            this.$emit("delete-employee");
        },
    },
    created() {
        // document.body.classList.add("modal-open");
    },
    destroyed() {
        // document.body.classList.remove("modal-open");
    },
};
</script>
