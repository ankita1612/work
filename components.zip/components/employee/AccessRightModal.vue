<template>
  <Teleport to="body">
    <transition name="modal">
        <div>
        <div class="modal-mask modal-scrollable access-right-modal">
            <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
                <button
                v-if="!disable_submit_btn"
                @click="closeModal"
                class="cursor-pointer modal-close"
                >
                <close-icon></close-icon>
                </button>
                <div class="text-center mlr-auto mb15 pt20 white-no-wrap">
                <div
                    class="form-group mb-0 location-dropdon mlr-auto"
                    v-if="all_locations.length > 1"
                >
                    <multiselect
                    class="company-location-select"
                    v-model="selected_location"
                    :options="all_locations"
                    label="location_nickname"
                    :taggable="false"
                    :multiple="false"
                    :close-on-select="true"
                    :showLabels="false"
                    track-by="id"
                    placeholder=""
                    :allowEmpty="false"
                    >
                    <template #noResult>
                        <div class="multiselect__noResult text-center">
                        No results found
                        </div>
                    </template>
                    </multiselect>
                    <label class="label label-select label-float">Location</label>
                </div>
                <div class="form-group mb-0 location-dropdon single-location-access-text text-truncate mlr-auto" :title="all_locations[0].location_nickname" v-else>
                    {{ all_locations[0].location_nickname }}
                </div>
                </div>

                <h2
                class="
                    font-24 font_semibold
                    blueog--text
                    line-normal
                    text-center
                    mb30
                "
                >
                {{
                    employee_data.first_name + " " + employee_data.last_name
                }}
                Access Rights
                </h2>
                <form @submit.prevent="editAccessRight" v-if="is_edit_mode == true">
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10"> Does this employee have a key to the facility?</h4>
                <div class="flex flex-wrap items-center justify-center mb20" :class="{ 'form-group--error': v$.facility_access_key.$error }">
                    <div class="radio mr16">
                    <input
                        id="facility_access_key_yes"
                        name="facility_access_key"
                        v-model.trim="v$.facility_access_key.$model"
                        type="radio"
                        value="Yes"
                    />
                    <label
                        for="facility_access_key_yes"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >Yes</label
                    >
                    </div>
                    <div class="radio mr16">
                    <input
                        id="facility_access_key_no"
                        name="facility_access_key"
                        v-model.trim="v$.facility_access_key.$model"
                        type="radio"
                        value="No"
                    />
                    <label
                        for="facility_access_key_no"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >No</label
                    >
                    </div>
                    <div v-if="v$.facility_access_key.$errors.length > 0">
                    <div class="form-error-text fill-width text-align-center">
                        {{ v$.facility_access_key.$errors[0].$message }}
                    </div>
                    </div>
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10"> Does this employee have full facility access?</h4>
                <div class="flex flex-wrap items-center justify-center mb20" :class="{ 'form-group--error': v$.full_facility_access.$error }">
                    <div class="radio mr16">
                    <input
                        id="full_facility_access_yes"
                        name="full_facility_access"
                        type="radio"
                        v-model.trim="v$.full_facility_access.$model"
                        value="Yes"
                    />
                    <label
                        for="full_facility_access_yes"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >Yes</label
                    >
                    </div>
                    <div class="radio mr16">
                    <input
                        id="full_facility_access_no"
                        name="full_facility_access"
                        v-model.trim="v$.full_facility_access.$model"
                        type="radio"
                        value="No"
                    />
                    <label
                        for="full_facility_access_no"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >No</label
                    >
                    </div>
                    <div v-if="v$.full_facility_access.$errors.length > 0">
                    <div class="form-error-text fill-width text-align-center">
                        {{ v$.full_facility_access.$errors[0].$message }}
                    </div>
                    </div>
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10"> Does this employee have full software access?</h4>
                <div class="flex flex-wrap items-center justify-center mb20" :class="{ 'form-group--error': v$.full_software_access.$error }">
                    <div class="radio mr16">
                    <input
                        id="full_software_access_yes"
                        name="full_software_access"
                        v-model.trim="v$.full_software_access.$model"
                        type="radio"
                        value="Yes"
                    />
                    <label
                        for="full_software_access_yes"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >Yes</label
                    >
                    </div>
                    <div class="radio mr16">
                    <input
                        id="full_software_access_no"
                        name="full_software_access"
                        v-model.trim="v$.full_software_access.$model"
                        type="radio"
                        value="No"
                    />
                    <label
                        for="full_software_access_no"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >No</label
                    >
                    </div>
                    <div v-if="v$.full_software_access.$errors.length > 0">
                    <div class="form-error-text fill-width text-align-center">
                        {{ v$.full_software_access.$errors[0].$message }}
                    </div>
                    </div>
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10"> Does this employee have software admin Privileges?</h4>
                <div class="flex flex-wrap items-center justify-center mb20" :class="{ 'form-group--error': v$.software_admin_privilages.$error }">
                    <div class="radio mr16">
                    <input
                        id="software_admin_privilages_yes"
                        name="software_admin_privilages"
                        v-model.trim="v$.software_admin_privilages.$model"
                        type="radio"
                        value="Yes"
                    />
                    <label
                        for="software_admin_privilages_yes"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >Yes</label
                    >
                    </div>
                    <div class="radio mr16">
                    <input
                        id="software_admin_privilages_no"
                        name="software_admin_privilages"
                        v-model.trim="v$.software_admin_privilages.$model"
                        type="radio"
                        value="No"
                    />
                    <label
                        for="software_admin_privilages_no"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >No</label
                    >
                    </div>
                    <div v-if="v$.software_admin_privilages.$errors.length > 0">
                        <div class="form-error-text fill-width text-align-center">
                            {{ v$.software_admin_privilages.$errors[0].$message }}
                        </div>
                    </div>
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10">Does this employee have full network access?</h4>
                <div class="flex flex-wrap items-center justify-center mb20" :class="{ 'form-group--error': v$.full_network_access.$error }">
                    <div class="radio mr16">
                    <input
                        id="full_network_access_yes"
                        name="full_network_access"
                        v-model.trim="v$.full_network_access.$model"
                        type="radio"
                        value="Yes"
                    />
                    <label
                        for="full_network_access_yes"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >Yes</label
                    >
                    </div>
                    <div class="radio mr16">
                    <input
                        id="full_network_access_no"
                        name="full_network_access"
                        v-model.trim="v$.full_network_access.$model"
                        type="radio"
                        value="No"
                    />
                    <label
                        for="full_network_access_no"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >No</label
                    >
                    </div>
                    <div v-if="v$.full_network_access.$errors.length > 0">
                        <div class="form-error-text fill-width text-align-center">
                            {{ v$.full_network_access.$errors[0].$message }}
                        </div>
                    </div>
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10">Does this employee have network admin privileges?</h4>
                <div class="flex flex-wrap items-center justify-center mb20" :class="{ 'form-group--error': v$.network_admin_privilages.$error }">
                    <div class="radio mr16">
                    <input
                        id="network_admin_privilages_yes"
                        name="network_admin_privilages"
                        v-model.trim="v$.network_admin_privilages.$model"
                        type="radio"
                        value="Yes"
                    />
                    <label
                        for="network_admin_privilages_yes"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >Yes</label
                    >
                    </div>
                    <div class="radio mr16">
                    <input
                        id="network_admin_privilages_no"
                        name="network_admin_privilages"
                        v-model.trim="v$.network_admin_privilages.$model"
                        type="radio"
                        value="No"
                    />
                    <label
                        for="network_admin_privilages_no"
                        class="radio-label font-14 font-light gray_checkmark--text"
                        >No</label
                    >
                    </div>
                    <div v-if="v$.network_admin_privilages.$errors.length > 0">
                        <div class="form-error-text fill-width text-align-center">
                            {{ v$.network_admin_privilages.$errors[0].$message }}
                        </div>
                    </div>
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10"> If your office has a security alarm system, what is the code
                    this employee uses when entering the facility?</h4>
                    <div class="flex justify-center flex-wrap">
                    <div class="form-group mb-0 access-right-code-imput" :class="{ 'form-group--error': v$.security_code.$error }">
                        <input
                        class="form-input location-input-box"
                        v-model.trim="v$.security_code.$model"
                        :disabled="is_security_code_applicable"
                        type="text"
                        name="security_code"
                        />
                        <label class="label location-input-label" :class="{'label-float':v$.security_code.$model}">Code</label>
                        <div v-if="v$.security_code.$errors.length > 0">
                            <div class="form-error-text fill-width text-align-center">
                                {{ v$.security_code.$errors[0].$message }}
                            </div>
                        </div>
                    </div>

                    <div class="checkbox mx12 mt8">
                        <input
                        id="is_security_code_applicable"
                        name="is_security_code_applicable"
                        type="checkbox"
                        v-model="is_security_code_applicable"
                        @click="clearSecurityCodeInput"
                        />
                        <label
                        for="is_security_code_applicable"
                        class="checkbox-label font-14 font-light gray_checkmark--text"
                        >Not Applicable</label
                        >
                    </div>
                    </div>
                </div>

                <div class="checkbox mb20" v-if="all_locations.length > 1">
                    <input
                    v-model.trim="apply_to_all_location"
                    id="apply_to_all_location"
                    name="apply_to_all_location"
                    type="checkbox"
                    />
                    <label
                    for="apply_to_all_location"
                    class="checkbox-label font-14 font-light gray_checkmark--text"
                    >Apply access details to all locations that this employee
                    works at</label
                    >
                </div>

                <div class="flex flex-wrap items-center justify-center">
                    <button
                    :disabled="disable_submit_btn"
                    type="submit"
                    class="btn-primary"
                    >
                    <span>Submit</span>
                    </button>
                </div>
                </form>
                <div v-if="is_edit_mode == false">
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10">Does this employee have a key to the facility?</h4>
                <div class="flex flex-wrap items-center justify-center mb20 font-14 font_light gray_checkmark--text" >
                    {{selected_location.employee_access_right.facility_access_key}}
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10">Does this employee have full facility access?</h4>
                <div class="flex flex-wrap items-center justify-center mb20 font-14 font_light gray_checkmark--text" >
                    {{selected_location.employee_access_right.full_facility_access}}
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10">Does this employee have full software access?</h4>
                <div class="flex flex-wrap items-center justify-center mb20 font-14 font_light gray_checkmark--text">
                    {{selected_location.employee_access_right.full_software_access}}
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10">Does this employee have software admin privileges?</h4>
                <div class="flex flex-wrap items-center justify-center mb20 font-14 font_light gray_checkmark--text" >
                    {{selected_location.employee_access_right.software_admin_privilages}}
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10">Does this employee have full network access?</h4>
                <div class="flex flex-wrap items-center justify-center mb20 font-14 font_light gray_checkmark--text" >
                    {{selected_location.employee_access_right.full_network_access}}
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10">Does this employee have network admin privileges?</h4>
                <div class="flex flex-wrap items-center justify-center mb20 font-14 font_light gray_checkmark--text" >
                    {{selected_location.employee_access_right.network_admin_privilages}}
                </div>
                </div>
                <div class="text-center mb30 access-right-item">
                <h4 class="font-14 font_semibold gray_checkmark--text mb10">If your office has a security alarm system, what is the code
                    this employee uses when entering the facility?</h4>
                <div class="form-group font-14 font_light gray_checkmark--text" >
                    {{selected_location.employee_access_right.security_code == null ? 'Not Applicable' : selected_location.employee_access_right.security_code}}
                </div>
                </div>

                <div class="flex flex-wrap items-center justify-center">
                    <VTooltip :triggers="['hover']" :popperTriggers="['hover']">
                    <button @click="openEditMode" type="button"
                        class="action-icon-btn action-btn-blueog cursor-pointer ml7">
                        <img :src="JS_APP_URL + '/images/pencil.svg'" alt="" title="">
                    </button>
                    <template #popper>
                        Edit
                    </template>
                    </VTooltip>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="modal-backdrop"></div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
import { useVuelidate } from '@vuelidate/core';
import { required, requiredIf, maxLength, helpers } from "@vuelidate/validators";
import closeIcon from "../common/icons/closeIcon.vue";
import _ from "lodash";

export default {
  props: {  
    employee_data: {
      type: Object,
      default: () => {},
    },
    all_locations:{
      type: Array,
      default: () => [],
    }
   },
   setup: () => ({ v$: useVuelidate() }),
  components: {
    closeIcon
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      disable_submit_btn: false,
      apply_to_all_location: false,
      selected_location: {},
      facility_access_key: "No",
      full_facility_access: "No",
      full_software_access: "No",
      software_admin_privilages: "No",
      full_network_access: "No",
      network_admin_privilages: "No",
      security_code: "",
      is_security_code_applicable: true,
      is_edit_mode:null,
    };
  },
  emits: ["close-model", "load-location-data", "change-access-rights-count"],
   validations() {
    var validationArray = {
      facility_access_key:{
        required: helpers.withMessage("Please select a facility access type", required),
      },
      full_facility_access:{
        required: helpers.withMessage("Please select a full facility access", required),
      },
      full_software_access: {
          required: helpers.withMessage("Please select a full software access", required),
      },
      software_admin_privilages: {
        required: helpers.withMessage("Please select a software admin Privileges", required),
      },
      full_network_access: {
         required: helpers.withMessage("Please select a full network access", required),
      },
      network_admin_privilages: {
        required: helpers.withMessage("Please select a network admin privileges", required),
      },
      security_code: {
        required: helpers.withMessage("Please enter a security code", requiredIf(() => {
            return !this.is_security_code_applicable
        })),
        maxLength: helpers.withMessage("Max 30 characters allowed", maxLength(30)),
      }
    };
    return validationArray;
  },
  watch:{
    selected_location(val){
      if(val.employee_access_right != null){
        this.is_edit_mode = false
      }else{
       this.openEditMode();
      }
    }
  },
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
    openEditMode(){
       if(this.selected_location.employee_access_right != null){
          this.facility_access_key = this.selected_location.employee_access_right.facility_access_key
          this.full_facility_access = this.selected_location.employee_access_right.full_facility_access
          this.full_software_access = this.selected_location.employee_access_right.full_software_access
          this.software_admin_privilages = this.selected_location.employee_access_right.software_admin_privilages
          this.full_network_access = this.selected_location.employee_access_right.full_network_access
          this.network_admin_privilages = this.selected_location.employee_access_right.network_admin_privilages
          this.security_code = this.selected_location.employee_access_right.security_code
          if(this.selected_location.employee_access_right.security_code == null){
            this.is_security_code_applicable = true
          }else{
            this.is_security_code_applicable = false
          } 
        }else{
          this.facility_access_key = "No";
          this.full_facility_access = "No";
          this.full_software_access = "No";
          this.software_admin_privilages = "No";
          this.full_network_access = "No";
          this.network_admin_privilages = "No";
          this.security_code = "";
          this.is_security_code_applicable = true;
        }
        this.apply_to_all_location = false
        this.v$.$reset();
        this.is_edit_mode = true
    },
    clearSecurityCodeInput(){
      this.security_code = ""
    },
   async editAccessRight() {
        this.v$.$touch();
        const is_valid = await this.v$.$validate();
        if (is_valid) {
          NProgress.start();
          this.disable_submit_btn = true;
          let param = {
            apply_to_all_location: (this.apply_to_all_location == true)?'yes':'no',
            employee_id: this.employee_data.id,
            location_id: this.selected_location.id,
            facility_access_key: this.facility_access_key,
            full_facility_access: this.full_facility_access,
            full_software_access: this.full_software_access,
            software_admin_privilages: this.software_admin_privilages,
            full_network_access: this.full_network_access,
            network_admin_privilages: this.network_admin_privilages,
            security_code:this.security_code,
          };
            axios
            .post(JS_APP_URL + "/employee/employee-access-right-update",param)
            .then((response) => {
                if (response["data"]["status"] == "Error") {
                  if(response["data"]['data'].length > 0){
                      toastr.error(response["data"]['data'].join('</br>'), "Error");
                  }else{
                      toastr.error(response["data"]["message"], "Error");
                  }
                } else {
                    toastr.success(response["data"]["message"], "Success");
                    this.$emit('load-location-data',true);
                    setTimeout(() => {
                      var index = _.findIndex(this.all_locations, (o) => { return o.employee_access_right == null; });
                      if(index == -1){
                        var location_index = _.findIndex(this.all_locations,(o) => { return o.id == this.selected_location.id; });
                        this.selected_location = this.all_locations[location_index];
                        this.$emit('change-access-rights-count',this.all_locations.length);
                        this.is_edit_mode = false
                      }else{
                        this.selected_location = this.all_locations[index];
                      }
                    }, 800);
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                   window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
              setTimeout(() => {
                NProgress.done();
                this.disable_submit_btn = false;
              }, 800);
            });
        }
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.disable_submit_btn) {
        this.$emit("close-model", false);
      }
    });
  },
  mounted() {
    if(this.all_locations.length > 1){
      var index = _.findIndex(this.all_locations, (o) => { return o.employee_access_right == null; });
      if(index == -1){
        this.selected_location = this.all_locations[0];
      }else{
        this.selected_location = this.all_locations[index];
      }
    }else{
      this.selected_location = this.all_locations[0];
    }
  },
  destroyed() {
    // document.body.classList.remove('modal-open');
  },
};
</script>
