<template>
  <div>
    <p class="font-16 font-italic dark--text mb20">Items in trash will be deleted forever after 30 days.</p>
    <folder-list
      :folders="trashed_documents.folders"
      :layout_style="layout_style"
      :active_page="'trash_page'"
      @get-sub-document-list="getDeletedDocumetsList"
      :selected_location="selected_location"
      :parent_folder_id="parent_folder_id"
      :from_where="from_trash"
    ></folder-list>
    <file-list
      :files="trashed_documents.files"
      :layout_style="layout_style"
      :active_page="'trash_page'"
      @get-sub-document-list="getDeletedDocumetsList"
      :from_where="from_trash"
    ></file-list>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import fileList from "./fileList.vue";
import folderList from "./folderList.vue";
import fullPageLoader from "../common/fullPageLoader.vue";

export default {
  components: { fileList, folderList, fullPageLoader },
  emits: ["append-breadcrumb"],
  props: {
    selected_location: Object,
    layout_style: String,
    trash_page_direct_folder_id: Number,
    trash_page_direct_folder_name: String,
    trash_page:Number
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      trashed_documents: [],
      is_full_page_loader_shown: false,
      parent_folder_id:0,
      from_trash:'Trash'
    };
  },
  mounted() {
    this.getDeletedDocumetsList();
  },
  watch:{
    trash_page_direct_folder_id(){
      this.getDeletedDocumetsList(this.trash_page_direct_folder_id,this.trash_page_direct_folder_name,false)
    },
    trash_page(){
      this.getDeletedDocumetsList();
    }
  },
  methods: {
     appendBreadcrumb(folder_id = 0, folder_name = "") {
      this.$emit("append-breadcrumb", {
        name: folder_name,
        id: folder_id,
        type: "trash_folder",
      });
    },
    getDeletedDocumetsList(parent_folder_id = "", parent_folder_name = "",breadcum_add = true) {
      this.is_full_page_loader_shown = true;
      if(parent_folder_id == 0){
        parent_folder_id = ""
      }
      if(parent_folder_id != ""){
        this.parent_folder_id = parent_folder_id;
        if(breadcum_add == true && parent_folder_name != ""){
          this.appendBreadcrumb(parent_folder_id,parent_folder_name)
        }
      }
      let url =
        JS_APP_URL +
        "/abyde-drive/get-trashed-documents?location_id=" +
        this.selected_location.id+"&parent_folder_id="+parent_folder_id;
      axios
        .get(url)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.trashed_documents = response["data"]["data"];
          } else {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
  },
};
</script>
