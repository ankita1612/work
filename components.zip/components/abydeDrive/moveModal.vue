<template>
<div>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
            <button v-if="!btn_disable" @click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
            <h2
                class="
                font-28 font_semibold
                blueog--text
                line-normal
                text-center
                mb20
                "
            >
                {{ type == "file" ? "Move File" : "Move Folder" }}
            </h2>
            <div class="text-center drive-move-wrapper">
                <ul class="tree inline-block text-left mb40">
                <tree-item
                    :item="folder_tree_list"
                    @select-folder="selectFolder"
                    :destination_folder_id="destination_folder_id"
                ></tree-item>
                </ul>
            </div>

            <div class="flex flex-wrap items-center justify-center">
                <button
                type="submit"
                class="btn-primary-outline h-32"
                @click="moveToSelectedFolder"
                :disabled=btn_disable
                >
                Move
                </button>
            </div>
            </div>
        </div>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
        </div>
    </transition>
  </Teleport>
  <div class="modal-backdrop"></div>
</div>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import treeItem from "./treeItem.vue";
import fullPageLoader from "../common/fullPageLoader.vue";

export default {
  props: {
    selected_location: Object,
    location_id: Number,
    folder_id: {
      type: Number,
      default: null,
    },
    file_id: {
      type: Number,
      default: null,
    },
    type: String,
    parent_folder_id:{
      type: Number,
      default: null,
    },
  },

  components: { closeIcon, treeItem, fullPageLoader },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      folder_tree_list: {},
      is_full_page_loader_shown: false,
      destination_folder_id: '',
      btn_disable:false,
    };
  },
  mounted() {
    this.getFolderTree();
  },
  emits: ["get-sub-document-list", "close-modal"],
  watch:{
    destination_folder_id(val){
      if(val != 0){
        this.btn_disable = false
      }else{
        this.btn_disable = true
      }
    }
  },
  methods: {
    getFolderTree() {
      this.is_full_page_loader_shown = true;
      let url =
        JS_APP_URL +
        "/abyde-drive/get-folder-tree?location_id=" +
        this.location_id +
        "&type=" +
        this.type;
      if (this.folder_id) {
        url += "&folder_id=" + this.folder_id;
      }
      axios
        .post(url)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.folder_tree_list = response["data"]["data"];
          } else {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },

    closeModal() {
      this.$emit("close-modal");
    },

    selectFolder(item) {
        if(item.id == null) {
            this.destination_folder_id = 0;
        }
      this.destination_folder_id = item.id;
    },

    moveToSelectedFolder() {
      this.is_full_page_loader_shown = true;
      let url = JS_APP_URL + "/abyde-drive/";
      if (this.destination_folder_id == "") {
        toastr.error("Please select a destination folder", "Error");
        this.is_full_page_loader_shown = false;
        return;
      }
      let payload = {
        location_id: this.location_id,
        destination_folder_id: this.destination_folder_id,
      };
      if (this.type == "file") {
        url += "move-file";
        payload.file_id = this.file_id;
      }

      if (this.type == "folder") {
        url += "move-folder";
        payload.folder_id = this.folder_id;
      }
      this.btn_disable = true
      axios
        .post(url, payload)
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            toastr.success(response["data"]["message"], "Success");
            if(this.parent_folder_id != null){
              this.$emit("get-sub-document-list",this.parent_folder_id);
            }else{
              this.$emit("get-sub-document-list");
            }

            this.closeModal();
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
          this.btn_disable = false;
        });
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.btn_disable) {
        this.closeModal();
      }
    });
  },
    destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
