<template>
  <li>
    <button class="main-folder-name cursor-pointer flex items-center" :class="[(item.id == destination_folder_id) ? 'selected' : '']" type="button" @click="selectFolder(item)">
      <img
        :src="JS_APP_URL + '/images/folder.svg'"
        alt=""
        title=""
        class="mr5 move-main-folder-icon"
      />
      <span class="font-16 font_semibold gray2--text">{{ item.folder_name }}</span>
    </button>

    <ul class="tree-inner-ul" v-show="isOpen">
      <tree-item
        v-for="(child, index) in item.folder_tree"
        :key="index"
        :item="child"
        :destination_folder_id="destination_folder_id"
        @select-folder="$emit('select-folder', $event)"
      ></tree-item>
    </ul>
  </li>
</template>

<script>
export default {
  name: "tree-item",
  emits: ["select-folder"],
  props: {
    item: Object,
    destination_folder_id: Number|String
  },
  data() {
    return {
      isOpen: false,
      JS_APP_URL: JS_APP_URL,
    };
  },
  methods: {
    selectFolder(item_single) {
      this.isOpen = !this.isOpen;
      this.$emit("select-folder", item_single);
    },
  },
};
</script>
