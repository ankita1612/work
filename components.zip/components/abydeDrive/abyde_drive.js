import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import FloatingVue from 'floating-vue'
import 'floating-vue/dist/style.css'
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.css';
import abydeDrive from "./abydeDrive.vue";
import moment from "moment";
import ContextMenu from '@imengyu/vue3-context-menu'
import '@imengyu/vue3-context-menu/lib/vue3-context-menu.css'
import VueMask from '@devindex/vue-mask';

const app = createApp(abydeDrive);
app.use(VueMask);
app.config.productionTip = false;
app.use(useVuelidate);
app.use(FloatingVue);
app.component('multiselect', Multiselect);
app.config.globalProperties.$filters = {
    formatDate(value) {
        if (value) {
           return moment.utc(String(value)).local().format("MM/DD/YYYY");
        }
    },
    formatCreateDate(value) {
        if (value) {
            return moment.utc(String(value)).local().format("MMMM D, YYYY h:mm A");
        }
    },
}
app.use(ContextMenu)
app.mount('#abyde_drive_app');

