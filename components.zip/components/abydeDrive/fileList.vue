<template>
  <div class="drive-listing-row mb50" >
    <div
      class="row flex-auto -mx-10 mb10 flex justify-between pb20"
      v-if="show_search_bar"
    >
      <div class="col-12 col-md-3 col-lg-4 col-xl-5 px10 mb-sm-10">
        <div class="font-22 font_semibold blueog--text">Files</div>
      </div>

      <div class="col-12 col-md-9 col-lg-6 col-xl-6 px10" v-if="files && files.length > 0" >
        <div class="row -mx-10 items-center flex-auto">
           <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10 mb-sm-10 flex">
              <div class="form-group account-filter-wrapper mb-0 flex-auto">
                  <multiselect
                  v-model="sort_by"
                  :options="sort_by_array"
                  label="name"
                  :taggable="false"
                  :multiple="false"
                  :close-on-select="true"
                  :showLabels="false"
                  placeholder=""
                  :searchable="false"

                >
                  <template #noResult>
                    <div class="multiselect__noResult text-center">
                      No results found
                    </div>
                  </template>
                </multiselect>
                <label class="label label-select font-italic" :class="{ 'label-float': sort_by }" >Sort by</label>
              </div>
              <img @click="toggleSortDir" v-if="sort_by != null && sort_by_dir == 'ASC'" :src="JS_APP_URL +'/images/sort-up.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" />
              <img @click="toggleSortDir" v-if="sort_by != null && sort_by_dir == 'DESC'" :src="JS_APP_URL +'/images/sort-down.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" />
            </div>
          <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10">
            <div class="form-group account-filter-wrapper mb-0">
              <input class="form-input form-input-search" type="text" v-model="searchQuery"/>
              <label class="label font-italic" :class="{ 'label-float': searchQuery }">Search</label>
              <div class="search-btn-input">
                <img :src="JS_APP_URL + '/images/search.svg'" alt="" title="" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-if="layout_style == 'list'">
      <div class="drive-listing-item pb10" v-for="file in searchingSortingResult" :key="file.id">
        <div class="row flex-auto items-center -mx-10">
          <div class="col-12 col-md-7 col-lg-5 col-xl-4 px10">
            <div v-if="file.is_shared == true" class="flex items-center file-folder-name-wrapper">
              <img
                :src="getSharedImagepath(file.file_name)"
                alt=""
                title=""
                class="mr12 drive-listing-icon"
              />
              <span class="font-16 font_semibold gray2--text file-list-name">{{
                file.title
              }}</span>
            </div>
            <div v-else class="flex items-center file-folder-name-wrapper">
              <img
                :src="getImagepath(file.file_name)"
                alt=""
                title=""
                class="mr12 drive-listing-icon"
              />
              <span class="font-16 font_semibold gray2--text file-list-name">{{
                file.title
              }}</span>
            </div>
          </div>
          <div class="col-12 col-md-5 col-lg-3 col-xl-3 px10">
            <span class="font-7 font-italic gray_checkmark--text margin-4-right-txt"
              >Owned by:</span
            >
            <span class="font-12 font_semibold blueog--text">{{
              file.user.first_name + " " + file.user.last_name
            }}</span>
          </div>
          <div class="col-6 col-md-6 col-lg-3 col-xl-3 px10 self-start">
            <span class="font-7 font-italic gray_checkmark--text margin-4-right-txt"
              >Last modified:</span
            >
            <span class="font-12 font_semibold blueog--text  blueog--text">{{$filters.formatDate(file.updated_at)}}</span>
          </div>
          <div class="col-6 col-md-6 col-lg-1 col-xl-2 px10 text-right">
            <VDropdown strategy="fixed" class="inline-block">
              <button type="button" class="cursor-pointer">
                <img
                  :src="JS_APP_URL + '/images/drive-dots-blue.svg'"
                  alt=""
                  title=""
                  class="drive-dots-img"
                />
              </button>
              <template #popper>
                <div class="drive-file-dropdown">
                  <button
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-if="active_page != 'trash_page'"
                    v-close-popper
                    @click="renameModalToggle(file)"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/pencil.svg'"
                        alt=""
                        title=""
                        class="rename-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Rename</span
                    >
                  </button>

                  <button
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="downloadFile(file.id)"
                  >
                    <div class="drive-dropdown-img">
                       <img
                        :src="JS_APP_URL + '/images/file-cloud.svg'"
                        alt=""
                        title=""
                        class="cloud-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Download</span
                    >
                  </button>

                  <button
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="deleteModalToggle(file.id)"
                    v-if="active_page != 'trash_page'"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/bin.svg'"
                        alt=""
                        title=""
                        class="bin-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Delete</span
                    >
                  </button>

                  <button
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="moveModalToggle(file.location_id, file.id)"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/file-move.svg'"
                        alt=""
                        title=""
                        class="move-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Move</span
                    >
                  </button>
                  <button
                    v-if="(from_where == 'AbydeDrive' || from_where == 'RecentPage') && location_limit_count > 1"
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="getSharedLocations(file.location_id,file.id,'file')"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/menu-folder-shared-small.svg'"
                        alt=""
                        title=""
                        class="info-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Share</span
                    >
                  </button>

                  <button
                    v-if="(from_where == 'AbydeDrive' || from_where == 'RecentPage') && location_limit_count > 1 && file.is_shared && file.file_share_count > 0"
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="getSharedLocations(file.location_id,file.id,'file','unshare')"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/menu-folder-unshared-small.svg'"
                        alt=""
                        title=""
                        class="info-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Unshare</span
                    >
                  </button>

                  <button
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="getFileDetails(file.id)"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/file-info.svg'"
                        alt=""
                        title=""
                        class="info-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >View Details</span
                    >
                  </button>
                </div>
              </template>
            </VDropdown>
          </div>
        </div>
      </div>
    </div>
    <div v-if="layout_style == 'grid'">
      <div class="drive-files-box flex flex-wrap">
        <div class="drive-files-col" v-for="file in searchingSortingResult" :key="file.id"   @contextmenu="onContextMenu($event, file)">
          <div
            class="drive-file-item flex-auto flex flex-col">
            <div
              v-if="file.is_shared == true"
              class="drive-file-img flex flex-col flex-auto items-center justify-center"
            >
              <img
                :src="getSharedImagepath(file.file_name)"
                alt=""
                title=""
                class="drive-menu-icon"
              />
            </div>
            <div
              v-else
              class="drive-file-img flex flex-col flex-auto items-center justify-center"
            >
              <img
                :src="getImagepath(file.file_name)"
                alt=""
                title=""
                class="drive-menu-icon"
              />
            </div>
            <div
              class="
                drive-file-text
                font-16 font_semibold
                gray2--text
                text-center
              "
            >
              {{ file.title }}
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-if="searchingSortingResult && searchingSortingResult.length === 0" class="">
      <div class="user-detail-text font-14 gray_checkmark--text text-center">
        <no-data-icon></no-data-icon>
        <div class="font-14 text-center blueog--text">No Files available.</div>
      </div>
    </div>
    <details-modal
      v-if="show_details_modal"
      :modal_type="'file'"
      :details="view_file_details"
      @close-model="detailsModalToggle"
    >
    </details-modal>

    <delete-modal
      v-if="show_delete_modal"
      :delete_id="delete_file_id"
      @delete="deleteFile"
      @close-model="deleteModalToggle"
    >
    </delete-modal>
    <file-modal
      v-if="show_rename_modal"
      :modal_type="'rename'"
      :file="rename_file_details"
      @file-modal-toggle="renameModalToggle"
      @get-sub-document-list="getDocumentList"
    ></file-modal>
    <move-modal
      v-if="show_move_modal"
      :location_id="location_id"
      :file_id="file_id"
      type="file"
      @close-modal="moveModalToggle"
      @get-sub-document-list="getDocumentList"
    >
    </move-modal>
    <share-with-location-modal
      v-if="share_with_location" 
      @close-model="shareWithLocationModalToggle" 
      @get-updated-doc="getDocumentList"
      :parent_folder_id="parent_folder_id"
      :location_list="location_list"
      :shared_parent_locations="shared_parent_locations"
      :shared_current_locations="shared_current_locations"
      :from_loc_id = "get_location_id"
      :doc_id = "get_folder_id"
      :doc_type = "get_doc_type">
    </share-with-location-modal>
    <unshare-with-location-modal
      v-if="unshare_with_location" 
      @close-model="unshareWithLocationModalToggle" 
      @get-updated-doc="getDocumentList"
      :parent_folder_id="parent_folder_id"
      :location_list="unshared_all_locations"
      :shared_parent_locations="shared_parent_locations"
      :shared_current_locations="shared_current_locations"
      :from_loc_id = "get_location_id"
      :doc_id = "get_folder_id"
      :doc_type = "get_doc_type"
      >
    </unshare-with-location-modal>
  </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import NProgress from "nprogress";
import detailsModal from "./detailsModal.vue";
import deleteModal from "./deleteModal.vue";
import fileModal from "./fileModal.vue";
import _ from "lodash";
import { h } from 'vue'
import moveModal from "./moveModal.vue";
import noDataIcon from '../common/icons/noDataIcon.vue';
import shareWithLocationModal from "./shareWithLocationModal.vue";
import unshareWithLocationModal from "./unshareWithLocationModal.vue";

export default {
  props: {
    files: Array,
    layout_style: String,
    active_page: String,
    show_search_bar: {
      type: Boolean,
      default: true,
    },
    parent_folder_id: Number,
    from_where: String,
    all_locations: Array,
    location_limit_count: Number
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      show_details_modal: false,
      show_delete_modal: false,
      show_rename_modal: false,
      show_move_modal: false,
      view_file_details: {},
      rename_file_details: {},
      delete_file_id: null,
      location_id: null,
      file_id: null,
      searchQuery:null,
      sort_by:null,
      sort_by_dir:"ASC",
      sort_by_array:[
        { name: 'Name', key: 'title' },
        { name: 'Date', key: 'updated_at' }
      ],
      share_with_location: false,
      unshare_with_location: false,
      shared_parent_locations: [],
      shared_current_locations: [],
      location_list: [],
      get_location_id:null,
      get_folder_id: null,
      get_doc_type: null,
      unshared_all_locations: []
    };
  },
  emits: ["get-sub-document-list"],
  components: {
    detailsModal,
    deleteModal,
    fileModal,
    moveModal,
    noDataIcon,
    shareWithLocationModal,
    unshareWithLocationModal
  },
  watch: {
    files(val){
       this.searchQuery = null
       this.sort_by = null
       this.sort_by_dir = "ASC"
    }
  },
  computed: {
    searchingSortingResult(){
      let sortable_array = this.files;
      if(this.sort_by != null ){
          sortable_array = sortable_array.concat().sort((a,b)=>{
          if(this.sort_by_dir == "DESC"){
            if(this.sort_by.key != 'updated_at'){
              return a[this.sort_by.key].toLowerCase() > b[this.sort_by.key].toLowerCase() ? -1:1
            }else{
              return a[this.sort_by.key] > b[this.sort_by.key] ? -1:1
            }
          }else{
            if(this.sort_by.key != 'updated_at'){
              return a[this.sort_by.key].toLowerCase() > b[this.sort_by.key].toLowerCase() ? 1:-1
            }else{
             return a[this.sort_by.key] > b[this.sort_by.key] ? 1:-1
            }

          }
        })
       }
      if(this.searchQuery != null ){
        sortable_array = sortable_array.filter((item)=>{
            return this.searchQuery.toLowerCase().split(' ').every(v => item.title.toLowerCase().includes(v))
        });
      }
      return sortable_array
    }
  },
  methods: {
    getSharedLocations(from_location_id,doc_id,doc_type = "",menu = "share"){
      NProgress.start();
      axios
        .post(JS_APP_URL + "/abyde-drive/get-shared-locations", {
            from_location_id: from_location_id,
            doc_id: doc_id,
            doc_type: doc_type
        })
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.get_location_id = from_location_id;
            this.get_folder_id = doc_id;
            this.get_doc_type = doc_type;
            this.shared_parent_locations = response["data"]["data"]['shared_parent_locations'];
            this.shared_current_locations = response["data"]["data"]['shared_current_locations'];
            this.location_list = response["data"]["data"]['all_locations'];
            this.unshared_all_locations = response["data"]["data"]['unshared_all_locations'];
            if(menu == 'unshare'){
              this.unshare_with_location = true;              
            }else{
              this.share_with_location = true;
            }
          } else {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        });
    },
    getImagepath(filename) {
      let file_extention = filename.split(".").slice(-1);
      let img_path;
      switch (_.lowerCase(file_extention)) {
        case "pdf":
          img_path = JS_APP_URL + "/images/extension-icons/PDF.svg";
          break;
        case "doc":
          img_path = JS_APP_URL + "/images/extension-icons/DOC.svg";
          break;
        case "docx":
          img_path = JS_APP_URL + "/images/extension-icons/DOCX.svg";
          break;
        case "png":
          img_path = JS_APP_URL + "/images/extension-icons/PNG.svg";
          break;
        case "jpg":
          img_path = JS_APP_URL + "/images/extension-icons/JPG.svg";
          break;
        case "jpeg":
          img_path = JS_APP_URL + "/images/extension-icons/JPEG.svg";
          break;
        case "csv":
          img_path = JS_APP_URL + "/images/extension-icons/CSV.svg";
          break;
        case "xls":
          img_path = JS_APP_URL + "/images/extension-icons/XLS.svg";
          break;
        case "xlsx":
          img_path = JS_APP_URL + "/images/extension-icons/XLSX.svg";
          break;
        case "txt":
          img_path = JS_APP_URL + "/images/extension-icons/TXT.svg";
          break;
        case "zip":
          img_path = JS_APP_URL + "/images/extension-icons/ZIP.svg";
          break;
        case "html":
          img_path = JS_APP_URL + "/images/extension-icons/HTML.svg";
          break;
        default:
          img_path = JS_APP_URL + "/images/extension-icons/UNKNOWN.svg";
      }
      return img_path;
    },
    getSharedImagepath(filename) {
      let file_extention = filename.split(".").slice(-1);
      let img_path;
      switch (_.lowerCase(file_extention)) {
        case "pdf":
          img_path = JS_APP_URL + "/images/extension-icons/PDF-shared.svg";
          break;
        case "doc":
          img_path = JS_APP_URL + "/images/extension-icons/DOCX-shared.svg";
          break;
        case "docx":
          img_path = JS_APP_URL + "/images/extension-icons/DOCX-shared.svg";
          break;
        case "png":
          img_path = JS_APP_URL + "/images/extension-icons/PNG-shared.svg";
          break;
        case "jpg":
          img_path = JS_APP_URL + "/images/extension-icons/JPEG-shared.svg";
          break;
        case "jpeg":
          img_path = JS_APP_URL + "/images/extension-icons/JPEG-shared.svg";
          break;
        case "csv":
          img_path = JS_APP_URL + "/images/extension-icons/CSV-shared.svg";
          break;
        case "xls":
          img_path = JS_APP_URL + "/images/extension-icons/XLS-shared.svg";
          break;
        case "xlsx":
          img_path = JS_APP_URL + "/images/extension-icons/XLSX-shared.svg";
          break;
        case "txt":
          img_path = JS_APP_URL + "/images/extension-icons/TXT-shared.svg";
          break;
        case "zip":
          img_path = JS_APP_URL + "/images/extension-icons/ZIP-shared.svg";
          break;
        case "html":
          img_path = JS_APP_URL + "/images/extension-icons/HTML-shared.svg";
          break;
        default:
          img_path = JS_APP_URL + "/images/extension-icons/UNKNOWN.svg";
      }
      return img_path;
    },
    detailsModalToggle() {
      if (this.show_details_modal == true) {
        this.show_details_modal = false;
      } else {
        this.show_details_modal = true;
      }
    },
    deleteModalToggle(file_id = 0) {
      if (this.show_delete_modal == true) {
        this.delete_file_id = null;
        this.show_delete_modal = false;
      } else {
        this.delete_file_id = file_id;
        this.show_delete_modal = true;
      }
    },
    renameModalToggle(file = null) {
      if (this.show_rename_modal == true) {
        this.rename_file_details = null;
        this.show_rename_modal = false;
      } else {
        this.rename_file_details = file;
        this.show_rename_modal = true;
      }
    },
    moveModalToggle(location_id = null, file_id = null) {
      this.location_id = location_id;
      this.file_id = file_id;
      this.show_move_modal = !this.show_move_modal;
    },
    shareWithLocationModalToggle(){
      this.share_with_location = !this.share_with_location;
    },
    unshareWithLocationModalToggle(){
      this.unshare_with_location = !this.unshare_with_location;
    },
    getFileDetails(id) {
      NProgress.start();
      axios
        .get(JS_APP_URL + "/abyde-drive/view-file-detail", {
          params: { file_id: id },
        })
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.view_file_details = response["data"]["data"];
            this.show_details_modal = true;
          } else {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        });
    },
    getDocumentList(folder_id = 0) {
       this.searchQuery = null
       this.sort_by = null
       this.sort_by_dir = "ASC"
      if(this.parent_folder_id != "undefined" && folder_id == 0){
        folder_id = this.parent_folder_id
      }
      this.$emit("get-sub-document-list", folder_id);
    },
    deleteFile(id) {
      NProgress.start();
      axios
        .delete(JS_APP_URL + "/abyde-drive/delete-file", {
          params: { file_id: id },
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            toastr.success(response["data"]["message"], "Success");
            this.getDocumentList();
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        });
    },
    downloadFile(id) {
      NProgress.start();
      axios
        .post(JS_APP_URL + "/abyde-drive/download-file", {
          file_id: id,
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            let data = "";
            if (response["data"]["data"]) {
              data = response["data"]["data"].join(", ");
            }
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            const filePath =
              response["data"]["data"]["download_url"].split("/");
            const tempFileName = filePath[filePath.length - 1];
            const fileName = tempFileName.split("?")[0];
            axios({
              url: response["data"]["data"]["download_url"],
              method: "GET",
              responseType: "blob",
            }).then((response) => {
              var fileURL = window.URL.createObjectURL(
                new Blob([response.data])
              );
              var fileLink = document.createElement("a");
              fileLink.href = fileURL;
              fileLink.setAttribute("download", fileName);
              document.body.appendChild(fileLink);
              fileLink.click();
            });
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        });
    },
    toggleSortDir(){
      this.sort_by_dir = (this.sort_by_dir == 'ASC')?'DESC':'ASC';
    },
    onContextMenu(e, file) {
        e.preventDefault();
        if (this.active_page != 'trash_page') {
          if(this.location_limit_count > 1){
            if((file.is_shared == true && file.file_share_count > 0))
            {
              this.$contextmenu({
                customClass: "v-context drive-file-dropdown",
                items: [
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Rename"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/pencil.svg',
                            class: 'rename-file-icon'
                        }),
                        onClick: () => {
                            this.renameModalToggle(file);
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Download"),
                        icon: "drive-dropdown-img drive-download-icon",
                        onClick: () => {
                            this.downloadFile(file.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Delete"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/bin.svg',
                            class: 'bin-file-icon'
                        }),
                        onClick: () => {
                            this.deleteModalToggle(file.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Move"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-move.svg',
                            class: 'move-file-icon'
                        }),
                        onClick: () => {
                            this.moveModalToggle(file.location_id, file.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Share"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/menu-folder-shared-small.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                          this.getSharedLocations(file.location_id,file.id,'file')
                        },
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Unshare"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/menu-folder-unshared-small.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                          this.getSharedLocations(file.location_id,file.id,'file','unshare')
                        },
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "View Details"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-info.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                            this.getFileDetails(file.id)
                        },
                    }
                ],
                //iconFontClass: 'iconfont',
                //customClass: "class-a",
                zIndex: 3,
                minWidth: 230,
                x: e.x,
                y: e.y,
            });
            }else{
              this.$contextmenu({
                customClass: "v-context drive-file-dropdown",
                items: [
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Rename"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/pencil.svg',
                            class: 'rename-file-icon'
                        }),
                        onClick: () => {
                            this.renameModalToggle(file);
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Download"),
                        icon: "drive-dropdown-img drive-download-icon",
                        onClick: () => {
                            this.downloadFile(file.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Delete"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/bin.svg',
                            class: 'bin-file-icon'
                        }),
                        onClick: () => {
                            this.deleteModalToggle(file.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Move"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-move.svg',
                            class: 'move-file-icon'
                        }),
                        onClick: () => {
                            this.moveModalToggle(file.location_id, file.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Share"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/menu-folder-shared-small.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                          this.getSharedLocations(file.location_id,file.id,'file')
                        },
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "View Details"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-info.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                            this.getFileDetails(file.id)
                        },
                    }
                ],
                //iconFontClass: 'iconfont',
                //customClass: "class-a",
                zIndex: 3,
                minWidth: 230,
                x: e.x,
                y: e.y,
            });
            }
          }else{
            this.$contextmenu({
                customClass: "v-context drive-file-dropdown",
                items: [
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Rename"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/pencil.svg',
                            class: 'rename-file-icon'
                        }),
                        onClick: () => {
                            this.renameModalToggle(file);
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Download"),
                        icon: "drive-dropdown-img drive-download-icon",
                        onClick: () => {
                            this.downloadFile(file.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Delete"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/bin.svg',
                            class: 'bin-file-icon'
                        }),
                        onClick: () => {
                            this.deleteModalToggle(file.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Move"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-move.svg',
                            class: 'move-file-icon'
                        }),
                        onClick: () => {
                            this.moveModalToggle(file.location_id, file.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "View Details"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-info.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                            this.getFileDetails(file.id)
                        },
                    }
                ],
                //iconFontClass: 'iconfont',
                //customClass: "class-a",
                zIndex: 3,
                minWidth: 230,
                x: e.x,
                y: e.y,
            });
          }
        }
        else {
            this.$contextmenu({
                x: e.x,
                y: e.y,
                customClass: "v-context drive-file-dropdown drive-file-dropdown",
                items: [
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Download"),
                        icon: "drive-dropdown-img drive-download-icon",
                        onClick: () => {
                            this.downloadFile(file.id)
                        }
                        ,
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Move"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-move.svg',
                            class: 'move-file-icon'
                        }),
                        onClick: () => {
                            this.moveModalToggle(file.location_id, file.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "View Details"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-info.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                            this.getFileDetails(file.id)
                        },
                    },
                ],
                //iconFontClass: 'iconfont',
                //customClass: "class-a",
                zIndex: 3,
                minWidth: 230,
                x: e.x,
                y: e.y,
            });
        }

    }
  },
};
</script>
