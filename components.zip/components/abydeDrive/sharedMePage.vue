<template>
    <div>
      <shared-me-folder-list
        :folders="shared_documents.folders"
        :selected_location="selected_location"
        @get-sub-document-list="getSubDocumentList"
        :active_page="'shared_me'"
        :layout_style="layout_style"
        :parent_folder_id="parent_folder_id"
      ></shared-me-folder-list>
  
      <shared-me-file-list
        :files="shared_documents.files"
        :layout_style="layout_style"
        :active_page="'shared_me'"
        @get-sub-document-list="getSubDocumentList"
        :parent_folder_id="parent_folder_id"
      ></shared-me-file-list>
    </div>
  </template>
  
  <script scoped>
  import sharedMeFolderList from "./sharedMeFolderList.vue";
  import sharedMeFileList from "./sharedMeFileList.vue";
  
  export default {
    components: { sharedMeFolderList, sharedMeFileList },
    emits: ["get-sub-document-list", "change-active-page",'append-breadcrumb'],
    props: {
      selected_location: Object,
      shared_documents: Object,
      parent_folder_id: Number,
      layout_style: String,
      active_page: String,
    },
    data() {
      return {
        JS_APP_URL: JS_APP_URL,
      };
    },
    methods: {
      getSubDocumentList(folder_id = 0, folder_name = "") {
        this.$emit("get-sub-document-list", folder_id, folder_name);
    },
    },
  };
  </script>
  