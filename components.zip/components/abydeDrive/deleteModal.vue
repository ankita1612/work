<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
            <button v-if="!is_btn_disabled" @click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb10 pt20">
                <img
                :src="JS_APP_URL + '/images/alert.svg'"
                alt=""
                title=""
                class="warning-icon-modal"
                />
            </div>
            <h2
                class="
                font-24 font_semibold
                blueog--text
                line-normal
                text-center
                mb30
                "
            >
                Are you sure?
            </h2>
            <p class="text-center font-16 text-999 line-normal mb40">
                Once deleted, you will not be able to recover this data!
            </p>
            <div class="flex flex-wrap items-center justify-center pb40">
                <button
                @click="deleteSubmit"
                class="btn-cancel-outline mx5 h-32 min-w-120 mt-xs-20"
                :disabled="is_btn_disabled"
                >
                Yes Delete!
                </button>
                <button @click="closeModal" :disabled="is_btn_disabled" class="btn-blue-outline mx7">
                Nevermind
                </button>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";

export default {
  components: { closeIcon },

  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_btn_disabled: false,
    };
  },
  emits: ["close-model", "delete"],
  props: {
    delete_id: Number,
  },

  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },

    deleteSubmit() {
      this.is_btn_disabled = true;
      this.$emit("delete", this.delete_id);
      this.$emit("close-model");
    },
  },

  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.is_btn_disabled) {
        this.$emit("close-model");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
