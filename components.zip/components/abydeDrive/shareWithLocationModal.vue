<template>
    <Teleport to="body">
      <transition name="modal">
        <div class="modal-mask">
          <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
                <button v-if="!disable_location_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                    <close-icon></close-icon>
                </button>
                <h2 class="font-24 font_semibold blueog--text line-normal mb10 text-center">
                  Document Sharing
                </h2>
                <div class="completecase-content mlr-auto">
                  <div class="font-16 text-center gray_checkmark--text line-normal mb20">
                    Select Location(s) Below:
                  </div>
                  <div class="flex items-center flex-wrap flex-auto mb20">
                    <div class="row flex-auto justify-center -mx-10">
                      <div class="col-12 col-md-12 px10">
                        <form @submit.prevent="setShareLocationSubmit" class="fill-width">
                          <div class="form-group mb-0 mlr-auto location-dropdon" :class="{ 'form-group--error': v$.select_location_id.$errors.length }">
                              <multiselect
                              :options="filteredLocationList"
                              v-model="v$.select_location_id.$model"
                              openDirection="bottom"
                              track-by="id"
                              :custom-label="customLabel"
                              placeholder=""
                              :multiple="true"
                              :searchable="true"
                              :showLabels="false"
                              :taggable="false"
                              :close-on-select="false"
                              :disabled="disable_location_submit_btn"
                               @update:model-value="onChange"
                              >
                                  <template #noResult>
                                      <div class="multiselect__noResult text-center">No results found</div>
                                  </template>
                                  <template #noOptions>
                                      <div class="multiselect__noOptions text-center">No data available</div>
                                  </template>
                                  <template #selection>
                                      <div class="multiselect__tags-wrap" v-if="select_location_id.length > 1">
                                          <span class="multiselect__tag">
                                              <span>{{ select_location_id.length }} Locations Selected</span>
                                          </span>
                                      </div>
                                  </template>
                              </multiselect>
                              <label class="label label-select" :class="{ 'label-float': (select_location_id.length > 0) }">Location(s)</label>
                              <div v-if="v$.select_location_id.$errors.length > 0">
                                <div class="form-error-text">
                                  {{ v$.select_location_id.$errors[0].$message }}
                                </div>
                              </div>
                          </div>
                          <div class="text-center pt30">
                              <button
                              type="submit"
                              class="btn-primary mlr-auto"
                               :disabled="select_location_id.length <= 0"
                              >
                                  <span>Submit</span>
                              </button>
                          </div>
                      </form>
                      </div>
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </transition>
    </Teleport>
  </template>
  
  <script scoped>
  import axios from "axios";
  import NProgress from "nprogress";
  import toastr from "toastr";
  import "toastr/toastr.scss";
  toastr.options.preventDuplicates = true;
  import { useVuelidate } from '@vuelidate/core';
  import { required, helpers } from "@vuelidate/validators";
  import _ from 'lodash';
  import closeIcon from '../common/icons/closeIcon.vue';
  import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
  
  export default {
    data() {
      return {
        select_location_id:[],
        disable_location_submit_btn:false,
        JS_APP_URL: JS_APP_URL,
        default_select_location_ids:[]
      };
    },
    props: {
        from_loc_id: Number,
        parent_folder_id: Number,
        doc_id: Number,
        doc_type: String,
        location_list: Array,
        shared_parent_locations: Array,
        shared_current_locations: Array
    },
    emits: ["close-model", "get-updated-doc"],
    setup: () => ({ v$: useVuelidate() }),
    validations() {
      return {
        select_location_id: {
          required: helpers.withMessage('Please select location(s)', required)
        }
      }
    },
    created() {
      document.addEventListener('keyup', (evt) => {
        if (evt.keyCode === 27 && !this.disable_location_submit_btn) {
          this.$emit("close-model", false);
        }
      });
    },
    computed: {
      filteredLocationList() {
          let locations = this.location_list.map((location) => ({
            ...location,
            $isDisabled: this.shared_parent_locations.some(shared => shared.id === location.id) ||this.shared_current_locations.some(shared => shared.id === location.id)
          }));
          const allDisabled = locations.every(location => location.$isDisabled);
          return [{ id: "select_all", location_nickname: "Select All", $isDisabled: allDisabled }, ...locations];
      }
    },
    components: {
      closeIcon,
      clearDropdownIcon
    },
    methods: {
      onChange(value){
        if (value.some(item => item.id === "select_all")) {
            if (this.select_location_id.length === this.filteredLocationList.length - (this.shared_parent_locations.length + this.shared_current_locations.length )  ) {
              this.select_location_id = [];
            } else {
              this.select_location_id = this.filteredLocationList.filter(item => !item.$isDisabled && item.id !== "select_all");
            }
          }
      },
      customLabel(option) {
        return `${option.location_nickname}`
      },
      setShareLocationSubmit() {
        this.v$.$touch();
        if (!this.v$.$invalid) {
          var location_selected_new = [];
          var location_selected_removed = []; 

          _.forEach(this.select_location_id,(value) => {
            location_selected_new.push({"location_id": value.id});
          });

          this.disable_location_submit_btn =true;
            NProgress.start();
            axios
            .post(JS_APP_URL + "/abyde-drive/share-document-to-location",{
                from_loc_id: this.from_loc_id,
                doc_id: this.doc_id,
                doc_type: this.doc_type,
                selected_locations:location_selected_new,
                removed_selected_locations: location_selected_removed
            })
            .then((response) => {
            if (response["data"]["status"] == "Error") {
                if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
            } else {
                this.$emit("get-updated-doc", this.parent_folder_id);
                
                if(location_selected_new.length > 0 && location_selected_removed.length > 0){
                  if(this.doc_type == 'file'){
                    toastr.success("File shared/unshared successfully.", "Success");                
                  }else{
                    toastr.success("Folder shared/unshared successfully.", "Success");                
                  }
                }
                if(location_selected_new.length > 0 && location_selected_removed.length == 0)
                {
                  toastr.success(response["data"]["message"], "Success");
                }
                if(location_selected_new.length == 0 && location_selected_removed.length > 0)
                {
                  if(this.doc_type == 'file'){
                    toastr.success("File unshared successfully.", "Success");                
                  }else{
                    toastr.success("Folder unshared successfully.", "Success");                
                  }
                }
                
                setTimeout(() => {
                    this.$emit("close-model", false);
                }, 100);
            }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
            NProgress.done();
            this.disable_location_submit_btn =false;
            });
        }
      },
       closeModal() {
        this.$emit("close-model", false);
      },
    },
  };
  </script>
  