<template>
  <div>
    <file-list
      :files="recent_files"
      :layout_style="layout_style"
      :all_locations="all_locations"
      :from_where="from_recent_page"
      @get-sub-document-list="getRecentDocumetsList"
      :location_limit_count="location_limit_count"
    ></file-list>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import sidebarMenuOption from "./sidebarMenuOption.vue";
import fileList from "./fileList.vue";
import fullPageLoader from "../common/fullPageLoader.vue";

export default {
  components: { sidebarMenuOption, fileList, fullPageLoader },
  props: {
    selected_location: Object,
    layout_style: String,
    all_locations: Array,
    location_limit_count: Number
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      recent_files: [],
      is_full_page_loader_shown: false,
      from_recent_page: 'RecentPage'
    };
  },
  mounted() {
    this.getRecentDocumetsList();
  },
  methods: {
    getRecentDocumetsList() {
      this.is_full_page_loader_shown = true;
      let url =
        JS_APP_URL +
        "/abyde-drive/get-recent-files?location_id=" +
        this.selected_location.id;
      axios
        .get(url)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.recent_files = response["data"]["data"];
          } else {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
  },
};
</script>
