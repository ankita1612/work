<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
            <button v-if="!disable_submit_btn" @click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
            <h2
                class="
                font-28 font_semibold
                blueog--text
                line-normal
                text-center
                mb40 mt20
                "
            >
                {{ modal_type == "rename" ? "Rename" : "New Folder" }}
            </h2>

            <div class="form-group mlr-auto" :class="{ 'form-group--error': v$.folder_name.$error }" style="max-width:263px;">
                <input class="form-input" v-model="v$.folder_name.$model" @keyup.enter="submit"  />
                <label class="label" :class="{ 'label-float': folder_name }"
                >Folder Name</label
                >
                <div v-if="v$.folder_name.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.folder_name.$errors[0].$message }}
                  </div>
                </div>
            </div>

            <div class="flex flex-wrap items-center justify-center mb20">
                <button @click="submit" :disabled="disable_submit_btn" type="submit" class="btn-primary">
                SUBMIT
                </button>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import { useVuelidate } from '@vuelidate/core';
import { required, maxLength, helpers } from "@vuelidate/validators";
import { alphaNumValidator } from "../common/customValidation";

export default {
  props: {
    modal_type: String,
    selected_location: Object,
    parent_folder_id: Number,
    folder: Object,
  },

  components: { closeIcon },
  setup: () => ({ v$: useVuelidate() }),
  emits: ["get-sub-document-list", "folder-modal-toggle"],
  data() {
    return {
      disable_submit_btn: false,
      JS_APP_URL: JS_APP_URL,
      folder_name: "",
    };
  },
  validations() {
    return {
        folder_name: {
            required: helpers.withMessage('Please enter a folder name', required),
            maxLength: helpers.withMessage('Max 25 characters allowed', maxLength(25)),
            alphaNumValidator: helpers.withMessage('Please enter a valid folder name', alphaNumValidator),
        },
    }
},
  mounted() {
    if (this.folder) {
      this.folder_name = this.folder.folder_name;
    }
  },
  methods: {
    async submit() {
      this.v$.$touch();
      const is_valid = await this.v$.$validate()
      if (is_valid) {
        let url = "";

      let payload = {
        folder_name: this.folder_name,
        location_id: this.selected_location.id,
      };

      if (this.parent_folder_id != 0) {
        payload.parent_folder_id = this.parent_folder_id;
      }

      if (this.modal_type == "rename") {
        url = this.JS_APP_URL + "/abyde-drive/rename-folder";
        payload.folder_id = this.folder.id;
      } else {
        url = this.JS_APP_URL + "/abyde-drive/create-folder";
      }
      this.disable_submit_btn = true;
      axios
        .post(url, payload)
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }else {
              toastr.success(response["data"]["message"], "Success");
              if (this.parent_folder_id != 0) {
                this.$emit("get-sub-document-list",this.parent_folder_id);
              }else{
                this.$emit("get-sub-document-list");
              }

              this.closeModal();
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.disable_submit_btn = false;
        });
      }

    },

    closeModal() {
      this.$emit("folder-modal-toggle");
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.disable_submit_btn) {
        this.closeModal();
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
