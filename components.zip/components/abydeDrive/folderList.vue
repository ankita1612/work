<template>
  <div class="drive-listing-row mb50" >
    <div class="row flex-auto -mx-10 mb22 flex justify-between">
      <div class="col-12 col-md-6 col-lg-4 col-xl-5 px10 mb-sm-10">
        <div class="font-22 font_semibold blueog--text">Folders</div>
      </div>

      <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10"  v-if="folders && folders.length > 0">
        <div class="row -mx-10 items-center flex-auto">
           <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10 mb-sm-10 flex">
          <div class="form-group account-filter-wrapper mb-0 flex-auto">
              <multiselect
              v-model="sort_by"
              :options="sort_by_array"
              label="name"
              :taggable="false"
              :multiple="false"
              :close-on-select="true"
              :showLabels="false"
              placeholder=""
              :searchable="false"

            >
              <template #noResult>
                <div class="multiselect__noResult text-center">
                  No results found
                </div>
              </template>
            </multiselect>
            <label class="label label-select font-italic" :class="{ 'label-float': sort_by }" >Sort by</label>
          </div>
          <img @click="toggleSortDir" v-if="sort_by != null && sort_by_dir == 'ASC'" :src="JS_APP_URL +'/images/sort-up.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" />
          <img @click="toggleSortDir" v-if="sort_by != null && sort_by_dir == 'DESC'" :src="JS_APP_URL +'/images/sort-down.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" />
      </div>
      <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10">
        <div class="form-group account-filter-wrapper mb-0">
          <input class="form-input form-input-search" type="text" v-model="searchQuery"/>
          <label class="label font-italic" :class="{ 'label-float': searchQuery }" >Search</label>
          <div class="search-btn-input">
            <img :src="JS_APP_URL + '/images/search.svg'" alt="" title="" />
          </div>
        </div>
      </div>
        </div>
      </div>
    </div>
    <div v-if="layout_style == 'list'">
      <div
        class="drive-listing-item pb5"
        v-for="folder in searchingSortingResult"
        :key="folder.id"
      >
        <div class="row flex-auto items-enter -mx-10">
          <div class="col-12 col-md-4 col-lg-3 col-xl-4 px10">
            <a
              href="javascript:void(0)"
              @click="getSubDocumentList(folder.id, folder.folder_name)"
            >
              <div v-if="folder.is_shared == true" class="flex items-center file-folder-name-wrapper">
                <img
                  :src="JS_APP_URL + '/images/folder-shared.svg'"
                  alt=""
                  title=""
                  class="mr12 drive-folder-list-img-shared"
                  style="width: 26px;"
                />
                <span class="font-16 font_semibold gray2--text file-list-name">{{
                  folder.folder_name
                }}</span>
              </div>
              <div v-else class="flex items-center file-folder-name-wrapper">
                <img
                  :src="JS_APP_URL + '/images/folder.svg'"
                  alt=""
                  title=""
                  class="mr12"
                />
                <span class="font-16 font_semibold gray2--text file-list-name">{{
                  folder.folder_name
                }}</span>
              </div>
            </a>
          </div>
          <div class="col-12 col-md-3 col-lg-3 col-xl-3 px10">
            <span class="font-7 font-italic gray_checkmark--text margin-4-right-txt"
              >Owned by:</span
            >
            <span class="font-12 font_semibold blueog--text">{{
              folder.user.first_name + " " + folder.user.last_name
            }}</span>
          </div>
          <div class="col-12 col-md-3 col-lg-3 col-xl-3 px10 self-start">
            <span class="font-7 font-italic gray_checkmark--text margin-4-right-txt"
              >Last modified:</span
            >
            <span class="font-12 font_semibold blueog--text">{{ $filters.formatDate(folder.updated_at)}}</span>
          </div>
          <div class="col-12 col-md-2 col-lg-3 col-xl-2 px10 text-right">
            <VDropdown strategy="fixed" class="inline-block">
              <button type="button" class="cursor-pointer">
                <img
                  :src="JS_APP_URL + '/images/drive-dots-blue.svg'"
                  alt=""
                  title=""
                  class="drive-dots-img"
                />
              </button>
              <template #popper>
                <div class="drive-file-dropdown">
                  <button
                    v-if="active_page != 'trash_page'"
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="renameModalToggle(folder)"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/pencil.svg'"
                        alt=""
                        title=""
                        class="rename-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Rename</span
                    >
                  </button>

                  <button
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="downloadFolder(folder.id)"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/file-cloud.svg'"
                        alt=""
                        title=""
                        class="cloud-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Download</span
                    >
                  </button>

                  <button
                    v-if="active_page != 'trash_page'"
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="deleteModalToggle(folder.id)"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/bin.svg'"
                        alt=""
                        title=""
                        class="bin-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Delete</span
                    >
                  </button>

                  <button
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="moveModalToggle(folder.location_id, folder.id)"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/file-move.svg'"
                        alt=""
                        title=""
                        class="move-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Move</span
                    >
                  </button>
                  <button
                    v-if="from_where == 'AbydeDrive' && location_limit_count > 1"
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="getSharedLocations(folder.location_id,folder.id,'folder')"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/menu-folder-shared-small.svg'"
                        alt=""
                        title=""
                        class="info-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Share</span
                    >
                  </button>
                  <button
                    v-if="from_where == 'AbydeDrive' && location_limit_count > 1 && folder.is_shared && folder.folder_share_count > 0"
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="getSharedLocations(folder.location_id,folder.id,'folder','unshare')"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/menu-folder-unshared-small.svg'"
                        alt=""
                        title=""
                        class="info-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >Unshare</span
                    >
                  </button>
                  <button
                    type="button"
                    class="drive-dropdown-item flex items-center"
                    v-close-popper
                    @click="getFolderDetails(folder.id)"
                  >
                    <div class="drive-dropdown-img">
                      <img
                        :src="JS_APP_URL + '/images/file-info.svg'"
                        alt=""
                        title=""
                        class="info-file-icon"
                      />
                    </div>
                    <span class="font-12 gray2--text drive-dropdown--text"
                      >View Details</span
                    >
                  </button>
                </div>
              </template>
            </VDropdown>
          </div>
        </div>
      </div>
    </div>
    <div v-if="layout_style == 'grid'">
      <div class="drive-files-box drive-folder-grid flex flex-wrap">
        <div class="drive-files-col" v-for="folder in searchingSortingResult" :key="folder.id">
          <div
            class="drive-file-item flex-auto flex flex-col element" @click="getSubDocumentList(folder.id, folder.folder_name)" @contextmenu="onContextMenu($event, folder)"
          >
            <div
              v-if="folder.is_shared == true"
              class="
                drive-file-img
                flex flex-col
                items-center
                justify-center
                flex-auto
              "
            >
              <img
                :src="JS_APP_URL + '/images/folder-shared-blue.svg'"
                alt=""
                title=""
                class="drive-folder-icon shared-folder-img"
              />
            </div>

            <div
              v-else
              class="
                drive-file-img
                flex flex-col
                items-center
                justify-center
                flex-auto
              "
            >
              <img
                :src="JS_APP_URL + '/images/folder-blue.svg'"
                alt=""
                title=""
                class="drive-folder-icon"
              />
            </div>
            <div
              class="
                drive-file-text
                font-16 font_semibold
                gray2--text
                text-center
              "
            >
              {{ folder.folder_name }}
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-if="searchingSortingResult && searchingSortingResult.length === 0" class="">
      <div class="user-detail-text font-14 gray_checkmark--text text-center">
        <no-data-icon></no-data-icon>
        <div class="font-14 text-center blueog--text">No Folders available.</div>
      </div>
    </div>
    <folder-modal
      :modal_type="'rename'"
      :selected_location="selected_location"
      :parent_folder_id="parent_folder_id"
      :folder="rename_folder"
      v-if="show_rename_modal"
      @folder-modal-toggle="renameModalToggle"
      @get-sub-document-list="getSubDocumentList"
    >
    </folder-modal>

    <delete-modal
      v-if="show_delete_modal"
      :delete_id="delete_folder_id"
      @delete="deleteFolder"
      @close-model="deleteModalToggle"
    >
    </delete-modal>

    <details-modal
      v-if="show_details_modal"
      :modal_type="'folder'"
      :details="view_folder_details"
      @close-model="detailsModalToggle"
    >
    </details-modal>
    <move-modal
      v-if="show_move_modal"
      :location_id="location_id"
      :folder_id="folder_id"
      type="folder"
      :parent_folder_id="parent_folder_id"
      @close-modal="moveModalToggle"
      @get-sub-document-list="getSubDocumentList"
    >
    </move-modal>
    <share-with-location-modal
      v-if="share_with_location" 
      @close-model="shareWithLocationModalToggle" 
      @get-updated-doc="getSubDocumentList"
      :parent_folder_id="parent_folder_id"
      :location_list="location_list"
      :shared_parent_locations="shared_parent_locations"
      :shared_current_locations="shared_current_locations"
      :from_loc_id = "get_location_id"
      :doc_id = "get_folder_id"
      :doc_type = "get_doc_type"
      >
    </share-with-location-modal>
    <unshare-with-location-modal
      v-if="unshare_with_location" 
      @close-model="unshareWithLocationModalToggle" 
      @get-updated-doc="getSubDocumentList"
      :parent_folder_id="parent_folder_id"
      :location_list="unshared_all_locations"
      :shared_parent_locations="shared_parent_locations"
      :shared_current_locations="shared_current_locations"
      :from_loc_id = "get_location_id"
      :doc_id = "get_folder_id"
      :doc_type = "get_doc_type"
      >
    </unshare-with-location-modal>
  </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import NProgress from "nprogress";
import folderModal from "./folderModal.vue";
import deleteModal from "./deleteModal.vue";
import detailsModal from "./detailsModal.vue";
import { h } from 'vue'
import moveModal from "./moveModal.vue";
import noDataIcon from '../common/icons/noDataIcon.vue';
import shareWithLocationModal from "./shareWithLocationModal.vue";
import unshareWithLocationModal from "./unshareWithLocationModal.vue";

export default {
  props: {
    folders: Array,
    selected_location: Object,
    layout_style: String,
    active_page: String,
    parent_folder_id: Number,
    from_where: String,
    all_locations: Array,
    location_limit_count: Number
  },
  components: {
    folderModal,
    deleteModal,
    detailsModal,
    moveModal,
    noDataIcon,
    shareWithLocationModal,
    unshareWithLocationModal
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      rename_folder: null,
      show_rename_modal: false,
      show_delete_modal: false,
      show_move_modal: false,
      delete_folder_id: null,
      show_details_modal: false,
      view_folder_details: null,
      location_id: null,
      folder_id: null,
      searchQuery:null,
      sort_by:null,
      sort_by_dir:"ASC",
      sort_by_array:[
        { name: 'Name', key: 'folder_name' },
        { name: 'Date', key: 'updated_at' }
      ],
      share_with_location: false,
      unshare_with_location: false,
      get_location_id:null,
      get_folder_id: null,
      get_doc_type: null,
      shared_parent_locations: [],
      shared_current_locations: [],
      location_list: [],
      unshared_all_locations: []
    };
  },
  watch: {
    folders(val){
       this.searchQuery = null
       this.sort_by = null
       this.sort_by_dir = "ASC"
    }
  },
  emits: ["get-sub-document-list"],
  computed: {
    searchingSortingResult(){
      let sortable_array = this.folders;
      if(this.sort_by != null ){
          sortable_array = sortable_array.concat().sort((a,b)=>{
          if(this.sort_by_dir == "DESC"){
            if(this.sort_by.key != 'updated_at'){
              return a[this.sort_by.key].toLowerCase() > b[this.sort_by.key].toLowerCase() ? -1:1
            }else{
              return a[this.sort_by.key] > b[this.sort_by.key] ? -1:1
            }
          }else{
            if(this.sort_by.key != 'updated_at'){
              return a[this.sort_by.key].toLowerCase() > b[this.sort_by.key].toLowerCase() ? 1:-1
            }else{
             return a[this.sort_by.key] > b[this.sort_by.key] ? 1:-1
            }
            
          }
        })
       }
      if(this.searchQuery != null ){
        sortable_array = sortable_array.filter((item)=>{
            return this.searchQuery.toLowerCase().split(' ').every(v => item.folder_name.toLowerCase().includes(v))
        });
      }
      return sortable_array
    }
  },
  methods: {
    getSharedLocations(from_location_id,doc_id,doc_type = "",menu = "share"){
      NProgress.start();
      axios
        .post(JS_APP_URL + "/abyde-drive/get-shared-locations", {
            from_location_id: from_location_id,
            doc_id: doc_id,
            doc_type: doc_type
        })
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.get_location_id = from_location_id;
            this.get_folder_id = doc_id;
            this.get_doc_type = doc_type;
            this.shared_parent_locations = response["data"]["data"]['shared_parent_locations'];
            this.shared_current_locations = response["data"]["data"]['shared_current_locations'];
            this.unshared_all_locations = response["data"]["data"]['unshared_all_locations'];
            this.location_list = response["data"]["data"]['all_locations'];
            if(menu == 'unshare'){
              this.unshare_with_location = true;              
            }else{
              this.share_with_location = true;
            }
          } else {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        });
    },
    getSubDocumentList(folder_id = 0, folder_name = "") {
      this.searchQuery = null
      this.sort_by = null
      this.sort_by_dir = "ASC"
      this.$emit("get-sub-document-list", folder_id, folder_name);
    },
    renameModalToggle(folder = null) {
      if (this.show_rename_modal == true) {
        this.rename_folder = null;
        this.show_rename_modal = false;
      } else {
        this.rename_folder = folder;
        this.show_rename_modal = true;
      }
    },
    deleteModalToggle(folder_id = 0) {
      if (this.show_delete_modal == true) {
        this.delete_folder_id = null;
        this.show_delete_modal = false;
      } else {
        this.delete_folder_id = folder_id;
        this.show_delete_modal = true;
      }
    },
    detailsModalToggle() {
      if (this.show_details_modal == true) {
        this.show_details_modal = false;
      } else {
        this.show_details_modal = true;
      }
    },
    deleteFolder(id) {
      NProgress.start();
      axios
        .delete(JS_APP_URL + "/abyde-drive/delete-folder", {
          params: { folder_id: id },
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            let data = "";
            if (response["data"]["data"]) {
              data = response["data"]["data"].join(", ");
            }
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            toastr.success(response["data"]["message"], "Success");
            if(this.parent_folder_id != "undefined"){
              this.getSubDocumentList(this.parent_folder_id);
            }else{
              this.getSubDocumentList();
            }

          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        });
    },
    getFolderDetails(id) {
      NProgress.start();
      axios
        .get(JS_APP_URL + "/abyde-drive/view-folder-detail", {
          params: { folder_id: id },
        })
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.view_folder_details = response["data"]["data"];
            this.show_details_modal = true;
          } else {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        });
    },
    downloadFolder(id) {
      NProgress.start();
      axios
        .post(JS_APP_URL + "/abyde-drive/download-folder", {
          folder_id: id,
          location_id: this.selected_location.id,
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            const filePath =
              response["data"]["data"]["download_url"].split("/");
            const fileName = filePath[filePath.length - 1];
            axios({
              url: response["data"]["data"]["download_url"],
              method: "GET",
              responseType: "blob",
            }).then((response) => {
              var fileURL = window.URL.createObjectURL(
                new Blob([response.data])
              );
              var fileLink = document.createElement("a");
              fileLink.href = fileURL;
              fileLink.setAttribute("download", fileName);
              document.body.appendChild(fileLink);
              fileLink.click();
            });
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        });
    },
    moveModalToggle(location_id = null, folder_id = null) {
      this.location_id = location_id;
      this.folder_id = folder_id;
      this.show_move_modal = !this.show_move_modal;
    },
    shareWithLocationModalToggle(){
      this.share_with_location = !this.share_with_location;
    },
    unshareWithLocationModalToggle(){
      this.unshare_with_location = !this.unshare_with_location;
    },
    toggleSortDir(){
      this.sort_by_dir = (this.sort_by_dir == 'ASC')?'DESC':'ASC';
    },
    onContextMenu(e, folder) {
        e.preventDefault();
        if (this.active_page != 'trash_page') {
          if(this.location_limit_count > 1){
            if((folder.is_shared == true && folder.folder_share_count > 0))
            {
              this.$contextmenu({
                x: e.x,
                y: e.y,
                customClass: "v-context drive-file-dropdown drive-file-dropdown",
                items: [
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Rename"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/pencil.svg',
                            class: 'rename-file-icon'
                        }),
                        onClick: () => {
                            this.renameModalToggle(folder);
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Download"),
                        icon: "drive-dropdown-img drive-download-icon",
                        onClick: () => {
                            this.downloadFolder(folder.id)
                        }
                        ,
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Delete"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/bin.svg',
                            class: 'bin-file-icon'
                        }),
                        onClick: () => {
                            this.deleteModalToggle(folder.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Move"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-move.svg',
                            class: 'move-file-icon'
                        }),
                        onClick: () => {
                            this.moveModalToggle(folder.location_id, folder.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Share"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/menu-folder-shared-small.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                          this.getSharedLocations(folder.location_id,folder.id,'folder')
                        },
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Unshare"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/menu-folder-unshared-small.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                          this.getSharedLocations(folder.location_id,folder.id,'folder','unshare')
                        },
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "View Details"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-info.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                            this.getFolderDetails(folder.id)
                        },
                    }
                ],
                //iconFontClass: 'iconfont',
                //customClass: "class-a",
                zIndex: 3,
                minWidth: 230,
                x: e.x,
                y: e.y,
              });
            }else{
              this.$contextmenu({
                x: e.x,
                y: e.y,
                customClass: "v-context drive-file-dropdown drive-file-dropdown",
                items: [
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Rename"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/pencil.svg',
                            class: 'rename-file-icon'
                        }),
                        onClick: () => {
                            this.renameModalToggle(folder);
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Download"),
                        icon: "drive-dropdown-img drive-download-icon",
                        onClick: () => {
                            this.downloadFolder(folder.id)
                        }
                        ,
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Delete"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/bin.svg',
                            class: 'bin-file-icon'
                        }),
                        onClick: () => {
                            this.deleteModalToggle(folder.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Move"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-move.svg',
                            class: 'move-file-icon'
                        }),
                        onClick: () => {
                            this.moveModalToggle(folder.location_id, folder.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Share"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/menu-folder-shared-small.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                          this.getSharedLocations(folder.location_id,folder.id,'folder')
                        },
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "View Details"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-info.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                            this.getFolderDetails(folder.id)
                        },
                    }
                ],
                //iconFontClass: 'iconfont',
                //customClass: "class-a",
                zIndex: 3,
                minWidth: 230,
                x: e.x,
                y: e.y,
              }); 
            }
          }else{
            this.$contextmenu({
                x: e.x,
                y: e.y,
                customClass: "v-context drive-file-dropdown drive-file-dropdown",
                items: [
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Rename"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/pencil.svg',
                            class: 'rename-file-icon'
                        }),
                        onClick: () => {
                            this.renameModalToggle(folder);
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Download"),
                        icon: "drive-dropdown-img drive-download-icon",
                        onClick: () => {
                            this.downloadFolder(folder.id)
                        }
                        ,
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Delete"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/bin.svg',
                            class: 'bin-file-icon'
                        }),
                        onClick: () => {
                            this.deleteModalToggle(folder.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Move"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-move.svg',
                            class: 'move-file-icon'
                        }),
                        onClick: () => {
                            this.moveModalToggle(folder.location_id, folder.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "View Details"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-info.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                            this.getFolderDetails(folder.id)
                        },
                    }
                ],
                //iconFontClass: 'iconfont',
                //customClass: "class-a",
                zIndex: 3,
                minWidth: 230,
                x: e.x,
                y: e.y,
            });
          }
        }
        else {
            this.$contextmenu({
                x: e.x,
                y: e.y,
                customClass: "v-context drive-file-dropdown",
                items: [
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Download"),
                        icon: "drive-dropdown-img drive-download-icon",
                        onClick: () => {
                            this.downloadFolder(folder.id)
                        }
                        ,
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "Move"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-move.svg',
                            class: 'move-file-icon'
                        }),
                        onClick: () => {
                            this.moveModalToggle(folder.location_id, folder.id)
                        },
                        divided: true,
                    },
                    {
                        label: h('div', {
                            class: "font-12 gray2--text drive-dropdown--text"
                        }, "View Details"),
                        icon: h('img', {
                            src: JS_APP_URL + '/images/file-info.svg',
                            class: 'info-file-icon'
                        }),
                        onClick: () => {
                            this.getFolderDetails(folder.id)
                        },
                    },
                ],
                //iconFontClass: 'iconfont',
                //customClass: "class-a",
                zIndex: 3,
                minWidth: 230,
                x: e.x,
                y: e.y,
            });
        }
    },
    selectLocationToggle(status = true, selected_location_id = '', selected_folder_id = '') {
      this.get_location_id = selected_location_id;
      this.get_folder_id = selected_folder_id;
      if(status == true) {
        this.show_location_popup = status;
      } else {
        this.show_location_popup = status;
      }
    }
  },
};
</script>
