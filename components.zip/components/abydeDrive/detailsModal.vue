<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
            <button @click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
            <h4 class="modal-title font-28 font_semibold blueog--text mb20">
                {{ modal_type == "file" ? "File Details" : "Folder Details" }}
            </h4>
            <div class="table-responsive">
            <table
                class="table folder-detail-table margin0"
                cellsspacing="0"
                v-if="modal_type == 'file'"
            >
                <tbody>
                <tr>
                    <td
                    style="width: 46%;vertical-align: text-top;"
                    class="folder-detail-td-left"
                    scope="row"
                    >
                    File name
                    </td>
                    <td
                    style="width: 56%"
                    class="break-word folder-detail-td-rihgt word-break "
                    >
                    {{ details.title }}
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="folder-detail-td-left">File size</td>
                    <td class="break-word folder-detail-td-rihgt word-break ">
                    {{ details.file_size }}
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="folder-detail-td-left">File type</td>
                    <td class="break-word folder-detail-td-rihgt word-break  uppercase">
                    {{ getFileType }}
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="folder-detail-td-left">Upload date</td>
                    <td class="break-word folder-detail-td-rihgt word-break ">
                    {{ $filters.formatCreateDate(details.updated_at)  }}
                    </td>
                </tr>
                <tr v-if="active_page != 'archive_page'">
                    <td scope="row" class="folder-detail-td-left">
                    Last modified date
                    </td>
                    <td class="break-word folder-detail-td-rihgt word-break ">
                    {{ $filters.formatCreateDate(details.updated_at) }}
                    </td>
                </tr>
                <tr v-if="active_page != 'archive_page' && details.user">
                    <td scope="row" class="folder-detail-td-left">Created by</td>
                    <td class="break-word folder-detail-td-rihgt word-break ">
                    {{ details.user.first_name +' '+ details.user.last_name }}
                    </td>
                </tr>
                </tbody>
            </table>
            <table
                class="table folder-detail-table margin0"
                cellsspacing="0"
                v-else
            >
                <tbody>
                <tr>
                    <td
                    style="width: 40%"
                    class="folder-detail-td-left"
                    scope="row"
                    >
                    Folder name
                    </td>
                    <td
                    style="width: 60%"
                    class="break-word folder-detail-td-rihgt word-break "
                    >
                    {{ details.folder_name }}
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="folder-detail-td-left">Created Date</td>
                    <td class="break-word folder-detail-td-rihgt word-break ">
                    {{ $filters.formatCreateDate(details.created_at) }}
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="folder-detail-td-left">
                    Last modified date
                    </td>
                    <td class="break-word folder-detail-td-rihgt word-break ">
                    {{ $filters.formatCreateDate(details.updated_at) }}
                    </td>
                </tr>
                <tr>
                    <td scope="row" class="folder-detail-td-left">Created by</td>
                    <td class="break-word folder-detail-td-rihgt word-break ">
                    {{ details.user.first_name +' '+ details.user.last_name}}
                    </td>
                </tr>
                </tbody>
            </table>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";
import _ from "lodash";

export default {
  components: { closeIcon },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
    };
  },
  emits: ["close-model"],
  props: {
    modal_type: String,
    details: Object,
    active_page:String,
  },
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
  },
  computed: {
    getFileType() {
      let file_extention = this.details.file_name.split(".").slice(-1);
      return _.lowerCase(file_extention);
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
