<template>
  <div>
    <folder-list
      :folders="documents.folders"
      :selected_location="selected_location"
      @get-sub-document-list="getSubDocumentList"
      :layout_style="layout_style"
      :parent_folder_id="parent_folder_id"
      :from_where="from_abyde_drive"
      :all_locations="all_locations"
      :location_limit_count="location_limit_count"
    ></folder-list>

    <file-list
      :files="documents.files"
      :layout_style="layout_style"
      @get-sub-document-list="getSubDocumentList"
      :parent_folder_id="parent_folder_id"
      :from_where="from_abyde_drive"
      :all_locations="all_locations"
      :location_limit_count="location_limit_count"
    ></file-list>

    <archive-page
      :selected_location="selected_location"
      :layout_style="layout_style"
      :active_page="active_page"
      @change-active-page="changeActivePage"
      v-if="parent_folder_id == 0"
    ></archive-page>
  </div>
</template>

<script scoped>
import folderList from "./folderList.vue";
import fileList from "./fileList.vue";
import archivePage from "./archivePage.vue";
import axios from "axios";

export default {
  components: { folderList, fileList, archivePage },
  props: {
    selected_location: Object,
    documents: Object,
    parent_folder_id: Number,
    layout_style: String,
    active_page: String,
    all_locations: Array,
    location_limit_count: Number
  },
  emits: ["get-sub-document-list", "change-active-page"],
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      from_abyde_drive: 'AbydeDrive',
      is_full_page_loader_shown: false,
      all_locations_list:[]
    };
  },
  methods: {
    getSubDocumentList(folder_id = 0, folder_name = "") {
      this.$emit("get-sub-document-list", folder_id, folder_name);
    },
    changeActivePage(pageName, folder_id = 0, folder_name = "") {
      this.$emit("change-active-page", pageName, folder_id, folder_name);
    },
  },
};
</script>
