<template>
  <div>
    <div
      class="drive-listing-row mb50"
      v-if="archive_folders && archive_folders.length > 0"
    >
      <div class="row flex-auto -mx-10 mb10 flex justify-between pb20">
        <div class="col-12 col-md-6 col-lg-4 col-xl-5 px10 mb-sm-10">
          <div class="font-22 font_semibold blueog--text" v-if="active_page == 'archive_page'">Folders</div>
          <div class="font-22 font_semibold blueog--text" v-if="active_page == 'home_page'">Archive</div>
        </div>
      </div>
      <div v-if="layout_style == 'list'">
        <div
          class="drive-listing-item pb10"
          v-for="folder in archive_folders"
          :key="folder.id"
        >
          <div class="row flex-auto items-center -mx-10">
            <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
              <a
                href="javascript:void(0)"
                @click="getSubDocumentList(folder.id, folder.folder_name)"
              >
                <div class="flex items-center file-folder-name-wrapper">
                  <img
                    :src="JS_APP_URL + '/images/folder-blue.svg'"
                    alt=""
                    title=""
                    class="mr12"
                  />
                  <span
                    class="font-16 font_semibold gray2--text file-list-name"
                    >{{ folder.folder_name }}</span
                  >
                </div>
              </a>
            </div>
            <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
              <span class="font-12 gray_checkmark--text">{{
                folder.description
              }}</span>
            </div>
            <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10 text-right">
              <VDropdown class="inline-block">
                <button type="button" class="cursor-pointer">
                  <img
                    :src="JS_APP_URL + '/images/drive-dots-blue.svg'"
                    alt=""
                    title=""
                    class="drive-dots-img"
                  />
                </button>
                <template #popper>
                  <div class="drive-file-dropdown">
                    <button
                      type="button"
                      class="drive-dropdown-item flex items-center"
                      v-close-popper
                      @click="downloadFolder(folder.id)"
                    >
                      <div class="drive-dropdown-img drive-download-icon">
                        <img
                          :src="JS_APP_URL + '/images/file-cloud.svg'"
                          alt=""
                          title=""
                          class="cloud-file-icon"
                        />
                      </div>
                      <span class="font-12 gray2--text drive-dropdown--text"
                        >Download</span
                      >
                    </button>
                  </div>
                </template>
              </VDropdown>
            </div>
          </div>
        </div>
      </div>
      <div v-if="layout_style == 'grid'">
        <div class="drive-files-box drive-folder-grid flex flex-wrap">
          <div
            class="drive-files-col"
            v-for="folder in archive_folders"
            :key="folder.id"
          >
            <div
              class="drive-file-item flex-auto flex flex-col"
              @click="getSubDocumentList(folder.id, folder.folder_name)"
              @contextmenu="onContextMenu($event, folder)"
            >
              <div
                class="
                  drive-file-img
                  flex flex-col
                  items-center
                  justify-center
                  flex-auto
                "
              >
                <img
                  :src="JS_APP_URL + '/images/folder-blue.svg'"
                  alt=""
                  title=""
                  class="drive-folder-icon"
                />
              </div>
              <div
                class="
                  drive-file-text
                  font-16 font_semibold
                  gray2--text
                  text-center
                "
              >
                {{ folder.folder_name }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <archive-file-list
    v-if="archive_documents.length > 0"
      :files="archive_documents"
      :layout_style="layout_style"
      :active_page="active_page"
    ></archive-file-list>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import fileList from "./fileList.vue";
import folderList from "./folderList.vue";
import fullPageLoader from "../common/fullPageLoader.vue";
import archiveFileList from "./ArchiveFileList.vue";
import { h } from 'vue'

export default {
  components: {
    fileList,
    folderList,
    fullPageLoader,
    archiveFileList,
  },
  props: {
    selected_location: Object,
    layout_style: String,
    active_page: String,
    archive_page_direct_folder_id: Number,
    archive_page_direct_folder_name: String,
    from_link: Boolean,
    archive_parent_folder_id: Number
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      archive_folders: [],
      archive_documents: [],
      is_full_page_loader_shown: false,
      show_doc_list: false,
    };
  },
  emits: ["toggle-from-link", "change-active-page", "append-breadcrumb"],
  mounted() {
    if (this.from_link == true){
      this.appendBreadcrumb(0,"Archive")
      this.appendBreadcrumb(Number(this.archive_parent_folder_id),"HIPAA Logs")
      this.$emit("toggle-from-link",false);
      // this.from_link = false
    }
    if(typeof(this.archive_page_direct_folder_id) !== "undefined" && this.archive_page_direct_folder_id != 0 && typeof(this.archive_page_direct_folder_name) !== "undefined" && this.archive_page_direct_folder_name != ""){
      this.getSubDocumentList(this.archive_page_direct_folder_id, this.archive_page_direct_folder_name);
    }else{
      this.getArchivedFolders();
    }
  },
  methods: {
    getArchivedFolders() {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/abyde-drive/get-archive-folders")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.archive_folders = response["data"]["data"];
            this.archive_documents = [];
          } else {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },

    getSubDocumentList(folder_id = 0, folder_name = "",appendBreadcrumb = true) {
      if(this.active_page == 'home_page'){
        this.$emit("change-active-page", "archive_page", folder_id, folder_name);
      }else{
        this.is_full_page_loader_shown = true;
        axios
          .get(
            JS_APP_URL +
              "/abyde-drive/get-archive-doc-list?location_id=" +
              this.selected_location.id +
              "&archive_folder_id=" +
              folder_id
          )
          .then((response) => {
            if (response["data"]["status"] == "Success") {
              this.archive_documents = response["data"]["data"]["files"];
              this.archive_folders = response["data"]["data"]["folders"];
              if(appendBreadcrumb == true){
                this.appendBreadcrumb(folder_id, folder_name);
              }
              // this.$emit("change-active-page", "archive_page");
            } else {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            this.is_full_page_loader_shown = false;
          });
      }
    },

    appendBreadcrumb(folder_id = 0, folder_name = "") {
      this.$emit("append-breadcrumb", {
        name: folder_name,
        id: folder_id,
        type: "archive_folder",
      });
    },

    downloadFolder(id) {
      this.is_full_page_loader_shown = true;
      axios
        .post(JS_APP_URL + "/abyde-drive/download-archive-folder", {
          folder_id: id,
          location_id: this.selected_location.id,
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            const filePath =
              response["data"]["data"]["download_url"].split("/");
            const fileName = filePath[filePath.length - 1];
            axios({
              url: response["data"]["data"]["download_url"],
              method: "GET",
              responseType: "blob",
            }).then((response) => {
              var fileURL = window.URL.createObjectURL(
                new Blob([response.data])
              );
              var fileLink = document.createElement("a");
              fileLink.href = fileURL;
              fileLink.setAttribute("download", fileName);
              document.body.appendChild(fileLink);
              fileLink.click();
            });
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    onContextMenu(e, folder) {
        e.preventDefault();
        this.$contextmenu({
            customClass: "drive-file-dropdown",
            items: [
                {
                    label: h('div', {
                        class: "font-12 gray2--text drive-dropdown--text"
                    }, "Download"),
                    icon: "drive-dropdown-img drive-download-icon",
                    onClick: () => {
                        this.downloadFolder(folder.id)
                    },
                },
            ],
            //iconFontClass: 'iconfont',
            //customClass: "class-a",
            zIndex: 3,
            minWidth: 230,
            x: e.x,
            y: e.y,
        });
    }
  },
};
</script>
