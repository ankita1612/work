<template>
    <div>
     <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask modal-scrollable">
                <div class="modal-wrapper animate__animated animate__zoomIn">
                    <div class="modal-container Whoa-modal">
                    <button @click="closeModal" class="cursor-pointer modal-close"
                    :class="{ 'd-none': close_icon_btn }" >
                        <close-icon></close-icon>
                    </button>
                    <h2
                        class="
                        font-28 font_semibold
                        blueog--text
                        line-normal
                        text-center
                        mb40 mt20
                        "
                    >
                        {{ modal_type == "rename" ? "Rename" : "Upload File(s)" }}
                    </h2>

                    <div class="form-group  mlr-auto" v-if="modal_type == 'rename'" :class="{ 'form-group--error': v$.file_name.$error }" style="max-width:263px;">
                        <input class="form-input" v-model="v$.file_name.$model" @keyup.enter="submit" />
                        <label class="label" :class="{ 'label-float': file_name }"
                        >File Name</label>
                        <div v-if="v$.file_name.$errors.length > 0">
                                <div class="form-error-text">
                                    {{ v$.file_name.$errors[0].$message }}
                                </div>
                        </div>
                    </div>

                    <vue-dropzone
                        ref="myVueDropzone"
                        id="dropzone"
                        :options="dropzoneOptions"
                        v-if="modal_type == 'upload'"
                        :useCustomSlot="true"
                        @vdropzone-error="dropzoneError"
                        @vdropzone-queue-complete="dropzoneQueueComplete"
                        @vdropzone-files-added="dropzoneFileAdded"
                        @vdropzone-removed-file="dropzoneRemovedFile"
                        :class="{ 'dz-disable': close_icon_btn}"
                        v-on:vdropzone-sending="sendingEvent"
                    >
                        <div class="dropzone-custom-content" :class="{ 'd-none': close_icon_btn}">
                        <h3 class="dropzone-custom-title font-22 text-999 font_normal">
                            Drag and drop files here or click to
                            select <br /> files from your device.
                        </h3>
                        <div class="subtitle"></div>
                        </div>
                    </vue-dropzone>

                    <div class="flex flex-wrap items-center justify-center mt40 mb20">
                        <button
                        @click="submit"
                        class="btn-primary"
                        :disabled="disable_submit_btn"
                        >
                        SUBMIT
                        </button>
                    </div>
                    </div>
                </div>
            </div>
        </transition>
     </Teleport>
        <div class="modal-backdrop"></div>
    </div>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import vueDropzone from 'dropzone-vue3'
import cookie from "cookie";
import { useVuelidate } from '@vuelidate/core';
import { required, maxLength, helpers } from "@vuelidate/validators";
import { alphaNumValidator } from "../common/customValidation";
import _ from "lodash";

export default {
  props: {
    modal_type: String,
    selected_location: Object,
    parent_folder_id: Number,
    file: Object,
  },
  setup: () => ({ v$: useVuelidate() }),
  emits: ["get-sub-document-list", "file-modal-toggle"],
  validations() {
    return {
        file_name: {
            required: helpers.withMessage('Please enter a file name', required),
            maxLength: helpers.withMessage('Max 25 characters allowed', maxLength(25)),
            alphaNumValidator: helpers.withMessage('Please enter a valid file name', alphaNumValidator),
        },
    }
  },
  components: { closeIcon, vueDropzone },
  data() {
    let params;
    if (this.modal_type == "upload") {
      params = {
        location_id: this.selected_location.id,
      };
    }
    if (this.parent_folder_id) {
      params.folder_id = this.parent_folder_id;
    }
    return {
      JS_APP_URL: JS_APP_URL,
      file_name: "",
      disable_submit_btn: true,
      close_icon_btn:false,
      dropzoneOptions: {
        headers: {
          "X-XSRF-TOKEN": cookie.parse(document.cookie)["XSRF-TOKEN"],
        },
        url: JS_APP_URL + "/abyde-drive/upload-file",
        params: params,
        thumbnailWidth: 200,
        addRemoveLinks: true,
        autoProcessQueue: false,
        parallelUploads: 1,
        uploadMultiple: false,
        timeout: 0,
        dataType: "JSON",
        maxFilesize: 10, // MB
        maxFiles: 10,
        dictMaxFilesExceeded: "You can select only 10 files at once",
        dictFileTooBig:"File is too big ({{filesize}}MB). Max filesize: {{maxFilesize}}MB.",
        dictUploadCanceled: "",
        acceptedFiles:
          ".csv,.doc,.docx,.jpg,.jpeg,.pdf,.png,.txt,.xls,.xlsx,.zip,.html",
        renameFile(file) {
          let file_name = _.trim(file.name);
          var name = file_name.substr(0, file_name.lastIndexOf('.'));
          var ext = file_name.substr(file_name.lastIndexOf('.') + 1);
          name = name.replace(/[^a-zA-Z0-9_\- ]/g, '');
          name = name.replace(/\s\s+/g, ' ');
          name = _.trim(name);
          if(name === ''){
            return (new Date()).getTime() +  '.' + ext;
          }else{
            if(name.length > 25){
              return name.substr(0, 25) + '.' + ext;
            }else{
              return name + '.' + ext;
            }
          }
        },
      },
    };
  },
  mounted() {
    if (this.file) {
      this.file_name = this.file.title;
    }
    if(this.modal_type == 'rename'){
      this.disable_submit_btn = false;
    }
  },
  methods: {
    dropzoneFileAdded(files) {
        this.disable_submit_btn = false;
    },
    dropzoneRemovedFile(file, error, xhr) {
        if (this.$refs.myVueDropzone && this.$refs.myVueDropzone.getQueuedFiles().length <= 0) {
            this.disable_submit_btn = true;
        }
    },
    dropzoneError(file, message, xhr) {
        this.disable_submit_btn = false;
        this.close_icon_btn = false;
        if (this.$refs.myVueDropzone) {
            this.$refs.myVueDropzone.removeFile(file);
        }
        if (message) {
            toastr.error(message, "Error!");
        } else {
            if (xhr) {
                let res = JSON.parse(xhr.response);
                if (res.status == "Error") {
                    toastr.error(res.message, "Error!");
                }
            }
        }
    },
    dropzoneQueueComplete() {
        if (this.parent_folder_id != 0) {
            this.$emit("get-sub-document-list", this.parent_folder_id);
        } else {
            this.$emit("get-sub-document-list");
        }
        this.closeModal();
    },
    async submit() {
      let url = "";

      let payload = {
        file_name: this.file_name,
      };

      if (this.modal_type == "rename") {
        const is_valid = await this.v$.$validate()
        if (is_valid) {
          this.disable_submit_btn = true;
          payload.file_id = this.file.id;
          url = this.JS_APP_URL + "/abyde-drive/rename-file";
          axios
            .post(url, payload)
            .then((response) => {
              if (response["data"]["status"] == "Error") {
                if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
              } else {
                toastr.success(response["data"]["message"], "Success");
                this.$emit("get-sub-document-list");
                this.closeModal();
              }
            })
            .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
              }
            })
            .then(() => {
              this.disable_submit_btn = false;
            });
        }
      } else {
        [].forEach.call(document.querySelectorAll('.dz-remove'), (el) => {
          el.style.visibility = 'hidden';
        });
        this.disable_submit_btn = true;
        this.close_icon_btn = true;
        setTimeout(() => {
          this.$refs.myVueDropzone.processQueue();
        }, 400);

      }
    },

    closeModal() {
      this.$emit("file-modal-toggle");
    },
    sendingEvent(file, xhr, formData) {
        formData.append('location_id', this.selected_location.id);
        if (this.parent_folder_id) {
            formData.append('folder_id', this.parent_folder_id);
        }
    }
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
         if(this.close_icon_btn == false || !this.disable_submit_btn){
           this.closeModal();
         }
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
