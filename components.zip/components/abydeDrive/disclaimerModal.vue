<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
            <a :href="JS_APP_URL" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </a>
            <div class="text-center mlr-auto mb10 pt20">
                <img
                :src="JS_APP_URL + '/images/alert.svg'"
                alt=""
                title=""
                class="warning-icon-modal"
                />
            </div>
            <h2
                class="
                font-24 font_semibold
                blueog--text
                line-normal
                text-center
                mb20
                "
            >
                Disclaimer!
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">
                Protected Health Information may NOT be uploaded into or <br/> stored within the Abyde Drive. For reference, review the <br/>
                <a :href="(AUTH_USER.partner_reseller_id != null)?JS_WORDPRESS_URL + '/reseller-terms-and-conditions':JS_WORDPRESS_URL + '/terms-conditions'" target="_blank" class="font-16 font_semibold green--text"> terms and conditions</a> of the <span class="font-italic">Abyde
                Drive.</span>
            </p>
            <div class="flex flex-wrap items-center justify-center pb40">
                <button @click="closeModal" class="btn-primary-outline h-32">
                GOT IT!
                </button>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";

export default {
  components: { closeIcon },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      AUTH_USER: AUTH_USER,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  emits: ["close-model"],
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
  },
  created() {
    // document.body.classList.add('modal-open');
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
