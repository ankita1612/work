<template>
  <div>
    <header-after-login
      @location-limit-count="locationLimitCount"
    >
    </header-after-login>
    <div class="container pt40 pb60">
      <div class="flex justify-center flex-wrap mb30" :class="{'drive-title-single':all_locations.length == 1}">
        <div class="form-group mb-0 location-dropdon mlr-auto"  v-if="all_locations.length>1">
          <multiselect
            class="company-location-select"
            v-model="selected_location"
            :options="all_locations"
            label="location_nickname"
            :taggable="false"
            :multiple="false"
            :close-on-select="true"
            :showLabels="false"
            track-by="id"
            placeholder=""
            :allowEmpty="false"
          >
            <template #noResult>
              <div class="multiselect__noResult text-center">
                No results found
              </div>
            </template>
          </multiselect>
          <label class="label label-select label-float">Location</label>
        </div>
        <div class="relative">
          <div class="view-type flex items-center" :class="{'view-type-single':all_locations.length == 1}">
            <span class="font-18 blueog--text mr4">View:</span>
            <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" style="height: 32px;" class="cursor-pointer">
              <template #popper>
                List View
              </template>
              <button
                type="button"
                class="view-type-item cursor-pointer px0"
                :class="{ active: layout_style == 'list' }"
                @click="changeLayoutStyle('list')"
              >
                <img
                  :src="JS_APP_URL + '/images/view-list.svg'"
                  alt=""
                  title=""
                  class=""
                />
              </button>
            </VTooltip>
            <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" style="height: 32px;" class="cursor-pointer">
              <template #popper>
                Grid View
              </template>
              <button
                type="button"
                class="view-type-item cursor-pointer px0 ml3"
                :class="{ active: layout_style == 'grid' }"
                @click="changeLayoutStyle('grid')"
              >
                <img
                  :src="JS_APP_URL + '/images/view-grid.svg'"
                  alt=""
                  title=""
                  class=""
                />
              </button>
            </VTooltip>
          </div>
        </div>
      </div>
      <div class="flex items-center justify-center flex-wrap">
        <h1
          class="
            location-dashbaord-title
            text-center
            font-24 font_semibold
            blueog--text
            line-normal
            mb20
          "
          v-if="active_page == 'home_page' && parent_folder_id == 0"
         >
          Abyde Drive
        </h1>
        <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml6 mb20 mb-md-5 mb-sm-5" v-if="active_page == 'home_page' && parent_folder_id == 0">
            <button @click="PlayExplainerVideoModalToggle('yes')" class="cursor-pointer svg-icon-height dashboard-video-icon mt4">
              <explainer-video-icon></explainer-video-icon>
            </button>
            <template #popper>
              Video Guide
            </template>
        </VTooltip>  
      </div>
    
      <div class="row flex-auto -mx-10 mb30">
        <sidebar-menu-option
          :all_locations="all_locations"
          :selected_location="selected_location"
          :parent_folder_id="parent_folder_id"
          :active_page="active_page"
          :location_limit_count="location_limit_count"
          @change-active-page="changeActivePage"
          @get-sub-document-list="getDocumetsList"
        ></sidebar-menu-option>
        <div
          class="col-12 col-md-9 col-lg-9 col-xl-10 px10 recent-file-column"
          v-if="
            documents.recent_files &&
            documents.recent_files.length > 0 &&
            active_page == 'home_page'
          "
        >         
          <file-list
            :files="documents.recent_files"
            layout_style="grid"
            :show_search_bar="false"
            @get-sub-document-list="getDocumetsList"
            :all_locations="all_locations"
            :location_limit_count="location_limit_count"
          ></file-list>
        </div>
        <div class="col-12 col-md-9 col-lg-9 col-xl-10 px10 recent-file-column">
          <div
            class="drive-breadcrumb flex flex-wrap mb20"
            v-if="active_page != 'home_page' || parent_folder_id != 0"
          >
            <button
              type="button"
              class="
                breadcrumb-active
                font-20 font_semibold
                blueog--text
                cursor-pointer
                px0
                breadcrumb-nav-main
              "
              @click="changeActivePage('home_page')"
            >
              Abyde Drive
            </button>
            <div v-for="(bc, index) in breadcrumb" :key="index">
              <span v-if="breadcrumb.length - 1 == index"
                class="font-18 breadcrumb-nav text-999 cursor-pointer breadcrumb-item">{{ bc.name }}</span>
              <span v-else class="font-18 breadcrumb-nav text-999 cursor-pointer breadcrumb-item"
                @click="changeBreadcrumbWithData(bc, index)" >{{ bc.name }}</span>
            </div>
          </div>
          <recent-page
            :selected_location="selected_location"
            :layout_style="layout_style"
            :all_locations="all_locations"
            v-if="active_page == 'recent_page'"
            :location_limit_count="location_limit_count"
          ></recent-page>

          <trash-page
            :selected_location="selected_location"
            :layout_style="layout_style"
            v-if="active_page == 'trash_page'"
            @append-breadcrumb="appendBreadcrumb"
            @change-active-page="changeActivePage"
            :trash_page="trash_page"
            :trash_page_direct_folder_id="trash_page_direct_folder_id"
            :trash_page_direct_folder_name="trash_page_direct_folder_name"
          ></trash-page>

          <archive-page
            :selected_location="selected_location"
            :layout_style="layout_style"
            :active_page="active_page"
            :archive_page_direct_folder_id="archive_page_direct_folder_id"
            :archive_page_direct_folder_name="archive_page_direct_folder_name"
            v-if="active_page == 'archive_page'"
            @append-breadcrumb="appendBreadcrumb"
            @toggle-from-link="from_link = !from_link"
            :from_link="from_link"
            :archive_parent_folder_id="archive_parent_folder_id"
            :key="archive_page"
             ref="archivePageComponent"
          ></archive-page>

          <shared-me-page
            :selected_location="selected_location"
            :shared_documents="shared_documents"
            :parent_folder_id="parent_folder_id"
            :layout_style="layout_style"
            @append-breadcrumb="appendBreadcrumb"
            @get-sub-document-list="getSharedDocumetsList"
            v-if="active_page == 'shared_me'"
          ></shared-me-page>

          <home-page
            :selected_location="selected_location"
            :documents="documents"
            :parent_folder_id="parent_folder_id"
            :layout_style="layout_style"
            @get-sub-document-list="getDocumetsList"
            v-if="active_page == 'home_page' && parent_folder_id != 0"
            :all_locations="all_locations"
            :location_limit_count="location_limit_count"
          ></home-page>
        </div>
      </div>

      <home-page
        :selected_location="selected_location"
        :documents="documents"
        :parent_folder_id="parent_folder_id"
        :layout_style="layout_style"
        :active_page="active_page"
        @get-sub-document-list="getDocumetsList"
        @change-active-page="changeActivePage"
        v-if="active_page == 'home_page' && parent_folder_id == 0"
        :all_locations="all_locations"
        :location_limit_count="location_limit_count"
      ></home-page>
    </div>
    <disclaimer-modal
      v-if="show_disclaimer_modal"
      @close-model="disclaimerModalToggle"
    ></disclaimer-modal>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    <play-explainer-video-modal v-if="play_video_modal == true" :video_file="video_file"
      :video_caption_file="video_caption_file" @close-model="PlayExplainerVideoModalToggle"></play-explainer-video-modal>
  </div>
</template>

<style scoped>
</style>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import fullPageLoader from "../common/fullPageLoader.vue";
import infoIcon from "../common/icons/infoIcon.vue";
import plusIcon from "../common/icons/plusIcon.vue";
import noDataIcon from "../common/icons/noDataIcon.vue";
import disclaimerModal from "./disclaimerModal.vue";
import homePage from "./homePage.vue";
import recentPage from "./recentPage.vue";
import trashPage from "./trashPage.vue";
import archivePage from "./archivePage.vue";
import sidebarMenuOption from "./sidebarMenuOption.vue";
import fileList from "./fileList.vue";
import sharedMePage from "./sharedMePage.vue";
import _ from "lodash";
import explainerVideoIcon from "../common/icons/explainerVideoIcon.vue";
import playExplainerVideoModal from "../common/includes/playExplainerVideoModal.vue";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_full_page_loader_shown: false,
      all_locations: [],
      selected_location: {},
      show_disclaimer_modal:
      localStorage.getItem("show_disclaimer_modal") == "false" ? false : true,
      documents: {},
      parent_folder_id: 0,
      active_page: "home_page",
      layout_style: "list",
      breadcrumb: [],
      archive_page: 0,
      archive_page_direct_folder_id: 0,
      archive_page_direct_folder_name: "",
      archive_parent_folder_id: 0,
      trash_page: 0,
      trash_page_direct_folder_id: 0,
      trash_page_direct_folder_name: "",
      url_location_id: null,
      from_link: false,
      archive_parent_folder_id: 0,
      video_file: "hce_explainer_abyde_drive_final.mp4",  
      video_caption_file: "hce_explainer_abyde_drive_final.vtt",  
      play_video_modal: false,
      shared_documents: {},
      location_limit_count: 0
    };
  },
  mounted() {
    let url = (new URL(window.location))
    this.url_location_id = url.searchParams.get('location_id')
    let folder_id = Number(url.searchParams.get('folder_id'))
    this.archive_parent_folder_id = Number(url.searchParams.get('parent_id'))
    this.loadLocationNicknameList();
    if (this.url_location_id != null){
      this.from_link = true
      this.archive_page_direct_folder_id = folder_id
      this.archive_page_direct_folder_name = "Breach Logs"  
    }
  },
  components: {
    headerAfterLogin,
    fullPageLoader,
    infoIcon,
    plusIcon,
    noDataIcon,
    disclaimerModal,
    homePage,
    recentPage,
    trashPage,
    archivePage,
    sidebarMenuOption,
    fileList,
    explainerVideoIcon,
    playExplainerVideoModal,
    sharedMePage,
  },
  watch: {
    selected_location(val) {
      this.active_page = (this.url_location_id != null && this.url_location_id == val.id) ? "archive_page" : "home_page";
      this.url_location_id = null;
      this.getDocumetsList();
    },
  },
  methods: {
    locationLimitCount(location_limit_count){
      this.location_limit_count = location_limit_count
    },
    PlayExplainerVideoModalToggle() {
      if (this.play_video_modal == true) {
        this.play_video_modal = false;
      } else {
        this.play_video_modal = true;
      }
    },
    changeBreadcrumbWithData(bc, index) {
      let static_bc = ["Archive", "Recent", "Trash", "Shared with me"];
      if (static_bc.includes(bc.name)) {
        switch (bc.name) {
          case "Archive":
            this.changeActivePage("archive_page");
            break;
          case "Recent":
            break;
          case "Trash":
            this.changeActivePage("trash_page");
            break;
          case "Shared with me":            
            this.changeActivePage("shared_me");
            break;
        }
      } else {
        this.breadcrumb.splice(index + 1);
        if (bc.type == "archive_folder") {
          this.$refs.archivePageComponent.getSubDocumentList(bc.id,bc.name,false);
        }
        if (bc.type == "folder") {
          this.getDocumetsList(bc.id);
        }
        if (bc.type == "shared_folder") {
          this.getSharedDocumetsList(bc.id);
        }
        if(bc.type == 'trash_folder'){
          this.trash_page_direct_folder_id = bc.id
          this.trash_page_direct_folder_name = bc.name
        }
      }
    },

    appendBreadcrumb(bc) {
      this.breadcrumb.push(bc);
    },

    loadLocationNicknameList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/general/get-assigned-location-list")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.all_locations = response["data"]["data"];
            if (this.url_location_id != null){
              let new_location = this.all_locations.find(o => o.id == this.url_location_id)
              this.selected_location = _.isEmpty(new_location) ? this.all_locations[0] : new_location
            }else{
              this.selected_location = this.all_locations[0];
            }
          } else {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },

    disclaimerModalToggle() {
      this.show_disclaimer_modal = !this.show_disclaimer_modal;
      localStorage.setItem("show_disclaimer_modal", false);
    },

    getDocumetsList(parent_folder_id = 0, parent_folder_name = "") {
      if (parent_folder_id) {
        if (parent_folder_name != "") {
          this.appendBreadcrumb({
            name: parent_folder_name,
            id: parent_folder_id,
            type: "folder",
          });
        }
      } else {
        this.breadcrumb = [];
      }
      this.parent_folder_id = parent_folder_id;
      this.is_full_page_loader_shown = true;
      let url =
        JS_APP_URL +
        "/abyde-drive/list-documents?location_id=" +
        this.selected_location.id;

      if (parent_folder_id != 0) {
        url = url + "&parent_folder_id=" + this.parent_folder_id;
      }
      axios
        .get(url)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.documents = response["data"]["data"];
          } else {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },

    getSharedDocumetsList(parent_folder_id = 0, parent_folder_name = "") {
      if (parent_folder_id) {
        if (parent_folder_name != "") {
          this.appendBreadcrumb({
            name: parent_folder_name,
            id: parent_folder_id,
            type: "shared_folder",
          });
        }
      } else {
        this.breadcrumb = [
            {
              name: "Shared with me",
            },
          ];
      }
      this.parent_folder_id = parent_folder_id;
      this.is_full_page_loader_shown = true;
      let url =
        JS_APP_URL +
        "/abyde-drive/list-shared-me-documents?location_id=" +
        this.selected_location.id;

      if (parent_folder_id != 0) {
        url = url + "&parent_folder_id=" + this.parent_folder_id;
      }
      axios
        .get(url)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.shared_documents = response["data"]["data"];
          } else {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },

    changeActivePage(pageName, folder_id = 0, folder_name = "") {
      this.active_page = pageName;
      switch (pageName) {
        case "home_page":
          this.getDocumetsList();
          break;
        case "recent_page":
          this.breadcrumb = [
            {
              name: "Recent",
            },
          ];
          break;
        case "archive_page":
          this.archive_page++;
          this.breadcrumb = [
            {
              name: "Archive",
            },
          ];
          if(folder_id != 0 && folder_name != ""){
            this.archive_page_direct_folder_id = folder_id;
            this.archive_page_direct_folder_name = folder_name;
          }else{
            this.archive_page_direct_folder_id = 0;
            this.archive_page_direct_folder_name = "";
          }
          break;
        case "trash_page":
          this.trash_page++;
          this.breadcrumb = [
            {
              name: "Trash",
            },
          ];
          break;
        case "shared_me":
          this.getSharedDocumetsList();
          break;
      }
    },

    changeLayoutStyle(style = "list") {
      this.layout_style = style;
    },
  },
};
</script>
