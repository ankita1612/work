<template>
  <div class="col-12 col-md-3 col-lg-3 col-xl-2 px10">
    <div class="mb15" v-if="active_page == 'home_page'">
      <VDropdown>
        <button
          type="button"
          class="btn-blue-outline btn-left-icon btn-new-plus"
          @click="subMenuToggle"
        >
          <div class="prev-arrow-icon">
            <plus-icon class="new-plus-svg"></plus-icon>
          </div>
          New
        </button>
        <template #popper>
          <div class="new-folder-dropdown">
            <button
              type="button"
              class="drive-dropdown-item flex items-center"
              @click="folderModalToggle"
              v-close-popper
            >
              <div class="drive-dropdown-img">
                <img
                  :src="JS_APP_URL + '/images/folder.svg'"
                  alt=""
                  title=""
                  class="folder-file-icon"
                />
              </div>
              <span class="font-14 blueog--text drive-dropdown--text flex-auto text-left font_semibold"
                >New Folder</span
              >
            </button>
            <button
              type="button"
              class="drive-dropdown-item flex items-center"
              @click="fileModalToggle"
              v-close-popper
            >
              <div class="drive-dropdown-img">
                <img
                  :src="JS_APP_URL + '/images/upload-file.svg'"
                  alt=""
                  title=""
                  class="upload-file-icon"
                />
              </div>
              <span class="font-14 blueog--text drive-dropdown--text flex-auto text-left font_semibold"
                >File Upload</span
              >
            </button>
          </div>
        </template>
      </VDropdown>
    </div>
    <div class="mb15">
      <button
        type="button"
        class="dive-menu-item flex items-center"
        @click="changeActivePage('home_page')"
        :class="{ active: active_page == 'home_page' }"
      >
        <div class="drive-menu-img">
          <img
            :src="JS_APP_URL + '/images/drive.svg'"
            alt=""
            title=""
            class="drive-menu-icon"
          />
        </div>
        <span class="font-14 gray2--text pl10">Abyde Drive</span>
      </button>
    </div>
    <div class="mb15">
      <button
        type="button"
        class="dive-menu-item flex items-center"
        @click="changeActivePage('archive_page')"
        :class="{ active: active_page == 'archive_page' }"
      >
        <div class="drive-menu-img">
          <img
            :src="JS_APP_URL + '/images/archive.svg'"
            alt=""
            title=""
            class="drive-menu-icon"
          />
        </div>
        <span class="font-14 gray2--text pl10">Archive</span>
      </button>
    </div>
    <div v-if="location_limit_count > 1" class="mb15">
      <button
        type="button"
        class="dive-menu-item flex items-center"
        @click="changeActivePage('shared_me')"
        :class="{ active: active_page == 'shared_me' }"
      >
        <div class="drive-menu-img">
          <img
            :src="JS_APP_URL + '/images/folder-shared.svg'"
            alt=""
            title=""
            class="drive-menu-icon"
          />
        </div>
        <span class="font-14 gray2--text pl10">Shared With Me</span>
      </button>
    </div>
    <div class="mb15">
      <button
        type="button"
        class="dive-menu-item flex items-center"
        @click="changeActivePage('recent_page')"
        :class="{ active: active_page == 'recent_page' }"
      >
        <div class="drive-menu-img">
          <img
            :src="JS_APP_URL + '/images/clock.svg'"
            alt=""
            title=""
            class="drive-menu-icon"
          />
        </div>
        <span class="font-14 gray2--text pl10">Recent</span>
      </button>
    </div>
    <div class="mb15">
      <button
        type="button"
        class="dive-menu-item flex items-center"
        @click="changeActivePage('trash_page')"
        :class="{ active: active_page == 'trash_page' }"
      >
        <div class="drive-menu-img">
          <img
            :src="JS_APP_URL + '/images/bin.svg'"
            alt=""
            title=""
            class="drive-menu-icon"
          />
        </div>
        <span class="font-14 gray2--text pl10">Trash</span>
      </button>
    </div>
    <folder-modal
      v-if="show_folder_modal"
      modal_type="new"
      @folder-modal-toggle="folderModalToggle"
      @get-sub-document-list="getDocumetsList"
      :selected_location="selected_location"
      :parent_folder_id="parent_folder_id"
    ></folder-modal>
    <file-modal
      v-if="show_file_modal"
      :modal_type="'upload'"
      :selected_location="selected_location"
      :parent_folder_id="parent_folder_id"
      @file-modal-toggle="fileModalToggle"
      @get-sub-document-list="getDocumetsList"
    ></file-modal>
  </div>
</template>

<script scoped>
import plusIcon from "../common/icons/plusIcon.vue";
import folderModal from "./folderModal.vue";
import fileModal from "./fileModal.vue";
import axios from "axios";

export default {
  props: {
    selected_location: Object,
    parent_folder_id: Number,
    active_page: String,
    all_locations: Array,
    location_limit_count: Number
  },
  components: { plusIcon, folderModal, fileModal },
  emits: ["change-active-page", "get-sub-document-list"],
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      show_sub_menu: false,
      show_folder_modal: false,
      show_file_modal: false,
    };
  },
  methods: {
    subMenuToggle() {
      this.show_sub_menu = !this.show_sub_menu;
    },

    folderModalToggle() {
      this.show_folder_modal = !this.show_folder_modal;
    },

    fileModalToggle() {
      this.show_file_modal = !this.show_file_modal;
    },
    changeActivePage(pageName) {
      this.$emit("change-active-page", pageName);
    },
    getDocumetsList(folder_id = 0, folder_name = "") {
      this.$emit("get-sub-document-list", folder_id, folder_name);
    },
  },
};
</script>
