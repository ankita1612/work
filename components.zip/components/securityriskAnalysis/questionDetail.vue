<template>
  <div v-if="loaded">
    <full-page-loader v-if="is_full_page_loader_shown" />
    <h6 class="font-22 font_light blueog--text text-center line-normal" v-if="has_multi_locations">
      {{ selected_location.location_nickname }}
    </h6>
    <h1 class="font-24 font_semibold blueog--text text-center mb-md-20 mb25">
      Security Risk Analysis
    </h1>
    <div class="security-progress-wrapper mb24">
      <radial-progress-bar class="sra-quetions-progress" :diameter="200" :completed-steps="percentage_count.percentage"
        :total-steps="total_steps_outer" :start-color="start_color_outer" :stop-color="start_color_outer"
        :inner-stroke-color="inner_stroke_color" :inner-stroke-width="3" :stroke-width="6">
        <h1 class="sra-percent-text font_semibold" v-bind:style="{ color: start_color_outer }">
          {{ percentage_count.percentage }}%
        </h1>
        <h3 class="sra-completed-text">Completed</h3>
      </radial-progress-bar>
    </div>
    <div class="text-center mb2">
      <span class="
              font-25 font_semibold
              blue--text
              inline-flex
              items-center
              flex-wrap
            ">
        {{ question_detail.question_category.category_title }}
        <VTooltip :triggers="['hover']" :popperTriggers="['hover']" style="height: 24px;" class="cursor-pointer ml10">
          <span><info-icon></info-icon></span>
          <template #popper>
            {{ question_detail.question_category.category_description ?
              question_detail.question_category.category_description : question_detail.question_category.category_title }}
          </template>
        </VTooltip>
      </span>
    </div>
    <div class="text-center mb18">
      <span class="
              font-16
              gray_checkmark--text
              inline-flex
              items-center
              flex-wrap
            ">
        {{ question_detail.question_law_section ? question_detail.question_law_section.title : "" }}
      </span>
    </div>
    <p class="font-25 black--text text-center mb50 quetion-text" v-html="question_detail.question">
    </p>
    <div class="sra-quetions-wrapper mlr-auto">
      <div class="row flex-auto justify-center -mx-10 mb15" v-if="question_detail.question_answer_layout == 'radio'">
        <div class="col-12 col-md-12 col-lg-4 col-xl-4 mb-md-20 px10"
          v-for="answer_opt in question_detail.risk_analysis_question_answer_options" :key="answer_opt.id">
          <div class="answer-option-item">
            <input type="radio" class="answer-option-radio" :id="'radio ' + answer_opt.id" :value="answer_opt.id"
              v-model="selected_answers" />
            <label class="answer-option-lable font-20 blueog--text" :for="'radio ' + answer_opt.id">{{ answer_opt.answer
            }}</label>
          </div>
        </div>
      </div>

      <div class="row flex-auto justify-center -mx-10 mb15" v-if="question_detail.question_answer_layout == 'checkbox'">
        <div class="col-12 col-md-12 col-lg-4 col-xl-4 mb-md-20 px10"
          v-for="answer_opt in question_detail.risk_analysis_question_answer_options" :key="answer_opt.id">
          <div class="answer-option-item">
            <input type="checkbox" class="answer-option-radio" :id="'radio ' + answer_opt.id" :value="answer_opt.id"
              v-model="selected_answers" />
            <label class="answer-option-lable font-20 blueog--text" :for="'radio ' + answer_opt.id">{{ answer_opt.answer
            }}</label>
          </div>
        </div>
      </div>

      <div v-if="question_detail.question_answer_layout == 'text'">
        <div class="mb15 relative">
          <textarea rows="4" class="textarea form-input" v-model.trim="answer_txt"></textarea>
          <label class="label location-input-label" :class="{ 'label-float': answer_txt }">Please enter an answer</label>
        </div>
      </div>

      <div v-if="show_error" class="mb10 font-12 red2--text">
        <div v-if="question_detail.question_answer_layout == 'radio'" class="text-center font-16 font_bold">
          * Please select an answer to continue
        </div>
        <div v-if="question_detail.question_answer_layout == 'checkbox'" class="text-center font-16 font_bold">
          * Please select answer(s) to continue
        </div>
        <div v-if="question_detail.question_answer_layout == 'text'" class="text-center font-16 font_bold">
          * Please enter an answer to continue
        </div>
      </div>

      <div v-if="has_comment">
        <div class="px10 py10 answer-view-block relative mb10">
          <p class="font-15 font_semibold black--text mb4">Note:</p>
          <p class="font-14 font_semibold dark--text word-break">{{ note_txt }}</p>
          <div class="">
            <button type="button" class="edit-comment-btn" @click="toggleCommentBox">
              <img :src="JS_APP_URL + '/images/pencil.svg'" alt="" title="">
            </button>
            <button type="button" class="edit-bin-btn" @click="removeComment">
              <img :src="JS_APP_URL + '/images/bin.svg'" alt="" title="">
            </button>
          </div>
        </div>
        <div class="">
          Your note will be saved upon hitting the NEXT or SAVE &amp; EXIT button
        </div>
      </div>
      <div v-else class="
              flex
              justify-end
              items-center
              flex-wrap
              sra-add-comment-wrapper
              mb20
            ">
        <div class="relative sra-add-comment">
          <div v-if="toggle_comment_box">
            <div class="text-center sra-textarea-wrapper">
              <div class="textarea-box relative">
                <textarea rows="4" class="textarea form-input" :maxLength="max_characters_comment"
                  v-model.trim="note_txt"></textarea>
                <label class="label location-input-label" :class="{ 'label-float': note_txt }">Add Note</label>
                <button type="button" class="bin-btn" @click="
                  () => {
                    this.note_txt = '';
                  }
                ">
                  <img :src="JS_APP_URL + '/images/bin.svg'" alt="" title="">
                </button>
              </div>
              <div class="relative text-left font-11 save-hint-text">
                Your note will be saved upon hitting the NEXT or SAVE &amp; EXIT button
              </div>
              <div class="relative textarea-remaining-text">
                <div class="
                        font-10
                        fotn-light
                        gray_checkmark--text
                        text-right
                        textarea-character-count
                      ">
                  {{ reamining_characters_comment }} Characters Remaining
                </div>
              </div>
            </div>
          </div>
        </div>

        <button type="button" class="
                btn-blue-outline btn-width-136
                h-32
                d-inline-block
                px30
                mt-xs-20
                ml22
              " @click="toggleCommentBox" :disabled="is_btn_disabled">
          ADD NOTE
        </button>
      </div>

      <div class="text-center relative mt12">
        <div class="text-left mb-md-20">
        <button type="button" class="btn-blue-outline btn-left-icon prev-btn" @click="loadPreviousQuestion" v-if="has_previous"
            :disabled="is_btn_disabled">
            <div class="prev-arrow-icon"><previous-icon></previous-icon></div>
            Previous Question
        </button>
        </div>
        <button type="submit" class="
                btn-blueog-outline btn-width-136
                h-32
                d-inline-block
                px30
              " @click="saveAndExit" :disabled="is_btn_disabled">
          Save &amp; Exit
        </button>
        <button type="submit" class="btn-primary btn-width-136 h-32 d-inline-block px30 next-btn"
          @click="loadNextQuestion" :disabled="is_btn_disabled">
          Next
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import RadialProgressBar from "vue3-radial-progress";
import previousIcon from "../common/icons/previousIcon.vue";
import infoIcon from "../common/icons/infoIcon.vue";
import binIcon from "../common/icons/binIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import _ from 'lodash';
import fullPageLoader from "../common/fullPageLoader.vue";

let given_answer = "";
let given_note = "";

export default {
  props: {
    pagination: {
      type: String,
    },
    selected_location: {
      type: Object,
    },
    has_multi_locations: {
      type: Boolean,
    },
    is_demo_account: {
      type: Number,
    },
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      inner_stroke_color: "#CCCCCC",
      percentage_count: {},
      total_steps_outer: 100,
      start_color_outer: "#CCCCCC",
      start_color_inner: "#203C72",
      strokeLinecap: "",
      pagination_type: this.pagination,
      question_detail: {},
      toggle_comment_box: false,
      selected_answers: [],
      last_answer_data: {},
      answer_txt: "",
      note_txt: "",
      has_previous: false,
      loaded: false,
      show_error: false,
      max_characters_comment: 1000,
      reamining_characters_comment: 1000,
      is_btn_disabled: false,
      has_comment: false,
      is_full_page_loader_shown: true,
      is_exit_pressed: false,
    };
  },
  emits: ["toggle-loader", "show-page"],
  components: {
    RadialProgressBar,
    previousIcon,
    infoIcon,
    binIcon,
    fullPageLoader,
  },

  mounted() {
    this.loadQuestion();
  },

  watch: {
    percentage_count(val) {
      if (val.percentage <= 69) {
        this.start_color_outer = "#C72121";
      } else if (val.percentage > 69 && val.percentage <= 89) {
        this.start_color_outer = "#FAC224";
      } else {
        this.start_color_outer = "#7FC361";
      }
    },
    selected_answers(val) {
      this.show_error = false;
    },
    answer_txt(val) {
      if (val != "") {
        this.show_error = false;
      }
    },
    note_txt(val) {
      this.note_txt = (val) ? val.replace(/\n|\r|  +/g, "") : "";
      if (val) {
        this.reamining_characters_comment =
          this.max_characters_comment - val.length;
      } else {
        this.reamining_characters_comment = this.max_characters_comment;
      }
    },
  },

  methods: {
    loadQuestion() {
      this.$emit("toggle-loader", true);
      this.is_full_page_loader_shown = true;
      this.has_comment = false;
      this.selected_answers = [];
      this.is_btn_disabled = true;
      let payload = {
        location_id: this.selected_location.id,
        pagination_type: this.pagination_type,
      };

      if (this.pagination_type == "next") {
        payload.question_id = this.last_answer_data.question_id;
        payload.answer_id = this.last_answer_data.answer_id;
      }
      if (this.pagination_type == "previous") {
        payload.question_id = this.question_detail.id;
      }
      axios
        .post(
          JS_APP_URL + "/security-risk-analysis/load-risk-analysis-question",
          payload
        )
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            let data = response["data"]["data"];
            this.note_txt = "";
            this.answer_txt = "";
            this.percentage_count = data.percentage_count;
            if (data.question_detail == null) {
              if (
                data.percentage_count.total_questions ==
                data.percentage_count.attempted_questions
              ) {
                this.completeSRA();
                this.$emit("toggle-loader", false);
                this.$emit("show-page", "completed_page");
              } else {
                this.$emit("toggle-loader", false);
                this.$emit("show-page");
                toastr.error('There is some technical issue. Please contact Abyde support!', "Error");
              }
            } else {
              this.question_detail = data.question_detail;
              if (data.has_previous) {
                this.has_previous = true;
              } else {
                this.has_previous = false;
              }
              if (
                this.question_detail.risk_analysis_attempted_question &&
                this.question_detail.risk_analysis_attempted_question.length >
                0
              ) {
                this.note_txt =
                  this.question_detail.risk_analysis_attempted_question[0].note;

                if (this.note_txt) {
                  this.has_comment = true;
                }

                given_note =
                  this.question_detail.risk_analysis_attempted_question[0]
                    .note;

                if (this.question_detail.question_answer_layout == "text") {
                  this.answer_txt =
                    this.question_detail.risk_analysis_attempted_question[0].attempted_question_answer[0].answer;
                  given_answer = this.answer_txt;
                } else if (
                  this.question_detail.question_answer_layout == "checkbox"
                ) {
                  this.selected_answers = _.map(
                    this.question_detail.risk_analysis_attempted_question[0]
                      .attempted_question_answer,
                    "answer_id"
                  );
                  given_answer = [...this.selected_answers];
                } else if (
                  this.question_detail.question_answer_layout == "radio"
                ) {
                  this.selected_answers =
                    this.question_detail.risk_analysis_attempted_question[0].attempted_question_answer[0].answer_id;
                  given_answer = this.selected_answers;
                }
              }
            }
            this.last_answer_data = {};
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.loaded = true;
          this.toggle_comment_box = false;
          this.is_btn_disabled = false;
          this.$emit("toggle-loader", false);
          this.is_full_page_loader_shown = false;
        });
    },
    loadPreviousQuestion() {
      this.pagination_type = "previous";
      this.loadQuestion(JSON.parse(JSON.stringify(given_answer)));
    },

    loadNextQuestion() {
      this.is_exit_pressed = false;
      this.pagination_type = "next";

      let check_ans_same;
      if (this.question_detail.question_answer_layout == "text") {
        check_ans_same = given_answer == this.answer_txt;
      } else if (this.question_detail.question_answer_layout != "text") {
        if (_.isArray(this.selected_answers)) {
          check_ans_same = _.isEqual(
            _.sortBy(this.selected_answers),
            _.sortBy(given_answer)
          );
        } else {
          check_ans_same = this.selected_answers == given_answer;
        }
      }

      if (
        given_answer == "" ||
        (given_answer != "" && (this.note_txt != given_note || !check_ans_same))
      ) {
        given_answer = "";
        this.saveAnswer(check_ans_same);
      } else {
        this.last_answer_data = {
          question_id: this.question_detail.id,
        };
        if (this.question_detail.question_answer_layout != "text") {
          this.last_answer_data.answer_id = this.selected_answers;
        }

        this.selected_answers = [];
        given_answer = "";

        this.loadQuestion();
      }
    },

    saveAndExit() {
      this.is_exit_pressed = true;
      let check_ans_same;
      if (this.question_detail.question_answer_layout == "text") {
        check_ans_same = given_answer == this.answer_txt;
      } else if (this.question_detail.question_answer_layout != "text") {
        if (_.isArray(this.selected_answers)) {
          check_ans_same = _.isEqual(
            _.sortBy(this.selected_answers),
            _.sortBy(given_answer)
          );
        } else {
          check_ans_same = this.selected_answers == given_answer;
        }
      }
      this.saveAnswer(check_ans_same);
    },

    toggleCommentBox() {
      if (this.toggle_comment_box) {
        this.toggle_comment_box = false;
        this.note_txt = "";
      } else {
        this.has_comment = false;
        this.toggle_comment_box = true;
      }
    },

    removeComment() {
      this.note_txt = "";
      this.has_comment = false;
    },

    saveAnswer(is_ans_same = true) {
      let payload = {
        location_id: this.selected_location.id,
        question_id: this.question_detail.id,
        is_ans_same: is_ans_same,
      };
      payload.note = this.note_txt;
      if (this.question_detail.question_answer_layout == "text") {
        if (this.answer_txt == "") {
          this.show_error = true;
        } else {
          payload.answer = this.answer_txt;
        }
      } else {
        if (this.selected_answers) {
          if (this.selected_answers.length <= 0) {
            this.show_error = true;
          } else {
            if (!Array.isArray(this.selected_answers)) {
              payload.answer_id = [this.selected_answers];
            } else {
              payload.answer_id = this.selected_answers;
            }
          }
        }
      }

      if (!this.show_error) {
        this.is_full_page_loader_shown = true;
        this.is_btn_disabled = true;
        axios
          .post(JS_APP_URL + "/security-risk-analysis/save-answer", payload)
          .then((response) => {
            if (response["data"]["status"] == "Success") {
              let data = response["data"]["data"];
              this.last_answer_data = data;
              this.selected_answers = [];
              this.note_txt = "";
              this.answer_txt = "";
              if (this.is_exit_pressed) {
                this.$emit("show-page");
              } else {
                this.loadQuestion();
              }
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            this.is_full_page_loader_shown = false;
            this.is_btn_disabled = false;
          });
      }
    },

    completeSRA() {
      this.is_btn_disabled = true;
      axios
        .get(
          JS_APP_URL +
          "/security-risk-analysis/complete-risk-analysis?location_id=" +
          this.selected_location.id
        )
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            let data = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_btn_disabled = false;
        });
    },
  },
};
</script>
