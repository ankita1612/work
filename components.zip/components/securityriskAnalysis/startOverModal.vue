<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
            <button v-on:click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb30 pt20">
                <img
                :src="JS_APP_URL + '/images/warning.svg'"
                alt=""
                title=""
                class="warning-icon-modal"
                />
            </div>
            <h2
                class="
                font-24 font_semibold
                blueog--text
                line-normal
                text-center
                mb20
                "
            >
                Whoa!
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">
                Are you sure you want to start over Security Risk Analysis? You
                will not be able to recover the answers you've saved.
            </p>
            <div class="flex flex-wrap items-center justify-center pb40">
                <button v-on:click="closeModal" class="btn-cancel-outline">
                NO
                </button>
                <button
                v-on:click="startOver"
                class="btn-primary mx5 px30 mt-xs-20"
                >
                YES
                </button>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";

export default {
  components: { closeIcon },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
    };
  },
  emits: ["close-model", "start-over"],
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
    startOver() {
      this.$emit("start-over");
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.closeModal()
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
