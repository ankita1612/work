import { createApp } from 'vue';
import securityRiskAnalysis from "./securityRiskAnalysis.vue";

import { useVuelidate } from '@vuelidate/core';
import FloatingVue from 'floating-vue'
import 'floating-vue/dist/style.css'
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import VueMask from '@devindex/vue-mask';

const app = createApp(securityRiskAnalysis);
app.use(VueMask);
app.component('multiselect', Multiselect);
app.use(FloatingVue);
app.use(useVuelidate);
app.mount("#sra_app");
