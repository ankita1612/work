<template>
    <div>
        <header-employee-portal></header-employee-portal>
            <div class="container pt30">
                <h1
                    class="
                    location-dashbaord-title
                    text-center
                    font-24 font_semibold
                    blueog--text
                    line-normal
                    mb35
                    mb-sm-10 mb-md-10
                    "
                >
                    Training
                </h1>
            </div>
            <div class="training-tabs-wrapper pb50">
                <div class="training-tab-nav">
                    <div class="container flex items-bottom flex-wrap justify-between">
                        <button
                            type="button"
                            @click="changeActivateTabs('reporting')"
                            class="training-tab-nav-item font-21"
                            :class="{ active: active_tab == 'reporting' }"
                        >
                            Reporting
                        </button>
                        <button
                            type="button"
                            @click="changeActivateTabs('available')"
                            class="training-tab-nav-item font-21 empportal-avai-tab-center"
                            :class="{ active: active_tab == 'available' }"
                        >
                            Available Training <span class="training-total-count">{{available_training_count_emp}}</span>
                        </button>
                        <button
                            type="button"
                            @click="changeActivateTabs('archived')"
                            class="training-tab-nav-item font-21"
                            :class="{ active: active_tab == 'archived' }"
                        >
                            Archived Training <span class="training-total-count">{{archived_training_count_emp}}</span>
                        </button>
                    </div>
                </div>
                <div class="training-tab-content pt40">
                    <!-- Reporting -->
                    <reporting 
                        v-if="active_tab == 'reporting'"
                    />
                    <!-- End -->

                    <!-- Available -->
                    <available 
                        v-if="active_tab == 'available'"
                        @set-training-count="setTrainingCounts"
                    />
                    <!-- End -->

                    <!-- Archived -->
                    <archived 
                        v-if="active_tab == 'archived'"
                    />
                    <!-- End -->
                </div>
            </div>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>

<script>
import fullPageLoader from "../../common/fullPageLoader.vue";
import noDataIcon from "../../common/icons/noDataIcon.vue";
import headerEmployeePortal from "../../common/includes/headerEmployeePortal.vue";
import available from "./available/available.vue"
import archived from "./archived/archived.vue"
import reporting from "./reporting/reporting.vue"

export default {
    data() {
        return {
            active_tab: "available",
            is_full_page_loader_shown:false,
            available_training_count_emp: 0,
            archived_training_count_emp: 0,
        }
    },
    components: {
        reporting,
        headerEmployeePortal,
        fullPageLoader,
        noDataIcon,
        available,
        archived,
    },
    methods: {
        changeActivateTabs(tab_name) {
            this.active_tab = tab_name;
        },
        setTrainingCounts(total_count)
        {                              
            this.available_training_count_emp = total_count.available_training_count_emp;
            this.archived_training_count_emp = total_count.archived_training_count_emp;                  
          
        } 
    },
}
</script>