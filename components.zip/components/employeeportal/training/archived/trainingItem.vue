<template>
  <div class="recommended-training-item relative pb10 mb32 flex">
    <div class="video-play-box recommended-video-thumb relative cursor-pointer mr16 no-allowed mt12" @click="PlayVideoModalToggle('yes')">
        <img
            :src="video_poster_file_url"
            alt=""
            title=""
            class="video-thumnail"
        />
        <img
            :src="JS_APP_URL + '/images/video-play.svg'"
            alt=""
            title=""
            class="play-icon"
        />
    </div>        
    
    <div class="employee-portal-training-center-box">
      <div class="training-left-top flex flex-wrap">          
        <div class="training-box-heading col-12 col-md-12 col-xl-6 self-center px10 py5">
          <h4 class="font-18 font_semibold blueog--text mb0 text-center">{{ parent_training.title_for_list }}</h4>            
        </div>
        <div class="training-box-tabs self-end flex-grow flex"  v-if="parent_training.child_training.length>0">    
          <button @click="fetchSubTrainingDetails(parent_training.id)" type="button" class="training-box-tab-item font-21 mr2 font_semibold" :class="(parent_training.id == active_training_id  ? 'active-archived' : 'inactive-archived')" >{{ parent_training.title_for_tab }}</button>
            <template v-for="child_training_data in parent_training.child_training">               
              <button @click="fetchSubTrainingDetails(child_training_data.id)" v-if="child_training_data.training_location.length > 0"  type="button" class="training-box-tab-item font-21 mr2 font_semibold" :class="(child_training_data.id == active_training_id  ? 'active-archived' : 'inactive-archived')" >{{child_training_data.title_for_tab}} </button>                  
              </template>                  
        </div>        
      </div>
      <p class="font-12 font_light gray2--text mb6 pt4 px10" v-html="training.description"></p>   
    </div>

    <div class="recommended-item-buttons col-md-3 col-lg-3 col-xl-3">    
        <div class="mb8"><span class="font-14 font_semibold blueog--text">Last Completion:</span> 
            <span class="font-14 font_light gray2--text" v-if="training.training_invite">{{$filters.formatDate(training.training_invite.completed_datetime)}}</span>
        </div>        
    </div>
    <play-video-modal
        v-if="play_video_modal == 'true'"
        :training="training"
        :video_file_url="video_file_url"
        :vtt_file_url="vtt_file_url"
        @close-model="PlayVideoModalToggle"
        @ended="videoEnded"
    ></play-video-modal>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script>
import axios from "axios";
import playVideoModal from "./playVideoModal.vue";
import fullPageLoader from "../../../common/fullPageLoader.vue";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            check_list_modal: false,
            play_video_modal: false,
            quiz_modal:false,
            is_training_completed:"",
            video_poster_file_url: null,
            video_file_url: null,
            vtt_file_url: null,
            training : this.parent_training,
            active_training_id: this.parent_training.id,
            training_parent_id: "",
            counter_for_create_sign_url:0 ,
            is_full_page_loader_shown: false,
        }
    },
    props: {
        parent_training: Object,
        employee_location_count:{}
    },
    components: {
        playVideoModal,
        fullPageLoader,
    },
    mounted() {
        if(this.training.training_invite && this.training.training_invite.ref_token == "" && this.training.training_invite.completed_datetime != null && this.training.training_invite.completed_attempt_id != null){
            this.is_training_completed = true
        }else{
            this.is_training_completed = false
        }
        this.createSignUrl(this.training.video_poster_file,'poster_file');
    },
    methods: {
        createSignUrl(file_name,file_type,file_time = 600){
            var request = {
                params: {
                    file_path: 'trainings/'+ this.training.id + '/' + file_name,
                    file_exp_time: file_time
                }
            }
            axios.get(JS_APP_URL + "/employeeportal/get-sign-url",request)
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    if(file_type == 'poster_file'){
                        this.video_poster_file_url = response.data.data;
                    }
                    if(file_type == 'video_file'){
                        this.video_file_url = response.data.data;
                    }
                    if(file_type == 'vtt_file'){
                        this.vtt_file_url = response.data.data;
                    }
                    this.counter_for_create_sign_url++;
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/employeeportal/login";
                }
            });
        },
        PlayVideoModalToggle(is_api_call = 'yes') {
            if (this.play_video_modal == "true") {
                this.play_video_modal = "false";
            } else {
                this.is_full_page_loader_shown = true;
                if(is_api_call ==  'yes'){
                    this.counter_for_create_sign_url = 0;
                    this.createSignUrl(this.training.video_file,'video_file', 3600);
                    this.createSignUrl(this.training.video_caption_file,'vtt_file');
                }
                setTimeout(() => {
                    if(this.vtt_file_url != null && this.counter_for_create_sign_url==2){
                        this.play_video_modal = "true";
                        this.is_full_page_loader_shown = false;
                    }else{
                        this.PlayVideoModalToggle('no');
                    }
                }, 200);
            }
        },
        videoEnded(){
            this.play_video_modal = "false";
        },
        startTraining() {
            window.location = JS_APP_URL + "/employeeportal/training-quiz/" + btoa(this.training.training_invite.id)
        },
        fetchSubTrainingDetails(training_id)
        {            
            //NProgress.start();
            this.active_training_id = training_id;
            this.is_full_page_loader_shown = true;
            axios.get(JS_APP_URL + "/employeeportal/training-detail-for-child-training?training_id="+training_id)
            .then((response) => {
                if (response["data"]["status"] == "Success") {                    
                    this.training = response.data.data.single_training.training;                                       
                    this.createSignUrl(this.training.video_poster_file,'poster_file');
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_WORDPRESS_URL;
                }
            }).then(()=>{
                this.is_full_page_loader_shown = false;
              //  NProgress.done();
            });
        }
    },
}
</script>