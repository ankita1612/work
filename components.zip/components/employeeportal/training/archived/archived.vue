<template>
    <div class="container">
        <taining-item
            v-for="training in trainings"
            :key="training.id"
            :parent_training="training.training"            
            :employee_location_count="employee_location_count"
        />
        <div v-if="!is_full_page_loader_shown && trainings.length === 0" class="">
            <div class="user-detail-text font-14 gray_checkmark--text text-center">
                <no-data-icon></no-data-icon>
                <div class="font-14 text-center blueog--text">
                    No archived training available.
                </div>
            </div>
        </div>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>

<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../../../common/fullPageLoader.vue";
import noDataIcon from "../../../common/icons/noDataIcon.vue";
import tainingItem from './trainingItem.vue';

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            JS_EMPLOYEE_DATA: JS_EMPLOYEE_DATA,
            is_full_page_loader_shown: false,
            trainings: {},
            employee_location_count:"",
        }
    },
    mounted() {
        this.getArchivedTraining();
    },
    components: {
        fullPageLoader,
        noDataIcon,
        tainingItem
    },
    methods: {
        getArchivedTraining() {
            this.is_full_page_loader_shown = true;
            const params = {
                employee_id: JS_EMPLOYEE_DATA.id,
            };
            axios.get(JS_APP_URL + "/employeeportal/get-archived-training", { params })
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    this.trainings = response.data.data.training_list;
                    this.employee_location_count = response.data.data.employee_location_count;
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_WORDPRESS_URL;
                }
            })
            .then(() => {
                this.is_full_page_loader_shown = false;
            });
        }
    }
}
</script>