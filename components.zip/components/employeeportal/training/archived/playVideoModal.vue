<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div
            class="modal-wrapper video-modal animate__animated animate__zoomIn"
        >
            <div class="modal-container Whoa-modal video-modal-container">
            <button @click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
                <video-player :options="videoOptions"
                @ended="onPlayerEnded()" />
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from "../../../common/icons/closeIcon.vue";
import VideoPlayer from "../../../training/available/VideoPlayer.vue"

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      videoOptions: {
        autoplay: true,
        controls: true,
        sources: [
          {
            src:
              this.video_file_url,
              type: 'video/mp4'
          }
        ],
        tracks: [
            {
                src: this.vtt_file_url,
                kind:'captions',
            }
        ]
      },
    };
  },
  emits: ["close-model", "ended"],
  components: {
    closeIcon,
    VideoPlayer,
  },
  props: {
    training: {},
    video_file_url:String,
    vtt_file_url:String,
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  },
  methods: {
    closeModal() {
      this.$emit("close-model");
    },
    onPlayerEnded(){
       this.$emit('ended');
    }
  },
};
</script>
<style>
  @import 'video.js/dist/video-js.css';
</style>
