<template>
    <div class="container">
        <training v-for="training in trainings" :key="training.id" 
            :parent_training="training" 
            @get-training-list-for-report="getTrainingListForReport" 
        />
        <div v-if="!is_full_page_loader_shown && trainings.length === 0" class="">
            <div class="user-detail-text font-14 gray_checkmark--text text-center">
                <no-data-icon></no-data-icon>
                <div class="font-14 text-center blueog--text">
                    No training available.
                </div>
            </div>
        </div>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>

<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../../../common/fullPageLoader.vue";
import training from "./training.vue";
import noDataIcon from "../../../common/icons/noDataIcon.vue";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            JS_EMPLOYEE_DATA: JS_EMPLOYEE_DATA,
            is_full_page_loader_shown: false,
            trainings: [],
        }
    },
    mounted() {
        this.getTrainingListForReport();
    },
    components: {
        fullPageLoader,
        training,
        noDataIcon
    },
    methods: {
        getTrainingListForReport() {
            this.is_full_page_loader_shown = true;
            const params = {
                employee_id: this.JS_EMPLOYEE_DATA.id,
            };
            axios.get(JS_APP_URL + "/employeeportal/training-list-for-report", { params })
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    this.trainings = response.data.data;
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_WORDPRESS_URL;
                }
            })
            .then(() => {
                this.is_full_page_loader_shown = false;
            });
        },
    },
}
</script>