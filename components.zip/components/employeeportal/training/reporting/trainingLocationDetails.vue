<template>
  <tr v-for="(invite, index) in training_invite" :key="index">
    <td :class="{'training-gray-text font-italic': location_type == 'secondary',}">
      {{ location.location_nickname }}
    </td>
    <td :class="{'training-gray-text font-italic': location_type == 'secondary',}">
        <span v-text="(invite.completed_datetime == '' || invite.completed_datetime == null) ? $filters.formatDate(invite.invite_datetime) : '-'"></span>
    </td>
     <td :class="{'training-gray-text font-italic': location_type == 'secondary',}">        
        <span v-text="(invite.completed_datetime != '' && invite.completed_datetime != null) ? $filters.formatDate(invite.completed_datetime) : '-'"></span>
    </td>
    <td :class="{'training-gray-text font-italic': location_type == 'secondary',}">
        {{ invite.reason }}
    </td>
    <td class="training-gray-text font-italic" v-if=" location_type == 'secondary'"> N/A </td>
    <td v-else>
      <div
        class="checkbox relative"
        v-if="invite.completed_datetime != null"
      >
        <input
          id="is_send_to_all_employee_option"
          name="is_send_to_all_employee_option"
          type="checkbox"
          checked
        />
        <label
          class="checkbox-label font-14 font-light gray_checkmark--text"
        ></label>
      </div>
       <span
        class="
          yellow--text
          font-14 font_semibold
          uppercase
        "
       v-else>Pending</span>  
    </td>
    <td class="training-gray-text font-italic" v-if=" location_type == 'secondary'"> 
      <span class="inline-flexc align-center items-center relative">
        N/A 
      </span>
    </td>
    <td v-else > 
      <span class="inline-flex align-center items-center relative">
        {{ invite.training_attempt_count }}       
        <VTooltip
          :triggers="['hover']"
          :popperTriggers="['hover']"
          style="height: 24px"
          class="cursor-pointer inline-block failed-training-info ml2"
          v-if="
            invite.completed_datetime == null &&
            invite.training_attempt_count > 0
          "
        >
          <a v-on:click="trainingAttemptFailedModalOpen(invite.id)" target="_blank"
            ><span><info-icon></info-icon></span
          ></a>
          <template #popper>Click here to view failed attempts</template>
        </VTooltip>
      </span>
    </td>
    <td>
       <span
        class="report-table-tag report-view-tag font-14 font_semibold uppercase"
        v-if="invite.completed_datetime != null"
        @click="viewCertificate(invite.id)"
        >View</span
      >
      <span
        v-else
        class="
          report-table-tag
          locked-pending-tag
          font-italic
          font-14 font_light
          uppercase
        "
        >Locked</span
      >
    </td>
    <certificate-modal
      v-if="certificate_modal"
      @close-model="certificateModalclose"
      :file_url="file_url"
      :invite_id="certificate_invite_id"
    />
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </tr>
</template>

<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import certificateModal from './certificateModal.vue';
import fullPageLoader from "../../../common/fullPageLoader.vue";
import infoIcon from "../../../common/icons/infoIcon.vue";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      certificate_invite_id: "",
      certificate_modal: false,
      is_full_page_loader_shown: false,
    };
  },
  emits: ["training-attempt-failed-popup"],
  props: {
    location: {},
    training_invite: {},
    training: {},
    location_type:{},
    training_invite_count:{}
  },
  components: {
    certificateModal,
    fullPageLoader,
    infoIcon,
  },
  mounted() {},
  methods: {
    trainingAttemptFailedModalOpen(invite_id) {
      this.is_full_page_loader_shown = true;
      let param = {
        invite_id: invite_id,
      };
      axios
        .post(JS_APP_URL + "/employeeportal/get-training-attempts-failed", param)
        .then((response) => {
          var training_attempt_failed_result = response["data"]["data"];
          this.$emit(
            "training-attempt-failed-popup",
            JS_EMPLOYEE_DATA.first_name,
            JS_EMPLOYEE_DATA.last_name,
            training_attempt_failed_result
          );
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_WORDPRESS_URL;
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        })
    },
    viewCertificate(invite_id) {
      this.is_full_page_loader_shown = true;
      let param = {
          location_id: this.location.id,
          invite_id: invite_id,
        };
      this.certificate_invite_id = invite_id;
     
      axios
        .post(JS_APP_URL + "/employeeportal/get-training-certificate", param)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.file_url = response.data.data;
            this.is_full_page_loader_shown = false;
            this.certificate_modal = true;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/employeeportal/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    certificateModalclose() {
      this.certificate_modal = false;
    },
  },
};
</script>

<style>
</style>