<template>
 <div class="report-training-item mb22">
    <div class="row -mx-10 items-center flex-auto pb0">
      <div class="training-box-heading col-12 col-md-12 col-xl-6 self-center px10 py5">
        <h4 class="font-18 font_semibold blueog--text mb0 text-left">{{ parent_training.training.title_for_list }}</h4>
      </div>      
      <div class="training-box-tabs self-end flex-grow flex"  v-if="parent_training.training.child_training.length>0">    
        <button @click="parent_training.training_invite_count==0 ? '' : fetchSubTrainingDetails(parent_training.training.id)" type="button" class="training-box-tab-item font-21 mr2 font_semibold" :class="(parent_training.training_invite_count==0 ? 'inactive-disabled':(parent_training.training_id == active_training_id && parent_training.training_invite_complete_count == parent_training.training_invite_count ? 'active-archived' : (parent_training.training_id != active_training_id && parent_training.training_invite_complete_count == parent_training.training_invite_count ? 'inactive-archived' : (parent_training.training_id == active_training_id && parent_training.training_invite_complete_count != parent_training.training_invite_count ?'active-unarchived':'inactive-unarchived'))))" >{{ parent_training.training.title_for_tab }}</button>   
        <template v-for="child_training_data in parent_training.training.child_training">                    
            <button @click="parent_training.child_calculation[child_training_data.id].training_invite_count ==0 ? '' :fetchSubTrainingDetails(child_training_data.id)" v-if="child_training_data.training_location.length > 0"  type="button" class="training-box-tab-item font-21 mr2 font_semibold"  :class="(parent_training.child_calculation[child_training_data.id].training_invite_count ==0 ? 'inactive-disabled':(child_training_data.id == active_training_id && parent_training.child_calculation[child_training_data.id].training_invite_incomplete == parent_training.child_calculation[child_training_data.id].training_invite_count ? 'active-archived' : (child_training_data.id != active_training_id && parent_training.child_calculation[child_training_data.id].training_invite_incomplete == parent_training.child_calculation[child_training_data.id].training_invite_count ?'inactive-archived' : (child_training_data.id == active_training_id && parent_training.child_calculation[child_training_data.id].training_invite_incomplete != parent_training.child_calculation[child_training_data.id].training_invite_count  ?'active-unarchived':'inactive-unarchived'))))" >{{child_training_data.title_for_tab}} </button>                  
        </template>                  
      </div>        
    </div>  
    <div class="table-responsive scrollbar-style pb10">
            <table class="report-training-table" border="0" cellpadding="5" cellspacing="6">
                <thead>
                    <tr>
                        <th>Locations</th>
                        <th>Last Date Sent</th>
                        <th>Completion Date</th> 
                        <th>Reason</th>
                        <th>Video/Quiz</th>
                        <th>Attempts</th>
                        <th>Certificate</th>
                    </tr>
                </thead>
                <training-location-details
                    v-if="training.location"
                    :location="training.location"
                    :training_invite="training.training_invites"
                    :training="training.training"
                    :location_type="'primary'"
                    :training_invite_count="training.training_invite_count"
                    @training-attempt-failed-popup="trainingAttemptFailedModalToggle"
                />
                <training-location-details
                    v-for="location in training.SecondaryWorkLocation" :key="location.id"
                    :location="location.location"
                    :training_invite="training.training_invites"
                    :training="training.training"
                    :location_type="'secondary'"
                    :training_invite_count="training.training_invite_count"
                    @training-attempt-failed-popup="trainingAttemptFailedModalToggle"
                />
                <div v-if="training.length === 0" class="">
                    <div class="user-detail-text font-14 gray_checkmark--text text-center">
                        <no-data-icon></no-data-icon>
                        <div class="font-14 text-center blueog--text">
                            No Employee available.
                        </div>
                    </div>
                </div>
            </table>
        </div>
        <training-attempt-failed
            :first_name="first_name"
            :last_name="last_name"
            :training_name="training.training.title"
            :training_attempt_failed_result="training_attempt_failed_result"
            @close-model="trainingAttemptFailedModalToggle"
            v-if="training_attempt_failed_modal"
        />
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script>
import trainingLocationDetails from "./trainingLocationDetails.vue";
import fullPageLoader from "../../../common/fullPageLoader.vue";
import noDataIcon from "../../../common/icons/noDataIcon.vue";
import trainingAttemptFailed from "../../../training/failedAttemptModal.vue";
import axios from "axios";
export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            is_full_page_loader_shown: false,
            training_attempt_failed_modal: false,
            training_attempt_failed_result: [],
            training : this.parent_training,
            active_training_id: this.parent_training.training_id,
        }
    },
    props: {
        parent_training: {},
    },
    components:{
        trainingLocationDetails,
        noDataIcon,
        fullPageLoader,
        trainingAttemptFailed,
    },
    mounted() {        
       if(this.parent_training.active_training != this.parent_training.training_id){
            this.fetchSubTrainingDetails(this.parent_training.active_training)
        }
    },
    methods: {
        trainingAttemptFailedModalToggle(first_name, last_name, training_attempt_failed_result) {
            if (this.training_attempt_failed_modal == true) {
                this.training_attempt_failed_modal = false;
            } else {
                this.first_name = first_name;
                this.last_name = last_name;
                this.training_attempt_failed_result = training_attempt_failed_result;
                this.training_attempt_failed_modal = true;
            }
        },
        fetchSubTrainingDetails(training_id)
        {            
            //NProgress.start();
            this.active_training_id = training_id;
            this.is_full_page_loader_shown = true;
            axios.get(JS_APP_URL + "/employeeportal/training-report-for-child-training?training_id="+training_id)
            .then((response) => {
                if (response["data"]["status"] == "Success") {                    
                    this.training = response.data.data.single_training;                                                          
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                 if (error.response.status === 401) {
                    window.location = JS_WORDPRESS_URL;
                 }
            }).then(()=>{
                this.is_full_page_loader_shown = false;
            });
         }
    }
}
</script>
