<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask pdf-modal-mask">
        <div class="pdf-modal-overlay"></div>
        <div class="modal-wrapper pdf-view-modal animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
            <button @click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
            <iframe :src="JS_APP_URL+'/pdfjs/web/viewer.html?file='+file_url" width="960" height="550"></iframe>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";
import closeIcon from "../../../common/icons/closeIcon.vue";

export default {
  components:{closeIcon},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
    };
  },
  emits: ["close-model"],
  props:{
   file_url:{},
   invite_id:{}
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  },
  methods: {
    closeModal(){
      this.$emit('close-model');
    }
  },
};
</script>
