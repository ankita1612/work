import { createApp } from 'vue';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import moment from 'moment'
import training from './training.vue'

const app = createApp(training)
app.config.globalProperties.$filters = {
    formatDate(value) {
        if (value) {
            return moment.utc(String(value)).local().format('MM/DD/YYYY')
        }
    }
};
app.use(FloatingVue);
app.component('multiselect', Multiselect);
app.mount("#employee_potal_training_app")
