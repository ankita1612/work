<template>
<div>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
            <button v-on:click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb15 pt20">
                <img :src="JS_APP_URL + '/images/hco-badge.svg'" alt="" title="" class="warning-icon-modal" />
            </div>
            <h2
                class="
                font-24 font_semibold blueog--text line-normal text-center mb20
                "
            >
                Your HIPAA Compliance Officer(s)
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal">Have a question or in need of some assistance?</p>
            <p class="text-center font-16 gray_checkmark--text line-normal">Reach out to your HIPAA Compliance Officer for help!</p>

            <div v-for="hco in JS_EMPLOYEE_DATA.hco_list" :key="hco.id" class="mt20">
                <p class="font-20 font_semibold gray_checkmark--text line-normal word-wrap"><span class="" :title="hco.location.location_nickname">{{ hco.location.location_nickname }}</span>: {{hco.hco.first_name}} {{hco.hco.last_name}}</p>
                <a :href="'mailto:'+hco.hco.email" class="font-18 line-normal green--text hover-underline-animation word-break">{{hco.hco.email}}</a>
            </div>
            <div v-if="JS_EMPLOYEE_DATA.hco_list.length == 0" class="mt20">
                <p class="font-14 font-italic font_semiBold text-red line-normal">Sorry, We have not found HIPAA Compliance Officer for your location(s).</p>
            </div>
            <div class="pb30"></div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
      <div class="modal-backdrop"></div>
</div>
</template>

<script scoped>
import closeIcon from '../../common/icons/closeIcon.vue';

export default {
  props: {
    JS_EMPLOYEE_DATA:{
        type: Object,
        default: () => {}
    }
  },
  components: { closeIcon },
  emits: ["close-model"],
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
    };
  },
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    }
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", false);
      }
    });
  },
    destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
