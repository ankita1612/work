import { createApp } from 'vue';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import VueMask from '@devindex/vue-mask';
import dashboard from "./dashboard.vue";

const app = createApp(dashboard)
app.use(VueMask)
app.use(FloatingVue)
app.component('multiselect', Multiselect)
app.mount("#employee_potal_dashboard_app")
