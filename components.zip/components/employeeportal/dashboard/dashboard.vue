<template>
  <div>
    <header-employee-portal></header-employee-portal>
    <div class="font-22 font_light blueog--text mt40 text-center">
      Welcome to Your
    </div>
    <div class="flex items-center justify-center flex-wrap ">
      <div class="font-24 font_semibold blueog--text mb40 text-center">
        Abyde Employee Portal
      </div>
      <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml6 mb40 mb-md-50 mb-sm-40">
            <button @click="PlayExplainerVideoModalToggle('yes')" class="cursor-pointer svg-icon-height dashboard-video-icon mt4">
              <explainer-video-icon></explainer-video-icon>
            </button>
            <template #popper>
              Video Guide
            </template>
      </VTooltip>
    </div>
    <div class="container pb40">
        <div class="employee-portal-locations">
          <div class="employee-portal-locations-items pb13 mb13">
            <div class="row flex-auto -mx-10 items-center">
              <div class="col-12 col-md-9 col-lg-10 col-xl-10 px10 mb-sm-10 employee-portal-table-left">
                  <span class="font-18 font_semibold blueog--text employee-portal-table-title mr15">Location</span>
                  <span class="font-12 gray_checkmark--text font-italic">Just in case you forgot where you go to work everyday</span>
              </div>     
              <div class="col-12 col-md-3 col-lg-2 col-xl-2 px10 text-center">
                  <div class="flex items-center justify-center">
                    <span v-if="JS_EMPLOYEE_DATA.employee_primary_work_location.location_nickname" class="font-14 font_semibold blue--text mr10 word-break text-truncate white-no-wrap tuncate-location-width" :title="JS_EMPLOYEE_DATA.employee_primary_work_location.location_nickname" v-text="JS_EMPLOYEE_DATA.employee_primary_work_location.location_nickname"></span>
                    <VTooltip v-if="JS_EMPLOYEE_DATA.employee_secondary_work_location.length > 0" :triggers="['hover']"  :popperTriggers="['hover']" style="height: 24px;" class="cursor-pointer location-hq-icon">
                    <span><img :src="JS_APP_URL +'/images/location.svg'" alt="" title=""></span>
                      <template #popper>
                        <div class="text-center line-normal">
                          <div class="font_semibold line-normal mb5 pb5 pt5">Additional Work Location(s)</div>
                          <div  class="seperator-line pt3 pb3" v-for="loc in JS_EMPLOYEE_DATA.employee_secondary_work_location" :key="loc.location.id">
                            {{loc.location.location_nickname}}
                          </div>
                        </div>
                      </template>
                    </VTooltip>                      
                  </div>
              </div>                        
            </div>
          </div>
          <div class="employee-portal-locations-items pb13 mb13">
            <div class="row flex-auto -mx-10 items-center">
              <div class="col-12 col-md-9 col-lg-10 col-xl-10 px10 mb-sm-10 employee-portal-table-left">
                  <span class="font-18 font_semibold blueog--text employee-portal-table-title mr15 cursor-pointer" v-on:click="hcoDetailModaltoggle">HIPAA Compliance Officer(s)</span>
                  <span class="font-12 gray_checkmark--text font-italic">Name and contact information for your facility’s HCO</span>
              </div>   
              <div class="col-12 col-md-3 col-lg-2 col-xl-2 px10 text-center">
                <button type="button" class="btn-blue btn-hipaa-officer fill-width" v-on:click="hcoDetailModaltoggle" :title="getHCODetails()">{{getHCODetails()}}</button>
              </div>
            </div>
          </div>      
          <div class="employee-portal-locations-items pb13 mb13">
            <div class="row flex-auto -mx-10 items-center">
              <div class="col-12 col-md-9 col-lg-10 col-xl-10 px10 mb-sm-10 employee-portal-table-left">
                  <a :href="(JS_EMPLOYEE_DATA.is_policy_module_enable == 'no')?'javascript:void(0);':JS_APP_URL+'/employeeportal/procedures-policies-forms'"><span class="font-18 font_semibold blueog--text employee-portal-table-title mr15" :class="{'text-locked' : JS_EMPLOYEE_DATA.is_policy_module_enable == 'no'}">Policies &amp; Procedures</span></a>
                  <span class="font-12 gray_checkmark--text font-italic" :class="{'text-locked' : JS_EMPLOYEE_DATA.is_policy_module_enable == 'no'}">Your organization’s HIPAA playbook</span>
              </div>
              <div class="col-12 col-md-3 col-lg-2 col-xl-2 px10 text-center">
                <a :href="(JS_EMPLOYEE_DATA.is_policy_module_enable == 'no')?'javascript:void(0);':JS_APP_URL+'/employeeportal/procedures-policies-forms'">
                  <img :src="JS_APP_URL +'/images/files.svg'" alt="" title="" :class="{'img-locked' : JS_EMPLOYEE_DATA.is_policy_module_enable == 'no'}">
                </a>
              </div>                        
            </div>
          </div>  
          <div class="employee-portal-locations-items pb13 mb13">
            <div class="row flex-auto -mx-10 items-center">
              <div class="col-12 col-md-9 col-lg-10 col-xl-10 px10 mb-sm-10 employee-portal-table-left">
                  <a :href="(JS_EMPLOYEE_DATA.is_training_module_enable == 'no')?'javascript:void(0);':JS_APP_URL + '/employeeportal/training'"><span class="font-18 font_semibold blueog--text employee-portal-table-title mr15" :class="{'text-locked' : JS_EMPLOYEE_DATA.is_training_module_enable == 'no'}">HIPAA Training</span></a>
                  <span class="font-12 gray_checkmark--text font-italic" :class="{'text-locked' : JS_EMPLOYEE_DATA.is_training_module_enable == 'no'}">Complete required HIPAA training and view certificates of completion</span>
              </div> 
              <div class="col-12 col-md-3 col-lg-2 col-xl-2 px10 text-center">
                <button type="button" class="cursor-pointer">
                  <a :href="(JS_EMPLOYEE_DATA.is_training_module_enable == 'no')?'javascript:void(0);':JS_APP_URL + '/employeeportal/training'">
                  <img :src="JS_APP_URL +'/images/book-active.svg'" alt="" title="" :class="{'img-locked' : JS_EMPLOYEE_DATA.is_training_module_enable == 'no'}">
                  </a>
                </button>
              </div>                        
            </div>
          </div>                                                    

        </div>

    </div>
    <hco-detail-modal
    v-if="is_hco_detail_modal_shown"
    :JS_EMPLOYEE_DATA="JS_EMPLOYEE_DATA"
    @close-model="hcoDetailModaltoggle"
    ></hco-detail-modal>
    <play-explainer-video-modal v-if="play_video_modal == true" :video_file="video_file"
      :video_caption_file="video_caption_file" @close-model="PlayExplainerVideoModalToggle" user_type="employeeportal"></play-explainer-video-modal>
  </div>
</template>

<script scoped>
import toastr from "toastr";
import axios from "axios";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import headerEmployeePortal from '../../common/includes/headerEmployeePortal.vue';
import hcoDetailModal from "./hcoDetailsModal.vue";
import explainerVideoIcon from "../../common/icons/explainerVideoIcon.vue";
import playExplainerVideoModal from "../../common/includes/playExplainerVideoModal.vue";

export default {
  data() {
    return {
      JS_EMPLOYEE_DATA: JS_EMPLOYEE_DATA,
		  JS_APP_URL: JS_APP_URL,
      is_hco_detail_modal_shown: false,
      video_file: "hce_explainer_employee_portal_dashboard_final.mp4",  
      video_caption_file: "hce_explainer_employee_portal_dashboard_final.vtt",  
      play_video_modal: false,
    };
  },
  components: {
    headerEmployeePortal,
    hcoDetailModal,
    explainerVideoIcon,
    playExplainerVideoModal
  },
  methods: {
    PlayExplainerVideoModalToggle() {
      if (this.play_video_modal == true) {
        this.play_video_modal = false;
      } else {
        this.play_video_modal = true;
      }
    },
    getHCODetails(){
      if(JS_EMPLOYEE_DATA.hco_list.length > 0){
        return (JS_EMPLOYEE_DATA.hco_list.length > 1)?JS_EMPLOYEE_DATA.hco_list.length:JS_EMPLOYEE_DATA.hco_list[0].hco.first_name;
      }else{
        return 0;
      }      
    },
    hcoDetailModaltoggle(status = true){
      this.is_hco_detail_modal_shown = status;
    }
  },
};
</script>
