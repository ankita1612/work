<template>
<div>
    <header-employee-portal></header-employee-portal>
    <div class="container pt30">
      <div class="flex justify-center flex-wrap mb32 relative" v-if="all_location_list.length > 1">
        <div class="col-12 col-sm-8 col-md-8 col-lg-6 col-xl-3">
          <div class="form-group mb-0 location-dropdon mlr-auto">
              <multiselect
                class="company-location-select"
                v-model="selected_location"
                :options="all_location_list"
                label="location_nickname"
                :taggable="false"
                :multiple="false"
                :close-on-select="true"
                :showLabels="false"
                track-by="id"
                placeholder=""
                :allowEmpty="false"
                @update:model-value="onChangeLocation"
              >
                <template #noResult>
                  <div class="multiselect__noResult text-center">
                    No results found
                  </div>
                </template>
              </multiselect>
              <label class="label label-select label-float" >Location</label>
          </div>
        </div>
      </div>
      <div class="flex items-center justify-center flex-wrap">
        <h1 class="
            location-dashbaord-title
            text-center
            font-24 font_semibold
            blueog--text
            line-normal
            mb25
            mb-sm-10 mb-md-10
          ">
          Policies and Procedures
        </h1>
        <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml6 mb25 mb-md-10 mb-sm-10">
              <button @click="PlayExplainerVideoModalToggle('yes')" class="cursor-pointer svg-icon-height dashboard-video-icon mt4">
                <explainer-video-icon></explainer-video-icon>
              </button>
              <template #popper>
                Video Guide
              </template>
        </VTooltip>
      </div>
    </div>
    <div class="training-tabs-wrapper">
      <div class="training-tab-nav">
        <div class="container flex items-center justify-between flex-wrap">
          <button v-on:click="changeTab('procedure')" type="button" class="training-tab-nav-item font-21 mr2" :class="{ active: (policy_tab == 'procedure') }">
            Procedures                                                   
          </button>
          <button v-on:click="changeTab('policy')"  type="button" class="training-tab-nav-item sharp-tab-item font-21" :class="{ active: (policy_tab == 'policy') }">
            Policies                                                         
          </button>          
          <button v-on:click="changeTab('form')"  type="button" class="training-tab-nav-item sharp-tab-item font-21" :class="{ active: (policy_tab == 'form') }">
            Forms
          </button>
        </div>
      </div>
    </div>
    <div class="training-tab-content pt20 pb50">
        <div class="container">
          <div class="flex justify-end mb20">
            <div class="col-12 col-md-4 col-lg-3 col-xl-2 px0">
                <input
                  class="form-input form-input-search"
                  v-model.trim="search_query"
                  id="search"
                  type="text"
                  @input="applySearch()"
                />
                <label
                  class="label font-italic"
                  :class="{ 'label-float': search_query }"
                  >Search</label
                >
                <div class="search-btn-input">
                  <img
                    :src="JS_APP_URL + '/images/search.svg'"
                    alt=""
                    title=""
                  />
                </div>
              </div>
          </div>
          <div v-for="policy in policy_list.policy" :key="policy.id">
          <div class="user-detail-card py10 px15 light mb10 relative" :class="{'policies-item-disable': policy.is_disabled}">
            <div class="row flex-auto -mx-10 items-center">
              <div class="col-12 col-md-8 col-lg-5 col-xl-6 px10 mb-md-10">
                <div class="flex items-center flex-wrap">
                  <div class="font-16 font_semibold gray2--text">
                    {{policy.title}}
                  </div>
                  <VTooltip :triggers="['hover']" :popperTriggers="['hover']" style="height: 20px;"
                    class="cursor-pointer ml10">
                    <span><info-icon></info-icon></span>
                    <template #popper>
                      {{policy.doc_description}}
                    </template>
                  </VTooltip>
                  <VTooltip :triggers="['hover']" :popperTriggers="['hover']" style="height: 22px;"
                  class="cursor-pointer ml8" v-if="policy.has_spanish">
                  <span>
                    <button type="button" class="cursor-pointer px0">
                      <img :src="JS_APP_URL + '/images/checkmark-blue.svg'" alt="" title="" />
                    </button>
                  </span>
                  <template #popper>
                    {{policy.doc_eye_description}}
                  </template>
                </VTooltip>
                <VTooltip :triggers="['hover']" :popperTriggers="['hover']" theme="red-tooltip" style="height: 22px;"
                  class="cursor-pointer ml8" v-if="policy.doc_warning_description">
                  <span>
                    <button type="button" class="cursor-pointer px0">
                      <img :src="JS_APP_URL + '/images/info-red.svg'" alt="" title="" />
                    </button>
                  </span>
                  <template #popper>
                    <p class="info-red-tooltip">{{policy.doc_warning_description}}</p>
                  </template>
                </VTooltip>
                  <button type="button" class="policies-history-icon cursor-pointer ml5" style="height: 20px;" @click="policyHistory(policy.id)" v-if="policy.policy_versioning.length > 0" :disabled="policy.is_disabled">
                    <img :src="JS_APP_URL + '/images/history.svg'" alt="" title="" />
                  </button>
                </div>
              </div>
              <div class="col-12 col-md-4 col-lg-3 col-xl-2 px10 mb-md-10">
                <span class="font-10 gray_checkmark--text font-italic margin-4-right-txt" v-if="!policy.is_disabled">Last Updated:</span>
                <span class="font-12 font_semibold blueog--text" v-if="!policy.is_disabled">{{ $filters.formatDate(lastUpdateDate(policy))}}</span>
              </div>
              <div class="col-12 col-md-6 col-lg-4 col-xl-4 px10 inline-flex items-center justify-end policies-item-button" v-if="policy.has_spanish">
              <div class="flex policies-lan-buttons" :class="{'policies-npp-btn' : policy.code !== 'NPP'}">
                <div class="ml5 policies-lan-btn" v-if="policy.code == 'NPP'">
                  <button class="btn-blue-outline btn-left-padding btn-left-white btn-focus-issue mb4 full-width" :disabled="policy.is_disabled"
                  @click="generateNppPolicy(policy, 'english')">
                    <div class="next-arrow-icon">
                      <img :src="JS_APP_URL + '/images/open-link-icon.svg'" alt="" title="" />
                    </div>
                    <span>ENGLISH</span>
                  </button>
                  <button class="btn-blue-outline btn-left-padding btn-left-white btn-focus-issue mb4 full-width" :disabled="policy.is_disabled"
                  @click="generateNppPolicy(policy, 'spanish')">
                    <div class="next-arrow-icon">
                      <img :src="JS_APP_URL + '/images/open-link-icon.svg'" alt="" title="" />
                    </div>
                    <span>SPANISH</span>
                  </button>
                </div>
                <div class="ml5">
                  <button class="btn-blue-outline btn-left-padding btn-left-white btn-focus-issue mb4 full-width" :disabled="policy.is_disabled" v-on:click="downloadPolicy(policy)">
                    <div class="next-arrow-icon pdf-icon"> <pdf-icon></pdf-icon></div> <span>ENGLISH</span>
                  </button>
                  <button class="btn-blue-outline btn-left-padding btn-left-white btn-focus-issue full-width" :disabled="policy.is_disabled" v-on:click="downloadPolicy(policy, 'spanish')">
                    <div class="next-arrow-icon pdf-icon"> <pdf-icon></pdf-icon></div> <span>SPANISH</span>
                  </button>
                </div>
              </div>
            </div>
              <div
                class="col-12 col-md-6 col-lg-4 col-xl-4 px10 inline-flex items-center justify-end policies-item-button" v-else>
                <button class="btn-blue-outline btn-left-padding btn-left-white btn-focus-issue" :disabled="policy.is_disabled" v-on:click="downloadPolicy(policy)">
                  <div class="next-arrow-icon pdf-icon"> <pdf-icon></pdf-icon></div> <span>DOWNLOAD</span>
                </button>
              </div>
            </div>
          </div>
          <policy-history     
              v-if="policy.id == policy_id_for_history"
              :policy_versions="policy.policy_versioning"  
              :policy_title="policy.title"
              :has_spanish="policy.has_spanish"
              :module_complete_date="policy.module_complete_date ? policy.module_complete_date : policy_list.module_complete_date"
            />
        </div>
          <div v-if="!is_full_page_loader_shown && policy_list.policy.length === 0">
            <div class="user-detail-text font-14 gray_checkmark--text text-center">
              <no-data-icon></no-data-icon>
              <div class="font-14 text-center blueog--text">No {{(policy_tab == 'policy')?'policies':policy_tab+'s'}} available.</div>
            </div>
          </div>                                   
        </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    <play-explainer-video-modal v-if="play_video_modal == true" :video_file="video_file"
      :video_caption_file="video_caption_file" @close-model="PlayExplainerVideoModalToggle" user_type="employeeportal"></play-explainer-video-modal>
</div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../../common/fullPageLoader.vue";
import headerEmployeePortal from "../../common/includes/headerEmployeePortal.vue";
import pdfIcon from "../../common/icons/pdfIcon.vue";
import noDataIcon from '../../common/icons/noDataIcon.vue';
import infoIcon from "../../common/icons/infoIcon.vue";
import policyHistory from '../policy/policyHistory.vue';
import explainerVideoIcon from "../../common/icons/explainerVideoIcon.vue";
import playExplainerVideoModal from "../../common/includes/playExplainerVideoModal.vue";

export default {
  data() {
    return {
      JS_EMPLOYEE_DATA: JS_EMPLOYEE_DATA,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      selected_location: {},
      is_full_page_loader_shown: true,
      search_query: "",
      policy_tab: "procedure",
      all_location_list: [],
      policy_list: [],
      timer: null,
      policy_id_for_history: null,
      video_file: "hce_explainer_employee_portal_policy_final.mp4",  
      video_caption_file: "hce_explainer_employee_portal_policy_final.vtt",  
      play_video_modal: false,
    };
  },
  components: {
    headerEmployeePortal,
    fullPageLoader,
    pdfIcon,
    noDataIcon,
    infoIcon,
    policyHistory,
    explainerVideoIcon,
    playExplainerVideoModal
  },
  mounted() {
    this.all_location_list = this.JS_EMPLOYEE_DATA.location_list
    this.selected_location = this.JS_EMPLOYEE_DATA.location_list[0]
    setTimeout(() => {
        this.loadPolicyList()
    }, 100);
  },
  watch: {
  },
  computed: {},
  methods: {
    PlayExplainerVideoModalToggle() {
      if (this.play_video_modal == true) {
        this.play_video_modal = false;
      } else {
        this.play_video_modal = true;
      }
    },
    applySearch(){
       if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      this.timer = setTimeout(() => {
        this.loadPolicyList()
      }, 500);
    },
    loadPolicyList(){
      this.is_full_page_loader_shown = true;
      axios
          .post(JS_APP_URL + "/employeeportal/get-policy-list", {
            type: this.policy_tab,
            search_query: this.search_query,
            location_id: this.selected_location.id,
            source: 'employee_portal'
          })
          .then((response)  => {
            if (response["data"]["status"] == "Success") {
              this.policy_list =  response["data"]["data"];
            }else{
              if(response["data"]["message"] == "Complete DRP first") {
                toastr.error("Contact respective location's HIPAA Compliance Officer for more details.", "Error");
                setTimeout(() => {
                  window.location = JS_APP_URL + "/employeeportal/dashboard";
                }, 1000);
              }else{
                if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
              }
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_WORDPRESS_URL;
            }
          })
          .then(() => {
            setTimeout(() => {
              this.is_full_page_loader_shown = false;
            }, 100);
          });
    },
    downloadPolicy(policy, lang = 'english'){
      this.is_full_page_loader_shown = true;
      axios
          .post(JS_APP_URL + "/employeeportal/download-policy", {
            policy_id: policy.id,
            location_id: this.selected_location.id,
            lang: lang,
            effective_date_text: 'Last Updated: '+ this.$filters.formatDate(this.lastUpdateDate(policy))
          })
          .then((response)  => {
            if (response["data"]["status"] == "Success") {
              var link = document.createElement("a");
              link.setAttribute("href", response["data"]['data']['download_url']);
              link.setAttribute("download", response["data"]['data']['file_name']);
              link.setAttribute("target", '_blank');
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_WORDPRESS_URL;
            }
          })
          .then(() => {
            setTimeout(() => {
              this.is_full_page_loader_shown = false;
            }, 100);
          });
    },
    generateNppPolicy(policy, lang = 'english') {
      let url = JS_APP_URL + '/policy-url/notice-privacy-practices/' + this.encryption(policy.id) + '/' + this.encryption(this.selected_location.id)
      if(lang == 'spanish') {
        url += '/spanish'
      }
      window.open(url, '_blank').focus();
    },
    encryption(params) {
      var encoded = btoa(params);
      return encoded;
    },
    policyHistory(policyId) {
      if(policyId == this.policy_id_for_history){
        this.policy_id_for_history = null;
      }else{
        this.policy_id_for_history = policyId;
      }
      
    },
    lastUpdateDate(policy){
      let policy_verioning_count = policy.policy_versioning.length
      if(policy_verioning_count == 0){
        if (policy.module_complete_date){
          return policy.module_complete_date
        }else{
          return this.policy_list.module_complete_date
        }
      }else{
        return policy.policy_versioning[0].created_at
      }
    },
    changeTab(tab_type){
      if (this.policy_tab != tab_type) {
        this.policy_id_for_history = null;
      }
      this.policy_tab = tab_type;
      this.search_query = "";
      this.loadPolicyList();
    },
    onChangeLocation(){
      this.policy_tab = 'procedure';
      this.search_query = "";
      this.loadPolicyList();
    }
  },
};
</script>
