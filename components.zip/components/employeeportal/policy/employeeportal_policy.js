import { createApp } from 'vue';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import moment from 'moment'
import policy from "./policy.vue";

const app = createApp(policy)
app.use(FloatingVue, {
    themes: {
        'red-tooltip': {
          $extend: 'tooltip',
          $resetCss: true,
        },
}});
app.config.globalProperties.$filters = {
    formatDate(value) {
        if (value) {
            return moment.utc(String(value)).local().format('MM/DD/YYYY');
        }
    }
};
app.component('multiselect', Multiselect);
app.mount("#employee_potal_policy_app")
