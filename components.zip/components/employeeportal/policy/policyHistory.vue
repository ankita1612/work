<template>
  <div>
    <div
      class="policies-sub-item py10 px15 white mb10 relative"
      v-for="(policy, index) in policy_versions"
      :key="index"
    >
      <div class="row flex-auto -mx-10 items-center">
        <div class="col-12 col-md-6 col-lg-5 col-xl-5 px10 mb-md-10">
          <div class="flex items-center flex-wrap">
            <div class="font-16 font_semibold gray2--text">
              {{ policy_title }}
            </div>
          </div>
        </div>
        <div
          class="col-12 col-md-6 col-lg-3 col-xl-5 px10 mb-md-10 policies-sub-date-column"
          v-if="index + 1 != policy_versions.length"
        >
          <span class="font-10 gray_checkmark--text font-italic margin-4-right-txt">Effective:</span>
          <span
            class="font-12 font_semibold blueog--text"
            v-if="index + 2 != policy_versions.length"
          >
            {{ $filters.formatDate(policy_versions[index + 1].created_at) }} -
            {{ $filters.formatDate(policy.created_at) }}</span
          >
          <span class="font-12 font_semibold blueog--text" v-else>
            {{ $filters.formatDate(module_complete_date) }} -
            {{ $filters.formatDate(policy.created_at) }}</span
          >
        </div>
        <div class="col-12 col-md-6 col-lg-3 col-xl-5 px10 mb-md-10 policies-sub-date-column" v-else>
          <span class="font-10 gray_checkmark--text font-italic margin-4-right-txt">Last Effective:</span>
          <span class="font-12 font_semibold blueog--text">{{
            $filters.formatDate(module_complete_date)
          }}</span>
        </div>
        <div
          class="col-12 col-md-6 col-lg-4 col-xl-2 px10 inline-flex items-center justify-end policies-item-button"
          v-if="has_spanish"
        >
          <div
            class="flex policies-lan-buttons policies-npp-btn"
          >
            <div class="ml5">
              <button
                class="btn-blue-outline btn-left-padding btn-left-white btn-focus-issue mb4 full-width"
                v-on:click="downloadPolicy(policy, index)"
              >
                <div class="next-arrow-icon pdf-icon"><pdf-icon></pdf-icon></div>
                <span>ENGLISH</span>
              </button>
              <button
                class="btn-blue-outline btn-left-padding btn-left-white btn-focus-issue full-width"
                v-on:click="downloadPolicy(policy, index, 'spanish')"
              >
                <div class="next-arrow-icon pdf-icon"><pdf-icon></pdf-icon></div>
                <span>SPANISH</span>
              </button>
            </div>
          </div>
        </div>
        <div
          class="col-12 col-md-6 col-lg-4 col-xl-2 px10 inline-flex items-center justify-end policies-item-button"
          v-else
        >
          <button
            class="btn-blue-outline btn-left-padding btn-left-white btn-focus-issue"
            v-on:click="downloadPolicy(policy, index)"
          >
            <div class="next-arrow-icon pdf-icon"><pdf-icon></pdf-icon></div>
            <span>DOWNLOAD</span>
          </button>
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script>
import pdfIcon from "../../common/icons/pdfIcon.vue";
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../../common/fullPageLoader.vue";

export default {
  data() {
    return {
      is_full_page_loader_shown: false,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  components: {
    pdfIcon,
    fullPageLoader,
  },
  props: {
    policy_versions: {},
    policy_title: {},
    module_complete_date: {},
    has_spanish: {},
  },
  mounted() {},
  methods: {
    downloadPolicy(policy, index, lang = "english") {
      var effective_date_text = "";
      if (index + 1 != this.policy_versions.length) {
        if (index + 2 != this.policy_versions.length) {
          effective_date_text =
            "Effective " +
            this.$filters.formatDate(this.policy_versions[index + 1].created_at) +
            " - " +
            this.$filters.formatDate(policy.created_at);
        } else {
          effective_date_text =
            "Effective " +
            this.$filters.formatDate(this.module_complete_date) +
            " - " +
            this.$filters.formatDate(policy.created_at);
        }
      } else {
        effective_date_text =
          "Last Effective " + this.$filters.formatDate(this.module_complete_date);
      }
      this.is_full_page_loader_shown = true;
      axios
        .post(JS_APP_URL + "/employeeportal/download-policy-versioning", {
          policy_versioning_id: policy.id,
          lang: lang,
          effective_date_text: effective_date_text,
        })
        .then((response)  => {
          if (response["data"]["status"] == "Success") {
            var link = document.createElement("a");
            link.setAttribute("href", response["data"]["data"]["download_url"]);
            link.setAttribute("download", response["data"]["data"]["file_name"]);
            link.setAttribute("target", "_blank");
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          } else {
            toastr.error(response["data"]["message"], "Error");
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_WORDPRESS_URL;
          }
        })
        .then(() => {
          setTimeout(() => {
            this.is_full_page_loader_shown = false;
          }, 100);
        });
    },
  },
};
</script>
