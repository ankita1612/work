import { createApp } from 'vue';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import VueMask from '@devindex/vue-mask';
import login from "./login.vue";

const app = createApp(login)
app.use(VueMask);
app.use(FloatingVue);
app.component('multiselect', Multiselect);
app.mount("#employeeportal_login_app")
