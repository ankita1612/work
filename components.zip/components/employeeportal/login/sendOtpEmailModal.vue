<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
            <div class="text-center mlr-auto mb30 pt20">
                <img :src="JS_APP_URL +'/images/envelop-upload.svg'" alt="" title="" />
            </div>
            <h2
                class="
                font-24 font_semibold
                blueog--text
                line-normal
                mb30
                text-center
                "
            >
                Send a One Time Password to Your Email
            </h2>
            <div class="modal-body">
                <form @submit.prevent="sendOtpEmailSubmit" class="reset-form">
                <div
                    class="form-group"
                    :class="{ 'form-group--error': v$.email.$error }"
                >
                    <input
                    class="form-input"
                    :class="{ 'form-error': v$.email.$error }"
                    id="email"
                    name="email"
                    v-model.trim="v$.email.$model"
                    type="text"
                    />
                    <label class="label" :class="{ 'label-float': v$.email.$model }"
                    >Email Address</label
                    >
                    <div v-if="v$.email.$errors.length > 0">
                        <div class="form-error-text text-left">
                            {{ v$.email.$errors[0].$message }}
                        </div>
                    </div>
                </div>
                <div class="text-center mb22">
                    <button
                    :disabled="disable_send_otp_email_btn"
                    type="submit"
                    class="btn-primary btn-primary-outline mlr-auto reset-pass-btn"
                    >
                    <span>SEND EMAIL</span>
                    </button>
                </div>
                </form>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import { useVuelidate } from '@vuelidate/core';
import { required, maxLength, email, helpers } from "@vuelidate/validators";
export default {
  data() {
    return {
      email: "",
      JS_APP_URL: JS_APP_URL,
    };
  },
  props: {
    disable_send_otp_email_btn:{
      type: Boolean,
      default: () => false
    },
  },
  components:{
  },
  setup: () => ({ v$: useVuelidate() }),
  emits: ["close-model", "send-otp-email-submit"],
  validations() {
    return {
        email: {
            required: helpers.withMessage('Please enter an email', required),
            email: helpers.withMessage('Please enter a valid email', email),
            maxLength: helpers.withMessage("Max 100 characters allowed",maxLength(100)),
        },
    }
  },
  methods: {
    closeModal(){
      this.$emit("close-model", false);
    },
    sendOtpEmailSubmit()    {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        this.$emit("send-otp-email-submit", this.email);
      }
    },
  },
  created() {
    // document.body.classList.add('modal-open');
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
