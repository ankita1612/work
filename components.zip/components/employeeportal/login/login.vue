<template>
  <div class="flex flex-col flex-auto min-fill-height">
      <div class="flex flex-col flex-auto min-fill-height">
        <div class="header-container container flex items-center flex-wrap py18">
          <a :href="JS_WORDPRESS_URL" target="_blank" class="logo-wrapper" >
            <img :src="JS_APP_URL + '/images/logo.svg'" alt="" title="" class="logo">
          </a>
          <div class="header-links flex-wrap flex  font_normal ml50">
            <a href="javascript:void(0)" class="header-link-item items-center relative relative px55 mt4 active">
              <div class="relative">
                <span class="header-text-small font-10 gray_checkmark--text">For</span>
                <div class="header-text-big font-24 gray_checkmark--text">Employees</div>
              </div>
            </a>
          </div>          
        </div>
        <div class="flex-auto blueog">
          <div class="container fill-height">
            <div class="row">
              <div class="col-12 col-md-12 col-lg-6 col-xl-6">
                <div class="sign-in-left fill-height flex justify-end">
                  <h1 class="login-left-title text-right white--text font-60 mb0">
                    <span class="font_light font-300">Never Stress Over</span>
                    <br /><span class="font-70 font_bold font-700">Compliance&nbsp;</span>
                    <span class="font_light font-300">Again.</span>
                  </h1>
                </div>
              </div>
              <div class="col-12 col-md-12 col-lg-6 col-xl-6">
                <div class="sign-in-box white mt38 mb40 pt38 pb30 px60">
                  <div class="text-center sign-in-icon mlr-auto pb20 mb30">
                    <img :src="JS_APP_URL + '/images/abyde_a.svg'" alt="" title="" />
                      <h2
                      class="
                        font-24 font_semibold
                        blueog--text
                        mt12
                        text-center
                        lh-1
                      "
                    >
                      Abyde Employee Portal
                    </h2>                    
                  </div>
                  <form @submit.prevent="verifyOtpSubmit" class="">
                  <p class="font-21 blueog--text line-normal text-center mb34">Please enter the verification code <br/> that was sent to your email below. </p>
                  <div class="form-group mb-0" :class="{ 'form-group--error': v$.verfication_otp.$error }">
                    <input
                      class="form-input sign-in-input"
                      :class="{ 'form-error': v$.verfication_otp.$error }"
                      id="verfication_otp"
                      name="verfication_otp"
                      v-model.trim="v$.verfication_otp.$model"
                      type="text"
                      v-mask="'0-0-0-0'"
                    />
                    <label class="label" :class="{ 'label-float': v$.verfication_otp.$model }"
                      >Verification Code</label
                    >
                    <div v-if="v$.verfication_otp.$errors.length > 0">
                      <div class="form-error-text">
                        {{ v$.verfication_otp.$errors[0].$message }}
                      </div>
                    </div>
                  </div>
                  <div class="font-16 font-italic font_light gray2--text text-center mt17">Code is valid for 30 minutes or 5 attempts</div>
                  <div class="flex items-center flex-wrap justify-center verification-buttons pt50">
                    <button
                      type="button"
                      class="btn-cancel-outline mx4"
                      :disabled="disable_verify_otp_btn"
                      v-on:click="sendOtpEmailSubmit(employee_data.email, employee_data.employee_portal_login.id)"
                    >
                      <span>Resend code</span>
                    </button>                    
                    <button                      
                      type="submit"
                      class="btn-primary mx4"
                      :disabled="disable_verify_otp_btn"                      
                    >
                      <span>Log In</span>
                    </button>
                  </div>             
                  </form>     
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
    <send-otp-email-modal
    v-if="is_send_otp_emal_modal_shown"
    :disable_send_otp_email_btn= "disable_send_otp_email_btn"
    @send-otp-email-submit= "sendOtpEmailSubmit"
    >      
    </send-otp-email-modal>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, minLength, maxLength, helpers } from "@vuelidate/validators";
import fullPageLoader from '../../common/fullPageLoader.vue';
import sendOtpEmailModal from "./sendOtpEmailModal.vue";
export default {
  data() {
    return {
      verfication_otp: "",
      employee_data: "",
      disable_verify_otp_btn: false,
      is_send_otp_emal_modal_shown: true,
      disable_send_otp_email_btn: false,
	    JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL
    };
  },
  components: {
    fullPageLoader,
    sendOtpEmailModal,
  },
  setup: () => ({ v$: useVuelidate() }),
  mounted() {
  },
  validations() {
    return {
      verfication_otp: {
        required: helpers.withMessage('Please enter a verification code', required),
        minLength: helpers.withMessage('Please enter a valid verification code', minLength(7)),
        maxLength: helpers.withMessage('Please enter a valid verification code', maxLength(7)),
      },
    }
  },
  watch: {
  },
  computed: {
  },
  methods: {
    sendOtpEmailSubmit(email = '', otp_ref_id = ''){
      if(email){
        NProgress.start();
        this.disable_send_otp_email_btn = true;
        axios
          .post(JS_APP_URL + "/employeeportal/send-login-otp", {
            email: email,
            otp_ref_id: otp_ref_id,
          })
          .then((response)  => {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
            } else {
              toastr.success(response["data"]["message"], "Success");
              this.is_send_otp_emal_modal_shown = false;
              this.employee_data = response["data"]['data'];
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
          })
          .then(() => {
            NProgress.done();
            this.disable_send_otp_email_btn = false;
          });
      }
    },
    async verifyOtpSubmit(){
      if(this.employee_data.employee_portal_login.id){
        this.v$.$touch();
        const is_valid = await this.v$.$validate();
        if (is_valid) {
          this.disable_verify_otp_btn = true;
          axios
            .post(JS_APP_URL + "/employeeportal/verify-otp-and-login", {
              verfication_otp: this.verfication_otp,
              otp_ref_id: this.employee_data.employee_portal_login.id,
            })
            .then((response)  => {
              if (response["data"]["status"] == "Error") {
                if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
              } else {
                setTimeout(() => {
                  window.location = JS_APP_URL + "/employeeportal/dashboard";
                }, 500);
              }
            })
            .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
            })
            .then(() => {
              NProgress.done();
              this.disable_verify_otp_btn = false;
            });
        }
      }else{
        toastr.error("Something went wrong. Please try again!", "Error");
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      }
    }
  },
};
</script>
