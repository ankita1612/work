<template>
  <div>
    <header-employee-portal></header-employee-portal>
    <div class="container pt30 pb60">
       <div class="font-24 font_semibold blueog--tex text-center mb15 line-normal">Employee Confidentiality Agreement</div>
       <p class="font-16 gray_checkmark--text line-normal text-center mb20">Please review, sign and complete the HIPAA Employee Confidentiality Agreement. </p>
       <div class="employee-onboarding-steps flex flex-wrap mlr-auto line-normal mb35">
          <button type="button" class="employee-onboarding-step-item active flex-auto" :class="{'active' : progress_step >= 1}"><div class="font_semibold font-14">Step 1 </div><div class="font_light font-13">Review Policy</div></button>
          <button type="button" class="employee-onboarding-step-item flex-auto" :class="{'active' : progress_step >= 2}"><div class="font_semibold font-14">Step 2 </div><div class="font_light font-13">Create Signature</div></button>
          <button type="button" class="employee-onboarding-step-item flex-auto" :class="{'active' : progress_step >= 3}"><div class="font_semibold font-14">Step 3 </div><div class="font_light font-13">Complete Policy</div></button>
       </div>
       <div v-if="progress_step == 1" class="employee-onboarding-content mlr-auto mb28">
          <div class="row flex-auto -mx-10 items-center mb20">
              <div class="col-12 px10">
                <iframe class="pdf-viewer" v-if="agreement_pdf_url!=''" :src="JS_APP_URL+'/pdfjs/web/viewer.html?file='+agreement_pdf_url" width="100%" height="600"></iframe>
              </div>
          </div>
          <div class="text-center">
            <button v-on:click="nextStep()" type="button" class="btn-blue-outline">next
              <div class="next-arrow-icon"> <next-icon></next-icon></div>
            </button>
          </div>
       </div>
       <div v-if="progress_step == 2" class="employee-onboarding-content mlr-auto mb28">
          <div class="row flex-auto -mx-10 items-center mb20">
              <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10">
                  <div class="form-group" :class="{ 'form-group--error': v$.signature.$error }">
                      <input class="form-input location-input-box preveiw-signature-input-box" :class="{ 'form-error': v$.signature.$error }" type="text" name="signature" v-model.trim="v$.signature.$model">
                      <label class="label location-input-label" :class="{ 'label-float': v$.signature.$model }">Create Signature</label>
                      <div v-if="v$.signature.$errors.length > 0" class="form-error-text absolute">
                        <span>
                        {{ v$.signature.$errors[0].$message }}
                        </span>
                      </div>
                  </div>
              </div>
              <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10">
                  <div class="form-group">
                    <input disabled="disabled" v-bind:value="signature" class="form-input preveiw-signature-input font-bold" type="text" name="first_name">
                    <label class="label location-input-label preveiw-signature-label" :class="{ 'label-float': v$.signature.$model }">Preview Signature</label>
                  </div>
              </div>
          </div>
          <div class="text-center">
            <button v-on:click="nextStep()" type="button" class="btn-blue-outline">next
              <div class="next-arrow-icon"> <next-icon></next-icon></div>
            </button>
          </div>
       </div>
       <div v-if="progress_step == 3" class="employee-onboarding-content mlr-auto mb28">
          <p class="font-15 line-normal text-center text-999 font_semibold mb20">The following policy applies to all locations that you are an employee of.</p>
          <div class="row flex-auto -mx-10 items-center mb20">
              <div class="col-12 px10">
                <iframe v-if="agreement_pdf_url!=''" :src="JS_APP_URL+'/pdfjs/web/viewer.html?file='+agreement_pdf_url" width="100%" height="600"></iframe>
              </div>
          </div>
          <div class="text-center">
            <button v-on:click="downloadAgreement" type="button" class="btn-blue-outline emp-portal-download-btn">
              <div class="next-arrow-icon pdf-icon"> <pdf-icon></pdf-icon></div>
              download</button>
              <button v-on:click="redirectToAbyde(JS_WORDPRESS_URL)" type="button" class="btn btn-blue mx5 complete_btn">
              complete</button>
          </div>
       </div>
       <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
       <download-agreement-modal v-if="is_downloadagreementmodal_shown" :agreement_pdf_url_downloadebale="agreement_pdf_url_downloadebale"></download-agreement-modal>
    </div>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, maxLength, helpers } from "@vuelidate/validators";

import nextIcon from '../../common/icons/nextIcon.vue';
import pdfIcon from '../../common/icons/pdfIcon.vue';
import fullPageLoader from '../../common/fullPageLoader.vue';
import downloadAgreementModal from '../agreement/downloadAgreementModal.vue';
import headerEmployeePortal from '../../common/includes/headerEmployeePortal.vue';
import {checkSpecialChars, checkSpecialCharsErrorMessage}  from "../../common/customValidation";
export default {
  data() {
    return {
      signature: '',
      progress_step: 0,
      agreement_pdf_url: '',
      agreement_pdf_url_downloadebale: '',
      is_full_page_loader_shown: false,
      is_downloadagreementmodal_shown: false,
      JS_EMPLOYEE_ID: JS_EMPLOYEE_ID,
      JS_REF_TOKEN: JS_REF_TOKEN,
      JS_EMPLOYEE_DATA: JS_EMPLOYEE_DATA,
      JS_EMPLOYEE_AGREEMENT_DATA: JS_EMPLOYEE_AGREEMENT_DATA,
		  JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage
    };
  },
  components: {
    nextIcon,
    fullPageLoader,
    downloadAgreementModal,
    pdfIcon,
    headerEmployeePortal
   },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
        signature: {
            required: helpers.withMessage("Please enter a signature name", required),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
        }
    };
    return validationArray;
  },
  created() {
    if(!JS_EMPLOYEE_DATA || !JS_EMPLOYEE_AGREEMENT_DATA){
      this.is_full_page_loader_shown = true;
      toastr.error("Seems like your agreement link has been expired!. Please contact support.", "Error");
      setTimeout(() => {
        this.is_full_page_loader_shown = false;
        window.location = JS_WORDPRESS_URL;
      }, 1500);
    }else{
      this.progress_step++;
    }
  },
  watch: {
    progress_step(newVal, oldVal){
      this.stepChanged();
    }
  },
  computed: {
  },
  methods: {
    redirectToAbyde(abyde_url){
      window.location = abyde_url;
    },
    nextStep(){
      if(this.progress_step == 2){
        this.v$.$touch();
        if (!this.v$.$invalid) {
          this.progress_step++;
        }
      }else{
        this.progress_step++;
      }
    },
    stepChanged(){
      if(this.progress_step == 1 || this.progress_step == 3 && (JS_EMPLOYEE_DATA && JS_EMPLOYEE_AGREEMENT_DATA)){
        this.is_full_page_loader_shown = true;
        var request_obj = {
          employee_id: this.JS_EMPLOYEE_ID,
          ref_token: this.JS_REF_TOKEN,
        };
        if(this.progress_step == 3){
          request_obj['signature'] = this.signature;
        }
        axios
        .post(JS_APP_URL + "/employeeportal/get-agreement-data",request_obj)
        .then((response)  => {
          if (response["data"]["status"] == "Success") {
            this.agreement_pdf_url = response['data']['data']['agreement_pdf_url'];
            this.agreement_pdf_url_downloadebale = response['data']['data']['agreement_pdf_url_downloadebale'];
            if(response['data']['data']['employee_agreement']['signature'] && response['data']['data']['employee_agreement']['file_name'] && this.progress_step == 3){
              toastr.success('Employee Confidentiality Agreement Completed.');
            }
            if(response['data']['data']['employee_agreement']['signature'] && response['data']['data']['employee_agreement']['file_name'] && this.progress_step == 1){
              this.is_downloadagreementmodal_shown = true;
            }
          }else{
            setTimeout(() => {
              window.location = JS_WORDPRESS_URL;
            }, 1500);
          }
        })
        .catch((error) => {
        })
        .then(() => {
          setTimeout(() => {
            this.is_full_page_loader_shown = false;
          }, 200);
        });
      }
    },
    downloadAgreement(){
      var link = document.createElement("a");
      link.href = this.agreement_pdf_url_downloadebale;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  },
};
</script>
