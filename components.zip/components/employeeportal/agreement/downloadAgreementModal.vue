<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
            <div class="text-center mlr-auto mb30 pt20">
                <img :src="JS_APP_URL + '/images/envelop-done.svg'" alt="" title="" class="warning-icon-modal" />
            </div>
            <h2
                class="
                font-24 font_semibold blueog--text line-normal text-center mb20
                "
            >
                Congratulations!
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb15">Thank you for completing the Employee Agreement.</p>
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">Click the button below to view, print and/or download a copy of your signed Employee Agreement.</p>
            <div class="flex flex-wrap items-center justify-center pb20">
                <button v-on:click="downloadAgreement" class="btn-primary-outline mx5">DOWNLOAD AGREEMENT</button>
            </div>
            <div class="flex flex-wrap items-center justify-center pb40">
                <button  v-on:click="goToLogin" class="btn-blueog-outline mx5">CLOSE WINDOW</button>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>

export default {
  props: {
    agreement_pdf_url_downloadebale:{
      type: String,
      default: () => ''
    },
  },
  components:{},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  methods: {
    downloadAgreement(){
      var link = document.createElement("a");
      link.href = this.agreement_pdf_url_downloadebale;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    },
    goToLogin(){
      window.location = JS_WORDPRESS_URL;
    }
  },
  created() {
    // document.body.classList.add('modal-open');
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
