<template>
  <div>
    <header-employee-portal></header-employee-portal>
      <div class="container pt40 pb60">
      <full-page-loader v-if="is_full_page_loader_shown" />
      <!-- First screen code as per design  -->
      <first-page
        v-if="show_sra_start_page"
        :selected_employee="selected_employee"
        :training="training"
        @get-quiz-question="getQuizQuestion"
      />
      <!-- end first screen code -->

      <!-- second screen code -->
      <question-detail
        v-if="show_question_detail_page"
        :training_qustions="training_qustions"
        :selected_employee="selected_employee"
        @submit-quiz-question-answer="submitQuizQuestionAnswer"
      />
      <!-- end second screen code -->
      <complete-quiz
        v-if="quiz_fail_page"
        :selected_employee="selected_employee"
        :result="result"
        :training="training"
      />
      
    </div>

  </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import headerEmployeePortal from "../../common/includes/headerEmployeePortal.vue";
import fullPageLoader from "../../common/fullPageLoader.vue";
import firstPage from "../trainingQuiz/firstPage.vue";
import questionDetail from "../trainingQuiz/questionDetail.vue";
import completeQuiz from "../trainingQuiz/completeQuiz.vue";
import NProgress from "nprogress";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      selected_employee:JS_EMPLOYEE_DATA,
      training:"",
      show_sra_start_page:true,
      is_full_page_loader_shown:false,
      training_qustions:{},
      show_question_detail_page:false,
      quiz_fail_page:false,
      result:{}
    };
  },
  components: {
    headerEmployeePortal,
    fullPageLoader,
    firstPage,
    questionDetail,
    completeQuiz
  },
  mounted() {
    if(JS_INVITE_ID == null || JS_INVITE_ID == ""){
        window.location = JS_APP_URL + "/employeeportal/training";
    }
    this.getInviteDetails();
  },
  methods: {
    getInviteDetails(){
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/employeeportal/get-invite-details/"+JS_INVITE_ID)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.training = response.data.data.training
            this.selected_employee = response.data.data.emp_user_acntuser_student
            this.show_sra_start_page= true
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_WORDPRESS_URL;
          }
        })
        .then((response) => {
          this.is_full_page_loader_shown = false;
        });
    },
    getQuizQuestion(){
      NProgress.start();
      axios
        .get(JS_APP_URL + "/employeeportal/get-training-quiz?training_id="+this.training.id)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.training_qustions = response.data.data
             this.show_sra_start_page = false
             this.show_question_detail_page = true
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_WORDPRESS_URL;
          }
        })
        .then((response) => {
          NProgress.done();
        });
    },
    submitQuizQuestionAnswer(answer_array){
      this.is_full_page_loader_shown = true;
      axios
        .post(JS_APP_URL + "/employeeportal/add-training-complete-record",{
          invite_id:JS_INVITE_ID,
          queans:answer_array
        })
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.result = response.data.data
             this.quiz_fail_page = true
            this.show_question_detail_page = false
            if(response.data.data.result_of_training_quiz < 70){
             
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_WORDPRESS_URL;
          }
        })
        .then((response) => {
          this.is_full_page_loader_shown = false;
        });

    }
  },
};
</script>