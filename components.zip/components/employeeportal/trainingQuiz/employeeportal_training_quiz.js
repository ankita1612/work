import { createApp } from 'vue';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import trainingQuiz from "./trainingQuiz.vue";

const app = createApp(trainingQuiz)
app.use(FloatingVue);
app.component('multiselect', Multiselect);
app.mount("#employee_potal_training_quiz_app")
