<template>
  <div>
    <full-page-loader v-if="is_full_page_loader_shown" />
    <h3 class="
        location-dashbaord-title
        text-center
        font-24
        font_light
        blueog--text
        line-normal
        mb-md-10 mb-sm-10
      "> Training Quiz </h3>
    <h1 class="font-24 font_semibold blueog--text text-center mb-md-20 mb25">
      {{ training_qustions.title }} Quiz
    </h1>
    <div class="security-progress-wrapper mb40">
      <radial-progress-bar
        class="sra-quetions-progress"
        :diameter="200"
        :completed-steps="percentage_count"
        :total-steps="total_steps_outer"
        :start-color="start_color_outer"
        :stop-color="start_color_outer"
        :inner-stroke-color="inner_stroke_color"
        :inner-stroke-width="3"
        :stroke-width="6"
      >
        <h1
          class="sra-percent-text font_semibold"
          v-bind:style="{ color: start_color_outer }"
        >
          {{ percentage_count }}%
        </h1>
        <h3 class="sra-completed-text">Completed</h3>
      </radial-progress-bar>
    </div>
    <p class="font-25 black--text text-center mb50" v-html="training_qustions.training_question[current_question].question">
    </p>
    <div class="sra-quetions-wrapper mlr-auto">
      <div class="row flex-auto justify-center -mx-10 mb54">
        <div
          class="col-12 col-md-4 col-lg-3 col-xl-3 mb15 mb-md-20 px10"
          v-for="answer_opt in training_qustions.training_question[
            current_question
          ].training_question_answer"
          :key="answer_opt.id"
        >
          <div class="answer-option-item">
            <input
              type="radio"
              class="answer-option-radio"
              :id="'radio ' + answer_opt.id"
              :value="answer_opt.id"
              v-model="selected_answers"
            />
            <label
              class="answer-option-lable font-20 blueog--text"
              :for="'radio ' + answer_opt.id"
              >{{ answer_opt.answer }}</label
            >
          </div>
        </div>
        <div class="col-12">
          <div v-if="show_error" class="mb10 font-12 red2--text">
            <div class="text-center font-16 font_bold">
              * Please select an answer to continue
            </div>
          </div>
        </div>
      </div>

      

      <div class="text-center relative mt12">
          <button
            type="button"
            class="btn-blue-outline btn-left-icon prev-btn"
            v-if="current_question > 0"
            :disabled="is_btn_disabled"
            @click="previousQuestion"
          >
            <div class="prev-arrow-icon"><previous-icon></previous-icon></div>
            Previous Question
          </button>
        <button
          type="submit"
          class="btn-primary-outline btn-width-136 h-32 d-inline-block px30"
          :disabled="is_btn_disabled"
          @click="nextquestion"
        >
          Next
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import RadialProgressBar from "vue3-radial-progress";
import previousIcon from "../../common/icons/previousIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import _ from "lodash";
import fullPageLoader from "../../common/fullPageLoader.vue";

export default {
  props: {
    training_qustions: {
      type: Object,
    },
    selected_employee: {},
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      inner_stroke_color: "#CCCCCC",
      percentage_count: 0,
      total_steps_outer: 100,
      start_color_outer: "#C72121",
      start_color_inner: "#203C72",
      selected_answers: "",
      show_error: false,
      is_btn_disabled: false,
      is_full_page_loader_shown: false,
      question_answer: [],
      current_question: 0,
      total_qustion: this.training_qustions.training_question.length,
      employees: [],
    };
  },
  emits: ["submit-quiz-question-answer"],
  components: {
    RadialProgressBar,
    previousIcon,
    fullPageLoader,
  },

  mounted() {
    this.employees.push(this.selected_employee);
    _.range(0, this.total_qustion).forEach((current, index, range) => {
      this.question_answer.push({ ["question_id"]: "", ["answer_id"]: "" });
    });
  },

  watch: {
    percentage_count(val) {
      if (val <= 69) {
        this.start_color_outer = "#C72121";
      } else if (val > 69 && val <= 89) {
        this.start_color_outer = "#FAC224";
      } else {
        this.start_color_outer = "#7FC361";
      }
    },
    selected_answers(val){
      if(val != "" || val != null){
        this.show_error = false;
      }
    }
  },

  methods: {
    nextquestion() {
      if (this.selected_answers == "" || this.selected_answers == null) {
        this.show_error = true;
      } else {
        if (this.current_question + 1 == this.total_qustion) {
          this.question_answer[this.current_question]["question_id"] = this.training_qustions.training_question[this.current_question].id;
          this.question_answer[this.current_question]["answer_id"] = this.selected_answers;
          this.show_error = false;
          this.$emit("submit-quiz-question-answer", this.question_answer);
        } else {
          this.question_answer[this.current_question]["question_id"] = this.training_qustions.training_question[this.current_question].id;
          this.question_answer[this.current_question]["answer_id"] = this.selected_answers;
          this.show_error = false;
          this.current_question++;
          this.selected_answers = this.question_answer[this.current_question]["answer_id"];
          if (this.question_answer[this.current_question]["answer_id"] == "") {
            this.percentage_count = parseInt(
              ((this.current_question * 100) / this.total_qustion).toFixed(0)
            );
          }
        }
      }
    },
    previousQuestion() {
      this.selected_answers = "";
      this.show_error = false;
      this.current_question--;
      this.selected_answers = this.question_answer[this.current_question]["answer_id"];
    },
    fullname(option) {
      return `${option.first_name} ${option.last_name}`;
    },
  },
};
</script>
