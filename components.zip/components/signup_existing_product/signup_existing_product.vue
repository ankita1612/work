<template>
  <div class="flex flex-col flex-auto min-fill-height">
    <header-before-login></header-before-login>
    <div class="flex-auto blueog">
      <div class="container fill-height">
        <div class="sign-in-box white mt38 mb40 pt38 pb30 px38 mlr-auto">
          <div v-if="Object.keys(partner_reseller_osha).length > 0" class="text-center">
                <img :src="JS_APP_URL + '/images/partner/' + partner_reseller_osha.logo" alt="Abyde" width="200px" />
          </div>
          <form @submit.prevent="signupSubmit">
            <h1 class="font-30 font_semibold blueog--text text-center mb30">HIPAA for Covered Entities Sign Up</h1>
            <div class="text-center mlr-auto mb30">
              <button type="button" class="pricing-time-item font-18 uppercase gray2--text with-transition pricing-time-item-selected">{{(payment_plan == 'monthly')? 'MONTHLY':(payment_plan == 'quarterly')?'QUARTERLY': (payment_plan == 'biannually')?'BI-ANNUALLY':'ANNUALLY'}}</button>
            </div>
            <div class="mlr-auto total-location-wrapper">
              <div class="row flex-auto -mx-10 items-center">
                <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10 mb-sm-20 text-center">
                  <h4 class="font-24 blueog--text font_bold font_semibold mb10">Locations</h4>
                  <span class="font-25 location-number-text font_bold">{{selected_location}}</span>
                </div>
                <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10 text-center">
                    <h4 class="font-24 blueog--text font_bold font_semibold mb10">Employee Range</h4>
                    <span class="font-25 location-number-text font_bold">{{selected_employee.limit}}</span>
                </div>
              </div>
            </div>

            <div class="promo-code-box light px15 py10 mb30">
              <div class="row">
                <div class="col-12 col-md-6 col-lg-7 col-xl-7 self-center font-20 blueog--text font_normal font_semibold mb-sm-10">
                  Drop that promo code to save $$$
                </div>
                <div class="col-12 col-md-6 col-lg-5 col-xl-5 self-stretch">
                  <div class="promo-code-input relative">
                    <input :disabled="Object.keys(promocode_data).length > 0" type="text" v-model.trim = "entered_promocode" class="promo-input font-16 darkgray--text" placeholder="Enter promo code" v-uppercase />
                    <button v-if="Object.keys(promocode_data).length == 0" v-on:click="applyPromocode()" type="button" class="text-center apply-btn font_normal font_semibold">APPLY</button>
                    <button v-if="Object.keys(promocode_data).length > 0" v-on:click="removePromocode()" type="button" class="text-center apply-btn remove-btn font_normal font_semibold">REMOVE</button>
                  </div>
                  <div class="promo-text green--text" v-if="Object.keys(promocode_data).length > 0 && promocode_data.discount_type == 'percentage'">{{promocode_data.discount_percentage}}% Discount Applied</div>
                </div>
              </div>
            </div>
            <div class="account-info-block px40 mb10"  v-if="query_is_admin_panel_login == '0'">               
                <h2 class="font-24 blueog--text font_normal font_semibold mb20">Account Information</h2>
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 text-left">
                      <div class="relative mb30">
                        <div
                          class="form-group mb-0"
                          :class="{ 'form-group--error': v$.password.$error }"
                        >
                          <input
                            class="form-input form-input-password"
                            :class="{ 'form-error': v$.password.$error }"
                            id="password"
                            name="password"
                            v-model.trim="v$.password.$model"
                            :type="password_field_type"
                          />
                          <label
                            class="label"
                            :class="{ 'label-float': v$.password.$model }"
                            >Password</label
                          >
                          <div v-if="v$.password.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.password.$errors[0].$message }}
                            </div>
                          </div>
                          <button v-on:click="togglePasswordVisibility('password')" type="button" class="cursor-pointer pass-eye-icon">
                            <img v-if="password_field_type == 'password'" :src="JS_APP_URL + '/images/eye.svg'" alt="" title="" />
                            <img v-if="password_field_type == 'text'" :src="JS_APP_URL + '/images/eye-closed.svg'" alt="" title="" />
                          </button>
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 text-left">
                      <div class="relative mb30">
                        <div
                          class="form-group mb-0"
                          :class="{ 'form-group--error': v$.confirm_password.$error }"
                        >
                          <input
                            class="form-input form-input-password"
                            :class="{ 'form-error': v$.confirm_password.$error }"
                            id="confirm_password"
                            name="confirm_password"
                            v-model.trim="v$.confirm_password.$model"
                            :type="confirm_password_field_type"
                            @paste.prevent
                            @click.right.prevent
                          />
                          <label
                            class="label"
                            :class="{ 'label-float': v$.confirm_password.$model }"
                            >Confirm Password</label
                          >
                          <div v-if="v$.confirm_password.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.confirm_password.$errors[0].$message }}
                            </div>
                          </div>
                          <button v-on:click="togglePasswordVisibility('confirm_password')" type="button" class="cursor-pointer pass-eye-icon">
                              <img v-if="confirm_password_field_type == 'password'" :src="JS_APP_URL + '/images/eye.svg'" alt="" title="" />
                              <img v-if="confirm_password_field_type == 'text'" :src="JS_APP_URL + '/images/eye-closed.svg'" alt="" title="" />
                          </button>
                        </div>
                      </div>
                    </div>
                </div>
            </div>

            <div class="account-info-block px40 mb10">
              <div class="row items-center mb20">
                <div class="col-xs-12 col-md-6 col-lg-4">
                  <h2 class="font-24 blueog--text font_normal font_semibold mb-sm-10">Billing Information</h2>
                </div>
                <div class="col-xs-12 col-md-6 col-lg-8 flex items-center flex-wrap">
                  <button type="button" v-on:click="billingInfoChanged('same')" class="billing-card-btn font-16 blue--text with-transition mr15" :class="{'active' : billing_info == 'same'}">Same</button>
                  <button type="button" v-on:click="billingInfoChanged('new')" class="billing-card-btn font-16 with-transition" :class="{'active' : billing_info == 'new'}">New</button>
                </div>
              </div>
              <div class="row items-center mb20">
                <div class="col-xs-12 col-md-12 col-lg-12">
                  <h2 class="font-14 green--text font-italic font_semibold mb-sm-10">Use your existing {{(payment_source_type == 'card')?'card':'bank'}} ending with ••••{{stripe_payment_source_data.last4}}</h2>
                </div>
              </div>
              <div v-if="billing_info == 'new'" class="row items-center mb20">
                <div class="col-xs-12 col-md-12 col-lg-12 flex items-center flex-wrap">
                  <button type="button" v-on:click="paymentTypeChanged('card')" class="billing-card-btn font-16 blue--text with-transition mr15" :class="{'active' : payment_type == 'card'}">Credit Card</button>
                  <button type="button" v-on:click="paymentTypeChanged('bank')" class="billing-card-btn font-16 with-transition" :class="{'active' : payment_type == 'bank'}">Bank Account</button>
                </div>
              </div>
              <div v-show="billing_info == 'new' && payment_type == 'card'">
                <div class="row flex-auto -mx-10">
                  <div class="col-12 col-md-12 col-lg-12 col-xl-12 px10 mb15">
                    <div class="relative mb10">
                      <div class="form-group mb-0" :class="{ 'form-group--error': v$.card_name.$error }">
                        <input
                          class="form-input"
                          :class="{ 'form-error': v$.card_name.$error }"
                          id="card_name"
                          name="card_name"
                          v-model.trim="v$.card_name.$model"
                          type="text"
                        />
                        <label class="label" :class="{ 'label-float': v$.card_name.$model }">Name on Card</label
                        >
                        <div v-if="v$.card_name.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.card_name.$errors[0].$message }}
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card_elements_container">
                  <div class="row flex-auto -mx-10">
                      <div class="col-12 col-md-12 col-lg-12 col-xl-12 px10 mb25">
                        <div class="form-group mb-0">
                          <div id="card-number" class="input empty"></div>
                          <label class="label">Card Number</label>
                        </div>
                      </div>
                  </div>
                  <div class="row flex-auto -mx-10">
                      <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10 mb25">
                        <div class="form-group mb-0">
                          <div id="card-expiration" class="input empty"></div>
                          <label class="label">Card Expiration</label>
                        </div>
                      </div>
                      <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10 mb25">
                        <div class="form-group mb-0">
                          <div id="card-cvc" class="input empty"></div>
                          <label class="label">CVV Code</label>
                        </div>
                      </div>
                  </div>                                
                </div>  
              </div>
              <div v-show="billing_info == 'new' && payment_type == 'bank'">
                <div class="row">
                  <div class="col-xs-12 col-lg-12 text-left">
                    <div class="relative mb10">
                        <button type="button" class="btn-primary" v-on:click="addNewBank()">
                            <span>LINK YOUR BANK ACCOUNT</span>
                        </button>
                    </div>
                    <div class="text-left" v-if="linked_bank_accnount_message != ''">
                      <p class="green--text">Bank account ending with <b> {{linked_bank_accnount_message}} </b> linked successfully! Please proceed with signup process.</p>
                    </div>
                    <p class="Proxima-Nova-L small font-italic mt10 mb10">By clicking "Link Your Bank Account" button you agree to authorize payments pursuant to <a target="_blank" class="green--text" href="https://stripe.com/en-in/legal/ach-payments/authorization">these terms.</a></p>
                  </div>
                </div>
              </div>
              <div class="row margin0 padding0">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-left">
                  <p class="Proxima-Nova-L small font-italic">By checking this box, you confirm that you agree to Abyde's terms and conditions, including the subscription and renewal policies. Upon clicking ‘Sign Up,’ you authorize Abyde to process your subscription and charge your payment method for all future renewal periods as specified in the terms. Please note that once confirmed, your subscription cannot be canceled until the next renewal period, and all fees are non-refundable except as stated in our terms and conditions.</p>
                </div>
              </div>
            </div>

            <div class="account-info-block px40">
              <h2 class="font-24 blueog--text font_normal font_semibold mb20">Subscription Plan</h2>
              <div class="pricing-modal-plan-box light px10 py15 br10">
                <div class="row">
                  <div class="col-xs-12 col-sm-7 col-md-6 col-lg-6">
                    <div class="mb10">
                      <span class="sub-plan-left-text font-18 gray_checkmark--text font_semibold">Regular Price</span>
                      <span class="sub-plan-right-text font-18 gray_checkmark--text font_normal" :class="{'strikethrough': (getFinalPromocode() != '-' || sales_tax.length > 0)}">{{getFinalRegularPrice()}}</span>
                    </div>
                    <div class="mb10">
                      <span class="sub-plan-left-text font-18 gray_checkmark--text font_semibold">Promo Code</span>
                      <span class="sub-plan-right-text font-18 gray_checkmark--text font_normal">{{getFinalPromocode()}}</span>
                    </div>
                    <!-- <div class="mb10">
                      <span class="sub-plan-left-text font-18 gray_checkmark--text font_semibold"> Transaction Fee</span>
                      <span class="sub-plan-right-text font-18 gray_checkmark--text font_normal">&nbsp;{{getFinalTransactionFee()}}</span>
                    </div> -->
                    <div v-if="sales_tax.length == 0">
                      <span class="sub-plan-left-text font-18 gray_checkmark--text font_semibold">Tax <span class="Proxima-Nova-Rg">(0%)</span>
                      </span> <span class="sub-plan-right-text font-18 gray_checkmark--text font_normal">$0</span>
                    </div>
                    <div v-else>
                      <div v-for="(st, index) in sales_tax" :key="index">                        
                        <span class="sub-plan-left-text font-14 gray_checkmark--text font_semibold">{{st.percentage}}</span>
                        <span class="sub-plan-right-text font-14 gray_checkmark--text font_normal">{{getFinalSalesTaxAmount(st.amount/100)}}</span>
                      </div>
                    </div>
                  </div>
                  <div class="col-xs-12 col-sm-5 col-md-6 col-lg-6 self-center">
                    <div class="text-center font-18 font_semibold blueog--text sub-plan-dis-title mb10">Payment Price</div>
                    <div class="d-flex justify-center">
                      <span class="pricing-value font-36 green--text font_semibold lh-1">{{getFinalPaymentPrice()}}</span>
                      <span class="pricing-year self-end font-20 gray_checkmark--text font_normal">/{{getFinalPaymentPlan()}}</span>
                    </div>
                    <div class="d-flex justify-center" style="margin-top: 3%;">
                      <span class="pricing-year self-end font-14 gray_checkmark--text font_normal">{{ getFinalPaymentPlanText() }}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group my30 modal-terms text-center" :class="{ 'form-group--error': v$.is_terms_accepted.$error }">
                <div class="checkbox">
                  <input id="add_is_no_expiration_applicable" v-model="v$.is_terms_accepted.$model" name="add_is_no_expiration_applicable" type="checkbox">
                  <label for="add_is_no_expiration_applicable"  class="checkbox-label font-14 font_semibold gray_checkmark--text">
                    I Accept the
                    <a :href="(Object.keys(partner_reseller_osha).length > 0)?JS_WORDPRESS_URL + '/reseller-terms-and-conditions':JS_WORDPRESS_URL + '/terms-conditions'" target="_blank" class="font-16 green--text font_semibold"> Terms and Conditions </a>
                  </label>
                </div>
                <div v-if="v$.is_terms_accepted.$errors.length > 0">
                    <div class="form-error-text form-error-text-center">
                        {{ v$.is_terms_accepted.$errors[0].$message }}
                    </div>
                </div>
              </div>
              <div class="d-flex justify-center">
                  <button type="submit" class="btn-primary mx5" :disabled="is_signup_btn_disabled">
                      <span>sign up</span>
                  </button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
      <resend-email-modal
        v-if="show_resend_email_modal"
        @close-model="resendEmailModalToggle"
        @show-additional-products="showAdditionalProducts"
        :email="email"
        :chargebee_invoice_id="chargebee_invoice_id"
      ></resend-email-modal>
      <show-additional-products-modal
        v-if="show_additional_products_modal"
        @show-additional-products="showAdditionalProducts"
        :email="email"
        :addition_product_list="addition_product_list"
        :action="query_action"
      ></show-additional-products-modal>
    </div>
    <footer-before-login :is_reseller="(Object.keys(partner_reseller_osha).length > 0)?'yes':'no'"></footer-before-login>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, numeric, maxLength, email, minLength, sameAs, requiredIf, helpers } from "@vuelidate/validators";
import infoIcon from "../common/icons/infoIcon.vue"
import fullPageLoader from '../common/fullPageLoader.vue';
import headerBeforeLogin from "../common/includes/headerBeforeLogin.vue";
import footerBeforeLogin from "../common/includes/footerBeforeLogin.vue";
import resendEmailModal from "../signup_new_product/resendEmailModal.vue";
import showAdditionalProductsModal from "../signup_new_product/showAdditionalProductsModal.vue";
import moment from "moment-timezone";
import _ from "lodash";
import {checkSpecialChars, checkSpecialCharsErrorMessage, complexPassword, complexPasswordErrorMseesage }  from "../common/customValidation";
export default {
  data() {
    return {
      billing_info: 'same',
      location_pricing: {},
      selected_location: '',
      employee_pricing: {},
      selected_employee: '',
      payment_plan: '',
      first_name: '',
      last_name: '',
      company_name: '',
      phone_number: '',
      email: '',
      password: "",
      password_field_type: 'password',
      confirm_password: "",
      confirm_password_field_type: 'password',
      selected_state: '',
      zip_code: '',
      payment_type: 'card',
      card_name: "",   
      cardNumber: {},
      cardExpiry: {},
      cardCvc: {},
      is_terms_accepted: false,
      is_full_page_loader_shown: false,
      is_signup_btn_disabled: false,
      entered_promocode: '',
      promocode_data: {},
      stripe_payment_method: '',
      sales_tax: [],
      total_price: 0,
      transaction_fee: 0,
      linked_bank_accnount_message: '',
      show_resend_email_modal: false,
      show_additional_products_modal: false,
      addition_product_list: [{
        "id": "oshahc",
        "name": "OSHA HC",
        "full_name": "OSHA for Healthcare"
      }],
      numberInWordsArray: ['Zero Month', 'One Month', 'Two Months', 'Three Months', 'Four months', 'Five months', 'Six months', 'Seven months', 'Eight months', 'Nine months', 'Ten months', 'Eleven months', 'Twelve months'],
      JS_APP_URL: JS_APP_URL,
      JS_OSHA_HC_APP_URL: JS_OSHA_HC_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
      action_type: ['outside', 'inside'],
      query_token: '',
      query_product: '',
      query_action: '',
      stripe_customer_id: '',
      reference_id: '',
      payment_source_type: '',
      stripe_payment_source_data: {},
      partner_reseller_osha: {},
      setup_intent_client_secret: {},
      stripe_elements:{},
      chargebee_invoice_id: '',
      chargebee_customer_id: null,
      query_is_admin_panel_login: '',
      login_type: ['0','1']
    };
  },
  setup: () => ({ v$: useVuelidate() }),
  components: {
    fullPageLoader,
    headerBeforeLogin,
    footerBeforeLogin,
    infoIcon,
    resendEmailModal,
    showAdditionalProductsModal
  },
  validations() {
    return {
        password: {          
             requiredIf: helpers.withMessage("Please enter a password",
                requiredIf(() => {
                    return this.query_is_admin_panel_login == '0'
            })),
            minLength: helpers.withMessage('Password must have at least 6 letters', minLength(6)),           
            isComplexPassword: helpers.withMessage(
              complexPasswordErrorMseesage,
              function(value) {
                // Skip validation if it's an admin panel login                
                if (this.query_is_admin_panel_login == "1") {                                   
                  return true;
                }
                return complexPassword(value); // Apply actual validation
              }
            )            
        },
        confirm_password: {            
             requiredIf: helpers.withMessage("Please enter a confirm password",
                requiredIf(() => {
                    return this.query_is_admin_panel_login == '0'
            })),
            confirmPassword: helpers.withMessage('Confirm password must match with original password', sameAs(this.password)),
        },
        card_name: {
            requiredIf: helpers.withMessage("Please enter a card holder name",
                requiredIf(() => {
                    return this.billing_info == 'new' && this.payment_type == 'card'
                })),
            maxLength: helpers.withMessage('Max 50 characters allowed', maxLength(50)),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        },
        is_terms_accepted: {
            accept_terms: helpers.withMessage('Please agree with terms and conditions', sameAs(true)),
        }
    }
  },
  mounted() {
    const query_param_list = new URLSearchParams(window.location.search);
    const query_token = query_param_list.get('t');
    const query_product = query_param_list.get('p');
    const query_action = query_param_list.get('a');
    const query_is_admin_panel_login = query_param_list.get('u');
    if(!query_token || !query_product || !query_action || query_product != 'oshahc' || !this.action_type.includes(query_action) || !query_is_admin_panel_login || !this.login_type.includes(query_is_admin_panel_login)){
      window.location = JS_APP_URL + "/login";
    }else{
      this.query_token = query_token.trim();
      this.query_product = query_product.trim();
      this.query_action = query_action.trim();
      this.query_is_admin_panel_login = query_is_admin_panel_login.trim();
      this.stripeInit();
      this.initStripeSetupIntent(true);
      this.initStripeCardElements();
    }
  },

  directives: {
    uppercase: {
      update(el) {
        el.value = el.value.toUpperCase()
      }
    }
  },

  watch: {
    
  },

  methods: {
    stripeInit(){
      this.stripe_elements = stripe.elements({
            fonts: [
                {
                family: 'Proxima-Nova-L',
                src: 'url(https://hipaace.abyde.com/stripe_elements_fonts_2541896938763007482152019.php)'
                },
            ],
            loader: 'always',
            mode: 'setup',
            currency: 'usd',
            setupFutureUsage: 'off_session',
            paymentMethodTypes: ['card', 'us_bank_account'],
            paymentMethodOptions: {us_bank_account : {verification_method : 'instant'}},
            appearance:{
              theme: 'stripe'
            }
      });
    },
    async initStripeSetupIntent(is_first_call = false){
      NProgress.start();
      this.is_full_page_loader_shown = true;
      await axios
          .get(JS_APP_URL + "/signup/get-stripe-setup-intent")
          .then((response) => {
            if (response["data"]["status"] == "Success") {
              this.setup_intent_client_secret = response["data"]["data"]['setup_intent_client_secret'];
            }else{
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(()=> {
            if(is_first_call == false){
              NProgress.done();
              this.is_full_page_loader_shown = false;
            }else{
              setTimeout(() => {
                this.loadEmployeeLocationPricing();
              }, 100);
            }
          });
    },
    initStripeCardElements(){
      var card_el_inputs = document.querySelectorAll('.card_elements_container .input');
      Array.prototype.forEach.call(card_el_inputs, function(input) {
        input.classList.add('form-input')
        input.addEventListener('focus', function() {
          input.classList.add('focused');
          input.querySelector('.label').classList.add('label-float');
        });
        input.addEventListener('blur', function() {
          input.classList.remove('focused');
          input.querySelector('.label').classList.remove('label-float');
        });
        input.addEventListener('keyup', function() {
          if (input.value.length === 0) {
            input.classList.add('empty');
          } else {
            input.classList.remove('empty');
          }
        });
      });
      var StripeElementStyles = {
        base: {
          color: '#495057',
          fontWeight: 400,
          fontFamily: 'Proxima-Nova-L',
          fontSize: '14px',
          fontSmoothing: 'antialiased',
          '::placeholder': {
            color: '#495057',
          },
          ':-webkit-autofill': {
            color: '#495057',
          },
        },
        invalid: {
          color: '#495057',
          '::placeholder': {
            color: '#FFCCA5',
          },
        },
      };
      var StripeElementClasses = {
        focus: 'focused',
        empty: 'empty',
        invalid: 'invalid',
      };
      this.cardNumber = this.stripe_elements.create('cardNumber', {
        style: StripeElementStyles,
        classes: StripeElementClasses,
        placeholder: '',
      });
      this.cardNumber.mount('#card-number');
      this.cardExpiry = this.stripe_elements.create('cardExpiry', {
        style: StripeElementStyles,
        classes: StripeElementClasses,
        placeholder: '',
      });
      this.cardExpiry.mount('#card-expiration');
      this.cardCvc = this.stripe_elements.create('cardCvc', {
        style: StripeElementStyles,
        classes: StripeElementClasses,
        placeholder: '',
      });
      this.cardCvc.mount('#card-cvc');
    }, 
    showAdditionalProducts(){
      if(this.show_additional_products_modal){
        this.show_additional_products_modal = !this.show_additional_products_modal;
        setTimeout(() => {
              window.location = JS_APP_URL + "/login";
        }, 100);
      }else{
        this.resendEmailModalToggle(false);
        this.checkOtherProductsPurchased();
      }
    },
    checkOtherProductsPurchased(){
      NProgress.start();
      this.is_signup_btn_disabled = true;
      this.is_full_page_loader_shown = true;
        axios
      .post(JS_OSHA_HC_APP_URL + "/check-email-already-signup", {
        email: this.email
      })
      .then((response) => {
        if (response["data"]["status"] == "Error") {
          if(response["data"]['data'].length > 0){
            toastr.error(response["data"]['data'].join('</br>'), "Error");
          }else{
            toastr.error(response["data"]["message"], "Error");
          }
        } else {
          if(response["data"]['data']['is_availabe'] == 1){
            const is_found_product_index = _.findIndex(this.addition_product_list, (o) => { return o.id === 'oshahc'; });
            if(is_found_product_index >= 0){
              this.addition_product_list.splice(is_found_product_index, 1);
            }
          }
          if(this.addition_product_list.length > 0){
            this.show_additional_products_modal = !this.show_additional_products_modal;
          }else{
              toastr.error('Oops, You do not have any new products to purchase!', "Error");
              setTimeout(() => {
                    window.location = JS_APP_URL + "/login";
              }, 1000);
          }
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
      })
      .then(() => {
        NProgress.done();
        this.is_signup_btn_disabled = false;
        this.is_full_page_loader_shown = false;
      });
    },
    resendEmailModalToggle(redirect = true){
      this.show_resend_email_modal = !this.show_resend_email_modal;
      if(redirect == true){
        setTimeout(() => {
              window.location = JS_APP_URL + "/login";
        }, 100);
      }
    },
    togglePasswordVisibility(input_type){
      if(input_type == 'password'){
        this.password_field_type = (this.password_field_type == 'password')?'text':'password';
      }
      if(input_type == 'confirm_password'){
        this.confirm_password_field_type = (this.confirm_password_field_type == 'password')?'text':'password';
      }
    },
    loadEmployeeLocationPricing (){
      NProgress.start();
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/get-location-employee-pricing")
        .then((response) => {
           if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            }else{
              this.employee_pricing = response['data']["data"]['employee_pricing'];
              delete this.employee_pricing['3501+'];
              this.location_pricing = response['data']["data"]['location_pricing'];
            }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
        })
        .then(() => {
          this.loadUserExistingProductData();
        });
    },
    loadUserExistingProductData(){
       if(this.query_product == 'oshahc'){
         axios
           .get(JS_OSHA_HC_APP_URL + "/get-user-plan-information-for-product/" + this.query_token + "/hipaace")
           .then((response) => {
             if (response["status"] == "Error") {
                 toastr.error('Your signup link has been expired. Please try again!', "Error");
                 setTimeout(() => {
                       window.location = JS_APP_URL + "/login";
                 }, 1000);
             } else {
               if(Object.keys(response['data']['data']).length > 0){
                 this.first_name = response['data']['data']['first_name'];
                 this.last_name = response['data']['data']['last_name'];
                 this.company_name = response['data']['data']['company_name'];
                 this.phone_number = response['data']['data']['phone_number'];
                 this.email = response['data']['data']['email'];
                 this.selected_state = response['data']['data']['state'];
                 this.zip_code = response['data']['data']['zip_code'];
                 this.selected_location = response['data']['data']['user_plan']['location_limit'];
                 this.selected_employee = response['data']['data']['user_plan']['employee_limit'];
                 this.stripe_customer_id = response['data']['data']['stripe_customer_id'];
                 this.payment_plan = response['data']['data']['plan_type'];
                 this.reference_id = response['data']['data']['payment_source_data']['reference_id'];
                 this.payment_source_type = response['data']['data']['payment_source_data']['type'];
                 if((response['data']['data']['payment_source_data']['card']) && response['data']['data']['payment_source_data']['card'] != null){
                    this.stripe_payment_source_data = response['data']['data']['payment_source_data']['card'];
                 }else{
                    this.stripe_payment_source_data = response['data']['data']['payment_source_data']['bank_account'];
                 }
                 if(response['data']['data']['chargebee_customer_id'] !== undefined){
                  this.chargebee_customer_id = response['data']['data']['chargebee_customer_id'];
                 }
                 if(this.query_action == 'outside'){
                   if(response['data']['data']['promo_code']){
                    this.entered_promocode = response['data']['data']['promo_code'].toUpperCase();
                    //this.applyPromocode();
                   }
                 }
                 if (response['data']['data']['partner_reseller_id'] != null) {
                    this.partner_reseller_osha = response['data']['data']['reseller']
                 }
                 if (this.query_is_admin_panel_login == '1') {
                   this.confirm_password = this.password = response['data']['data']['pw'];
                 }
                 setTimeout(() => {
                   this.calculatePricing('initial');
                 }, 200);
               }else{
                 toastr.error('Your signup link has been expired. Please try again!', "Error");
                 setTimeout(() => {
                       window.location = JS_APP_URL + "/login";
                 }, 1000);
               }
             }
           })
           .catch((error) => {
             toastr.error('Your signup link has been expired. Please try again!', "Error");
             setTimeout(() => {
                   window.location = JS_APP_URL + "/login";
             }, 1000);
           })
           .then(() => {
             NProgress.done();
             this.is_full_page_loader_shown = false;
           });
       }
    },
    calculatePricing(call_from_action = '') {
      console.log(this.promocode_data)
      if(this.is_full_page_loader_shown == false){
        NProgress.start();
        this.is_full_page_loader_shown = true;
      }
      axios
          .post(JS_APP_URL + "/get-chargebee-price-estimation", {
            selected_location: this.selected_location,
            selected_employee: this.selected_employee.max_limit,
            payment_plan: this.payment_plan,
            selected_state: (!_.isEmpty(this.selected_state))?this.selected_state:'',
            zip_code: (this.zip_code.length == 5)?this.zip_code:'',
            entered_promocode: (call_from_action == 'apply_promo' || call_from_action == 'remove_promo' || call_from_action == 'initial' || !_.isEmpty(this.promocode_data)) ? this.entered_promocode : '',
            user_type: (this.partner_reseller_osha && Object.keys(this.partner_reseller_osha).length === 0 ) ? 'Normal' : 'Reseller',
          })
          .then((response) => {
              if (response["data"]["status"] == "Error") {
                if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                  if(!_.isUndefined(response["data"]['data']['error_type']) && response["data"]['data']['error_type'] == 'coupon'){
                    this.entered_promocode = '';
                    this.promocode_data = {};
                    this.calculatePricing('initial');
                  }else if (!_.isUndefined(response["data"]['data']['error_type']) && response["data"]['data']['error_type'] == 'zipcode'){
                    this.is_signup_btn_disabled = true;
                    toastr.error(response["data"]["message"], "Error");
                    this.selected_state =  {};
                    this.zip_code =  '';
                    this.calculatePricing('initial');
                  }else{
                    this.selected_state =  {};
                    this.zip_code =  '';
                  }
                  toastr.error(response["data"]["message"], "Error");
                }                
              }else{                
                this.transaction_fee = response["data"]['data']['transaction_fee'] / 100;
                this.total_price = (response["data"]['data']['total'] / 100);
                if(response["data"]['data']['taxes']){
                  this.sales_tax = response["data"]['data']['taxes'];
                }else{
                  this.sales_tax = [];
                }
                if(response["data"]['data']['discounts']){
                  this.promocode_data = response["data"]['data']['discounts'];
                }
              }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
          })
          .then(() => {
            NProgress.done();
            this.is_full_page_loader_shown = false;
          });
    },
    numberFormatter(){
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
      });
    },
    getFinalRegularPrice(){
      var regular_price = this.total_price;
      regular_price = regular_price - this.transaction_fee;
      if(!_.isEmpty(this.promocode_data)){
         regular_price = regular_price + (this.promocode_data.discount_amount / 100);
      }
      _.forEach(this.sales_tax, function(value) {
        regular_price = regular_price - (value.amount / 100);
      });
      return this.numberFormatter().format(regular_price);
    },
    getFinalPromocode(){
      return (!_.isEmpty(this.promocode_data))?this.promocode_data.id:'-';
    },
    getFinalTransactionFee(){
      return this.numberFormatter().format(this.transaction_fee);
    },
    getFinalSalesTaxAmount(sales_tax_amount){
      return this.numberFormatter().format(sales_tax_amount);
    },
    getFinalPaymentPrice(){
      return this.numberFormatter().format(this.total_price);
    },
    getFinalPaymentPlan(){
      return (this.payment_plan == 'monthly') ? 'Monthly' : (this.payment_plan == 'quarterly') ? 'Quarterly' : (this.payment_plan == 'biannually') ? 'Bi-Annually' : 'Annually';
    },
    getFinalPaymentPlanText() {
      return (this.payment_plan == 'monthly') ? '*12 Payments Annually' : (this.payment_plan == 'quarterly') ? '*Paid four times per year' : (this.payment_plan == 'biannually') ? '*Paid twice per year' : '';
    },
    applyPromocode(){
      if(this.entered_promocode != ''){
        this.calculatePricing('apply_promo');
      }else{
        toastr.error('Please enter a promo code!', 'Error!');
      }
    },
    removePromocode(){
      this.entered_promocode = '';
      this.promocode_data = {};
      this.calculatePricing('remove_promo');
    },
    paymentTypeChanged(payment_type){
      this.payment_type = payment_type;
      if(this.payment_type == 'bank'){
        this.card_name = '';
        this.cardNumber.clear();
        this.cardCvc.clear();
        this.cardExpiry.clear();
        if(this.stripe_payment_method != ''){
          this.initStripeSetupIntent();
        }
        this.stripe_payment_method = '';
      }else{
        if(this.stripe_payment_method != ''){
          this.initStripeSetupIntent();
        }
        this.stripe_payment_method = '';
        this.linked_bank_accnount_message = '';
      }
    },
    billingInfoChanged(billing_info){
      if(billing_info == 'new'){
        this.initStripeSetupIntent();
      }
      if(billing_info == 'same'){
        this.payment_type = 'card';
        this.card_name = '';
        this.cardNumber.clear();
        this.cardCvc.clear();
        this.cardExpiry.clear();
        this.stripe_payment_method =  '';
        this.linked_bank_accnount_message = '';
      }
      this.billing_info = billing_info;
    },
    async signupSubmit(){
      this.v$.$touch();
      const is_valid = await this.v$.$validate();
      if (is_valid) {
        NProgress.start();
        this.is_signup_btn_disabled = true;
        this.is_full_page_loader_shown = true;
        if(this.billing_info == 'new' ){
          if(this.payment_type == 'card'){
            var is_valid_Card_details = true;
            var card_el_inputs = document.querySelectorAll('.card_elements_container .input');
            Array.prototype.forEach.call(card_el_inputs, function(input) {
                if(input.classList.contains('empty')){
                    is_valid_Card_details = false;
                }
            });
            if(is_valid_Card_details == false){
                NProgress.done();
                this.is_signup_btn_disabled = false;
                this.is_full_page_loader_shown = false;
                toastr.error('Please enter valid card details', 'Error!');
                return false;
            }
            if(this.stripe_payment_method == ''){
                stripe.confirmCardSetup(
                    this.setup_intent_client_secret, {
                        payment_method: {
                            card: this.cardNumber,
                            billing_details: {
                              name: this.card_name
                            },
                        },
                    }
                    ).then((result) => {
                        if (result.error) {
                            NProgress.done();
                            this.is_signup_btn_disabled = false;
                            this.is_full_page_loader_shown = false;
                            toastr.error(result.error.message, 'Error!')
                        } else {
                            this.stripe_payment_method = result.setupIntent.payment_method
                            this.doSignup();
                        }
                    });
            }else{
                this.doSignup();
            }  
          }else{
            if (!this.stripe_payment_method) {
              NProgress.done();
              this.is_signup_btn_disabled = false;
              this.is_full_page_loader_shown = false;
              toastr.error('Please link your bank account!', 'Error!');
            } else {
              this.doSignup();
            }
          }
        }else{
          this.doSignup();
        }
      }
    },
    async addNewBank(){
      if(this.first_name == '' || this.last_name == '' || this.email == ''){
          toastr.error('Please enter First Name, Last Name and Email address before linking bank', 'Error!');
          return false;
        }
        if(this.stripe_payment_method != ''){
          await this.initStripeSetupIntent();
          this.stripe_payment_method = '';
        }
        this.is_full_page_loader_shown = true;
        stripe.collectBankAccountForSetup({
          clientSecret: this.setup_intent_client_secret,
          params: {
            payment_method_type: 'us_bank_account',
            payment_method_data: {
                billing_details: {
                    name: this.first_name + ' ' + this.last_name,
                    email: this.email,
                },
            },
          },
          expand: ['payment_method'],
        })
        .then(({setupIntent, error}) =>{
            if (error) {
              toastr.error(error.message, 'Error!')
              this.is_full_page_loader_shown = false;
            } else if (setupIntent.status === 'requires_payment_method') {
              toastr.error('Failed to link your bank account. Please try again!', 'Error!')
              this.is_full_page_loader_shown = false;
            } else if (setupIntent.status === 'requires_confirmation') {
              const last4 = setupIntent.payment_method.us_bank_account.last4;
              const bank_name = setupIntent.payment_method.us_bank_account.bank_name;
              stripe.confirmUsBankAccountSetup(this.setup_intent_client_secret)
              .then(({setupIntent, error}) =>{
                  if (error) {
                      toastr.error(error.message, 'Error!')
                      this.is_full_page_loader_shown = false;
                  } else if (setupIntent.status === "requires_payment_method") {
                      toastr.error('Failed to link your bank account. Please try again!', 'Error!')
                      this.is_full_page_loader_shown = false;
                  } else if (setupIntent.status === "succeeded") {
                      this.stripe_payment_method = setupIntent.payment_method
                      this.linked_bank_accnount_message = last4 + ' of ' + bank_name;
                      this.is_full_page_loader_shown = false;
                      toastr.success('Bank account linked successfully!', 'Success!');
                  } else if (setupIntent.next_action?.type === "verify_with_microdeposits") {
                      console.log('THHIS SHOULD NOT HAPPEN AS WE HAVE NOT ENABLED MICRO DEPOSIT VERIFICATRION');
                      this.is_full_page_loader_shown = false;
                  }
              });
            }
        });
    },
    doSignup(){
      let payment_method_type = this.payment_type;
      if(this.billing_info == 'same'){
        payment_method_type = this.payment_source_type;
      }
      axios
        .post(JS_APP_URL + "/signup/do-signup", {
          first_name: this.first_name,
          last_name: this.last_name,
          company_name: this.company_name,
          selected_state: this.selected_state,
          zip_code: this.zip_code,
          email: this.email,
          phone_number: this.phone_number,
          password: this.password,
          password_confirmation: this.confirm_password,
          payment_source_type:payment_method_type,
          stripe_payment_method: this.stripe_payment_method,
          plan_type: this.payment_plan,
          location_limit: this.selected_location,
          employee_limit: this.selected_employee,
          promo_code: (!_.isEmpty(this.promocode_data))?this.promocode_data.id:'',
          transaction_fee: this.transaction_fee,
          billing_info: this.billing_info,
          stripe_customer_id: this.stripe_customer_id,
          reference_id: this.reference_id,
          signup_call_type: this.query_action,
          timezone: moment.tz.guess(),
          partner_reseller_slug: this.partner_reseller_osha != null ? this.partner_reseller_osha.slug : null,
          chargebee_customer_id: this.chargebee_customer_id,
          is_admin_panel_login: this.query_is_admin_panel_login
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
              toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
              toastr.error(response["data"]["message"], "Error");
            }
          } else {
            toastr.success(response["data"]["message"], 'Success!');
            if(this.query_action == 'outside'){
              this.chargebee_invoice_id = response["data"]['data']['chargebee_invoice_id'];
              this.show_resend_email_modal = true;
            }else{
              setTimeout(() => {
                    window.location = JS_APP_URL + "/login";
              }, 1000);
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
        })
        .then(() => {
          NProgress.done();
          this.is_signup_btn_disabled = false;
          this.is_full_page_loader_shown = false;
        });
    }
  },
};
</script>
