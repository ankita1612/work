<template>
    <div>
      <header-business-associates-portal />
      <div class="container pt30 pb60">
        <div v-if="progress_step == 0 && JS_BUSINESS_ASSOCIATES_DATA && JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA">
          <div class="font-22 blueog--text font_bold line-normal text-center mb5">{{JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA.location.company_name}}</div>
          <div  class="font-24 font_light blueog--text line-normal text-center">Primary Address</div>
          <div class="font-22 blueog--text font_bold text-center mb20 line-normal">{{JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA.location.address+', ' +JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA.location.city+', '+JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA.location.state.state_name+', '+JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA.location.zip_code}}</div>
          <div style="max-width:752px; margin:0 auto;">
            <p class="font-16 text-999 text-center mb15 line-normal">
              {{JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA.location.company_name}} or one of its locations has identified {{JS_BUSINESS_ASSOCIATES_DATA.name}} as a Business Associate. According to the Department of Health and Human Services a business associate is a person or entity that performs certain functions or activities that involve the use or disclosure of protected health information on behalf of, or provides services to, a covered entity.
            </p>
            <p class="font-16 text-999 text-center mb15 line-normal">
              By law, the Privacy Rule allows {{JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA.location.company_name}} to disclose protected health information to these “business associates” if they obtain satisfactory assurances that the business associate will use the information only for the purposes for which it was engaged by {{JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA.location.company_name}}, will safeguard the information from misuse, and will help {{JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA.location.company_name}} comply with some of their duties under the Privacy Rule.
            </p>
            <p class="font-16 text-999 text-center mb50 line-normal">In compliance with Federal Regulation 45 CFR 164.504(e) business associates and covered entities must sign a contract or written arrangement. Click the Start button below to review, complete and sign {{JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA.location.company_name}}’s Business Associate Agreement.</p>
          </div>
          <div class="text-center">
            <button type="button"
              class="btn-primary mx-auto d-inline-block px30 mt-xs-20 mlr-auto" @click="startAgreementProcess()">
              Start 
              </button>
        </div>
        </div>
        <div class="font-22 blueog--text font_light line-normal text-center mb5" v-if="progress_step != 0 && progress_step != 4">{{JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA.location.company_name}}</div>
        <div v-if="progress_step != 0" class="font-24 font_semibold blueog--tex text-center mb15 line-normal">Business Associate Agreement</div>
        <p v-if="progress_step != 0" class="font-16 text-999 line-normal text-center mb20">Please review, sign and complete the Business Associate Agreement.</p>
        <div v-if="progress_step != 0" class="vendor-onboarding-steps ba-agreement-steps flex flex-wrap mlr-auto line-normal mb35">
            <button type="button" class="vendor-onboarding-step-item flex-auto" :class="{'active' : progress_step == 1}"><div class="font_semibold font-14">Step 1 </div><div class="font_light font-13">Review Agreement</div></button>
            <button type="button" class="vendor-onboarding-step-item flex-auto" :class="{'active' : progress_step == 2}"><div class="font_semibold font-14">Step 2 </div><div class="font_light font-13">Company Information</div></button>
            <button type="button" class="vendor-onboarding-step-item flex-auto" :class="{'active' : progress_step == 3}"><div class="font_semibold font-14">Step 3 </div><div class="font_light font-13">Create Signature</div></button>
            <button type="button" class="vendor-onboarding-step-item flex-auto" :class="{'active' : progress_step == 4}"><div class="font_semibold font-14">Step 4 </div><div class="font_light font-13">Complete Agreement</div></button>
        </div>
        <div v-if="progress_step == 1" class="vendor-onboarding-content mlr-auto mb29">
            <div class="row flex-auto -mx-10 items-center mb40">
                <div class="col-12 px10">
                  <iframe class="pdf-viewer" v-if="agreement_pdf_url_downloadebale!=''" :src="JS_APP_URL+'/pdfjs/web/viewer.html?file='+agreement_pdf_url_downloadebale" width="100%" height="600"></iframe>
                </div>
            </div>
            <div class="text-center flex justify-between">
               <button v-on:click="backStep()" type="button" class="btn-blue-outline btn-left-icon min-width-90">
                <div class="prev-arrow-icon"><previous-icon></previous-icon></div>back
              </button>
              <button  v-on:click="nextStep()" type="button" class="btn-blue-outline min-width-90">next
                <div class="next-arrow-icon"> <next-icon></next-icon></div>
              </button>
            </div>
        </div>
        <div v-if="progress_step == 2" class="ba-agreement-content mlr-auto mb28">
            <div class="row flex-auto -mx-10 mb25">
                <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10 mb-sm-20">
                      <div class="form-group mb-0" :class="{ 'form-group--error': v$.address.$errors.length }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.address.$errors.length }" type="text" id="address" name="address" v-model.trim="v$.address.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.address.$model }">Address</label>
                          <div v-if="v$.address.$errors.length > 0">
                            <div class="form-error-text">
                              {{ v$.address.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
                    <div class="col-12 col-md-6 col-lg-6 col-xl-4 px10">
                      <div class="form-group mb-0" :class="{ 'form-group--error': v$.city.$errors.length }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.city.$errors.length }" type="text" id="city" name="city" v-model.trim="v$.city.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.city.$model }">City</label>
                          <div v-if="v$.city.$errors.length > 0">
                            <div class="form-error-text">
                              {{ v$.city.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
                </div>
                <div class="row flex-auto -mx-10 justify-center mb60">
                  <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10 mb-md-20">
                      <div class="form-group mb-0" :class="{ 'form-group--error': v$.country.$errors.length }">
                          <multiselect
                          class="font-style-normal"
                          v-model.trim="country"
                          placeholder=""
                          :options="country_list"
                          track-by="country_code"
                          label="country_name"
                          :multiple="false"
                          :close-on-select="true"
                          position="bottom"
                          :showLabels="false"
                          :taggable="false"
                          @update:model-value="onChangeCountryOption"
                          :class="{ 'form-error': v$.country.$errors.length }"
                          :allowEmpty="false">
                          <template #noResult>
                            <div class="multiselect__noResult text-center">No results found</div>
                          </template>
                          </multiselect>
                          <label class="label label-select" :class="{ 'label-float': (v$.country.$model) }">Country</label>
                          <div v-if="v$.country.$errors.length > 0">
                            <div class="form-error-text">
                              {{ v$.country.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10 mb-md-20">
                      <div v-if="!is_state_dropdown" class="form-group mb-0" :class="{ 'form-group--error': v$.state.$errors.length }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.state.$errors.length }" type="text" id="state" name="state" v-model.trim="v$.state.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.state.$model }">State</label>
                          <div v-if="v$.state.$errors.length > 0">
                            <div class="form-error-text">
                              {{ v$.state.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                       <div v-if="is_state_dropdown" class="form-group mb-0" :class="{ 'form-group--error': v$.state_id.$errors.length }">
                          <multiselect
                          class="font-style-normal"
                          v-model.trim="state_id"
                          placeholder=""
                          :options="all_state_list"
                          track-by="id"
                          label="state_name"
                          :multiple="false"
                          :close-on-select="true"
                          position="bottom"
                          :showLabels="false"
                          :taggable="false"
                          :class="{ 'form-error': v$.state_id.$errors.length }"
                          :allowEmpty="false">
                          <template #noResult>
                            <div class="multiselect__noResult text-center">No results found</div>
                          </template>
                          </multiselect>
                          <label class="label label-select" :class="{ 'label-float': (v$.state_id.$model) }">State</label>
                          <div v-if="v$.state_id.$errors.length > 0">
                            <div class="form-error-text">
                              {{ v$.state_id.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10 mb-sm-20">
                      <div class="form-group mb-0" :class="{ 'form-group--error': v$.zip_code.$errors.length }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.zip_code.$errors.length }" type="text" id="zip_code" name="zip_code" v-mask="'00000'" @click.right.prevent @copy.prevent @paste.prevent v-model.trim="v$.zip_code.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.zip_code.$model }">Zip Code</label>
                          <div v-if="v$.zip_code.$errors.length > 0">
                            <div class="form-error-text">
                              {{ v$.zip_code.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10">
                      <div class="form-group mb-0" :class="{ 'form-group--error': v$.fax_no.$errors.length }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.fax_no.$errors.length }" type="text" id="fax_no" name="fax_no" v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent v-model.trim="v$.fax_no.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.fax_no.$model }">Fax Number</label>
                          <div v-if="v$.fax_no.$errors.length > 0">
                            <div class="form-error-text">
                              {{ v$.fax_no.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
            </div>
            <div class="text-center flex justify-between">
               <button v-on:click="backStep()" type="button" class="btn-blue-outline btn-left-icon min-width-90">
                <div class="prev-arrow-icon"><previous-icon></previous-icon></div>back
              </button>
              <button v-on:click="nextStep()" type="button" class="btn-blue-outline min-width-90">next
                <div class="next-arrow-icon"> <next-icon></next-icon></div>
              </button>
            </div>
        </div>
        <div v-if="progress_step == 3" class="ba-agreement-content mlr-auto mb28">
            <div class="row flex-auto -mx-10 justify-center mb40">
                <div class="col-12 col-md-6 col-lg-6 col-xl-5 px10">
                    <div class="form-group" :class="{ 'form-group--error': v$.signature.$errors.length }">
                        <input class="form-input location-input-box preveiw-signature-input-box" :class="{ 'form-error': v$.signature.$errors.length }" type="text" name="signature" v-model.trim="v$.signature.$model">
                        <label class="label location-input-label" :class="{ 'label-float': v$.signature.$model }">Signee Name</label>
                        <div v-if="v$.signature.$errors.length > 0">
                          <div class="form-error-text">
                            {{ v$.signature.$errors[0].$message }}
                          </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6 col-xl-5 px10">
                    <div class="form-group" :class="{ 'form-group--error': v$.signature_title.$errors.length }">
                        <input class="form-input location-input-box preveiw-signature-input-box" :class="{ 'form-error': v$.signature_title.$errors.length }" type="text" name="signature_title" v-model.trim="v$.signature_title.$model">
                        <label class="label location-input-label" :class="{ 'label-float': v$.signature_title.$model }">Signee Title</label>
                        <div v-if="v$.signature_title.$errors.length > 0">
                          <div class="form-error-text">
                            {{ v$.signature_title.$errors[0].$message }}
                          </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10">
                    <div class="form-group mb-0 ba-signature-prev">
                      <input disabled="disabled" v-bind:value="signature" class="form-input preveiw-signature-input font-bold text-center" type="text" name="first_name">
                      <label class="label ba-signature-label" :class="{ 'label-float': v$.signature.$model }">Signature Preview</label>
                    </div>
                </div>
            </div>
            <div class="text-center flex justify-between">
               <button v-on:click="backStep()" type="button" class="btn-blue-outline btn-left-icon min-width-90">
                <div class="prev-arrow-icon"><previous-icon></previous-icon></div>back
              </button>
              <button v-on:click="nextStep()" type="button" class="btn-blue-outline min-width-90">next
                <div class="next-arrow-icon"> <next-icon></next-icon></div>
              </button>
            </div>
        </div>
        <div v-if="progress_step == 4" class="vendor-onboarding-content mlr-auto mb28">
            <div class="row flex-auto -mx-10 items-center mb20">
                <div class="col-12 px10">
                  <iframe v-if="agreement_pdf_url!=''" :src="JS_APP_URL+'/pdfjs/web/viewer.html?file='+agreement_pdf_url" width="100%" height="600"></iframe>
                </div>
            </div>
            <div class="text-center">
              <button  v-on:click="downloadAgreement" type="button" class="btn-blue-outline btn-left-padding ba-download-btn">
                <div class="next-arrow-icon pdf-icon"> <pdf-icon></pdf-icon></div>
                download</button>
                <button v-on:click="redirectToAbyde(JS_WORDPRESS_URL)" type="button" class="btn btn-blue mx5 complete_btn">
              complete</button>
            </div>
        </div>
          <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
        <download-agreement-modal v-if="is_downloadagreementmodal_shown" :agreement_pdf_url_downloadebale="agreement_pdf_url_downloadebale"></download-agreement-modal>
      </div>
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, maxLength, minLength, requiredIf, helpers } from "@vuelidate/validators";
import nextIcon from '../../common/icons/nextIcon.vue';
import previousIcon from "../../common/icons/previousIcon.vue";
import pdfIcon from '../../common/icons/pdfIcon.vue';
import fullPageLoader from '../../common/fullPageLoader.vue';
import downloadAgreementModal from '../agreement/downloadAgreementModal.vue';
import headerBusinessAssociatesPortal from '../../common/includes/headerBusinessAssociatesPortal.vue';
import {checkSpecialChars, checkSpecialCharsErrorMessage, checkSpecialCharsForAddress, checkSpecialCharsForAddressErrorMessage}  from "../../common/customValidation";
import _ from 'lodash';

export default {
  data() {
    return {
      signature: '',
      signature_title:'',
      progress_step: 0,
      address:'',
      city:'',
      zip_code:'',
      fax_no:'',
      country:'',
      country_list:[],
      state:'',
      state_id:'',
      all_state_list:[],
      is_state_dropdown:false,
      agreement_pdf_url: '',
      agreement_pdf_url_downloadebale: '',
      is_full_page_loader_shown: false,
      is_downloadagreementmodal_shown: false,
      JS_BUSINESS_ASSOCIATES_ID: JS_BUSINESS_ASSOCIATES_ID,
      JS_REF_TOKEN: JS_REF_TOKEN,
      JS_BUSINESS_ASSOCIATES_DATA: JS_BUSINESS_ASSOCIATES_DATA,
      JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA: JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA,
	    JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      checkSpecialCharsErrorMessage,
      checkSpecialCharsForAddressErrorMessage: checkSpecialCharsForAddressErrorMessage 
    };
  },
  components: {
    nextIcon,
    pdfIcon,
    fullPageLoader,
    downloadAgreementModal,
    headerBusinessAssociatesPortal,
    previousIcon
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
     address: {
        required: helpers.withMessage("Please enter an address", required),
        checkSpecialCharsForAddress: helpers.withMessage(checkSpecialCharsForAddressErrorMessage, checkSpecialCharsForAddress),
        maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
      },
      city: {
        required: helpers.withMessage("Please enter a city", required),
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
      },
      zip_code: {
        required: helpers.withMessage("Please enter a zip code", required),
        minLength: helpers.withMessage("Please enter a valid zip code", minLength(5)),
        maxLength: helpers.withMessage("Please enter a valid zip code", maxLength(5)),
      },
      fax_no: {
        minLength: helpers.withMessage("Please enter a valid fax number", minLength(12)),
        maxLength: helpers.withMessage("Please enter a valid fax number", maxLength(12)),
      },
      country: {
        required: helpers.withMessage("Please select a country", required),
      },
      state:{
        required: helpers.withMessage("Please enter a state", requiredIf(() => {
          return !this.is_state_dropdown
        })),
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
      },
      state_id:{
        required: helpers.withMessage("Please select a state", requiredIf(() => {
          return this.is_state_dropdown
        }))
      }
    };
    if(this.progress_step == 3){
      validationArray.signature = {
        required: helpers.withMessage("Please enter a Signee name", required),
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
      };
      validationArray.signature_title = {
        required: helpers.withMessage("Please enter a Signee title", required),
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
      };
    }
    return validationArray;
  },
  mounted() {
    if(!JS_BUSINESS_ASSOCIATES_DATA || !JS_BUSINESS_ASSOCIATES_AGREEMENT_DATA){
      this.is_full_page_loader_shown = true;
      toastr.error("Seems like your agreement link has been expired!. Please contact support.", "Error");
      setTimeout(() => {
        this.is_full_page_loader_shown = false;
        window.location = JS_APP_URL + "/login";
      }, 1500);
    }
    this.stepChanged();
  },
  watch: {
    progress_step(newVal, oldVal){
      this.stepChanged();
    }
  },
  computed: {
  },
  methods: {
    redirectToAbyde(abyde_url){
      window.location = abyde_url;
    },
    startAgreementProcess(){
      this.progress_step++;
    },
    backStep(){
      this.progress_step--;
    },
    nextStep(){
      if(this.progress_step == 2 || this.progress_step == 3){
        this.v$.$touch();
        if (!this.v$.$invalid) {
          this.progress_step++;
          if(this.signature != '' || this.signature_title != ''){
            this.v$.$touch();
          }
        }
      }else{
        this.progress_step++;
      }
    },
    stepChanged(){
      if(this.progress_step == 4 || (this.agreement_pdf_url == '' && this.progress_step == 0)){
        this.is_full_page_loader_shown = true;
        var request_obj = {
          business_associates_id: this.JS_BUSINESS_ASSOCIATES_ID,
          ref_token: this.JS_REF_TOKEN,
        };
        if(this.progress_step == 4){
          request_obj['signature'] = this.signature;
          request_obj['signature_title'] = this.signature_title;
          request_obj['address'] = this.address;
          request_obj['city'] = this.city;
          request_obj['zip_code'] = this.zip_code;
          request_obj['fax_no'] = this.fax_no;
          request_obj['country'] = this.country;
          if(!this.is_state_dropdown){
            request_obj['state'] = this.state;
          }else{
            request_obj['state'] = this.state_id;
          }
        }
        axios
        .post(JS_APP_URL + "/businessassociatesportal/get-agreement-data",request_obj)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.agreement_pdf_url = response['data']['data']['agreement_pdf_url'];
            this.agreement_pdf_url_downloadebale = response['data']['data']['agreement_pdf_url_downloadebale'];
            this.country_list = response['data']['data']["countries"];
            if(response['data']['data']['business_associates_agreement']['signature'] && response['data']['data']['business_associates_agreement']['file_name'] && this.progress_step == 4){
              toastr.success('Business Associate Agreement Completed.');
            }
            if(response['data']['data']['business_associates_agreement']['signature'] && response['data']['data']['business_associates_agreement']['file_name'] && this.progress_step == 0){
              this.is_downloadagreementmodal_shown = true;
            }
            if(this.progress_step == 0){
              let usa_country = _.find(
                  this.country_list, (o) => {
                    return o.country_code == "US";
                  }
              );
              this.country = usa_country;
              this.onChangeCountryOption();
            }
          }else{
            setTimeout(() => {
              window.location = JS_APP_URL + "/login";
            }, 1500);
          }
        })
        .catch((error) => {
        })
        .then(() => {
          setTimeout(() => {
            this.is_full_page_loader_shown = false;
          }, 200);
        });
      }
    },
    downloadAgreement(){
      var link = document.createElement("a");
      link.href = this.agreement_pdf_url_downloadebale;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    },
    onChangeCountryOption(){
       if(this.country.country_code == "US"){
          axios
          .get(JS_APP_URL + "/businessassociatesportal/get-state-list")
          .then((response) =>{
              if(response["data"]["status"] == "Success") {
                  this.all_state_list = response["data"]["data"];
                  this.is_state_dropdown = true;
              }
          })
          .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                  window.location = JS_APP_URL + "/login";
              }
          });
        }else{
          this.is_state_dropdown = false;
          this.state_id = '';
          this.state = '';
        }
    }
  },
};
</script>
