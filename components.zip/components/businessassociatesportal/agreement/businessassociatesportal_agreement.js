import { createApp } from "vue";
import agreement from "./agreement.vue";
import VueMask from '@devindex/vue-mask';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import InfiniteLoading from "v3-infinite-loading";
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.css';

const agreement_app = createApp(agreement);
agreement_app.use(FloatingVue);
agreement_app.use(VueMask);
agreement_app.component('InfiniteLoading', InfiniteLoading);
agreement_app.component('multiselect', Multiselect);
agreement_app.mount("#agreement_app");