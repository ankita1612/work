<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
            <button v-on:click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb15 mt10">
                <img :src="JS_APP_URL + '/images/abyde_a.svg'" class="abyde-signup-logo" alt="" title="" />
            </div>
            <h2 class="font-24 blueog--text line-normal text-center mb20">
                <span class="font-24 font_semibold blueog--text">
                Time to Make HIPAA Compliance Stress-free!
                </span>
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb25">
                If you’re a current Abyde user, simply exit out of this popup <br class="hidden-sm hidden-md"/> and log in to your OSHA HC account. Then click the ‘ADD PRODUCT’ <br class="hidden-sm hidden-md"/> link located in the top menu dropdown to sign up from<br class="hidden-sm hidden-md"/> within the software.
            </p>
            <p class="text-center font-16 text-999 gray_checkmark--text line-normal mb25">
            If you’re a totally new user, click the button below to go to <br class="hidden-sm hidden-md"/> our pricing and sign up page!
            </p>
            <div class="flex flex-wrap items-center justify-center pb10">
                <button @click="ok()" class="btn-primary h-32 mx5 btn-new-signup">NEW USER SIGN UP</button>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from '../common/icons/closeIcon.vue';
export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      JS_SUPPORT_EMAIL: SUPPORT_EMAIL,
    };
  },
  components:{
    closeIcon
  },
  emits: ["close-model"],
  methods: {
    ok() {
      window.location = JS_WORDPRESS_URL + '/signup'
    },
    closeModal() {
      this.$emit("close-model", false);
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
