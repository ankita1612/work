import { createApp } from 'vue'
import VueMask from '@devindex/vue-mask';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import login from "./login.vue";

const app = createApp(login);
app.use(VueMask);
app.use(FloatingVue);
app.mount('#login_app');
