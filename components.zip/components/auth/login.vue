<template>
  <div class="flex flex-col flex-auto min-fill-height">
    <header-before-login></header-before-login>
    <div class="flex-auto blueog">
      <div class="container fill-height">
        <div class="row">
          <div class="col-12 col-md-12 col-lg-6 col-xl-6">
            <div class="sign-in-left fill-height flex justify-end">
              <h1 class="login-left-title text-right white--text font-60 mb0">
                <span class="font_light font-300">Never Stress Over</span>
                <br /><span class="font-70 font_bold font-700">HIPAA </span>
                <span class="font_light font-300">Again.</span>
              </h1>
            </div>
          </div>
          <div class="col-12 col-md-12 col-lg-6 col-xl-6">
            <div class="sign-in-box white mt38 mb40 pt38 pb30 px38">
              <div class="text-center sign-in-icon mlr-auto pb34 mb15">
                <img :src="JS_APP_URL + '/images/abyde_a.svg'" alt="" title="" />
              </div>
              <div v-if="!is_verification_otp_form_shown">
              <h2
                class="
                  font-40 font_semibold
                  blueog--text
                  mb8
                  text-center
                  lh-1
                "
              >
                Sign In
              </h2>
              <h4
                class="
                  signup-abyde-text
                  font-18
                  gray_checkmark--text
                  text-center
                  line-normal
                  mb30
                  font_semibold
                "
              >
                Or
                <a
                  rel="noreferrer"
                  class="blueog--text cursor-pointer"
                  v-on:click="hipaaSignupToggle"
                  >Sign Up</a
                >
                for Abyde
              </h4>
              <form @submit.prevent="loginSubmit">
                <div
                  class="form-group"
                  :class="{ 'form-group--error': v$.email.$error }"
                >
                  <input
                    class="form-input sign-in-input"
                    :class="{ 'form-error': v$.email.$error }"
                    id="email"
                    name="email"
                    v-model.trim="v$.email.$model"
                    type="text"
                  />
                  <label class="label" :class="{ 'label-float': v$.email.$model }"
                    >Email Address</label
                  >
                  <div v-if="v$.email.$errors.length > 0">
                    <div class="form-error-text">
                        {{ v$.email.$errors[0].$message }}
                    </div>
                  </div>
                </div>
                <div
                  class="form-group"
                  :class="{ 'form-group--error': v$.password.$error }"
                >
                  <input
                    class="form-input sign-in-input sign-pass-input"
                    :class="{ 'form-error': v$.password.$error }"
                    id="password"
                    name="password"
                    v-model.trim="v$.password.$model"
                    :type="password_field_type"
                  />
                  <label
                    class="label"
                    :class="{ 'label-float': v$.password.$model }"
                    >Password</label
                  >
                  <div v-if="v$.password.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.password.$errors[0].$message }}
                        </div>
                  </div>
                  <button v-on:click="togglePasswordVisibility()" type="button" class="cursor-pointer pass-eye-icon pass-eye-icon-login">
                    <img v-if="password_field_type == 'password'" :src="JS_APP_URL + '/images/eye.svg'" alt="" title="" />
                    <img v-if="password_field_type == 'text'" :src="JS_APP_URL + '/images/eye-closed.svg'" alt="" title="" />
                  </button>
                </div>
                <div class="text-center pt10">
                  <button
                    :disabled="disable_signin_btn"
                    type="submit"
                    class="btn-primary mlr-auto"
                  >
                    <span>Log In</span>
                  </button>
                </div>
                <p class="text-center font-14 mb0 mt5">
                  <button
                    v-on:click="forgotPasswordToggle"
                    type="button"
                    class="font-14 font_semibold cursor-pointer blueog--text forgot-link"
                  >
                    Forgot Password?
                  </button>
                  <a :href="JS_APP_URL + '/employeeportal/login'" class="font-14 font_semibold green--text d-block mt5 text-decoration-underline">
                      Log in to your Abyde Employee portal
                  </a>
                </p>
              </form>
                </div>
                  <div v-else>
                    <form @submit.prevent="verifyOtpSubmit" class="">
                      <p class="font-21 blueog--text line-normal text-center mb34">Please enter the verification code <br/> that was sent to your email below. </p>
                      <div class="form-group mb-0" :class="{ 'form-group--error': v$.verfication_otp.$error }">
                        <input
                          class="form-input sign-in-input"
                          :class="{ 'form-error': v$.verfication_otp.$error }"
                          id="verfication_otp"
                          name="verfication_otp"
                          v-model.trim="v$.verfication_otp.$model"
                          type="text"
                          v-mask="'0-0-0-0'"
                        />
                        <label class="label" :class="{ 'label-float': v$.verfication_otp.$model }"
                          >Verification Code</label
                        >
                        <div v-if="v$.verfication_otp.$errors.length > 0">
                          <div class="form-error-text">
                            {{ v$.verfication_otp.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                      <div class="font-16 font-italic font_light gray2--text text-center mt17">Code is valid for 30 minutes or 5 attempts</div>
                      <div class="flex items-center flex-wrap justify-center verification-buttons pt50">
                        <VTooltip class="text-center" v-if="disable_resend_btn" :triggers="['hover']"  :popperTriggers="['hover']">
                            <button
                              type="button"
                              class="btn-cancel-outline mx4"
                              disabled="disabled"
                            >
                              <span>Resend code</span>
                            </button>
                            <template #popper>
                                <div class="white--text font-12 font_semibold mb2 text-center">You can resend code after 1 minute.</div>
                            </template>
                        </VTooltip>
                        <button
                          v-if="!disable_resend_btn"
                          type="button"
                          class="btn-cancel-outline mx4"
                          :disabled="disable_signin_btn"
                          v-on:click="resendOtpSubmit()"
                        >
                          <span>Resend code</span>
                        </button>
                        <button
                          type="submit"
                          class="btn-primary mx4"
                          :disabled="disable_signin_btn"
                        >
                          <span>Verify</span>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
          </div>
        </div>
      </div>
      <forgotpasswordmodal
        v-if="is_forgotpasswordmodal_shown"
        @close-model="forgotPasswordToggle"
      ></forgotpasswordmodal>
      <hipaasignupmodal
        v-if="is_hipaasignupmodal_shown"
        @close-model="hipaaSignupToggle"
      ></hipaasignupmodal>
      <resetpasswordmodal
        v-if="is_resetpasswordmodal_shown"
        :verification_code="reset_password_verification_code"
        :user_id="reset_password_user_id"
        :account_type="reset_password_account_type"
        :action_type="reset_password_action_type"
        @close-model="resetPasswordToggle"
      ></resetpasswordmodal>
      <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
    <footer-before-login :is_reseller="'no'"></footer-before-login>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, email, helpers, requiredIf, minLength, maxLength } from "@vuelidate/validators";
import forgotpasswordmodal from "./forgotpasswordmodal.vue";
import hipaasignupmodal from "./hipaasignupmodal.vue";
import resetpasswordmodal from "./resetpasswordmodal.vue";
import fullPageLoader from '../common/fullPageLoader.vue';
import headerBeforeLogin from "../common/includes/headerBeforeLogin.vue";
import footerBeforeLogin from "../common/includes/footerBeforeLogin.vue";
import moment from "moment-timezone";
export default {
  data() {
    return {
      email: "",
      password: "",
      verfication_otp: "",
      password_field_type: 'password',
      disable_signin_btn: false,
      is_forgotpasswordmodal_shown: false,
      is_hipaasignupmodal_shown: false,
      is_resetpasswordmodal_shown: false,
      reset_password_verification_code: '',
      reset_password_user_id: '',
      reset_password_account_type: '',
      reset_password_action_type: '',
      account_verification_code: '',
      account_verification_user_id: '',
      is_full_page_loader_shown: false,
      is_verification_otp_form_shown: false,
      disable_resend_btn: true,
      user_login_id: '',
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  setup: () => ({ v$: useVuelidate() }),
  components: {
    forgotpasswordmodal,
    resetpasswordmodal,
    fullPageLoader,
    headerBeforeLogin,
    footerBeforeLogin,
    hipaasignupmodal
  },
  validations() {
    var validationsArr = {};
    if (!this.is_verification_otp_form_shown) {
        validationsArr.email = {
            required: helpers.withMessage('Please enter an email', required),
            email: helpers.withMessage('Please enter a valid email', email),
            maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
        },
            validationsArr.password = {
                required: helpers.withMessage('Please enter a password', required),
            };
    } else {
        validationsArr.verfication_otp = {
            required: helpers.withMessage('Please enter a verification code', required),
            minLength: helpers.withMessage('Please enter a valid verification code', minLength(7)),
            maxLength: helpers.withMessage('Please enter a valid verification code', maxLength(7)),
        };
    }
    return validationsArr;
  },
  mounted() {
    if(JS_VERIFICATION_CODE && JS_USER_ID && JS_ACCOUNT_TYPE){
      this.reset_password_verification_code = JS_VERIFICATION_CODE;
      this.reset_password_user_id = JS_USER_ID;
      this.reset_password_account_type = JS_ACCOUNT_TYPE;
      setTimeout(() => {
        this.checkValidResetPasswordRequest();
      }, 100);
    }
    else if(JS_VERIFICATION_CODE && JS_USER_ID){
      this.account_verification_code = JS_VERIFICATION_CODE;
      this.account_verification_user_id = JS_USER_ID;
      setTimeout(() => {
        this.checkAccountVerificationRequest();
      }, 100);
    }
  },

  watch: {},

  computed: {},

  methods: {
    async loginSubmit() {
      this.v$.$touch();
      const is_valid = await this.v$.$validate()
      if (is_valid) {
        NProgress.start();
        this.disable_signin_btn = true;
        axios
          .post(JS_APP_URL + "/login", {
            email: this.email,
            password: this.password
          })
          .then((response)=> {
            if (response["data"]["status"] == "Error") {
                if (response["data"]['data'].length > 0) {
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                } else {
                    toastr.error(response["data"]["message"], "Error");
                }
            } else {
              if (!response["data"]['data']['user_login_id']) {
                setTimeout(() => {
                  window.location = JS_APP_URL + "/dashboard";
                }, 500);
              }
              else {
                this.is_verification_otp_form_shown = true;
                this.user_login_id = response["data"]['data']['user_login_id'];
                toastr.success(response["data"]["message"], "Success");
                setTimeout(() => {
                  this.disable_resend_btn = false;
                }, 60000);
              }
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
          })
          .then(() => {
            NProgress.done();
            this.disable_signin_btn = false;
          });
      }
    },
    async verifyOtpSubmit() {
        this.v$.$touch();
        if (!this.v$.$invalid) {
            NProgress.start();
            this.disable_signin_btn = true;
            axios
                .post(JS_APP_URL + "/verify-otp", {
                    user_login_id: this.user_login_id,
                    verfication_otp: this.verfication_otp,
                    timezone: moment.tz.guess()
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if (response["data"]['data'].length > 0) {
                            toastr.error(response["data"]['data'].join('</br>'), "Error");
                        } else {
                            toastr.error(response["data"]["message"], "Error");
                        }
                        this.verfication_otp = '';
                    } else {
                        setTimeout(() => {
                            window.location = JS_APP_URL + "/dashboard";
                        }, 500);
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                })
                .then(() => {
                    NProgress.done();
                    this.disable_signin_btn = false;
                });
        }
    },
    resendOtpSubmit() {
        NProgress.start();
        this.disable_signin_btn = true;
        axios
            .post(JS_APP_URL + "/resend-otp", {
                user_login_id: this.user_login_id
            })
            .then((response) => {
                if (response["data"]["status"] == "Error") {
                    if (response["data"]['data'].length > 0) {
                        toastr.error(response["data"]['data'].join('</br>'), "Error");
                    } else {
                        toastr.error(response["data"]["message"], "Error");
                    }
                } else {
                    this.disable_resend_btn = true;
                    toastr.success(response["data"]["message"], "Success");
                    setTimeout(() => {
                        this.disable_resend_btn = false;
                    }, 60000);
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
            })
            .then(() => {
                NProgress.done();
                this.disable_signin_btn = false;
            });
    },
    forgotPasswordToggle(status = true) {
      this.is_forgotpasswordmodal_shown = status;
    },
    hipaaSignupToggle(status = true) {
      this.is_hipaasignupmodal_shown = status;
    },
    checkValidResetPasswordRequest () {
      if (this.reset_password_verification_code && this.reset_password_user_id && this.reset_password_account_type) {
        this.is_full_page_loader_shown = true;
        axios
          .post(JS_APP_URL + "/reset-password-verify-token", {
            verification_code: this.reset_password_verification_code,
            user_id: this.reset_password_user_id,
            account_type: this.reset_password_account_type,
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              toastr.error("Uh oh, your password reset link has expired! Please try again.", "Error");
              setTimeout(() => {
                window.location = JS_APP_URL + "/login";
              }, 1500);
            } else {
              this.reset_password_action_type = response["data"]["data"]['action_type'];
              setTimeout(() => {
                this.resetPasswordToggle();
              }, 100);
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
          })
          .then(() => {
            this.is_full_page_loader_shown = false;
          });
      }
    },
    resetPasswordToggle(status = true) {
      this.is_resetpasswordmodal_shown = status;
    },
    checkAccountVerificationRequest(){
      if (this.account_verification_code && this.account_verification_user_id) {
        this.is_full_page_loader_shown = true;
        axios
          .post(JS_APP_URL + "/account-verification", {
            verification_code: this.account_verification_code,
            user_id: this.account_verification_user_id
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              toastr.success(response["data"]["message"], "Success");
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
          })
          .then(() => {
            this.is_full_page_loader_shown = false;
            setTimeout(() => {
              window.location = JS_APP_URL + "/login";
            }, 2000);
          });
      }
    },
    togglePasswordVisibility(){
      this.password_field_type = (this.password_field_type == 'password')?'text':'password';
    },
  },
};
</script>
