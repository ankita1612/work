<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
            <button v-if="!disable_forgotpassword_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb30 pt20">
                <img :src="JS_APP_URL + '/images/pass_lock.svg'" alt="" title="" />
            </div>
            <h2
                class="
                font-24 font_semibold
                blueog--text
                line-normal
                mb30
                text-center
                "
            >
                Forgot password?
            </h2>
            <div class="modal-body">
                <form @submit.prevent="forgotPasswordSubmit" class="reset-form">
                <div
                    class="form-group"
                    :class="{ 'form-group--error': v$.email.$error }"
                >
                    <input
                    class="form-input"
                    :class="{ 'form-error': v$.email.$error }"
                    id="email"
                    name="email"
                    v-model.trim="v$.email.$model"
                    type="text"
                    />
                    <label class="label" :class="{ 'label-float': v$.email.$model }"
                    >Email Address</label
                    >
                    <div v-if="v$.email.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.email.$errors[0].$message }}
                        </div>
                    </div>
                </div>
                <div class="text-center pt10">
                    <button
                    :disabled="disable_forgotpassword_btn"
                    type="submit"
                    class="btn-primary mlr-auto reset-pass-btn"
                    >
                    <span>RESET PASSWORD</span>
                    </button>
                </div>
                </form>
            </div>
            <p class="font-18 gray_checkmark--text text-center mt20 mb16">
                Not a current customer?
                <a
                rel="noreferrer"
                :href="JS_WORDPRESS_URL + '/signup'"
                target="_blank"
                class="blueog--text"
                >Sign up</a
                >
                for Abyde.
            </p>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';//app.use(useVuelidate);
import { required, email, maxLength, helpers } from "@vuelidate/validators";
import closeIcon from '../common/icons/closeIcon.vue';

export default {
  data() {
    return {
      email: "",
      disable_forgotpassword_btn: false,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  setup: () => ({ v$: useVuelidate() }),
  components:{
    closeIcon
  },
  emits: ["close-model"],
  validations() {
    return {
        email: {
            required: helpers.withMessage('Please enter an email', required),
            email: helpers.withMessage('Please enter a valid email', email),
            maxLength: helpers.withMessage("Max 100 characters allowed",maxLength(100)),
        },
    }
  },
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
    async forgotPasswordSubmit() {
      this.v$.$touch();
      const is_valid = await this.v$.$validate()
      if (is_valid) {
        NProgress.start();
        this.disable_forgotpassword_btn = true;
        axios
          .post(JS_APP_URL + "/forgot-password", {
            email: this.email,
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              toastr.success(response["data"]["message"], "Success");
              this.$parent.is_forgotpasswordmodal_shown = false;
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
          })
          .then(() => {
            NProgress.done();
            this.disable_forgotpassword_btn = false;
          });
      }
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.disable_forgotpassword_btn) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
