<template>
  <div class="flex flex-col flex-auto min-fill-height">
    <hipaaChallengeHeader :partner_info="{}" />
    <div class="main-content flex-auto">
      <div class="container">
        <div class="hipaa-map-block">
          <div>
            <h3 class="font_semibold text-center blueog--text font-26 mt20 mb6">
              We're looking forward to speaking with you!
            </h3>
            <h4 class="font_light text-center blueog--text font-20 mb20">
              To schedule your 15 minute review, please pick your state.
            </h4>
            <div id="map" style="height: 400px"></div>
          </div>
        </div>
      </div>
    </div>
    <hipaa-challenge-footer />
  </div>
</template>

<script>
import jsVectorMap from "jsvectormap";
import "./maps/us-aea-en";
import hipaaChallengeHeader from "./hipaaChallengeHeader.vue";
import hipaaChallengeFooter from './hipaaChallengeFooter.vue'
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from "lodash";

export default {
  components: {
    hipaaChallengeHeader,
    hipaaChallengeFooter
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      selectedStateCode: "",
      all_state_list: [],
    };
  },
  mounted() {
    this.generateUSGraph();
    this.loadStateList();
  },
  methods: {
    generateUSGraph() {
      new jsVectorMap({
        selector: "#map",
        map: "us_aea_en",
        showTooltip: true,
        zoomOnScroll: false,
        regionsSelectable: true,
        regionsSelectableOne: true,
        regionStyle: {
          initial: {
            fill: '#b5b5b5',
            stroke: "#ffffff",
            strokeWidth: 1,
            strokeOpacity: 0.25,
            fillOpacity: 1
          },
          hover: { 
            fill: '#3399d1',
            fillOpacity: 1
          },
          selected: { 
            fill: '#3399d1',
            fillOpacity: 1
          },
          selectedHover: { 
            fill: '#3399d1',
            fillOpacity: 1
          }
        },
        onRegionClick:(event, code) => {
          this.selectedStateCode = code.toUpperCase();
          this.gotoCalendlyLink();
        },
      });
    },
    gotoCalendlyLink() {
      if(this.selectedStateCode != ''){
        var foundState = _.find(this.all_state_list, (state) => {
          return 'US-'+state.state_code == this.selectedStateCode
        });
        if(!_.isUndefined(foundState)){
          window.open(
            foundState.calendly_link.consultation_calendly_link,
            '_blank'
          );
        }else{
          window.open(
            JS_WORDPRESS_URL + '/contact-us',
            '_blank'
          );
        }
      }else{
        window.open(
          JS_WORDPRESS_URL + '/contact-us',
          '_blank'
        );
      }
    },
    openURL(link) {
      window.open(link, "_blank");
    },
    loadStateList() {
      axios
        .get(JS_APP_URL + "/hipaachallenge/get-state-list")
        .then((response) => {
          if(response["data"]["status"] == "Success") {
            this.all_state_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
        });
      },
  },
};
</script>
