<template>
  <div class="flex flex-col flex-auto min-fill-height">
    <hipaaChallengeHeader :partner_info="partner" />
    <div class="main-content flex-auto">
      <div class="container">
        <!-- starting front page code -->
        <first-page v-if="hipaa_step == 0" @step-change="changeStep" />

        <!-- quiz page code -->
        <quiz-page
          v-if="hipaa_step == 1"
          :first_question="challenge_question"
          @quiz-info="quizeInfo"
        />

        <!-- hipaa grade score -->
        <hipaa-grade
          v-if="hipaa_step == 2"
          :quiz_answer_info="quiz_answer_info"
          :partner_info="partner"
          @scorecard-info="scorecardInfo"
        />

        <!-- hipaa scorecard -->
        <scorecard-page
          v-if="hipaa_step == 3"
          :scorecard_info="scorecard"
          @step-change="changeStep"
        />

      </div>
    </div>
    <hipaa-challenge-footer />
  </div>
</template>

<script scoped>
import firstPage from "./firstPage.vue";
import quizPage from "./quizPage.vue";
import hipaaGrade from "./hipaaGrade.vue";
import scorecardPage from "./scorecardPage.vue";
import hipaaChallengeFooter from './hipaaChallengeFooter.vue';
import hipaaChallengeHeader from "./hipaaChallengeHeader.vue";
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import NProgress from "nprogress";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      hipaa_step: 0,
      challenge_question: {},
      attempted_questions: [],
      quiz_answer_info: [],
      scorecard: {},
      partner: {},
    };
  },
  components: {
    firstPage,
    quizPage,
    hipaaGrade,
    scorecardPage,
    hipaaChallengeHeader,
    hipaaChallengeFooter
  },
  created() {
    let uri = window.location.pathname;
    uri = uri.split("/");
    if (uri[2]) {
      this.getPartnerInfo(uri[2]);
    }
  },
  methods: {
    changeStep(step) {
      if (step == 1) {
        this.getChallengeQuestion();
      } else {
        this.hipaa_step = step;
      }
    },
    getChallengeQuestion() {
      NProgress.start();
      axios
        .post(JS_APP_URL + "/hipaachallenge/load-question", {
          pagination_type: "first",
          attempted_questions: this.attempted_questions,
        })
        .then((response) => {
          this.challenge_question = response.data.data;
          this.hipaa_step = 1;
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        });
    },
    getPartnerInfo(slug) {
      axios
        .post(JS_APP_URL + "/hipaachallenge/partner-info", {
          slug: slug,
        })
        .then((response) => {
          this.partner = response.data.data;
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },
    quizeInfo(quiz_info) {
      setTimeout(() => {
        if (quiz_info != null) {
          this.quiz_answer_info = quiz_info;
          this.hipaa_step = 2;
        }
      }, 200);
    },
    scorecardInfo(scorecard_info) {
      setTimeout(() => {
        if (scorecard_info != null) {
          this.scorecard = scorecard_info;
          this.hipaa_step = 3;
        }
      }, 500);
    },
  },
};
</script>
