<template>
    <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask">
                <div class="modal-wrapper animate__animated animate__zoomIn">
                    <div class="modal-container Whoa-modal">
                        <div class="text-center mlr-auto">
                        </div>
                        <h2 class="font-24 blueog--text line-normal text-center mb20">
                            <span class="font-24 font_semibold">Don't look back! Before you <br/> begin... </span>
                        </h2>
                        <p class="text-center font-16 text-999 line-normal mb30">
                            While taking this short challenge, make sure 
                            <b>not</b> 
                            to hit the back button or refresh your browser otherwise you'll need to start your challenge questions over again.
                        </p>
                        <div class="flex flex-wrap items-center justify-center pb20">
                            <button
                                class="btn-primary-outline btn-width-136 mx5 px30 mt-xs-20"
                                :disabled="is_btn_disabled"
                                @click="closeModal"
                                >
                                GOT IT!
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </Teleport>
</template>

<script>
export default {
    emits: ["close-model"],
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_btn_disabled:false
        }
    },
    components: {
    },
    methods: {
        closeModal() {
            this.is_btn_disabled = true
            this.$emit("close-model", true);
        },
    },
    created() {
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.$emit("close-model");
            }
        });
    }
}
</script>