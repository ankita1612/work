<template>
  	<div class="header-container py18">
      <div class="container flex items-center justify-center flex-wrap relative">
        <a :href="JS_WORDPRESS_URL" target="_blank" class="logo-wrapper" >
          <img :src="JS_APP_URL + '/images/logo.svg'" alt="" title="" class="logo">
        </a>
        <div class="flex-wrap flex  font_normal">
          <a :href="JS_WORDPRESS_URL" class="font_semibold font-45 blueog--text hipaa-map-header-title">
            HIPAA Challenge
          </a>
        </div>
        <a :href="partner_info.link" class="hipaa-partner-logo" target="_blank" v-if="Object.keys(partner_info).length > 0">
            <img :src="JS_APP_URL + '/images/partner/'+partner_info.logo" alt="Abyde" class=""/>
        </a>
      </div>
  </div>
</template>


<script scoped>

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      JS_OSHA_HC_APP_URL: JS_OSHA_HC_APP_URL,
    };
  },
  props: {
    partner_info: Object
  },
  components: {},
  mounted() {},
  watch: {},
  computed: {},
  methods: {},
};
</script>
