import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import InfiniteLoading from "v3-infinite-loading";
import hipaachallenge from './hipaaChallenge.vue';
import VueMask from '@devindex/vue-mask';

const hipaachallenge_app = createApp(hipaachallenge);
hipaachallenge_app.use(VueMask);
hipaachallenge_app.use(FloatingVue);
hipaachallenge_app.component('multiselect', Multiselect);
hipaachallenge_app.component('InfiniteLoading', InfiniteLoading);
hipaachallenge_app.mount("#hipaachallenge_app");