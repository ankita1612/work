import { createApp } from "vue"
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import InfiniteLoading from "v3-infinite-loading";
import selectState from "./selectstate.vue";

const selectState_app = createApp(selectState);
selectState_app.use(FloatingVue);
selectState_app.component('multiselect', Multiselect);
selectState_app.component('InfiniteLoading', InfiniteLoading);
selectState_app.mount("#selectstate_app");