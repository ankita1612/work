<template>
    <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask">
                <div class="modal-wrapper animate__animated animate__zoomIn">
                    <div class="modal-container Whoa-modal">
                        <div class="text-center mlr-auto">
                        </div>
                        <h2 class="font-24 blueog--text line-normal text-center mb20">
                            Congratulations!
                        </h2>
                        <p class="text-center font-16 text-999 line-normal mb30">
                            Your HIPAA Challenge has been completed successfully! Please click the OK button below to see how you scored.
                        </p>
                        <div class="flex flex-wrap items-center justify-center pb20">
                            <button class="btn-primary-outline btn-width-136 mx5 px30 mt-xs-20" @click="closeModal">
                                OK
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </Teleport>
</template>

<script>
export default {
    emits: ['quiz-complete'],
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
        }
    },
    methods: {
        closeModal() {
            this.$emit('quiz-complete', true);
        }
    }
}
</script>