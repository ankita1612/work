<template>
    <div class="hipaa-map-block">
        <div class="hipaa-challenge-progress-wrapper mb30">
            <radial-progress-bar
                class="hipaa-challenge-progress"
                :diameter="130"
                :completed-steps="percentage"
                :total-steps="total_steps_outer"
                :start-color="start_color_outer"
                :stop-color="start_color_outer"
                :inner-stroke-color="inner_stroke_color"
                :inner-stroke-width="3"
                :stroke-width="6"
            >
                <h2
                class="challenge-percent-text font_semibold"
                :style="{ color: start_color_outer }"
                >
                {{ percentage }}%
                </h2>
                <h5 class="challenge-completed-text">Completed</h5>
            </radial-progress-bar>
        </div>

        <h4
        class="
            font-22
            bluog--text
            font_semibold
            hipaa-challenge-question-text
            text-center
            mb40
        "
        >
            {{question.question_detail.question}}
        </h4>

        <div class="mlr-auto justify-center mb30">
            <div class="row flex-auto justify-center -mx-10 mb15" v-if="question.question_detail.question_answer_layout == 'radio'">
                <div class="col-12 col-md-12 col-lg-3 col-xl-3 mb-md-20 px10" v-for="(ans_options,index) in question.question_detail.hipaa_challenge_question_answer_options" :key="index">
                    <div class="answer-option-item">
                        <input type="radio" class="answer-option-radio" v-model="selected_answers" :value="ans_options.id" />
                        <label class="answer-option-lable font-20 blueog--text" @click="nextQuestion(ans_options)"
                        >{{ans_options.answer}}</label
                        >
                    </div>
                </div>
            </div>
            <div v-else class="row flex-auto justify-center -mx-10 mb15">
                <div class="col-12 col-md-12 col-lg-3 col-xl-3 mb-md-20 px10">
                    <div class="answer-option-item">
                        <multiselect
                          class="font-style-normal"
                          v-model.trim="state_obj"
                          :options="all_state_list"
                          track-by="id"
                          label="state_name"
                          :multiple="false"
                          :close-on-select="true"
                          position="bottom"
                          :showLabels="false"
                          :taggable="false"
                          @update:model-value="nextQuestion"
                          :allowEmpty="true"
                          :clear-on-select="true">
                            <template #noResult>
                                <div class="multiselect__noResult text-center">No results found</div>
                            </template>
                            <template #noOptions>
                                <div class="multiselect__noOptions text-center">No data available</div>
                            </template>
                          </multiselect>
                          <label class="label label-select dropdown-label-blue" :class="{ 'label-float': (state_obj && Object.keys(state_obj).length > 0 && Object.getPrototypeOf(state_obj) === Object.prototype) }"><b>Select Option</b></label>
                    </div>
                </div>
            </div>
        </div>

        <div class="back-btn">
            <button v-if="previous_question_array.length > 0"
                @click="previousQuestion"
                type="button"
                class="cursor-pointer"
            >
                <img
                  :src="JS_APP_URL + '/images/back_btn_blue.png'"
                  alt=""
                  title=""
                  class="hipaa-prev-btn"
                />
            </button>
        </div>
        <quiz-complete-modal
            v-if="is_quiz_complete"
            @quiz-complete="quizComplete"
        />
    </div>
</template>

<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import NProgress from "nprogress";
import RadialProgressBar from "vue3-radial-progress";
import quizCompleteModal from './quizCompleteModal.vue'
import _ from "lodash";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            question: this.first_question,
            previous_question_array:[],
            all_state_list: [],
            state_obj: {},
            state_id: 0,
            attempted_questions: [],
            total_steps_outer: 100,
            inner_stroke_color: "#CCCCCC",
            start_color_outer: "#3399D1",
            quiz_info : [],
            selected_answers: '',
            is_quiz_complete: false,
            is_processing:false,
            percentage: 0
        }
    },
    components: {
        RadialProgressBar,
        quizCompleteModal
    },
    props: {
        first_question: {}
    },
    emits: ['quiz-info'],
    mounted() {
        this.loadStateList();
    },
    methods: {
        nextQuestion(selected_answer) {
            if(this.state_obj && this.state_obj != null) {
                if(this.is_processing == false){
                    this.is_processing = true
                    this.selected_answers = selected_answer.id != null ? selected_answer.id : this.state_obj.id;
                    const question_id = selected_answer.question_id != null ? selected_answer.question_id : this.question.question_detail.id;
                    var has_que = _.find(this.attempted_questions, ['id', question_id]);
                    if (!has_que) {
                        this.attempted_questions.push({'id': question_id, 'answer_id': this.selected_answers});
                    } else {
                        has_que.answer_id = this.selected_answers
                    }
                    this.quiz_info.push({'question_id': question_id, 'answer_id': this.selected_answers, 'answer_type': this.question.question_detail.question_answer_layout});
                    NProgress.start();
                    axios
                    .post(JS_APP_URL + '/hipaachallenge/load-question', {
                        pagination_type: 'next',
                        attempted_questions: this.quiz_info,
                        question_id: question_id,
                        answer_id: this.selected_answers,
                    })
                    .then((response) => {
                        if(response.data.data.question_detail == null) {
                            setTimeout(() => {
                                this.is_quiz_complete = true;
                            }, 800);
                            this.percentage = response.data.data.percentage_count.percentage;
                        } else {
                            this.question.question_detail.attempted_answer = this.selected_answers;
                            this.previous_question_array.push(this.question.question_detail);
                            this.question = response.data.data;
                            var is_attempted_que = _.find(this.attempted_questions, ['id', this.question.question_detail.id]);
                            if (!is_attempted_que) {
                                this.selected_answers = '';
                                if ( this.percentage < parseInt(this.question.percentage_count.percentage)) {
                                    this.percentage = this.question.percentage_count.percentage;
                                }
                            } else {
                                this.selected_answers = is_attempted_que.answer_id;
                            }
                        }
                    })
                    .catch((error) => {
                        toastr.error(error.response["data"]["message"], "Error");
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        this.is_processing = false
                        NProgress.done();
                    });
                }
            } else {
                this.state_obj = {}
            }
        },
        previousQuestion() {
            NProgress.start();
            const last_element_index = this.previous_question_array.length - 1
            this.question.question_detail =  this.previous_question_array[last_element_index]
            this.selected_answers = this.question.question_detail.attempted_answer;
            this.quiz_info = this.quiz_info.filter(x => {return x.question_id != this.question.question_detail.id;})
            this.previous_question_array.pop();
            NProgress.done();
        },
        loadStateList() {
            axios
            .get(JS_APP_URL + "/hipaachallenge/get-state-list")
            .then((response) => {
                if(response["data"]["status"] == "Success") {
                    this.all_state_list = response["data"]["data"];
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
            });
        },
        quizComplete(is_complete) {
            if(is_complete == true) {
                this.is_quiz_complete = false;
                var myData = this.quiz_info;
                this.quiz_info = Array.from(new Set(myData.map(JSON.stringify))).map(JSON.parse);
                this.$emit('quiz-info', this.quiz_info);
            }
        }
    }
}
</script>
