<template>
    <div class="dark py40">
			<div class="container">
        <div class="row flex-auto -mx-10 hipaa-footer">
					<div class="col-12 col-sm-5 col-md-6 col-lg-6 col-xl-6 px10 mb-sm-10 text--white">
						Copyright &copy; {{CURRENT_YEAR}} Abyde
					</div>
					<div class="col-12 col-sm-7 col-md-6 col-lg-6 col-xl-6 px10 text-right">
						<a class="btn px10" :href="JS_WORDPRESS_URL + '/terms-conditions'">TERMS AND CONDITIONS</a>
						<a class="btn px10" :href="JS_WORDPRESS_URL + '/privacy-policy'">PRIVACY POLICY</a>
					</div>					
        </div>
			</div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            CURRENT_YEAR: CURRENT_YEAR,
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
        }
    }
}
</script>