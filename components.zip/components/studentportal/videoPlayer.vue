<template>
    <div>
        <video oncontextmenu="return false;" ref="videoPlayer" class="video-js"  @ended="onPlayerEnded($event)" ></video>
    </div>
</template>

<script scoped>
import videojs from 'video.js';

export default {
    name: 'VideoPlayer',
    data() {
        return {
            player: null
        }
    },
    props: {
        options: {
            type: Object,
            default() { return {}; }
        }
    },
    emits: ['ended'],
    mounted() {
        this.player = videojs(this.$refs.videoPlayer, this.options, () => {});
    },
    methods: {
        onPlayerEnded(){
            this.$emit('ended');
        }
    },
    beforeDestroy() {
        if (this.player) {
            this.player.dispose();
        }
    },
}
</script>