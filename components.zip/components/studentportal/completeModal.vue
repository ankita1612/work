<template>
    <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask">
                <div class="modal-wrapper animate__animated animate__zoomIn">
                    <div class="modal-container">
                        <div class="text-center mlr-auto mb20 pt20">
                            <img :src="JS_APP_URL + '/images/envelop-done.svg'" alt="" title="" class="warning-icon-modal" />
                        </div>
                        <h2
                            class="
                            font-24 font_semibold blueog--text line-normal text-center mb20
                            "
                        >
                            Congratulations!
                        </h2>
                        <p class="text-center font-16 text-999 font_semibold line-normal mb20">Thank you for completing the Training.</p>
                        <p class="text-center font-16 text-999 line-normal mb30">Click the button below to view, print and/or download a copy of your {{ training.title }} certificate.</p>
                        <div class="flex flex-wrap items-center justify-center pb20">
                            <button class="btn-primary-outline mx5" @click="downloadCertificate" :disabled="is_disable_download">DOWNLOAD CERTIFICATE</button>
                        </div>
                        <div class="flex flex-wrap items-center justify-center pb10">
                            <button @click="goToLogin" class="btn-blueog-outline mx5">CLOSE WINDOW</button>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </Teleport>
</template>

<script scoped>
import axios from 'axios';
import toastr from "toastr";
import "toastr/toastr.scss";
import NProgress from "nprogress";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_disable_download: false
        }
    },
    props: {
        training: {},
        training_invite: {}
    },
    methods: {
        goToLogin(){
            window.location = JS_APP_URL + "/login";
        },
        downloadCertificate() {
            NProgress.start();
            this.is_disable_download = true;
            axios.post(JS_APP_URL + '/studentportal/get-training-certificate', {
                location_id : this.training_invite.emp_user_acntuser_student.primary_work_location_id,
                invite_id : this.training_invite.id,
            })
            .then((response) => {
                if (response["data"]["status"] == "Error") {
                    let data = "";
                    if (response["data"]["data"]) {
                        data = response["data"]["data"].join(", ");
                    }
                    if(response["data"]['data'].length > 0){
                        toastr.error(response["data"]['data'].join('</br>'), "Error");
                    }else{
                        toastr.error(response["data"]["message"], "Error");
                    }
                } else {
                    const filePath =
                    response["data"]["data"].split("/");
                    const tempFileName = filePath[filePath.length - 1];
                    const fileName = tempFileName.split("?")[0];
                    axios({
                        url: response["data"]["data"],
                        method: "GET",
                        responseType: "blob",
                    }).then((response) => {
                        var fileURL = window.URL.createObjectURL(
                            new Blob([response.data])
                        );
                        var fileLink = document.createElement("a");
                        fileLink.href = fileURL;
                        fileLink.setAttribute("download", fileName);
                        document.body.appendChild(fileLink);
                        fileLink.click();
                    });
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                NProgress.done();
                this.is_disable_download = false;
            })
        }
    }
}
</script>
