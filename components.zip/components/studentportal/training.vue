<template>
    <div>
        <header-student-portal></header-student-portal>
        <div class="container pt30 pb60" v-if="!start_training">
            <div class="flex justify-center flex-wrap mb15 relative">
                <div class="col-12 col-sm-6 font-16 font_semibold  blueog--text px0 mb-0 mlr-auto text-center">
                    {{this.location.location_nickname}}
                </div>
            </div>
            <h1 class="location-dashbaord-title  text-center  font-24 font_semibold  blueog--text line-normal mb15 mb-sm-10 mb-md-10">Training</h1>
            <p class="font-16 dark--text line-normal text-center mb40">HIPAA compliance training is mandatory for all students. After the student has watched the selected training video they must take the associated quiz. Once the quiz is complete, an Abyde HIPAA Training certificate will be available to download or print.</p>
            <!-- training -->
            <div class="recommended-training-item mb12 flex mt20">
                <div class="video-play-box recommended-video-thumb relative cursor-pointer mr16 self-center" @click="PlayVideoModalToggle('yes')">
                    <img
                        :src="video_poster_file_url"
                        alt=""
                        title=""
                        class="video-thumnail"
                    />
                    <img
                        :src="JS_APP_URL + '/images/video-play.svg'"
                        alt=""
                        title=""
                        class="play-icon"
                    />
                </div>
                <div class="recommended-items-text flex-auto mr16 mt-sm-10">
                    <h4 class="font-19 gray2--text font_semibold mb0">
                        {{ training.title }}
                    </h4>
                    <p class="font-14 font_light gray2--text line-normal" v-html="training.description" ></p>
                </div>
                <div class="recommended-item-buttons self-center col-md-4 col-lg-3 col-xl-3">
                    <div class="mb8" v-if="JS_TRAINING_INVITE.completed_datetime == null && JS_TRAINING_INVITE.completed_attempt_id == null">
                        <span class="font-14 font_semibold blueog--text">Sent on: </span> <span class="font-14 font_light gray2--text">{{ $filters.formatDate(invite_details.invite_datetime) }}</span>
                    </div>
                    <div class="mb8" v-if="is_training_completed">
                        <span class="font-14 font_semibold blueog--text">Complete date on:</span> <span class="font-14 font_light gray2--text">{{ $filters.formatDate(JS_TRAINING_INVITE.completed_datetime) }}</span>
                    </div>
                    <button
                        type="button"
                        class="btn-blue-outline quiz-btn inline-flex items-center"
                        v-if="JS_TRAINING_INVITE.training_attempt_count == 0"
                        @click="startTraining"
                    >
                        <img
                        :src="JS_APP_URL + '/images/quiz-list.svg'"
                        alt=""
                        title=""
                        style="width: 22px; height: 22px"
                        />
                        <span class="pl14 font-14">QUIZ</span>
                    </button>
                    <button
                        type="button"
                        class="btn-primary btn-retry-quiz h-32 mt10"
                        v-if="JS_TRAINING_INVITE.training_attempt_count > 0 && JS_TRAINING_INVITE.completed_datetime == null && JS_TRAINING_INVITE.completed_attempt_id == null"
                        @click="startTraining"
                        >
                        RETRY QUIZ
                    </button>
                    <div class="font-10 red--text font_bold font-italic mr30 mt4" v-if="JS_TRAINING_INVITE.training_attempt_count > 0 && JS_TRAINING_INVITE.completed_datetime == null && JS_TRAINING_INVITE.completed_attempt_id == null">
                        ATTEMPTS: {{JS_TRAINING_INVITE.training_attempt_count}}
                    </div>
                </div>
                <play-video-modal
                    v-if="play_video_modal == 'true'"
                    :training="training"
                    :video_file_url="video_file_url"
                    :vtt_file_url="vtt_file_url"
                    @close-model="PlayVideoModalToggle"
                    @ended="videoEnded"
                ></play-video-modal>

            </div>
        </div>
        <training-quiz v-if="start_training" :training="training" :training_invite="JS_TRAINING_INVITE" :student_id="JS_STUDENT.id" @back-to-listing="backToListing"/>
        <complete-modal v-if="is_training_completed" :training="training" :training_invite="invite_details"/>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>

<script scoped>
import axios from "axios";
import headerStudentPortal from '../common/includes/headerStudentPortal.vue';
import fullPageLoader from '../common/fullPageLoader.vue';
import playVideoModal from './playVideoModal.vue';
import trainingQuiz from './trainingQuiz/trainingQuiz.vue';
import completeModal from './completeModal.vue';

export default {
    data() {
        return {
            JS_STUDENT: JS_STUDENT,
            JS_TRAINING_INVITE: JS_TRAINING_INVITE,
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            is_full_page_loader_shown: false,
            play_video_modal: false,
            training: [],
            invite_details: [],
            location:[],
            video_poster_file_url: null,
            video_file_url: null,
            vtt_file_url: null,
            is_training_completed: true,
            start_training: false
        }
    },
    components: {
        headerStudentPortal,
        fullPageLoader,
        playVideoModal,
        trainingQuiz,
        completeModal
    },
    mounted() {
        if(JS_TRAINING_INVITE.ref_token == "" && JS_TRAINING_INVITE.completed_datetime != null && JS_TRAINING_INVITE.completed_attempt_id != null){
            this.is_training_completed = true
        }else{
            this.is_training_completed = false
        }
        this.getTrainingInvite();
    },
    watch: {
        'training.video_poster_file' (){
            this.createSignUrl(this.training.video_poster_file,'poster_file');
        }
    },
    methods: {
        createSignUrl(file_name,file_type,file_time = 600){
            var request = {
                params: {
                    file_path: 'trainings/'+ this.training.id + '/' + file_name,
                    file_exp_time: file_time
                }
            }
            axios
            .get(JS_APP_URL + "/studentportal/get-sign-url",request)
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    if(file_type == 'poster_file'){
                        this.video_poster_file_url = response.data.data;
                    }
                    if(file_type == 'video_file'){
                        this.video_file_url = response.data.data;
                    }
                    if(file_type == 'vtt_file'){
                        this.vtt_file_url = response.data.data;
                    }
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            });
        },
        PlayVideoModalToggle(is_api_call = 'yes') {
            if (this.play_video_modal == "true") {
                this.play_video_modal = "false";
            } else {
                if(is_api_call ==  'yes'){
                    this.createSignUrl(this.training.video_file,'video_file', 3600);
                    this.createSignUrl(this.training.video_caption_file,'vtt_file');
                }
                setTimeout(() => {
                    if(this.vtt_file_url != null){
                        this.play_video_modal = "true";
                    }else{
                        this.PlayVideoModalToggle('no');
                    }
                }, 200);
            }
        },
        videoEnded(){
            this.play_video_modal = "false";
        },
        getTrainingInvite() {
            axios.post(JS_APP_URL + '/studentportal/get-invite-details',{
                invite_id : JS_TRAINING_INVITE.id
            })
            .then((response) => {
                this.invite_details = response.data.data.invite_details;
                this.training = this.invite_details.training;
                this.location = response.data.data.location
            })
            .catch((error) => {
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {})
        },
        startTraining() {
            this.start_training = true;
        },
        backToListing(){
            this.start_training = false;
        }
    },
}
</script>
