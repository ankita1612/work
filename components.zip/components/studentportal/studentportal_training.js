import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import FloatingVue from 'floating-vue'
import 'floating-vue/dist/style.css'
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.css';
import training from "./training.vue";
import moment from "moment";

const training_app = createApp(training);
training_app.config.productionTip = false;
training_app.use(useVuelidate);
training_app.use(FloatingVue);
training_app.component('multiselect', Multiselect);
training_app.config.globalProperties.$filters = {
    formatDate(value) {
        if (value) {
           return moment.utc(String(value)).local().format("MM/DD/YYYY");
        }
    },    
};
training_app.mount("#training_app");