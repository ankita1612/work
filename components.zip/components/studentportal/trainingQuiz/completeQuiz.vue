<template>
    <div>
        <div class="container pt40 pb60">
            <h3 class="
                location-dashbaord-title
                text-center
                font-24 
                font_light
                blueog--text
                line-normal
                mb-md-10 mb-sm-10
            "> Training Quiz </h3>
            <h1
                class="
                location-dashbaord-title
                text-center
                font-24 font_semibold
                blueog--text
                line-normal
                mb20
                mb-sm-10 mb-md-10
                "
            >
                {{ training.title }} Quiz
            </h1>
            <!-- congratulations code -->
            <div
                class="quiz-congrats-block text-center mb20"
                v-if="
                result.result_of_training_quiz >= 70
                "
            >
                <img
                :src="JS_APP_URL + '/images/quiz-congrats.gif'"
                alt=""
                title=""
                class="inline-block"
                />
                <div class="quiz-congrats-answered-text text-center font-20 uppercase font_light gray2--text mb20">
                    YOU ANSWERED
                    <span class="font_semibold"
                        >{{ result.total_correct_ans_attempt }}/{{
                        result.total_que_attempt
                        }}</span>
                    QUESTIONS CORRECT
                </div>
            </div>
            <p class="font-20 black--text text-center mb24 congrats-text" v-if="result.result_of_training_quiz >= 70">
                Congratulations! You've successfully completed your {{ training.title }}!
                Your certificate of<br />
                completion will be available in your student portal as well as the
                <span class="font-italic">Training</span> section of Abyde!
            </p>
            <!-- End  -->

            <!-- just missed code -->
            <div
                class="quiz-misses-block text-center"
                v-if="result.result_of_training_quiz < 70"
            >
                <img
                    :src="JS_APP_URL + '/images/quiz-misses.gif'"
                    alt=""
                    title=""
                    class="inline-block"
                />
            </div>
            <div
                class="quiz-misses-text animate__fadeIn animate__animated mb30"
                v-if="result.result_of_training_quiz < 70"
            >
                <div class="quiz-congrats-answered-text text-center font-20 uppercase font_light gray2--text mb20">
                    YOU ANSWERED
                    <span class="font_semibold"
                        >{{ result.total_correct_ans_attempt }}/{{
                        result.total_que_attempt
                        }}</span
                    >
                    QUESTIONS CORRECT
                </div>
                <p class="font-20 black--text text-center mb20 congrats-text">
                    Uh oh! You need to score a 70% or above in order to pass this quiz.
                    <br />Please review the video and try again!
                </p>
            </div>
            <!-- End -->

            <div class="text-center mb30">
                <button @click="gotIt" class="btn-got-it btn-primary-outline h-32">GOT IT!</button>
            </div>
        </div>
    </div>
</template>

<script scoped>

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
        }
    },
    props: {
        result: {},
        training: {},
        student_id: {},
        invite_id: {}
    },
    methods: {
        gotIt() {
            window.location = JS_APP_URL + "/studentportal/training/"+btoa(this.student_id)+'/'+btoa(this.invite_id);
        },
    }
}
</script>