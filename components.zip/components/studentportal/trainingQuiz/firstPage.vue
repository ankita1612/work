<template>
    <div class="container pt40 pb60">
        <h3 class="location-dashbaord-title text-center font-22 font_light blueog--text line-normal mb-md-10 mb-sm-10 "> Training Quiz </h3>
        <h1 class="
            location-dashbaord-title
            text-center
            font-24 font_semibold
            blueog--text
            line-normal
            mb30
            mb-md-10 mb-sm-10
        ">
            {{ training.title }} Quiz
        </h1>
        <div>
            <div class="security-progress-wrapper mb50">
                <radial-progress-bar
                class="sra-start-progress"
                :diameter="200"
                :completed-steps="0"
                :total-steps="10"
                :start-color="'#C72121'"
                :stop-color="'#C72121'"
                :inner-stroke-color="'#CCCCCC'"
                :inner-stroke-width="6"
                :stroke-width="6"
                >
                    <h1 class="sra-percent-text font_semibold">0%</h1>
                    <p class="sra-completed-text">Completed</p>
                </radial-progress-bar>
            </div>
            <p class="font-20 black--text text-center mb50">
                Please answer the following questions as part of your Training Quiz.
            </p>
            <div class="text-center sra-first-buttons">
                <button
                    type="button"
                    class="btn-blue-36 mx-auto d-inline-block px30 mt-xs-20 mx5"
                    @click="backToListing">
                Back
                </button>                
                <button
                    type="button"
                    class="btn-primary mx-auto d-inline-block px30 mt-xs-20 mx5"
                    @click="startQuiz">
                Start
                </button>

            </div>
        </div>
    </div>
</template>

<script scoped>
import RadialProgressBar from "vue3-radial-progress";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
        };
    },
    components: {
        RadialProgressBar,
    },
    props: {
        training:{}
    },
    emits: ['get-quiz-question', 'back-to-listing'],
    methods: {
        startQuiz(){
            this.$emit('get-quiz-question');
        },
        backToListing(){
            this.$emit('back-to-listing');
        }
    }
}
</script>