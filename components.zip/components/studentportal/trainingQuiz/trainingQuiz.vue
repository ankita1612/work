<template>
    <div>
        <full-page-loader v-if="is_full_page_loader_shown" />
        <!-- First screen code as per design  -->
        <first-page 
            v-if="show_sra_start_page"
            :training="training"
            @get-quiz-question="getQuizQuestion"
            @back-to-listing="backToListing"
        />
        <!-- end first screen code -->

        <!-- second screen code -->
        <question-detail
            v-if="show_question_detail_page"
            :training_qustions="training_qustions"
            @submit-quiz-question-answer="submitQuizQuestionAnswer"
        />
        <!-- end second screen code -->
        <complete-quiz
            v-if="quiz_fail_page"
            :result="result"
            :training="training"
            :invite_id="training_invite.id"
            :student_id="student_id"
        />
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from '../../common/fullPageLoader.vue';
import firstPage from './firstPage.vue';
import questionDetail from './questionDetails.vue';
import completeQuiz from './completeQuiz.vue';

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            training_qustions:{},
            show_sra_start_page: true,
            quiz_fail_page:false,
            result:{},
            is_full_page_loader_shown: false,
            show_question_detail_page: false,
        };
    },
    components: {
        fullPageLoader,
        firstPage,
        questionDetail,
        completeQuiz,
    },
    props: {
        training: {},
        training_invite: {},
        student_id: {}
    },
    emits: ['back-to-listing'],
    methods: {
        getQuizQuestion() {
            NProgress.start();
            axios.post(JS_APP_URL + "/studentportal/get-training-quiz", {
                training_id : this.training.id
            })
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    this.training_qustions = response.data.data
                    this.show_sra_start_page = false
                    this.show_question_detail_page = true
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/employeeportal/login";
                }
            })
            .then(() => {
                NProgress.done();
            });
        },
        submitQuizQuestionAnswer(answer_array){
            this.is_full_page_loader_shown = true;
            axios.post(JS_APP_URL + "/studentportal/add-training-complete-record",{
                invite_id : this.training_invite.id,
                queans : answer_array,
            })
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    this.result = response.data.data
                    this.quiz_fail_page = true
                    this.show_question_detail_page = false
                    if(response.data.data.result_of_training_quiz < 70){
                    
                    }
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                this.is_full_page_loader_shown = false;
            });
        },
        backToListing(){
            this.$emit('back-to-listing');
        }
    }
}
</script>