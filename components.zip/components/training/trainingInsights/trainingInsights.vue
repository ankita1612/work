<template>
  <div>
     <header-after-login></header-after-login>
      <div class="container pt30">
        <div class="mb30 relative">
          <button type="button" class="btn-blue-outline btn-left-icon min-width-90 training-report-btn" @click="backToTraining">
            <div class="prev-arrow-icon"><previous-icon></previous-icon></div>back
          </button>

          <div class="row flex-auto -mx-15 justify-center">
            <div class="col-12 col-md-6 col-lg-4 col-xl-3 mt-sm-10 px15">
                 <multiselect
                    class="company-location-select"
                    v-model="selected_training"
                    :options="all_trainings"
                    label="title"
                    :taggable="false"
                    :multiple="false"
                    :close-on-select="true"
                    :showLabels="false"
                    track-by="id"
                    placeholder=""
                    :allowEmpty="false"
                  >
                <template #noResult>
                    <div class="multiselect__noResult text-center">
                    No results found
                    </div>
                </template>
                </multiselect>
                <label class="label label-select label-float label-float-left-space">Training</label>
            </div>
            <div class="col-12 col-md-6 col-lg-4 col-xl-3 mt-sm-10 px15"  v-if="all_locations.length > 1">
              <multiselect
                class="company-location-select"
                v-model="selected_location"
                :options="all_locations"
                label="location_nickname"
                :taggable="false"
                :multiple="false"
                :close-on-select="true"
                :showLabels="false"
                track-by="id"
                placeholder=""
                :allowEmpty="false"
              >
                <template #noResult>
                  <div class="multiselect__noResult text-center">
                    No results found
                  </div>
                </template>
              </multiselect>
              <label class="label label-select label-float label-float-left-space">Location</label>
            </div>
          </div>
        </div>
        <h1
        class="
          location-dashbaord-title
          text-center
          font-24 font_semibold
          blueog--text
          line-normal flex justify-center items-center
          mb15
          mb-sm-10 mb-md-10
          "
        >
          Course Overview
        </h1>
        <p class="font-16 dark--text line-normal text-center mb40">
           View {{ (selected_training.who_can_train == "hco") ? "HCO" : "employees" }} training status at a glance, send reminders, download Certificates of Completion and more!
        </p>
      </div>
      <div class="training-tabs-wrapper pb50">
        <div class="training-tab-nav">
          <div class="container flex items-center flex-wrap">
            <button
              type="button"
              class="training-tab-nav-item font-21"
              @click="changeActivateTabs('assigned_emp')"
              :class="{ active: active_tab == 'assigned_emp' }"
            >
              Assigned {{(selected_training.who_can_train == "hco") ? "HCO" : "Employees"}}
            </button>
            <button v-if="selected_training.training_code != 'HT1' && selected_training.training_code != 'HT2' && selected_training.training_location != null  && selected_training.training_location[0].is_triggered == 1"
              type="button"
              class="training-tab-nav-item sharp-tab-item font-21 ml175"
              @click="changeActivateTabs('unassigned_emp')"
              :class="{ active: active_tab == 'unassigned_emp' }"
            >
              Unassigned {{ (selected_training.who_can_train == "hco") ? "HCO" : "Employees" }}
            </button>
          </div>
        </div>
        <div class="training-tab-content pt12">
          <assigned v-if="active_tab == 'assigned_emp'"
            :selected_location = "selected_location"
            :selected_training = "selected_training"
          />
          <unassigned  v-if="active_tab == 'unassigned_emp'"
            :selected_location = "selected_location"
            :selected_training = "selected_training"
            @change-activate-tabs = changeActivateTabs
          />
        </div>
      </div>
    <full-page-loader v-if = "is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import previousIcon from "../../common/icons/previousIcon.vue";
import fullPageLoader from "../../common/fullPageLoader.vue";
import headerAfterLogin from "../../common/includes/headerAfterLogin.vue";
import NProgress from "nprogress";
import _ from "lodash";

import assigned from "./assigned/assigned.vue";
import unassigned from "./unassigned/unAssigned.vue";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      selected_location: "",
      all_locations: [],
      selected_training: "",
      all_trainings: [],
      is_full_page_loader_shown: false,
      active_tab: 'assigned_emp',
      download_report_modal: false,
    };
  },
    mounted() {
    this.loadLocationNicknameList();

  },
  components: {
    headerAfterLogin,
    fullPageLoader,
    previousIcon,
    assigned,
    unassigned
  },
  methods: {
    backToTraining() {
      window.location = JS_APP_URL + '/training/' + this.encryption(this.selected_location.id);
    },
    changeActivateTabs(tab_name) {
      this.active_tab = tab_name;
    },


    loadLocationNicknameList() {
      this.is_full_page_loader_shown = true;
      axios
      .get(JS_APP_URL + "/general/get-assigned-location-list")
      .then((response) => {
        if (response["data"]["status"] == "Success") {
          this.all_locations = response["data"]["data"];
          this.selected_location = this.all_locations.find(
            (object) => object.id === parseInt(JS_LOCATION_ID)
          );

        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";
        }
      })
      .then(() => {
        //this.is_full_page_loader_shown = false;
      });
    },
    loadLocationTraining(location_id, training_id = '') {
        if (training_id == ''){
            training_id = JS_TRAINING_ID
        }
        this.is_full_page_loader_shown = true;
        axios
            .get(JS_APP_URL +"/training/get-training-list-for-download-report?location_id=" + location_id + '&tab_name=employee')
            .then((response) => {
                this.all_trainings = response['data']['data'];
                var curr_selected_training = this.all_trainings.find(
                    (object) => object.id === parseInt(training_id)
                );

                if (_.isUndefined(curr_selected_training)){
                    window.location = JS_APP_URL + "/dashboard";
                }
                else{
                    this.selected_training = curr_selected_training;
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                this.is_full_page_loader_shown = false;
            });
    },
    encryption(params) {
      var encoded = btoa(params);
      return encoded;
    },
    dwonloadReportModalToggle() {
        if (this.download_report_modal == true) {
            this.download_report_modal = false
        } else {
            this.download_report_modal = true
        }

    },
  },
  watch:
  {
    selected_location() {
        this.loadLocationTraining(this.selected_location.id,(this.selected_training!=undefined)? this.selected_training.id:"")
    },
  },
};
</script>
