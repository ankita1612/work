import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.css';
import trainingInsights from "./trainingInsights.vue";
import { useVuelidate } from '@vuelidate/core';
import moment from "moment";
import InfiniteLoading from "v3-infinite-loading";

const training_app = createApp(trainingInsights);
training_app.config.globalProperties.$filters = {
    formatDate(value) {
        if (value) {
            return moment.utc(String(value)).local().format("MM/DD/YYYY");
        }
    },
};
training_app.use(FloatingVue);
training_app.component('InfiniteLoading', InfiniteLoading);
training_app.use(useVuelidate);
training_app.component('multiselect', Multiselect);
training_app.mount("#training_insights_app");
