<template>
<div>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button  v-if="!is_btn_disabled"  @click="closeModal()" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb10">
              <img
                :src="JS_APP_URL + '/images/emp_training_alert.svg'"
                alt=""
                title=""
                class="warning-icon-modal"
              />
            </div>
            <h2
              class="
                font-21 font_semibold
                blueog--text
                line-normal
                text-center
                mb20
              "
            >
              {{(is_hidden==0)?"Unhide":"Hide"}} {{ emp_type =="hco"?"HCO":"employee"}}?
            </h2>            
            <p class="text-center font-16 text-999 mb10" style="line-height: 22px;padding: 0 2rem;">
             Click confirm to {{ (is_hidden == 0) ? "add" : "remove" }} this {{ emp_type == "hco" ? "HCO" : "employee" }} from the unassigned count for 
             <span v-if="total_trainings == selected_training_data.length">
                All
             </span>
             <span v-else>
              <span v-for="(training_name, index) in selected_training_data">
                      {{training_name.name}}<span v-if="index+1 < selected_training_data.length">, </span>
              </span>.
            </span>
            </p>
            <p class="text-center font-16 text-999 mb20" style="line-height: 22px;padding: 0 2rem;">The HCO is accountable for ensuring that all necessary HIPAA training has been completed.</p>

            <div class="checkbox pb20 pt20" v-if="emp_type != 'hco'">
              <input v-model.trim="is_hide_all" id="is_hide_all" name="is_hide_all" type="checkbox">
              <label for="is_hide_all" class="checkbox-label font-16 gray_checkmark--text">{{(is_hidden==0)?"Unhide":"Hide"}} all unassigned {{ emp_type == "hco" ? "HCO" : "employees" }}</label>
            </div>
            <div class="flex flex-wrap items-center justify-center">
              <button class="btn-primary-outline mx15 btn-width-120 h-32 " :disabled="is_btn_disabled" @click="saveHideEmployee">CONFIRM</button>
              <button class="btn-cancel-outline mx15 btn-width-120 h-32" :disabled="is_btn_disabled" @click="closeModal()">CANCEL</button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
    <div class="modal-backdrop"></div>
</div>
</template>

<script scoped>
import closeIcon from "../../../common/icons/closeIcon.vue";
import NProgress from "nprogress";
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";

export default {
  components: { closeIcon },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_btn_disabled: false,
      is_hide_all: false,
      hide_unhide_prefix:null,      
    };
  },
  props: {
     unassigned_training_id:null,
     is_hidden: null,
     selected_location: null,
     selected_training: null,
     emp_type: null,
     training_arr: {},
     emp_user_acntuser_student_id: null,
     emp_user_acntuser_student_type: null,
     selected_training_data :{},
     total_trainings : null
  },
  emits: ["close-model", 'emp-student-list-for-training'],
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", (this.is_hidden == 1) ? 0 : 1);
      }
    });
  },
  computed(){

  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  },
  watch: {

  },  
  methods: {
      closeModal() {
         this.$emit("close-model", (this.is_hidden == 1) ? 0 : 1);
      },
      saveHideEmployee() {
        NProgress.start();
        this.is_btn_disabled = true;
        axios
          .post(JS_APP_URL + "/training/hide-employee-student-list-for-training",
              {
                  location_id : this.selected_location.id,
                  training_arr : this.training_arr,
                  unassigned_training_id : this.unassigned_training_id,
                  hide_all : this.is_hide_all,
                  is_hidden: this.is_hidden,
                  user_type: (this.emp_type == "hco") ? "hco" : "employee",
                  emp_user_acntuser_student_id: this.emp_user_acntuser_student_id,
                  emp_user_acntuser_student_type: this.emp_user_acntuser_student_type,
              })
          .then((response) => {
              if (response["data"]["status"] == "Error") {
                  if (response["data"]['data'].length > 0) {
                      toastr.error(response["data"]['data'].join('</br>'), "Error");
                  } else {
                      toastr.error(response["data"]["message"], "Error");
                  }
              } else {
                  toastr.success(response["data"]["message"], "Success");
                  if (this.is_hide_all == true) {
                      this.$emit('emp-student-list-for-training', 'full');
                  }
                  this.$emit("close-model", this.is_hidden);
              }
          })
          .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                  window.location = JS_APP_URL + "/login";
              }
          })
          .then(() => {
              NProgress.done();
              this.is_btn_disabled = false;
          });
        },        
  },
};
</script>
