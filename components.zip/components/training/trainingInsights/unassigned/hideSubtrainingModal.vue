<template>
<div>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button  v-if="!is_btn_disabled"  @click="closeModal()" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb10">
              <img
                :src="JS_APP_URL + '/images/emp_training_alert.svg'"
                alt=""
                title=""
                class="warning-icon-modal"
              />
            </div>
            <h2
              class="
                font-21 font_semibold
                blueog--text
                line-normal
                text-center
                mb20
              "
            >
              {{(is_hidden==0)?"Unhide":"Hide"}} {{ emp_type =="hco"?"HCO":"employee"}}?
            </h2>
            <p class="text-center font-16 text-999 mb10" style="line-height: 22px;padding: 0 2rem;">
                Select which training(s) you would like to {{ (is_hidden == 0) ? "add" : "remove" }}.              
            </p>
            <div class="self-center" v-if="selected_training.child_training_count > 0 || this.selected_training.parent_training_id!=null">
              <div class="mt15 mb20 flex flex-col items-center" :class="{ 'form-group--error': v$.training_arr.$error }">
                <div class="col-6 text-left">                                  
                  <div class="checkbox pb10" v-for="sub_training in sub_trainings">
                    <input type="checkbox" :value="sub_training.training.id" :id="sub_training.training.id" v-model="training_arr" class="checkbox pb15" style="margin-right:14px" @change='checkSelectAll()' />                      
                    <label :for="sub_training.training.id" class="checkbox-label gray_checkmark--text">{{sub_training.training.title_for_tab}}</label>                      
                  </div>                       
                  <div class="checkbox" >
                    <input v-model.trim="is_send_to_all" id="is_send_to_all" name="is_send_to_all" type="checkbox" @change="selectAll()">
                    <label for="is_send_to_all" class="checkbox-label font-14 font-light gray_checkmark--text">(Optional) {{(is_hidden==0)?"Unhide":"Hide"}} All Tabs</label>
                  </div>                               
                  <div class="flex mt10">
                      <div v-if="v$.training_arr.$errors.length > 0" class="form-error-text">Please select training(s) to {{(is_hidden==0)?"unhide":"hide"}} {{ emp_type =="hco"?"HCO":"employee"}}</div>
                  </div>                           
                </div>
              </div>
            </div>            
            <div class="flex flex-wrap items-center justify-center">
              <button class="btn-primary-outline mx15 btn-width-120 h-32 " :disabled="is_btn_disabled" @click="saveHideEmployee">CONFIRM</button>
              <button class="btn-cancel-outline mx15 btn-width-120 h-32" :disabled="is_btn_disabled" @click="closeModal()">CANCEL</button>              
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
    <div class="modal-backdrop"></div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
</div>
</template>

<script scoped>
import closeIcon from "../../../common/icons/closeIcon.vue";
import NProgress from "nprogress";
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import useVuelidate from "@vuelidate/core";
import { required, helpers } from "@vuelidate/validators";
import fullPageLoader from "../../../common/fullPageLoader.vue";

export default {
  setup: () => ({ v$: useVuelidate() }),
  components: { closeIcon, fullPageLoader },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_btn_disabled: false,
      is_hide_all: false,
      hide_unhide_prefix:null,
      training_arr: [], 
      sub_trainings: {},
      training_arr: [],      
      all_selected: 0,     
      is_full_page_loader_shown: false,  
      is_send_to_all: false,
      error_msg_training:'Please select training(s)',
      selected_training_data:[],
      total_trainings : 0  
    };
  },
  validations() {
    return {        
        training_arr: { required: helpers.withMessage(this.error_msg_training, required) },          
    }
  },
  props: {
     is_hidden: null,
     selected_location: null,
     selected_training: null,
     emp_user_acntuser_student_id: null,
     emp_user_acntuser_student_type: null,
     parent_training_id: null,
     emp_type: null,
  },
  emits: ["close-model", 'hide-employee-popup'],
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", (this.is_hidden == 1) ? 0 : 1);
      }
    });
  },
  computed(){

  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  },
  watch: {

  },
  mounted() {       
      if(this.selected_training.child_training_count > 0 || this.selected_training.parent_training_id!=null ){
      this.getHiddenSubTrainingList()
      this.training_arr.push(this.selected_training.id)
    }    
    else{
      this.training_arr.push(this.selected_training.id)
    }            
    // this.error_msg_training +=(this.is_hidden==0)?"Unhide ":"Hide ";
    // this.error_msg_training += (this.emp_type =="hco")?"HCO":"employee";  
    // alert(this.error_msg_training)     
  },
  methods: {
    closeModal() {
         this.$emit("close-model", (this.is_hidden == 1) ? 0 : 1);
    },
    async saveHideEmployee() {         
      this.v$.$touch();
      var sub_training;
      const is_valid = await this.v$.$validate();
      if (is_valid)
      {        
        for (sub_training in this.sub_trainings) {           
          if(this.training_arr.indexOf(this.sub_trainings[sub_training].training_id)!=-1)
            {
              this.selected_training_data.push({id:this.sub_trainings[sub_training].training_id,name:this.sub_trainings[sub_training].training.title});                 
            }
        }            
        this.$emit("close-model", false);        
        this.$emit('hide-employee-popup',this.is_hidden, this.training_arr, this.selected_training_data,this.total_trainings)        
      }
    },
    getHiddenSubTrainingList(){      
        var hidden_status=(this.is_hidden == 1) ? 0 : 1;
        this.is_full_page_loader_shown = true;

        axios
            .get(JS_APP_URL +"/training/get-hidden-sub-training-list?location_id=" + this.selected_location.id + "&training_id="+this.parent_training_id+"&emp_user_acntuser_student_id="+this.emp_user_acntuser_student_id+"&emp_user_acntuser_student_type="+this.emp_user_acntuser_student_type+"&is_hidden="+hidden_status)
            .then((response) => {
                this.sub_trainings = response['data']['data'];   
                this.total_trainings =this.sub_trainings.length                
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                this.is_full_page_loader_shown = false;
            });
    },
    checkSelectAll(){
      if(this.training_arr.length != this.sub_trainings.length){
        this.is_send_to_all=false;
        this.all_selected = 0;
      }
      else if(this.training_arr.length == this.sub_trainings.length)
      {
        this.is_send_to_all = true;
        this.all_selected = 1;
      }
    },
    selectAll() {           
        this.training_arr = [];
        var sub_training;                    
        if (this.all_selected == 0){
            for (sub_training in this.sub_trainings) {                       
              this.training_arr.push(this.sub_trainings[sub_training].training_id);                 
            }            
        }            
        this.all_selected =(this.all_selected == 1) ? 0 : 1;
    },
  },
};
</script>
