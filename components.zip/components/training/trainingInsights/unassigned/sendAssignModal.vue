<template>
<div>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button v-if="!is_btn_disabled" @click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto">
              <img
                :src="JS_APP_URL + '/images/send-reminder.svg'" style="width: 140px;margin-bottom: -16px;"
                alt=""
                title=""
                class="warning-icon-modal"
              />
            </div>
            <h2
              class="font-24 blueog--text line-normal text-center mb20"
            >
              <span class="font-24 font_semibold"
                >Assign Training Now?
                </span
              >
            </h2>

            <p class="text-center font-16 text-999 line-normal mb30" v-if="send_assign_modal_emp_student_details.emp_type == 'hco'">
              It looks like {{ send_assign_modal_emp_student_details.first_name }} {{ send_assign_modal_emp_student_details.last_name }} is unassigned for {{training_name}}. Would you like to assign this training now?
            </p>
            <p class="text-center font-16 text-999 line-normal mb30" v-else>
                It looks like {{ send_assign_modal_emp_student_details.first_name }} {{ send_assign_modal_emp_student_details.last_name }} is unassigned for {{ training_name }}. Would you like to assign this training now?
            </p>
            
            <div class="self-center" v-if="selected_training.child_training_count > 0 || this.selected_training.parent_training_id!=null">              
              <div class="mt15 mb20 flex flex-col items-center" :class="{ 'form-group--error': v$.training_arr.$error }">
                <p class="text-center font-16 text-999 mb10" style="line-height: 22px;padding: 0 2rem;" >
                    Select which training(s) you would like to assign.
                </p>
                <div class="col-6 text-left">                                                    
                  <div class="checkbox pb10" v-for="sub_training in sub_trainings">
                    <input type="checkbox" :value="sub_training.training.id" :id="sub_training.training.id" v-model="training_arr" class="checkbox pb15" style="margin-right:14px" @change='checkSelectAll()' />                      
                    <label :for="sub_training.training.id" class="checkbox-label gray_checkmark--text">{{sub_training.training.title_for_tab}}</label>                      
                  </div>                                
                  <div class="checkbox" v-if="selected_training.who_can_train == 'employee' || selected_training.who_can_train == 'hco'  ">
                    <input v-model.trim="is_send_to_all" id="is_send_to_all" name="is_send_to_all" type="checkbox" @change="selectAll()">
                    <label for="is_send_to_all" class="checkbox-label font-14 font-light gray_checkmark--text">(Optional) Assign All Tabs</label>
                  </div>
                  <div class="flex flex mt10">
                    <div v-if="v$.training_arr.$errors.length > 0" class="form-error-text">{{ v$.training_arr.$errors[0].$message }}</div>
                  </div>               
                </div>                              
              </div>
            </div>
            <div class="flex flex-wrap items-center justify-center pb40">
              <button
                class="btn-primary-outline btn-width-136 mx5 px30 mt-xs-20"
                :disabled="is_btn_disabled"
                @click="sendAssign"
              >
                Assign Training
              </button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
  <full-page-loader v-if = "is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script>
import closeIcon from "../../../common/icons/closeIcon.vue";
import axios from "axios";
import useVuelidate from "@vuelidate/core";
import { required, helpers } from "@vuelidate/validators";
import toastr from "toastr";
import NProgress from "nprogress";
import fullPageLoader from "../../../common/fullPageLoader.vue";
import "toastr/toastr.scss";
export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_btn_disabled: false,
      is_send_to_all: false,
      is_full_page_loader_shown: false,
      sub_trainings: {},
      training_arr: [],      
      all_selected: 0,     
      is_full_page_loader_shown: false,
    };
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    return {        
        training_arr: { required: helpers.withMessage("Please select training(s) to assign", required) },          
    }
  },
  props: {
    invite_id: {},
    send_assign_modal_emp_student_details:{},
    training_name:{},
    selected_location:{},
    selected_training:{},
    parent_training_id: null
  },
  emits: ["close-model", 'emp-student-list-for-training'],
  components: {closeIcon, fullPageLoader},
  mounted() {   
    if(this.selected_training.child_training_count > 0 || this.selected_training.parent_training_id!=null ){
      this.getUnassignedSubTrainingList()
      this.training_arr.push(this.selected_training.id)
    }  
    else{
      this.training_arr.push(this.selected_training.id)
    }  
  },
  methods: {
    getUnassignedSubTrainingList()
    {      
        this.is_full_page_loader_shown = true;
        axios
            .get(JS_APP_URL +"/training/get-unassigned-sub-training-list?location_id=" + this.selected_location.id + "&training_id="+this.parent_training_id+"&emp_stud_user_id="+this.send_assign_modal_emp_student_details.emp_user_acntuser_student_id+"&emp_stud_type="+this.send_assign_modal_emp_student_details.emp_user_acntuser_student_type)
            .then((response) => {
                this.sub_trainings = response['data']['data'];                
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                this.is_full_page_loader_shown = false;
            });

    },
    checkSelectAll(){
      if(this.training_arr.length != this.sub_trainings.length){
        this.is_send_to_all=false;
        this.all_selected = 0;
      }
      else if(this.training_arr.length == this.sub_trainings.length)
      {
        this.is_send_to_all = true;
        this.all_selected = 1;
      }
    },
    selectAll() {           
        this.training_arr = [];
        var sub_training;                    
        if (this.all_selected == 0){
            for (sub_training in this.sub_trainings) {                       
              this.training_arr.push(this.sub_trainings[sub_training].training_id);                 
            }            
        }            
        this.all_selected =(this.all_selected == 1) ? 0 : 1;
    },
    closeModal() {
      this.$emit("close-model");
    },
    async sendAssign() {
      this.v$.$touch();
      const is_valid = await this.v$.$validate();
      if (is_valid)
      { 
        NProgress.start();
        this.is_btn_disabled = true;
        axios
        .post(JS_APP_URL + "/training/send-invite-for-training",
            {
                type : this.send_assign_modal_emp_student_details.emp_user_acntuser_student_type ,
                emp_stud_user_id: this.send_assign_modal_emp_student_details.emp_user_acntuser_student_id,
                location_id: this.selected_location.id,                
                training_arr : this.training_arr,
                call_type: "unassignToAssign"
            })
        .then((response) => {
            if (response["data"]["status"] == "Error") {
                if (response["data"]['data'].length > 0) {
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                } else {
                    toastr.error(response["data"]["message"], "Error");
                }
            } else {
                toastr.success(response["data"]["message"], "Success");
                this.$emit('emp-student-list-for-training', 'full');
                this.$emit("close-model", false);
            }
        })
        .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
            }
        })
        .then(() => {
            NProgress.done();
            this.is_btn_disabled = false;
        });
      }
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.is_btn_disabled) {
        this.$emit("close-model");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
