<template>
  <div class="container">
    <div class="row flex-auto -mx-15 justify-end mb26" v-if="training_emp_student_lists.length > 0 && selected_training.who_can_train == 'employee'">
      <div class="col-12 col-md-6 col-lg-5 col-xl-5 px15">
        <div class="row flex-auto -mx-10 justify-center justify-start-small-medium items-center">
          <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 px10  mt-sm-10">
            <div class="flex items-center">
              <div class="form-group account-filter-wrapper mb-0 flex-auto">
                <multiselect
                    v-model="filter_selected_sort_by"
                    tag-placeholder=""
                    placeholder=""
                    label="name"
                    track-by="name"
                    :options="sort_by_array"
                    :multiple="false"
                    :close-on-select="true"
                    :searchable="false"
                    :showLabels="false"
                    @update:model-value="onChangeFilter"
                    :taggable="false">

                    <template #noResult>
                    <div class="multiselect__noResult text-center">
                        No results found
                    </div>
                    </template>
                </multiselect>
                <label class="label label-select font-italic" :class="{ 'label-float': filter_selected_sort_by }">Sort by</label>
              </div>
              <img @click="toggleSortDir" v-if="filter_selected_sort_by != null && sort_by_dir == 'ASC'" :src="JS_APP_URL + '/images/sort-up.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" />
              <img @click="toggleSortDir" v-if="filter_selected_sort_by != null && sort_by_dir == 'DESC'" :src="JS_APP_URL + '/images/sort-down.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5"/>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 px10 mt-sm-10">
            <div class="form-group account-filter-wrapper mb-0">
              <input class="form-input form-input-search" type="text" v-model="searchQuery"/>
              <label class="label font-italic" :class="{ 'label-float': searchQuery }">Search</label>
              <div class="search-btn-input">
                <img :src="JS_APP_URL + '/images/search.svg'" alt="" title="" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div>
      <div v-if="training_emp_student_lists.length > 0" >
        <div class="assigned-emp-training-tbl-item table-responsive">
          <table class="assigned-emp-training-table" border="0" cellpadding="4" cellspacing="5">
            <thead>
                <tr>
                    <th style="width: 25%" v-text="(selected_training.who_can_train == 'employee') ? 'Employee Name' : 'HCO Name'"></th>
                    <th style="width: 25%" v-text="(selected_training.who_can_train == 'employee') ? 'Date Employee Added' : 'Date HCO Added'"></th>
                    <th style="width: 25%">Video/Quiz</th>
                    <th style="width: 25%">Hide</th>
                </tr>
            </thead>
          </table>
        </div>
        <div>
          <unassigned-list
                v-for="training_emp_student_list in searchingSortingResult"
                :key="training_emp_student_list.id"
                :selected_training = "selected_training"
                :selected_location = "selected_location"
                :training_emp_student_list = "training_emp_student_list"
                @emp-student-list-for-training  = "empStudentListForTraining"                
                @send-assign-popup="sendAssignModalToggle"
          />          
        </div>
      </div>
      <div v-if="!is_full_page_loader_shown && searchingSortingResult.length === 0" class="">
        <div class="user-detail-text font-14 gray_checkmark--text text-center mt20">
            <no-data-icon></no-data-icon>
            <div class="font-14 text-center blueog--text">No {{ (selected_training.who_can_train == 'hco') ? 'HCO' : 'employee(s)' }} available.</div>
        </div>
      </div>
      <send-assign
            :selected_location = "selected_location"
            :selected_training = "selected_training"
            :invite_id = "send_assign_modal_invite_id"
            :send_assign_modal_emp_student_details = "send_assign_modal_emp_student_details"
            :parent_training_id = "parent_training_id"
            @close-model = "sendAssignModalToggle"
            v-if = "send_assign_modal"
            :training_name = "selected_training.title"
            @emp-student-list-for-training  = "empStudentListForTraining"
          />
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import fullPageLoader from "../../../common/fullPageLoader.vue";
import unassignedList from "./unassignedList.vue";
import sendAssign from "./sendAssignModal.vue";
import noDataIcon from '../../../common/icons/noDataIcon.vue';
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_full_page_loader_shown: false,
            filter_selected_sort_by: null,
            sort_by_dir: "ASC",
            sort_by_array: [
                { name: "Name", key: "emp_user_acntuser_student.first_name" },
                { name: "Last Added Employee", key: "created_at" },
            ],
            searchQuery: null,
            training_emp_student_lists: [],
            unassigned_training_id: null,
            send_assign_modal: false,
            send_assign_modal_invite_id: "",
            send_assign_modal_emp_student_details: "",
            is_hidden: null,
            emp_type: null,
            calling_ajax: 0,
            is_hidden_var: null,
            delay_timer: "",                        
            parent_training_id : null,            
        }
    },
    computed: {
        searchingSortingResult() {
            let sortable_array = this.training_emp_student_lists ? this.training_emp_student_lists : [];           
            if (this.searchQuery != null) {
                let query = this.searchQuery ? this.searchQuery.toLowerCase().split(" ") : null;
                sortable_array = sortable_array.filter((item) => {
                    return !query || query
                        .every(
                            (v) =>
                                item.emp_user_acntuser_student.first_name.toLowerCase().includes(v) ||
                                item.emp_user_acntuser_student.last_name.toLowerCase().includes(v)
                        );
                });
            }
            return sortable_array;
        },
    },
    components: {
        fullPageLoader, unassignedList, sendAssign,  noDataIcon,
    },
    mounted(){
        this.empStudentListForTraining('full');
    },
    props: {
        selected_location: {},
        selected_training: {}
    },
    methods: {
        sendAssignModalToggle(invite_id = "", training_emp_student_list = "", parent_training_id = "") {            
            if (this.send_assign_modal == true) {
                this.send_assign_modal = false;
            } else {
                this.send_assign_modal_invite_id = invite_id
                this.send_assign_modal_emp_student_details = training_emp_student_list
                this.send_assign_modal = true;
                this.parent_training_id =  parent_training_id
            }
        },
        toggleSortDir() {
            this.sort_by_dir = this.sort_by_dir == "ASC" ? "DESC" : "ASC";
            this.empStudentListForTraining('half');
        },
        onChangeFilter() {
            if (this.delay_timer) {
                clearTimeout(this.delay_timer);
                this.delay_timer = null;
            }
            this.delay_timer = setTimeout(() => {
                   this.empStudentListForTraining('half');
            }, 800);
        },
        empStudentListForTraining(refresh = '') {
            if (refresh=='full') {
                this.training_emp_student_lists = [];
                this.filter_selected_sort_by = null;
                this.sort_by_dir = "ASC";  
                this.searchQuery = "";              
            }
            else if (refresh == 'half') {
                this.training_emp_student_lists = [];
            }

            if (this.selected_location.id != undefined && this.selected_location.id != '' && this.selected_training.id != undefined && this.selected_training.id != "" && this.calling_ajax == 0) 
            {
                if (this.selected_training.training_code == 'HT1' || this.selected_training.training_code == 'HT2' || (this.selected_training.training_location != null  && this.selected_training.training_location[0].is_triggered == 0))
                {
                    this.$emit('change-activate-tabs', 'assigned_emp')
                }
                else
                {
                    this.calling_ajax = 1;
                    this.is_full_page_loader_shown = true;
                    let param = {
                        location_id: this.selected_location.id,
                        training_id: this.selected_training.id,
                        sort_by: (this.filter_selected_sort_by != null) ? this.filter_selected_sort_by.key : '',                        
                        sort_by_dir: (this.filter_selected_sort_by == '' || this.filter_selected_sort_by == null) ? "DESC" : this.sort_by_dir,
                    };

                    axios
                    .post(JS_APP_URL + "/training/unassigned-employee-student-list-for-training", param)
                    .then((response) => {
                        if (response["data"]["status"] == "Success") {
                            this.training_emp_student_lists = response.data.data.unassigned_list;
                            this.is_full_page_loader_shown = false;
                        }
                        else {
                            if (response["data"]["message"] == "Complete SRA first") {
                                window.location = JS_APP_URL + "/dashboard";
                            } else {
                                if (response["data"]['data'].length > 0) {
                                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                                } else {
                                    toastr.error(response["data"]["message"], "Error");
                                }
                            }
                        }
                    })
                    .catch((error) => {
                        toastr.error(error.response["data"]["message"], "Error");
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        this.is_full_page_loader_shown = false;
                        this.calling_ajax = 0;
                    });
                }                
            }
        },

    },    
    watch: {
        selected_training() {
            this.empStudentListForTraining('full');
        },
    },
    emits: ['change-activate-tabs'],
}
</script>
