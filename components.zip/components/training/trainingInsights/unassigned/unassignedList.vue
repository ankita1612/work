<template>
    <div class="light unassigned-emp-inner-item mb26 table-responsive">
        <table class="assigned-emp-training-table" border="0" cellpadding="4" cellspacing="5">
            <tbody>
                <tr>
                    <td style="width: 25%;">
                        <div class="inline-flex items-center felx-wrap justify-between full-width" >
                        <span class="font-14  mr15" :class="(training_emp_student_list.emp_type != 'secondary') ? 'font_semibold darkgray--text' :  (training_emp_student_list.is_hidden == 1) ? 'gray_checkmark--text font-italic' : 'font_semibold gray_checkmark--text font-italic'">{{ training_emp_student_list.emp_user_acntuser_student.first_name }} {{ training_emp_student_list.emp_user_acntuser_student.last_name }}</span>
                        <span>
                        <button v-if="training_emp_student_list.emp_type == 'primary' && training_emp_student_list.emp_user_acntuser_student.employee_secondary_work_location.length > 0 " type="button" class="ml6">
                            <VTooltip :triggers="['hover']" :popperTriggers="['hover']">
                                <img :src="JS_APP_URL + '/images/location-blue.svg'" alt="" title="" class="cursor-pointer"/>
                                <template #popper>
                                    <div class="white--text font-12 font_semibold mb2 text-center pb5 pt5">
                                        SECONDARY LOCATION(S)
                                    </div>
                                    <div class="text-center seperator-line pt3 pb" v-for="(each_location, each_location_index) in training_emp_student_list.emp_user_acntuser_student.employee_secondary_work_location"
                                        v-bind:key="each_location_index" v-text="each_location.location.location_nickname">
                                    </div>
                                </template>
                            </VTooltip>
                        </button>
                        <button v-else-if="training_emp_student_list.emp_type == 'secondary' && training_emp_student_list.emp_user_acntuser_student.employee_primary_work_location != null > 0" type="button" class="ml6"  title="">
                                <VTooltip :triggers="['hover']" :popperTriggers="['hover']">
                                    <img :src="JS_APP_URL + '/images/location_.svg'" alt="" title="" class="cursor-pointer"/>
                                    <template #popper>
                                        <div class="white--text font-12 font_semibold mb2 text-center pb5 pt5">
                                            PRIMARY LOCATION
                                        </div>
                                        <div class="text-center seperator-line pt3 pb" v-bind:key="training_emp_student_list.emp_user_acntuser_student.employee_primary_work_location.id" v-text="training_emp_student_list.emp_user_acntuser_student.employee_primary_work_location.location_nickname">
                                        </div>
                                    </template>
                                </VTooltip>
                            </button>
                        </span>
                        </div>
                    </td>

                    <td style="width: 25%;" class="font-14 mr15 ">
                        <span :class="(training_emp_student_list.emp_type != 'secondary') ? 'font_semibold darkgray--text' : (training_emp_student_list.is_hidden == 1) ? 'gray_checkmark--text font-italic' : 'font_semibold gray_checkmark--text font-italic'" >{{ (training_emp_student_list.created_at!=null)?$filters.formatDate(training_emp_student_list.created_at):"NA" }}</span>
                    </td>

                    <td style="width: 25%;" v-if="((training_emp_student_list.emp_type == 'primary' && training_emp_student_list.emp_user_acntuser_student.status == 'active') ||(training_emp_student_list.emp_type == 'hco')) && training_emp_student_list.is_hidden == 0">
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml6">
                            <button @click="sendAssignModalOpen(training_emp_student_list)" type="button" class="action-icon-btn action-btn-blue cursor-pointer send-action-btn overflow-hide " title="">
                                <span class="pending-svg-icon inline-flex items-center justify-center"><sendTrainingIcon></sendTrainingIcon></span>
                            </button>
                            <template #popper>
                                Click send to assign this training now.
                            </template>
                        </VTooltip>
                    </td>
                    <td style="width: 25%;" v-else>
                        <button type="button" class="action-icon-btn action-btn-blue cursor-pointer send-action-btn overflow-hide disable">
                            <span class="pending-svg-icon inline-flex items-center justify-center"><sendTrainingIcon></sendTrainingIcon></span>
                        </button>
                    </td>
                    <td style="width: 25%;">
                        <div class="flex flex-wrap items-center justify-center"  >
                            <div class="flex flex-wrap items-center justify-center">
                                <div class="radio mr8">
                                    <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" >
                                        <input v-model.trim="training_emp_student_list.is_hidden"  class="form-check-input" :id="'is_hidden_yes_' + training_emp_student_list.id" :name="'is_hidden_' + training_emp_student_list.id" type="radio" value="1"
                                        @change="showSubtrainigModalOpen(1)" :disabled="((training_emp_student_list.emp_type == 'primary' && training_emp_student_list.emp_user_acntuser_student.status == 'active') || (training_emp_student_list.emp_type == 'hco')) ? false : true"
                                        />
                                        <label :for= "'is_hidden_yes_' + training_emp_student_list.id" class="radio-label font-14 font-light "  :class="(training_emp_student_list.emp_type != 'secondary') ? 'font_semibold darkgray--text' : (training_emp_student_list.is_hidden == 1) ? 'gray_checkmark--text font-italic' : 'font_semibold gray_checkmark--text font-italic'">Yes</label>
                                        <template #popper>
                                            Hide an {{(training_emp_student_list.emp_type == 'hco')?'HCO':'employee' }} to remove them from the Unassigned {{ (training_emp_student_list.emp_type == 'hco') ? 'HCO' : 'Employee' }} count for this training on the dashboard.
                                        </template>
                                    </VTooltip>
                                </div>
                                <div class="radio ml8">
                                    <input v-model.trim="training_emp_student_list.is_hidden"  class="form-check-input" :id="'is_hidden_no_'+training_emp_student_list.id" :name="'is_hidden_'+training_emp_student_list.id" type="radio" value="0" @change="showSubtrainigModalOpen(0)" :disabled="((training_emp_student_list.emp_type == 'primary' && training_emp_student_list.emp_user_acntuser_student.status == 'active') || (training_emp_student_list.emp_type == 'hco')) ? false : true"
                                    />
                                    <label :for="'is_hidden_no_'+training_emp_student_list.id" class="radio-label font-14 font-light" :class="(training_emp_student_list.emp_type != 'secondary') ? 'font_semibold darkgray--text' : (training_emp_student_list.is_hidden == 1) ? 'gray_checkmark--text font-italic' : 'font_semibold gray_checkmark--text font-italic'">No</label>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>        
        <hide-subtraining-modal
            v-if="hide_sub_training_modal == 'true'"            
            :is_hidden = "is_hidden"
            :selected_training = "selected_training"
            :selected_location = "selected_location"
            :emp_type = "emp_type"
            :parent_training_id ="parent_training_id"
            @close-model = "closeModelSubTraining"            
            :emp_user_acntuser_student_type = "training_emp_student_list.emp_user_acntuser_student_type"
            :emp_user_acntuser_student_id = "training_emp_student_list.emp_user_acntuser_student_id"    
            @hide-employee-popup = "hideEmployeeModalOpen"            
        />

        <hide-employee-modal
            v-if="hide_training_modal == 'true'"            
            :is_hidden = "is_hidden"
            :selected_training = "selected_training"
            :selected_location = "selected_location"
            :emp_type = "emp_type"
            @close-model = "closeModelHideEmployee"  
            :emp_user_acntuser_student_type =  "training_emp_student_list.emp_user_acntuser_student_type"
            :emp_user_acntuser_student_id = "training_emp_student_list.emp_user_acntuser_student_id"      
            :training_arr = "training_arr"  
            :selected_training_data  ="selected_training_data"
            :total_trainings = "total_trainings"
        />
    </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import pdfIcon from "../../../common/icons/pdfIcon.vue";
import infoIcon from "../../../common/icons/infoIcon.vue"
import pendingTraining from "../../../common/icons/pendingTraining.vue"
import viewFileIcon from "../../../common/icons/viewFileIcon.vue"
import sendTrainingIcon from "../../../common/icons/sendTrainingIcon.vue"
import fullPageLoader from "../../../common/fullPageLoader.vue";
import hideEmployeeModal from "./hideEmployeeModal.vue";
import hideSubtrainingModal from "./hideSubtrainingModal.vue";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_full_page_loader_shown: false,
            hide_training_modal: false,
            is_hidden: null,
            hide_sub_training_modal: null,            
            emp_type: null,
            emp_student_data: [],
            parent_training_id: null,
            training_arr:[],
            selected_training_data:[],
            total_trainings:1
        }
    },
    props: {
        training_emp_student_list: {},
        selected_location: {},
        selected_training: {},        
    },
    components: {
        pdfIcon, infoIcon, pendingTraining, viewFileIcon, sendTrainingIcon, fullPageLoader, hideEmployeeModal, hideEmployeeModal, hideSubtrainingModal
    },

    methods: {
        get_training_emp_student_list(refresh) {
            this.$emit('emp-student-list-for-training', 'full');
        },
        closeModelSubTraining(is_hidden) {            
            this.training_emp_student_list.is_hidden = is_hidden
            this.hide_sub_training_modal = false;                
        },
        closeModelHideEmployee(is_hidden) {
            this.training_emp_student_list.is_hidden = is_hidden
            this.hide_training_modal = false;
            this.$emit('emp-student-list-for-training', 'full');        
        },
        showSubtrainigModalOpen(is_hidden) {            
            if( this.selected_training.parent_training_id != null || this.selected_training.child_training_count > 0){                
                this.parent_training_id = (this.selected_training.parent_training_id==null? this.selected_training.id : this.selected_training.parent_training_id)                 
                this.hide_sub_training_modal = "true";
                this.is_hidden = is_hidden;
                this.emp_type = this.training_emp_student_list.emp_type; 
            }
            else{                       
                this.hide_training_modal = "true";                
                this.is_hidden = is_hidden;
                this.emp_type = this.training_emp_student_list.emp_type; 
                this.training_arr=[this.selected_training.id]   
                this.selected_training_data = [{id:this.selected_training.id, name:this.selected_training.title}]
                this.total_trainings = 1
            }        
        },
        hideEmployeeModalOpen(is_hidden, training_arr, selected_training_data, total_trainings) {            
            this.hide_training_modal = "true";            
            this.is_hidden = is_hidden;
            this.emp_type = this.training_emp_student_list.emp_type;
            this.training_arr = training_arr
            this.selected_training_data = selected_training_data
            this.total_trainings = total_trainings            
        },
        sendAssignModalOpen(training_emp_student_list) {            
            var parent_training_id = (this.selected_training.parent_training_id==null? this.selected_training.id : this.selected_training.parent_training_id)              
            this.emp_student_data.emp_type = training_emp_student_list.emp_type
            this.emp_student_data.first_name = training_emp_student_list.emp_user_acntuser_student.first_name
            this.emp_student_data.last_name = training_emp_student_list.emp_user_acntuser_student.last_name
            this.emp_student_data.emp_user_acntuser_student_type = training_emp_student_list.emp_user_acntuser_student_type
            this.emp_student_data.emp_user_acntuser_student_id = training_emp_student_list.emp_user_acntuser_student_id
            this.$emit('send-assign-popup', '', this.emp_student_data, parent_training_id)
        },
    },
    emits: ['hide-employee-modal-toggle', 'send-assign-popup','emp-student-list-for-training'],
}
</script>
