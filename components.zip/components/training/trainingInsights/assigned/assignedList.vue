<template>
    <div class="assigned-emp-item light py10 mb30 table-responsive">
      <table
          class="assigned-emp-training-table" border="0" cellpadding="0" cellspacing="0">
          <tbody>
              <tr>
                  <td style="width: 16%">
                      <div class="inline-flex items-center felx-wrap justify-between full-width">
                      <span class="font-14 font_semibold" :class="(training_emp_student_list.emp_type == 'secondary') ? ' gray_checkmark--text mr15 font-italic' : 'darkgray--text'" >{{ training_emp_student_list.first_name }} {{ training_emp_student_list.last_name }}</span>
                      <span>
                          <button v-if="training_emp_student_list.emp_type == 'primary' && training_emp_student_list.employee_secondary_work_location.length > 0" type="button" class="ml6"  title="">
                          <VTooltip :triggers="['hover']" :popperTriggers="['hover']">
                              <img :src="JS_APP_URL + '/images/location-blue.svg'" alt="" title="" class="cursor-pointer"/>
                              <template #popper>
                                  <div class="white--text font-12 font_semibold mb2 text-center pb5 pt5">
                                      SECONDARY LOCATION(S)
                                  </div>
                                  <div class="text-center seperator-line pt3 pb" v-for="(each_location, each_location_index) in training_emp_student_list.employee_secondary_work_location"
                                      v-bind:key="each_location_index" v-text="each_location.location.location_nickname">
                                  </div>
                              </template>
                          </VTooltip>
                          </button>
  
                          <button v-else-if="training_emp_student_list.emp_type == 'secondary' && training_emp_student_list.employee_primary_work_location != null > 0" type="button" class="ml6"  title="">
                              <VTooltip :triggers="['hover']" :popperTriggers="['hover']">
                                  <img :src="JS_APP_URL + '/images/location_.svg'" alt="" title="" class="cursor-pointer"/>
                                  <template #popper>
                                      <div class="white--text font-12 font_semibold mb2 text-center pb5 pt5">
                                          PRIMARY LOCATION
                                      </div>
                                      <div class="text-center seperator-line pt3 pb" v-bind:key="training_emp_student_list.employee_primary_work_location.id" v-text="training_emp_student_list.employee_primary_work_location.location_nickname">
                                      </div>
                                  </template>
                              </VTooltip>
                          </button>
                      </span>
                      </div>
                  </td>
  
                  <td style="width: 14%" class="font-14 mr15 " v-if="training_emp_student_list.training_invite != null">
                      <span class="font_semibold " :class="(training_emp_student_list.emp_type == 'secondary') ? 'font_normal gray_checkmark--text font-italic' : 'darkgray--text'" >{{ $filters.formatDate(training_emp_student_list.training_invite.invite_datetime) }}</span>
                  </td>
                  <td style="width: 14%" class="font-14 mr15 font_semibold" v-else> <span :class="(training_emp_student_list.emp_type == 'secondary') ? ' gray_checkmark--text font-italic' : ' darkgray--text'" >NA</span></td>
  
                  <td style="width: 13%" class="font-14 mr15 ">
                      <span class="inline-flex items-center relative font_semibold" :class="(training_emp_student_list.emp_type == 'secondary') ? 'gray_checkmark--text font-italic' : 'darkgray--text'">
                      <div class="mr8">{{ (training_emp_student_list.training_attempt_count==0)?"None": training_emp_student_list.training_attempt_count }}</div>
                      <VTooltip
                          :triggers="['hover']"
                          :popperTriggers="['hover']"
                          style="height: 24px"
                          class="cursor-pointer inline-block failed-training-info"
                          v-if="training_emp_student_list.is_video_quiz_completed == false &&
                              training_emp_student_list.training_attempt_count > 0
                              "
                      >
                          <a v-on:click="trainingAttemptFailedModalOpen(training_emp_student_list.training_invite.id, training_emp_student_list.first_name,
                              training_emp_student_list.last_name)" target="_blank"  title=""
                          ><span><info-icon></info-icon></span
                          ></a>
                          <template #popper>Click here to view failed attempts</template>
                      </VTooltip>
  
                      </span>
                  </td>
  
                  <td style="width: 14%">
                      <span v-if="training_emp_student_list.is_video_quiz_completed == true">
                          <button  type="button" class="complete-img-btn"  title="">
                              <img :src="JS_APP_URL +'/images/Complete.svg'" alt="" title="" width="32" height="32" />
                          </button>
                      </span>
                      <span class="font-14 font_semibold uppercase" v-else-if="training_emp_student_list.is_video_quiz_completed == false && training_emp_student_list.emp_type == 'secondary'">
                          <button type="button" class="action-icon-btn cursor-pointer assigned-pending-btn disable" title="">
                              <span class="pending-svg-icon inline-flex items-center justify-center"><pendingTraining></pendingTraining></span>
                          </button>
                      </span>
  
                      <span class="font-14 font_semibold uppercase " v-else-if="training_emp_student_list.is_video_quiz_completed == false && training_emp_student_list.emp_type != 'secondary'" @click="(training_emp_student_list.emp_type == 'primary' && training_emp_student_list.status != 'active') ? null : sendReminderModalOpen(training_emp_student_list.training_invite.id, training_emp_student_list)">
                      <button type="button" class="action-icon-btn cursor-pointer assigned-pending-btn" :class="[(training_emp_student_list.emp_type == 'primary' && training_emp_student_list.status != 'active') ? 'disable' : '']" title="">
                          <span class="pending-svg-icon inline-flex items-center justify-center"><pendingTraining></pendingTraining></span>
                      </button>
                      </span>
                  </td>
  
                  <td style="width: 14%">
                      <span class="font-14 font_semibold uppercase"  v-if="training_emp_student_list.is_video_quiz_completed == true" @click=" viewCertificateModalOpen(training_emp_student_list.training_invite.id)">
                      <button type="button" class="action-icon-btn action-btn-blue cursor-pointer complete-action-btn overflow-hide" title="">
                      <span class="pending-svg-icon inline-flex items-center justify-center"><view-file-icon></view-file-icon></span>
                      </button>
                      </span>
                      <span v-else >
                      <button type="button" class="action-icon-btn action-btn-blue complete-action-btn pdf-round-btn disable" title="">
                          <span class="pending-svg-icon inline-flex items-center justify-center"><pdf-icon></pdf-icon></span>
                      </button>
                      </span>
                  </td>
  
                  <td style="width: 15%" class="font-14 mr15 "> <span class="font_semibold " :class="(training_emp_student_list.emp_type == 'secondary') ? 'gray_checkmark--text font-italic' : 'darkgray--text'">{{ (training_emp_student_list.training_invite != null) ? training_emp_student_list.training_invite.reason : "" }}</span></td>
  
                  <td style="width: 14%">
                      <button type="button" class="training-resend " :class="(is_triggered == true && training_emp_student_list.is_video_quiz_completed == true && ((training_emp_student_list.emp_type == 'primary' && training_emp_student_list.status == 'active') || training_emp_student_list.emp_type == 'hco') && training_emp_student_list.is_resend_enabled == 1) ? 'cursor-pointer' : ''"  @click="(is_triggered == true && training_emp_student_list.is_video_quiz_completed == true && ((training_emp_student_list.emp_type == 'primary' && training_emp_student_list.status == 'active') || training_emp_student_list.emp_type == 'hco' ) && training_emp_student_list.is_resend_enabled == 1) ? resendtrainingModalOpen(): null"  title="">
                          <img :src="(is_triggered == true && training_emp_student_list.is_video_quiz_completed == true && ((training_emp_student_list.emp_type == 'primary' && training_emp_student_list.status == 'active') || training_emp_student_list.emp_type == 'hco') && training_emp_student_list.is_resend_enabled == 1) ? JS_APP_URL + '/images/resend.svg' : JS_APP_URL + '/images/resend-gray.svg'" alt="" title="" />
                      </button>
                      <div class="text-center" v-if="training_emp_student_list.training_invite_count > 1 && see_more == 1">
                          <a href="javascript:void(0)" class="see-more-link font-14 blueog--text font_semibold text-decoration-underline" @click="inviteHistory(training_emp_student_list.id, training_emp_student_list.type)"  title="See More">See More</a>
                      </div>
                  </td>
              </tr>
              <invite-history
              v-if = "training_emp_student_list.id == emp_student_id_history"
              :training_invites = "training_invites"
              :emp_type = "training_emp_student_list.emp_type"
              :emp_status = "training_emp_student_list.status"
              :training_emp_student_id = "training_emp_student_list.id"
              :emp_first_name = "training_emp_student_list.first_name"
              :emp_last_name = "training_emp_student_list.last_name"
              :emp_detail = "training_emp_student_list"
              @close-invite-history = "inviteHistory"
              @training-attempt-failed = "trainingAttemptFailedModalOpen"
              @view-certificate = "viewCertificateModalOpen"
              @send-reminder-popup = "sendReminderModalOpen"
              />
          </tbody>
      </table>
    </div>
  </template>
  
  <script scoped>
  import axios from "axios";
  import pdfIcon from "../../../common/icons/pdfIcon.vue";
  import infoIcon from "../../../common/icons/infoIcon.vue"
  import pendingTraining from "../../../common/icons/pendingTraining.vue"
  import viewFileIcon from "../../../common/icons/viewFileIcon.vue"
  import sendTrainingIcon from "../../../common/icons/sendTrainingIcon.vue"
  import inviteHistory from "./inviteHistory.vue";
  import NProgress from "nprogress";
  
  export default {
      data() {
          return {
              JS_APP_URL: JS_APP_URL,
              emp_student_id_history: null,
              see_more: 1,
              send_reminder_modal: false,
              training_invites :[]
          }
      },
      components: {
          pdfIcon, infoIcon, pendingTraining, viewFileIcon, sendTrainingIcon, inviteHistory
      },
      props: {
          training_emp_student_list: {},
          selected_location: {},
          selected_training: {},
          is_triggered: true
      },
     // emits: [ "get-training-list-for-report"],
      emits: ["training-attempt-failed-popup", "send-reminder-popup", "view-certificate", "resend-training-popup", "emp-student-list-for-training", 'close-modal','sub-training-selection-popup'],
      mounted() {
  
      },
      methods: {
          inviteHistory(training_emp_student_id = '', emp_student_type) {
              if (this.see_more == 1) {
                  NProgress.start();
                  this.emp_student_id_history = training_emp_student_id;
                  this.see_more = 0;
                  let param = {
                          location_id: this.selected_location.id,
                          training_id: this.selected_training.id,
                          emp_stud_user_id: training_emp_student_id,
                          type: emp_student_type
                  };
                  axios
                      .post(JS_APP_URL + "/training/employee-student-invite-list-for-training", param)
                      .then((response) => {
                          if (response["data"]["status"] == "Success") {
                              this.training_invites = response.data.data;
                          }
                      })
                      .catch((error) => {
                          toastr.error(error.response["data"]["message"], "Error");
                          if (error.response.status === 401) {
                              window.location = JS_APP_URL + "/login";
                          }
                      })
                      .then(() => {
                         NProgress.done();
                      });
              }
              else
              {
                  this.emp_student_id_history = null;
                  this.see_more = 1;
              }
          },
          trainingAttemptFailedModalOpen(training_invite_id, first_name, last_name) {
              NProgress.start();
              let param = {
                  invite_id: training_invite_id,
              };
              axios
                  .post(JS_APP_URL + "/training/get-training-attempts-failed", param)
                  .then((response) => {
                      var training_attempt_failed_result = response["data"]["data"];
                      this.$emit(
                          "training-attempt-failed-popup",
                          first_name,
                          last_name,
                          training_attempt_failed_result
                      );
                  })
                  .catch((error) => {
                      toastr.error(error.response["data"]["message"], "Error");
                      if (error.response.status === 401) {
                          window.location = JS_APP_URL + "/login";
                      }
                  })
                  .then((response) => {
                      NProgress.done();
                  })
          },
          sendReminderModalOpen(training_invite_id, training_emp_student_list) {
              this.$emit('send-reminder-popup', training_invite_id, training_emp_student_list)
          },
          resendtrainingModalOpen() {                        
            if( this.selected_training.parent_training_id != null || this.selected_training.child_training_count > 0){
                var parent_training_id = (this.selected_training.parent_training_id==null? this.selected_training.id : this.selected_training.parent_training_id)                
                this.$emit('sub-training-selection-popup',this.training_emp_student_list.id, this.training_emp_student_list.type, parent_training_id)
            }
            else{                
                this.$emit('resend-training-popup',this.training_emp_student_list.id, this.training_emp_student_list.type,[this.selected_training.id])
            }            
        },
          viewCertificateModalOpen(invite_id) {
              this.$emit('view-certificate', invite_id);
          },
  
      },
  }
  </script>