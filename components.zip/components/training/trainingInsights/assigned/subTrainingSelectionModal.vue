<template>
<div>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button @click="closeModal" class="cursor-pointer modal-close" v-if="!is_btn_disabled">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb10">
              <img
                :src="JS_APP_URL + '/images/envelop-upload.svg'"
                alt=""
                title=""
                class="warning-icon-modal"
              />
            </div>
            <h2
              class="
                font-21 font_semibold
                blueog--text
                line-normal
                text-center
                mb10
              "
            >
              Resend Training?
            </h2>
            <p class="text-center font-16 text-999 mb10" style="line-height: 22px;padding: 0 2rem;" >
              Select which training(s) you would like to resend.             
            </p>                 
            <div class="self-center" v-if="selected_training.child_training_count > 0 || this.selected_training.parent_training_id!=null">
              <div class="mt15 mb20 flex flex-col items-center" :class="{ 'form-group--error': v$.training_arr.$error }">
                <div class="col-6 text-left">                                  
                  <div class="checkbox pb10" v-for="sub_training in sub_trainings">
                    <input type="checkbox" :value="sub_training.id" :id="sub_training.id" v-model="training_arr" class="checkbox pb15" style="margin-right:14px" @change='checkSelectAll()' />                      
                    <label :for="sub_training.id" class="checkbox-label gray_checkmark--text">{{sub_training.title_for_tab}}</label>                      
                  </div>                       
                  <div class="checkbox" >
                    <input v-model.trim="is_send_to_all" id="is_send_to_all" name="is_send_to_all" type="checkbox" @change="selectAll()">
                    <label for="is_send_to_all" class="checkbox-label font-14 font-light gray_checkmark--text">(Optional) Resend All Tabs</label>
                  </div>                               
                  <div class="flex mt10">
                      <div v-if="v$.training_arr.$errors.length > 0" class="form-error-text">{{ v$.training_arr.$errors[0].$message }}</div>
                  </div>                           
                </div>
              </div>
            </div>
            <div class="flex flex-wrap items-center justify-center">
              <button class="btn-primary-outline mx15 btn-width-120 h-32" :disabled="is_btn_disabled"  @click="resendTraining">CONFIRM</button>
              <button class="btn-cancel-outline mx15 btn-width-120 h-32" :disabled="is_btn_disabled" @click="closeModal">CANCEL</button>              
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
    <full-page-loader v-if = "is_full_page_loader_shown"></full-page-loader>
    <div class="modal-backdrop"></div>
</div>
</template>

<script scoped>
import closeIcon from "../../../common/icons/closeIcon.vue";
import useVuelidate from "@vuelidate/core";
import { required, helpers } from "@vuelidate/validators";
import fullPageLoader from "../../../common/fullPageLoader.vue";
import axios from "axios";
import toastr from "toastr";
import NProgress from "nprogress";
import "toastr/toastr.scss";
export default {
  setup: () => ({ v$: useVuelidate() }),
  components: { closeIcon, fullPageLoader },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_btn_disabled: false,
      selected_employee: "",
      hco_id: "",
      resend_option: null,
      training_type: "",
      is_send_to_all: false,
      sub_trainings: {},
      training_arr: [],      
      all_selected: 0,     
      is_full_page_loader_shown: false,
    };
  },
  validations() {
    return {        
        training_arr: { required: helpers.withMessage("Please select training(s) to resend", required) },          
    }
  },
    props: {
        selected_location: {},
        selected_training: {},
        emp_stud_type: null,
        emp_stud_user_id: null,
        parent_training_id: null
  },
  emits: ["close-model", "resend-training-popup"],
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  },
  watch: {},
  mounted() {
    if(this.selected_training.child_training_count > 0 || this.selected_training.parent_training_id!=null ){
      this.getSubTrainingListForResend()
      this.training_arr.push(this.selected_training.id)
    }    
    else{
      this.training_arr.push(this.selected_training.id)
    }  
  },
  methods: {
    checkSelectAll(){
      if(this.training_arr.length != this.sub_trainings.length){
        this.is_send_to_all = false;
        this.all_selected = 0;
      }
      else if(this.training_arr.length == this.sub_trainings.length)
      {
        this.is_send_to_all = true;
        this.all_selected = 1;
      }
    },
    selectAll() {           
        this.training_arr = [];
        var sub_training;                    
        if (this.all_selected == 0){
            for (sub_training in this.sub_trainings) {                       
              this.training_arr.push(this.sub_trainings[sub_training].id);                 
            }            
        }            
        this.all_selected =(this.all_selected == 1) ? 0 : 1;
    },
    getSubTrainingListForResend()
    {
        this.is_full_page_loader_shown = true;
        axios
            .get(JS_APP_URL +"/training/get-sub-training-list-for-resend?location_id=" + this.selected_location.id + "&training_id="+this.parent_training_id+"&emp_stud_user_id="+this.emp_stud_user_id+"&emp_stud_type="+this.emp_stud_type)
            .then((response) => {
                this.sub_trainings = response['data']['data'];               
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                this.is_full_page_loader_shown = false;
            });

    },
    async resendTraining() {
      this.v$.$touch();
      const is_valid = await this.v$.$validate();
      if (is_valid)
      {
        this.$emit("close-model", false);
        this.$emit('resend-training-popup',this.emp_stud_user_id, this.emp_stud_type, this.training_arr)
      }
    },
    closeModal() {
      this.$emit("close-model");
    },
  },
};
</script>
