<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button v-if="!is_btn_disabled" @click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto">
              <img
                :src="JS_APP_URL + '/images/send-reminder.svg'" style="width: 140px;margin-bottom: -16px;"
                alt=""
                title=""
                class="warning-icon-modal"
              />
            </div>
            <h2
              class="font-24 blueog--text line-normal text-center mb20"
            >
              <span class="font-24 font_semibold"
                >Send a reminder to complete <br/> Training Video &amp; Quiz?</span
              >
            </h2>

            <p class="text-center font-16 text-999 line-normal mb30" v-if="send_reminder_modal_emp_student_details.emp_type == 'hco'">
              It looks like {{send_reminder_modal_emp_student_details.first_name}} {{send_reminder_modal_emp_student_details.last_name}} hasn't completed their {{ training_name }} just yet. Would you like to send them a reminder to complete
              the required training in their training section?
            </p>
            <p class="text-center font-16 text-999 line-normal mb30" v-else>
               It looks like {{ send_reminder_modal_emp_student_details.first_name }} {{ send_reminder_modal_emp_student_details.last_name }} hasn't completed their
                    {{ training_name }} just yet. Would you like to send them a reminder to complete
                the required training in their Employee Portal?
            </p>
            <div class="checkbox pb20 pt20" v-if="send_reminder_modal_emp_student_details.emp_type != 'hco'">
              <input v-model.trim="is_send_to_all" id="is_send_to_all" name="is_send_to_all" type="checkbox">
              <label for="is_send_to_all"  class="checkbox-label font-16 gray_checkmark--text">Send Reminder To All Pending Employees</label>
            </div>
            <div class="flex flex-wrap items-center justify-center pb40">
              <button
                class="btn-primary-outline btn-width-136 mx5 px30 mt-xs-20"
                :disabled="is_btn_disabled"
                @click="sendReminder"
              >
                Send reminder
              </button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script>
import closeIcon from "../../../common/icons/closeIcon.vue";
import axios from "axios";
import toastr from "toastr";
import NProgress from "nprogress";
import "toastr/toastr.scss";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_btn_disabled: false,
      is_send_to_all: false
    };
  },
  props: {
    invite_id: {},
    send_reminder_modal_emp_student_details:{},
    training_name:{},
    selected_location:{},
    selected_training:{},
    send_reminder_called_by: null
  },
  emits: ["close-model", 'emp-student-list-for-training'],
  components: {
    closeIcon,
  },
  methods: {
    closeModal() {
      this.$emit("close-model");
    },
    sendReminder() {
        NProgress.start();
        this.is_btn_disabled = true;
        axios
        .post(JS_APP_URL + "/training/send-training-reminder",
            {
                id: this.invite_id,
                location_id: this.selected_location.id,
                is_send_to_all: this.is_send_to_all
            })
        .then((response) => {
            if (response["data"]["status"] == "Error") {
                if (response["data"]['data'].length > 0) {
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                } else {
                    toastr.error(response["data"]["message"], "Error");
                }
            } else {
                toastr.success(response["data"]["message"], "Success");
                this.$emit('emp-student-list-for-training', 'full');
                this.$emit("close-model", false);
            }
        })
        .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
            }
        })
        .then(() => {
            NProgress.done();
            this.is_btn_disabled = false;
        });
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.is_btn_disabled) {
        this.$emit("close-model");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
