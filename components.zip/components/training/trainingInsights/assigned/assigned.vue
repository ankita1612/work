<template>
  <div class="container">
    <div class="row flex-auto -mx-15 justify-end mb26"  v-if="training_emp_student_lists.length > 0">
      <div class="col-12 col-md-6 col-lg-7 px15" :class="(training_emp_student_lists.length > 0 && selected_training.who_can_train == 'employee') ? 'col-xl-7' : 'col-xl-12'">
        <button class="btn-blue-outline btn-left-padding mr10 download-btn-focus mb-md-10" type="buttton" @click="download_report">
          <div class="next-arrow-icon pdf-icon"><xlsx-icon></xlsx-icon></div>
            DOWNLOAD Training Report
        </button>
      </div>
      <div class="col-12 col-md-6 col-lg-5 col-xl-5 px15" v-if="training_emp_student_lists.length > 0 && selected_training.who_can_train == 'employee'">
        <div class="row flex-auto -mx-10 justify-center justify-start-small-medium items-center">
          <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 px10 mt-sm-10">
            <div class="flex items-center">
              <div class="form-group account-filter-wrapper mb-0 flex-auto">
                <multiselect
                    v-model="filter_selected_sort_by"
                    :options="sort_by_array"
                    label="name"
                    :taggable="false"
                    :multiple="false"
                    :close-on-select="true"
                    :showLabels="false"
                    placeholder=""
                    :searchable="false"
                    @update:model-value="onChangeFilter">
                    <template #noResult>
                    <div class="multiselect__noResult text-center">
                        No results found
                    </div>
                    </template>
                </multiselect>
                <label class="label label-select font-italic" :class="{ 'label-float': filter_selected_sort_by }">Sort by</label>
                </div>
                <img @click="toggleSortDir" v-if="filter_selected_sort_by != null && sort_by_dir == 'ASC'" :src="JS_APP_URL + '/images/sort-up.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" />
                <img @click="toggleSortDir" v-if="filter_selected_sort_by != null && sort_by_dir == 'DESC'" :src="JS_APP_URL + '/images/sort-down.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5"/>
              </div>
            </div>
            <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 px10 mt-sm-10">
              <div class="form-group account-filter-wrapper mb-0">
                <input class="form-input form-input-search" type="text" v-model="searchQuery"/>                
                <label class="label font-italic" :class="{ 'label-float': searchQuery }">Search</label>
                <div class="search-btn-input">
                   <img :src="JS_APP_URL + '/images/search.svg'" alt="" title="" />
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>    
    <div v-if="training_emp_student_lists.length > 0">
      <div>
        <div class="assigned-emp-training-tbl-item table-responsive">
         <table class="assigned-emp-training-table" border="0" cellpadding="4" cellspacing="5">
            <thead>
                <tr>
                    <th style="width: 16%" v-text="(selected_training.who_can_train == 'employee')?'Employee Name':'HCO Name'"></th>
                    <th style="width: 14%">Date Sent</th>
                    <th style="width: 13%">Attempts</th>
                    <th style="width: 14%">Video/Quiz</th>
                    <th style="width: 14%">Certificate</th>
                    <th style="width: 15%">Reason</th>
                    <th style="width: 14%">Resend</th>
                </tr>
            </thead>
          </table>
        </div>
        <div>
          <assigned-list
                v-for="training_emp_student_list in searchingSortingResult"
                :key="training_emp_student_list.id"
                :training_emp_student_list = "training_emp_student_list"
                :selected_training = "selected_training"
                :selected_location = "selected_location"
                :is_triggered = "selected_training['training_location'][0]['is_triggered']"
                @send-reminder-popup = "sendReminderModalToggle"
                @resend-training-popup = "resendTrainingModalToggle"
                @view-certificate = "viewCertificate"
                @training-attempt-failed-popup = "trainingAttemptFailedModalToggle"
                @close-model = "sendReminderModalToggle"
                @emp-student-list-for-training = "empStudentListForTraining"
                @sub-training-selection-popup = "subTrainingSelectionModalToggle"
            />          
        </div>

      </div>
    </div>
    <div v-if="!is_full_page_loader_shown &&  searchingSortingResult.length === 0" class="mt20">
      <div class="user-detail-text font-14 gray_checkmark--text text-center">
        <no-data-icon></no-data-icon>
        <div class="font-14 text-center blueog--text">No {{ (selected_training.who_can_train == 'hco') ? 'HCO' : 'employee(s)' }} available.</div>
      </div>
    </div>
    <full-page-loader v-if = "is_full_page_loader_shown"></full-page-loader>
    <certificate-modal v-if = "certificate_modal"
      @close-model = "certificateModalclose"
      :file_url = "file_url"
      :invite_id = "certificate_invite_id"
    />
    <send-reminder v-if="send_reminder_modal"
      send_reminder_called_by = 'assigned'
      :selected_location = "selected_location"
      :invite_id = "send_reminder_modal_invite_id"
      :send_reminder_modal_emp_student_details = "send_reminder_modal_emp_student_details"
      :training_name = "selected_training.title"
      :selected_training = "selected_training"
      @close-model = "sendReminderModalToggle"
      @emp-student-list-for-training = "empStudentListForTraining"
    />
    <training-attempt-failed v-if="training_attempt_failed_modal"
        :first_name = "first_name"
        :last_name = "last_name"
        :training_name = "selected_training.title"
        :training_attempt_failed_result = "training_attempt_failed_result"
        @close-model = "trainingAttemptFailedModalToggle"
    />
    <resend-training-modal v-if="resend_training_modal == 'true'"
        :selected_location = "selected_location"
        :selected_training = "selected_training"
        :emp_stud_user_id = "emp_stud_user_id"
        :emp_stud_type = "emp_stud_type"        
        :training_arr ="training_arr"
        @close-model = "resendTrainingModalToggle"
        @emp-student-list-for-training = "empStudentListForTraining"
        @incedent-trainig = "incedentResponseModalToggle"
    />
    <sub-training-selection-modal v-if="sub_training_selection_modal == 'true'"
        :selected_location = "selected_location"
        :selected_training = "selected_training"
        :emp_stud_user_id = "emp_stud_user_id"
        :emp_stud_type = "emp_stud_type"
        :parent_training_id = "parent_training_id"
        @close-model = "subTrainingSelectionModalToggle"
        @resend-training-popup = "resendTrainingModalToggle"
    />
    <incedent-response-modal v-if="incedent_response_modal == 'true'"
        :selected_location = "selected_location"
        :selected_training = "selected_training"
        @close-model = "incedentResponseModalToggle"
    />    
  </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import pdfIcon from "../../../common/icons/pdfIcon.vue";
import fullPageLoader from "../../../common/fullPageLoader.vue";
import assignedList from "./assignedList.vue";
import certificateModal from './certificateModal.vue'
import sendReminder from "./sendReminderModal.vue";
import trainingAttemptFailed from "../../failedAttemptModal.vue";
import moment from "moment-timezone";
import resendTrainingModal from "./resendTrainingModal.vue";
import subTrainingSelectionModal from "./subTrainingSelectionModal.vue";
import incedentResponseModal from "./incedentResponseModal.vue";
import noDataIcon from '../../../common/icons/noDataIcon.vue';
import xlsxIcon from "../../../common/icons/xlsx.vue";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_full_page_loader_shown: false,
            filter_selected_sort_by: null,
            sort_by_dir: "ASC",
            sort_by_array: [
                { name: "Name", key: "first_name" },
                { name: "Last Date Sent", key: "trainingInvite.invite_datetime" },
                { name: "Number of Attempts", key: "training_attempt_count" },
                { name: "Completion", key: "is_video_quiz_completed" },
            ],
            searchQuery: null,
            training_emp_student_lists: [],
            certificate_invite_id: "",
            certificate_modal: false,
            send_reminder_modal: false,
            send_reminder_modal_invite_id: "",
            send_reminder_modal_emp_student_details: "",
            training_attempt_failed_modal: false,
            training_attempt_failed_result: [],
            resend_training_modal: false,
            sub_training_selection_modal: false,
            incedent_response_modal: false,
            calling_ajax: 0,
            emp_stud_user_id: null,
            emp_stud_type: null,
            hco_training_history_modal: false,            
            delay_timer: "",            
            parent_training_id : null,            
            training_arr :[]
        }
    },
    computed: {
        searchingSortingResult() {
            let sortable_array = this.training_emp_student_lists ? this.training_emp_student_lists : [];           
            if (this.searchQuery != null) {
                let query = this.searchQuery ? this.searchQuery.toLowerCase().split(" ") : null;
                sortable_array = sortable_array.filter((item) => {
                    return !query || query
                        .every(
                            (v) =>
                                item.first_name.toLowerCase().includes(v) ||
                                item.last_name.toLowerCase().includes(v)
                        );
                });
            }
            return sortable_array;
        },
    },
    components: {
        pdfIcon, fullPageLoader, assignedList, certificateModal, sendReminder, trainingAttemptFailed, resendTrainingModal, incedentResponseModal, noDataIcon, xlsxIcon, subTrainingSelectionModal
    },
    props: {
      selected_location: {},
      selected_training: {}
    },
    mounted() {
       this.empStudentListForTraining('full');
    },    
    methods: {     
        subTrainingSelectionModalToggle(emp_stud_user_id = "", emp_stud_type = "", parent_training_id="") {
            if (this.sub_training_selection_modal == "true"){
                this.sub_training_selection_modal = "false";
            } else {
                this.sub_training_selection_modal = "true";
                this.emp_stud_user_id = emp_stud_user_id
                this.emp_stud_type =  emp_stud_type
                this.parent_training_id =  parent_training_id
            }
        },   
        resendTrainingModalToggle(emp_stud_user_id = "", emp_stud_type = "", training_arr=[]) {
            if (this.resend_training_modal == "true"){
                this.resend_training_modal = "false";
            } else {
                this.resend_training_modal = "true";
                this.emp_stud_user_id = emp_stud_user_id
                this.emp_stud_type =  emp_stud_type                
                this.training_arr = training_arr;
            }
        },
        incedentResponseModalToggle(emp_stud_user_id = "", emp_stud_type = "") {
            if (this.incedent_response_modal == "true") {
                this.incedent_response_modal = "false";
            } else {
                this.incedent_response_modal = "true";
                this.emp_stud_user_id = emp_stud_user_id
                this.emp_stud_type = emp_stud_type
            }
        },
         fullLoaderToggle(status) {
            this.is_full_page_loader_shown = status;
        },
        toggleSortDir() {            
            this.sort_by_dir = this.sort_by_dir == "ASC" ? "DESC" : "ASC";            
            this.empStudentListForTraining('half');
        },
        onChangeFilter() {
            if (this.delay_timer) {
                clearTimeout(this.delay_timer);
                this.delay_timer = null;
            }
            this.delay_timer = setTimeout(() => {
                this.empStudentListForTraining('half');
            }, 800);
        },
        empStudentListForTraining(refresh = '') {                      
            if (refresh == 'full') {
                this.training_emp_student_lists = [];
                this.filter_selected_sort_by = null;
                this.sort_by_dir = "ASC";
                this.searchQuery = "";
            }
            else if (refresh == 'half') {
                this.training_emp_student_lists = [];
            }

            if (this.selected_location.id != undefined && this.selected_location.id != '' && this.selected_training.id != undefined && this.selected_training.id != "" && this.calling_ajax == 0)
            {                
                this.calling_ajax = 1;
                this.is_full_page_loader_shown = true;
                let param = {
                    location_id: this.selected_location.id,
                    training_id: this.selected_training.id,                                        
                    sort_by: (this.filter_selected_sort_by != null) ? this.filter_selected_sort_by.key : '',
                    sort_by_dir: (this.filter_selected_sort_by == '' || this.filter_selected_sort_by == null) ? "DESC" : this.sort_by_dir,                    
                };

                axios
                    .post(JS_APP_URL + "/training/employee-student-list-for-training", param)
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        this.training_emp_student_lists = response.data.data.emp_student_list;                                                
                        this.is_full_page_loader_shown = false;                        
                    }
                    else
                    {
                        if (response["data"]["message"] == "Complete SRA first") {
                            window.location = JS_APP_URL + "/dashboard";
                        } else {
                            if (response["data"]['data'].length > 0) {
                                toastr.error(response["data"]['data'].join('</br>'), "Error");
                            } else {
                                toastr.error(response["data"]["message"], "Error");
                            }
                        }
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    this.is_full_page_loader_shown = false;
                    this.calling_ajax = 0;
                });
            }

        },
        download_report(){
            var trainings = [];
            trainings.push(this.selected_training.id);
            window.location.href = JS_APP_URL + "/training/download-hipaa-training-report?location_id=" + this.selected_location.id + "&training_ids=" + trainings + '&timezone=' + moment.tz.guess() + '&tab_name=employee';
        },
        sendReminderModalToggle(invite_id = "", training_emp_student_list = "") {
            if (this.send_reminder_modal == true) {
                this.send_reminder_modal = false;
            } else {
                this.send_reminder_modal_invite_id = invite_id
                this.send_reminder_modal_emp_student_details = training_emp_student_list
                this.send_reminder_modal = true;
            }
        },
        certificateModalclose() {
            this.certificate_modal = false;
        },
        viewCertificate(invite_id) {
            this.is_full_page_loader_shown = true;
            let param = {
                location_id: this.selected_location.id,
                invite_id: invite_id,
                timezone: moment.tz.guess()
            };
            this.certificate_invite_id = invite_id;
            axios
                .post(JS_APP_URL + "/training/get-training-certificate", param)
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        this.file_url = response.data.data;
                        this.is_full_page_loader_shown = false;
                        this.certificate_modal = true;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    this.is_full_page_loader_shown = false;
                });
        },
        trainingAttemptFailedModalToggle(
            first_name,
            last_name,
            training_attempt_failed_result
        ) {
            if (this.training_attempt_failed_modal == true) {
                this.training_attempt_failed_modal = false;
            } else {
                this.first_name = first_name;
                this.last_name = last_name;
                this.training_attempt_failed_result = training_attempt_failed_result;
                this.training_attempt_failed_modal = true;
            }
        },
    },
    watch: {
        selected_training() {
            this.empStudentListForTraining('full');
        },
    },
}
</script>
