<template>
<div>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button @click="closeModal" class="cursor-pointer modal-close" v-if="!is_btn_disabled">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb10">
              <img
                :src="JS_APP_URL + '/images/envelop-upload.svg'"
                alt=""
                title=""
                class="warning-icon-modal"
              />
            </div>
            <h2
              class="
                font-21 font_semibold
                blueog--text
                line-normal
                text-center
                mb10
              "
            >
              Resend Training?
            </h2>
            <p class="text-center font-16 text-999 mb10" style="line-height: 22px;padding: 0 2rem;">
              Select the reason for resending training.
            </p>
            <div class="self-center" :class="{ 'form-group--error': v$.resend_option.$error }">
              <div class="form-group">
                <div class="flex flex-wrap items-center justify-center mb10">

                <div class="radio mr16">
                    <input  v-model.trim="resend_option"  class="form-check-input" id='refresher' name="resend_option" type="radio" value="Refresher"/>
                    <label for="refresher" class="radio-label font-14 font-light gray_checkmark--text">Refresher</label>
                </div>
                <div class="radio mr16">
                    <input v-model.trim="resend_option"  class="form-check-input" id='incident' name="resend_option" type="radio" value="Incident Response"/>
                    <label for="incident" class="radio-label font-14 font-light gray_checkmark--text">Incident Response</label>
                </div>
                </div>
                <div class="flex justify-center">
                    <div v-if="v$.resend_option.$errors.length > 0" class="form-error-text">{{ v$.resend_option.$errors[0].$message }}</div>
                </div>
                <div class="checkbox pb20 pt10" style="margin-right:14px" v-if="selected_training.who_can_train == 'employee'">
                  <input v-model.trim="is_send_to_all" id="is_send_to_all" name="is_send_to_all" type="checkbox">
                  <label for="is_send_to_all" class="checkbox-label font-14 font-light gray_checkmark--text">(Optional) Resend to All Employees</label>
                </div>
              </div>
            </div>
            <div class="flex flex-wrap items-center justify-center">
              <button class="btn-primary-outline mx15 btn-width-120 h-32" :disabled="is_btn_disabled"  @click="resendTraining">CONFIRM</button>
              <button class="btn-cancel-outline mx15 btn-width-120 h-32" :disabled="is_btn_disabled" @click="closeModal">CANCEL</button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
    <div class="modal-backdrop"></div>
</div>
</template>

<script scoped>
import closeIcon from "../../../common/icons/closeIcon.vue";
import useVuelidate from "@vuelidate/core";
import { required, helpers } from "@vuelidate/validators";
import axios from "axios";
import toastr from "toastr";
import NProgress from "nprogress";
import "toastr/toastr.scss";
export default {
  setup: () => ({ v$: useVuelidate() }),
  components: { closeIcon },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_btn_disabled: false,
      selected_employee: "",
      hco_id: "",
      resend_option: null,
      training_type: "",
      is_send_to_all: false
    };
  },
  validations() {
    return {
        resend_option: { required: helpers.withMessage("Please select reason for resending training", required) },
    }
  },
    props: {
        selected_location: {},
        selected_training: {},
        emp_stud_type: null,
        emp_stud_user_id: null,        
        training_arr: {}
  },
  emits: ["close-model", "emp-student-list-for-training", "incedent-trainig"],
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  },
  watch: {},
  mounted() {},
  methods: {
     async resendTraining() {
        this.v$.$touch();
        const is_valid = await this.v$.$validate();
        if (is_valid)
        {
            NProgress.start();
            this.is_btn_disabled = true;
            axios
            .post(JS_APP_URL + "/training/send-invite-for-training",
                {
                    type: this.emp_stud_type,
                    emp_stud_user_id: this.emp_stud_user_id,
                    location_id: this.selected_location.id,                    
                    reason: this.resend_option,
                    is_send_to_all: this.is_send_to_all,                    
                    training_arr : this.training_arr,
                    call_type: "resend"
                })
            .then((response) => {
                if (response["data"]["status"] == "Error") {
                    if (response["data"]['data'].length > 0) {
                        toastr.error(response["data"]['data'].join('</br>'), "Error");
                    } else {
                        toastr.error(response["data"]["message"], "Error");
                    }
                } else {
                    toastr.success(response["data"]["message"], "Success");
                    if (this.resend_option == "Incident Response") {
                        this.$emit("close-model", false);
                        this.$emit('emp-student-list-for-training', 'full');
                        this.$emit("incedent-trainig");
                    }
                    else {
                        this.$emit('emp-student-list-for-training', 'full');
                        this.$emit("close-model", false);
                    }
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                NProgress.done();
                this.is_btn_disabled = false;
            });
        }
    },
    closeModal() {
      this.$emit("close-model");
    },
  },
};
</script>
