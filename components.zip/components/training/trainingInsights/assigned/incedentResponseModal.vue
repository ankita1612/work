<template>
<div>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button @click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb10">
              <img :src="JS_APP_URL + '/images/log-file.svg'" alt="" title="" class="warning-icon-modal"/>
            </div>
            <h2 class="font-21 font_semibold blueog--text line-normal text-center mb10">You selected Incident Response</h2>
            <p class="text-center font-16 text-999 mb10" style="line-height: 22px;padding: 0 2rem;">
              Remember to fill out a Breach Log in Abyde. Review your Breach Notification Policy and contact our Customer Success team if you have any remaining questions.
            </p>
            <div class="flex flex-wrap items-center justify-center">
              <button class="btn-primary-outline mx15 h-32" :disabled="is_btn_disabled"  @click="redirectToLog()">GO TO HIPAA LOGS</button>
              <button class="btn-cancel-outline mx15 btn-width-120 h-32 " @click="closeModal">DISMISS</button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
    <div class="modal-backdrop"></div>
</div>
</template>

<script scoped>
import closeIcon from "../../../common/icons/closeIcon.vue";
import toastr from "toastr";
import NProgress from "nprogress";
import "toastr/toastr.scss";
export default {
  components: { closeIcon },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_btn_disabled: false,
      selected_employee: "",
      hco_id: "",
      resend_option: null,
      training_type: "",
    };
  },
  props: {
        selected_location: {},
        selected_training: {},
  },
  emits: ["close-model", "emp-student-list-for-training"],
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  },
  watch: {},
  mounted() {},
  methods: {
    redirectToLog() {
        window.location = JS_APP_URL + "/hipaa-logs/"+ this.encryption(this.selected_location.id)+"/breachlog";
    },
    closeModal() {
      this.$emit('emp-student-list-for-training', 'full');
      this.$emit("close-model");
    },
    encryption(params) {
        var encoded = btoa(params);
        return encoded;
    },
  },
};
</script>
