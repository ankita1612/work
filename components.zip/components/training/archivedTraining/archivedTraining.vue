<template>
    <div class="container">
        <training v-for="(training, index) in trainings" :key="training.id" 
            :parent_training="training" 
            :selected_location="selected_location"
            :index="index"
        />
        <div v-if="!is_full_page_loader_shown && trainings.length === 0" class="">
            <div class="user-detail-text font-14 gray_checkmark--text text-center">
                <no-data-icon></no-data-icon>
                <div class="font-14 text-center blueog--text">
                No training available.
                </div>
            </div>
        </div>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>

<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../../common/fullPageLoader.vue";
import training from "./training.vue";
import noDataIcon from "../../common/icons/noDataIcon.vue";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_full_page_loader_shown: false,
            trainings: [],
            APP_ENV: APP_ENV
        }
    },
    props: {
        selected_location: {},
        all_locations: {},
        old_location: null
    },
    emits: ['set-training-count'],
    components: {
        fullPageLoader,
        training,
        noDataIcon,
    },
    watch: {
        selected_location() {
            this.getTrainingListForArchive();
        },
    },
    mounted() {
        if(this.selected_location){
            this.getTrainingListForArchive();
        }
    },
    methods: {
        getTrainingListForArchive(reset_counter = 0) {
            this.is_full_page_loader_shown = true;
            const params = {
                location_id: this.selected_location.id,
                tab_name:'employee',
                is_archived: 1,
                fetch_count: (this.old_location!=this.selected_location.id || reset_counter == 1) ? 1 : 0 
            };
            axios
            .get(JS_APP_URL + "/training/training-list", { params })
            .then((response) => {
            if (response["data"]["status"] == "Success") {                                
                this.trainings = response.data.data.training_list;
                if(this.old_location != this.selected_location.id || reset_counter == 1){
                   this.$emit('set-training-count', this.selected_location.id, response.data.data.total_count, reset_counter);
                }                
                setTimeout(() => {
                    if(APP_ENV == 'production') {
                        var metadata = {
                            first_time_training_added: response.data.data.first_time_training_added,
                            location_id: this.selected_location.id,
                            location_nickname: this.selected_location.location_nickname,
                            user_locations_number: this.all_locations.length
                        };
                        Intercom('trackEvent', 'training-status', metadata);
                    }
                }, 1000);
            }else{
                if(response["data"]["message"] == "Complete SRA first") {
                    window.location = JS_APP_URL + "/dashboard";
                }else{
                    if(response["data"]['data'].length > 0){
                        toastr.error(response["data"]['data'].join('</br>'), "Error");
                    }else{
                        toastr.error(response["data"]["message"], "Error");
                    }     
                }
            }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                this.is_full_page_loader_shown = false;
            });
        },
    }
}
</script>