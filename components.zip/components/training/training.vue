<template>
    <div>
        <header-after-login></header-after-login>
      <div class="container pt40">
        <div class="flex justify-center flex-wrap mb30 relative">
          <button
            class="btn-blue-outline btn-left-padding mr10 training-report-btn download-btn-focus"
            type="buttton"
            @click="dwonloadReportModalToggle">
              <div class="next-arrow-icon pdf-icon">
                <xlsx-icon></xlsx-icon>
              </div>
            DOWNLOAD Training Report
          </button>
          <div
            class="location-dropdon
              form-group
              col-12 col-sm-8 col-md-5 col-lg-4 col-xl-3
              px0
              mb-0
              mlr-auto
            "
            v-if="all_locations.length>1">
            <multiselect
              class="company-location-select"
              v-model="selected_location"
              :options="all_locations"
              label="location_nickname"
              :taggable="false"
              :multiple="false"
              :close-on-select="true"
              :showLabels="false"
              track-by="id"
              placeholder=""
              :allowEmpty="false"
            >
              <template #noResult>
                <div class="multiselect__noResult text-center">
                  No results found
                </div>
              </template>
            </multiselect>
            <label class="label label-select label-float">Location</label>
          </div>
          <!-- Demo Reset Button -->
          <button
            v-if="is_demo_account == 1"
            class="btn-blue-outline demo-reset-btn mr30 download-btn-focus"
            type="button"
            @click="demoResetTraining">
            DEMO RESET
          </button>
        </div>
        <h1
        class="
          location-dashbaord-title
          text-center
          font-24 font_semibold
          blueog--text
          line-normal flex justify-center items-center
          mb15
          mb-sm-10 mb-md-10 ml32
          "
        >
          Training
          <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml6">
            <div class="cursor-pointer svg-icon-height">
                <info-icon></info-icon>
            </div>
            <template #popper>
                Click the date button for any upcoming training to manually schedule.  Manually selected dates are updated with a green date button and can be rescheduled as needed until the training is sent.
            </template>
          </VTooltip>
        </h1>
        <p class="font-16 dark--text line-normal text-center mb40">
           Employees can complete their training within their employee portal or from this module in the software.
        </p>
      </div>
      <div class="training-tabs-wrapper pb50">
        <div class="training-tab-nav">
          <div class="container flex items-center flex-wrap">
            <button
              type="button"
              class="training-tab-nav-item font-21"
              @click="changeActivateTabs('available')"
              :class="{ active: active_tab == 'available' }"
              v-if="is_educational_account != 1"
            >
              Available Training <span class="training-total-count">{{available_training_count_emp}}</span>
            </button>
            <button
              type="button"
              class="training-tab-nav-item sharp-tab-item font-21 ml10"
              @click="changeActivateTabs('archived')"
              :class="{ active: active_tab == 'archived' }"
              v-if="is_educational_account != 1"
            >
              Archived Training <span class="training-total-count">{{archived_training_count_emp}}</span>
            </button>
            <button
              type="button"
              @click="changeActivateTabs('available')"
              class="training-tab-nav-item font-21 mr2"
              :class="{ active: active_tab == 'available' }"
              v-if="is_educational_account == 1"
            >
              Available Training <span class="training-total-count">{{available_training_count_emp}}</span>
            </button>
            <button
              type="button"
              @click="changeActivateTabs('archived')"
              class="training-tab-nav-item font-21 mr2"
              :class="{ active: active_tab == 'archived' }"
              v-if="is_educational_account == 1"
            >
              Archived Training <span class="training-total-count">{{archived_training_count_emp}}</span>
            </button>
            <button
              type="button"
              v-if="is_educational_account == 1"
              @click="changeActivateTabs('student_available')"
              class="training-tab-nav-item font-21 mr2"
              :class="{ active: active_tab == 'student_available' }"
            >
              Available Student Training <span class="training-total-count">{{available_training_count_stu}}</span>
            </button>
            <button
              type="button"
              v-if="is_educational_account == 1"
              @click="changeActivateTabs('student_training')"
              class="training-tab-nav-item font-21 mr2"
              :class="{ active: active_tab == 'student_training' }"
            >
              Archived Student Training <span class="training-total-count">{{archived_training_count_stu}}</span>
            </button>
          </div>
        </div>
        <div class="training-tab-content pt22">
          <div class="container">
              <!-- archived training code -->
              <archived-training
                v-if="active_tab == 'archived'"
                :selected_location="selected_location"
                :all_locations="all_locations"
                :old_location= "old_location"
                @set-training-count="setTrainingCounts"
                ref="form_archived"
              ></archived-training>
              <!-- End -->
        
              <!-- available training code -->
              <available
                v-if="active_tab == 'available'"
                :selected_location="selected_location"
                :all_locations="all_locations"
                :old_location= "old_location"
                @set-training-count="setTrainingCounts"
                ref="form_available"
              />

              <!-- student training code -->
              <student-reporting
                v-if="active_tab == 'student_available'"
                :selected_location="selected_location"
                :old_location= "old_location"
                @show-download-btn="showDownloadBtn"
                @set-training-count="setTrainingCounts"
                ref="form_available_stu"
              ></student-reporting>
              <!-- End -->

              <!-- student training code -->
              <student-training
                v-if="active_tab == 'student_training'"
                :selected_location="selected_location"
                :old_location= "old_location"
                @set-training-count="setTrainingCounts"
                ref="form_archived_stu"
              ></student-training>
              <!-- End -->

              <download-report-modal 
              v-if="download_report_modal"
              :selected_location="selected_location"
              @show-full-loader="fullLoaderToggle"
              @close-model="dwonloadReportModalToggle"/>

              <download-student-report-modal 
              v-if="download_student_report_modal"
              :selected_location="selected_location"
              @show-full-loader="fullLoaderToggle"
              @close-model="dwonloadReportModalToggle"/>
              <!-- End -->
          </div>
        </div>
      </div>
      <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>

<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import plusIcon from "../common/icons/plusIcon.vue";
import pdfIcon from "../common/icons/pdfIcon.vue";
import xlsxIcon from "../common/icons/xlsx.vue";
import infoIcon from "../common/icons/infoIcon.vue"
import fullPageLoader from "../common/fullPageLoader.vue";
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import available from "./available/available.vue";
import archivedTraining from "./archivedTraining/archivedTraining.vue";
import studentTraining from "./studentTraining/studentTraining.vue";
import studentReporting from "./studentReporting/studentReporting.vue";
import downloadReportModal from './downloadReportModal.vue'
import downloadStudentReportModal from "./downloadStudentReportModal.vue"

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_CURRENT_TAB: JS_CURRENT_TAB,
            active_tab: '',
            selected_location: "",
            all_locations: [],
            is_full_page_loader_shown: false,
            download_report_modal:false,
            download_student_report_modal:false,
            download_student_report_btn:false,
            is_educational_account:parseInt(AUTH_USER.is_educational_account),
            is_demo_account:parseInt(AUTH_USER.is_demo_account),
            available_training_count_stu: 0,
            archived_training_count_stu: 0,
            available_training_count_emp: 0,
            archived_training_count_emp: 0,
            old_location :''
        };
    },
    mounted() {
        if(JS_CURRENT_TAB == 'student_training'){
            this.active_tab = 'student_available';
        }else {
            this.active_tab = 'available';
        }
        this.loadLocationNicknameList();        
    },
    components: {
        headerAfterLogin,
        fullPageLoader,
        plusIcon,
        pdfIcon,
        infoIcon,
        available,
        archivedTraining,
        studentTraining,
        studentReporting,
        downloadReportModal,
        downloadStudentReportModal,
        xlsxIcon
    },
    methods: {
        changeActivateTabs(tab_name) {
            this.active_tab = tab_name;
        },
        dwonloadReportModalToggle(){
            if(this.active_tab == 'available' || this.active_tab == 'archived'){
                if(this.download_report_modal == true){
                    this.download_report_modal = false
                }else{
                    this.download_report_modal = true
                }
            }
            if(this.active_tab == 'student_available' || this.active_tab == 'student_training'){
                if(this.download_student_report_modal == true){
                    this.download_student_report_modal = false
                }else{
                    this.download_student_report_modal = true
                }
            }
        },
        fullLoaderToggle(status){
            this.is_full_page_loader_shown = status;
        },
        showDownloadBtn(status){
            this.download_student_report_btn = status
        },
        loadLocationNicknameList(is_demo_reset = 0 ) {
            this.is_full_page_loader_shown = true;
            axios
            .get(JS_APP_URL + "/general/get-assigned-location-list")
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                this.all_locations = response["data"]["data"];
                  if(is_demo_reset === 0){ 
                    this.selected_location = this.all_locations.find(
                      (object) => object.id === parseInt(JS_LOCATION_ID)
                    );
                  }else{
                    this.selected_location = this.all_locations.find(
                      (object) => object.id === this.selected_location.id
                    );
                  }
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                this.is_full_page_loader_shown = false;
            });
        },
        demoResetTraining(){          
          this.is_full_page_loader_shown = true;
            axios
            .get(JS_APP_URL + "/training/demo-reset-training/"+this.selected_location.id)
            .then((response) => {                         
                if (response["data"]["status"] == "Success") {
                  //this.loadLocationNicknameList(1);
                  if(this.active_tab == 'available'){
                    this.$refs.form_available.getTrainingListForReport(1)
                  }
                  else if(this.active_tab == 'archived'){
                    this.$refs.form_archived.getTrainingListForArchive(1)
                  }
                  else if(this.active_tab == 'student_available'){                    
                    this.$refs.form_available_stu.getTrainingListForReport(1)
                  }
                  else{
                    this.$refs.form_archived_stu.getTrainingListForArchive(1)                                                 
                  }    
              }
            })
            .catch((error) => {              
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                this.is_full_page_loader_shown = false;
            });
        },
        setTrainingCounts(location_id, total_count, reset_counter=0)
        {                    
          if(this.old_location != location_id || reset_counter == 1)
          {            
            this.old_location = location_id;
            this.available_training_count_stu = total_count.available_training_count_stu;
            this.archived_training_count_stu = total_count.archived_training_count_stu;
            this.available_training_count_emp = total_count.available_training_count_emp;
            this.archived_training_count_emp = total_count.archived_training_count_emp;                  
          }                   
        }        
    },
}
</script>