<template>
  <div>
    <Teleport to="body">
      <transition name="modal">
        <div class="modal-mask">
          <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
              <div class="text-center mlr-auto mb10">
                <img :src="JS_APP_URL + '/images/training_schedule.svg'" alt="" title="" class="warning-icon-modal mr15" />
              </div>
              <h2 class="font-21 font_semibold blueog--text line-normal text-center mb10">
                Schedule 
                <div class="uppercase">{{ training.training.title }}</div>
                for 
                <div class="uppercase">{{ location.location_nickname }}</div>
              </h2>
              <p class="text-center font-15 text-999 mb20" style="line-height: 22px;padding: 0 2rem;">
                Schedule training anytime before your {{ $filters.formatDate(training.renewal_date) }} renewal date. The training will be released to staff at 8 AM EST. Abyde recommends that manually scheduled training follows the default order. 
              </p>
              <div class="row -mx-5 items-center flex-auto justify-center mb25">
                <div class="col-12 col-md-4 col-lg-4 col-xl-4 px5">
                  <div class="form-group mb-0" :class="{ 'form-group--error': v$.selected_schedule_date.$error }">
                    <div class="mx-datepicker datepicker-input cursor-pointer">
                      <div class="mx-input-wrapper">
                        <datepicker
                          v-model:value="v$.selected_schedule_date.$model"
                          :disabled-date="disabledScheduleDate"
                          format="MM/DD/YYYY"
                          valueType="YYYY-MM-DD"
                          titleFormat="MM-DD-YYYY"
                          :editable="false"
                          class="datepicker-input"
                          type="date"
                          @focus="schedule_date_dateoicker_focus = true"
                          @blur="schedule_date_dateoicker_focus = false"
                          :class="{ 'form-error': v$.selected_schedule_date.$errors.length, }"
                        ></datepicker>
                      </div>
                    </div>
                    <label class="label location-input-label" :class="{ 'label-float': selected_schedule_date || schedule_date_dateoicker_focus }">Schedule Date</label>  
                    <div v-if="v$.selected_schedule_date.$errors.length > 0">
                      <div class="form-error-text">
                          {{ v$.selected_schedule_date.$errors[0].$message }}
                      </div>
                    </div>            
                  </div>  
                </div>
              </div>
              <p class="font-14 font_semibold red--text font-italic text-center mb20" v-if="is_invalid_schedule_date">                
                The date you have selected is in the future: <br>your renewal date is {{ $filters.formatDate(training.renewal_date) }}.
              </p>
              <div class="flex flex-wrap items-center justify-center">
                <button @click="setScheduleDate" :disabled="is_submit_btn_disabled" type="button" class="btn-primary-outline mx15 btn-width-120 h-32 ">SUBMIT</button>
                <button @click="closeModal" :disabled="is_btn_disabled" type="button" class="btn-cancel-outline mx15 btn-width-120 h-32 ">CANCEL</button>
              </div>
            </div>
          </div>
        </div>
      </transition>
    </Teleport>
    <div class="modal-backdrop"></div>
  </div>
</template>

<script scoped>
import axios from "axios"
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import closeIcon from "../common/icons/closeIcon.vue";
import { useVuelidate } from '@vuelidate/core';
import { required, helpers } from "@vuelidate/validators";

export default {
  components: { closeIcon },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_btn_disabled: false,
      is_submit_btn_disabled: false,
      hco_id:"",
      selected_schedule_date: '',
      schedule_date_dateoicker_focus: false,
      disabledScheduleDate: (date) => date < new Date(),

    };
  },
  props: {
    location: {},
    training: {},
    schedule_date: {},
    training_parent_id : null
  },
  emits: ["close-model", "fetch-sub-training-details"],
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      selected_schedule_date: {
        required: helpers.withMessage("Please select schedule date", required)
      }
    }
    return validationArray;
  },
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model");
      }
    });
  },
  watch: {
    selected_schedule_date(val) {
      if(val == null) {
        this.disabledScheduleDate = (date) => date <= new Date();
      } else {
        var modify_date = new Date();
        modify_date.setDate(modify_date.getDate());
        this.disabledScheduleDate = (date) => date < modify_date;
      }
    },
  },
  computed: {
    is_invalid_schedule_date() {
      var new_schedule_date = new Date(this.selected_schedule_date);
      var renewal_date = new Date(this.training.renewal_date);
      if(new_schedule_date > renewal_date) {
        this.is_submit_btn_disabled = true;
        return true;
      } else {
        this.is_submit_btn_disabled = false;
        return false;
      }
    }
  },
  mounted() {
    if(this.schedule_date) {
      this.selected_schedule_date = this.schedule_date;
    }
  },
  methods: {
    setScheduleDate() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        NProgress.start();
        this.is_submit_btn_disabled = true;
        this.is_btn_disabled = true;
        axios.post(JS_APP_URL + '/training/schedule-training', {
          location_id: this.location.id,
          training_id: this.training.training.id,
          schedule_date: this.selected_schedule_date,
          training_parent_id: this.training_parent_id
        })
        .then((response) => { 
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
              toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
              toastr.error(response["data"]["message"], "Error");
            }
          } else {
            toastr.success(response["data"]["message"], "Success");
            setTimeout(() => {
              this.$emit("close-model", false);
              this.$emit("fetch-sub-training-details", this.training.training.id);
            }, 100);
          }
        })
        .catch((error) => { 
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => { 
          this.is_submit_btn_disabled = false;
          this.is_btn_disabled = false
          NProgress.done();
        })
      }
    },
    closeModal() {
      this.$emit("close-model");
    },
    
  },
};
</script>
