<template>
<div>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button @click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb20 pt20">
              <img
                :src="JS_APP_URL + '/images/start-quiz-modal.svg'"
                alt=""
                title=""
                class="warning-icon-modal"
              />
            </div>
            <h2
              class="
                font-24 font_semibold
                blueog--text
                line-normal
                text-center
                mb10
              "
            >
              Complete {{training.training.title}} Quiz
            </h2>
            <p class="text-center font-16 text-999 mb30" style="line-height: 22px;padding: 0 2rem;">
              Quizzes are available to all student's in their Abyde portal. If
              you prefer to have a student complete their training within the
              software instead, please select the student's name from the
              dropdown below.
            </p>
            <div
              class="
                form-group
                col-12 col-md-8 col-lg-6 col-xl-4
                px0
                mb-25
                mlr-auto
              "
            >
              <multiselect
                v-model="selected_student"
                :options="students"
                :custom-label="fullname"
                :taggable="false"
                :multiple="false"
                :close-on-select="true"
                :showLabels="false"
                track-by="id"
                placeholder=""
                :allowEmpty="false"
              >
                <template #noResult>
                  <div class="multiselect__noResult text-center">
                    No results found
                  </div>
                </template>
                <template #noOptions>
                    <div class="multiselect__noOptions text-center">No data available</div>
                </template>  
              </multiselect>
              <label
                class="label label-select"
                :class="{ 'label-float': selected_student }"
                >Student</label
              >
            </div>
            <div class="flex flex-wrap items-center justify-center pb20">
              <button
                class="btn-primary-outline btn-width-136 mx5 px30 mt-xs-20"
                :disabled="is_btn_disabled"
                @click="startTraining"
              >
                START QUIZ
              </button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
    <div class="modal-backdrop"></div>
</div>
</template>

<script scoped>
import closeIcon from "../../common/icons/closeIcon.vue";

export default {
  components: { closeIcon },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_btn_disabled: true,
      selected_student: "",
      hco_id:""
    };
  },
  props: {
    training: {},
    selected_location: {},
    students: {}
  },
  emits: ["close-model"],
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model");
      }
    });
  },
  destroyed(){
  },
  watch: {
    selected_student(val) {
      if (val == "" || val == null) {
        this.is_btn_disabled = true;
      } else {
        this.is_btn_disabled = false;
      }
    },
  },
  mounted() {
  },
  methods: {
    closeModal() {
      this.$emit("close-model");
    },
    startTraining() {
      window.location =
        JS_APP_URL +
        "/training/training-quiz/" +
        this.encryption(this.selected_location.id) +
        "/" +
        this.encryption(this.selected_student.training_invite.id);
    },
    fullname(option) {
      return `${option.first_name} ${option.last_name}`;
    },
    encryption(params){
      var encoded = btoa(params);
      return encoded;
    }
  },
};
</script>
