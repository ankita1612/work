<template>
    <div class="report-training-item relative pt15 pb10 mb32 flex flex-wrap" 
        :class="{ 'report-training-item-disable' : training.is_disable == 1}">
        <div class="training-item-left">
            <div class="px20 pt10">
                <h4 class="font-18 font_semibold blueog--text mb0">{{ training.training.title }}</h4>
                <p class="font-12 font_light gray2--text mb12" v-html="training.training.description" />
            </div>
            <div class="table-responsive">
                <table class="report-training-table" border="0" cellpadding="4" cellspacing="5">
                    <thead>
                        <tr>
                            <th style="width: 16.66%">Training Sent</th>
                            <th style="width: 16.66%">Scheduled By</th>
                            <th style="width: 16.66%">Assigned</th>
                            <th style="width: 16.66%">Completed</th>
                            <th style="width: 16.66%">Unassigned</th>
                        </tr>
                    </thead>
                    <tbody>    
                        <tr>
                            <td>
                                <div v-if="training.schedule_date == null">
                                    <span class="font-italic">{{ $filters.formatDate(training.created_at) }}</span>
                                </div>
                                <div v-else>
                                    <span class="font-italic">{{ $filters.formatDate(training.schedule_date) }}</span>
                                </div>
                            </td>
                            <td class="font-italic">Abyde</td>
                            <td class="font-italic">{{ training.assigned == 0 ? "-" : training.assigned }}</td>
                            <td class="font-italic">{{ training.completed == 0 ? "-" : training.completed }}</td>
                            <td class="font-italic">{{ training.unassigned_trainings_count == 0 ? "-" : training.unassigned_trainings_count }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="training-item-right px20 pt15">
            <div class="flex flex-wrap justify-between items-center mb30 mt-sm-20 justify-start-small-medium">
                <button class="training-video-button cursor-pointer" type="button" @click="PlayVideoModalToggle('yes')">
                    <img :src="video_poster_file_url" alt="" title="" class="video-thumnail" height="50px" width="50px" />
                    <img :src="JS_APP_URL + '/images/video-play.svg'" alt="" title="" class="play-icon relative" />
                </button>
                <button type="button" :disable="training.is_triggered == 0 || training.assigned == 0 || training.assigned == '-'"
                    @click="(training.is_triggered == 0 || training.assigned == 0 || training.assigned == '-')? '' : quizModalToggle(training)" class="action-icon-btn cursor-pointer quiz-action-btn"
                    :class="(training.is_triggered == 0 || training.assigned == 0 || training.assigned == '-')?'not-allowed':''">
                    <span
                    class="pending-svg-icon inline-flex items-center justify-center"><quize-orange-training></quize-orange-training></span>
                </button>
            </div>
            <div class="text-center">
                <a :class="(training.is_triggered == 0 || training.assigned == 0 || training.assigned == '-') && training.unassigned_trainings_count==0 && training.unassigned_hidden_count == 0?'not-allowed':''"
                :disable="(training.is_triggered == 0 || training.assigned == 0 || training.assigned == '-') && training.unassigned_trainings_count==0 && training.unassigned_hidden_count == 0"
                @click="(training.is_triggered == 0 || training.assigned == 0 || training.assigned == '-') && training.unassigned_trainings_count==0 && training.unassigned_hidden_count == 0?'':manageStudent(training)"
                class="font-14 blueog--text font_semibold text-decoration-underline cursor-pointer">
                    Manage Students
                </a>
            </div>
        </div>
    </div>
    <quiz-modal
      v-if="quiz_modal == true"
      :training="training"
      :students="students"
      @close-model="quizModalToggle"
      :selected_location="selected_location"
    />
    <play-video-modal
      v-if="play_video_modal == true"
      :video_file_url="video_file_url"
      :vtt_file_url="vtt_file_url"
      @close-model="PlayVideoModalToggle"
      @ended="videoEnded"
    ></play-video-modal>
</template>

<script scoped>
import axios from "axios"
import toastr from "toastr";
import "toastr/toastr.scss";
import NProgress from "nprogress";
import quizModal from "../studentReporting/quiztModal.vue";
import playVideoModal from '../available/playVideoModal.vue';
import quizeOrangeTraining from "../../common/icons/quizeorangetraining.vue"

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            send_reminder_modal:false,
            employee_type:"",
            is_full_page_loader_shown: false,
            video_poster_file_url: null,
            video_file_url: null,
            vtt_file_url: null,
            quiz_modal: false,
            students: [],
            play_video_modal: false,
        }
    },
    props: {
        training: {},
        selected_location: {},
        index: 0
    },
    components: {
        quizeOrangeTraining, quizModal, playVideoModal       
    },
    mounted() {
        this.createSignUrl(this.training.training.video_poster_file,'poster_file');
    },
    methods: {
        createSignUrl(file_name,file_type,file_time = 600){
            var request = {
                params: {
                    file_path: 'trainings/'+ this.training.training.id + '/' + file_name,
                    file_exp_time: file_time
                }
            }
            axios
            .get(JS_APP_URL + "/general/get-sign-url",request)
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    if(file_type == 'poster_file'){
                        this.video_poster_file_url = response.data.data;
                    }
                    if(file_type == 'video_file'){
                        this.video_file_url = response.data.data;
                    }
                    if(file_type == 'vtt_file'){
                        this.vtt_file_url = response.data.data;
                    }
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            });
        },
        manageStudent(training) {
            window.location = JS_APP_URL + '/training/training-insights-student/'+
                this.encryption(this.selected_location.id) +
                "/" +
                this.encryption(training.training.id);
        },
        quizModalToggle() {
            if (this.quiz_modal == true) {
                this.quiz_modal = false;
            } else {
                this.getStudent();
            }
        },
        PlayVideoModalToggle(is_api_call = 'yes') {
            if (this.play_video_modal == true) {
                this.play_video_modal = false;
            } else {
                if(is_api_call ==  'yes'){
                    this.createSignUrl(this.training.training.video_file,'video_file', 3600);
                    this.createSignUrl(this.training.training.video_caption_file,'vtt_file');
                }
                setTimeout(() => {
                    if(this.vtt_file_url != null){
                        this.play_video_modal = true;
                    }else{
                        this.PlayVideoModalToggle('no');
                    }
                }, 200);
            }
        },
        videoEnded(){
            this.play_video_modal = false;
            this.getStudent();
        },
        getStudent() {
            NProgress.start();
            this.is_full_page_loader_shown = true;
            axios.post(JS_APP_URL + "/training/student-list-for-training-quiz", {
                training_id: this.training.training.id,
                location_id: this.selected_location.id,
            })
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                this.students = response.data.data;
                this.quiz_modal = true;
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
                }
            }).then(()=>{
                this.is_full_page_loader_shown = false;
                NProgress.done();
            });
        },
        encryption(params){
            var encoded = btoa(params);
            return encoded;
        },
    },
}
</script>