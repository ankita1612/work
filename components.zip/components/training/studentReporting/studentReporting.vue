<template>
  <div class="container">
    <div class="mlr-auto mb26 px10" v-if="!is_full_page_loader_shown && Object.values(trainings).length > 0">
      <div class="row -mx-5 items-center justify-center flex-auto">
        <!-- <div class="col-12 col-md-4 col-lg-4 col-xl-4 px5  mb-sm-10">
          <div class="form-group account-filter-wrapper mb-0 flex-auto">
            <multiselect
              v-model="filter_by"
              :options="filter_by_array"
              label="name"
              :taggable="false"
              :multiple="false"
              :close-on-select="true"
              :showLabels="false"
              placeholder=""
              :searchable="false"
            >
              <template #noResult>
                <div class="multiselect__noResult text-center">
                  No results found
                </div>
              </template>
            </multiselect>
            <label class="label label-select label-italic" :class="{ 'label-float': filter_by }">filter by types</label>
          </div>
        </div> -->
        <div class="col-12 col-md-4 col-lg-3 col-xl-2 px5 mb-sm-10">
          <div class="form-group account-filter-wrapper mb-0 flex-auto">
            <multiselect
              v-model="sort_by"
              :options="sort_by_array"
              label="name"
              :taggable="false"
              :multiple="false"
              :close-on-select="true"
              :showLabels="false"
              placeholder=""
              :searchable="false"
            >
              <template #noResult>
                <div class="multiselect__noResult text-center">
                  No results found
                </div>
              </template>
            </multiselect>
            <label class="label label-select font-italic" :class="{ 'label-float': sort_by }">Sort by</label>
          </div>
        </div>
        <div class="col-12 col-md-4 col-lg-3 col-xl-2 px5">
          <div class="form-group account-filter-wrapper mb-0">
            <input
              class="form-input form-input-search"
              type="text" v-model="searchQuery"
            />
            <label
              class="label font-italic" :class="{ 'label-float': searchQuery }"
            >Search</label>
            <div class="search-btn-input">
              <img :src="JS_APP_URL + '/images/search.svg'" alt="" title="" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <training v-for="(training, index) in searchingSortingResult" :key="index" 
    :training="training" 
    :selected_location="selected_location"
    :index="index"
    />
    <div v-if="!is_full_page_loader_shown && searchingSortingResult.length === 0" class="">
      <div class="user-detail-text font-14 gray_checkmark--text text-center">
        <no-data-icon></no-data-icon>
        <div class="font-14 text-center blueog--text">
          No training available.
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../../common/fullPageLoader.vue";
import training from "./training.vue"
import noDataIcon from "../../common/icons/noDataIcon.vue";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_full_page_loader_shown: false,
      trainings: [],
      APP_ENV: APP_ENV,
      // filter_by: null,
      // filter_by_array: [
      //   { name: "HCO", key: "hco" },
      //   { name: "Employee", key: "employee" },
      // ],
      sort_by: null,
      sort_by_array: [
        { name: "Oldest to Newest", key: "old_to_new" },
        { name: "Newest to Oldest", key: "new_to_old" },
      ],
      searchQuery: null,
      sort_by_desc: false
    };
  },
  mounted() {
    if(this.selected_location){
      this.getTrainingListForReport();
    }
  },
  props: {
    selected_location: {},
    all_locations: {},
    download_student_report_btn:false,
    old_location: null
  },
  components: {
    fullPageLoader,
    training,
    noDataIcon,
  },
  emits: ['set-training-count'],
  computed: {
    searchingSortingResult() {
      this.is_full_page_loader_shown = true;
      let sortable_array = this.trainings ? this.trainings : [];
      // if(this.filter_by != null) {
      //   sortable_array = sortable_array.filter((item) => {
      //     return item.training.who_can_train == this.filter_by.key
      //   });
      // }
      if (this.sort_by != null) {
        sortable_array = Object.values(sortable_array).concat().sort((a, b) => {
          // Compare by is_triggered first
          if (a.is_triggered < b.is_triggered) return 1;
          if (a.is_triggered > b.is_triggered) return -1;

          // If is_triggered values are equal, compare by display_order
          const display_order_a = a.display_order;
          const display_order_b = b.display_order;

          this.sort_by_desc = this.sort_by.key !== "old_to_new";
          return this.sort_by_desc
            ? display_order_b - display_order_a // Descending order
            : display_order_a - display_order_b; // Ascending order
        });
      }
      if (this.searchQuery != null) {
        sortable_array = Object.values(sortable_array).filter((item) => {
          return this.searchQuery
            .toLowerCase()
            .split(" ")
            .every(
              (v) =>
                item.training.title.toLowerCase().includes(v) ||
                item.training.description.toLowerCase().includes(v)
            );
        });
      }
      this.is_full_page_loader_shown = false;
      return sortable_array;
    }
  },
  watch: {
    selected_location() {
      this.sort_by = null;
      this.searchQuery = null;
      this.getTrainingListForReport();
    },
  },
  methods: {
    getTrainingListForReport(reset_counter = 0) {
      this.is_full_page_loader_shown = true;
      const params = {
        location_id: this.selected_location.id,
        tab_name:'student',
        fetch_count: (this.old_location!=this.selected_location.id || reset_counter == 1) ? 1 : 0 
      };
      axios
        .get(JS_APP_URL + "/training/training-list", { params })
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.trainings = response.data.data.training_list;
            if(this.old_location != this.selected_location.id || reset_counter == 1){
              this.$emit('set-training-count', this.selected_location.id, response.data.data.total_count, reset_counter);
            }
          }else{
            if(response["data"]["message"] == "Complete SRA first") {
              window.location = JS_APP_URL + "/dashboard";
            }else{
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }     
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
  },
};
</script>

<style>
</style>
