<template>
    <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask pdf-modal-mask">
                <div class="pdf-modal-overlay pdf-modal-mask"></div>
                <div class="modal-wrapper animate__animated animate__zoomIn failed-training-question-modal">
                    <div class="modal-container">
                        <button @click="closeModal" class="cursor-pointer modal-close">
                            <close-icon></close-icon>
                        </button>
                        <h2 class="font-26 font_semibold blueog--text line-normal mb10 text-center">
                            {{ training_name }}
                        </h2>
                        <h2 class="font-24 font_semibold blueog--text line-normal mb10 text-center" v-if="first_name && last_name">
                            {{ first_name}} {{last_name }}
                        </h2>

                        <div v-if="trainingAttemptFailedResult.length > 0">
                            <div v-for="(attempt_detail, index) in trainingAttemptFailedResult" :key="index">
                                <div class="font-16 font_semibold blueog--text line-normal mb15 mt15 text-center">Attempt {{ index + 1 }} on {{ $filters.formatDate(attempt_detail.created_at) }}</div>
                                <div class="row flex-auto -mx-10">
                                    <div class="col-5 col-md-5 col-lg-2 col-xl-2 px10">
                                        <p class="text-center font-16 gray_checkmark--text line-normal font_bold mt3 mb3">#</p>
                                    </div>
                                    <div class="col-7 col-md-7 col-lg-10 col-xl-10 px10">
                                        <p class="text-left font-16 gray_checkmark--text line-normal font_bold mt3 mb3">Incorrect Questions</p>
                                    </div>
                                </div>
                                <div class="row flex-auto -mx-10" v-for="(attempt_failed, index1) in attempt_detail.training_quiz_attempt" :key="index1">
                                    <div class="col-5 col-md-5 col-lg-2 col-xl-2 px10">
                                        <p class="text-center font-16 gray_checkmark--text line-normal mt3 mb3">{{ index1+1 }}</p>
                                    </div>
                                    <div class="col-7 col-md-7 col-lg-10 col-xl-10 px10">
                                        <p class="text-left font-16 gray_checkmark--text line-normal mt3 mb3"> {{ attempt_failed.training_questions.question }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p class="text-center font-16 gray_checkmark--text line-normal mb30 mt30" v-if="trainingAttemptFailedResult.length === 0">
                            No incorrect attempt available.
                        </p>
                    </div>
                </div>
            </div>
        </transition>
    </Teleport>
</template>

<script>
import closeIcon from "../common/icons/closeIcon.vue";
export default {
    data() {
        return {
            trainingAttemptFailedResult: [],
        };
    },
    props: {
        first_name: "",
        last_name: "",
        training_name:"",
        training_attempt_failed_result: {}
    },
    emits: ["close-model"],
    components: {
        closeIcon,
    },
    mounted() {
         this.trainingAttemptFailedResult = this.training_attempt_failed_result;
    },
    methods: {
        closeModal() {
            this.$emit("close-model");
        },
    },
    created() {
        // document.body.classList.add('modal-open');
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27 && !this.is_btn_disabled) {
                this.$emit("close-model");
            }
        });
    },
    destroyed() {
        // document.body.classList.remove('modal-open');
    }
};
</script>
