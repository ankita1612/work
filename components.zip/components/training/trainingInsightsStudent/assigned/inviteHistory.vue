<template>
    <tr v-for="(training_invite, index) in training_invites" :key="index" >
        <td></td>
        <td style="width: 15%" class="font-14 mr15">
             <span class="darkgray--text font_semibold" >{{ training_invite.student_class.class_name }}</span>
        </td>

        <td style="width: 14%" class="font-14 mr15 ">
            <span class="darkgray--text font_semibold">{{ $filters.formatDate(training_invite.invite_datetime) }}</span>
        </td>

        <td style="width: 10%" class="font-14 mr15">
            <span class="inline-flex items-center relative darkgray--text font_semibold">
            <div class="mr8">{{ (training_invite.training_attempt_count == 0) ? "None" : training_invite.training_attempt_count }}</div>
            <VTooltip
                :triggers="['hover']"
                :popperTriggers="['hover']"
                style="height: 24px"
                class="cursor-pointer inline-block failed-training-info"
                v-if="training_invite.is_video_quiz_completed == false &&
                    training_invite.training_attempt_count > 0
                    "
            >
            &nbsp;&nbsp;<a v-on:click="trainingAttemptFailedModalOpen(training_invite.training_attempt[0].invite_id)" target="_blank"
                ><span><info-icon></info-icon></span
                ></a>
                <template #popper>Click here to view failed attempts</template>
            </VTooltip>
            </span>
        </td>

        <td style="width: 10%">
            <span  v-if="training_invite.is_video_quiz_completed == true">
            <button  type="button" class="complete-img-btn">
                <img :src="JS_APP_URL + '/images/Complete.svg'" alt="" title="" width="32" height="32" />
            </button>
            </span>
            <span v-else class="font-14 font_semibold uppercase "  @click="sendReminderModalOpen(training_invite.id)">
            <button type="button" class="action-icon-btn cursor-pointer assigned-pending-btn"  >
                <span class="pending-svg-icon inline-flex items-center justify-center"><pendingTraining></pendingTraining></span>
            </button>
            </span>
        </td>
        <td style="width: 10%">
            <span class="font-14 font_semibold uppercase"  v-if="training_invite.is_video_quiz_completed == true" @click=" viewCertificateModalOpen(training_invite.id)">
            <button type="button" class="action-icon-btn action-btn-blue cursor-pointer complete-action-btn overflow-hide">
                <span class="pending-svg-icon inline-flex items-center justify-center"><view-file-icon></view-file-icon></span>
            </button>
            </span>
            <span v-else >
            <button  type="button" class="action-icon-btn action-btn-blue complete-action-btn pdf-round-btn disable">
                <span class="pending-svg-icon inline-flex items-center justify-center"><pdf-icon></pdf-icon></span>
            </button>
            </span>
        </td>

        <td class="font-14 mr15 "><span class="darkgray--text font_semibold">{{ training_invite.reason}}</span></td>

        <td>
             <br><br><div class="text-center" v-if="training_invites.length-1 == index">
                <a href="javascript:void(0)" class="see-more-link font-14 blueog--text font_semibold text-decoration-underline" @click="inviteHistory()">See Less</a>
            </div>
        </td>
    </tr>
</template>

<script scoped>
import axios from "axios";
import pdfIcon from "../../../common/icons/pdfIcon.vue";
import infoIcon from "../../../common/icons/infoIcon.vue"
import pendingTraining from "../../../common/icons/pendingTraining.vue"
import viewFileIcon from "../../../common/icons/viewFileIcon.vue"
import sendTrainingIcon from "../../../common/icons/sendTrainingIcon.vue"
import fullPageLoader from "../../../common/fullPageLoader.vue";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_full_page_loader_shown: false,
        }
    },
    components: {
        pdfIcon, infoIcon, pendingTraining, viewFileIcon, sendTrainingIcon, fullPageLoader
    },
    props: {
        selected_location: {},
        training_invites: {},
        training_emp_student_id: null,
        emp_first_name: null,
        emp_last_name: null,
        emp_detail: {}
    },
    emits: ["close-invite-history", "training-attempt-failed", "view-certificate", "send-reminder-popup"],
    mounted() {
    },
    methods: {
        sendReminderModalOpen(training_invite_id) {

            this.$emit('send-reminder-popup', training_invite_id, this.emp_detail)
        },
        viewCertificateModalOpen(training_invite_id) {
            this.$emit('view-certificate', training_invite_id)
        },
        inviteHistory() {
            this.$emit("close-invite-history", this.training_emp_student_id);
        },
        trainingAttemptFailedModalOpen(training_invite_id) {
            this.$emit("training-attempt-failed", training_invite_id, this.emp_first_name, this.emp_last_name);
        }
    }
}
</script>
