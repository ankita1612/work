<template>
  <div class="assigned-emp-item light py10 mb30  table-responsive">
    <table class="assigned-emp-training-table" border="0" cellpadding="0" cellspacing="0">
        <tbody>
            <tr>
            <td style="width: 16%">
                <span class="font-14 font_semibold darkgray--text" >{{ training_emp_student_list.first_name }} {{ training_emp_student_list.last_name }}</span>
            </td>

            <td style="width: 15%" class="font-14 mr15">
                <span class="font_semibold darkgray--text" >{{ training_emp_student_list.student_class.class_name }}</span>
            </td>

            <td style="width: 14%" class="font-14 mr15">
                <span class="font_semibold darkgray--text" >{{ $filters.formatDate(training_emp_student_list.training_invite.invite_datetime) }}</span>
            </td>

            <td style="width: 10%" class="font-14 mr15">
                <span class="inline-flex items-center relative font_semibold darkgray--text">
                    <div class="mr8">{{ (training_emp_student_list.training_attempt_count==0)?"None": training_emp_student_list.training_attempt_count }}</div>

                <VTooltip
                    :triggers="['hover']"
                    :popperTriggers="['hover']"
                    style="height: 24px"
                    class="cursor-pointer inline-block failed-training-info"
                    v-if="training_emp_student_list.is_video_quiz_completed == false && training_emp_student_list.training_attempt_count > 0">
                    <a v-on:click="trainingAttemptFailedModalOpen(training_emp_student_list.training_invite.id, training_emp_student_list.first_name,
                        training_emp_student_list.last_name)" target="_blank"
                    ><span><info-icon></info-icon></span
                    ></a>
                    <template #popper>Click here to view failed attempts</template>
                </VTooltip>
                </span>
            </td>

            <td style="width: 10%">
                <span  v-if="training_emp_student_list.is_video_quiz_completed == true">
                    <button  type="button" class="complete-img-btn">
                        <img :src="JS_APP_URL + '/images/Complete.svg'" alt="" title="" width="32" height="32" />
                    </button>
                </span>
                <span v-else class="font-14 font_semibold uppercase "  @click="sendReminderModalOpen(training_emp_student_list.training_invite.id, training_emp_student_list)">
                    <button type="button" class="action-icon-btn cursor-pointer assigned-pending-btn"  >
                        <span class="pending-svg-icon inline-flex items-center justify-center"><pendingTraining></pendingTraining></span>
                    </button>
                </span>
            </td>

            <td style="width: 10%">
                <span class="font-14 font_semibold uppercase"  v-if="training_emp_student_list.is_video_quiz_completed == true" @click=" viewCertificateModalOpen(training_emp_student_list.training_invite.id)">
                <button type="button" class="action-icon-btn action-btn-blue cursor-pointer complete-action-btn overflow-hide">
                <span class="pending-svg-icon inline-flex items-center justify-center"><view-file-icon></view-file-icon></span>
                </button>
                </span>
                <span v-else >
                <button  type="button" class="action-icon-btn action-btn-blue complete-action-btn pdf-round-btn disable">
                    <span class="pending-svg-icon inline-flex items-center justify-center"><pdf-icon></pdf-icon></span>
                </button>
                </span>
            </td>

            <td style="width: 15%" class="font-14 mr15 "> <span class="font_semibold darkgray--text">{{ (training_emp_student_list.training_invite != null) ? training_emp_student_list.training_invite.reason : "" }}</span></td>

            <td style="width: 10%">
                <button type="button" class="training-resend " :class="(training_emp_student_list.is_video_quiz_completed == true && training_emp_student_list.is_resend_enabled == 1) ? 'cursor-pointer' : ''"  @click="( training_emp_student_list.is_video_quiz_completed == true  && training_emp_student_list.is_resend_enabled==1) ? resendtrainingModalOpen(): null">
                    <img :src="(training_emp_student_list.is_video_quiz_completed == true && training_emp_student_list.is_resend_enabled == 1) ? JS_APP_URL + '/images/resend.svg' : JS_APP_URL + '/images/resend-gray.svg'" alt="" title="" />
                </button>
                <div class="text-center" v-if="training_emp_student_list.training_invite_count > 1 && see_more == 1">
                    <a href="javascript:void(0)" class="see-more-link font-14 blueog--text font_semibold text-decoration-underline" @click="inviteHistory(training_emp_student_list.id, training_emp_student_list.type)">See More</a>
                </div>
            </td>
            </tr>
            <invite-history
            v-if = "training_emp_student_list.id == emp_student_id_history"
            :training_invites = "training_invites"
            :training_emp_student_id = "training_emp_student_list.id"
            :emp_first_name = "training_emp_student_list.first_name"
            :emp_last_name = "training_emp_student_list.last_name"
            :emp_detail = "training_emp_student_list"
            @close-invite-history = "inviteHistory"
            @training-attempt-failed = "trainingAttemptFailedModalOpen"
            @view-certificate = "viewCertificateModalOpen"
            @send-reminder-popup = "sendReminderModalOpen"
            />
        </tbody>    
    </table>
  </div>
</template>

<script scoped>
import axios from "axios";
import pdfIcon from "../../../common/icons/pdfIcon.vue";
import infoIcon from "../../../common/icons/infoIcon.vue"
import pendingTraining from "../../../common/icons/pendingTraining.vue"
import viewFileIcon from "../../../common/icons/viewFileIcon.vue"
import sendTrainingIcon from "../../../common/icons/sendTrainingIcon.vue"
import NProgress from "nprogress";
import inviteHistory from "./inviteHistory.vue";
export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            emp_student_id_history: null,
            see_more: 1,
            send_reminder_modal: false,
            training_invites :[]
        }
    },
    components: {
        pdfIcon, infoIcon, pendingTraining, viewFileIcon, sendTrainingIcon, inviteHistory
    },
    props: {
        training_emp_student_list: {},
        selected_location: {},
        selected_training: {}
    },
   // emits: [ "get-training-list-for-report"],
    emits: ["training-attempt-failed-popup", "send-reminder-popup", "view-certificate", "resend-training-popup", "emp-student-list-for-training", 'close-modal'],
    mounted() {

    },
    methods: {
        inviteHistory(training_emp_student_id = '', emp_student_type) {
            if (this.see_more == 1) {
                this.emp_student_id_history = training_emp_student_id;
                this.see_more = 0;

                NProgress.start();
                let param = {
                        location_id: this.selected_location.id,
                        training_id: this.selected_training.id,
                        emp_stud_user_id: training_emp_student_id,
                        type: emp_student_type
                };
                axios
                    .post(JS_APP_URL + "/training/employee-student-invite-list-for-training", param)
                    .then((response) => {
                        if (response["data"]["status"] == "Success") {
                            this.training_invites = response.data.data;
                        }
                    })
                    .catch((error) => {
                        toastr.error(error.response["data"]["message"], "Error");
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        NProgress.done();
                    });
            }
            else
            {
                this.emp_student_id_history = null;
                this.see_more = 1;
            }
        },
        trainingAttemptFailedModalOpen(training_invite_id, first_name, last_name) {
            NProgress.start();
            let param = {
                invite_id: training_invite_id,
            };
            axios
                .post(JS_APP_URL + "/training/get-training-attempts-failed", param)
                .then((response) => {
                    var training_attempt_failed_result = response["data"]["data"];
                    this.$emit(
                        "training-attempt-failed-popup",
                        first_name,
                        last_name,
                        training_attempt_failed_result
                    );
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then((response) => {
                    NProgress.done();
                })
        },
        sendReminderModalOpen(training_invite_id, training_emp_student_list) {
            this.$emit('send-reminder-popup', training_invite_id, training_emp_student_list)
        },
        resendtrainingModalOpen() {
            this.$emit('resend-training-popup',this.training_emp_student_list.id, this.training_emp_student_list.type)
        },
        viewCertificateModalOpen(invite_id) {
            this.$emit('view-certificate', invite_id);
        },

    },
}
</script>
