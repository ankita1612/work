<template>
  <div class="report-training-item relative pb10 mb32 flex flex-wrap" :class="{ 'report-training-item-disable' : parent_training.is_disable == 1}">
    <div class="training-item-left">
      <div>
        <div class="training-left-top flex flex-wrap">
          <div class="training-label-top">
            <span class="training-box-badge font_semibold" :class="parent_training.training.who_can_train == 'hco' ? 'hco' : 'full-staff'">{{ parent_training.training.who_can_train == 'hco' ? "HCO" : "Full Staff"}}</span>
          </div>
          <div class="training-box-heading col-12 col-md-6 col-xl-5 self-center px5">
            <h4 class="font-18 font_semibold blueog--text mb0 text-center">{{ parent_training.training.title_for_list }}</h4>
          </div>
          <div class="training-box-tabs self-end flex-grow flex"  v-if="parent_training.training.child_training.length>0">    
            <button @click="fetchSubTrainingDetails(parent_training.training.id)" type="button" class="training-box-tab-item font-21 mr2 font_semibold" :class="(parent_training.training_id == active_training_id && parent_training.is_archived==1  ? 'active-archived' : (parent_training.training_id != active_training_id && parent_training.is_archived==1  ?'inactive-archived' : (parent_training.training_id == active_training_id && parent_training.is_archived == 0  ?'active-unarchived':'inactive-unarchived')))" >{{ parent_training.training.title_for_tab }}</button>   
              <template v-for="child_training_data in parent_training.training.child_training">               
                <button @click="fetchSubTrainingDetails(child_training_data.id)" v-if="child_training_data.training_location.length > 0"  type="button" class="training-box-tab-item font-21 mr2 font_semibold"  :class="(child_training_data.id == active_training_id && child_training_data['training_location'][0]['is_archived'] == 1  ? 'active-archived' : (child_training_data.id != active_training_id && child_training_data['training_location'][0]['is_archived'] == 1  ?'inactive-archived' : (child_training_data.id == active_training_id && child_training_data['training_location'][0]['is_archived'] == 0  ?'active-unarchived':'inactive-unarchived')))" >{{child_training_data.title_for_tab}} </button>                  
                </template>                  
          </div>
        </div>        
        <p class="font-12 font_light gray2--text mb6 pt4 px20" v-html="training.training.description"></p>                    
      </div>
      <div class="table-responsive">
        <table class="report-training-table" border="0" cellpadding="4" cellspacing="5">
            <thead>
                <tr>
                <th style="width: 16.66%"> {{ training.is_triggered == 0 ? "Training Scheduled" : "Training Sent" }} </th>
                <th style="width: 16.66%">Scheduled By</th>
                <th style="width: 16.66%">Assigned</th>
                <th style="width: 16.66%">Completed</th>
                <th style="width: 16.66%">Unassigned</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <td>
                    <div v-if="training.is_triggered == 0">
                        <button @click="scheduleDateModelToggle(training, training.schedule_date, parent_training.training.id)" class="report-table-tag cursor-pointer white"
                        :class="training.schedule_by !== null ? 'report-pending-tag-green' : 'report-pending-tag'">
                            <span class="font-14 font_semibold uppercase">
                                {{ $filters.formatDateUTC(training.schedule_date) }}
                            </span>
                        </button>
                    </div>
                    <div v-else-if="training.schedule_date == null">
                        <span class="font-italic"> {{ $filters.formatDateUTC(training.created_at) }} </span>
                    </div>
                    <div v-else>
                        <span class="font-italic"><i>{{ $filters.formatDateUTC(training.schedule_date) }}</i></span>
                    </div>
                </td>
                <td class="font-italic">
                        {{ training.schedule_by !== null ? training.schedule_by.first_name +' '+training.schedule_by.last_name : 'Abyde' }}
                        <span class="font-italic font-10">{{ (training.schedule_by !== null && training.schedule_by.deleted_at !== null) ? '(Deleted)' : '' }}</span>
                </td>
                <td class="font-italic">{{ (training.assigned == 0 || training.is_triggered == 0) ? "-" : training.assigned }}</td>
                <td class="font-italic">{{ (training.completed == 0 || training.is_triggered == 0) ? "-" : training.completed }}</td>
                <td class="font-italic">{{ (training.unassigned_trainings_count == 0 || training.is_triggered == 0) ? "-" : training.unassigned_trainings_count }}</td>
                </tr>
            </tbody>
        </table>
      </div>
    </div>
    <div class="training-item-right px20 pt15">
      <div class="flex flex-wrap justify-between items-center mb30 mt-sm-20 justify-start-small-medium">
        <button class="training-video-button cursor-pointer" type="button" @click="PlayVideoModalToggle('yes')">
                <img :src="video_poster_file_url" alt="" title="" class="video-thumnail" height="50px" width="50px" />
                <img :src="JS_APP_URL + '/images/video-play.svg'" alt="" title="" class="play-icon relative" />
        </button>
        <button type="button" :disable="(training.is_triggered == 0 || training.assigned == 0 || training.assigned == '-')? ((training.is_triggered == 0 && AUTH_USER.user_type != 'USER')? '0':'1') : 1"
            @click="(training.is_triggered == 0 || training.assigned == 0 || training.assigned == '-')? ((training.is_triggered == 0 && AUTH_USER.user_type != 'USER')? quizModalToggle(training):'') : quizModalToggle(training)" class="action-icon-btn cursor-pointer quiz-action-btn" 
            :class="(training.is_triggered == 0 || training.assigned == 0 || training.assigned == '-')?((training.is_triggered == 0 && AUTH_USER.user_type != 'USER')?'':'not-allowed'):''">
                <span class="pending-svg-icon inline-flex items-center justify-center"><quize-orange-training></quize-orange-training></span>
        </button> 
      </div>
      <div class="text-center">
        <a :class="allow_quiz == 0?'not-allowed':''" :disable="allow_quiz == 0" @click="allow_quiz == 0?'':manageEmployee(training)" class="font-14 blueog--text font_semibold text-decoration-underline cursor-pointer">
            {{ training.training.who_can_train == 'hco' ? "Training Insights" : "Manage Employees" }}
        </a>
      </div>
    </div>
  </div>
  <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  <quiz-modal
      v-if="quiz_modal == true"
      :training="training"
      :employees="employees"
      @close-model="quizModalToggle"
      :selected_location="selected_location"
    />
  <play-video-modal
      v-if="play_video_modal == true"
      :video_file_url="video_file_url"
      :vtt_file_url="vtt_file_url"
      @close-model="PlayVideoModalToggle"
      @ended="videoEnded"
    ></play-video-modal>    
   <schedule-date-modal
      v-if="schedule_date_modal == true"
      :schedule_date="selected_schedule_date"
      :location="selected_location"
      :training="set_training_schedule_date"
      :training_parent_id = "training_parent_id"
      @close-model="scheduleDateModelToggle"     
      @fetch-sub-training-details="getTrainingListForReport" 
    />
</template>

<script>
import axios from "axios"
import toastr from "toastr";
import "toastr/toastr.scss";
import NProgress from "nprogress";
import quizModal from "./quiztModal.vue";
import playVideoModal from '../available/playVideoModal.vue';
import quizeOrangeTraining from "../../common/icons/quizeorangetraining.vue"
import fullPageLoader from "../../common/fullPageLoader.vue";
import scheduleDateModal from '../scheduleDateModal.vue'

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            employee_type:"",
            is_full_page_loader_shown: false,
            video_poster_file_url: null,
            video_file_url: null,
            vtt_file_url: null,
            quiz_modal: false,
            employees: [],
            play_video_modal: false,  
            AUTH_USER: AUTH_USER,     
            training : this.parent_training,
            counter_for_create_sign_url:0 ,
            schedule_date_modal: false,
            set_training_schedule_date: null,
            selected_schedule_date: null,
            active_training_id: this.parent_training.training_id,
            training_parent_id: ""
        }
    },
    props: {
        parent_training: {},
        selected_location: {},
        index: 0,
    },
   // emits: ['schedule-model-toggle','fetch-sub-training'],
    components: {
        quizeOrangeTraining,
        quizModal,
        playVideoModal,   
        fullPageLoader,
        scheduleDateModal, 
    },
    watch: {
        parent_training(val) {
            this.training = this.parent_training;     
            this.active_training_id = this.parent_training.training_id;            
            if(this.active_training_id !=this.parent_training.active_training_id){
                this.fetchSubTrainingDetails(this.parent_training.active_training_id);
            }
        }
    },
    mounted() {
        if(this.active_training_id !=this.parent_training.active_training_id){
            this.fetchSubTrainingDetails(this.parent_training.active_training_id);
        }
        else{
            this.createSignUrl(this.training.training.video_poster_file,'poster_file');      
        }
    },
    computed:{
        allow_quiz()
        {
            return ((this.training.is_triggered==0 && (AUTH_USER.user_type=="PCO" || AUTH_USER.user_type=="HCO")) || this.training.is_triggered==1)?true:false;
        }
    },
    emits: ["get-training-list-for-report"],
    methods: {
        createSignUrl(file_name,file_type,file_time = 600){
            var request = {
                params: {
                    file_path: 'trainings/'+ this.training.training.id + '/' + file_name,
                    file_exp_time: file_time
                }
            }
            axios
            .get(JS_APP_URL + "/general/get-sign-url",request)
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    if(file_type == 'poster_file'){
                        this.video_poster_file_url = response.data.data;
                    }
                    if(file_type == 'video_file'){
                        this.video_file_url = response.data.data;
                    }
                    if(file_type == 'vtt_file'){
                        this.vtt_file_url = response.data.data;
                    }
                    this.counter_for_create_sign_url++;
                    
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            });
        },
        manageEmployee(training) {
            window.location = JS_APP_URL + '/training/training-insights/'+
                this.encryption(this.selected_location.id) +
                "/" +
                this.encryption(training.training.id);
        },
        quizModalToggle() {
            if (this.quiz_modal == true) {
                this.quiz_modal = false;
            } else {
                this.getEmployee();
            }
        },
        // scheduleDateModalToggle(selected_training, schedule_date) {
        //     this.$emit('schedule-model-toggle', selected_training, schedule_date);
        // },
        PlayVideoModalToggle(is_api_call = 'yes') {
            if (this.play_video_modal == true) {
                this.play_video_modal = false;
            } else {
                this.is_full_page_loader_shown = true;
                if(is_api_call ==  'yes'){
                    this.counter_for_create_sign_url = 0;
                    this.createSignUrl(this.training.training.video_file,'video_file', 3600);
                    this.createSignUrl(this.training.training.video_caption_file,'vtt_file');
                }
                setTimeout(() => {
                    if(this.vtt_file_url != null && this.counter_for_create_sign_url==2){
                        this.play_video_modal = true;
                        this.is_full_page_loader_shown = false;
                    }else{
                        this.PlayVideoModalToggle('no');
                    }
                }, 200);
            }
        },
        videoEnded(){
            this.play_video_modal = false;                        
            if((this.training.is_triggered==1)||(this.training.is_triggered==0 && AUTH_USER.user_type != 'USER')){
                this.getEmployee();
            }
        },
        getEmployee() {
            NProgress.start();
            this.is_full_page_loader_shown = true;
            axios.post(JS_APP_URL + "/training/employee-list-for-training-quiz", {
                training_id: this.training.training.id,
                location_id: this.selected_location.id,
            })
            .then((response) => {
            if (response["data"]["status"] == "Success") {
                this.employees = response.data.data.emp_list;
                if (response.data.data.hco_list && response.data.data.hco_list.length != 0) {
                    this.employees[this.employees.length] =
                    response.data.data.hco_list;
                }
                
                this.quiz_modal = true;                
            }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            }).then(()=>{
                this.is_full_page_loader_shown = false;
                NProgress.done();
            });
        },        
        encryption(params){
            var encoded = btoa(params);
            return encoded;
        },
        scheduleDateModelToggle(training, schedule_date, training_parent_id) {
            if(this.schedule_date_modal == true) {
                this.schedule_date_modal = false;
            } else {
                this.set_training_schedule_date = training;
                this.selected_schedule_date=schedule_date
                this.schedule_date_modal = true;
                this.training_parent_id = training_parent_id;
            }
        },
        fetchSubTrainingDetails(training_id)
        {   
            this.active_training_id = training_id;
            this.is_full_page_loader_shown = true;
            axios.get(JS_APP_URL + "/training/training-detail-for-child-training?location_id=" + this.selected_location.id+"&training_id="+training_id+"&tab_name=employee")
            .then((response) => {
                if (response["data"]["status"] == "Success") {                    
                    this.training = response.data.data.single_training[0];                                       
                    this.createSignUrl(this.training.training.video_poster_file,'poster_file');
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            }).then(()=>{
                this.is_full_page_loader_shown = false;              
            });
        },
        getTrainingListForReport(){
            this.$emit("get-training-list-for-report");
        }
    },
}
</script>