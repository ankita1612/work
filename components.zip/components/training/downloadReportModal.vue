<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button @click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb20 pt20">
              <img
                :src="JS_APP_URL + '/images/xlsx.svg'"
                alt=""
                title=""
                class="training-report-pdf-icon"
              />
            </div>
            <h2
              class="font-24 font_semibold blueog--text line-normal text-center mb20"
            >
              <span 
                >Download Training Report(s)</span
              >
            </h2>
            <p class="text-center font-16 text-999 line-normal mb30">
              Select which trainings you would like a full report for or select
              “all” to receive a complete report.
            </p>
            <div
              class="
                form-group
                col-12 col-sm-8 col-md-8 col-lg-6 col-xl-6
                px0
                mb-30
                mlr-auto
              "
              :class="{ 'form-group--error': v$.selected_training.$error }"
            >
              <multiselect
                class="company-location-select all-multiselct-option-select"
                v-model="v$.selected_training.$model"
                :options="training"
                label="title"
                :taggable="false"
                :multiple="true"
                :close-on-select="false"
                :showLabels="false"
                track-by="id"
                placeholder=""
                group-values="option" 
                group-label="all" 
                :group-select="true"
                :searchable="false"
              >
                <template #noResult>
                  <div class="multiselect__noResult text-center">
                    No results found
                  </div>
                </template>
                <template #noOptions>
                  <div class="multiselect__noOptions text-center">
                    No Trainings available
                  </div>
                </template>
                <template #selection>
                <div
                    class="multiselect__tags-wrap"
                    v-if="selected_training.length == training[0].option.length && selected_training.length !=0"
                  >
                    <span class="multiselect__tag">
                      <span
                        >All</span
                      >
                    </span>
                  </div>
                  <div
                    class="multiselect__tags-wrap"
                    v-else-if="selected_training.length > 1"
                  >
                    <span class="multiselect__tag">
                      <span
                        >{{ selected_training.length }} Trainings Selected</span
                      >
                    </span>
                  </div>
                </template>
              </multiselect>
              <pre class="all-json"><code></code></pre>
              <label
                class="label label-select"
                :class="{ 'label-float': selected_training.length > 0 }"
                >Select Training(s)</label
              >
              <div v-if="v$.selected_training.$errors.length > 0">
                <div class="form-error-text">
                  {{ v$.selected_training.$errors[0].$message }}
                </div>
              </div>
            </div>
            <div class="flex flex-wrap items-center justify-center pb40">
              <button
                class="btn-primary btn-width-136 mx5 px30 mt-xs-20"
                @click="download"
              >
                Download
              </button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script>
import closeIcon from '../common/icons/closeIcon.vue'
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import _ from "lodash";
import { useVuelidate } from '@vuelidate/core';
import { required, helpers } from "@vuelidate/validators";
import moment from "moment-timezone";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      training: [
        {
          all: 'All',
          option:[],
        }],
      selected_training: [],
    };
  },
  props: {
    selected_location: {},
  },
  emits: ["close-model", "show-full-loader"],
  components: {
    closeIcon,
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      selected_training: {
        required: helpers.withMessage("Please select training(s)", required),
      },
    }
    return validationArray;
  },
  mounted() {
    this.getTraining();
  },
  methods: {
    closeModal() {
      this.$emit("close-model");
    },
    getTraining() {
      this.$emit("show-full-loader", true);
      axios
        .get(
          JS_APP_URL +
            "/training/get-training-list-for-download-report?location_id=" +
            this.selected_location.id+'&tab_name=employee'
        )
        .then((response) => {
          this.training[0].option = response.data.data;
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then((response) => {
          this.$emit("show-full-loader", false);
        });
    },
    download() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        var trainings = [];
        trainings.push(_.map(this.selected_training, "id"));
        window.location.href =
          JS_APP_URL +
          "/training/download-hipaa-training-report?location_id=" +
          this.selected_location.id +
          "&training_ids=" +
          trainings+'&timezone='+moment.tz.guess()+'&tab_name=employee';
      }
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
