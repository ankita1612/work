import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.css';
import DatePicker from 'vue-datepicker-next';
import 'vue-datepicker-next/index.css';
import moment from "moment";
import training from "./training.vue"
import VueMask from '@devindex/vue-mask';

const training_app = createApp(training);
training_app.use(VueMask);
training_app.config.globalProperties.$filters = {
    formatDate(value) {
        if (value) {
            return moment.utc(String(value)).local().format("MM/DD/YYYY");
        }
    },
    formatDateUTC(value) {
        if (value) {
            return moment(value).format("MM/DD/YYYY");
        }
    },
};
training_app.use(FloatingVue);
training_app.component('datepicker', DatePicker)
training_app.component('multiselect', Multiselect);
training_app.mount("#training_app");
