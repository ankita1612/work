<template>
  <div>
    <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container">
            <button v-if="!close_icon_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>

          <!-- Upload files modal -->
          <div v-if="modal_type == 'file'">
            <div class="text-center mlr-auto">
              <img :src="JS_APP_URL + '/images/add-doc.svg'" alt="" title="" class="warning-icon-modal" />
            </div>          
            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb25">
              Upload File
            </h2>
            <div class="upload-file mt20 mb30">
              <vue-dropzone
              ref="myVueDropzone"
              id="dropzone"
              :options="dropzoneOptions"
              :useCustomSlot="true"
              @vdropzone-error="dropzoneError"
              @vdropzone-queue-complete="dropzoneQueueComplete"
              @vdropzone-files-added="dropzoneFileAdded"
              @vdropzone-removed-file="dropzoneRemovedFile"
              v-on:vdropzone-sending="sendingEvent"
              :class="{ 'dz-disable': close_icon_btn}"
            >
              <div class="dropzone-custom-content" :class="{ 'd-none': close_icon_btn}">
                <h3 class="dropzone-custom-title font-22 text-999 font_normal">
                  Drag and drop file here or click to
                  select <br /> files from your device.
                </h3>
                <div class="subtitle"></div>
              </div>
            </vue-dropzone>
            </div>
            <p class="text-center font-14 text-999 line-normal font-italic mb20">When uploading a non-Abyde Business Associate Agreement (BAA)<br/> please note that in order to meet HIPAA requirements, your BAA<br/> must be dually executed (signed by both parties). If your uploaded<br/> agreement is not dually executed, we advise you to reach out to<br/> your Business Associate to obtain a signed copy.</p>                                
            <div class="text-center">
              <button
                :disabled="disable_agreement_submit_btn"
                type="submit"
                @click="uploadFile"
                class="btn-primary mlr-auto"
              >
                <span>SUBMIT</span>
              </button>
            </div>       
          </div>
          <!-- end code -->

          <!-- Enter URL of vendors modal -->
          <div v-if="modal_type == 'url'">
            <div class="text-center mlr-auto mb20">
              <img :src="JS_APP_URL + '/images/link-icon.png'" alt="" title="" class="warning-icon-modal"  width="70" height="64"/>
            </div>          
            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb25">
            Enter URL of vendors BAA website:
            </h2>
            <div class="row -mx-10 flex-auto justify-center mt30 mb30">
              <div class="col-12 col-md-8 col-lg-8 col-xl-8 px10">
              <div class="form-group mb-0">
                <input class="form-input" v-model="url" placeholder="https://example.com/businessassociateagreement">
                <label class="label label-float">URL</label>
              </div>  
            </div>
            </div>
            <p class="text-center font-14 text-999 line-normal font-italic mb25">When linking a non-Abyde Business Associate Agreement (BAA)<br/> please note that in order to meet HIPAA requirements, your BAA<br/> must be dually executed (signed by both parties). If your linked<br/> agreement is not dually executed, we advise you to reach out to<br/> your Business Associate to obtain a signed copy.</p>                                
            <div class="text-center">
              <button
                :disabled="disable_url_submit_btn"
                @click="submitAgreementUrl"
                type="submit"
                class="btn-primary mlr-auto"
              >
                <span>SUBMIT</span>
              </button>
            </div> 
          </div>
          <!-- end -->

          </div>
        </div>
      </div>
    </transition>
  </Teleport>
  <div class="modal-backdrop"></div>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import cookie from "cookie";
import toastr from "toastr";
import "toastr/toastr.scss";
import vueDropzone from 'dropzone-vue3'
import closeIcon from '../common/icons/closeIcon.vue';
export default {
  props: {
    modal_type:{
      type: String,
    },
    ba_id:{
      type: Number,
    }
  },
  emits: ["close-model", "load-ba-list"],
  components:{closeIcon, vueDropzone},
  data() {
     let params;
      params = {
        business_associative_id: this.ba_id,
        agreement_type:'doc'
      };
    return {
      JS_APP_URL: JS_APP_URL,
      disable_agreement_submit_btn:true,
      disable_url_submit_btn:true,
      close_icon_btn:false,
      url:'',
       dropzoneOptions: {
        headers: {
          "X-XSRF-TOKEN": cookie.parse(document.cookie)["XSRF-TOKEN"],
        },
        url: JS_APP_URL + "/business-associates/complete-agreement-by-url-doc",
        params: params,
        thumbnailWidth: 200,
        addRemoveLinks: true,
        autoProcessQueue: false,
        parallelUploads: 1,
        uploadMultiple: false,
        timeout: 0,
        dataType: "JSON",
        maxFilesize: 10, // MB
        maxFiles: 1,
        dictMaxFilesExceeded: "You can select only one file",
        dictFileTooBig:"File is too big ({{filesize}}MB). Max filesize: {{maxFilesize}}MB.",
        dictUploadCanceled: "",
        acceptedFiles:
          ".doc,.docx,.jpg,.jpeg,.pdf,.png",
      },
    };
  },
  mounted() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && this.close_icon_btn == false) {
        this.$emit("close-model", false);
      }
    });
  },
  watch:{
    url(){
      if(this.url != ""){
        if (this.url.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g)) {
          this.disable_url_submit_btn = false
        } else {
          this.disable_url_submit_btn = true
        }
      }else{
        this.disable_url_submit_btn = true
      }
    }
  },
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
    submitAgreementUrl(){
      NProgress.start();
      this.disable_url_submit_btn = true;
      this.close_icon_btn = true;
      axios
      .post(JS_APP_URL + "/business-associates/complete-agreement-by-url-doc", {
          business_associative_id: this.ba_id,
          agreement_type:'url',
          agreement_link :this.url,
      })
      .then((response) => {
          if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
          } else {
              toastr.success(response["data"]["message"], "Success");
              this.$emit("load-ba-list", true);
              this.$emit("close-model", false);
          }
      })
      .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
          }
      })
      .then(() => {
          NProgress.done();
          this.disable_url_submit_btn = false;
          this.close_icon_btn = false;
      });
    },
    dropzoneFileAdded(files) {
      this.disable_agreement_submit_btn = false;
    },
    dropzoneRemovedFile(file, error, xhr) {
      if (this.$refs.myVueDropzone && this.$refs.myVueDropzone.getQueuedFiles().length <= 0) {
        this.disable_agreement_submit_btn = true;
      }
    },
    dropzoneError(file, message, xhr) {
      this.disable_agreement_submit_btn = false;
      this.close_icon_btn = false;
      this.$refs.myVueDropzone.removeFile(file);
      if (message) {
        toastr.error(message, "Error!");
      } else {
        if (xhr) {
          let res = JSON.parse(xhr.response);
          if (res.status == "Error") {
            toastr.error(res.message, "Error!");
          }
        }
      }
    },

    dropzoneQueueComplete() {
      this.$emit("load-ba-list", true);
      this.$emit("close-model", false);
    },

    uploadFile() {
      [].forEach.call(document.querySelectorAll('.dz-remove'), function (el) {
        el.style.visibility = 'hidden';
      });
      this.disable_agreement_submit_btn = true;
      this.close_icon_btn = true;
      setTimeout(() => {
        this.$refs.myVueDropzone.processQueue();
      }, 400);
    },
    sendingEvent (file, xhr, formData) {
      formData.append('business_associative_id', this.ba_id);
      formData.append('agreement_type', 'doc');
    }
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
