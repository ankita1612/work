<template>
  <div>
    <form >
      <div class="add-employee-row row -mx-10 mb10 mb-sm-20 mb-md-20">
          <div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-20 px10  mb-lg-10 mb-md-10">
            <div class="form-group mb-0" :class="{ 'form-group--error': v$.name.$errors.length || v$.selected_pbr.$errors.length }">
              <input v-if="(selected_pbr && selected_pbr.id == 0)" class="form-input location-input-box" :class="{ 'form-error': v$.name.$errors.length }" type="text" name="name" v-model.trim="v$.name.$model">
              <multiselect
                v-else
                v-model="v$.selected_pbr.$model" 
                :close-on-select="true"
                tag-placeholder=""
                placeholder=""
                :searchable="true"
                :showLabels="false"
                :taggable="false"
                label="name" 
                track-by="id" 
                :options="predefined_ba_list"
                @update:model-value="selectPBA"
                :disabled="disable_add_ba_submit_btn"
                >
                <template #noResult>
                  <div class="multiselect__noResult text-center">No results found</div>
                </template>  
              </multiselect>
              <label class="label label-select" :class="{ 'label-float': (v$.name.$model) }">Vendor Name</label>
              <div v-if="v$.name.$errors.length > 0">
                <div class="form-error-text">
                  {{ v$.name.$errors[0].$message }}
                </div>
              </div>
              <div v-if="v$.selected_pbr.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.selected_pbr.$errors[0].$message }}
                  </div>
                </div>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-20 px10  mb-lg-10 mb-md-10">
            <div class="form-group mb-0" :class="{ 'form-group--error': v$.email.$errors.length }">
                <input :disabled="is_predifined_ba" class="form-input location-input-box" :class="{ 'form-error': v$.email.$errors.length }" type="text" name="email" v-model.trim="v$.email.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.email.$model }">Email</label>
                <div v-if="v$.email.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.email.$errors[0].$message }}
                  </div>
                </div>
            </div>
          </div>
          <div class="col-12 col-md-6 col-lg-4 col-xl-2 px10  mb-lg-10 mb-md-10">
            <div class="form-group mb-0" :class="{ 'form-group--error': v$.phone_number.$errors.length }">
                <input :disabled="is_predifined_ba" @click.right.prevent @copy.prevent @paste.prevent v-mask="'000-000-0000'" class="form-input location-input-box" :class="{ 'form-error': v$.phone_number.$errors.length }" type="text" name="phone_number" v-model.trim="v$.phone_number.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.phone_number.$model }">Phone Number</label>
                <div v-if="v$.phone_number.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.phone_number.$errors[0].$message }}
                  </div>
                </div>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-lg-4 col-xl-2 px10  mb-lg-10 mb-md-10">
            <div class="form-group mb-0" :class="{ 'form-group--error': v$.date_expired.$errors.length }">
                <datepicker v-model:value="date_expired" :disabled-date="disabledExpireDates"
                  format="MM/DD/YYYY" valueType="YYYY-MM-DD" titleFormat="MM-DD-YYYY" :disabled="is_predifined_ba" :class="{ 'form-error': v$.date_expired.$errors.length }"
                  :editable="false" @focus = "is_expired_datepicker_focus = true" @blur = "is_expired_datepicker_focus = false" class="datepicker-input">
                  <template v-slot:footer="{ emit }">
                    <div class="col-12 col-md-12 col-lg-12 col-xl-12 text-center px10">
                      <div class="checkbox pb10 mt9">
                        <input v-model.trim="is_no_expiration_applicable" id="add_is_no_expiration_applicable" name="add_is_no_expiration_applicable" type="checkbox" @click="no_expiration_date">
                        <label for="add_is_no_expiration_applicable"  class="checkbox-label font-14 font-light gray_checkmark--text">No Expiration</label>
                      </div>
                    </div>
                  </template>
                </datepicker>
                <label class="label" :class="{ 'label-float': (date_expired || is_expired_datepicker_focus) }">{{is_no_expiration_applicable == true?'No Expiration':'Expiration Date'}}</label>
                <div v-if="v$.date_expired.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.date_expired.$errors[0].$message }}
                  </div>
                </div>
            </div>
          </div>
          <div v-if="all_location_list.length > 1" class="col-12 col-md-4 col-lg-3 col-xl-3 col-20 px10">
            <div class="form-group" :class="{ 'form-group--error': v$.selected_work_locations.$error }">
              <multiselect
                class="select-all-dropdown"
                v-model="selected_work_locations"
                tag-placeholder=""
                placeholder=""
                label="location_nickname"
                track-by="id"
                :options="local_all_location_list"
                group-values="group_option_list"
                group-label="select_all"
                :group-select="true"
                :multiple= "true"
                :close-on-select="false"
                :showLabels="false"
                :taggable="false">
                  <template #noResult>
                    <div class="multiselect__noResult text-center">
                        No results found
                    </div>
                  </template>
                  <template #noOptions>
                    <div class="multiselect__noOptions text-center">
                        No data available
                    </div>
                  </template>
                  <template #selection>
                    <div class="multiselect__tags-wrap" v-if="selected_work_locations.length > 1">
                        <span class="multiselect__tag">
                        <span>{{ selected_work_locations.length }} Location(s) Assigned</span>
                        </span>
                    </div>
                  </template>
                </multiselect>
                <label class="label label-select" :class="{ 'label-float': (selected_work_locations.length > 0) }">Assigned Location(s)</label>
                <div v-if="v$.selected_work_locations.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.selected_work_locations.$errors[0].$message }}
                  </div>
                </div>
            </div>
          </div>
          <div class="col-12 px10" :class="{ 'col-md-6 col-lg-4 col-xl-3': all_location_list.length == 1 }">
            <div class="flex items-center justify-center justify-start-small-medium">
              <button 
                  :disabled="disable_add_ba_submit_btn"                 
                  type="submit"
                  class="btn-primary mx4"
                  id="btn-add-ba"
                  @click.once="addBASubmit"
                  :key="submit_button_key"
              >
                  <span>Submit</span>
              </button>
              <button
                  :disabled="disable_add_ba_submit_btn"
                  type="button"
                  class="btn-cancel-outline btn-cancel-mobile mx4"
                  @click="cancelAddBA"
              >
                  <span>Cancel</span>
              </button>
            </div>
          </div>
      </div>
    </form>
    <past-date-modal v-if="is_ba_past_date_show" @close-model="resetPastDate" @select-past-date="pastDateModalClose"/>
  </div>
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, email, minLength, maxLength, requiredIf, helpers } from "@vuelidate/validators";
import _ from 'lodash';
import infoIcon from "../common/icons/infoIcon.vue"
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
import { checkSpecialChars, checkSpecialCharsErrorMessage}  from "../common/customValidation";
import pastDateModal from "./businessAssociatePastDateModal.vue";

export default {
  data() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return {
      selected_pbr: null,
      name: '',
      email: '',
      phone_number: '',
      date_expired: '',
      is_expired_datepicker_focus: false,
      is_predifined_ba:false,
      is_no_expiration_applicable : true,
      predefine_business_associates_id:null,
      disabledExpireDates:(date) => date <= today || date > today,
      predefined_ba_list : [{
        id:0,
        name: 'Add New',
      }],
      disable_add_ba_submit_btn: false,
      check_ba_available_timer: null,
      is_ba_past_date_show: false,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
      APP_ENV: APP_ENV,
      selected_work_locations: [],
      local_all_location_list : [{
        'select_all': 'Select All',
        'group_option_list': this.all_location_list,
      }],
      submit_button_key: 1,
    };
  },
  components: {
    infoIcon,
    clearDropdownIcon,
    pastDateModal
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      name:{
          required: helpers.withMessage("Please enter a vendor name", requiredIf(() => {
          return this.selected_pbr != null;
        })),
          checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
          maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
      },
      selected_pbr: {
        required: helpers.withMessage("Please select a vendor name", requiredIf(() => {
          return !this.selected_pbr;
        })) 
      },
      email:{
        required: helpers.withMessage("Please enter an email", required),
        email: helpers.withMessage("Please enter a valid email", email),
        maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
        isUnique: helpers.withMessage('Email address already in use', helpers.withAsync(async (value) => {
          if (!value) return true;
          if (!this.v$.email.required || !this.v$.email.email) return true;
          this.disable_editvendor_submit_btn = true;
          let check_promise = new Promise((resolve, reject) => {
            if (this.check_ba_available_timer) {
              clearTimeout(this.check_ba_available_timer)
              this.check_ba_available_timer = null
            }
            this.check_ba_available_timer = setTimeout(() => {
              return fetch(JS_APP_URL + `/business-associates/check-unique-email-business-associates/${value}`)
                .then(response => {
                  if (response.ok) {
                    resolve(response.text())
                  } else {
                    resolve(new Error('error'))
                  }
                },  (error) => {
                  resolve(new Error('error'))
                })
            }, 500);
          });
          var response = await check_promise;
          this.disable_editvendor_submit_btn = false;
          return Boolean((response == 'available') ? false : true);
        }))
      },
      phone_number:{
          minLength: helpers.withMessage("Please enter a valid phone number", minLength(12)),
          maxLength: helpers.withMessage("Please enter a valid phone number", maxLength(12)),
      },
      date_expired:{
        required: helpers.withMessage("Please select expiration date", requiredIf(() => {
          return (this.is_no_expiration_applicable == false)
        }))
      },
      selected_work_locations: {
        requiredIf: helpers.withMessage("Please select assigned location(s)",
        requiredIf(() => {
            return this.all_location_list.length > 1
        })),
      },
    };
    return validationArray;
  },
  props:{
    call_pre_ba_api:{},
    all_location_list:{
      type: Array,
      default: () => []
    }
  },
  emits: ["add-ba-form-toggle", "reset-all-filter", "load-ba-list"],
  mounted() {
    this.getPredefineBusinessAssociatives();
  },
  watch:{
    date_expired(val){
      if(val != null){
        var modify_date = new Date(val);
        var today_date = new Date();
        today_date.setDate(today_date.getDate()-1);
        if(modify_date < today_date) {
          this.is_ba_past_date_show = true;
        }
      }
    },
    call_pre_ba_api(){
      this.predefined_ba_list = [{
        id:0,
        name: 'Add New',
      }]
      this.getPredefineBusinessAssociatives();
    }
  },
  methods:{
    no_expiration_date(){
      this.is_no_expiration_applicable = !this.is_no_expiration_applicable;
      if(this.is_no_expiration_applicable == true){
        this.date_expired = "";
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        this.disabledExpireDates = (date) => date <= today || date > today
      } else {
        this.date_expired = ""
        this.disabledExpireDates = (date) => date <= new Date(1)
      }
    },
    selectPBA() {
      if(this.selected_pbr && this.selected_pbr.id != 0){
        this.predefine_business_associates_id = this.selected_pbr.id 
        this.name = this.selected_pbr.name
        this.email = this.selected_pbr.email
        this.phone_number = this.selected_pbr.phone_number
        if(this.selected_pbr.expired_date != "" && this.selected_pbr.expired_date != null){
          this.date_expired = this.selected_pbr.expired_date
        }else{
          this.date_expired = "";
          this.is_no_expiration_applicable = true;
        }
        this.is_predifined_ba = true;
      }else{
        this.is_predifined_ba = false;
        this.predefine_business_associates_id = null 
        this.name = ''
        this.email = ''
        this.phone_number = ''
        this.date_expired = ''
        this.is_no_expiration_applicable = true;
      }
    },
    getPredefineBusinessAssociatives() {
      axios.get(JS_APP_URL + "/business-associates/get-predefine-business-associative")
      .then((response) => {
        if (response["data"]["status"] == "Success") {
          this.predefined_ba_list.push(...response["data"]["data"]);
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";    
        }
      });
    },
    addBASubmit(){
      this.v$.$touch();
      if (!this.v$.$invalid) {
            this.disable_add_ba_submit_btn = true;
            var location_list = new Array();
            if(this.all_location_list.length == 1){
              this.selected_work_locations = this.all_location_list;
            }
            _.forEach(this.selected_work_locations, (value)=> {
              location_list.push({"location_id": value.id});
            });
            NProgress.start();
            axios
            .post(JS_APP_URL + "/business-associates/add-business-associates", {
              name: this.name,
              email: this.email,
              phone_number: this.phone_number,
              expired_date: this.date_expired,
              is_no_expiration_applicable: this.is_no_expiration_applicable,
              predefine_business_associates_id:this.predefine_business_associates_id,
              location_list: location_list,
            })
            .then((response) => {
                if (response["data"]["status"] == "Error") {
                    if(response["data"]['data'].length > 0){
                        toastr.error(response["data"]['data'].join('</br>'), "Error");
                    }else{
                        toastr.error(response["data"]["message"], "Error");
                    }
                } else {
                    toastr.success(response["data"]["message"], "Success");
                    setTimeout(() => {
                      if(APP_ENV == 'production') {
                        var metadata = {
                          first_time_business_associates_added: response['data']['data']['first_business_associates_added'],
                          total_business_associates_added: response['data']['data']['total_business_associates_added'],
                          user_locations_number: response['data']['data']['user_locations_number']
                        };
                        Intercom('trackEvent', 'business-associate-status', metadata);
                      }
                        this.$emit("add-ba-form-toggle", false);
                        this.$emit("reset-all-filter");
                        this.$emit("load-ba-list", true);
                    }, 100);
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                   window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                NProgress.done();
                this.disable_add_ba_submit_btn = false;
                this.submit_button_key++;
            });
      }
      else{
        this.submit_button_key++;
      }
    },
    cancelAddBA(){
      this.$emit("add-ba-form-toggle", false);
    },
    resetPastDate(){
      this.date_expired = '';
      this.is_ba_past_date_show = false
    },
    pastDateModalClose(){
      this.is_ba_past_date_show = false
    }
  },
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("add-ba-form-toggle", false);
      }
    });
  }
};
 </script>
