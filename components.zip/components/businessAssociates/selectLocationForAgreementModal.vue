<template>
  <div>
    <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn modal-width-700">
          <div class="modal-container">
            <button v-if="!disable_agreement_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>

            <!-- send business associate agrrement modal code -->
            <div class="text-center mlr-auto">
              <img :src="JS_APP_URL + '/images/envelop-upload.svg'" alt="" title="" class="warning-icon-modal" />
            </div>          
            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb20">
              Complete Business Associate Agreement  
            </h2>
            <p class="text-center font-16 text-999 line-normal mb25">Select the Location Name (if your organization has multiple) to electronically complete your Business Associate Agreement</p> 

            <div class="row -mx-10 flex-auto justify-center mb45">
              <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10 mb-md-10">
                <div class="form-group mb-0">
                  <multiselect
                    v-model="selected_location"
                    :options="location_list"
                    :close-on-select="true"
                    tag-placeholder=""
                    placeholder=""
                    label="location_nickname"
                    track-by="id"
                    :searchable="true"
                    :showLabels="false"
                    :taggable="false"
                    >
                      <template #noResult>
                        <div class="multiselect__noResult text-center">
                          No results found
                        </div>
                      </template>
                    </multiselect>
                    <label class="label label-select ml-5" :class="{'label-float':selected_location != null}">Location</label>
                  </div>
                </div>
              </div>
  
            <div class="checkbox mb25">
              <input id="is_accept_btn" name="is_accept_btn" type="checkbox" v-model="is_accept_btn">
              <label for="is_accept_btn"  class="checkbox-label font-14 font_light gray_checkmark--text">I accept the <a :href="JS_APP_URL + '/site-policies'" class="font-14 font_semibold green--text text-decoration-underline" target="_blanck">Terms &amp; Conditions</a></label>
            </div>    
            <p class="text-center font-16 text-999 line-normal mb30">The employee listed above is authorized to sign legal documents for the selected location. By clicking the 'Complete' button below the selected employee above has read and agrees to the Business Associate Agreement.</p>                      
            <div class="text-center mb30">
              <button
                :disabled="selected_location == null || is_accept_btn == false || disable_agreement_submit_btn"
                type="submit"
                class="btn-primary btn-primary-outline mlr-auto reset-pass-btn"
                @click="completeAgreement"
              >
                <span>Complete</span>
              </button>
            </div>

            <!-- End -->
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
  <div class="modal-backdrop"></div>
  </div>
</template>

<script scoped>
import axios from "axios"
import closeIcon from '../common/icons/closeIcon.vue';

export default {
  props: {
    disable_agreement_submit_btn:{
      type: Boolean,
      default: () => false
    },
    all_location_list:{
      type: Array,
    },
    ba_data: {
      type: Object,
      default: () => {}
    }
  },
  emits: ["close-model", "complete-agreement"],
  components:{closeIcon},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      selected_location:null,
      is_accept_btn:false,
      location_list: []
    };
  },
  mounted(){
    this.getAssignedLocationList();
  },
  methods: {
    closeModal(){
      this.$emit("close-model", false);
    },
    completeAgreement(){
      this.$emit("complete-agreement",this.selected_location.id);
    },
    getAssignedLocationList() {
      axios.get(JS_APP_URL + "/business-associates/get-business-associates-assigned-location-list?ba_id=" + this.ba_data.id)
      .then((response) => {
        if (response["data"]["status"] == "Success") {
          this.location_list = response["data"]["data"];
          if(this.location_list.length == 0){
            window.location = JS_APP_URL + "/dashboard";  
          }
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";    
        }
      })
      .then(() => {}); 
    }
  },
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.disable_agreement_submit_btn) {
        this.$emit("close-model", false);
      }
    });
    // document.body.classList.add('modal-open');
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
