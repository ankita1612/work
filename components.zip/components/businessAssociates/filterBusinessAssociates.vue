<template>
  <div>
    <div class="row flex-auto items-center -mx-10 mb35">
      <div class="col-12 col-md-12 col-lg-6 col-xl-5 px10 mb-sm-10 mb-md-10">
        <div class="flex flex-wrap flex-auto items-center employee-filter-left">
          <h6 class="font-18 blueog--text mb0 mr6">Business Associates </h6>       
          <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" style="height: 24px;" class="cursor-pointer">
          <span><info-icon></info-icon></span>
            <template #popper>
               Business Associates include any person or entity that will have, or may have, access to Protected Health Information or electronic Protected Health Information. Some examples include; PM/EHR vendors, IT company/professionals, CPA firms, attorneys, data backup vendors, practice consultants, and claims processing companies. Click the email icon to send an agreement using the Abyde Business Associate Portal.
            </template>
          </VTooltip>
          <button v-on:click="toggleAddBAForm" type="button" class="plus-icon-btn ml3 mt1"><plus-icon></plus-icon></button>
          <div class="import-btn-wrapper ml25">
            <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
              <input :disabled="is_import_btn_disabled" ref="import_file_upload" type="file" hidden @change="importBusinessAssociates" accept=".xlsx, .xls">
              <button :disabled="is_import_btn_disabled" @click="onPickImportFile" type="button" class="import-btn"><span><import-icon></import-icon></span><span>Import</span></button>
              <template #popper>
                <i class="text-center d-block">If preferred, you may import multiple business associate records via excel file upload. Click here to <b><a class="downloadsamplelink font-300" :href="sample_import_doc" target="_blank">download the Template File</a></b>. Once completed, click the IMPORT button to upload your business associates.</i>
              </template>
            </VTooltip>
          </div>
          <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" v-if="is_refresh_btn_shown">
            <a v-on:click="resetAndLoadLatestData()" class="font-12 blueog--text ml10 font-italic font_semibold cursor-pointer d-block text-right">
              <img :src="JS_APP_URL +'/images/refresh-list.png'" />
            </a>
            <template #popper>
              Refresh Business Associates List
            </template>
          </VTooltip>
        </div>        
      </div>
      <div class="col-12 col-md-12 col-lg-6 col-xl-7 px10">
        <div class="flex flex-wrap flex-auto" :class="[all_location_list.length == 1 ? 'single-location-filter-wrapper' : '']">
          <div class="row flex-auto -mx-10 justify-end justify-start-small-medium items-center">
            <div v-if="all_location_list.length > 1" class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 px10  mb-sm-10">
              <div class="form-group account-filter-wrapper mb-0">
                <multiselect 
                v-model="filter_selected_locations" 
                tag-placeholder="" 
                placeholder="" 
                label="location_nickname" 
                track-by="id" 
                :options="all_location_list" 
                :multiple="true" 
                :close-on-select="true"
                :showLabels="false"
                @update:model-value="onChangeFilter"
                :taggable="false">  
                    <template #noResult>
                        <div class="multiselect__noResult text-center">No results found</div>
                    </template>  
                    <template #selection>
                        <div class="multiselect__tags-wrap" v-if="filter_selected_locations.length > 1">
                            <span class="multiselect__tag">
                                <span>{{ filter_selected_locations.length }} Locations Selected</span>
                            </span>
                        </div>
                    </template>                                      
                </multiselect>	
                <label class="label label-select font-italic" :class="{ 'label-float': (filter_selected_locations.length > 0) }">Filter by Location</label>
              </div>
            </div> 
            <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 px10  mb-sm-10">
            <div class="flex items-center">
              <div class="form-group account-filter-wrapper mb-0 flex-auto">
                <multiselect 
                v-model="filter_selected_sort_by" 
                :options="sort_by_options" 
                :close-on-select="true" 
                tag-placeholder="" 
                placeholder="" 
                label="text" 
                track-by="id" 
                @update:model-value="onChangeFilter"
                :searchable="false"
                :showLabels="false"
                :taggable="false"
                >
                  <template #noResult>
                      <div class="multiselect__noResult text-center">No results found</div>
                  </template>   
                </multiselect>
                <label class="label label-select font-italic" :class="{ 'label-float': (filter_selected_sort_by != null) }">Sort by</label>   
              </div>
              <img v-on:click="toggleSortDir" v-if="filter_selected_sort_by != null && filter_selected_sort_by_dir == 'DESC'" :src="JS_APP_URL +'/images/sort-down.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" />      
              <img v-on:click="toggleSortDir" v-if="filter_selected_sort_by != null && filter_selected_sort_by_dir == 'ASC'" :src="JS_APP_URL +'/images/sort-up.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" />      
              </div>
            </div> 
            <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
              <div class="form-group account-filter-wrapper mb-0">
                <input @input="onChangeFilter" class="form-input form-input-search" type="text" v-model.trim="search_text">
                  <label class="label font-italic" :class="{ 'label-float': search_text }">Search</label>
                  <div
                      class="search-btn-input">
                      <img :src="JS_APP_URL +'/images/search.svg'" alt="" title="" />
                  </div>
              </div>
            </div>                     
          </div>  
        </div>       
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>
<script scoped>
import axios from "axios";
import fullPageLoader from "../common/fullPageLoader.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import infoIcon from "../common/icons/infoIcon.vue"
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
import plusIcon from '../common/icons/plusIcon.vue';
import importIcon from '../common/icons/importIcon.vue';

export default {
  data() {
    return {
      filter_selected_locations: [],
      search_text: "",
      filter_selected_sort_by: null,
      filter_selected_sort_by_dir: 'ASC',
      sort_by_options: [
        { id: 'name', text: 'Name' },
        { id: 'email', text: 'Email' },
        { id: 'phone_number', text: 'Phone Number' },
        { id: 'expired_date', text: 'Expiration Date' },
      ],
      delay_timer: "",
      is_import_btn_disabled: false,
      is_full_page_loader_shown: false,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL
    };
  },
  props: {
    all_location_list:{
      type: Array,
      default: () => []
    },
    is_add_ba_shown:{
      type: Boolean,
      default: () => false
    },
    is_refresh_btn_shown:{
      type: Boolean,
      default: () => false
    },
    sample_import_doc:{
      type: String,
      default: () => ""
    },
  },
  emits: ['add-ba-form-toggle', 'apply-filter', "reset-all-filter", "load-ba-list", "open-import-modal"],
  components: {
    infoIcon,
    clearDropdownIcon,
    plusIcon,
    importIcon,
    fullPageLoader
  },
  watch:{
  },
  methods:{
    toggleSortDir(){
      this.filter_selected_sort_by_dir = (this.filter_selected_sort_by_dir == 'ASC')?'DESC':'ASC';
      this.onChangeFilter();
    },
    toggleAddBAForm(){
      this.$emit('add-ba-form-toggle', !this.is_add_ba_shown)
    },
    onChangeFilter(){
      if (this.delay_timer) {
          clearTimeout(this.delay_timer);
          this.delay_timer = null;
      }
      this.delay_timer = setTimeout(() => {
        this.$emit('apply-filter', {search_query:this.search_text, sort_by: (this.filter_selected_sort_by != null)?this.filter_selected_sort_by.id:'', sort_by_dir: this.filter_selected_sort_by_dir, filter_by_location: this.filter_selected_locations});
      }, 800);
    },
    resetAndLoadLatestData(){
      this.$emit("reset-all-filter");
      this.$emit("load-ba-list", true);
    },
    onPickImportFile(){
      this.$refs.import_file_upload.click();
    },
    importBusinessAssociates(event){
      var formData = new FormData();
      formData.append("import_file", event.target.files[0]);
      this.is_full_page_loader_shown = true;
      this.is_import_btn_disabled = true;
      axios
      .post(JS_APP_URL + "/business-associates/import-business-associates", formData, {
        headers: {
              'Content-Type': 'multipart/form-data'
        }
      })
      .then((response) => {
          if (response["data"]["status"] == "Error") {
              if(response['data']['data'].length == 0){
                  this.$emit("open-import-modal", response["data"]);
                }else{
                    this.$emit("open-import-modal", response['data']);
                 }
              setTimeout(() => {
                this.$refs.import_file_upload.value = null;
              }, 200);
          } else {
             if(response['data']['data'].length == 0){
                toastr.success(response["data"]["message"], "Success");
              }
              setTimeout(() => {
                  this.$emit('add-ba-form-toggle', false);
                  this.$emit("reset-all-filter");
                  this.$emit("load-ba-list", true);
                  if(response['data']['data'].length != 0){
                    this.$emit("open-import-modal", response['data']);
                  }
              }, 100);
          }
      })
      .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";    
          }
      })
      .then(() => {
        this.is_full_page_loader_shown = false;
          this.is_import_btn_disabled = false;
      });
    },
  }
};
 </script>