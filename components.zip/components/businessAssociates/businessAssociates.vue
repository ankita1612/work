<template>
  <div>
    <header-after-login></header-after-login>
    <div class="container pt40 pb60">
      <div class="flex items-center justify-center text-center flex-wrap mb50">
        <h1 class="page-center-title text-center font-24 font_semibold blueog--text line-normal  inline-flex items-center">
          Business Associates     
        </h1>
        <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml6">
          <button @click="PlayExplainerVideoModalToggle('yes')" class="cursor-pointer svg-icon-height dashboard-video-icon mt4">
            <explainer-video-icon></explainer-video-icon>
          </button>
          <template #popper>
            Video Guide
          </template>
        </VTooltip>
      </div>
      

      <filter-business-associates 
      :key="filter_component_key" 
      :all_location_list="all_location_list"
      :is_add_ba_shown="is_add_ba_shown"
      :is_refresh_btn_shown="is_refresh_btn_shown"
      :sample_import_doc="sample_import_document"
      @add-ba-form-toggle="addBAFormToggle"
      @apply-filter="applyFilter"
      @reset-all-filter="resetAllFilter"
      @load-ba-list="loadBAList"
      @open-import-modal="openCloseImportModal"
      >      
      </filter-business-associates>

      <transition name="simple-fade-transition">
        <add-business-associates v-if="is_add_ba_shown" :call_pre_ba_api="call_pre_ba_api" :all_location_list="all_location_list" @add-ba-form-toggle="addBAFormToggle" @load-ba-list="loadBAList" @reset-all-filter="resetAllFilter"></add-business-associates>
      </transition>

      <div class="mt60">
        <business-associates-item v-for="(ba_item, index) in ba_list" v-bind:key="index" :ba_item="ba_item" :all_location_list="all_location_list" @load-ba-list="loadBAList" @deleted-ba="deleteBA" @updated-ba="updatedBA"></business-associates-item>
        <div v-if="!is_full_page_loader_shown && ba_list.length === 0" class="">
          <div class="user-detail-text font-14 gray_checkmark--text text-center">
            <no-data-icon></no-data-icon>
            <div class="font-14 text-center blueog--text">No business associate(s) available.</div>
          </div>
        </div>
      </div>
      <InfiniteLoading @infinite="loadBAList(false)" />
      <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>  
    </div>
        <import-error-modal 
          v-if="is_import_error_modal"
          :import_errors="import_errors_data"
          @close-model="openCloseImportModal"
        />
        <play-explainer-video-modal v-if="play_video_modal == true" :video_file="video_file"
          :video_caption_file="video_caption_file" @close-model="PlayExplainerVideoModalToggle"></play-explainer-video-modal>
  </div>
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
import infoIcon from "../common/icons/infoIcon.vue"
toastr.options.preventDuplicates = true;
import fullPageLoader from '../common/fullPageLoader.vue';
import filterBusinessAssociates from "./filterBusinessAssociates.vue"
import addBusinessAssociates from "./addBusinessAssociates.vue"
import noDataIcon from '../common/icons/noDataIcon.vue'
import businessAssociatesItem from "./businessAssociatesItem.vue"
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import importErrorModal from "../common/includes/importErrorModal.vue";
import explainerVideoIcon from "../common/icons/explainerVideoIcon.vue";
import playExplainerVideoModal from "../common/includes/playExplainerVideoModal.vue";
import _ from "lodash";

export default {
  data() {
    return {
      ba_list: [],
      sample_import_document: '',
      is_list_loading: false,
      per_page_records: 10,
      current_page: 1,
      total_page: 1,
      sort_by: '',
      sort_by_dir: '',
      search_query: "",
      is_add_ba_shown: false,
      is_full_page_loader_shown: false,
      is_refresh_btn_shown: false,
      call_pre_ba_api:0,
      filter_component_key: Math.random(),
	    JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      is_import_error_modal: false,
      import_errors_data: [],
      call_ajax: 1,
      video_file: "hce_explainer_bap_final.mp4",  
      video_caption_file: "hce_explainer_bap_final.vtt",  
      play_video_modal: false,
      all_location_list: [],
      filter_by_location: []
    };
  },
  components: {
    infoIcon,
    fullPageLoader,
    filterBusinessAssociates,
    addBusinessAssociates,
    noDataIcon,
    businessAssociatesItem,
    headerAfterLogin,
    importErrorModal,
    explainerVideoIcon,
    playExplainerVideoModal
  },
  validations: {
  },
  watch: {
  },
  computed: {
  },
  mounted() {
	  this.loadLocationList();
  },
  methods:{
    PlayExplainerVideoModalToggle() {
      if (this.play_video_modal == true) {
        this.play_video_modal = false;
      } else {
        this.play_video_modal = true;
      }
    },
    addBAFormToggle(status = true){
      this.is_add_ba_shown = status;
    },
    applyFilter(search_params = {}){
      this.filter_by_location = search_params.filter_by_location;
      this.sort_by = search_params.sort_by;
      this.sort_by_dir = search_params.sort_by_dir;
      this.search_query = search_params.search_query;
      setTimeout(() => {
        this.loadBAList(true);
      }, 100);
    },
    resetAllFilter(){
      this.sort_by = '';
      this.sort_by_dir = '';
      this.filter_by_location = [];
      this.search_query = "";
      this.filter_component_key = Math.random();
    },
    loadLocationList(){
      this.is_full_page_loader_shown = true;
      axios
      .get(JS_APP_URL + "/general/get-business-associates-module-location-list")
      .then((response) => {
        if (response["data"]["status"] == "Success") {
          this.all_location_list = response["data"]["data"];
          if(this.all_location_list.length == 0){
            window.location = JS_APP_URL + "/dashboard";  
          }
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";    
        }
      })
      .then(() => {
        // this.is_full_page_loader_shown = false;
      });
    },
    loadBAList(need_pagination_reset = false){
      if(need_pagination_reset){
        this.current_page = 1;
        this.total_page = 1;
        this.ba_list = [];
      }
      if (this.current_page <= this.total_page && this.call_ajax == 1) {	
        this.call_ajax = 0;
        this.is_list_loading = true;	
        this.is_full_page_loader_shown = true;
        axios
          .post(JS_APP_URL + "/business-associates/get-business-associates-list", {
            sort_by: this.sort_by,
            sort_by_dir: this.sort_by_dir,
            search_query: this.search_query,
            per_page: this.per_page_records,
            page: this.current_page,
            filter_by_location: _.map(this.filter_by_location, 'id'),
          })
          .then((response) => {
            if (response["data"]["status"] == "Success") {
              var ba_data = response["data"]["data"]['business_associates_list'];
              this.sample_import_document = response['data']['data']['sample_import_doc'];
              this.ba_list.push(...ba_data.data);
              this.total_page = ba_data.last_page;
              if(this.ba_list.length == 0 && this.search_query == '' && this.sort_by == ''){
                this.is_add_ba_shown = true;
              }
              this.current_page = this.current_page + 1;
              this.is_list_loading = false;
              this.is_refresh_btn_shown = false;
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";    
            }
          })
          .then(() => {            
            setTimeout(() => {
              this.is_full_page_loader_shown = false;
              this.call_ajax = 1;
            }, 100);
          });
      }
    },
    deleteBA(ba_id = ''){
      if(ba_id){
        var found_index = _.findIndex(this.ba_list, (o) => { return o.id === ba_id; });
        if(found_index >= 0){
          this.ba_list.splice(found_index, 1);
          if(this.ba_list.length == 0){
            this.showRefreshListButton();
          }
          if(this.is_add_ba_shown == true){
            this.call_pre_ba_api++
          }
        }
      }
    },
    updatedBA(ba_updated = {}){
      if(!_.isEmpty(ba_updated)){
        var found_index = _.findIndex(this.ba_list, (o) => { return o.id === ba_updated.id; });
        if(found_index >= 0){
          this.ba_list[found_index] = ba_updated;
           this.showRefreshListButton();
        }
      }
    },
    showRefreshListButton(){
      if(this.sort_by != "" || this.search_query != "" || this.filter_by_location.length > 0){
        this.is_refresh_btn_shown = true;
      }
    },
    openCloseImportModal(import_errors) {
      if(!this.is_import_error_modal) {
        this.is_import_error_modal = true
        this.import_errors_data = import_errors;
      } else {
        this.is_import_error_modal = false
      }
    },
  }
};
 </script>