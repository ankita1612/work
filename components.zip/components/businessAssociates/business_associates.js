import { createApp } from 'vue';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import VueMask from '@devindex/vue-mask';
import DatePicker from 'vue-datepicker-next';
import 'vue-datepicker-next/index.css';
import InfiniteLoading from "v3-infinite-loading";
import businessAssociates from "./businessAssociates.vue";

const business_associates_app = createApp(businessAssociates);
business_associates_app.use(VueMask);
business_associates_app.use(FloatingVue)
business_associates_app.component('datepicker', DatePicker)
business_associates_app.component('multiselect', Multiselect)
business_associates_app.component('InfiniteLoading', InfiniteLoading);
business_associates_app.mount("#business_associates_app");