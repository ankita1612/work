<template>
    <div>
        <Teleport to="body">
            <transition name="modal">
                <div class="modal-mask modal-scrollable">
                    <div class="modal-wrapper animate__animated animate__zoomIn">
                        <div class="modal-container">
                            <button v-on:click="closeModal" class="cursor-pointer modal-close">
                                <close-icon></close-icon>
                            </button>
                            <div class="text-center mlr-auto mb7 pt20">
                                <img :src="JS_APP_URL +'/images/warning.svg'" class="warning-icon-modal mb5" alt="" title="">
                            </div>
                            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb20">
                                Past Date?
                            </h2>
                            <p class="text-center font-16 text-999 line-normal mb30">
                                You've selected an expiration date that has passed,<br>do you still want to continue?
                            </p>
                            <div class="flex flex-wrap items-center justify-center pb40">
                                <button @click="closeModal" class="btn-cancel-outline btn-width-120 mx10">Cancel</button>
                                <button @click="selectPastDate" class="btn-primary btn-width-120 mx10 px30 mt-xs-20">Yes</button>
                            </div>    
                        </div>
                    </div>
                </div>
            </transition>
        </Teleport>
        <div class="modal-backdrop"></div>
    </div>
</template>

<script scoped>
import closeIcon from '../common/icons/closeIcon.vue';

export default {
    emits: ["close-model", "select-past-date"],
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
        };
    },
    components:{
        closeIcon,
    },
    methods: {
        closeModal() {
            this.$emit("close-model");
        },
        selectPastDate(){
            this.$emit("select-past-date");
        }
    },
    created() {
        // document.body.classList.add('modal-open');
        document.addEventListener("keydown", (e) => {
        if (e.keyCode == 27) {
            this.$emit("close-model");
        }
        });
    },
    destroyed(){
        // document.body.classList.remove('modal-open');
    }
}
</script>