<template>
    <div>
        <Teleport to="body">
            <transition name="modal">
                <div class="modal-mask modal-scrollable">
                    <div class="modal-wrapper animate__animated animate__zoomIn">
                        <div class="modal-container">
                            <button v-if="!disable_agreement_remind_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                                <close-icon></close-icon>
                            </button>
                            <div class="text-center mlr-auto pt20">
                                <img :src="JS_APP_URL +'/images/envelop-process.svg'" class="warning-icon-modal" alt="" title="">
                            </div>
                            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb20">
                                Send a reminder to sign the Business Associate Agreement 
                            </h2>
                            <p class="text-center font-16 text-999 line-normal mb30" >
                                You’ve sent the Business Associate Agreement to {{send_agreement_ba_data.name}}, but are still awaiting a signature. If you’d like to send a reminder email, just click the button below!
                            </p>
                            <div class="flex flex-wrap items-center justify-center pb10">
                                <button :disabled="disable_agreement_remind_btn" v-on:click.once="sendReminderEmail" class="btn-primary-outline mx5">SEND REMINDER</button>
                            </div>
                        </div>
                    </div>
                </div>
            </transition>
        </Teleport>
        <div class="modal-backdrop"></div>
    </div>
</template>

<script scoped>
import closeIcon from '../common/icons/closeIcon.vue';
import pdfIcon from '../common/icons/pdfIcon.vue';

export default {
    props: {
        send_agreement_ba_data: {
            type: Object,
            default: () => {}
        },
        disable_agreement_remind_btn:{
            type: Boolean,
            default: () => false
        },
    },
    emits: ["close-model", "send-reminder-email"],
    components:{closeIcon,pdfIcon},
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
        };
    },
    methods: {
        closeModal() {
            this.$emit("close-model", false);
        },
        sendReminderEmail() {
            this.$emit("send-reminder-email")
        }
    },
    created() {
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27 && !this.disable_agreement_remind_btn) {
                this.$emit("close-model", false);
            }
        });
    },
}
</script>