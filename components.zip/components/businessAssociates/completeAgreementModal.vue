<template>
  <div>
    <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container">
            <button v-if="!disable_agreement_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb20 pt20">
              <img :src="JS_APP_URL +'/images/envelop-done.svg'" class="warning-icon-modal" alt="" title="">
            </div>
            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb20">
              Signed, sealed, delivered!
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">{{send_agreement_ba_data.name}} 
              has successfully signed the Business Associate Agreement. If you'd like to download a copy of the signed document, 
              click the {{send_agreement_ba_data.business_associates_agreement.agreement_type=='url'?'view':'download'}} button below!</p>
            <button v-on:click="downloadAgreement" v-if="is_download_btn == true" class="btn-blue-outline btn-left-padding">
              <div class="next-arrow-icon pdf-icon"> 
                <pdf-icon></pdf-icon>
              </div> DOWNLOAD
            </button>
            <button v-on:click="viewUrl" v-if="is_download_btn == false" class="btn-primary-outline mx5">
            View
            </button>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
  <div class="modal-backdrop"></div>
  </div>
</template>

<script scoped>
import closeIcon from '../common/icons/closeIcon.vue';
import pdfIcon from '../common/icons/pdfIcon.vue';
export default {
  props: {
    send_agreement_ba_data:{
      type: Object,
      default: () => {}
    },
    disable_agreement_submit_btn:{
      type: Boolean,
      default: () => false
    },
  },
  emits: ["close-model", "opne-url-modal"],
  components:{closeIcon, pdfIcon},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_download_btn:null,
    };
  },
  mounted(){
    if(this.send_agreement_ba_data.business_associates_agreement.agreement_type == 'url'){
      this.is_download_btn = false
    }else{
      this.is_download_btn = true
    }
  },
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
    downloadAgreement() {
      var link = document.createElement("a");
      link.download =this.send_agreement_ba_data.business_associates_agreement.file_name;
      link.href =this.send_agreement_ba_data.business_associates_agreement.file_name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      this.$emit("close-model", false);
    },
    viewUrl(){
      this.$emit("opne-url-modal", this.send_agreement_ba_data.business_associates_agreement.agreement_link);
    }
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.disable_agreement_submit_btn) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
