<template>
  <div>
    <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn modal-width-700">
          <div class="modal-container">
            <button v-if="!disable_agreement_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>

            <!-- send business associate agrrement modal code -->
            <div class="text-center mlr-auto">
              <img :src="JS_APP_URL + '/images/envelop-upload.svg'" alt="" title="" class="warning-icon-modal" />
            </div>          
            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb25">
              Send Business Associate Agreement for <br/>this vendor to review 
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">Select the Location Name (if your organization has multiple) and Employee<br/> (who is authorized to sign these agreements) to electronically send your<br/> Business Associate agreement for signature.<br/></p> 

            <div class="row -mx-10 flex-auto justify-center mb50">
              <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10 mb-md-10">
                <div class="form-group mb-0">
                  <multiselect
                    v-model="selected_location"
                    :options="location_list"
                    :close-on-select="true"
                    tag-placeholder=""
                    placeholder=""
                    label="location_nickname"
                    track-by="id"
                    @update:model-value="selectLocation"
                    :searchable="true"
                    :showLabels="false"
                    :taggable="false"
                    >
                      <template #noResult>
                        <div class="multiselect__noResult text-center">
                          No results found
                        </div>
                      </template>
                    </multiselect>
                    <label class="label label-select ml-5" :class="{'label-float':selected_location != null}">Location</label>
                  </div>
                </div>
              <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10 mb-md-10">
                <div class="form-group mb-0">
                  <multiselect
                      class="company-location-select"
                      v-model="selected_employee"
                      :options="employee_list"
                      :custom-label="customLabel"
                      :taggable="false"
                      :multiple="false"
                      :showLabels="false"
                      @update:model-value="checkHCOEmployee()"
                      track-by="id"
                      placeholder=""
                    >
                      <template #noResult>
                        <div class="multiselect__noResult text-center">
                          No results found
                        </div>
                      </template>
                      <template #noOptions>
                          <div class="multiselect__noOptions text-center">No data available</div>
                      </template>
                    </multiselect>
                    <label class="label label-select ml-5" :class="{'label-float':selected_employee != null}">Employee</label>
                  </div>
              </div>
              <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                <div class="form-group mb-0" :class="{ 'form-group--error': v$.job_title.$error }">
                  <input class="form-input" v-model.trim="v$.job_title.$model" :class="{ 'form-error': v$.job_title.$error }">
                  <label class="label" :class="{'label-float':v$.job_title.$model}">Job Title</label>
                  <div v-if="v$.job_title.$errors.length > 0">
                    <div class="form-error-text">
                      {{ v$.job_title.$errors[0].$message }}
                    </div>
                  </div>
              </div>            
            </div>                           
              </div>
            <div class="checkbox mb30">
              <input id="is_accept_btn" name="is_accept_btn" type="checkbox" v-model="is_accept_btn">
              <label for="is_accept_btn"  class="checkbox-label font-14 font_light gray_checkmark--text">I accept the <a :href="JS_APP_URL + '/site-policies'" class="font-14 font_semibold green--text text-decoration-underline" target="_blanck">Terms &amp; Conditions</a></label>
            </div>    
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">The employee listed above is authorized to sign legal documents for the selected location. Clicking the 'Send Email' button below will confirm the selected employee has read and agrees to the Business Associate Agreement.</p>                      
            <div class="flex flex-wrap items-center justify-center pb40">
              <button
                :disabled="selected_location == null || selected_employee == null || job_title == '' || job_title.length>40 || is_accept_btn == false || disable_agreement_submit_btn"
                type="submit"
                class="btn-primary btn-primary-outline mx5"
                @click="sendEmail"
              >
                <span>SEND EMAIL</span>
              </button>
              <button 
                v-if="send_agreement_ba_data && Object.keys(send_agreement_ba_data).length > 0 && send_agreement_ba_data.signature === null && send_agreement_ba_data.agreement_link === null  && send_agreement_ba_data.file_name === null"
                type="submit"
                class="btn-primary btn-primary-outline mx5"
                :disabled="selected_location !== null && selected_employee !== null && job_title !== '' && job_title.length>0 && is_accept_btn == true && !disable_agreement_submit_btn"
                @click="sendReminderTogglel"
              >
                <span>SEND REMINDER</span>
              </button>
            </div>

            <!-- End -->
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
  <div class="modal-backdrop"></div>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import closeIcon from '../common/icons/closeIcon.vue';
import useVuelidate from "@vuelidate/core";
import { maxLength, helpers } from "@vuelidate/validators";
import {checkSpecialChars, checkSpecialCharsErrorMessage}  from "../common/customValidation";

export default {
  props: {
    disable_agreement_submit_btn:{
      type: Boolean,
      default: () => false
    },
    all_location_list:{
      type: Array,
    },
    send_agreement_ba_data: {
      type: Object,
      default: () => {}
    },
    ba_data: {
      type: Object,
      default: () => {}
    }
  },
  emits: ["close-model", "send-agreement-email","send-reminder-toggle"],
  components:{closeIcon},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      selected_employee:null,
      employee_list:[],
      selected_location:null,
      is_accept_btn:false,
      job_title:'',
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
      location_list: []
    };
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      job_title: {
        maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars)
      }
    }
    return validationArray;
  },
  mounted() {
    this.getAssignedLocationList();
  },
  methods: {
    closeModal(){
      this.$emit("close-model", false);
    },
    sendEmail(){
      this.v$.$touch();
      if (!this.v$.$invalid) {
        this.$emit("send-agreement-email",this.customLabel(this.selected_employee),this.job_title,this.selected_location.id);
      }
    },
    selectLocation() {
      if(this.selected_location) {
        this.selected_employee=null;
        this.getEmployeeList();
      } else {
        this.selected_employee=null;
        this.employee_list=[];
        this.job_title="";
      }
    },
    getEmployeeList(){
        NProgress.start();
        axios.post(
          JS_APP_URL +
            "/business-associates/get-employees-hco",{
              location_id:this.selected_location.id
            }
        )
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.employee_list = response["data"]["data"];
          } else {
            if (response["data"]["data"].length > 0) {
              toastr.error(response["data"]["data"].join("</br>"), "Error");
            } else {
              toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        });
    },
    customLabel(option) {
      if (option.first_name && option.last_name) {
        return `${option.first_name} ${option.last_name}`;
      } else {
        return ``;
      }
    },
    checkHCOEmployee(){
      if(this.selected_employee && this.selected_employee.is_hco == 1){
        this.job_title = "HIPAA COMPLIANCE OFFICER"
      }else{
        this.job_title = ""
      }
    },
    sendReminderTogglel(){
      this.$emit("send-reminder-toggle");
    },
    getAssignedLocationList() {
      axios.get(JS_APP_URL + "/business-associates/get-business-associates-assigned-location-list?ba_id=" + this.ba_data.id)
      .then((response) => {
        if (response["data"]["status"] == "Success") {
          this.location_list = response["data"]["data"];
          if(this.location_list.length == 0){
            window.location = JS_APP_URL + "/dashboard";  
          }
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";    
        }
      })
      .then(() => {}); 
    }
  },
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.disable_agreement_submit_btn) {
        this.$emit("close-model", false);
      }
    });
    // document.body.classList.add('modal-open');
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
