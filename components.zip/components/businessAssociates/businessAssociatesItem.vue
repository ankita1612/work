<template>
  <div>
    <transition name="simple-fade-transition" mode="out-in">
    <div v-if="!is_ba_editing" key="saved" class="user-detail-card py6 px15 light mb20" >
      <div class="row flex-auto -mx-10 items-center">
        <div class="col-12 col-md-6 col-lg-2 col-xl-3 px10">
          <div class="user-detail-text font-14 gray_checkmark--text mb-md-10 mt-sm-10" v-text="ba_item.name"></div>
        </div>
        <div class="col-12 col-md-6 col-lg-2 col-xl-2 px10">
          <div class="user-detail-text font-14 gray_checkmark--text mb-md-10" v-text="ba_item.email"></div>
        </div>
        <div class="col-12 col-md-6 col-lg-2 col-xl-2 px10">
          <div class="user-detail-text font-14 gray_checkmark--text mb-md-10" v-text="(ba_item.phone_number == null ? '':ba_item.phone_number)"></div>
        </div>
        <div class="col-12 col-md-6 col-lg-2 col-xl-1 px10 text-center ba-date-col">
            <div class="inline-flex text-center flex-col">
                <div class="font-10 font-italic gray_checkmark--text mb2">Expiration Date</div>
                <div :class="{ 'blueog--text': ba_item.expired_date == null, 'red--text': ba_item.expired_date != null && this.compare_today_date > ba_item.expired_date }" class="font-14 blueog--text font_semibold mb-md-10" v-text="(ba_item.expired_date == null ? 'None':formatDate(ba_item.expired_date))"></div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-lg-2 col-xl-1 px10 text-center">
          <div v-if="all_location_list.length > 1" type="button" class="user-location-icon cursor-pointer ml50">
            <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
              <img :src="JS_APP_URL +'/images/location.svg'" alt="" title="">
              <template #popper>
                <div class="white--text font-12 font_semibold mb2 text-center">ASSIGNED LOCATION(S)</div>
                <div class="text-center seperator-line pb3 pt3" v-for="(each_location, each_location_index) in ba_item.business_associates_location" v-bind:key="each_location_index" v-text="each_location.location.location_nickname"></div>
              </template>
            </VTooltip>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10 flex justify-end justify-start-small-medium">
          <div class="flex flex-wrap items-center full-width">
              <div class="action-sept mr-auto ml40"></div>
              <div class="user-detail-action flex flex-wrap items-center">
                <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml7" 
                    v-if="(ba_item.predefine_business_associates_id != null && ba_item.predefine_business_associative.agreement_type != 'predefined_dynamic_doc') || ba_item.business_associates_agreement && (ba_item.business_associates_agreement.agreement_type == 'url' || ba_item.business_associates_agreement.agreement_type == 'doc')">
                      <span class="action-icon-btn action-btn-black cursor-pointer">
                          <i-icon></i-icon>
                      </span>
                      <template #popper>
                          When uploading or linking to a non-Abyde Business Associate Agreement (BAA) please note that to meet HIPAA requirements your BAA must be dually executed (signed by both parties). If your linked or uploaded agreement is not dually executed, we advise you to reach out to your Business Associate to obtain an executed copy.
                      </template>
                </VTooltip>
                <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml10"
                    v-if="(!(agreementStatus == 'complete')) && ba_item.predefine_business_associates_id == null">
                    <button @click="downloadAgreementWithoutSignature(ba_item.id)" type="button"
                        class="action-icon-btn action-btn-blue cursor-pointer complete-action-btn pdf-round-btn">
                        <span
                        class="pending-svg-icon inline-flex items-center justify-center"><pdf-icon></pdf-icon></span>
                    </button>
                    <template #popper>
                      Business Associate Agreement
                    </template>
                </VTooltip>
                <div class="ml10" v-else>
                    <button disabled type="button"
                        class="action-icon-btn action-btn-blue cursor-pointer complete-action-btn pdf-round-btn pdf-round-disable">
                        <span
                        class="pending-svg-icon inline-flex items-center justify-center"><pdf-icon></pdf-icon></span>
                    </button>
                </div>
                <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml7">
                    <button  type="button" class="action-icon-btn action-btn-blue cursor-pointer" :class="agreement_btn_class">
                      <span @click="sendAgreementToggle()" class="pending-svg-icon inline-flex items-center justify-center" v-if="agreementStatus == 'send'"><send-icon></send-icon></span>
                      <span @click="sendAgreementToggle()" class="pending-svg-icon inline-flex items-center justify-center" v-if="agreementStatus == 'pending'" ><pendingfile-icon></pendingfile-icon></span>
                      <span @click="selectLocationForAgreementToggle(true)" class="pending-svg-icon inline-flex items-center justify-center" v-if="agreementStatus == 'pending-pre-ba'" ><pendingfile-icon></pendingfile-icon></span>
                      <span @click="completeAgreementToggle(true)" class="pending-svg-icon inline-flex items-center justify-center" v-if="agreementStatus == 'complete'">
                          <complete-icon></complete-icon>
                      </span>
                    </button>
                    <template #popper>
                        Business Associate Agreement
                    </template>
                </VTooltip>
                <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml7">
                    <button v-on:click="editBA" type="button" class="action-icon-btn action-btn-blueog cursor-pointer">
                        <img :src="JS_APP_URL +'/images/pencil.svg'" alt="" title="">
                    </button>
                    <template #popper>
                        Edit
                    </template>
                </VTooltip>
                <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml7">
                    <button v-on:click="deleteBAToggle" type="button" class="delete-location-btn cursor-pointer">
                        <img :src="JS_APP_URL +'/images/bin.svg'" alt="" title="" class="mlr-auto">
                    </button>
                    <template #popper>
                        Delete
                    </template>
                </VTooltip>
              </div>
          </div>
        </div>
      </div>
    </div>
    <div v-else key="editing" class="user-detail-card py20 px15 light mb20">
      <form @submit.prevent="editBASubmit">
        <div class="row flex-auto -mx-10">
          <div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-20 px10 mb-lg-10 mb-md-10">
            <div class="form-group mb-0" :class="{ 'form-group--error': v$.name.$errors.length, 'cursor-not-allowed': ba_item.predefine_business_associates_id !== null }">
                <input :disabled="(ba_item.predefine_business_associates_id == null ? false: true)" class="form-input location-input-box" :class="{ 'form-error': v$.name.$errors.length }" type="text" name="name" v-model.trim="v$.name.$model">  
                <label class="label location-input-label" :class="{ 'label-float': v$.name.$model }">Vendor Name</label>
                <div v-if="v$.name.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.name.$errors[0].$message }}
                  </div>
                </div>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-20 px10 mb-lg-10 mb-md-10">
            <div class="form-group mb-0" :class="{ 'form-group--error': v$.email.$errors.length, 'cursor-not-allowed': ba_item.predefine_business_associates_id !== null }">
                <input :disabled="(ba_item.predefine_business_associates_id == null ? false: true)" class="form-input location-input-box" :class="{ 'form-error': v$.email.$errors.length }" type="text" name="email" v-model.trim="v$.email.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.email.$model }">Email</label>
                <div v-if="v$.email.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.email.$errors[0].$message }}
                  </div>
                </div>
            </div>
          </div>
          <div class="col-12 col-md-6 col-lg-4 col-xl-2 px10  mb-lg-10 mb-md-10">
            <div class="form-group mb-0" :class="{ 'form-group--error': v$.phone_number.$error, 'cursor-not-allowed': ba_item.predefine_business_associates_id !== null }">
                <input :disabled="(ba_item.predefine_business_associates_id == null ? false: true)" v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent class="form-input location-input-box" :class="{ 'form-error': v$.phone_number.$error }" type="text" name="phone_number" v-model.trim="v$.phone_number.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.phone_number.$model }">Phone Number</label>
                <div v-if="v$.phone_number.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.phone_number.$errors[0].$message }}
                  </div>
                </div>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-lg-4 col-xl-2 px10  mb-lg-10 mb-md-10">
            <div class="form-group mb-0" :class="{ 'form-group--error': v$.date_expired.$error, 'cursor-not-allowed': ba_item.predefine_business_associates_id !== null }">
                <datepicker :disabled="(ba_item.predefine_business_associates_id == null ? false: true)" v-model:value="date_expired" :disabled-date="disabledExpireDates"
                  format="MM/DD/YYYY" valueType="YYYY-MM-DD" titleFormat="MM-DD-YYYY" :class="{ 'form-error': v$.date_expired.$error }"
                  :editable="false" @focus="is_expired_datepicker_focus = true" @blur="is_expired_datepicker_focus = false" class="datepicker-input">
                  <template v-slot:footer="{ emit }">
                    <div class="col-12 col-md-12 col-lg-12 col-xl-12 text-center px10">
                      <div class="checkbox pb10 mt9">
                        <input v-model.trim="is_no_expiration_applicable" id="add_is_no_expiration_applicable" name="add_is_no_expiration_applicable" type="checkbox" @click="no_expiration_date">
                        <label for="add_is_no_expiration_applicable"  class="checkbox-label font-14 font-light gray_checkmark--text">No Expiration</label>
                      </div>
                    </div>
                  </template>
                </datepicker>
                <label class="label" :class="{ 'label-float': (date_expired || is_expired_datepicker_focus) }">{{is_no_expiration_applicable == true?'No Expiration':'Expiration Date'}}</label>
                <div v-if="v$.date_expired.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.date_expired.$errors[0].$message }}
                  </div>
                </div>
            </div>
          </div>
          <div v-if="all_location_list.length > 1" class="col-12 col-md-4 col-lg-3 col-xl-3 col-20 px10">
            <div class="form-group" :class="{ 'form-group--error': v$.selected_work_locations.$error }">
              <multiselect
                class="select-all-dropdown"
                v-model="selected_work_locations"
                tag-placeholder=""
                placeholder=""
                label="location_nickname"
                track-by="id"
                :options="local_all_location_list"
                group-values="group_option_list"
                group-label="select_all"
                :group-select="true"
                :multiple= "true"
                :close-on-select="false"
                :showLabels="false"
                :taggable="false">
                  <template #noResult>
                    <div class="multiselect__noResult text-center">
                        No results found
                    </div>
                  </template>
                  <template #noOptions>
                    <div class="multiselect__noOptions text-center">
                        No data available
                    </div>
                  </template>
                  <template #selection>
                    <div class="multiselect__tags-wrap" v-if="selected_work_locations.length > 1">
                        <span class="multiselect__tag">
                        <span>{{ selected_work_locations.length }} Location(s) Assigned</span>
                        </span>
                    </div>
                  </template>
                </multiselect>
                <label class="label label-select" :class="{ 'label-float': (selected_work_locations.length > 0) }">Assigned Location(s)</label>
                <div v-if="v$.selected_work_locations.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.selected_work_locations.$errors[0].$message }}
                  </div>
                </div>
            </div>
          </div>
          <div class="col-12 px10" :class="{ 'col-md-6 col-lg-4 col-xl-3': all_location_list.length == 1 }">
            <div class="flex items-center justify-center justify-start-small-medium">
                <button :disabled="disable_edit_ba_submit_btn" type="submit" class="btn-primary mx4">
                    <span>Submit</span>
                </button>
                <button :disabled="disable_edit_ba_submit_btn" type="button" class="btn-cancel-outline mx4 btn-cancel-mobile" @click="cancelEditBA">
                    <span>Cancel</span>
                </button>
            </div>
          </div>
        </div>
      </form>
    </div>
    </transition>
    <delete-business-associates-modal
    v-if="is_delete_ba_modal_shown"
    :ba_id="delete_ba_modal_ba_id"
    :business_associates_agreement="ba_item.business_associates_agreement"
    @close-model="deleteBAToggle"
    @delete-ba="deleteBASubmit"
    ></delete-business-associates-modal>
    <send-agreement-modal
    v-if="is_sendagreementmodal_shown"
    @close-model="sendAgreementToggle"
    @open-select-employee-for-agreement="selectEmployeeForAgreementToggle"
    @upload-file-url-for-agreement="uploadFileUrlForAgreementToggle"
    :send_agreement_ba_data="ba_item.business_associates_agreement"
    @send-reminder-toggle="sendAgreementReminderToggle"
    ></send-agreement-modal>
    <complete-agreement-modal
    v-if="is_complete_agreement_modal_shown"
    :send_agreement_ba_data="ba_item"
    :disable_agreement_submit_btn="disable_agreement_submit_btn"
    @close-model="completeAgreementToggle"
    @opne-url-modal="opneUrlModal" />
    <select-employee-for-agreement-modal 
    v-if="is_select_employee_for_agreement_modal_shown"
    :all_location_list="all_location_list"
    :send_agreement_ba_data="ba_item.business_associates_agreement"
    :disable_agreement_submit_btn="disable_agreement_submit_btn"
    :ba_data="ba_item"
    @close-model="selectEmployeeForAgreementToggle"
    @send-agreement-email="sendAgreementEmail"
    @send-reminder-toggle="sendAgreementReminderToggle"
    />
    <select-location-for-agreement-modal 
    v-if="is_select_location_for_agreement_modal"
    :all_location_list="all_location_list"
    :ba_data="ba_item"
    :disable_agreement_submit_btn="disable_agreement_submit_btn"
    @close-model="selectLocationForAgreementToggle"
    @complete-agreement="completeAgreementForPredefinedBa"
    />
    <upload-file-for-agreement-modal 
    v-if="is_upload_file_for_agreement_modal_shown"
    :ba_id="ba_item.id"
    :modal_type="agreement_modal_type"
    @load-ba-list="loadBAList"
    @close-model="uploadFileUrlForAgreementToggle"
    @complete-agreement="completeAgreement"/>
    <business-associate-edit-alert-modal 
    v-if="is_ba_edit_alert_modal_shown"
    @close-model="editAlertToggle"  
    />
    <open-website-url-modal 
    v-if="is_open_website_url_modal_show"
    :website_url="website_url"
    @close-model="is_open_website_url_modal_show = false"  
    />
    <past-date-modal v-if="is_ba_past_date_show" @close-model="resetPastDate" @select-past-date="pastDateModalClose"/>
    <send-agreement-reminder-modal 
      v-if="is_show_agreement_remind_modal"
      :send_agreement_ba_data="ba_item"
      :disable_agreement_remind_btn="disable_agreement_remind_btn"
      @close-model="sendAgreementReminderToggleClosed"
      @send-reminder-email="sendAgreementReminderEmail"
    />    
  </div>
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from 'lodash';
import iIcon from "../common/icons/iIcon.vue"
import { useVuelidate } from '@vuelidate/core';
import { required, email, minLength, maxLength, requiredIf, helpers } from "@vuelidate/validators";
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
import deleteBusinessAssociatesModal from "./deleteBusinessAssociatesModal.vue";
import sendAgreementModal from "./sendAgreementModal.vue";
import completeAgreementModal from "./completeAgreementModal.vue";
import selectLocationForAgreementModal from "./selectLocationForAgreementModal.vue";
import businessAssociateEditAlertModal from "./businessAssociateEditAlertModal.vue";
import selectEmployeeForAgreementModal from "./selectEmployeeForAgreementModal.vue";
import uploadFileForAgreementModal from "./uploadFileForAgreementModal.vue";
import pastDateModal from "./businessAssociatePastDateModal.vue";
import openWebsiteUrlModal from "./openWebsiteUrlModal.vue";
import pendingfileIcon from "../common/icons/pendingfileIcon.vue"
import completeIcon from "../common/icons/completeIcon.vue"
import sendIcon from "../common/icons/sendIcon.vue"
import {checkSpecialChars, checkSpecialCharsErrorMessage}  from "../common/customValidation";
import moment from 'moment';
import pdfIcon from "../common/icons/pdfIcon.vue"
import sendAgreementReminderModal from "./sendAgreementReminderModal.vue";
import mitt from 'mitt'
const emitter = mitt()

export default {
  data() {
    var today = new Date();
    var year = today.getFullYear();
    var month = String(today.getMonth() + 1).padStart(2, '0');
    var day = String(today.getDate()).padStart(2, '0');
    return {
      ba_id: "",
      name: "",
      email: "",
      phone_number: "",
      date_expired:"",
      is_no_expiration_applicable:false,
      agreement_btn_class:'',
      is_ba_editing: false,
      disabledExpireDates:(date) => date <= new Date(1),
      is_expired_datepicker_focus: false,
      disable_edit_ba_submit_btn: false,
      check_ba_available_timer: null,
      is_delete_ba_modal_shown: false,
      delete_ba_modal_ba_id: "",
      is_sendagreementmodal_shown: false,
      is_select_employee_for_agreement_modal_shown:false,
      is_upload_file_for_agreement_modal_shown:false,
      is_complete_agreement_modal_shown:false,
      is_select_location_for_agreement_modal:false,
      is_ba_edit_alert_modal_shown:false,
      disable_agreement_submit_btn: false,
      agreement_modal_type:null,
      website_url:null,
      is_open_website_url_modal_show:false,
      is_ba_past_date_show:false,
      JS_APP_URL: JS_APP_URL,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
      is_show_agreement_remind_modal: false,
      disable_agreement_remind_btn: false,
      selected_work_locations: [],
      local_all_location_list : [{
        'select_all': 'Select All',
        'group_option_list': this.all_location_list,
      }],  
      compare_today_date: `${year}-${month}-${day}`,  
    };
  },
  setup: () => ({ v$: useVuelidate() }),
  emits: ["close_other_ba_edit", "updated-ba", "deleted-ba", "load-ba-list"],
  validations() {
    return {
      name:{
          required: helpers.withMessage("Please enter a vendor name", required),
          checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
          maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
      },
      email:{
          required: helpers.withMessage("Please enter an email", required),
          email: helpers.withMessage("Please enter a valid email", email),
          maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
          isUnique: helpers.withMessage('Email address already in use', helpers.withAsync(async (value) => {
            if (!value) return true;
            if (!this.v$.email.required || !this.v$.email.email) return true;
            this.disable_editvendor_submit_btn = true;
            let check_promise = new Promise((resolve, reject) => {
              if (this.check_ba_available_timer) {
                clearTimeout(this.check_ba_available_timer)
                this.check_ba_available_timer = null
              }
              this.check_ba_available_timer = setTimeout(() => {
                return fetch(JS_APP_URL + `/business-associates/check-unique-email-business-associates/${value}/`+this.ba_id)
                  .then(response => {
                    if (response.ok) {
                      resolve(response.text())
                    } else {
                      resolve(new Error('error'))
                    }
                  },  (error) => {
                    resolve(new Error('error'))
                  })
              }, 500);
            });
            var response = await check_promise;
            this.disable_editvendor_submit_btn = false;
            return Boolean((response == 'available') ? false : true);
        }))
      },
      phone_number:{
          minLength: helpers.withMessage("Please enter a valid phone number", minLength(12)),
          maxLength: helpers.withMessage("Please enter a valid phone number", maxLength(12)),
      },
      date_expired:{
        required: helpers.withMessage("Please select expiration date", requiredIf(() => {
          return (this.is_no_expiration_applicable == false)
        }))
      },
      selected_work_locations: {
        requiredIf: helpers.withMessage("Please select assigned location(s)",
        requiredIf(() => {
        return this.all_location_list.length > 1
        })),
      },
    };
  },
  props: {
      ba_item:{
        type: Object,
        default: () => {}
      },
      all_location_list: {
        type: Array,
        default: () => [],
      },
  },
  watch:{
    name(newVal, oldVal) {
      if(newVal != this.ba_item.name && this.is_ba_editing == true && this.agreementStatus == 'complete') {
        this.name = this.ba_item.name;
        this.editAlertToggle();
      }
    },
    email(newVal, oldVal) {
      if(newVal != this.ba_item.email && this.is_ba_editing == true && this.agreementStatus == 'complete') {
        this.email = this.ba_item.email;
        this.editAlertToggle();
      }
    },
    phone_number(newVal, oldVal) {
      if(newVal !=  this.ba_item.phone_number && this.is_ba_editing == true && this.agreementStatus == 'complete') {
        this.phone_number =  this.ba_item.phone_number;
        this.editAlertToggle();
      }
    },
    date_expired(val){
      if(val != null && this.is_ba_editing){
        var modify_date = new Date(val);
        var today_date = new Date();
        today_date.setDate(today_date.getDate()-1);
        if(modify_date < today_date) {
          this.is_ba_past_date_show = true;
        }
      }
    },
  },
  computed:{
    agreementStatus(){
      if(this.ba_item.predefine_business_associates_id == null){
        if(!this.ba_item.business_associates_agreement || Object.keys(this.ba_item.business_associates_agreement).length === 0){
          this.agreement_btn_class = 'send-action-btn'
          return 'send';
        }
        if(this.ba_item.business_associates_agreement && Object.keys(this.ba_item.business_associates_agreement).length > 0 && this.ba_item.business_associates_agreement.signature === null && this.ba_item.business_associates_agreement.agreement_link === null  && this.ba_item.business_associates_agreement.file_name === null ){
          this.agreement_btn_class = 'pending-action-btn' 
          return 'pending';
        }
        if(this.ba_item.business_associates_agreement && Object.keys(this.ba_item.business_associates_agreement).length > 0 && (this.ba_item.business_associates_agreement.signature !== null || this.ba_item.business_associates_agreement.agreement_link !== null  || this.ba_item.business_associates_agreement.file_name !== null)){
          this.agreement_btn_class = 'complete-action-btn' 
           return 'complete';
        }
      }else{
        if(this.ba_item.predefine_business_associative.agreement_type == "predefined_dynamic_doc" && this.ba_item.business_associates_agreement.file_name == null){
          this.agreement_btn_class = 'pending-action-btn' 
          return 'pending-pre-ba';
        }else{
          this.agreement_btn_class = 'complete-action-btn' 
          return 'complete';
        }
      }
    },

  },
  components: {
    clearDropdownIcon,
    deleteBusinessAssociatesModal,
    selectEmployeeForAgreementModal,
    uploadFileForAgreementModal,
    sendAgreementModal,
    completeAgreementModal,
    selectLocationForAgreementModal,
    businessAssociateEditAlertModal,
    openWebsiteUrlModal,
    pendingfileIcon,
    sendIcon,
    completeIcon,
    iIcon,
    pastDateModal,
    pdfIcon,
    sendAgreementReminderModal,    
  },
  mounted() {
    emitter.on('close_other_ba_edit', (ba_id) => {
        if(ba_id !== this.ba_item.id){
            this.is_ba_editing = false;
        }
    });
  },
  methods:{
    formatDate(value){
      return moment.utc(String(value)).local().format('MM/DD/YYYY');
    },
    editBA(){
        this.ba_id = this.ba_item.id;
        this.name = this.ba_item.name;
        this.email = this.ba_item.email;
        this.phone_number = this.ba_item.phone_number;
        if(this.ba_item.expired_date == null){
            this.is_no_expiration_applicable = true;
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            this.disabledExpireDates = (date) => date <= today || date > today
            this.date_expired = "";
        }else{
            this.date_expired = this.ba_item.expired_date;
        }
        this.selected_work_locations = [];
        _.forEach(this.ba_item.business_associates_location, (value) => {
          var is_found_location = _.find(this.all_location_list, (o) => { return o.id === value.location.id; });
          if(!_.isUndefined(is_found_location)){
            this.selected_work_locations.push(is_found_location);
          }
        });
        setTimeout(() => {
            this.is_ba_editing = true;
            emitter.emit('close_other_ba_edit', this.ba_id);
        }, 100);
    },
    no_expiration_date(){
      this.is_no_expiration_applicable = !this.is_no_expiration_applicable;
      if(this.is_no_expiration_applicable == true){
        this.date_expired = "";
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        this.disabledExpireDates = (date) => date <= today || date > today
      } else {
        this.date_expired = ""
        this.disabledExpireDates = (date) => date <= new Date(1)
      }
    },
    async editBASubmit(){
      if(this.is_ba_edit_alert_modal_shown == false){
        this.v$.$touch();
        const is_valid = await !this.v$.$invalid;
        if (is_valid) {
          var location_work_new = new Array();
          var location_work_removed = new Array();
          if(this.all_location_list.length > 1){
            _.forEach(this.selected_work_locations, (value) => {
              if(_.isUndefined( _.find(this.ba_item.business_associates_location, (o) => { return o.location.id == value.id; }))){
                location_work_new.push({"location_id": value.id});
              }
            });
            _.forEach(this.ba_item.business_associates_location, (value) => {
              if(_.isUndefined( _.find(this.selected_work_locations, (o) => { return o.id == value.location.id; }))){
                location_work_removed.push({"location_id": value.location.id});
              }
            });
          }
          NProgress.start();
          this.disable_edit_ba_submit_btn = true;
          axios
          .post(JS_APP_URL + "/business-associates/edit-business-associates", {
              business_associative_id: this.ba_id,
              name: this.name,
              email: this.email,
              phone_number: this.phone_number,
              expired_date: this.date_expired,
              is_no_expiration_applicable: this.is_no_expiration_applicable,
              location_work_new: location_work_new,
              location_work_removed: location_work_removed
          })
          .then((response) => {
              if (response["data"]["status"] == "Error") {
                  if(response["data"]['data'].length > 0){
                      toastr.error(response["data"]['data'].join('</br>'), "Error");
                  }else{
                      toastr.error(response["data"]["message"], "Error");
                  }
              } else {
                  toastr.success(response["data"]["message"], "Success");
                  setTimeout(() => {
                      this.is_ba_editing = false;
                      this.$emit("updated-ba", response["data"]['data']);
                  }, 100);
              }
          })
          .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                  window.location = JS_APP_URL + "/login";
              }
          })
          .then(() => {
              NProgress.done();
              this.disable_edit_ba_submit_btn = false;
          });
        } 
      }
    },
    deleteBAToggle(status = true){
      this.delete_ba_modal_ba_id = this.ba_item.id;
      this.is_delete_ba_modal_shown = status;
      setTimeout(() => {
          emitter.emit('close_other_ba_edit', this.ba_item.id);
      }, 100);
    },
    deleteBASubmit(){
      if(this.delete_ba_modal_ba_id){
          NProgress.start();
          axios
          .post(JS_APP_URL + "/business-associates/delete-business-associates", {
              business_associative_id: this.delete_ba_modal_ba_id
          })
          .then((response) => {
              if (response["data"]["status"] == "Error") {
                  if(response["data"]['data'].length > 0){
                      toastr.error(response["data"]['data'].join('</br>'), "Error");
                  }else{
                      toastr.error(response["data"]["message"], "Error");
                  }
              } else {
                  toastr.success(response["data"]["message"], "Success");
                  setTimeout(() => {                        
                      this.$emit("deleted-ba", this.delete_ba_modal_ba_id);
                  }, 100);
              }
          })
          .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                  window.location = JS_APP_URL + "/login";
              }
          })
          .then(() => {
              NProgress.done();
              this.is_delete_ba_modal_shown = false;
          });
      }
    },
    sendAgreementToggle(status = true){
      if(!this.ba_item.email) {
        toastr.error('Please enter business associate email address', 'Error!');
      } else {
        this.is_sendagreementmodal_shown = status
      }
    },
    completeAgreementToggle(status = true){
      this.is_complete_agreement_modal_shown = status;
    },
    selectLocationForAgreementToggle(status = true){
      if(status == true){
        this.is_select_location_for_agreement_modal = true;
      }else{
        this.is_select_location_for_agreement_modal = false;
      }
    },
    uploadFileUrlForAgreementToggle(status = true,agreement_type = null){
      this.is_sendagreementmodal_shown = false;
      this.agreement_modal_type = agreement_type
      this.is_upload_file_for_agreement_modal_shown = status
    },
    selectEmployeeForAgreementToggle(status = true){
      this.is_sendagreementmodal_shown = false;
      if(status == true){
        this.is_select_employee_for_agreement_modal_shown = true;
      }else{
        this.is_select_employee_for_agreement_modal_shown = false;
      }
    },
    sendAgreementEmail(officer_name,officer_title,location_id){
      NProgress.start();
      this.disable_agreement_submit_btn = true;
      axios
      .post(JS_APP_URL + "/business-associates/send-agreement-email", {
          business_associative_id: this.ba_item.id,
          officer_name: officer_name,
          officer_title :officer_title,
          location_id:location_id
      })
      .then((response) => {
          if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
          } else {
              toastr.success(response["data"]["message"], "Success");
              this.$emit("load-ba-list", true);
              this.selectEmployeeForAgreementToggle(false);
          }
      })
      .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
          }
      })
      .then(() => {
          NProgress.done();
          this.disable_agreement_submit_btn = false;
      });
    },
    completeAgreement(){
      NProgress.start();
      this.disable_agreement_submit_btn = true;
      axios
      .post(JS_APP_URL + "/business-associates/send-agreement-email", {
          business_associative_id: this.ba_item.id,
          officer_name: officer_name,
          officer_title :officer_title,
      })
      .then((response) =>{
          if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
          } else {
              toastr.success(response["data"]["message"], "Success");
              this.$emit("load-ba-list", true);
              this.selectEmployeeForAgreementToggle(false);
          }
      })
      .catch((error) =>{
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
          }
      })
      .then(() => {
          NProgress.done();
          this.disable_agreement_submit_btn = false;
      });
    },
    cancelEditBA(){
      this.is_ba_editing = false;
    },
    loadBAList() {
      this.$emit("load-ba-list", true);
    },
    editAlertToggle(status = true) {
      if(status == false){
        this.is_ba_editing = false
      }
      this.is_ba_edit_alert_modal_shown = status;
    },
    opneUrlModal(website_url){
      this.website_url = website_url;
      this.is_complete_agreement_modal_shown = false
      setTimeout(() => {
        this.is_open_website_url_modal_show = true
      }, 100);
    },
    resetPastDate(){
      this.date_expired = '';
      this.is_ba_past_date_show = false
    },
    pastDateModalClose(){
      this.is_ba_past_date_show = false
    },
    completeAgreementForPredefinedBa(location_id){
      NProgress.start();
      this.disable_agreement_submit_btn = true;
      axios
      .post(JS_APP_URL + "/business-associates/complete-agreement-for-predefined-ba", {
          business_associates_id: this.ba_item.id,
          location_id:location_id
      })
      .then((response) => {
          if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
          } else {
              toastr.success(response["data"]["message"], "Success");
              this.$emit("load-ba-list", true);
              this.selectLocationForAgreementToggle(false);
          }
      })
      .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
          }
      })
      .then(() => {
          NProgress.done();
          this.disable_agreement_submit_btn = false;
      });
    },
    downloadAgreementWithoutSignature(business_associate_id) {
      NProgress.start();
      axios
          .get(JS_APP_URL + "/business-associates/download-agreement-without-signature?business_associate_id=" + business_associate_id)
          .then((response) => {
              if (response["data"]["status"] == "Success") {
                  var link = document.createElement("a");
                  link.setAttribute("href", response["data"]['data']['download_url']);
                  link.setAttribute("download", response["data"]['data']['file_name']);
                  link.setAttribute("target", '_blank');
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
              }
          })
          .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                  window.location = JS_APP_URL + "/login";
              }
          })
          .then(() => {
              setTimeout(() => {
                  NProgress.done();
              }, 100);
          });
    },
    sendAgreementReminderToggleClosed()
    {
      this.is_sendagreementmodal_shown = false;
      this.is_select_employee_for_agreement_modal_shown = false;
      this.is_show_agreement_remind_modal = false;
    },
    sendAgreementReminderToggle() {      
      NProgress.start();        
      axios.post(JS_APP_URL + "/business-associates/check-location-unassigned", {
        ba_id: this.ba_item.id,
      })
      .then((response) => {
        if (response["data"]["status"] == "Error") {            
            toastr.error(response["data"]["message"], "Error");            
        } else {
          this.is_sendagreementmodal_shown = false;
          this.is_select_employee_for_agreement_modal_shown = false;
          if(this.is_show_agreement_remind_modal == true) {
            this.is_show_agreement_remind_modal = false;
          } else {
            this.is_show_agreement_remind_modal = true;
          }
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";
        }
      })
      .then(() => { 
        NProgress.done();
        //this.disable_agreement_remind_btn = false;
      });      
    },    
    sendAgreementReminderEmail() {
      NProgress.start();
      this.disable_agreement_remind_btn = true;
      axios.post(JS_APP_URL + "/business-associates/send-reminder-email", {
        business_associative_id: this.ba_item.id,
      })
      .then((response) => {
        if (response["data"]["status"] == "Error") {
          if(response["data"]['data'].length > 0){
            toastr.error(response["data"]['data'].join('</br>'), "Error");
          }else{
            toastr.error(response["data"]["message"], "Error");
          }
        } else {
          toastr.success(response["data"]["message"], "Success");
          this.$emit("load-ba-list", true);
          this.selectEmployeeForAgreementToggle(false);
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";
        }
      })
      .then(() => { 
        NProgress.done();
        this.disable_agreement_remind_btn = false;
      });
    }
  },
  created() {
   document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.is_ba_editing = false;
      }
    });
  }
};
 </script>
