<template>
    <div>
        <Teleport to="body">
            <transition name="modal">
                <div class="modal-mask modal-scrollable">
                    <div class="modal-wrapper animate__animated animate__zoomIn">
                        <div class="modal-container">
                            <button @click="closeModal" class="cursor-pointer modal-close">
                                <close-icon></close-icon>
                            </button>
                            <div class="text-center mlr-auto mb20 pt20">
                                <img :src="JS_APP_URL +'/images/warning.svg'" class="warning-icon-modal" alt="" title="">
                            </div>
                            <button v-on:click="closeModal" class="cursor-pointer modal-close">
                                <close-icon></close-icon>
                            </button>            
                            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb10">
                                Uh Oh!
                            </h2>
                
                            <p class="text-center font-16 text-999 line-normal mb30">
                                You are trying to change details of a completed Business Associate Agreement. If you would like to make changes, first delete the completed Agreement so that it saves in your Abyde Drive - Archive and then create a new Agreement with the changes.
                            </p>
                            
                            <div class="flex flex-wrap items-center justify-center pb40">
                                <button class="btn-primary px30 mx5" @click="closeModal">GOT IT</button>
                            </div>
                        </div>
                    </div>
                </div>
            </transition>
        </Teleport>
        <div class="modal-backdrop"></div>
    </div>
</template>

<script scoped>
import closeIcon from '../common/icons/closeIcon.vue';

export default {
    emits: ["close-model"],
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
        }
    },
    components:{closeIcon},
    methods: {
        closeModal () {
            this.$emit("close-model", false);
        },
    },
    created () {
        // document.body.classList.add('modal-open');
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
              this.$emit("close-model", false);
            }
        });
    },
    destroyed(){
        // document.body.classList.remove('modal-open');
    }
}
</script>