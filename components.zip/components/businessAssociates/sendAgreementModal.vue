<template>
  <div>
    <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container">
            <button v-on:click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb20">
              Complete Business Associate Agreement 
            </h2>
            <p class="text-center font-16 text-999 line-normal mb30" >
              To complete the Business Associate Agreement, choose from the options below based on your practice's preference.
            </p>
            <div class="row flex-auto -mx-10 mb40" >
              <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10 mb-lg-10 mb-md-10 text-center" >
                <img :src="JS_APP_URL +'/images/envelop-upload.svg'" class="warning-icon-modal mb5 cursor-pointer" alt="" title="" @click="selectEmployeeForAgreementToggle">
                <h4 class="font-16 font_semibold blueog--text cursor-pointer" @click="selectEmployeeForAgreementToggle" >Email Abyde’s<br/> preferred BAA<br/> to vendor</h4>             
              </div>
              <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10 mb-lg-10 mb-md-10 text-center" >
                <img :src="JS_APP_URL +'/images/add-doc.svg'" class="warning-icon-modal mb5 cursor-pointer" alt="" title="" @click="uploadFileModalToggle('file')">
                <h4 class="font-16 font_semibold blueog--text cursor-pointer" @click="uploadFileModalToggle('file')">Upload existing or<br/> printed and signed<br/> BAA</h4>          
              </div>
              <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10 mb-lg-10 mb-md-10 text-center">
                <img :src="JS_APP_URL +'/images/link-icon.png'" class="warning-icon-modal mb20 cursor-pointer" alt="" title="" width="70" height="64" @click="uploadFileModalToggle('url')">
                <h4 class="font-16 font_semibold blueog--text cursor-pointer" @click="uploadFileModalToggle('url')">Link to BAA on vendor<br/> website</h4>             
              </div>                        
            </div> 
             <div class="flex flex-wrap items-center justify-center pb40">               
              <button 
                v-if="send_agreement_ba_data && Object.keys(send_agreement_ba_data).length > 0 && send_agreement_ba_data.signature === null && send_agreement_ba_data.agreement_link === null  && send_agreement_ba_data.file_name === null"
                type="submit"
                class="btn-primary btn-primary-outline mx5"                
                @click="sendReminderTogglel"
              >              
                <span>SEND REMINDER</span>
              </button>
            </div>   
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
  <div class="modal-backdrop"></div>
  </div>
</template>

<script scoped>
import closeIcon from '../common/icons/closeIcon.vue';
import pdfIcon from '../common/icons/pdfIcon.vue';
export default {
  components:{closeIcon,pdfIcon},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
    };
  },
  emits: ["close-model", 'open-select-employee-for-agreement', 'upload-file-url-for-agreement','send-reminder-toggle'],
  props: {
    send_agreement_ba_data: {
      type: Object,
      default: () => {}
    },    
  },
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
    selectEmployeeForAgreementToggle(){
      this.$emit('open-select-employee-for-agreement',true);
    },
    uploadFileModalToggle(type){
      this.$emit('upload-file-url-for-agreement',true,type);
    },
    sendReminderTogglel(){
      this.$emit("send-reminder-toggle");
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
