<template>
  <Teleport to="body">
    <transition name="modal">
      <div>
        <div class="modal-mask modal-scrollable">
          <div class="modal-wrapper animate__animated animate__zoomIn open-web-modal test">
            <div class="modal-container">
              <button @click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
              </button>
              <p class="font-16 text-999 mb12 mt-sm-10"> If page not display properly, 
                <a :href="website_url" target="_blank" class="blueog--text">click here</a> to visit website 
              </p>
              <iframe class="pdf-viewer" :src="website_url" width="100%" height="600"></iframe>
            </div>
          </div>
        </div>
        <div class="modal-backdrop"></div>
      </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from '../common/icons/closeIcon.vue';

export default {
  props: {
    website_url:{
      type: String,
       default: () => null
    }
  },
  emits: ["close-model"],
  components:{closeIcon},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
    };
  },
  methods: {
    closeModal () {
      this.$emit("close-model", false);
    },
  },
  created () {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", false);
      }
    });
    setTimeout(() => {
      // document.body.classList.add('modal-open');
    }, 200);
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
