<template>
  <div>
    <header-after-login></header-after-login>
      <div class="container pt40 pb60">
      <h1 class="
          location-dashbaord-title
          text-center
          font-28 font_semibold
          blueog--text
          line-normal mb25
        ">
        Let Us Upgrade You!
      </h1> 
      <p class="text-center font-16 font_normal black--text mb40">Your current account data is shown below. Enter a new number of locations to view your new pricing.</p>       
      <div class="upgrade-inputs flex justify-center">
        <div class="form-group upgrade-input-item" :class="{ 'form-group--error': v$.user_current_location_limit.$errors.length }">
            <input v-mask="'000'" @click.right.prevent @copy.prevent @paste.prevent class="form-input" :class="{ 'form-error': v$.user_current_location_limit.$errors.length }" type="text" id="user_current_location_limit" name="user_current_location_limit" v-model.trim="v$.user_current_location_limit.$model">
            <label class="label font_light" :class="{ 'label-float': v$.user_current_location_limit.$model }">Total Locations</label>
            <div v-if="v$.user_current_location_limit.$errors.length > 0">
              <div class="form-error-text">
                {{ v$.user_current_location_limit.$errors[0].$message }}
              </div>
            </div>
        </div>      
      </div>
      <div class="text-center">
        <div class="font-28 font_semibold blue--text mb22">Upgrade Amount</div>
        <div class="flex items-center justify-center">
          <div class="upgrade-amount-block flex items-center justify-center flex-col light mb12 mlr-auto">
              <div class="upgrade-price font-60 blue--text font_semibold line-normal">{{numberFormatter().format(charge_price)}}</div>
              <div class="font-14 black--text font_light font-italic mt10" v-if="Object.keys(promocode_data).length > 0 && promocode_data.discount_type == 'percentage'">Includes {{promocode_data.discount_percentage}}% discount</div>
              <div class="font-14 black--text font_light font-italic mt10" v-if="Object.keys(promocode_data).length > 0 && promocode_data.discount_type == 'fixed_amount'">Includes ${{promocode_data.discount_amount / 100}} discount</div>
          </div>
        </div>
        <div class="font-16 blue--text font_semibold mb30" v-if="sales_tax.length > 0">
          Above price is inclusive of below Sales Tax (State & Local):
          <p class="font-14 black--text font_light font-italic mt5" v-for="(st, index) in sales_tax" :key="index">                        
           {{st.percentage}}
          </p>
        </div>
        
        <p class="font-16 black--text mb40 mt40" >
          Note: Upgrade amount is pro-rated based on renewal date and will be charged<br class="hidden-sm hidden-md"/> immediately. Renewal pricing will include the full upgrade amount for the next {{(plan_type=="biannually"?"bi-annual": plan_type.slice(0, -2))}}. 
        </p>

        <button type="button" class="btn-primary btn-upgrade mlr-auto h-32 mt40" :disabled="is_upgrade_btn_disabled" @click="upgradeConfirmToggle"><span>Upgrade now!</span></button>

      </div>
      </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    <upgrade-confirm-modal
        v-if="is_upgradeconfirmmodal_shown"
        @close-model="upgradeConfirmToggle"
        @do-upgrade="doUpgrade"
    ></upgrade-confirm-modal>
    <upgrade-offline-modal
        v-if="is_upgradeofflinemodal_shown"
    ></upgrade-offline-modal>
  </div>
</template>

<script>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from 'lodash';
import { useVuelidate } from '@vuelidate/core';
import { required, numeric, helpers } from "@vuelidate/validators";
import fullPageLoader from "../common/fullPageLoader.vue";
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import upgradeConfirmModal from "./upgradeConfirmModal.vue";
import upgradeOfflineModal from "./upgradeOfflineModal.vue";

export default {
  data() {
    return {
      JS_SUPPORT_EMAIL : SUPPORT_EMAIL,
      JS_APP_URL: JS_APP_URL,
      is_full_page_loader_shown: false,
      location_max_limit:'',
      user_current_location_limit:'',
      user_current_location_limit_old:'',
      is_upgrade_btn_disabled: true,
      charge_price: 0,
      plan_type: '',
      sales_tax: [],
      promocode_data: {},
      is_upgradeconfirmmodal_shown:false,
      is_upgradeofflinemodal_shown:false,
      subscription_status: '',
      next_billing_at: ''
    };
  },
  components: {
    fullPageLoader,
    headerAfterLogin,
    upgradeConfirmModal,
    upgradeOfflineModal
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      user_current_location_limit:{
        required: helpers.withMessage("Please enter a new location limit", required),
        numeric: helpers.withMessage("Please enter a valid location limit", numeric)
      },
    };
    return validationArray;
  },
  mounted() {
    this.loadUserCurrentPlanInformation();
  },
  watch: {
      user_current_location_limit: _.debounce(function(newVal, oldVal){
          if(newVal == ''){
            this.charge_price = 0;
            this.is_upgrade_btn_disabled = true;
          }
          else if(newVal != oldVal )
          {
              this.on_location_limit_change()
          }
      }, 1000)
  },
  methods: {
    numberFormatter(){
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
      });
    },
    loadUserCurrentPlanInformation(){
      this.is_full_page_loader_shown = true;
      axios
      .get(JS_APP_URL + "/sra-only-upgrade/get-location-information")
      .then((response) => {
        this.user_current_location_limit = response["data"]["data"]["user_current_location_limit"];
        this.user_current_location_limit_old = response["data"]["data"]["user_current_location_limit"];
        this.location_max_limit = response["data"]["data"]["location_max_limit"];
        this.plan_type = response["data"]["data"]["chargebee_subscription"]["plan_type"];
        if(response["data"]["data"]["has_scheduled_changes"] == 'true' || response["data"]["data"]["subscription_status"] == 'cancelled'){
          this.is_upgradeofflinemodal_shown = true;
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";
        }
      })
      .then(() => {
        setTimeout(() => {
          this.is_full_page_loader_shown = false;
        }, 500);
      });
    },
    on_location_limit_change(){
      this.v$.$touch();
      if (!this.v$.$invalid) {
        if(this.user_current_location_limit > this.location_max_limit){
          toastr.success("Wow, that's a large organization! Please contact us at "+this.JS_SUPPORT_EMAIL+" so we can provide you with special pricing.", "Success");
          this.charge_price = 0;
          this.user_current_location_limit = this.user_current_location_limit_old;
          this.is_upgrade_btn_disabled = true;
          return false;
        }
        if(this.user_current_location_limit == this.user_current_location_limit_old){
          this.is_upgrade_btn_disabled = true;
          this.charge_price = 0;
          return false;
        }
        if(this.user_current_location_limit < this.user_current_location_limit_old){
          toastr.error("You can't downgrade package!", "Error");
          this.charge_price = 0;
          this.user_current_location_limit = this.user_current_location_limit_old;
          this.is_upgrade_btn_disabled = true;
          return false;
        }
        
        if(this.user_current_location_limit != this.user_current_location_limit_old){
          this.calculateprice();
        }
      }
    },
    calculateprice(){
      this.v$.$touch();
      if (!this.v$.$invalid) {
        this.is_full_page_loader_shown = true;
        NProgress.start();
        var formData = new FormData();
        formData.append("location_limit", this.user_current_location_limit);
        formData.append("plan_type", this.plan_type);
        axios
        .post(JS_APP_URL + "/sra-only-upgrade/get-chargebee-price-upgrade-estimation", formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        })
        .then((response) => {
            if (response["data"]["status"] == "Error") {
                this.is_upgrade_btn_disabled = true;
                if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                  toastr.error(response["data"]["message"], "Error");
                }
            } else {
              this.charge_price = response["data"]["data"]["total"] / 100;
              this.subscription_status = response["data"]["data"]["subscription_status"]
              this.next_billing_at = response["data"]["data"]["next_billing_at"]
              if(response["data"]['data']['taxes']){
                this.sales_tax = response["data"]['data']['taxes'];
              }else{
                this.sales_tax = [];
              }
              if(response["data"]['data']['discounts']){
                this.promocode_data = response["data"]['data']['discounts'];
              }
              this.is_upgrade_btn_disabled = false;
            }
        })
        .catch((error) => {
          this.is_upgrade_btn_disabled = true;
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
          this.is_full_page_loader_shown = false;
        })
      }
    },
    doUpgrade(){
      this.v$.$touch();
      if (!this.v$.$invalid) {
        this.is_full_page_loader_shown = true;
        this.is_upgrade_btn_disabled = true;
        NProgress.start();
        var formData = new FormData();
        formData.append("location_limit", this.user_current_location_limit);
        formData.append("location_limit_old", this.user_current_location_limit_old);
        formData.append("plan_type", this.plan_type);
        axios
        .post(JS_APP_URL + "/sra-only-upgrade/doupgrade", formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            this.is_upgrade_btn_disabled = true;
            toastr.error(response["data"]["message"], "Error");
          } else {
            toastr.success(response["data"]["message"], "Success");
            setTimeout(() => {                  
              window.location = JS_APP_URL + "/dashboard";
            }, 500);
          }
        })
        .catch((error) => {
          this.is_upgrade_btn_disabled = true;
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
          this.is_full_page_loader_shown = false;
          this.is_upgradeconfirmmodal_shown = false;
        })
      }
    },
    upgradeConfirmToggle(status = true){
      this.v$.$touch();
      if (!this.v$.$invalid) {
        this.is_upgradeconfirmmodal_shown = status;
      }
    },
  },
};
</script>