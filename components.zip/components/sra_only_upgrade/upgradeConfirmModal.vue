<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button v-if="!is_btn_disabled" v-on:click="closeModal" class="cursor-pointer modal-close px0">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb10 pt20">
              <img :src="JS_APP_URL + '/images/triangle-warning.svg'" alt="" title="" class="warning-icon-modal" />
            </div>
            <h2
              class="
                font-24 font_semibold blueog--text line-normal text-center mb40
              "
            >
              Are you sure you want to upgrade <br class="hidden-sm"/> your account?
            </h2>
            <div class="flex flex-wrap items-center justify-center pb30">
                <button :disabled="is_btn_disabled" v-on:click="closeModal" class="btn-upgrade-modal btn-cancel-outline mx5 h-32">No</button>
                <button :disabled="is_btn_disabled" v-on:click="doUpgradeConfirm" class="btn-upgrade-modal btn-primary mx5 px30 mt-xs-20 h-32">YES</button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from '../common/icons/closeIcon.vue';

export default {
  emits: ["close-model", "do-upgrade"],
  components:{closeIcon},
  data() {
    return {
      is_btn_disabled: false,
      JS_APP_URL: JS_APP_URL,
    };
  },
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
    doUpgradeConfirm() {
      this.is_btn_disabled = true;
      this.$emit("do-upgrade");
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.is_btn_disabled) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
