<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb40">
              Contact Support for Upgrade
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb30 mt30">
              Upgrading your account is easy! Just email
              <a :href="`mailto:${JS_SUPPORT_EMAIL}`" class="blueog--text">{{
                JS_SUPPORT_EMAIL
              }}</a>
              with the subject "Upgrade" and tell us how many locations and/or employees
              you'd like to add. We'll take care of the rest. In-app upgrades and
              downgrades are coming soon!
            </p>
            <div class="flex flex-wrap items-center justify-center pb30">
              <button
                v-on:click="goToDashboard"
                class="btn-upgrade-modal btn-primary mx5 px30 mt-xs-20 h-32"
              >
                ok
              </button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";
export default {
  components: { closeIcon },
  data() {
    return {
      is_btn_disabled: false,
      JS_APP_URL: JS_APP_URL,
      JS_SUPPORT_EMAIL: SUPPORT_EMAIL,
    };
  },
  methods: {
    goToDashboard() {
      window.location = JS_APP_URL + "/dashboard";
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.is_btn_disabled) {
      }
    });
  },
  destroyed() {
    // document.body.classList.remove('modal-open');
  },
};
</script>
