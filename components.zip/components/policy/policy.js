import { createApp } from "vue";
import FloatingVue from 'floating-vue'
import 'floating-vue/dist/style.css'
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import moment from 'moment'
import policy from "./policy.vue";
import VueMask from '@devindex/vue-mask';

const policy_app = createApp(policy);
policy_app.use(VueMask);
policy_app.component('multiselect', Multiselect);
policy_app.use(FloatingVue, {
    themes: {
        'red-tooltip': {
          $extend: 'tooltip',
          $resetCss: true,
        },
}});
policy_app.config.globalProperties.$filters = {
    formatDate(value) {
        if (value) {
            return moment.utc(String(value)).local().format("MM/DD/YYYY");
        }
    },
};
policy_app.mount("#policy_app");