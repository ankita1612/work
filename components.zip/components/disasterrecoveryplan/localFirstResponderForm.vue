<template>
  <div class="emergency-form-edit mb30">
    <div class="row flex flex-wrap -mx5 mb10 mb-sm-20">
      <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 px5 mb-sm-10">
        <div class="relative"
          :class="{ 'form-group--error': v$.local_emergency_contacts.local_police_department_name.$error }">
          <input class="form-input"
            :class="{ 'form-error': v$.local_emergency_contacts.local_police_department_name.$error }" type="text"
            v-model.trim="
              v$.local_emergency_contacts.local_police_department_name.$model
            " />
          <label class="label" :class="{
            'label-float':
              v$.local_emergency_contacts.local_police_department_name.$model
          }">Local Police Department Name</label>
          <div v-if="v$.local_emergency_contacts.local_police_department_name.$errors.length > 0">
            <div class="form-error-text">
                {{ v$.local_emergency_contacts.local_police_department_name.$errors[0].$message }}
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 px5 mb-sm-10">
        <div class="relative"
          :class="{ 'form-group--error': v$.local_emergency_contacts.local_police_department_phone.$error }">
          <input class="form-input"
            :class="{ 'form-error': v$.local_emergency_contacts.local_police_department_phone.$error }" type="text"
            v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent v-model.trim="
              v$.local_emergency_contacts.local_police_department_phone.$model
            " />
          <label class="label" :class="{
            'label-float':
              v$.local_emergency_contacts.local_police_department_phone.$model
          }">Phone Number</label>
          <div v-if="v$.local_emergency_contacts.local_police_department_phone.$errors.length > 0">
            <div class="form-error-text">
                {{ v$.local_emergency_contacts.local_police_department_phone.$errors[0].$message }}
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row flex flex-wrap -mx5 mb10 mb-sm-20">
      <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 px5 mb-sm-10">
        <div class="relative"
          :class="{ 'form-group--error': v$.local_emergency_contacts.local_fire_department_name.$error }">
          <input class="form-input"
            :class="{ 'form-error': v$.local_emergency_contacts.local_fire_department_name.$error }" type="text"
            id="local_emergency_contacts.local_fire_department_name"
            name="local_emergency_contacts.local_fire_department_name" v-model.trim="
              v$.local_emergency_contacts.local_fire_department_name.$model
            " />
          <label class="label" :class="{
            'label-float':
              local_emergency_contacts.local_fire_department_name
          }">Local Fire Department Name</label>
          <div v-if="v$.local_emergency_contacts.local_fire_department_name.$errors.length > 0">
            <div class="form-error-text">
                {{ v$.local_emergency_contacts.local_fire_department_name.$errors[0].$message }}
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 px5 mb-sm-10">
        <div class="relative"
          :class="{ 'form-group--error': v$.local_emergency_contacts.local_fire_department_phone.$error }">
          <input class="form-input"
            :class="{ 'form-error': v$.local_emergency_contacts.local_fire_department_phone.$error }" type="text"
            v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent v-model.trim="
              v$.local_emergency_contacts.local_fire_department_phone.$model
            " />
          <label class="label" :class="{
            'label-float':
              local_emergency_contacts.local_fire_department_phone

          }">Phone Number</label>
          <div v-if="v$.local_emergency_contacts.local_fire_department_phone.$errors.length > 0">
            <div class="form-error-text">
            {{ v$.local_emergency_contacts.local_fire_department_phone.$errors[0].$message }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import { checkSpecialChars, checkSpecialCharsErrorMessage } from "../common/customValidation";
import { useVuelidate } from '@vuelidate/core';
import { minLength, maxLength, helpers } from "@vuelidate/validators";

export default {
  props: {
    local_emergency_contacts: {
      type: Object,
    },
    location_id: {
      type: Number,
    },
  },
  setup: () => ({ v$: useVuelidate() }),
  data() {
    return {
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
    }
  },
  validations() {
    return {
      local_emergency_contacts: {
        local_fire_department_name: {
            maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        },
        local_fire_department_phone: {
            maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
            minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
        },
        local_police_department_name: {
            maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars)
        },
        local_police_department_phone: {
            maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
            minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
        },
      },
    }
  },
  methods: {
    isInvalid() {
      this.v$.$touch();
      return this.v$.$invalid;
    },
    resetForm() {
      this.v$.$reset();
    }
  }
};
</script>
