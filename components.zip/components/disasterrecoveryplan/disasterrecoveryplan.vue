<template>
  <div>
    <header-after-login></header-after-login>
    <div class="container pt40 pb60" >
      <full-page-loader v-if="is_full_page_loader_shown" />

      <div
        class="mlr-auto mb20 location-dropdon relative"
        v-if="all_locations.length > 1"
      >
        <multiselect
          class="company-location-select"
          v-model="selected_location"
          :options="all_locations"
          label="location_nickname"
          :taggable="false"
          :multiple="false"
          :close-on-select="true"
          :showLabels="false"
          track-by="id"
          placeholder=""
          :allowEmpty="false"
        >
          <template #noResult>
            <div class="multiselect__noResult text-center">
              No results found
            </div>
          </template>
        </multiselect>
        <label class="label label-select label-float">Location</label>
      </div>
      <div class="flex items-center justify-center flex-wrap">
        <h1
          class="
            location-dashbaord-title
            text-center
            font-24 font_semibold
            blueog--text
            line-normal
            mb30
            mb-md-10 mb-sm-10
          "
        >
          Disaster Recovery Plan
       </h1>
       <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml6 mb30 mb-md-10 mb-sm-10">
          <button @click="PlayExplainerVideoModalToggle('yes')" class="cursor-pointer svg-icon-height dashboard-video-icon mt4">
            <explainer-video-icon></explainer-video-icon>
          </button>
          <template #popper>
            Video Guide
          </template>
       </VTooltip>
      </div>
      <div v-if="is_data_loaded">
        <!-- Local First Responders -->
        <div class="flex flex-wrap flex-auto items-center mb30">
          <h6 class="font-18 blueog--text mb0 mr6">Local First Responders</h6>
          <VTooltip
            :triggers="['hover']"
            :popperTriggers="['hover']"
            style="height: 24px"
            class="cursor-pointer mr4"
          >
            <span><info-icon></info-icon></span>
            <template #popper>
              Input contact information for local emergency responders to be
              dynamically generated within your organization's Disaster Recovery
              Plan.
            </template>
          </VTooltip>
          <VTooltip
            :triggers="['hover']"
            :popperTriggers="['hover']"
            v-if="show_local_disaster_responder_edit_btn"
          >
            <button
              @click="toggleDisasterResponderForm"
              type="button"
              class="action-icon-btn action-btn-blueog disaster-edit-btn"
              :class="{ inactive: show_local_disaster_responder_form }"
            >
              <img :src="JS_APP_URL + '/images/pencil.svg'" alt="" title="" />
            </button>
            <template #popper> Edit </template>
          </VTooltip>
          <div class="import-btn-wrapper ml10">
            <VTooltip :triggers="['hover']" :popperTriggers="['hover']">
              <input
                ref="import_file_upload"
                type="file"
                hidden
                @change="importDisasterRecovery"
                accept=".xlsx, .xls"
              />
              <button @click="onPickImportFile" type="button" class="import-btn">
                <span><import-icon></import-icon></span><span>Import</span>
              </button>
              <template #popper>
                <i class="text-center d-block"
                  >If preferred, you may import Disaster Recovery Plan data via excel
                  file upload.<br />
                  Click here to
                  <b
                    ><a
                      class="downloadsamplelink font-300"
                      :href="sample_import_doc"
                      target="_blank"
                      >download the Template File</a
                    ></b
                  >. Click the IMPORT button to upload your contacts.</i
                >
              </template>
            </VTooltip>
          </div>
        </div>
        <div
          v-if="show_local_disaster_responder_form || disaster_responders == null"
        >
          <transition name="simple-fade-transition" mode="out-in">
            <local-first-responder-form
              :local_emergency_contacts="disaster_responders"
              :location_id="selected_location_id"
              ref="emergencyContacts"
            />
          </transition>
        </div>
        <div v-else>
          <transition name="simple-fade-transition" mode="out-in">
            <local-first-responder-list
              :local_emergency_contacts="disaster_responders"
            />
          </transition>
        </div>

        <!-- Disaster Vendors -->
        <div class="flex flex-wrap flex-auto items-center mb30">
          <h6 class="font-18 blueog--text mb0 mr6">Vendors</h6>
          <VTooltip
            :triggers="['hover']"
            :popperTriggers="['hover']"
            style="height: 24px"
            class="cursor-pointer mr4"
          >
            <span><info-icon></info-icon></span>
            <template #popper
              >List all vendors. Vendors may include companies and individuals who
              are not considered Business Associates.
            </template>
          </VTooltip>

          <button
            v-if="show_vendors_form"
            @click="addDisasterVendorForm"
            type="button"
            class="plus-icon-btn mr4"
          >
            <plus-icon></plus-icon>
          </button>

          <VTooltip
            :triggers="['hover']"
            :popperTriggers="['hover']"
            v-if="show_vendors_edit_btn"
          >
            <button
              @click="toggleDisasterVendorForm"
              type="button"
              class="action-icon-btn action-btn-blueog disaster-edit-btn"
              :class="{ inactive: show_vendors_form }"
            >
              <img :src="JS_APP_URL + '/images/pencil.svg'" alt="" title="" />
            </button>
            <template #popper> Edit </template>
          </VTooltip>
        </div>
        <div v-if="show_vendors_form">
          <transition name="simple-fade-transition" mode="out-in">
            <vendor-form
              :disaster_vendors="disaster_vendors"
              :disaster_add_vendors="disaster_add_vendors"
              :location_id="selected_location_id"
              @delete-vendor-org="deleteVendorOrg"
              ref="disasterVendors"
            />
          </transition>
        </div>
        <div v-else>
          <transition name="simple-fade-transition" mode="out-in">
            <vendor-list
              :disaster_vendors="disaster_vendors"
              :disaster_add_vendors="disaster_add_vendors"
            />
          </transition>
        </div>

        <!-- Emergency Roles and Responsibilities -->
        <div class="flex flex-wrap flex-auto items-center mb30">
          <h6 class="font-18 blueog--text mb0 mr6">
            Emergency Roles &amp; Responsibilities
          </h6>
          <VTooltip
            :triggers="['hover']"
            :popperTriggers="['hover']"
            style="height: 24px"
            class="cursor-pointer mr4"
          >
            <span><info-icon></info-icon></span>
            <template #popper>
              Designate key emergency roles and responsibilities for employees
              within your organization. These assignments will be dynamically
              generated in your Disaster Recovery Plan.
            </template>
          </VTooltip>
          <VTooltip
            :triggers="['hover']"
            :popperTriggers="['hover']"
            v-if="show_emergency_roles_edit_btn"
          >
            <button
              @click="toggleEmergencyRoleForm"
              type="button"
              class="action-icon-btn action-btn-blueog disaster-edit-btn"
              :class="{ inactive: show_emergency_roles_form }"
            >
              <img :src="JS_APP_URL + '/images/pencil.svg'" alt="" title="" />
            </button>
            <template #popper> Edit </template>
          </VTooltip>
          <span class="font-16 font_normal gray_checkmark--text font-italic select-apply-text ml10">(Select All That Apply)</span>
        </div>
        <div v-if="show_emergency_roles_form">
          <transition name="simple-fade-transition" mode="out-in">
            <emergency-roles-and-responsibilities-form
              :emergency_roles_and_responsibility="emergency_roles_responsibility"
              :all_employees="all_employee_list"
            />
          </transition>
        </div>
        <div v-else>
          <transition name="simple-fade-transition" mode="out-in">
            <emergency-roles-and-responsibilities-list
              :emergency_roles_and_responsibility="emergency_roles_responsibility"
            />
          </transition>
        </div>

        <!-- Vulnerabilities -->
        <div class="flex flex-wrap flex-auto items-center mb30">
          <h6 class="font-18 blueog--text mb0 mr6">Vulnerability List</h6>
          <VTooltip
            :triggers="['hover']"
            :popperTriggers="['hover']"
            style="height: 24px"
            class="cursor-pointer mr4"
          >
            <span><info-icon></info-icon></span>
            <template #popper>
              On a scale of 1-3 with 1 being Not Likely, 2 being Somewhat Likely,
              and 3 being Likely, what is the likelihood of each event affecting
              your practice (this location only)?
            </template>
          </VTooltip>
          <VTooltip
            :triggers="['hover']"
            :popperTriggers="['hover']"
            v-if="show_vulnerability_edit_btn"
          >
            <button
              @click="toggleVulnerabilityForm"
              type="button"
              class="action-icon-btn action-btn-blueog disaster-edit-btn"
              :class="{ inactive: show_vulnerability_form }"
            >
              <img :src="JS_APP_URL + '/images/pencil.svg'" alt="" title="" />
            </button>
            <template #popper> Edit </template>
          </VTooltip>
        </div>
        <div v-if="show_vulnerability_form">
          <transition name="simple-fade-transition" mode="out-in">
            <vulnerability-form
              :disaster_vulnerabilities="disaster_vulnerabilities"
              :location_id="selected_location_id"
              ref="disasterVulnerability"
            />
          </transition>
        </div>
        <div v-else>
          <transition name="simple-fade-transition" mode="out-in">
            <vulnerability-list
              :disaster_vulnerabilities="disaster_vulnerabilities"
            />
          </transition>
        </div>

        <div class="flex flex-wrap flex-auto mt50">
            <h6 class="font-14 gray_checkmark--text mb0 mr6">Do you have a lab?</h6>
            <div class="form-group flex items-center flex-wrap flex-auto mb-0 ml10">
                <div class="radio mr16">
                    <input v-model.trim="disaster_vulnerabilities.have_lab" id="have_lab_yes" name="have_lab"
                        type="radio" value="yes">
                    <label for="have_lab_yes"
                        class="radio-label font-14 font-light gray_checkmark--text">Yes</label>
                </div>
                <div class="radio">
                    <input v-model.trim="disaster_vulnerabilities.have_lab" id="have_lab_no" name="have_lab"
                        type="radio" value="no">
                    <label for="have_lab_no"
                        class="radio-label font-14 font-light gray_checkmark--text">No</label>
                </div>
            </div>
        </div>

        <div class="mt40">
          <div class="flex flex-wrap items-center justify-center pb40">
            <button
              type="submit"
              class="btn-primary btn-width-136 mx5 px30 mt-xs-20"
              @click="setDisasterRecoveryPlan"
              id="btn-add-edit-drp"
            >
              Submit
            </button>
            <button
              class="btn-cancel-outline mx5"
              @click="closeForms"
              v-if="
              (show_local_disaster_responder_form ||
              show_emergency_roles_form ||
              show_vendors_form ||
              show_vulnerability_form) && btn_cancel
              "
            >
              CANCEL
            </button>
          </div>
        </div>
      </div>
    </div>
       <import-error-modal
          v-if="is_import_error_modal"
          :import_errors="import_errors_data"
          @close-model="openCloseImportModal"
        />
        <play-explainer-video-modal v-if="play_video_modal == true" :video_file="video_file"
          :video_caption_file="video_caption_file" @close-model="PlayExplainerVideoModalToggle"></play-explainer-video-modal>
  </div>
</template>
<script scoped>
import axios from "axios";
import infoIcon from "../common/icons/infoIcon.vue";
import plusIcon from "../common/icons/plusIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import _ from "lodash";
toastr.options.preventDuplicates = true;
import localFirstResponderForm from "./localFirstResponderForm.vue";
import localFirstResponderList from "./localFirstResponderList.vue";
import emergencyRolesAndResponsibilitiesForm from "./emergencyRolesAndResponsibilitiesForm.vue";
import emergencyRolesAndResponsibilitiesList from "./emergencyRolesAndResponsibilitiesList.vue";
import vendorForm from "./vendorsForm.vue";
import vendorList from "./vendorsList.vue";
import vulnerabilityForm from "./vulnerabilityForm.vue";
import vulnerabilityList from "./vulnerabilityList.vue";
import fullPageLoader from "../common/fullPageLoader.vue";
import importIcon from "../common/icons/importIcon.vue";
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import importErrorModal from "../common/includes/importErrorModal.vue";
import explainerVideoIcon from "../common/icons/explainerVideoIcon.vue";
import playExplainerVideoModal from "../common/includes/playExplainerVideoModal.vue";

let responders_detault_data = {
  local_police_department_name: null,
  local_police_department_phone: null,
  local_fire_department_name: null,
  local_fire_department_phone: null,
};
let vendors_default_data = {
  alarm_system_company: null,
  alarm_system_company_phone: null,
  data_backup_vendor: null,
  data_backup_vendor_phone: null,
  data_backup_vendor_location: null,
  landlord_property_manager: null,
  landlord_property_manager_phone: null,
  practice_management_software: null,
  practice_management_software_phone: null,
  ehr_software: null,
  ehr_software_phone: null,
  it_vendor: null,
  it_vendor_phone: null,
  has_alarm_system_company: false,
  has_data_backup_vendor: false,
  has_landlord_property_manager: false,
  has_practice_management_software: false,
  has_ehr_software: false,
  has_it_vendor: false,
};
let vulnerabilities_default_data = {
  hurricane: "",
  flood: "",
  tornado: "",
  earthquake: "",
  fire: "",
  rogue_staff_vendor: "",
  theft: "",
  malicious_software_virus: "",
  utility_interruption_failure: "",
  public_health_emergency: "",
  have_lab: 'yes',
};

let emergency_roles_responsibility_org;
let disaster_first_data_org;
let disaster_vendor_data_org;
let disaster_vulnerability_data_org;
let disaster_add_vendors_org;

export default {
  data() {
    return {
      is_data_loaded: false,
      JS_APP_URL: JS_APP_URL,
      selected_location_id: parseInt(JS_LOCATION_ID),
      all_locations: [],
      selected_location: {},
      disaster_responders: { ...responders_detault_data },
      disaster_vendors: { ...vendors_default_data },
      disaster_vulnerabilities: { ...vulnerabilities_default_data },
      show_local_disaster_responder_form: true,
      show_vendors_form: true,
      show_emergency_roles_form: true,
      show_vulnerability_form: true,
      show_local_disaster_responder_edit_btn: false,
      show_vendors_edit_btn: false,
      show_emergency_roles_edit_btn: false,
      show_vulnerability_edit_btn: false,
      show_vendors_add_form: false,
      emergency_roles_responsibility: {
        disaster_recovery_leads: [],
        disaster_communication_employee: [],
        disaster_communication_authority: [],
        disaster_communication_partner_vendor: [],
        disaster_communication_patient: [],
        disaster_communication_media: [],
      },
      disaster_add_vendors: [],
      all_employee_list: [],
      is_full_page_loader_shown: true,
      btn_cancel: true,
      checklist_url: "",
      sample_import_doc: "",
      is_import_error_modal: false,
      import_errors_data: [],
      APP_ENV: APP_ENV,
      video_file: "hce_explainer_drp_final.mp4",  
      video_caption_file: "hce_explainer_drp_final.vtt",  
      play_video_modal: false,
    };
  },
  components: {
    infoIcon,
    plusIcon,
    localFirstResponderForm,
    localFirstResponderList,
    emergencyRolesAndResponsibilitiesForm,
    emergencyRolesAndResponsibilitiesList,
    vendorForm,
    vendorList,
    vulnerabilityForm,
    vulnerabilityList,
    fullPageLoader,
    importIcon,
    headerAfterLogin,
    importErrorModal,
    explainerVideoIcon,
    playExplainerVideoModal
  },
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        if (this.btn_cancel) {
          this.closeForms();
        }
      }
    });
    this.loadLocationNicknameList();
    this.loadEmployeeList();
  },
  watch: {
    selected_location(val) {
      this.selected_location_id = val.id;
      this.loadEmployeeList();
      this.getDisasterRecoveryPlan();
      if(this.$refs.import_file_upload){
        this.$refs.import_file_upload.value = null;
      }
    },
  },
  methods: {
    PlayExplainerVideoModalToggle() {
      if (this.play_video_modal == true) {
        this.play_video_modal = false;
      } else {
        this.play_video_modal = true;
      }
    },
    loadLocationNicknameList() {
      axios
        .get(JS_APP_URL + "/general/get-assigned-location-list")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.all_locations = response["data"]["data"];
            this.selected_location = this.all_locations.find(
              (object) => object.id == this.selected_location_id
            );
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },
    getDisasterRecoveryPlan() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL +
            "/disaster-recovery-plan/get-details-by-location-id/" +
            this.selected_location_id
        )
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            let data = response["data"]["data"];
            this.sample_import_doc = data.sample_import_doc;
            if (data.disaster_recovery_plan_module_status == true) {
              this.disaster_responders =
                data.disaster_local_first_responders != null
                  ? data.disaster_local_first_responders
                  : { ...responders_detault_data };
              if (data.disaster_vendors != null) {
                this.disaster_vendors = data.disaster_vendors;
                this.setVendorFormCheckboxValue();
              } else {
                this.disaster_vendors = { ...vendors_default_data };
                this.setVendorFormCheckboxValue();
              }

              this.emergency_roles_responsibility.disaster_recovery_leads =
                _.map(data.disaster_recovery_leads, "employee");
              this.emergency_roles_responsibility.disaster_communication_employee =
                _.map(data.disaster_communication_employee, "employee");
              this.emergency_roles_responsibility.disaster_communication_authority =
                _.map(data.disaster_communication_authority, "employee");
              this.emergency_roles_responsibility.disaster_communication_partner_vendor =
                _.map(data.disaster_communication_partner_vendor, "employee");
              this.emergency_roles_responsibility.disaster_communication_patient =
                _.map(data.disaster_communication_patients, "employee");
              this.emergency_roles_responsibility.disaster_communication_media =
                _.map(data.disaster_communication_media, "employee");

              this.disaster_vulnerabilities = data.disaster_vulnerabilities;
              this.disaster_add_vendors = data.disaster_vendor_manual;

              this.show_local_disaster_responder_form = false;
              this.show_vendors_form = false;
              this.show_emergency_roles_form = false;
              this.show_vulnerability_form = false;
              this.show_local_disaster_responder_edit_btn = true;
              this.show_vendors_edit_btn = true;
              this.show_emergency_roles_edit_btn = true;
              this.show_vulnerability_edit_btn = true;
              this.btn_cancel = true;
              setTimeout(() => {
                if(APP_ENV == 'production') {
                  var metadata = {
                    first_time_disaster_added: data.first_time_disaster_added,
                    location_id: this.selected_location_id,
                    location_nickname: this.selected_location.location_nickname,
                    user_locations_number: this.all_locations.length
                  };
                  Intercom('trackEvent', 'disaster-recovery-status', metadata);
                }
              }, 1000);
            } else {
              this.disaster_responders = { ...responders_detault_data };
              this.disaster_vendors = { ...vendors_default_data };
              this.emergency_roles_responsibility.disaster_recovery_leads = [];
              this.emergency_roles_responsibility.disaster_communication_employee =
                [];
              this.emergency_roles_responsibility.disaster_communication_authority =
                [];
              this.emergency_roles_responsibility.disaster_communication_partner_vendor =
                [];
              this.emergency_roles_responsibility.disaster_communication_patient =
                [];
              this.emergency_roles_responsibility.disaster_communication_media =
                [];
              this.disaster_vulnerabilities = {
                ...vulnerabilities_default_data,
              };
              this.disaster_add_vendors = [];
              this.disaster_add_vendors = data.disaster_vendor_manual;
              this.show_local_disaster_responder_form = true;
              this.show_vendors_form = true;
              this.show_emergency_roles_form = true;
              this.show_vulnerability_form = true;
              this.btn_cancel = false;
              this.show_local_disaster_responder_edit_btn = false;
              this.show_vendors_edit_btn = false;
              this.show_emergency_roles_edit_btn = false;
              this.show_vulnerability_edit_btn = false;
            }
            emergency_roles_responsibility_org = {
              ...this.emergency_roles_responsibility,
            };
            disaster_first_data_org = {
              ...this.disaster_responders,
            };
            disaster_vendor_data_org = {
              ...this.disaster_vendors,
            };
            disaster_vulnerability_data_org = {
              ...this.disaster_vulnerabilities,
            };
            disaster_add_vendors_org = [...this.disaster_add_vendors];
          } else {
            window.location = JS_APP_URL + "/dashboard";
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
          this.is_data_loaded = true;
        });
    },
    setVendorFormCheckboxValue() {
      this.disaster_vendors.has_alarm_system_company =
        this.disaster_vendors.alarm_system_company == null &&
        this.disaster_vendors.alarm_system_company_phone == null
          ? true
          : false;
      this.disaster_vendors.has_data_backup_vendor =
        this.disaster_vendors.data_backup_vendor == null &&
        this.disaster_vendors.data_backup_vendor_phone == null
          ? true
          : false;
      this.disaster_vendors.has_landlord_property_manager =
        this.disaster_vendors.landlord_property_manager == null &&
        this.disaster_vendors.landlord_property_manager_phone == null
          ? true
          : false;
      this.disaster_vendors.has_practice_management_software =
        this.disaster_vendors.practice_management_software == null &&
        this.disaster_vendors.practice_management_software_phone == null
          ? true
          : false;
      this.disaster_vendors.has_ehr_software =
        this.disaster_vendors.ehr_software == null &&
        this.disaster_vendors.ehr_software_phone == null
          ? true
          : false;
      this.disaster_vendors.has_it_vendor =
        this.disaster_vendors.it_vendor == null &&
        this.disaster_vendors.it_vendor_phone == null
          ? true
          : false;
    },
    async setDisasterRecoveryPlan() {
      let invalid_emergency_roles_form, vendors_form, vulnerability_form  = false;

      if (this.show_local_disaster_responder_form) {
        invalid_emergency_roles_form = this.$refs.emergencyContacts.isInvalid();
      }
      if (this.show_vendors_form) {
        vendors_form = await this.$refs.disasterVendors.isInvalid();
      }
      if (this.show_vulnerability_form) {
        vulnerability_form = this.$refs.disasterVulnerability.isInvalid();
      }

      if (!invalid_emergency_roles_form && !vendors_form && !vulnerability_form) {
        this.is_full_page_loader_shown = true;
        let local_first_responders = this.disaster_responders;
        let disaster_vendors = this.disaster_vendors;
        let disaster_vendor_manual = this.disaster_add_vendors;

        let disaster_recovery_lead_new = _.differenceBy(
          this.emergency_roles_responsibility.disaster_recovery_leads,
          emergency_roles_responsibility_org.disaster_recovery_leads,
          "id"
        );
        let disaster_recovery_lead_removed = _.map(
          _.differenceBy(
            emergency_roles_responsibility_org.disaster_recovery_leads,
            this.emergency_roles_responsibility.disaster_recovery_leads,
            "id"
          ),
          "id"
        );

        let disaster_communication_employee_new = _.differenceBy(
          this.emergency_roles_responsibility.disaster_communication_employee,
          emergency_roles_responsibility_org.disaster_communication_employee,
          "id"
        );
        let disaster_communication_employee_removed = _.map(
          _.differenceBy(
            emergency_roles_responsibility_org.disaster_communication_employee,
            this.emergency_roles_responsibility.disaster_communication_employee,
            "id"
          ),
          "id"
        );

        let disaster_communication_authority_new = _.differenceBy(
          this.emergency_roles_responsibility.disaster_communication_authority,
          emergency_roles_responsibility_org.disaster_communication_authority,
          "id"
        );
        let disaster_communication_authority_removed = _.map(
          _.differenceBy(
            emergency_roles_responsibility_org.disaster_communication_authority,
            this.emergency_roles_responsibility
              .disaster_communication_authority,
            "id"
          ),
          "id"
        );

        let disaster_communication_partner_vendor_new = _.differenceBy(
          this.emergency_roles_responsibility
            .disaster_communication_partner_vendor,
          emergency_roles_responsibility_org.disaster_communication_partner_vendor,
          "id"
        );
        let disaster_communication_partner_vendor_removed = _.map(
          _.differenceBy(
            emergency_roles_responsibility_org.disaster_communication_partner_vendor,
            this.emergency_roles_responsibility
              .disaster_communication_partner_vendor,
            "id"
          ),
          "id"
        );

        let disaster_communication_patient_new = _.differenceBy(
          this.emergency_roles_responsibility.disaster_communication_patient,
          emergency_roles_responsibility_org.disaster_communication_patient,
          "id"
        );
        let disaster_communication_patient_removed = _.map(
          _.differenceBy(
            emergency_roles_responsibility_org.disaster_communication_patient,
            this.emergency_roles_responsibility.disaster_communication_patient,
            "id"
          ),
          "id"
        );

        let disaster_communication_media_new = _.differenceBy(
          this.emergency_roles_responsibility.disaster_communication_media,
          emergency_roles_responsibility_org.disaster_communication_media,
          "id"
        );
        let disaster_communication_media_removed = _.map(
          _.differenceBy(
            emergency_roles_responsibility_org.disaster_communication_media,
            this.emergency_roles_responsibility.disaster_communication_media,
            "id"
          ),
          "id"
        );

        let disaster_vulnerability = this.disaster_vulnerabilities;

        let payload = {
          location_id: this.selected_location_id,
          disaster_local_first_responders: local_first_responders,
          disaster_vendors: disaster_vendors,
          disaster_vulnerability: disaster_vulnerability,
          disaster_recovery_lead_new,
          disaster_recovery_lead_removed,
          disaster_communication_employee_new,
          disaster_communication_employee_removed,
          disaster_communication_authority_new,
          disaster_communication_authority_removed,
          disaster_communication_partner_vendor_new,
          disaster_communication_partner_vendor_removed,
          disaster_communication_patient_new,
          disaster_communication_patient_removed,
          disaster_communication_media_new,
          disaster_communication_media_removed,
          disaster_vendor_manual,
        };
        axios
          .post(JS_APP_URL + "/disaster-recovery-plan/add-edit", payload)
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if (response["data"]["data"].length > 0) {
                toastr.error(response["data"]["data"].join("</br>"), "Error");
              } else {
                toastr.error(response["data"]["message"], "Error");
              }
            }
            if (response["data"]["status"] == "Success") {
              toastr.success(response["data"]["message"], "Success");
              this.getDisasterRecoveryPlan();
              this.show_local_disaster_responder_form = false;
              this.show_vendors_form = false;
              this.show_emergency_roles_form = false;
              this.show_vulnerability_form = false;
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            this.is_full_page_loader_shown = false;
          });
      }
    },
    toggleDisasterResponderForm() {
      if (this.show_local_disaster_responder_form) {
        this.disaster_responders = {
          ...disaster_first_data_org,
        };
      }
      this.show_local_disaster_responder_form =
        !this.show_local_disaster_responder_form;
    },
    toggleDisasterVendorForm() {
      if (this.show_vendors_form) {
        this.disaster_vendors = {
          ...disaster_vendor_data_org,
        };
        this.disaster_add_vendors = [...disaster_add_vendors_org];
      }
      this.show_vendors_form = !this.show_vendors_form;
    },
    addDisasterVendorForm() {
      this.disaster_add_vendors.push({
        vendor_name: "",
        vendor_phone: "",
        vendor_responsibility: "",
      });
    },
    toggleEmergencyRoleForm() {
      if (this.show_emergency_roles_form) {
        this.emergency_roles_responsibility = {
          ...emergency_roles_responsibility_org,
        };
      }
      this.show_emergency_roles_form = !this.show_emergency_roles_form;
    },
    toggleVulnerabilityForm() {
      if (this.show_vulnerability_form) {
        this.disaster_vulnerabilities = {
          ...disaster_vulnerability_data_org,
        };
      }
      this.show_vulnerability_form = !this.show_vulnerability_form;
    },
    loadEmployeeList() {
      axios
        .get(
          JS_APP_URL +
            "/general/get-employee-list-by-location-id?location_id=" +
            this.selected_location_id
        )
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.all_employee_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },
    closeForms() {
      this.emergency_roles_responsibility = {
        ...emergency_roles_responsibility_org,
      };
      this.disaster_responders = {
        ...disaster_first_data_org,
      };
      this.disaster_vendors = {
        ...disaster_vendor_data_org,
      };
      this.disaster_add_vendors = [...disaster_add_vendors_org];
      this.disaster_vulnerabilities = {
        ...disaster_vulnerability_data_org,
      };
      this.show_local_disaster_responder_form = false;
      this.show_vendors_form = false;
      this.show_emergency_roles_form = false;
      this.show_vulnerability_form = false;
    },
    importDisasterRecovery(event) {
      var formData = new FormData();
      formData.append("import_file", event.target.files[0]);
      formData.append("location_id", this.selected_location_id);
      this.is_full_page_loader_shown = true;
      axios
        .post(
          JS_APP_URL + "/disaster-recovery-plan/import-responders",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response['data']['data'].length != 0){
                this.openCloseImportModal(response['data']);
            }else{
              this.openCloseImportModal(response["data"]);
            }
          } else {
            toastr.success(response["data"]["message"], "Success");
            this.getDisasterRecoveryPlan();
            this.show_local_disaster_responder_form = false;
            this.show_vendors_form = false;
            this.show_emergency_roles_form = false;
            this.show_vulnerability_form = false;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.$refs.import_file_upload.value = null;
          this.is_full_page_loader_shown = false;
        });
    },
    onPickImportFile() {
      this.$refs.import_file_upload.click();
    },
    deleteVendorOrg(index) {
      disaster_add_vendors_org.splice(index, 1);
    },
    openCloseImportModal(import_errors) {
      if(!this.is_import_error_modal) {
        this.is_import_error_modal = true
        this.import_errors_data = import_errors;
      } else {
        this.is_import_error_modal = false
      }
    },
  },
};
</script>
