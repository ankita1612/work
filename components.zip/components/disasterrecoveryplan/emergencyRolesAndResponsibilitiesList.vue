<template>
  <div class="pb30">
    <div class="row flex-auto -mx-10">
      <div
        class="
          col-12 col-md-6 col-lg-4 col-xl-3 col-20-emergency mb10
          mb-md-10 mb-lg-10
          px10
        "
      >
        <div
          class="
            emergency-roles-item
            flex
            items-center
            justify-center
            flex-col
            light
            pt6
            pb4
            px10
            text-center
          "
        >
          <div class="font-14 font_semibold dark--text pb1">
            Disaster Recovery Lead(s)
          </div>
          <div
            class="font-12 dark--text"
            v-if="
              this.emergency_roles_and_responsibility.disaster_recovery_leads
                .length > 0
            "
            v-html="this.emergency_roles_and_responsibility.disaster_recovery_leads
                .map((u) => u.first_name + ' ' + u.last_name)
                .join('<br/>')"
          >
          </div>
          <div class="font-12 dark--text" v-else>No employee selected</div>
        </div>
      </div>
      <div
        class="
          col-12 col-md-6 col-lg-4 col-xl-3 col-20-emergency mb10
          mb-md-10 mb-lg-10
          px10
        "
      >
        <div
          class="
            emergency-roles-item
            flex
            items-center
            justify-center
            flex-col
            light
            pt6
            pb4
            px10
            text-center
          "
        >
          <div class="font-14 font_semibold dark--text pb1">
            Communication to Employees 
          </div>
          <div
            class="font-12 dark--text"
            v-if="
              this.emergency_roles_and_responsibility.disaster_communication_employee.length >
              0
            "
            v-html="this.emergency_roles_and_responsibility.disaster_communication_employee
                .map((u) => u.first_name + ' ' + u.last_name)
                .join('<br/>')"
          >
          </div>
          <div class="font-12 dark--text" v-else>No employee selected</div>
        </div>
      </div>
      <div
        class="
          col-12 col-md-6 col-lg-4 col-xl-3 col-20-emergency mb10
          mb-md-10 mb-lg-10
          px10
        "
      >
        <div
          class="
            emergency-roles-item
            flex
            items-center
            justify-center
            flex-col
            light
            pt6
            pb4
            px10
            text-center
          "
        >
          <div class="font-14 font_semibold dark--text pb1">
            Communication to Authorities
          </div>
          <div
            class="font-12 dark--text"
            v-if="
              this.emergency_roles_and_responsibility.disaster_communication_authority
                .length > 0
            "
            v-html="this.emergency_roles_and_responsibility.disaster_communication_authority
                .map((u) => u.first_name + ' ' + u.last_name)
                .join('<br/>')"
          >
          </div>
          <div class="font-12 dark--text" v-else>No employee selected</div>
        </div>
      </div>
      <div
        class="
          col-12 col-md-6 col-lg-4 col-xl-3 col-20-emergency mb10
          mb-md-10 mb-lg-10
          px10
        "
      >
        <div
          class="
            emergency-roles-item
            flex
            items-center
            justify-center
            flex-col
            light
            pt6
            pb4
            px10
            text-center
          "
        >
          <div class="font-14 font_semibold dark--text pb1">
            Communication to all Partners and Vendors
          </div>
          <div
            class="font-12 dark--text"
            v-if="
              this.emergency_roles_and_responsibility.disaster_communication_partner_vendor
                .length > 0
            "
            v-html="this.emergency_roles_and_responsibility.disaster_communication_partner_vendor
                .map((u) => u.first_name + ' ' + u.last_name)
                .join('<br/>')"
          >
          </div>
          <div class="font-12 dark--text" v-else>No employee selected</div>
        </div>
      </div>
      <div
        class="
          col-12 col-md-6 col-lg-4 col-xl-3 col-20-emergency mb10
          mb-md-10 mb-lg-10
          px10
        "
      >
        <div
          class="
            emergency-roles-item
            flex
            items-center
            justify-center
            flex-col
            light
            pt6
            pb4
            px10
            text-center
          "
        >
          <div class="font-14 font_semibold dark--text pb1">
            Communication to all Patients
          </div>
          <div
            class="font-12 dark--text"
            v-if="
              this.emergency_roles_and_responsibility.disaster_communication_patient
                .length > 0
            "
            v-html="this.emergency_roles_and_responsibility.disaster_communication_patient
                .map((u) => u.first_name + ' ' + u.last_name)
                .join('<br/>')"
          >
          </div>
          <div class="font-12 dark--text" v-else>No employee selected</div>
        </div>
      </div>
      <div
        class="
          col-12 col-md-6 col-lg-4 col-xl-3 col-20-emergency mb10
          mb-md-10 mb-lg-10
          px10
        "
      >
        <div
          class="
            emergency-roles-item
            flex
            items-center
            justify-center
            flex-col
            light
            pt6
            pb4
            px10
            text-center
          "
        >
          <div class="font-14 font_semibold dark--text pb1">
            Communication to Media
          </div>
          <div
            class="font-12 dark--text"
            v-if="
              this.emergency_roles_and_responsibility.disaster_communication_media
                .length > 0
            "
            v-html="this.emergency_roles_and_responsibility.disaster_communication_media
                .map((u) => u.first_name + ' ' + u.last_name)
                .join('<br/>')"
          >
          </div>
          <div class="font-12 dark--text" v-else>No employee selected</div>
        </div>
      </div>
    </div>
</div>
</template>

<script>
export default {
  props: {
    emergency_roles_and_responsibility: {
      type: Object,
    },
  },
};
</script>
