<template>
  <div class="row flex-auto -mx5 mb30">
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-20-emergency px5 mb10">
      <div class="form-group mb-0">
        <multiselect v-model="emergency_roles_and_responsibility.disaster_recovery_leads" class="font-style-normal select-all-dropdown"
          placeholder="" :options="all_employees_list" track-by="id" :custom-label="customLabel"  :group-select="true" group-values="group_option_list" 
          group-label="select_all" :multiple="true"
          :close-on-select="false" position="bottom" :showLabels="false" :taggable="false">
          <template #noResult>
            <div class="multiselect__noResult text-center">
              No results found
            </div>
          </template>
          <template #noOptions>
            <div class="multiselect__noOptions text-center">
              No data available
            </div>
          </template>
          <template #selection>
            <div class="multiselect__tags-wrap" v-if="emergency_roles_and_responsibility.disaster_recovery_leads.length > 1">
                <span class="multiselect__tag">
                <span>{{ emergency_roles_and_responsibility.disaster_recovery_leads.length }} Employees Selected</span>
                </span>
            </div>
          </template>
        </multiselect>
        <label class="label label-select" :class="{
          'label-float':
            emergency_roles_and_responsibility.disaster_recovery_leads.length >
            0,
        }">Disaster Recovery Lead(s)</label>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-20-emergency px5 mb-sm mb-md-10">
      <div class="form-group mb-0">
        <multiselect v-model="emergency_roles_and_responsibility.disaster_communication_employee"
          class="font-style-normal select-all-dropdown" placeholder="" :options="all_employees_list" track-by="id" :custom-label="customLabel"
          :group-select="true" group-values="group_option_list" group-label="select_all" :multiple="true" :close-on-select="false" position="bottom" :showLabels="false" :taggable="false">
            <template #noResult>
                <div class="multiselect__noResult text-center">
                    No results found
                </div>
            </template>
            <template #noOptions>
                <div class="multiselect__noOptions text-center">
                    No data available
                </div>
            </template>
            <template #selection>
                <div class="multiselect__tags-wrap" v-if="emergency_roles_and_responsibility.disaster_communication_employee.length > 1">
                    <span class="multiselect__tag">
                    <span>{{ emergency_roles_and_responsibility.disaster_communication_employee.length }} Employees Selected</span>
                    </span>
                </div>
            </template>
        </multiselect>
        <label class="label label-select" :class="{
          'label-float':
            emergency_roles_and_responsibility.disaster_communication_employee.length > 0,
        }">Communication to Employees</label>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-20-emergency px5 mb-sm mb-md-10">
      <div class="form-group mb-0">
        <multiselect v-model="emergency_roles_and_responsibility.disaster_communication_authority"
          class="font-style-normal select-all-dropdown" placeholder="" :options="all_employees_list" track-by="id" :custom-label="customLabel"
          :multiple="true" :group-select="true" group-values="group_option_list" group-label="select_all" :close-on-select="false" position="bottom" :showLabels="false" :taggable="false">
            <template #noResult>
                <div class="multiselect__noResult text-center">
                    No results found
                </div>
            </template>
            <template #noOptions>
                <div class="multiselect__noOptions text-center">
                    No data available
                </div>
            </template>
            <template #selection>
                <div class="multiselect__tags-wrap" v-if="emergency_roles_and_responsibility.disaster_communication_authority.length > 1">
                    <span class="multiselect__tag">
                    <span>{{ emergency_roles_and_responsibility.disaster_communication_authority.length }} Employees Selected</span>
                    </span>
                </div>
            </template>
        </multiselect>
        <label class="label label-select" :class="{
          'label-float':
            emergency_roles_and_responsibility.disaster_communication_authority
              .length > 0,
        }">Communication to Authorities</label>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-20-emergency px5 mb-sm mb-md-10">
      <div class="form-group mb-0">
        <multiselect v-model="emergency_roles_and_responsibility.disaster_communication_partner_vendor"
          class="font-style-normal select-all-dropdown" placeholder="" :options="all_employees_list" track-by="id" :custom-label="customLabel"
          :multiple="true" :group-select="true" group-values="group_option_list" group-label="select_all" :close-on-select="false" position="bottom" :showLabels="false" :taggable="false">
            <template #noResult>
                <div class="multiselect__noResult text-center">
                    No results found
                </div>
            </template>
            <template #noOptions>
                <div class="multiselect__noOptions text-center">
                    No data available
                </div>
            </template>
            <template #selection>
                <div class="multiselect__tags-wrap" v-if="emergency_roles_and_responsibility.disaster_communication_partner_vendor.length > 1">
                    <span class="multiselect__tag">
                    <span>{{ emergency_roles_and_responsibility.disaster_communication_partner_vendor.length }} Employees Selected</span>
                    </span>
                </div>
            </template>
        </multiselect>
        <label class="label label-select multiselect-lable-truncate" :class="{
          'label-float':
            emergency_roles_and_responsibility.disaster_communication_partner_vendor
              .length > 0,
        }">Communication to all Partners and Vendors</label>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-20-emergency px5 mb-sm mb-md-10">
      <div class="form-group mb-0">
        <multiselect v-model="emergency_roles_and_responsibility.disaster_communication_patient"
          class="font-style-normal select-all-dropdown" placeholder="" :options="all_employees_list" track-by="id" :custom-label="customLabel"
          :multiple="true" :group-select="true" group-values="group_option_list" group-label="select_all" :close-on-select="false" position="bottom" :showLabels="false" :taggable="false">
            <template #noResult>
                <div class="multiselect__noResult text-center">
                  No results found
                </div>
            </template>
            <template #noOptions>
                <div class="multiselect__noOptions text-center">
                  No data available
                </div>
            </template>
            <template #selection>
                <div class="multiselect__tags-wrap" v-if="emergency_roles_and_responsibility.disaster_communication_patient.length > 1">
                  <span class="multiselect__tag">
                    <span>{{ emergency_roles_and_responsibility.disaster_communication_patient.length }} Employees Selected</span>
                  </span>
                </div>
            </template>
        </multiselect>
        <label class="label label-select" :class="{
          'label-float':
            emergency_roles_and_responsibility.disaster_communication_patient.length >
            0,
        }">Communication to all Patients</label>
      </div>
    </div>
    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 col-20-emergency px5 mb-sm">
      <div class="form-group mb-0">
        <multiselect v-model="emergency_roles_and_responsibility.disaster_communication_media" class="font-style-normal select-all-dropdown"
          placeholder="" :options="all_employees_list" track-by="id" :custom-label="customLabel" :multiple="true"
          :group-select="true" group-values="group_option_list" group-label="select_all" :close-on-select="false" position="bottom" :showLabels="false" :taggable="false">
            <template #noResult>
                <div class="multiselect__noResult text-center">
                    No results found
                </div>
            </template>
            <template #noOptions>
                <div class="multiselect__noOptions text-center">
                    No data available
                </div>
            </template>
            <template #selection>
                <div class="multiselect__tags-wrap" v-if="emergency_roles_and_responsibility.disaster_communication_media.length > 1">
                    <span class="multiselect__tag">
                    <span>{{ emergency_roles_and_responsibility.disaster_communication_media.length }} Employees Selected</span>
                    </span>
                </div>
            </template>
        </multiselect>
        <label class="label label-select" :class="{
          'label-float':
            emergency_roles_and_responsibility.disaster_communication_media.length >
            0,
        }">Communication to Media</label>
      </div>
    </div>
  </div>
</template>

<script>
import clearDropdownIcon from "../common/icons/clearDropdownIcon.vue";
import _ from "lodash";

export default {
  data() {
    return {
      all_employees_list : [{
          'select_all': 'Select All',
          'group_option_list': this.all_employees,
      }]
    }
  },
  props: {
    emergency_roles_and_responsibility: {
      type: Object,
    },
    all_employees: {
      type: Array,
    },
  },
  components: {
    clearDropdownIcon,
  },
  mounted() {

    const disaster_recovery_leads = this.emergency_roles_and_responsibility.disaster_recovery_leads;
    this.emergency_roles_and_responsibility.disaster_recovery_leads = []
    _.forEach( disaster_recovery_leads, (value) => {
            var is_found_employee = _.find(
                this.all_employees,
                  (o) => {
                    return o.id === value.id;
                }
            );
            if (!_.isUndefined(is_found_employee)) {
                this.emergency_roles_and_responsibility.disaster_recovery_leads.push(
                    is_found_employee
                );
            }
        }
    );

    const disaster_communication_employee = this.emergency_roles_and_responsibility.disaster_communication_employee;
    this.emergency_roles_and_responsibility.disaster_communication_employee = []
    _.forEach( disaster_communication_employee, (value) => {
            var is_found_employee = _.find(
                this.all_employees,
                  (o) => {
                    return o.id === value.id;
                }
            );
            if (!_.isUndefined(is_found_employee)) {
                this.emergency_roles_and_responsibility.disaster_communication_employee.push(
                    is_found_employee
                );
            }
        }
    );    
    
    const disaster_communication_authority = this.emergency_roles_and_responsibility.disaster_communication_authority;
    this.emergency_roles_and_responsibility.disaster_communication_authority = []
    _.forEach( disaster_communication_authority, (value) => {
            var is_found_employee = _.find(
                this.all_employees,
                  (o) => {
                    return o.id === value.id;
                }
            );
            if (!_.isUndefined(is_found_employee)) {
                this.emergency_roles_and_responsibility.disaster_communication_authority.push(
                    is_found_employee
                );
            }
        }
    );    

    const disaster_communication_partner_vendor = this.emergency_roles_and_responsibility.disaster_communication_partner_vendor;
    this.emergency_roles_and_responsibility.disaster_communication_partner_vendor = []
    _.forEach( disaster_communication_partner_vendor, (value) => {
            var is_found_employee = _.find(
                this.all_employees,
                  (o) => {
                    return o.id === value.id;
                }
            );
            if (!_.isUndefined(is_found_employee)) {
                this.emergency_roles_and_responsibility.disaster_communication_partner_vendor.push(
                    is_found_employee
                );
            }
        }
    );    

    const disaster_communication_patient = this.emergency_roles_and_responsibility.disaster_communication_patient;
    this.emergency_roles_and_responsibility.disaster_communication_patient = []
    _.forEach( disaster_communication_patient, (value) => {
            var is_found_employee = _.find(
                this.all_employees,
                  (o) => {
                    return o.id === value.id;
                }
            );
            if (!_.isUndefined(is_found_employee)) {
                this.emergency_roles_and_responsibility.disaster_communication_patient.push(
                    is_found_employee
                );
            }
        }
    );    

    const disaster_communication_media = this.emergency_roles_and_responsibility.disaster_communication_media;
    this.emergency_roles_and_responsibility.disaster_communication_media = []
    _.forEach( disaster_communication_media, (value) => {
            var is_found_employee = _.find(
                this.all_employees,
                  (o) => {
                    return o.id === value.id;
                }
            );
            if (!_.isUndefined(is_found_employee)) {
                this.emergency_roles_and_responsibility.disaster_communication_media.push(
                    is_found_employee
                );
            }
        }
    );    
  }, 
  watch: {
    all_employees(val) {
      this.all_employees_list = [{
          'select_all': 'Select All',
          'group_option_list': this.all_employees,
      }]
    },
  },
  methods: {
    customLabel(option) {
      if (option.first_name && option.last_name) {
        return `${option.first_name} ${option.last_name}`;
      } else {
        return ``;
      }
    },
  },
};
</script>
