<template>
  <transition name="simple-fade-transition" mode="in-out">
    <div class="pb30">
      <div class="user-detail-card py11 pl30 pr20 light mb10">
        <div class="row flex-auto -mx-10">
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
            <div class="font-14 font_semibold dark--text pb1">  Local Police Department Name </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
            <div class="
                user-detail-text
                font-14 dark--text
                mb-md-10 mb-sm-10
                ">
            {{(local_emergency_contacts.local_police_department_name != null &&
            local_emergency_contacts.local_police_department_name != '') ?
            local_emergency_contacts.local_police_department_name : "Local Police Department Name"}}
            </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 col-12-emergency px10 self-end">
            <div class="
                user-detail-text
                font-14
                gray_checkmark--text
                mb-md-10 mb-sm-10
                ">
            {{(local_emergency_contacts.local_police_department_phone != null &&
            local_emergency_contacts.local_police_department_phone != '') ?
            local_emergency_contacts.local_police_department_phone : "N/A"}}
            </div>
        </div>
        </div>
      </div>
      <div class="user-detail-card py11 pl30 pr20 light mb10">
        <div class="row flex-auto -mx-10">
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
            <div class="font-14 font_semibold dark--text pb1">  Local Fire Department Name </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
            <div class="
                user-detail-text
                font-14
                dark--text
                mb-md-10 mb-sm-10
                ">
            {{(local_emergency_contacts.local_fire_department_name != null &&
            local_emergency_contacts.local_fire_department_name != '') ?
            local_emergency_contacts.local_fire_department_name : "Local Fire Department Name"}}
            </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 col-12-emergency px10 self-end">
            <div class="
                user-detail-text
                font-14
                gray_checkmark--text
                mb-md-10 mb-sm-10
                ">
            {{(local_emergency_contacts.local_fire_department_phone != null &&
            local_emergency_contacts.local_fire_department_phone != '') ?
            local_emergency_contacts.local_fire_department_phone : "N/A"}}
            </div>
        </div>
        </div>
      </div>
    </div>
  </transition>
</template>
<script>
export default {
  props: {
    local_emergency_contacts: {
      type: Object,
    },
  },
}
</script>
