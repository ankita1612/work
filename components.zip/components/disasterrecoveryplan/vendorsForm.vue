<template>
    <div class="mb30">
        <div class="row flex flex-wrap -mx5 mb10 mb-sm-20">
            <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 px5 mb-sm-10">
                <div class="relative" :class="{ 'form-group--error': v$.disaster_vendors.alarm_system_company.$error }">
                    <input v-model="v$.disaster_vendors.alarm_system_company.$model" class="form-input location-input-box"
                        :class="{ 'form-error': v$.disaster_vendors.alarm_system_company.$error }" type="text"
                        id="alarm_system_company" name="alarm_system_company"
                        :disabled="disaster_vendors.has_alarm_system_company == true">
                    <label for="alarm_system_company" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.alarm_system_company }">Alarm System
                        Company</label>
                    <div v-if="v$.disaster_vendors.alarm_system_company.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.alarm_system_company.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 px5 mb-sm-10">
                <div class="relative"
                    :class="{ 'form-group--error': v$.disaster_vendors.alarm_system_company_phone.$error }">
                    <input v-model="v$.disaster_vendors.alarm_system_company_phone.$model"
                        :class="{ 'form-error': v$.disaster_vendors.alarm_system_company_phone.$error }"
                        class="form-input location-input-box" type="text" id="alarm_system_company_phone"
                        name="alarm_system_company_phone" v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent
                        :disabled="disaster_vendors.has_alarm_system_company == true">
                    <label for="alarm_system_company_phone" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.alarm_system_company_phone }">Phone
                        Number</label>
                    <div v-if="v$.disaster_vendors.alarm_system_company_phone.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.alarm_system_company_phone.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-2 col-xl-2 px5">
                <div class="flex items-center flex-wrap flex-auto mt10">
                    <div class="checkbox">
                        <input v-model="disaster_vendors.has_alarm_system_company" id="has_alarm_system_company"
                            name="has_alarm_system_company" type="checkbox">
                        <label for="has_alarm_system_company"
                            class="checkbox-label font-14 font-light gray_checkmark--text">Not
                            Applicable</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row flex flex-wrap -mx5 mb10 mb-sm-20">
            <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 px5 mb-sm-10">
                <div class="relative" :class="{ 'form-group--error': v$.disaster_vendors.data_backup_vendor.$error }">
                    <input v-model="v$.disaster_vendors.data_backup_vendor.$model" class="form-input location-input-box"
                        :class="{ 'form-error': v$.disaster_vendors.data_backup_vendor.$error }" type="text"
                        id="data_backup_vendor" name="data_backup_vendor"
                        :disabled="disaster_vendors.has_data_backup_vendor == true">
                    <label for="data_backup_vendor" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.data_backup_vendor }">Data Backup
                        Vendor</label>
                    <div v-if="v$.disaster_vendors.data_backup_vendor.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.data_backup_vendor.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 px5 mb-sm-10">
                <div class="relative"
                    :class="{ 'form-group--error': v$.disaster_vendors.data_backup_vendor_phone.$error }">
                    <input v-model="v$.disaster_vendors.data_backup_vendor_phone.$model"
                        :class="{ 'form-error': v$.disaster_vendors.data_backup_vendor_phone.$error }"
                        v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent class="form-input location-input-box" type="text"
                        id="data_backup_vendor_phone" name="data_backup_vendor_phone"
                        :disabled="disaster_vendors.has_data_backup_vendor == true">
                    <label for="data_backup_vendor_phone" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.data_backup_vendor_phone }">Phone
                        Number</label>
                    <div v-if="v$.disaster_vendors.data_backup_vendor_phone.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.data_backup_vendor_phone.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 px5 mb-sm-10">
                <div class="relative"
                    :class="{ 'form-group--error': v$.disaster_vendors.data_backup_vendor_location.$error }">
                    <multiselect v-model="v$.disaster_vendors.data_backup_vendor_location.$model" :options="options"
                        placeholder="" :class="{ 'form-error': v$.disaster_vendors.data_backup_vendor_location.$error }"
                        position="bottom" :taggable="false" :showLabels="false"
                        :disabled="disaster_vendors.has_data_backup_vendor == true">
                          <template #noResult>
                            <div class="multiselect__noResult text-center">
                              No results found
                            </div>
                          </template>
                    </multiselect>
                    <label class="label label-select"
                        :class="{ 'label-float': disaster_vendors.data_backup_vendor_location }">Data backup
                        location</label>
                    <div v-if="v$.disaster_vendors.data_backup_vendor_location.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.data_backup_vendor_location.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-2 col-xl-2 px5">
                <div class="flex items-center flex-wrap flex-auto mt10">
                    <div class="checkbox">
                        <input v-model="disaster_vendors.has_data_backup_vendor" id="has_data_backup_vendor"
                            name="has_data_backup_vendor" type="checkbox">
                        <label for="has_data_backup_vendor"
                            class="checkbox-label font-14 font-light gray_checkmark--text">Not
                            Applicable</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row flex flex-wrap -mx5 mb10 mb-sm-20">
            <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 px5 mb-sm-10">
                <div class="relative"
                    :class="{ 'form-group--error': v$.disaster_vendors.landlord_property_manager.$error }">
                    <input v-model="v$.disaster_vendors.landlord_property_manager.$model"
                        :class="{ 'form-error': v$.disaster_vendors.landlord_property_manager.$error }"
                        class="form-input location-input-box" type="text" id="landlord_property_manager"
                        name="landlord_property_manager"
                        :disabled="disaster_vendors.has_landlord_property_manager == true">
                    <label for="landlord_property_manager" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.landlord_property_manager }">Landlord/Property
                        Manager</label>
                    <div v-if="v$.disaster_vendors.landlord_property_manager.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.landlord_property_manager.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 px5 mb-sm-10">
                <div class="relative"
                    :class="{ 'form-group--error': v$.disaster_vendors.landlord_property_manager_phone.$error }">
                    <input v-model="v$.disaster_vendors.landlord_property_manager_phone.$model" v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent
                        :class="{ 'form-error': v$.disaster_vendors.landlord_property_manager_phone.$error }"
                        class="form-input location-input-box" type="text" id="landlord_property_manager_phone"
                        name="landlord_property_manager_phone"
                        :disabled="disaster_vendors.has_landlord_property_manager == true">
                    <label for="landlord_property_manager_phone" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.landlord_property_manager_phone }">Phone
                        Number</label>
                    <div v-if="v$.disaster_vendors.landlord_property_manager_phone.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.landlord_property_manager_phone.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-2 col-xl-2 px5">
                <div class="flex items-center flex-wrap flex-auto mt8">
                    <div class="checkbox">
                        <input v-model="disaster_vendors.has_landlord_property_manager"
                            id="has_landlord_property_manager" name="has_landlord_property_manager" type="checkbox">
                        <label for="has_landlord_property_manager"
                            class="checkbox-label font-14 font-light gray_checkmark--text">Not
                            Applicable</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row flex flex-wrap -mx5 mb10 mb-sm-20">
            <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 px5 mb-sm-10">
                <div class="relative"
                    :class="{ 'form-group--error': v$.disaster_vendors.practice_management_software.$error }">
                    <input v-model="v$.disaster_vendors.practice_management_software.$model"
                        :class="{ 'form-error': v$.disaster_vendors.practice_management_software.$error }"
                        class="form-input location-input-box" type="text" id="practice_management_software"
                        name="practice_management_software"
                        :disabled="disaster_vendors.has_practice_management_software == true">
                    <label for="practice_management_software" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.practice_management_software }">Practice
                        Management
                        Software</label>
                    <div v-if="v$.disaster_vendors.practice_management_software.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.practice_management_software.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 px5 mb-sm-10">
                <div class="relative"
                    :class="{ 'form-group--error': v$.disaster_vendors.practice_management_software_phone.$error }">
                    <input v-model="v$.disaster_vendors.practice_management_software_phone.$model" v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent
                        :class="{ 'form-error': v$.disaster_vendors.practice_management_software_phone.$error }"
                        class="form-input location-input-box" type="text" id="practice_management_software_phone"
                        name="practice_management_software_phone"
                        :disabled="disaster_vendors.has_practice_management_software == true">
                    <label for="practice_management_software_phone" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.practice_management_software_phone }">Phone
                        Number</label>
                    <div v-if="v$.disaster_vendors.practice_management_software_phone.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.practice_management_software_phone.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-2 col-xl-2 px5">
                <div class="flex items-center flex-wrap flex-auto mt8">
                    <div class="checkbox">
                        <input v-model="disaster_vendors.has_practice_management_software"
                            id="has_practice_management_software" name="has_practice_management_software"
                            type="checkbox">
                        <label for="has_practice_management_software"
                            class="checkbox-label font-14 font-light gray_checkmark--text">Not
                            Applicable</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row flex flex-wrap -mx5 mb10 mb-sm-20">
            <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 px5 mb-sm-10">
                <div class="relative" :class="{ 'form-group--error': v$.disaster_vendors.ehr_software.$error }">
                    <input v-model="v$.disaster_vendors.ehr_software.$model" class="form-input location-input-box"
                        :class="{ 'form-error': v$.disaster_vendors.ehr_software.$error }" type="text" id="ehr_software"
                        name="ehr_software" :disabled="disaster_vendors.has_ehr_software == true">
                    <label for="ehr_software" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.ehr_software }">EHR Software</label>
                    <div v-if="v$.disaster_vendors.ehr_software.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.ehr_software.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 px5 mb-sm-10">
                <div class="relative" :class="{ 'form-group--error': v$.disaster_vendors.ehr_software_phone.$error }">
                    <input v-model="v$.disaster_vendors.ehr_software_phone.$model" class="form-input location-input-box"
                        :class="{ 'form-error': v$.disaster_vendors.ehr_software_phone.$error }" type="text"
                        id="ehr_software_phone" name="ehr_software_phone" v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent
                        :disabled="disaster_vendors.has_ehr_software == true">
                    <label for="ehr_software_phone" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.ehr_software_phone }">Phone Number</label>
                    <div v-if="v$.disaster_vendors.ehr_software_phone.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.ehr_software_phone.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-2 col-xl-2 px5">
                <div class="flex items-center flex-wrap flex-auto mt8">
                    <div class="checkbox">
                        <input v-model="disaster_vendors.has_ehr_software" id="has_ehr_software" name="has_ehr_software"
                            type="checkbox">
                        <label for="has_ehr_software" class="checkbox-label font-14 font-light gray_checkmark--text">Not
                            Applicable</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row flex flex-wrap -mx5 mb10 mb-sm-20">
            <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 px5 mb-sm-10">
                <div class="relative" :class="{ 'form-group--error': v$.disaster_vendors.it_vendor.$error }">
                    <input v-model="v$.disaster_vendors.it_vendor.$model" class="form-input location-input-box" type="text"
                        :class="{ 'form-error': v$.disaster_vendors.it_vendor.$error }" id="it_vendor" name="it_vendor"
                        :disabled="disaster_vendors.has_it_vendor == true">
                    <label for="it_vendor" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.it_vendor }">IT Vendor</label>
                    <div v-if="v$.disaster_vendors.it_vendor.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.it_vendor.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 px5 mb-sm-10">
                <div class="relative" :class="{ 'form-group--error': v$.disaster_vendors.it_vendor_phone.$error }">
                    <input v-model="v$.disaster_vendors.it_vendor_phone.$model" class="form-input location-input-box"
                        :class="{ 'form-error': v$.disaster_vendors.it_vendor_phone.$error }" type="text"
                        id="it_vendor_phone" name="it_vendor_phone" v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent
                        :disabled="disaster_vendors.has_it_vendor == true">
                    <label for="it_vendor_phone" class="label location-input-label"
                        :class="{ 'label-float': disaster_vendors.it_vendor_phone }">Phone Number</label>
                    <div v-if="v$.disaster_vendors.it_vendor_phone.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.disaster_vendors.it_vendor_phone.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-lg-2 col-xl-2 px5">
                <div class="flex items-center flex-wrap flex-auto mt8">
                    <div class="checkbox">
                        <input v-model="disaster_vendors.has_it_vendor" id="has_it_vendor" name="has_it_vendor"
                            type="checkbox">
                        <label for="has_it_vendor" class="checkbox-label font-14 font-light gray_checkmark--text">Not
                            Applicable</label>
                    </div>
                </div>
            </div>
        </div>

        <transition-group name="simple-fade-transition">
            <div class="row flex flex-wrap -mx5 mb10 mb-sm-20"
                v-for="(vendor, index) in disaster_add_vendors" :key="'key' + index">
                <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 px5 mb-sm-10">
                    <div class="relative" :class="{ 'form-group--error': v$.disaster_add_vendors.$each.$response.$errors[index].vendor_responsibility.length > 0 }">
                        <input v-model="vendor.vendor_responsibility"
                            :class="{ 'form-error': v$.disaster_add_vendors.$error && v$.disaster_add_vendors.$each.$response.$errors[index].vendor_responsibility.length > 0 }"
                            class="form-input location-input-box" type="text" id="vendor_responsibility"
                            name="vendor_responsibility">
                        <label class="label label-select"
                            :class="{ 'label-float': vendor.vendor_responsibility }">Vendor
                            Responsibility</label>
                        <div v-if="v$.disaster_add_vendors.$error && v$.disaster_add_vendors.$each.$response.$errors[index].vendor_responsibility.length > 0">
                            <div class="form-error-text">{{ v$.disaster_add_vendors.$each.$response.$errors[index].vendor_responsibility[0].$message }}</div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 px5 mb-sm-10">
                    <div class="relative" :class="{ 'form-group--error': v$.disaster_add_vendors.$each.$response.$errors[index].vendor_name.length > 0 }">
                        <input v-model="vendor.vendor_name" class="form-input location-input-box"
                            :class="{ 'form-error': v$.disaster_add_vendors.$error && v$.disaster_add_vendors.$each.$response.$errors[index].vendor_name.length > 0 }" type="text" id="vendor_name"
                            name="vendor_name">
                        <label for="vendor_name" class="label location-input-label"
                            :class="{ 'label-float': vendor.vendor_name }">Vendor Name</label>
                        <div v-if="v$.disaster_add_vendors.$error && v$.disaster_add_vendors.$each.$response.$errors[index].vendor_name.length > 0">
                            <div class="form-error-text">{{ v$.disaster_add_vendors.$each.$response.$errors[index].vendor_name[0].$message }}</div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 px5 mb-sm-10">
                    <div class="relative" :class="{ 'form-group--error': v$.disaster_add_vendors.$each.$response.$errors[index].vendor_phone.length > 0 }">
                        <input v-model="vendor.vendor_phone"
                            :class="{ 'form-error': v$.disaster_add_vendors.$error && v$.disaster_add_vendors.$each.$response.$errors[index].vendor_phone.length > 0 }"
                            v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent
                            class="form-input location-input-box" type="text" id="vendor_phone" name="vendor_phone">
                        <label for="vendor_phone" class="label location-input-label"
                            :class="{ 'label-float': vendor.vendor_phone }">Phone
                            Number</label>
                        <div v-if="v$.disaster_add_vendors.$error && v$.disaster_add_vendors.$each.$response.$errors[index].vendor_phone.length > 0">
                            <div class="form-error-text">{{ v$.disaster_add_vendors.$each.$response.$errors[index].vendor_phone[0].$message }}</div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-2 col-xl-2 px5">
                    <div class="flex items-center flex-wrap flex-auto">
                        <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml7">
                            <button @click="showDeleteVendorToggle(index, vendor)" :disabled="disabled" type="button"
                                class="delete-location-btn cursor-pointer">
                                <img :src="JS_APP_URL + '/images/bin.svg'" alt="" title="">
                            </button>
                            <template #popper>
                                Delete
                            </template>
                        </VTooltip>
                    </div>
                </div>
            </div>
        </transition-group>

        <delete-vendor-modal v-if="show_vendor_delete_modal" @close-model="hideDeleteVendorToggle"
            @delete-vendor="deleteVendor"></delete-vendor-modal>
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, requiredIf, maxLength, minLength, helpers } from "@vuelidate/validators";
import deleteVendorModal from "./deleteVendorModal.vue";
import { checkSpecialChars, checkSpecialCharsErrorMessage } from "../common/customValidation";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            options: ['Cloud/Hosted', 'Offsite', 'Onsite', 'Not Applicable'],
            checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
            show_vendor_delete_modal: false,
            delete_vendor_id: undefined,
            disabled: false
        }
    },
    setup: () => ({ v$: useVuelidate() }),
    props: {
        disaster_vendors: {
            type: Object
        },
        disaster_add_vendors: {
            type: Array
        },
        location_id: {
            type: Number
        }
    },
    watch: {
        location_id(val) {
            this.resetForm();
        },
        "disaster_vendors.has_alarm_system_company"() {
            this.disaster_vendors.alarm_system_company = "";
            this.disaster_vendors.alarm_system_company_phone = "";
            this.v$.disaster_vendors.alarm_system_company.$reset()
            this.v$.disaster_vendors.alarm_system_company_phone.$reset()
        },
        "disaster_vendors.has_data_backup_vendor"() {
            this.disaster_vendors.data_backup_vendor = ""
            this.disaster_vendors.data_backup_vendor_phone = ""
            this.disaster_vendors.data_backup_vendor_location = ""
            this.v$.disaster_vendors.data_backup_vendor.$reset()
            this.v$.disaster_vendors.data_backup_vendor_phone.$reset()
            this.v$.disaster_vendors.data_backup_vendor_location.$reset()
        },
        "disaster_vendors.has_ehr_software"() {
            this.disaster_vendors.ehr_software = ""
            this.disaster_vendors.ehr_software_phone = ""
            this.v$.disaster_vendors.ehr_software.$reset()
            this.v$.disaster_vendors.ehr_software_phone.$reset()
        },
        "disaster_vendors.has_it_vendor"() {
            this.disaster_vendors.it_vendor = ""
            this.disaster_vendors.it_vendor_phone = ""
            this.v$.disaster_vendors.it_vendor.$reset()
            this.v$.disaster_vendors.it_vendor_phone.$reset()
        },
        "disaster_vendors.has_landlord_property_manager"() {
            this.disaster_vendors.landlord_property_manager = ""
            this.disaster_vendors.landlord_property_manager_phone = ""
            this.v$.disaster_vendors.landlord_property_manager.$reset()
            this.v$.disaster_vendors.landlord_property_manager_phone.$reset()
        },
        "disaster_vendors.has_practice_management_software"() {
            this.disaster_vendors.practice_management_software = ""
            this.disaster_vendors.practice_management_software_phone = ""
            this.v$.disaster_vendors.practice_management_software.$reset()
            this.v$.disaster_vendors.practice_management_software_phone.$reset()
        }
    },
     validations() {
        return {
        disaster_vendors: {
            alarm_system_company: {
                requiredIf: helpers.withMessage("Please enter an alarm system company name",
                    requiredIf(() => {
                      return this.disaster_vendors.has_alarm_system_company == false
                })),
                maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            alarm_system_company_phone: {
                requiredIf: helpers.withMessage("Please enter an alarm system company phone number",
                    requiredIf(() => {
                    return this.disaster_vendors.has_alarm_system_company == false
                })),
                minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
                maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
            },
            data_backup_vendor: {
                requiredIf: helpers.withMessage("Please enter a data backup vendor name",
                    requiredIf(() => {
                        return this.disaster_vendors.has_data_backup_vendor == false
                })),
                maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            data_backup_vendor_phone: {
                requiredIf: helpers.withMessage("Please enter a data backup vendor phone number",
                    requiredIf(() => {
                        return this.disaster_vendors.has_data_backup_vendor == false
                })),
                minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
                maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
            },
            data_backup_vendor_location: {
                requiredIf: helpers.withMessage("Please select a data backup vendor location",
                    requiredIf(() => {
                        return this.disaster_vendors.has_data_backup_vendor == false
                })),
            },
            landlord_property_manager: {
                requiredIf: helpers.withMessage("Please enter a landlord/property manager name",
                    requiredIf(() => {
                        return this.disaster_vendors.has_landlord_property_manager == false
                })),
                maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            landlord_property_manager_phone: {
                requiredIf: helpers.withMessage("Please enter a landlord/property manager phone number",
                    requiredIf(() => {
                        return this.disaster_vendors.has_landlord_property_manager == false
                })),
                minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
                maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
            },
            practice_management_software: {
                requiredIf: helpers.withMessage("Please enter a practice management software name",
                    requiredIf(() => {
                        return this.disaster_vendors.has_practice_management_software == false
                })),
                maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            practice_management_software_phone: {
                maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
                minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
            },
            ehr_software: {
                requiredIf: helpers.withMessage("Please enter an EHR software name",
                    requiredIf(() => {
                        return this.disaster_vendors.has_ehr_software == false
                })),
                maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            ehr_software_phone: {
                requiredIf: helpers.withMessage("Please enter an EHR software phone number",
                    requiredIf(() => {
                        return this.disaster_vendors.has_ehr_software == false
                })),
                maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
                minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
            },
            it_vendor: {
                requiredIf: helpers.withMessage("Please enter an IT vendor name",
                    requiredIf(() => {
                        return this.disaster_vendors.has_it_vendor == false
                })),
                maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            it_vendor_phone: {
                requiredIf: helpers.withMessage("Please enter an IT vendor phone number",
                    requiredIf(() => {
                       return this.disaster_vendors.has_it_vendor == false
                })),
                maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
                minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
            }
        },
        disaster_add_vendors: {
            $each: helpers.forEach({
                vendor_name: {
                    required: helpers.withMessage('Please enter vendor name', required),
                    maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
                    checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
                },
                vendor_phone: {
                    required: helpers.withMessage('Please enter vendor phone number', required),
                    minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
                    maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
                },
                vendor_responsibility: {
                    required: helpers.withMessage('Please enter vendor responsibility', required),
                    maxLength: helpers.withMessage(' Max 200 characters allowed', maxLength(200)),
                    checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
                },
            })
        }
      }
    },
    components: {
        deleteVendorModal,
    },
    emits: ["delete-vendor-org"],
    methods: {
        isInvalid() {
            this.v$.$touch();
            return this.v$.$invalid;
        },
        resetForm() {
            this.v$.$reset();
        },
        deleteVendor() {
            if (this.delete_vendor_id) {
                NProgress.start();
                axios.delete(JS_APP_URL + "/disaster-recovery-plan/delete-disaster-vendor-manual-by-id/" + this.delete_vendor_id)
                    .then((response) => {
                        if (response["data"]["status"] == "Success") {
                            toastr.success(response["data"]["message"], "Success");
                            const index = this.disaster_add_vendors.findIndex((obj) => obj.id === this.delete_vendor_id);
                            this.disaster_add_vendors.splice(index, 1);
                            this.$emit("delete-vendor-org", index);
                        }
                    })
                    .catch((error) => {
                        toastr.error(error.response["data"]["message"], "Error");
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        NProgress.done();
                        this.hideDeleteVendorToggle();
                    })
            }
        },
        showDeleteVendorToggle(index, vendor) {
            // vendor.vendor_name.$reset();
            // vendor.vendor_phone.$reset();
            // vendor.vendor_responsibility.$reset();
            this.disabled = true
            this.timeout = setTimeout(() => {
                if (this.disaster_add_vendors[index]['id']) {
                    this.delete_vendor_id = this.disaster_add_vendors[index]['id'];
                    this.show_vendor_delete_modal = true;
                } else {
                    this.disaster_add_vendors.splice(index, 1);
                }
                this.disabled = false
            }, 100)
        },
        hideDeleteVendorToggle() {
            this.show_vendor_delete_modal = false;
        },
    }
}
</script>
