<template>
  <div class="pb30">
    <div class="user-detail-card py11 pl30 pr20 light mb10">
      <div class="row flex-auto -mx-10 items-center ">
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div class="font-14 font_semibold dark--text pb1">  Alarm System Company</div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">          
          <div
            class="
              user-detail-text
              font-14
              dark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.alarm_system_company != null && disaster_vendors.alarm_system_company != '' ? disaster_vendors.alarm_system_company : "N/A" }}
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div
            class="
              user-detail-text
              font-14
              gray_checkmark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.alarm_system_company_phone != null  && disaster_vendors.alarm_system_company_phone != '' ? disaster_vendors.alarm_system_company_phone : "N/A" }}
          </div>
        </div>
      </div>
    </div>
    <div class="user-detail-card py11 pl30 pr20 light mb10">
      <div class="row flex-auto -mx-10 items-center ">
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div class="font-14 font_semibold dark--text pb1"> Data Backup Vendor</div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div
            class="
              user-detail-text
              font-14
              dark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.data_backup_vendor != null && disaster_vendors.data_backup_vendor != '' ? disaster_vendors.data_backup_vendor : "N/A" }}
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div
            class="
              user-detail-text
              font-14
              gray_checkmark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.data_backup_vendor_phone != null && disaster_vendors.data_backup_vendor_phone != '' ? disaster_vendors.data_backup_vendor_phone : "N/A" }}
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div
            class="
              user-detail-text
              font-14
              gray_checkmark--text
              mb-md-10 mb-sm-10
            "
          >
            <button type="button" class="user-location-icon" v-if="disaster_vendors.data_backup_vendor_location">
              <VTooltip
                :triggers="['hover']"
                :popperTriggers="['hover']"
              >
                <img
                  :src="JS_APP_URL + '/images/location.svg'"
                  alt=""
                  title=""
                  class="cursor-pointer"
                />
                <template #popper>
                  <div
                    class="white--text font-12 font_semibold mb2 text-center"
                  >
                    LOCATION
                  </div>
                  <div
                    class="text-center"
                    v-text="disaster_vendors.data_backup_vendor_location"
                  ></div>
                </template>
              </VTooltip>
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="user-detail-card py11 pl30 pr20 light mb10">
      <div class="row flex-auto -mx-10 items-center ">
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div class="font-14 font_semibold dark--text pb1">Landlord/Property Manager</div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">          
          <div
            class="
              user-detail-text
              font-14
              dark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.landlord_property_manager != null && disaster_vendors.landlord_property_manager != '' ? disaster_vendors.landlord_property_manager : "N/A" }}
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div
            class="
              user-detail-text
              font-14
              gray_checkmark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.landlord_property_manager_phone != null && disaster_vendors.landlord_property_manager_phone != '' ? disaster_vendors.landlord_property_manager_phone : "N/A" }}
          </div>
        </div>
      </div>
    </div>
    <div class="user-detail-card py11 pl30 pr20 light mb10">
      <div class="row flex-auto -mx-10 items-center ">
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div class="font-14 font_semibold dark--text pb1">Practice  Management Software</div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">          
          <div
            class="
              user-detail-text
              font-14
              dark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.practice_management_software != null && disaster_vendors.practice_management_software != '' ? disaster_vendors.practice_management_software : "N/A" }}
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div
            class="
              user-detail-text
              font-14
              gray_checkmark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.practice_management_software_phone != null && disaster_vendors.practice_management_software_phone != '' ? disaster_vendors.practice_management_software_phone : "N/A" }}
          </div>
        </div>
      </div>
    </div>
    <div class="user-detail-card py11 pl30 pr20 light mb10">
      <div class="row flex-auto -mx-10 items-center ">
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div class="font-14 font_semibold dark--text pb1">EHR Software</div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">          
          <div
            class="
              user-detail-text
              font-14
              dark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.ehr_software != null && disaster_vendors.ehr_software != '' ? disaster_vendors.ehr_software : "N/A" }}
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div
            class="
              user-detail-text
              font-14
              gray_checkmark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.ehr_software_phone != null && disaster_vendors.ehr_software_phone != '' ? disaster_vendors.ehr_software_phone : "N/A" }}
          </div>
        </div>
      </div>
    </div>
    <div class="user-detail-card py11 pl30 pr20 light mb10">
      <div class="row flex-auto -mx-10 items-center ">
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div class="font-14 font_semibold dark--text pb1">IT Vendor</div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">          
          <div
            class="
              user-detail-text
              font-14
              dark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.it_vendor && disaster_vendors.it_vendor != '' != null ? disaster_vendors.it_vendor : "N/A" }}
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
          <div
            class="
              user-detail-text
              font-14
              gray_checkmark--text
              mb-md-10 mb-sm-10
            "
          >
            {{ disaster_vendors.it_vendor_phone != null && disaster_vendors.it_vendor_phone != '' ? disaster_vendors.it_vendor_phone : "N/A" }}
          </div>
        </div>
      </div>
    </div>
    <div v-if="disaster_add_vendors.length > 0">
      <div
        class="user-detail-card py11 pl30 pr20 light mb10"
        v-for="(manual, index) in disaster_add_vendors"
        :key="index"
      >
        <div class="row flex-auto -mx-10">
          <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
            <div
              class="
                user-detail-text
                font-14
                dark--text
                font_semibold
                mb-md-10 mb-sm-10
              "
            >
             {{ manual.vendor_responsibility }}
            </div>
          </div>
          <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
            <div
              class="
                user-detail-text
                font-14
                dark--text
                mb-md-10 mb-sm-10
              "
            >
              {{ manual.vendor_name }}
            </div>
          </div>
          <div class="col-12 col-md-6 col-lg-4 col-xl-3 px10">
            <div
              class="
                user-detail-text
                font-14
                gray_checkmark--text
                mb-md-10 mb-sm-10
              "
            >
              {{ manual.vendor_phone }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script scoped>
export default {
  props: {
    disaster_vendors: {
      type: Object,
    },
    disaster_add_vendors: {
      type: Array,
    },
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
    };
  },
};
</script>