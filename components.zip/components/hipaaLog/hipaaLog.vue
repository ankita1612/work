<template>
    <div>
        <header-after-login></header-after-login>
        <div class="container pt40 pb20">
            <div
                class="flex justify-center flex-wrap mb8 relative"
                v-if="all_location_list.length > 1"
            >
                <div class="col-12 col-sm-8 col-md-8 col-lg-6 col-xl-3">
                    <div class="form-group mb-0 location-dropdon mlr-auto">
                        <multiselect
                            class="company-location-select"
                            v-model="selected_location"
                            :options="all_location_list"
                            label="location_nickname"
                            :taggable="false"
                            :multiple="false"
                            :close-on-select="true"
                            :showLabels="false"
                            track-by="id"
                            placeholder=""
                            :allowEmpty="false"
                            @update:model-value="changeLocation"
                        >
                            <template #noResult>
                                <div class="multiselect__noResult text-center">
                                    No results found
                                </div>
                            </template>
                        </multiselect>
                        <label class="label label-select label-float"
                            >Location</label
                        >
                    </div>
                </div>
            </div>
            <h1
                class="location-dashbaord-title text-center font-24 font_semibold blueog--text line-normal mb15 mb-sm-10 mb-md-10"
            >
                HIPAA Logs
            </h1>
        </div>
        <div class="training-tabs-wrapper pb50">
            <div class="training-tab-nav">
                <div
                    class="container flex items-center justify-between flex-wrap"
                >
                    <button
                        type="button"
                        class="training-tab-nav-item font-21"
                        v-on:click="changeLogTab('breachlog')"
                        :class="{ active: current_log_tab == 'breachlog' }"
                    >
                        Breach Log
                    </button>
                    <button
                        type="button"
                        class="training-tab-nav-item sharp-tab-item font-21"
                        v-on:click="changeLogTab('assetlog')"
                        :class="{ active: current_log_tab == 'assetlog' }"
                    >
                        Asset Log
                    </button>
                    <button
                        type="button"
                        class="training-tab-nav-item sharp-tab-item font-21"
                        v-on:click="changeLogTab('accesslog')"
                        :class="{ active: current_log_tab == 'accesslog' }"
                    >
                        Access Log
                    </button>
                </div>
            </div>
            <access-log
                v-if="current_log_tab == 'accesslog'"
                :selected_location_id="selected_location_id"
            />
            <asset-log 
                 v-if="current_log_tab == 'assetlog'"
                :selected_location_id="selected_location_id"    
            />
            <breach-log
                v-if="current_log_tab == 'breachlog'"
                :selected_location_id="selected_location_id"
                :all_location_list = "all_location_list"
            />
        </div>
    </div>
</template>
<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import plusIcon from "../common/icons/plusIcon.vue";
import infoIcon from "../common/icons/infoIcon.vue";
import accessLog from "./accessLog/accessLog.vue";
import breachLog from "./breachlog/breachLog.vue";
import assetLog from "./assetLog/assetLog.vue";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_CURRENT_TAB: JS_CURRENT_TAB,
            current_log_tab: "",
            selected_location_id: parseInt(JS_LOCATION_ID),
            all_location_list: [],
            selected_location: {},
        };
    },
    components: {
        headerAfterLogin,
        plusIcon,
        infoIcon,
        accessLog,
        breachLog,
        assetLog
    },
    mounted() {
        if(this.JS_CURRENT_TAB == 'assetlog'){
            this.current_log_tab = 'assetlog';
        }else if(this.JS_CURRENT_TAB == 'accesslog'){
            this.current_log_tab = 'accesslog';
        }else{
            this.current_log_tab = 'breachlog';
        }
        this.loadLocationNicknameList();
    },
    methods: {
        changeLogTab(log_type) {
            if (this.current_log_tab != log_type) {
                this.current_log_tab = log_type;
            } else {
                return false;
            }
        },
        loadLocationNicknameList() {
            axios
                .get(JS_APP_URL + "/general/get-assigned-location-list")
                .then((response) =>  {
                    if (response["data"]["status"] == "Success") {
                        this.all_location_list = response["data"]["data"];
                        this.selected_location = this.all_location_list.find(
                            (object) => object.id === this.selected_location_id
                        );
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                });
        },
        changeLocation() {
            this.selected_location_id = this.selected_location.id;
        },
    },
};
</script>
