<template>
    <div class="training-tab-content pt40">
        <div class="container">
            <div class="flex flex-wrap flex-auto items-center mb20">
                <h6 class="font-18 blueog--text mb0 mr10">
                    Breach Incident Report Log
                </h6>
                <VTooltip
                    :triggers="['hover']"
                    :popperTriggers="['hover']"
                    style="height: 24px"
                    class="cursor-pointer"
                >
                    <span><info-icon></info-icon></span>
                    <template #popper>
                        If your practice has experienced a data breach complete
                        the Incident Log below to document the breach and assess
                        the likelihood data will be misused. The Incident Log is
                        for internal use only and will not be shared outside of
                        your organization. Keep in mind the Incident Log can be
                        used for potential breaches as well, even if you do not
                        plan to report the incident.
                    </template>
                </VTooltip>
                <button
                    v-on:click="toggleAddBreachLogForm()"
                    type="button"
                    class="plus-icon-btn ml3 mt1"
                >
                    <plus-icon></plus-icon>
                </button>
                <VTooltip
                    :triggers="['hover']"
                    :popperTriggers="['hover']"
                    v-if="is_refresh_btn_shown"
                >
                    <a
                        v-on:click="resetAndLoadLatestData()"
                        class="font-12 blueog--text ml10 font-italic font_semibold cursor-pointer d-block text-right"
                    >
                        <img :src="JS_APP_URL + '/images/refresh-list.png'" />
                    </a>
                    <template #popper> Refresh Breach Log List </template>
                </VTooltip>
            </div>
            <!-- -1 breach log -->
            <add-breach-log
                v-if="is_add_breach_log_form_show"
                @add-breach-log-form-toggle="cancelBreachLogForm"
                @toggle-add-form-on-change-location="
                    toggleAddFormOnChangeLocation
                "
                :PHI_type_list="all_PHI_type"
                :selected_location_id="location_id"
                :incident_reporter_data="incident_reporter"
                @load-breach-log-list="loadBreachLogList"
                @toggle-incident-risk-assessment-modal="
                    toggleIncidentRiskAssessmentModal
                "
            />

            <div class="breach-log-listing">
                <!-- filter breach log -->
                <div class="row flex-auto justify-end items-center -mx-10 mb20">      
                    <div class="col-12 col-sm-6 col-md-8 col-lg-9 col-xl-10 px10" v-if="show_link">
                      <p style="text-align: right;"  class="gray_checkmark--text">Looking for logs from previous years? Click <a :href="archive_url" class="text-decoration-underline">Here</a></p>
                    </div>
                    <div
                        class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 px10"
                    >
                        <div class="flex items-center">
                            <div
                                class="form-group account-filter-wrapper mb-0 flex-auto"
                            >
                                <multiselect
                                    v-model="sort_by"
                                    :options="sort_by_options"
                                    :close-on-select="true"
                                    label="name"
                                    placeholder=""
                                    track-by="id"
                                    @update:model-value="applyBreachLogSort"
                                    :searchable="false"
                                    :showLabels="false"
                                    :taggable="false"
                                >
                                    <template #noResult>
                                        <div class="multiselect__noResult text-center">
                                            No results found
                                        </div>
                                    </template>
                                    <template #noOptions>
                                        <div class="multiselect__noOptions text-center">
                                            No data available
                                        </div>
                                    </template>
                                </multiselect>
                                <label
                                    class="label label-select"
                                    :class="{
                                        'label-float': sort_by,
                                    }"
                                    >Sort by</label
                                >
                            </div>
                            <img
                                v-on:click="toggleSortDir"
                                v-if="sort_by && sort_by_dir == 'ASC'"
                                :src="JS_APP_URL + '/images/sort-up.svg'"
                                alt=""
                                title=""
                                class="cursor-pointer sort-arrow ml5"
                            />
                            <img
                                v-on:click="toggleSortDir"
                                v-if="sort_by && sort_by_dir == 'DESC'"
                                :src="JS_APP_URL + '/images/sort-down.svg'"
                                alt=""
                                title=""
                                class="cursor-pointer sort-arrow ml5"
                            />
                        </div>
                    </div>
                </div>
                <!-- breachlog items -->
                <div>
                    <breach-log-item
                        v-for="(breach_log, index) in breach_log_list"
                        v-bind:key="index"
                        :breach_log_item="breach_log"
                        :PHI_type_list="all_PHI_type"
                        :selected_location_id="location_id"
                        :incident_reporter_data="incident_reporter"
                        :location_list="all_location_list"
                        @full-loader="toggleFullLoader"
                        @load-updated-breach-log-data="loadUpdatedBreachLogData"
                        @toggle-incident-risk-assessment-modal="
                            toggleIncidentRiskAssessmentModal
                        "
                    />
                    <div
                        v-if="
                            !is_full_page_loader_shown &&
                            breach_log_list.length === 0
                        "
                        class=""
                    >
                        <div
                            class="user-detail-text font-14 gray_checkmark--text text-center light pt20 pb20"
                        >
                            <no-data-icon></no-data-icon>
                            <div class="font-14 text-center blueog--text">
                                No breach log(s) available.
                            </div>
                        </div>
                    </div>
                </div>
                 <InfiniteLoading @infinite="loadBreachLogList(false)" />
            </div>
            <incident-risk-assessment-modal
                v-if="is_show_incident_risk_assessment_modal"
                @close-model="toggleIncidentRiskAssessmentModal"
                @incident-risk-assessment-quiz="incidentRiskAssessmentQuiz"
            ></incident-risk-assessment-modal>
            <full-page-loader
                v-if="is_full_page_loader_shown"
            ></full-page-loader>
        </div>
    </div>
</template>

<script>
import pdfIcon from "../../common/icons/pdfIcon.vue";
import plusIcon from "../../common/icons/plusIcon.vue";
import infoIcon from "../../common/icons/infoIcon.vue";
import fullPageLoader from "../../common/fullPageLoader.vue";
import addBreachLog from "./addBreachLog.vue";
import breachLogItem from "./breachLogItem.vue";
import noDataIcon from "../../common/icons/noDataIcon.vue";
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import IncidentRiskAssessmentModal from "./incidentRiskAssessmentModal.vue";
toastr.options.preventDuplicates = true;
import _ from "lodash";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_add_breach_log_form_show: false,
            breach_log_list: [],
            is_list_loading: false,
            per_page_records: 10,
            current_page: 1,
            total_page: 1,
            is_full_page_loader_shown: false,
            all_PHI_type: [],
            incident_reporter: [],
            ra_attempt_questions: [],
            sort_by: "",
            sort_by_dir: "ASC",
            show_link: false,
            sort_by_options: [
                {
                    id: "incident_reporter_name",
                    name: "Reporters Name",
                },
                { id: "type_of_incident", name: "Type of Incident" },
                {
                    id: "individuals_affected",
                    name: "# of Individuals Affected",
                },
            ],
            location_id: this.selected_location_id,
            is_show_incident_risk_assessment_modal: false,
            breach_log_data_for_quiz: undefined,
            is_refresh_btn_shown: false,
            archive_url: null,
            call_ajax: 1,
        };
    },
    components: {
        pdfIcon,
        plusIcon,
        infoIcon,
        addBreachLog,
        breachLogItem,
        noDataIcon,
        fullPageLoader,
        IncidentRiskAssessmentModal,
    },
    props: {
        selected_location_id: {
            type: Number,
            default: () => {},
        },
        all_location_list: {
            type: Array,
            default: () => [],
        },
    },
    watch: {
        selected_location_id(newVal, oldVal) {
            this.location_id = newVal;
            this.resetAndLoadLatestData();
            this.checkPreviousBreachReport()
        },
    },
    mounted() {
        this.loadPHIList();
        this.checkPreviousBreachReport()
    },
    methods: {
        showRefreshListButton() {
            if (this.sort_by) {
                this.is_refresh_btn_shown = true;
            }
        },
        resetAndLoadLatestData() {
            this.sort_by = "";
            this.sort_by_dir = "ASC";
            this.loadBreachLogList(true);
        },
        loadUpdatedBreachLogData(updated_breach_log = {}) {
            if (!_.isEmpty(updated_breach_log)) {
                let found_index = _.findIndex(this.breach_log_list, (o) => {
                    return o.id === updated_breach_log.id;
                });
                if (found_index >= 0) {
                    this.breach_log_list[found_index] = updated_breach_log;
                    
                    this.showRefreshListButton();
                }
            }
        },
        toggleAddBreachLogForm() {
            this.is_add_breach_log_form_show =
                !this.is_add_breach_log_form_show;
        },
        cancelBreachLogForm(status = true) {
            this.is_add_breach_log_form_show = status;
        },
        toggleAddFormOnChangeLocation(status = true) {
            if (this.all_location_list.length == 0) {
                this.is_add_breach_log_form_show = status;
                this.is_add_breach_log_form_show = true;
            } else {
                this.is_add_breach_log_form_show = status;
            }
        },
        toggleSortDir() {
            this.sort_by_dir = this.sort_by_dir == "ASC" ? "DESC" : "ASC";
            this.loadBreachLogList(true);
        },
        applyBreachLogSort() {
            setTimeout(() => {
                this.loadBreachLogList(true);
            }, 100);
        },
        loadBreachLogList(need_pagination_reset = false) {
            if (need_pagination_reset) {
                this.current_page = 1;
                this.total_page = 1;
                this.breach_log_list = [];
            }
            if (this.current_page <= this.total_page && this.call_ajax == 1) {
                this.is_list_loading = true;
                this.is_full_page_loader_shown = true;
                this.call_ajax = 0;
                axios
                    .post(
                        JS_APP_URL + `/hipaa-logs/get-breachlog-by-location-id`,
                        {
                            location_id: this.location_id,
                            per_page: this.per_page_records,
                            page: this.current_page,
                            sort_by: this.sort_by ? this.sort_by.id : "",
                            sort_by_dir: this.sort_by_dir,
                        }
                    )
                    .then((response) =>  {
                        if (response["data"]["status"] == "Success") {
                            let breach_log_list_data = response.data.data;
                            this.breach_log_list.push(
                                ...breach_log_list_data.data
                            );
                            this.total_page = breach_log_list_data.last_page;
                            this.breach_log_list.length == 0
                                ? (this.is_add_breach_log_form_show = true)
                                : "";
                            this.current_page = this.current_page + 1;
                            this.is_list_loading = false;
                            this.is_refresh_btn_shown = false;
                        }else{
                            window.location = JS_APP_URL + "/dashboard";
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        setTimeout(() => {
                            this.call_ajax = 1;
                            this.is_full_page_loader_shown = false;
                        }, 100);
                    });
            }
        },
        loadPHIList() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/hipaa-logs/get-phi-type-list")
                .then((response) =>  {
                    if (response.data.status == "Success") {
                        this.all_PHI_type = response.data.data;
                    }
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    setTimeout(() => {
                        this.loadIncidentReporterList();
                    }, 100);
                });
        },
        loadIncidentReporterList() {
            axios
                .get(JS_APP_URL + "/hipaa-logs/get-incident-reporter-list")
                .then((response) =>  {
                    if (response.data.status == "Success") {
                        this.incident_reporter = response.data.data;
                    }
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {});
        },
        checkPreviousBreachReport() {
            axios
                .get(JS_APP_URL + "/hipaa-logs/check-previous-breach-log?location_id="+this.location_id)
                .then((response) =>  {
                    if (response.data.status == "Success" ) {
                        if (response.data.data !== null){
                            let folder_id = response.data.data.archive_folder_id
                            let parent_id = response.data.data.abyde_drive_archive_folder.parent_folder_id
                            this.archive_url = JS_APP_URL + "/abyde-drive?location_id="+ this.location_id + "&folder_id="+ folder_id + "&parent_id="+parent_id
                            this.show_link = true
                        }
                        else{
                            this.show_link = false
                        }

                    }
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {});
        },
        toggleFullLoader(status = true) {
            this.is_full_page_loader_shown = status;
        },
        toggleIncidentRiskAssessmentModal(
            status = false,
            data = undefined,
            call_from = ""
        ) {
            if (data) {
                this.breach_log_data_for_quiz = data;
            }
            if (call_from == "add") {
                this.toggleAddBreachLogForm();
                this.resetAndLoadLatestData();
                setTimeout(() => {
                    this.is_show_incident_risk_assessment_modal = status;
                }, 500);
            } else {
                this.is_show_incident_risk_assessment_modal = status;
            }
        },
        incidentRiskAssessmentQuiz() {
            this.is_show_incident_risk_assessment_modal = false;
            setTimeout(() => {
                window.location =
                    JS_APP_URL +
                    "/hipaa-logs/breach-log-quiz/" +
                    btoa(this.breach_log_data_for_quiz.id);
            }, 200);
        },
    },
    created(){
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.is_add_breach_log_form_show = false;
            }
        });
    },
};
</script>
