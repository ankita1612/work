<template>
    <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask">
                <div class="modal-wrapper animate__animated animate__zoomIn">
                    <div class="modal-container Whoa-modal">
                        <button
                            v-if="!is_btn_disabled"
                            v-on:click="closeModal"
                            class="cursor-pointer modal-close"
                        >
                            <close-icon></close-icon>
                        </button>
                        <div class="text-center mlr-auto mb10 pt20">
                            <img
                                :src="JS_APP_URL + '/images/warning.svg'"
                                alt=""
                                title=""
                                class="warning-icon-modal"
                            />
                        </div>
                        <h2
                            class="font-24 font_semibold blueog--text line-normal text-center mb20"
                        >
                            Are you sure?
                        </h2>
                        <p
                            class="text-center font-16 gray_checkmark--text line-normal mb30"
                        >
                            Making changes to your Breach Report will require you to
                            complete a new Breach Assessment. Are you sure you'd like
                            to proceed?
                        </p>
                        <div
                            class="flex flex-wrap items-center justify-center pb40"
                        >
                            <button
                                :disabled="is_btn_disabled"
                                v-on:click="updateBreachLog"
                                class="btn-primary-outline btn-width-140 mx5 px30 mt-xs-20"
                            >
                                YES
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </Teleport>
</template>

<script scoped>
import closeIcon from "../../common/icons/closeIcon.vue";

export default {
    components: { closeIcon },
    data() {
        return {
            is_btn_disabled: false,
            JS_APP_URL: JS_APP_URL,
        };
    },
    emits: ["close-model", "update-breach-log"],
    methods: {
        closeModal() {
            this.$emit("close-model", false);
        },
        updateBreachLog() {
            this.is_btn_disabled = true;
            this.$emit("update-breach-log");
        },
    },
    created(){
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27 && !this.is_btn_disabled) {
                this.$emit("close-model", false);
            }
        });
    },
    destroyed() {},
};
</script>
