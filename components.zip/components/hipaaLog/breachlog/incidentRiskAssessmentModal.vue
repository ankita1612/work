<template>
    <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask">
            <div class="modal-wrapper animate__animated animate__zoomIn">
                <div class="modal-container Whoa-modal">
                <button v-on:click="closeModal" class="cursor-pointer modal-close">
                    <close-icon></close-icon>
                </button>
                <div class="text-center mlr-auto mb25 pt10">
                    <img :src="JS_APP_URL + '/images/clipboard.svg'" alt="" title="" class="warning-icon-modal" />
                </div>
                <h2
                    class="
                    font-24 font_semibold blueog--text line-normal text-center mb20
                    "
                >
                    Complete Incident Risk Assessment
                </h2>
                <p class="text-center font-16 text-999 line-normal mb20">You're almost there! To complete your Breach Report and Breach Risk Assessment click the <b>'COMPLETE NOW'</b> button below. </p>
                <p class="text-center font-16 text-999 line-normal mb40">If you'd like to complete this later, just hit <b>'DO THIS LATER'</b>. Remember, the sooner you complete this Risk Assessment the better you will be able to respond and mitigate the risk of your submitted breach, as well as comply with government mandated notification deadlines.</p>
                <div class="flex flex-wrap items-center justify-center pb10">
                    <button @click="closeModal" class="btn-blue complete-risk-btn h-32 mx8">DO THIS LATER</button>
                    <button @click="incidentRiskAssessmentQuiz" class="btn-primary complete-risk-btn mx8 h-32 mt-xs-20">COMPLETE NOW</button>
                </div>
                </div>
            </div>
            </div>
        </transition>
    </Teleport>
</template>

<script scoped>
import closeIcon from '../../common/icons/closeIcon.vue';

export default {
  components:{closeIcon},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
    };
  },
  emits: ["close-model", "incident-risk-assessment-quiz"],
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
    incidentRiskAssessmentQuiz () {
      this.$emit("incident-risk-assessment-quiz");
    },
  },
  created () {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
