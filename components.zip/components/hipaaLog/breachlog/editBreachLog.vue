<template>
    <div class="user-detail-card py20 px20 light mb10">
        <div class="add-access-log">
            <div class="row flex-auto -mx-10 mb10">
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error':
                                v$.incident_reporter_name.$error,
                        }"
                    >
                        <input
                            class="form-input location-input-box"
                            :class="{
                                'form-error': v$.incident_reporter_name.$error,
                            }"
                            type="text"
                            name="name"
                            v-model.trim="v$.incident_reporter_name.$model"
                        />
                        <label
                            class="label location-input-label"
                            :class="{
                                'label-float': v$.incident_reporter_name.$model,
                            }"
                            >Incident Reporter Name</label
                        >
                        <div v-if="v$.incident_reporter_name.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.incident_reporter_name.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.discovered_by.$error,
                        }"
                    >
                        <input
                            class="form-input location-input-box"
                            :class="{
                                'form-error': v$.discovered_by.$error,
                            }"
                            type="text"
                            name="name"
                            v-model.trim="v$.discovered_by.$model"
                        />
                        <label
                            class="label location-input-label"
                            :class="{ 'label-float': v$.discovered_by.$model }"
                            >Discovered By</label
                        >
                        <div v-if="v$.discovered_by.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.discovered_by.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error':
                                v$.discovered_start_date.$error,
                        }"
                    >
                        <datepicker
                            v-model:value="v$.discovered_start_date.$model"
                            :disabled-date="disableddiscoveredStartDate"
                            format="MM/DD/YYYY"
                            valueType="YYYY-MM-DD"
                            titleFormat="MM-DD-YYYY"
                            :editable="false"
                            class="datepicker-input"
                            @focus="
                                discovered_start_date_datepicker_focus = true
                            "
                            @blur="
                                discovered_start_date_datepicker_focus = false
                            "
                            type="date"
                            :class="{
                                'form-error': v$.discovered_start_date.$error,
                            }"
                        ></datepicker>

                        <label
                            class="label location-input-label"
                            :class="{
                                'label-float':
                                    discovered_start_date ||
                                    discovered_start_date_datepicker_focus,
                            }"
                            >Date Discovered (Start)</label
                        >
                        <div v-if="v$.discovered_start_date.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.discovered_start_date.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.discovered_end_date.$error,
                        }"
                    >
                        <datepicker
                            v-model:value="v$.discovered_end_date.$model"
                            :disabled-date="disableddiscoveredEndDate"
                            format="MM/DD/YYYY"
                            valueType="YYYY-MM-DD"
                            titleFormat="MM-DD-YYYY"
                            :editable="false"
                            class="datepicker-input"
                            @focus="discovered_end_date_datepicker_focus = true"
                            @blur="discovered_end_date_datepicker_focus = false"
                            type="date"
                            :class="{
                                'form-error': v$.discovered_end_date.$error,
                            }"
                        ></datepicker>

                        <label
                            class="label location-input-label"
                            :class="{
                                'label-float':
                                    discovered_end_date ||
                                    discovered_end_date_datepicker_focus,
                            }"
                            >Date Discovered (End)</label
                        >
                        <div v-if="v$.discovered_end_date.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.discovered_end_date.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error':
                                v$.individuals_affected_selected.$error,
                        }"
                    >
                        <multiselect
                            v-model="v$.individuals_affected_selected.$model"
                            :value="individuals_affected_selected"
                            :options="individuals_affected_list"
                            :close-on-select="true"
                            tag-placeholder=""
                            placeholder=""
                            label="text"
                            track-by="id"
                            :searchable="false"
                            :showLabels="false"
                            :taggable="false"
                        >
                            <template #noResult>
                                <div class="multiselect__noResult text-center">
                                    No results found
                                </div>
                            </template>
                            <template #noOptions>
                                <div class="multiselect__noOptions text-center">
                                    No data available
                                </div>
                            </template>
                        </multiselect>

                        <label
                            class="label label-select"
                            :class="{
                                'label-float':
                                    v$.individuals_affected_selected.$model !=
                                    null,
                            }"
                            >Individuals Affected</label
                        >
                        <div v-if="v$.individuals_affected_selected.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.individuals_affected_selected.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error':
                                v$.type_of_incident_selected.$error,
                        }"
                    >
                        <multiselect
                            v-model="v$.type_of_incident_selected.$model"
                            :options="type_of_incident_list"
                            :close-on-select="true"
                            tag-placeholder=""
                            placeholder=""
                            label="text"
                            track-by="id"
                            :searchable="false"
                            :showLabels="false"
                            :taggable="false"
                        >
                            <template #noResult>
                                <div class="multiselect__noResult text-center">
                                    No results found
                                </div>
                            </template>
                            <template #noOptions>
                                <div class="multiselect__noOptions text-center">
                                    No data available
                                </div>
                            </template>
                        </multiselect>

                        <label
                            class="label label-select"
                            :class="{
                                'label-float':
                                    v$.type_of_incident_selected.$model != null,
                            }"
                            >Type of Incident</label
                        >
                        <div v-if="v$.type_of_incident_selected.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.type_of_incident_selected.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.breach_start_date.$error,
                        }"
                    >
                        <datepicker
                            v-model:value="v$.breach_start_date.$model"
                            :disabled-date="disabledbreachStartDate"
                            format="MM/DD/YYYY"
                            valueType="YYYY-MM-DD"
                            titleFormat="MM-DD-YYYY"
                            :editable="false"
                            class="datepicker-input"
                            @focus="breach_start_date_datepicker_focus = true"
                            @blur="breach_start_date_datepicker_focus = false"
                            type="date"
                            :class="{
                                'form-error': v$.breach_start_date.$error,
                            }"
                        ></datepicker>

                        <label
                            class="label location-input-label"
                            :class="{
                                'label-float':
                                    breach_start_date ||
                                    breach_start_date_datepicker_focus,
                            }"
                            >Breach Start Date</label
                        >
                        <div v-if="v$.breach_start_date.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.breach_start_date.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.breach_end_date.$error,
                        }"
                    >
                        <datepicker
                            v-model:value="v$.breach_end_date.$model"
                            :disabled-date="disabledbreachEndDate"
                            format="MM/DD/YYYY"
                            valueType="YYYY-MM-DD"
                            titleFormat="MM-DD-YYYY"
                            :editable="false"
                            class="datepicker-input"
                            @focus="breach_end_date_datepicker_focus = true"
                            @blur="breach_end_date_datepicker_focus = false"
                            type="date"
                            :class="{ 'form-error': v$.breach_end_date.$error }"
                        ></datepicker>

                        <label
                            class="label location-input-label"
                            :class="{
                                'label-float':
                                    breach_end_date ||
                                    breach_end_date_datepicker_focus,
                            }"
                            >Breach End Date</label
                        >
                        <div v-if="v$.breach_end_date.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.breach_end_date.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex flex-wrap flex-auto items-center mb10">
                <h6 class="font-14 font_semibold gray_checkmark--text mb0 mr10">
                    Type of PHI Exposed
                </h6>
                <VTooltip
                    :triggers="['hover']"
                    :popperTriggers="['hover']"
                    style="height: 24px"
                    class="cursor-pointer"
                >
                    <span><info-icon></info-icon></span>
                    <template #popper>
                        Select all forms of PHI that were exposed or possibly
                        exposed in the breach. If 'other', please describe the
                        specific type of PHI exposed to the best of your
                        ability.
                    </template>
                </VTooltip>
                <span class="font-16 font_normal gray_checkmark--text ml10 font-italic select-apply-text">(Select All That Apply)</span>
            </div>
            <div
                class="row flex-auto items-center justify-start-small-medium phi-exposed-row -mx-10 mb20"
                :class="{
                    'form-group--error': v$.type_of_PHI_selected.$error,
                }"
            >
                <div
                    v-for="(type_of_PHI, index) in PHI_type_list"
                    :key="index"
                    class="col-12 col-sm-6 col-md-2 col-lg-2 col-xl-2 px10 mb-sm-10"
                >
                    <div class="checkbox mr16">
                        <input
                            v-model="v$.type_of_PHI_selected.$model"
                            :id="'type_of_PHI_edit' + type_of_PHI.phi_type_id"
                            type="checkbox"
                            :value="type_of_PHI"
                        />
                        <label
                            :for="'type_of_PHI_edit' + type_of_PHI.phi_type_id"
                            class="checkbox-label font-14 font-light gray_checkmark--text"
                            >{{ type_of_PHI.name }}</label
                        >
                    </div>
                </div>

                <div
                    v-if="isOtherPHISelected()"
                    class="form-group flex-auto other-PHI-input px10 mb-0"
                    :class="{
                        'form-group--error': v$.other_PHI_description.$error,
                    }"
                >
                    <div class="relative">
                        <input
                            class="form-input location-input-box"
                            :class="{
                                'form-error': v$.other_PHI_description.$error,
                            }"
                            type="text"
                            name="name"
                            v-model.trim="v$.other_PHI_description.$model"
                        />
                        <label
                            class="label location-input-label"
                            :class="{
                                'label-float': v$.other_PHI_description.$model,
                            }"
                            >Describe the other PHI exposed</label
                        >
                        <div v-if="v$.other_PHI_description.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.other_PHI_description.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div v-if="v$.type_of_PHI_selected.$errors.length > 0">
                    <div class="form-error-text px10 fill-width">
                        {{ v$.type_of_PHI_selected.$errors[0].$message }}
                    </div>
                </div>
            </div>
            <div class="flex flex-wrap flex-auto items-center mb10">
                <h6 class="font-14 font_semibold gray_checkmark--text mb0 mr10">
                    Has this incident already been reported? If so, to whom?
                </h6>
                <!-- <VTooltip
                    :triggers="['hover']"
                    :popperTriggers="['hover']"
                    style="height: 24px"
                    class="cursor-pointer"
                >
                    <span><info-icon></info-icon></span>
                    <template #popper>
                        Has this incident already been reported? If so, to whom?
                    </template>
                </VTooltip> -->
            </div>
            <div
                class="row flex-auto items-center justify-start-small-medium -mx-10 mb20"
                :class="{
                    'form-group--error': v$.incident_reported_selected.$error,
                }"
            >
                <div
                    v-for="incident_reported in incident_reporter_list_data"
                    :key="incident_reported.incident_reporter_id"
                    class="col-12 col-sm-6 col-md-3 col-lg-3 col-xl-2 office-civil-col px10 mb-sm-10"
                >
                    <div class="checkbox mr16">
                        <input
                            v-model="v$.incident_reported_selected.$model"
                            :id="
                                'incident_reported_edit' +
                                incident_reported.incident_reporter_id
                            "
                            type="checkbox"
                            :value="incident_reported"
                            @click="adjustIncidentSelected(incident_reported)"
                        />
                        <label
                            :for="
                                'incident_reported_edit' +
                                incident_reported.incident_reporter_id
                            "
                            class="checkbox-label font-14 font-light gray_checkmark--text"
                            >{{ incident_reported.name }}</label
                        >
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 px10 mb-sm-10 mt10">
                    <div v-if="v$.incident_reported_selected.$errors.length > 0">
                        <div class="form-error-text">
                            {{ v$.incident_reported_selected.$errors[0].$message }}
                        </div>
                    </div>
                </div>
            </div>
            <div
                class="row flex-auto justify-start-small-medium edit-date-reported -mx-10 mb20"
            >
                <div
                    class="col-12 col-sm-6 col-md-3 col-lg-3 col-xl-2 px10 mb-sm-10"
                >
                    <div
                        v-if="
                            checkForNotNoneIncidentReportSelected(
                                'Office for Civil Rights'
                            )
                        "
                        class="form-group mb-0"
                        :class="{
                            'form-group--error':
                                v$.office_civil_right_incident_reported_date
                                    .$error,
                        }"
                    >
                        <datepicker
                            v-model:value="
                                v$.office_civil_right_incident_reported_date
                                    .$model
                            "
                            format="MM/DD/YYYY"
                            valueType="YYYY-MM-DD"
                            titleFormat="MM-DD-YYYY"
                            :editable="false"
                            class="datepicker-input"
                            type="date"
                            @focus="office_civil_right_datepicker_focus = true"
                            @blur="office_civil_right_datepicker_focus = false"
                            :class="{
                                'form-error':
                                    v$.office_civil_right_incident_reported_date
                                        .$error,
                            }"
                        ></datepicker>
                        <label
                            class="label location-input-label"
                            :class="{
                                'label-float':
                                    office_civil_right_incident_reported_date ||
                                    office_civil_right_datepicker_focus,
                            }"
                            >Date Reported</label
                        >
                        <div v-if="v$.office_civil_right_incident_reported_date.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.office_civil_right_incident_reported_date.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    class="col-12 col-sm-6 col-md-3 col-lg-3 col-xl-2 px10 mb-sm-10"
                >
                    <div
                        v-if="
                            checkForNotNoneIncidentReportSelected(
                                'Affected Individuals'
                            )
                        "
                        class="form-group mb-0"
                        :class="{
                            'form-group--error':
                                v$.affected_individual_incident_reported_date
                                    .$error,
                        }"
                    >
                        <datepicker
                            v-model:value="v$.affected_individual_incident_reported_date.$model"
                            format="MM/DD/YYYY"
                            valueType="YYYY-MM-DD"
                            titleFormat="MM-DD-YYYY"
                            :editable="false"
                            class="datepicker-input"
                            type="date"
                            @focus="affected_individual_datepicker_focus = true"
                            @blur="affected_individual_datepicker_focus = false"
                            :class="{'form-error':v$.affected_individual_incident_reported_date.$error,}"
                        ></datepicker>
                        <label
                            class="label location-input-label"
                            :class="{
                                'label-float':
                                    affected_individual_incident_reported_date ||
                                    affected_individual_datepicker_focus,
                            }"
                            >Date Reported</label
                        >
                        <div v-if="v$.affected_individual_incident_reported_date.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.affected_individual_incident_reported_date.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    class="col-12 col-sm-6 col-md-3 col-lg-3 col-xl-2 px10 mb-sm-10"
                >
                    <div
                        v-if="checkForNotNoneIncidentReportSelected('Abyde')"
                        class="form-group mb-0"
                        :class="{
                            'form-group--error':
                                v$.abyde_incident_reported_date.$error,
                        }"
                    >
                        <datepicker
                            v-model:value="v$.abyde_incident_reported_date.$model"
                            format="MM/DD/YYYY"
                            valueType="YYYY-MM-DD"
                            titleFormat="MM-DD-YYYY"
                            :editable="false"
                            class="datepicker-input"
                            type="date"
                            @focus="abyde_datepicker_focus = true"
                            @blur="abyde_datepicker_focus = false"
                            :class="{
                                'form-error':
                                    v$.abyde_incident_reported_date.$error,
                            }"
                        ></datepicker>
                        <label
                            class="label location-input-label"
                            :class="{
                                'label-float':
                                    abyde_incident_reported_date ||
                                    abyde_datepicker_focus,
                            }"
                            >Date Reported</label
                        >
                        <div v-if="v$.abyde_incident_reported_date.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.abyde_incident_reported_date.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    class="col-12 col-sm-1 col-md-3 col-lg-3 col-xl-2 px10 mb-sm-10"
                ></div>
            </div>

            <div class="mt40">
                <div
                    class="flex items-center justify-center flex-wrap flex-auto submit-cancel-buttons"
                >
                    <button
                        type="submit"
                        class="btn-primary mx7"
                        :disabled="disable_submit_button"
                        @click="openBreachLogEditModal"
                    >
                        <span>Submit</span>
                    </button>
                    <button
                        type="button"
                        class="btn-cancel-outline mx7"
                        v-on:click="cancelEditBreachLog"
                        :disabled="disable_submit_button"
                    >
                        <span>Cancel</span>
                    </button>
                </div>
            </div>
        </div>
        <edit-breach-log-modal
            v-if="is_edit_breach_log_modal_shown"
            @close-model="closeBreachLogEditModal"
            @update-breach-log="updateBreachLog"
        ></edit-breach-log-modal>
    </div>
</template>
<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import NProgress from "nprogress";
import infoIcon from "../../common/icons/infoIcon.vue";
import { useVuelidate } from '@vuelidate/core';
import { required, maxLength, requiredIf, helpers } from "@vuelidate/validators";

import {
    checkSpecialChars,
    checkSpecialCharsErrorMessage,
} from "../../common/customValidation";
import editBreachLogModal from "./editBreachLogModal.vue";
import _ from "lodash";
export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            incident_reporter_name: "",
            discovered_by: "",
            discovered_start_date: "",
            discovered_end_date: "",
            disableddiscoveredEndDate: (date) => date <= new Date(1),
            disableddiscoveredStartDate: (date) => date <= new Date(1),
            breach_start_date: "",
            breach_end_date: "",
            disabledbreachEndDate: (date) => date <= new Date(1),
            disabledbreachStartDate: (date) => date <= new Date(1),
            individuals_affected_selected: null,
            individuals_affected_list: [
                {
                    id: "less_than_500",
                    text: "Less than 500",
                },
                {
                    id: "500_or_more_than_500",
                    text: "500 or more",
                },
            ],
            type_of_incident_selected: null,
            type_of_incident_list: [
                {
                    id: "hacking_it_incident",
                    text: "Hacking/IT",
                },
                {
                    id: "improper_disposal",
                    text: "Improper Disposal",
                },
                {
                    id: "loss",
                    text: "Loss of PHI",
                },
                {
                    id: "theft",
                    text: "Theft of PHI",
                },
                {
                    id: "unauthorized_access",
                    text: "Unauthorized Access/Disclosure",
                },
            ],
            type_of_PHI_selected: [],
            other_PHI_description: "",

            incident_reported_selected: [],
            office_civil_right_incident_reported_date: "",
            affected_individual_incident_reported_date: "",
            abyde_incident_reported_date: "",
            office_civil_right_datepicker_focus: false,
            affected_individual_datepicker_focus: false,
            abyde_datepicker_focus: false,

            disable_submit_button: false,
            discovered_start_date_datepicker_focus: false,
            discovered_end_date_datepicker_focus: false,
            breach_start_date_datepicker_focus: false,
            breach_end_date_datepicker_focus: false,
            checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
            is_edit_breach_log_modal_shown: false,
        };
    },
    components: {
        infoIcon,
        editBreachLogModal,
    },
    emits: ["cancel-edit-breach-log-form", "load-updated-breach-log-data", "edit-breach-log-form-toggle"],
    setup: () => ({ v$: useVuelidate() }),
    props: {
        breach_log_item: {
            type: Object,
            default: () => {},
        },
        PHI_type_list: {
            type: Array,
            default: () => [],
        },
        incident_reporter_list_data: {
            type: Array,
            default: () => [],
        },
        selected_location_id: {
            type: Number,
            default: () => [],
        },
    },
    watch: {
        breach_start_date(val) {
            if (val == null) {
                this.disabledbreachEndDate = (date) => date <= new Date(1);
            } else {
                var modify_date = new Date(val);
                modify_date.setDate(modify_date.getDate() - 1);
                this.disabledbreachEndDate = (date) => date < modify_date;
            }
        },
        breach_end_date(val) {
            if (val == null) {
                this.disabledbreachStartDate = (date) => date <= new Date(1);
            } else {
                var modify_date = new Date(val);
                this.disabledbreachStartDate = (date) =>
                    date >= modify_date || date <= new Date(1);
            }
        },
        discovered_start_date(val) {
            if (val == null) {
                this.disableddiscoveredEndDate = (date) => date <= new Date(1);
            } else {
                var modify_date = new Date(val);
                modify_date.setDate(modify_date.getDate() - 1);
                this.disableddiscoveredEndDate = (date) => date < modify_date;
            }
        },
        discovered_end_date(val) {
            if (val == null) {
                this.disableddiscoveredStartDate = (date) =>
                    date <= new Date(1);
            } else {
                var modify_date = new Date(val);
                this.disableddiscoveredStartDate = (date) =>
                    date >= modify_date || date <= new Date(1);
            }
        },
        type_of_PHI_selected() {
            var is_found = _.find(this.type_of_PHI_selected, { name: "Other" });
            if (_.isUndefined(is_found)) {
                this.other_PHI_description = "";
            }
        },
        is_not_applicable_affected_locations(val) {
            if (val == true) {
                this.additional_location_selected = [];
                this.v$.$touch();
            }
        },
        incident_reported_selected(newVal, oldVal) {
            let differenceValue = _.difference(oldVal, newVal);
            _.forEach(differenceValue, (value) => {
                if (value.name == "Office for Civil Rights") {
                    this.office_civil_right_incident_reported_date = "";
                }
                if (value.name == "Affected Individuals") {
                    this.affected_individual_incident_reported_date = "";
                }
                if (value.name == "Abyde") {
                    this.abyde_incident_reported_date = "";
                }
            });
            this.v$.$touch();
        },
    },
    mounted() {
        this.setValueForEditBreachLog();
    },
    validations() {
        let validationArray = {
            incident_reporter_name: {
                required: helpers.withMessage("Please enter an incident reporter name", required),
                maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            discovered_by: {
                required: helpers.withMessage("Please enter a name by whom the incident was discovered", required),
                maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            discovered_start_date: {
                required: helpers.withMessage("Please select a discovered start date", required),
            },
            discovered_end_date: {
                required: helpers.withMessage("Please select a discovered end date", required),
            },
            breach_start_date: {
                required: helpers.withMessage("Please select a breach start date", required),
            },
            breach_end_date: {
                required: helpers.withMessage("Please select a breach end date", required),
            },
            individuals_affected_selected: {
                required: helpers.withMessage("Please select an affected individuals", required),
            },
            type_of_incident_selected: {
                required: helpers.withMessage("Please select a type of incident", required),
            },
            type_of_PHI_selected: {
                required: helpers.withMessage("Please select at least one type of PHI", required),
            },
            incident_reported_selected: {
                required: helpers.withMessage("Please select at least one reported option", required),
            },
            office_civil_right_incident_reported_date: {
                required: helpers.withMessage('Please select reported date', requiredIf(() => {
                    return this.checkForNotNoneIncidentReportSelected("Office for Civil Rights");
                })),
            },
            affected_individual_incident_reported_date: {
                required: helpers.withMessage('Please select reported date', requiredIf(() => {
                    return this.checkForNotNoneIncidentReportSelected("Affected Individuals");
                })),
            },
            abyde_incident_reported_date: {
                required: helpers.withMessage('Please select reported date', requiredIf(() => {
                    return this.checkForNotNoneIncidentReportSelected("Abyde");
                })),
            },
            other_PHI_description: {
                required: helpers.withMessage('Please describe the other PHI exposed', requiredIf(() => {
                    return this.isOtherPHISelected();
                })),
                maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
        };
        return validationArray;
    },
    methods: {
        cancelEditBreachLog() {
            this.$emit("cancel-edit-breach-log-form", false);
        },
        openBreachLogEditModal() {
            this.v$.$touch();
            if (!this.v$.$invalid) {
                if (this.breach_log_item.ra_attempt_questions.length > 0) {
                    this.is_edit_breach_log_modal_shown = true;
                } else {
                    this.updateBreachLog();
                }
            }
        },
        closeBreachLogEditModal() {
            this.is_edit_breach_log_modal_shown = false;
        },
        setValueForEditBreachLog() {
            this.incident_reporter_name =
                this.breach_log_item.incident_reporter_name;
            this.discovered_by = this.breach_log_item.discovered_by;
            this.discovered_start_date = this.breach_log_item.discovered_start_date;
            this.discovered_end_date = this.breach_log_item.discovered_end_date;
            this.breach_start_date = this.breach_log_item.breach_start_date;
            this.breach_end_date = this.breach_log_item.breach_end_date;
            // for type of PHI_selected
            _.forEach(this.breach_log_item.phi_type, (value) => {
                this.type_of_PHI_selected.push({
                    phi_type_id: value.phi_type_name.id,
                    name: value.phi_type_name.name,
                });
                if (value.phi_type_name.name == "Other") {
                    this.other_PHI_description = value.other_details;
                }
            });

            // for type_of_incident_selected
            var is_type_of_incident = _.find(
                this.type_of_incident_list,
                (o) => {
                    return o.id == this.breach_log_item.type_of_incident;
                }
            );
            if (!_.isUndefined(is_type_of_incident)) {
                this.type_of_incident_selected = is_type_of_incident;
            }

            // for individuals_affected_selected
            var is_individuals_affected = _.find(
                this.individuals_affected_list,
                (o) => {
                    return o.id == this.breach_log_item.individuals_affected;
                }
            );
            if (!_.isUndefined(is_individuals_affected)) {
                this.individuals_affected_selected = is_individuals_affected;
            }

            // for incident reported
            _.forEach(this.breach_log_item.incident_report, (value) => {
                this.incident_reported_selected.push({
                    incident_reporter_id: value.incident_reporter_type.id,
                    name: value.incident_reporter_type.name,
                });
                if (
                    value.incident_reporter_type.name ==
                    "Office for Civil Rights"
                ) {
                    this.office_civil_right_incident_reported_date =
                        value.incident_date;
                }
                if (
                    value.incident_reporter_type.name == "Affected Individuals"
                ) {
                    this.affected_individual_incident_reported_date =
                        value.incident_date;
                }
                if (value.incident_reporter_type.name == "Abyde") {
                    this.abyde_incident_reported_date = value.incident_date;
                }
            });
        },
        isOtherPHISelected() {
            let is_found = _.find(this.type_of_PHI_selected, { name: "Other" });
            if (!_.isUndefined(is_found)) {
                return true;
            }
            return false;
        },
        checkForNotNoneIncidentReportSelected(name) {
            let is_found = _.find(this.incident_reported_selected, {
                name: name,
            });
            if (!_.isUndefined(is_found)) {
                return true;
            }
            return false;
        },
        adjustIncidentSelected(incident_reported) {
            let found_index = _.findIndex(
                this.incident_reported_selected,
                (o) => {
                    return o.name === "None";
                }
            );
            if (incident_reported.name == "None") {
                this.incident_reported_selected = [
                        {
                            incident_reporter_id: 4,
                            name: "None",
                        },
                ];
                this.office_civil_right_incident_reported_date = "";
                this.affected_individual_incident_reported_date = "";
                this.abyde_incident_reported_date = "";
                this.office_civil_right_datepicker_focus = false;
                this.affected_individual_datepicker_focus = false;
                this.abyde_datepicker_focus = false;
            } else {
                if (found_index >= 0) {
                    this.incident_reported_selected.splice(found_index, 1);
                }
            }
        },
        async updateBreachLog(){
             this.v$.$touch();
            const is_valid = await this.v$.$validate();
            if (is_valid) {
                NProgress.start();
                this.disable_submit_button = true;

                let selected_phi_type_new = new Array();
                let selected_phi_type_removed = new Array();
                // Set PHI Type variables
                _.forEach(this.type_of_PHI_selected, (value) => {
                    if (
                        _.isUndefined(
                            _.find(this.breach_log_item.phi_type, (o) => {
                                return o.phi_type_id == value.phi_type_id;
                            })
                        )
                    ) {
                        selected_phi_type_new.push({
                            phi_type_id: value.phi_type_id,
                            other_details:
                                value.name == "Other"
                                    ? this.other_PHI_description
                                    : "",
                        });
                    }
                });
                _.forEach(this.breach_log_item.phi_type, (value) => {
                    if (
                        _.isUndefined(
                            _.find(this.type_of_PHI_selected, (o) => {
                                return o.phi_type_id == value.phi_type_id;
                            })
                        )
                    ) {
                        selected_phi_type_removed.push({
                            phi_type_id: value.phi_type_id,
                        });
                    }
                    // check for other details changed
                    if (value.phi_type_name.name === "Other") {
                        let is_avail_other_in_new = _.find(
                            this.type_of_PHI_selected,
                            (o) => {
                                return o.name == value.phi_type_name.name;
                            }
                        );
                        if (
                            !_.isUndefined(is_avail_other_in_new) &&
                            value.other_details !== this.other_PHI_description
                        ) {
                            selected_phi_type_removed.push({
                                phi_type_id: value.phi_type_id,
                            });
                            selected_phi_type_new.push({
                                phi_type_id: value.phi_type_id,
                                other_details: this.other_PHI_description,
                            });
                        }
                    }
                });

                let selected_incident_list_new = new Array();
                let selected_incident_list_removed = new Array();
                // set incident reported variables
                _.forEach(this.incident_reported_selected, (value) => {
                    if (
                        _.isUndefined(
                            _.find(
                                this.breach_log_item.incident_report,
                                (o) => {
                                    return (
                                        o.incident_reporter_id ==
                                        value.incident_reporter_id
                                    );
                                }
                            )
                        )
                    ) {
                        if (value.name == "Office for Civil Rights") {
                            selected_incident_list_new.push({
                                incident_reporter_id:
                                    value.incident_reporter_id,
                                incident_date:
                                    this
                                        .office_civil_right_incident_reported_date,
                            });
                        } else if (value.name == "Abyde") {
                            selected_incident_list_new.push({
                                incident_reporter_id:
                                    value.incident_reporter_id,
                                incident_date:
                                    this.abyde_incident_reported_date,
                            });
                        } else if (value.name == "Affected Individuals") {
                            selected_incident_list_new.push({
                                incident_reporter_id:
                                    value.incident_reporter_id,
                                incident_date:
                                    this
                                        .affected_individual_incident_reported_date,
                            });
                        } else {
                            selected_incident_list_new.push({
                                incident_reporter_id:
                                    value.incident_reporter_id,
                                incident_date: null,
                            });
                        }
                    }
                });
                _.forEach(this.breach_log_item.incident_report, (value) => {
                    if (
                        _.isUndefined(
                            _.find(
                                this.incident_reported_selected,
                                (o) => {
                                    return (
                                        o.incident_reporter_id ==
                                        value.incident_reporter_id
                                    );
                                }
                            )
                        )
                    ) {
                        selected_incident_list_removed.push({
                            incident_reporter_id: value.incident_reporter_id,
                        });
                    }
                    // check for date changed
                    if (
                        value.incident_reporter_type.name ===
                        "Office for Civil Rights"
                    ) {
                        let is_avail_in_new = _.find(
                            this.incident_reported_selected,
                            (o) => {
                                return (
                                    o.name == value.incident_reporter_type.name
                                );
                            }
                        );
                        if (
                            !_.isUndefined(is_avail_in_new) &&
                            value.incident_date !==
                                this.office_civil_right_incident_reported_date
                        ) {
                            selected_incident_list_removed.push({
                                incident_reporter_id:
                                    value.incident_reporter_id,
                            });
                            selected_incident_list_new.push({
                                incident_reporter_id:
                                    value.incident_reporter_id,
                                incident_date:
                                    this
                                        .office_civil_right_incident_reported_date,
                            });
                        }
                    }
                    if (
                        value.incident_reporter_type.name ===
                        "Affected Individuals"
                    ) {
                        let is_avail_in_new = _.find(
                            this.incident_reported_selected,
                            (o) => {
                                return (
                                    o.name == value.incident_reporter_type.name
                                );
                            }
                        );
                        if (
                            !_.isUndefined(is_avail_in_new) &&
                            value.incident_date !==
                                this.affected_individual_incident_reported_date
                        ) {
                            selected_incident_list_removed.push({
                                incident_reporter_id:
                                    value.incident_reporter_id,
                            });
                            selected_incident_list_new.push({
                                incident_reporter_id:
                                    value.incident_reporter_id,
                                incident_date:
                                    this
                                        .affected_individual_incident_reported_date,
                            });
                        }
                    }
                    if (value.incident_reporter_type.name === "Abyde") {
                        let is_avail_in_new = _.find(
                            this.incident_reported_selected,
                            (o) => {
                                return (
                                    o.name == value.incident_reporter_type.name
                                );
                            }
                        );
                        if (
                            !_.isUndefined(is_avail_in_new) &&
                            value.incident_date !==
                                this.abyde_incident_reported_date
                        ) {
                            selected_incident_list_removed.push({
                                incident_reporter_id:
                                    value.incident_reporter_id,
                            });
                            selected_incident_list_new.push({
                                incident_reporter_id:
                                    value.incident_reporter_id,
                                incident_date:
                                    this.abyde_incident_reported_date,
                            });
                        }
                    }
                });
                axios
                    .post(JS_APP_URL + "/hipaa-logs/update-breachlog", {
                        breach_log_id: this.breach_log_item.id,
                        location_id: this.selected_location_id,
                        incident_reporter_name: this.incident_reporter_name,
                        discovered_by: this.discovered_by,
                        discovered_start_date: this.discovered_start_date,
                        discovered_end_date: this.discovered_end_date,
                        breach_start_date: this.breach_start_date,
                        breach_end_date: this.breach_end_date,
                        individuals_affected:
                            this.individuals_affected_selected.id,
                        type_of_incident: this.type_of_incident_selected.id,
                        selected_phi_list_new: selected_phi_type_new,
                        selected_phi_list_removed: selected_phi_type_removed,
                        selected_incident_list_new: selected_incident_list_new,
                        selected_incident_list_removed:
                            selected_incident_list_removed,
                    })
                    .then((response) =>  {
                        if (response["data"]["status"] == "Error") {
                            if (response["data"]["data"].length > 0) {
                                toastr.error(
                                    response["data"]["data"].join("</br>"),
                                    "Error"
                                );
                            } else {
                                toastr.error(
                                    response["data"]["message"],
                                    "Error"
                                );
                            }
                        } else {
                            toastr.success(
                                response["data"]["message"],
                                "Success"
                            );
                            setTimeout(() => {
                                this.is_edit_breach_log_modal_shown = false;
                                this.$emit(
                                    "load-updated-breach-log-data",
                                    response["data"]["data"]
                                );
                                this.$emit("edit-breach-log-form-toggle", false);
                            }, 100);
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() =>  {
                        NProgress.done();
                        this.disable_submit_button = false;
                    });
            }
        },
    },
};
</script>
