<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container Whoa-modal">
            <div class="text-center mlr-auto mb16 pt20">
                <img :src="JS_APP_URL + '/images/check-circle.svg'" alt="" title="" class="warning-icon-modal" />
            </div>
            <h2
                class="
                font-24 font_semibold blueog--text line-normal text-center mb20
                "
            >
                Congratulations!
            </h2>
            <p class="text-center font-16 text-999 line-normal mb30">Your Breach Risk Assessment has been completed! <br />Click FINISH to view full Breach Log Report. </p>
            <div class="flex flex-wrap items-center justify-center pb10">
                <button @click="finishRAQuiz" class="btn-primary-outline btn-width-140 mx5">FINISH</button>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>

export default {
  props: {
    location_id:{
      type: Number
    }
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
    };
  },
  emits: ["finish-ra-quiz"],
  methods: {
    finishRAQuiz() {
      this.$emit('finish-ra-quiz');
    }
  },
  created () {
    // document.body.classList.add('modal-open');
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
