<template>
  <div>
    <header-after-login></header-after-login>
    <div class="container pt30 pb60 mb20">
      <h1
        class="location-dashbaord-title text-center font-24 font_semibold blueog--text line-normal mb15 mb-sm-10 mb-md-10"
      >
        Breach Risk Assessment
      </h1>
      <div v-if="percentage_count == 0 && is_first_page == true">
        <div class="security-progress-wrapper mb50">
          <radial-progress-bar
            class="sra-start-progress"
            :diameter="200"
            :completed-steps="percentage_count"
            :total-steps="total_steps_outer"
            :start-color="start_color_outer"
            :stop-color="start_color_outer"
            :inner-stroke-color="inner_stroke_color"
            :inner-stroke-width="6"
            :stroke-width="6"
          >
            <h1 class="sra-percent-text font_semibold">{{ percentage_count }}%</h1>
            <p class="sra-completed-text">Completed</p>
          </radial-progress-bar>
        </div>
        <p class="font-20 black--text text-center mb50">
          Please answer the following questions to provide important information regarding
          your case.
        </p>
        <div class="text-center sra-first-buttons">
          <button
            type="button"
            class="btn-primary mx-auto d-inline-block px30 mt-xs-20 mx5"
            @click="startQuiz"
          >
            Start
          </button>
        </div>
      </div>

      <div v-if="is_first_page == false && question_detail">
        <div class="security-progress-wrapper mb40">
          <radial-progress-bar
            class="sra-quetions-progress"
            :diameter="200"
            :completed-steps="percentage_count"
            :total-steps="total_steps_outer"
            :start-color="start_color_outer"
            :stop-color="start_color_outer"
            :inner-stroke-color="inner_stroke_color"
            :inner-stroke-width="3"
            :stroke-width="6"
          >
            <h1
              class="sra-percent-text font_semibold"
              v-bind:style="{ color: start_color_outer }"
            >
              {{ percentage_count }}%
            </h1>
            <h3 class="sra-completed-text">Completed</h3>
          </radial-progress-bar>
        </div>
        <p
          class="font-25 black--text text-center mb30 quetion-text"
          v-html="question_detail.question"
        ></p>
        <div class="sra-quetions-wrapper mlr-auto">
          <div
            class="row flex-auto justify-center -mx-10 mb15"
            v-if="question_detail.question_answer_layout == 'radio'"
          >
            <div
              class="col-12 col-md-12 col-lg-4 col-xl-4 mb-md-20 px10"
              v-for="answer_opt in question_detail.breach_log_ra_question_answers"
              :key="answer_opt.id"
            >
              <div class="answer-option-item">
                <input
                  type="radio"
                  class="answer-option-radio"
                  :id="'radio ' + answer_opt.id"
                  :value="answer_opt.id"
                  v-model="selected_answer"
                />
                <label
                  class="answer-option-lable font-20 blueog--text"
                  :for="'radio ' + answer_opt.id"
                  >{{ answer_opt.answer }}</label
                >
              </div>
            </div>
          </div>

          <div
            class="row flex-auto justify-center -mx-10 mb15"
            v-if="question_detail.question_answer_layout == 'checkbox'"
          >
            <div
              class="col-12 col-md-12 col-lg-4 col-xl-4 mb-md-20 px10"
              v-for="answer_opt in question_detail.breach_log_ra_question_answers"
              :key="answer_opt.id"
            >
              <div class="answer-option-item">
                <input
                  type="checkbox"
                  class="answer-option-radio"
                  :id="'radio ' + answer_opt.id"
                  :value="answer_opt.id"
                  v-model="selected_answer"
                />
                <label
                  class="answer-option-lable font-20 blueog--text"
                  :for="'radio ' + answer_opt.id"
                  >{{ answer_opt.answer }}</label
                >
              </div>
            </div>
          </div>

          <div
            v-if="
              question_detail.question_answer_layout == 'text' ||
              question_detail.question_answer_layout == 'number' ||
              question_detail.question_answer_layout == 'email'
            "
          >
            <div class="mb15 relative">
              <input
                :type="question_detail.question_answer_layout"
                class="form-input"
                v-model.trim="selected_answer"
              />
              <label
                class="label location-input-label"
                :class="{ 'label-float': selected_answer.length != 0 }"
                >{{ question_detail.question_answer_layout_data }}</label
              >
            </div>
          </div>

          <div v-if="question_detail.question_answer_layout == 'textarea'">
            <div class="mb15 relative">
              <textarea
                rows="4"
                class="textarea form-textarea"
                v-model.trim="selected_answer"
              ></textarea>
              <label
                class="label location-input-label"
                :class="{ 'label-float': selected_answer.length != 0 }"
                >{{ question_detail.question_answer_layout_data }}</label
              >
            </div>
          </div>

          <div class="col-12 col-md-8 col-xl-7 mlr-auto" v-if="question_detail.question_answer_layout == 'date_picker'">
            <div class="mb15 relative">
              <datepicker
                v-model:value="selected_answer"
                format="MM/DD/YYYY"
                valueType="YYYY-MM-DD"
                titleFormat="MM-DD-YYYY"
                :editable="false"
                class="datepicker-input"
                type="date"
                @focus="datepicker_focus = true"
                @blur="datepicker_focus = false"
                @clear="selected_answer = []"
              ></datepicker>
              <label
                class="label location-input-label"
                :class="{
                  'label-float': selected_answer.length != 0 || datepicker_focus,
                }"
                >{{ question_detail.question_answer_layout_data }}</label
              >
            </div>
          </div>

          <div class="col-12 col-md-8 col-xl-7 mlr-auto"
            v-if="
              question_detail.question_answer_layout == 'single_select_dropdown' ||
              question_detail.question_answer_layout == 'multi_select_dropdown'
            "
          >
            <div
              class="mb15 relative"
              v-if="question_detail.question_answer_layout_data == 'BA'"
            >
              <multiselect
                v-model="selected_answer"
                :options="ba_list"
                :close-on-select="
                  question_detail.question_answer_layout == 'multi_select_dropdown'
                    ? false
                    : true
                "
                tag-placeholder=""
                placeholder=""
                label="name"
                track-by="id"
                :multiple="
                  question_detail.question_answer_layout == 'multi_select_dropdown'
                    ? true
                    : false
                "
                :searchable="true"
                :showLabels="false"
                :taggable="false"
                :allowEmpty="false"
              >
                <template #noResult>
                  <div class="multiselect__noResult text-center">No results found</div>
                </template>
                <template #noOptions>
                  <div class="multiselect__noOptions text-center">No data available</div>
                </template>
              </multiselect>
              <label
                class="label label-select"
                :class="{ 'label-float': selected_answer && Object.keys(selected_answer).length > 0  }"
                >Please select an answer to continue</label
              >
            </div>
            <div
              class="mb15 relative"
              v-if="question_detail.question_answer_layout_data == 'STATE'"
            >
              <multiselect
                v-model="selected_answer"
                :options="state_list"
                :close-on-select="
                  question_detail.question_answer_layout == 'multi_select_dropdown'
                    ? false
                    : true
                "
                tag-placeholder=""
                placeholder=""
                label="state_name"
                track-by="id"
                :multiple="
                  question_detail.question_answer_layout == 'multi_select_dropdown'
                    ? true
                    : false
                "
                :searchable="true"
                :showLabels="false"
                :taggable="false"
              >
              <template #noResult>
                <div class="multiselect__noResult text-center">
                  No results found
                </div>
              </template>
              <template #noOptions>
                <div class="multiselect__noOptions text-center">
                  No data available
                </div>
              </template>
              <template #selection>
                <div class="multiselect__tags-wrap" v-if="selected_answer.length > 1">
                  <span class="multiselect__tag">
                    <span>{{ selected_answer.length }} States Selected</span>
                  </span>
                </div>
              </template>
            </multiselect>
              <label
                class="label label-select"
                :class="{ 'label-float': selected_answer.length > 0 }"
                >Please select state(s)</label
              >
            </div>
            <div
              class="mb15 relative"
              v-if="question_detail.question_answer_layout_data == 'EMPLOYEE'"
            >
              <multiselect
                v-model="selected_answer"
                :options="employee_list"
                :close-on-select="
                  question_detail.question_answer_layout == 'multi_select_dropdown'
                    ? false
                    : true
                "
                tag-placeholder=""
                placeholder=""
                :showLabels="false"
                :custom-label="customLabel"
                track-by="id"
                @select="updateSelectedEmployee"
                :multiple="
                  question_detail.question_answer_layout == 'multi_select_dropdown'
                    ? true
                    : false
                "
                :searchable="true"
                :taggable="false"
              >
                <template #noResult>
                    <div class="multiselect__noResult text-center">
                    No results found
                    </div>
                </template>
                <template #noOptions>
                    <div class="multiselect__noOptions text-center">
                    No data available
                    </div>
                </template>
                <template #selection>
                    <div class="multiselect__tags-wrap" v-if="selected_answer.length > 1">
                        <span class="multiselect__tag">
                        <span>{{ selected_answer.length }} Employees Selected</span>
                        </span>
                    </div>
                </template>
              </multiselect>
              <label
                class="label label-select"
                :class="{ 'label-float': selected_answer.length > 0 }"
                >Please select employee(s)</label
              >
            </div>
          </div>

          <div v-if="show_error" class="mb10 font-12 red2--text">
            <div
              v-if="
                question_detail.question_answer_layout == 'radio' ||
                question_detail.question_answer_layout == 'single_select_dropdown'
              "
              class="text-center font-16 font_bold"
            >
              * Please select an answer to continue
            </div>
            <div
              v-if="
                question_detail.question_answer_layout == 'checkbox' ||
                question_detail.question_answer_layout == 'multi_select_dropdown'
              "
              class="text-center font-16 font_bold"
            >
              * Please select answer(s) to continue
            </div>
            <div
              v-if="question_detail.question_answer_layout == 'date_picker'"
              class="text-center font-16 font_bold"
            >
              * Please select a date to continue
            </div>
            <div
              v-if="
                question_detail.question_answer_layout == 'text' ||
                question_detail.question_answer_layout == 'textarea' ||
                question_detail.question_answer_layout == 'number'
              "
              class="text-center font-16 font_bold"
            >
              * Please enter an answer to continue
            </div>
            <div
              v-if="question_detail.question_answer_layout == 'email'"
              class="text-center font-16 font_bold"
            >
              * Please enter an email to continue
            </div>
          </div>

          <div class="text-center relative mt12">
            <div class="text-left mb-md-20">
              <button
                type="button"
                class="btn-blue-outline btn-left-icon prev-btn"
                @click="loadPreviousQuestion"
                v-if="pervious_question_ids.length > 0"
                :disabled="is_btn_disabled"
              >
                <div class="prev-arrow-icon"><previous-icon></previous-icon></div>
                Previous Question
              </button>
            </div>
            <button
              type="submit"
              class="btn-primary btn-width-136 h-32 d-inline-block px30 next-btn"
              @click="saveAnswer"
              :disabled="is_btn_disabled"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      <risk-assessment-complete-modal
        :location_id="location_id"
        @finish-ra-quiz="saveBreachLogQuestionAnswer"
        v-if="show_completed_modal"
      ></risk-assessment-complete-modal>
      <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
  </div>
</template>

<script>
import headerAfterLogin from "../../../common/includes/headerAfterLogin.vue";
import fullPageLoader from "../../../common/fullPageLoader.vue";
import previousIcon from "../../../common/icons/previousIcon.vue";
import infoIcon from "../../../common/icons/infoIcon.vue";
import RadialProgressBar from "vue3-radial-progress";
import RiskAssessmentCompleteModal from "./riskAssessmentCompleteModal.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import axios from "axios";
toastr.options.preventDuplicates = true;
import _ from "lodash";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      breach_log_id: JS_BREACH_LOG_ID,
      location_id: parseInt(JS_LOCATION_ID),
      total_steps_outer: 100,
      start_color_outer: "#C72121",
      inner_stroke_color: "#CCCCCC",
      percentage_count: 0,
      is_first_page: true,
      show_completed_modal: false,
      question_list: [],
      question_detail: {},
      show_error: false,
      is_btn_disabled: false,
      selected_answer: [],
      question_index: 0,
      attempted_questions: [],
      ba_list: [],
      employee_list: [],
      state_list: [],
      pervious_question_ids: [],
      all_ids: [],
      datepicker_focus: false,
      is_full_page_loader_shown: false,
    };
  },
  components: {
    headerAfterLogin,
    fullPageLoader,
    infoIcon,
    previousIcon,
    RadialProgressBar,
    RiskAssessmentCompleteModal,
  },
  mounted() {
    this.loadQestions();
  },
  watch: {
    percentage_count(val) {
      if (val <= 69) {
        this.start_color_outer = "#C72121";
      } else if (val > 69 && val <= 89) {
        this.start_color_outer = "#FAC224";
      } else {
        this.start_color_outer = "#7FC361";
      }
    },
    selected_answer(val) {
      this.show_error = false;
    },
  },
  methods: {
    updateSelectedEmployee(selected_employee) {
      setTimeout(() => {
        if (selected_employee.id == "None") {
          this.selected_answer = [];
          this.selected_answer.push({ ...selected_employee });
        } else {
          let checkIndex = _.findIndex(this.selected_answer, (e) => e.id == "None");
          if (checkIndex >= 0) {
            this.selected_answer.splice(checkIndex, 1);
          }
        }
      }, 100);
    },

    toggleRiskAssessmentCompleteModal(status = true) {
      this.show_completed_modal = status;
    },

    loadQestions() {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/hipaa-logs/breach-log-ra-question-list")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.question_list = response["data"]["data"];
            _.forEach(this.question_list, (value, key) => {
                if(value.question_code == 'BN8S3'){
                  value.question = value.question.replace(/{%POLICY_URL%}/g, this.JS_APP_URL + '/procedures-policies-forms/' +btoa(this.location_id));
                  this.question_list[key]=value
                }
            });
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },

    startQuiz() {
      this.is_first_page = false;
      this.question_detail = this.question_list[this.question_index];
    },

    async loadNextQuestion(current) {
      await this.getPercentageCount();

      this.question_detail = _.find(this.question_list, (e) => {
        if (e.parent_question_id == current.id) {
          if (e.parent_answer_id == current.selected_answer) {
            return e;
          } else if (typeof current.selected_answer === "object") {
            if (
              Array.isArray(current.selected_answer) &&
              current.selected_answer.includes(e.parent_answer_id)
            ) {
              return e;
            } else if (e.parent_answer_data == current.selected_answer.name) {
              return e;
            }
          } else {
            let ans_arr = e.parent_answer_data.split(",");
            if (ans_arr.includes(current.selected_answer + "")) {
              return e;
            }
          }
        }
      });

      if (!this.question_detail) {
        this.question_detail = _.find(this.question_list, (e, index) => {
          if (e.parent_question_id == current.parent_question_id) {
            if (e.sequence_no > current.sequence_no && e.level == current.level) {
              if (e.parent_answer_id == current.parent_answer_id) {
                return e;
              }
            }
          }
        });

        if (!this.question_detail) {
          await this.getNextParentQuestion(current.parent_question_id);

          if (this.question_detail == undefined) {
            this.show_completed_modal = true;
            return;
          }
        }
      }

      if (
        this.question_detail.question_answer_layout == "single_select_dropdown" ||
        this.question_detail.question_answer_layout == "multi_select_dropdown"
      ) {
        if (this.question_detail.question_answer_layout_data == "BA") {
          if (this.ba_list.length <= 0) {
            await this.getBAList();
          }
        } else if (this.question_detail.question_answer_layout_data == "EMPLOYEE") {
          if (this.employee_list.length <= 0) {
            await this.getEmployeeList();
          }
        } else if (this.question_detail.question_answer_layout_data == "STATE") {
          if (this.state_list.length <= 0) {
            await this.getStateList();
          }
        }
      }

      let index_to_select_answer = this.findAttemptedQuestionIndex(
        this.question_detail.id
      );

      if (index_to_select_answer >= 0) {
        this.selected_answer = this.attempted_questions[
          index_to_select_answer
        ].selected_answer;
      }
    },

    getNextParentQuestion(question_id) {
      let parent_question = _.find(this.question_list, (e) => e.id == question_id);
      if (!parent_question) {
        return undefined;
      }

      let question = _.find(this.question_list, (e) => {
        return (
          e.parent_question_id == parent_question.parent_question_id &&
          e.sequence_no > parent_question.sequence_no &&
          e.level == parent_question.level
        );
      });
      if (!question) {
        this.getNextParentQuestion(parent_question.parent_question_id);
      } else {
        this.question_detail = question;
      }
    },

    loadPreviousQuestion() {
      this.is_full_page_loader_shown = true;
      let perv_question_id = this.pervious_question_ids.pop();
      this.question_detail = _.find(this.question_list, (e) => e.id == perv_question_id);

      let index_to_select_answer = this.findAttemptedQuestionIndex(
        this.question_detail.id
      );
      if (index_to_select_answer >= 0) {
        this.selected_answer = this.attempted_questions[
          index_to_select_answer
        ].selected_answer;
      }
      this.is_full_page_loader_shown = false;
    },
    validateEmail(email_value) {
      let validator = String(email_value).match(/^([\w-\.\+]+@([\w-]+\.)+[\w-]{2,})?$/);
      if (validator == null || validator == false) {
        return false;
      } else {
        return true;
      }
    },

    async saveAnswer() {
      if (this.selected_answer.length <= 0) {
        this.show_error = true;
      }
      if (
        this.question_detail.question_answer_layout == "email" &&
        !this.validateEmail(this.selected_answer)
      ) {
        this.show_error = true;
      }

      if (!this.show_error) {
        this.is_full_page_loader_shown = true;
        let index_to_replace_answer = this.findAttemptedQuestionIndex(
          this.question_detail.id
        );

        let attmpted_que_ans = {
          id: this.question_detail.id,
          qeustion_type: this.question_detail.question_answer_layout,
          question_answer_layout_data: this.question_detail.question_answer_layout_data,
          sequence_no: this.question_detail.sequence_no,
          level: this.question_detail.level,
          parent_question_id: this.question_detail.parent_question_id,
          parent_answer_id: this.question_detail.parent_answer_id,
          selected_answer: this.selected_answer,
        };
        if (index_to_replace_answer >= 0) {
          if (
            this.attempted_questions[index_to_replace_answer].selected_answer !=
            this.selected_answer
          ) {
            let is_same = false;
            if (typeof this.selected_answer === "object") {
              if (
                Array.isArray(this.selected_answer)
              ) {
                let sub_que = [];
                this.selected_answer.forEach(ans => {
                  sub_que = _.filter(this.question_list, (e) => {
                    if (e.parent_answer_id == ans) {
                      is_same = true;
                    }
                  });
                });
              }
            }
            if (!is_same) {
              await this.removeAnswerRecursive(
                this.attempted_questions[index_to_replace_answer].id,
                this.attempted_questions[index_to_replace_answer].selected_answer
              );
            }

            this.attempted_questions[index_to_replace_answer] = attmpted_que_ans;
          }
        } else {
          this.attempted_questions.push(attmpted_que_ans);
        }
        this.pervious_question_ids.push(this.question_detail.id);
        this.selected_answer = [];
        this.all_ids = [];

        await this.loadNextQuestion(attmpted_que_ans);
        this.is_full_page_loader_shown = false;
      }
    },

    async removeAnswerRecursive(question_id, answer) {
      let question = _.filter(this.question_list, (e) => {
        if (e.parent_question_id == question_id) {
          if (e.parent_answer_id == answer) {
            return e;
          } else if (typeof answer === "object") {
            if (Array.isArray(answer) && answer.includes(e.parent_answer_id)) {
              return e;
            } else if (e.parent_answer_data == answer.name) {
              return e;
            }
          } else {
            let ans_arr = e.parent_answer_data.split(",");
            if (ans_arr.includes(answer + "")) {
              return e;
            }
          }
        }
      });

      await question.forEach(async (element) => {
        let index = this.findAttemptedQuestionIndex(element.id);
        if (index >= 0) {
          await this.removeAnswerRecursive(this.attempted_questions[index].id);
          this.attempted_questions.splice(index);
        }
      });
    },

    getPercentageCount() {
      this.getRecursiveCountOfQuestion(this.attempted_questions, this.all_ids);

      const per = Math.round(
        ((this.attempted_questions.length + this.all_ids.length) /
          this.question_list.length) *
          100
      );

      this.percentage_count = per > this.percentage_count ? per : this.percentage_count;
    },

    getRecursiveCountOfQuestion(attempted_question) {
      attempted_question.forEach((atmt_que) => {
        let sub_ques = _.filter(this.question_list, (que) => {
          if (que.parent_question_id == atmt_que.id) {
            if (typeof atmt_que.selected_answer === "object") {
              if (
                Array.isArray(atmt_que.selected_answer) &&
                !atmt_que.selected_answer.includes(que.parent_answer_id)
              ) {
                return que;
              } else if (
                que.parent_answer_data != atmt_que.selected_answer.name &&
                !Array.isArray(atmt_que.selected_answer)
              ) {
                return que;
              }
            } else if (
              que.parent_answer_id &&
              que.parent_answer_id != atmt_que.selected_answer
            ) {
              return que;
            } else {
              if (que.parent_answer_data) {
                let ans_arr = que.parent_answer_data.split(",");
                if (!ans_arr.includes(atmt_que.selected_answer + "")) {
                  return que;
                }
              }
            }
          }
        });
        if (sub_ques.length > 0) {
          this.all_ids.push(...sub_ques);
          this.getRecursiveCountOfQuestion(sub_ques);
        }
      });
    },

    findAttemptedQuestionIndex(question_id) {
      return _.findIndex(
        this.attempted_questions,
        (e) => {
          return e.id == question_id;
        },
        0
      );
    },

    getBAList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/general/get-ba-list?location_id=" +
            this.location_id)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.ba_list = response["data"]["data"];
            this.ba_list.push({
              id: "Other",
              name: "Other",
            });
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },

    getEmployeeList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL +
            "/general/get-employee-list-by-location-id?location_id=" +
            this.location_id
        )
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.employee_list = response["data"]["data"];
            this.employee_list.push({
              id: "None",
              first_name: "None",
              last_name: "",
            });
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },

    getStateList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/general/get-state-list")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.state_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    saveBreachLogQuestionAnswer() {
      this.is_full_page_loader_shown = true;
      axios
        .post(JS_APP_URL + "/hipaa-logs/save-breach-log-ra-question-answer", {
          breach_log_id: this.breach_log_id,
          attempted_questions: this.attempted_questions,
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            this.is_full_page_loader_shown = false;
            if (response["data"]["data"].length > 0) {
              toastr.error(response["data"]["data"].join("</br>"), "Error");
            } else {
              toastr.error(response["data"]["message"], "Error");
            }
          } else {
            window.location =
              JS_APP_URL + "/hipaa-logs/" + btoa(this.location_id) + "/breachlog";
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },

    customLabel(option) {
      if (option.first_name) {
        return `${option.first_name} ${option.last_name}`;
      } else {
        return ``;
      }
    },
  },
};
</script>
