import { createApp } from 'vue';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import DatePicker from 'vue-datepicker-next';
import 'vue-datepicker-next/index.css';
import BreachLogQuiz from "./breachLogQuiz.vue";


const app = createApp(BreachLogQuiz)
app.use(FloatingVue);
app.component('datepicker', DatePicker)
app.component('multiselect', Multiselect);
app.mount("#breach_log_quiz_app")
