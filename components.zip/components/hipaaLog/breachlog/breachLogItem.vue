<template>
    <div>
        <transition name="simple-fade-transition" mode="out-in">
            <div
                class="user-detail-card py6 px20 light mb10"
                v-if="!this.is_edit_breach_log_form_show"
            >
                <div class="row flex-auto -mx-10 items-center">
                    <div
                        class="col-12 col-md-6 col-lg-5 col-xl-5 px10 mb-md-10"
                    >
                        <span class="font-14 gray_checkmark--text word-wrap">
                            {{ getBreachLogListName(breach_log_item) }}
                        </span>
                    </div>
                    <div
                        class="col-12 col-md-6 col-lg-3 col-xl-3 px10 mb-md-10"
                    >
                        <span
                            class="font-10 gray_checkmark--text font-italic word-wrap mr2  margin-4-right-txt"
                            >Last Updated:</span
                        >
                        <span class="font-12 font_semibold blueog--text">{{
                            formatLogDate(breach_log_item.updated_at)
                        }}</span>
                    </div>
                    <div
                        class="col-12 col-md-6 col-lg-4 col-xl-4 px10 mb-md-10"
                    >
                        <div
                            class="flex flex-wrap items-center justify-between breach-log-action"
                        >
                            <div
                                class="flex flex-wrap items-center justify-end ml-auto"
                            >
                                <div class="action-sept mr-auto"></div>

                                <!-- Done file icon -->
                                <VTooltip
                                    :triggers="['hover']"
                                    :popperTriggers="['hover']"
                                    v-if="
                                        breach_log_item.ra_attempt_questions
                                            .length > 0
                                    "
                                >
                                    <button
                                        type="button"
                                        class="action-icon-btn action-btn-blue cursor-pointer complete-action-btn"
                                    >
                                        <span
                                            class="pending-svg-icon inline-flex items-center justify-center"
                                            ><done-icon></done-icon
                                        ></span>
                                    </button>
                                    <template #popper>
                                        Breach RA Completed
                                    </template>
                                </VTooltip>
                                <!-- pending file icon -->
                                <VTooltip
                                    :triggers="['hover']"
                                    :popperTriggers="['hover']"
                                    v-else
                                    class=""
                                >
                                    <button
                                        type="button"
                                        class="action-icon-btn action-btn-blue pending-action-btn cursor-pointer"
                                        @click="
                                            openIncidentRiskAssessmentModal(
                                                breach_log_item
                                            )
                                        "
                                    >
                                        <span
                                            class="pending-svg-icon inline-flex items-center justify-center"
                                            ><pending-icon></pending-icon
                                        ></span>
                                    </button>
                                    <template #popper>
                                        Breach RA Pending
                                    </template>
                                </VTooltip>

                                <VTooltip
                                    :triggers="['hover']"
                                    :popperTriggers="['hover']"
                                    class="ml12"
                                >
                                    <button
                                        type="button"
                                        class="action-icon-btn action-btn-blueog cursor-pointer"
                                        v-on:click="toggleEditBreachLogForm()"
                                    >
                                        <img
                                            :src="
                                                JS_APP_URL +
                                                '/images/pencil.svg'
                                            "
                                            alt=""
                                            title=""
                                        />
                                    </button>
                                    <template #popper> Edit </template>
                                </VTooltip>

                                <button
                                    class="btn-blue-outline btn-left-padding ml12 download-pdf-btn-small breach-download-btn"
                                    type="buttton"
                                    v-on:click="
                                        downloadBreachLogPDF(breach_log_item.id)
                                    "
                                >
                                    <div class="next-arrow-icon pdf-icon">
                                        <pdf-icon> </pdf-icon>
                                    </div>
                                    DOWNLOAD
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- edit breachlog -->
            <editBreachLog
                v-else
                :breach_log_item="breach_log_item"
                :PHI_type_list="PHI_type_list"
                :selected_location_id="selected_location_id"
                :incident_reporter_list_data="incident_reporter_data"
                @edit-breach-log-form-toggle="cancelEditBreachLog"
                @load-updated-breach-log-data="loadUpdatedBreachLog"
                @cancel-edit-breach-log-form="cancelEditBreachLog"
            />
        </transition>
    </div>
</template>
<script>
import NProgress from "nprogress";
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import pdfIcon from "../../common/icons/pdfIcon.vue";
import doneIcon from "../../common/icons/doneIcon.vue";
import pendingIcon from "../../common/icons/pendingfileIcon.vue";
import editBreachLog from "./editBreachLog.vue";
import moment from "moment";
import mitt from 'mitt'
const emitter = mitt()

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_edit_breach_log_form_show: false,
        };
    },
    components: {
        pdfIcon,
        doneIcon,
        pendingIcon,
        editBreachLog,
    },
    emits: ["toggle-incident-risk-assessment-modal", "full-loader", "load-updated-breach-log-data"],
    props: {
        breach_log_item: {
            type: Object,
            default: () => {},
        },
        PHI_type_list: {
            type: Array,
            default: () => [],
        },
        incident_reporter_data: {
            type: Array,
            default: () => [],
        },
        selected_location_id: {
            type: Number,
            default: () => [],
        },
        location_list: {
            type: Array,
            default: () => [],
        },
    },
    mounted() {
        emitter.on("close_other_breachlog_edit", (breach_log_item_id) => {
            if (breach_log_item_id !== this.breach_log_item.id) {
                this.is_edit_breach_log_form_show = false;
            }
        });
    },
    methods: {
        getBreachLogListName(breach_log_item) {
            if (this.location_list.length == 1) {
                return (
                    " Breach Report " +
                    this.formatLogDate(breach_log_item.created_at)
                );
            } else {
                return (
                    breach_log_item.location.location_nickname +
                    " Breach Report " +
                    this.formatLogDate(breach_log_item.created_at)
                );
            }
        },
        loadUpdatedBreachLog(data) {
            this.$emit("load-updated-breach-log-data", data);
        },
        cancelEditBreachLog(status = true) {
            this.is_edit_breach_log_form_show = status;
        },
        formatLogDate(value) {
            return moment(String(value)).format("MM/DD/YYYY");
        },
        toggleEditBreachLogForm() {
            if (this.is_edit_breach_log_form_show == true) {
                this.is_edit_breach_log_form_show = false;
            } else {
                this.is_edit_breach_log_form_show = true;
                this.$root.$emit(
                    "close_other_breachlog_edit",
                    this.breach_log_item.id
                );
            }
        },
        downloadBreachLogPDF(breach_log_id) {
            this.$emit("full-loader", true);
            axios
                .post(JS_APP_URL + `/hipaa-logs/download-breach-log-pdf`, {
                    breach_log_id: breach_log_id,
                })
                .then((response) =>  {
                    if (response["data"]["status"] == "Success") {
                        let link = document.createElement("a");
                        link.setAttribute(
                            "href",
                            response["data"]["data"]["download_url"]
                        );
                        link.setAttribute(
                            "download",
                            response["data"]["data"]["file_name"]
                        );
                        link.setAttribute("target", "_blank");
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    } else {
                        if (response["data"]["data"].length > 0) {
                            toastr.error(
                                response["data"]["data"].join("</br>"),
                                "Error"
                            );
                        } else {
                            toastr.error(response["data"]["message"], "Error");
                        }
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    setTimeout(() => {
                        this.$emit("full-loader", false);
                    }, 100);
                });
        },
        openIncidentRiskAssessmentModal(data) {
            this.$emit(
                "toggle-incident-risk-assessment-modal",
                true,
                data,
                "list"
            );
        },
    },
    created(){
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.is_edit_breach_log_form_show = false;
            }
        });
    },
};
</script>
