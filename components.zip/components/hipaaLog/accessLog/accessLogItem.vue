<template>
    <div>
        <transition name="simple-fade-transition" mode="out-in">
            <div
                class="user-detail-card py6 px15 light mb10"
                v-if="!this.is_edit_form_show"
            >
                <div class="row flex-auto -mx-10 items-center">
                    <div
                        class="col-12 col-md-6 col-lg-1 col-xl-2 px10 mb-md-10 col-access-item-name"
                    >
                        <span class="font-12 gray_checkmark--text word-wrap">{{
                            access_log_item.name
                        }}</span>
                    </div>
                    <div
                        class="col-12 col-md-6 col-lg-2 col-xl-2 px10 mb-md-10 col-access-item-company"
                    >
                        <span class="font-12 gray_checkmark--text word-wrap">{{
                            access_log_item.company_name
                        }}</span>
                    </div>
                    <div
                        class="col-12 col-md-6 col-lg-1 col-xl-1 px10 mb-md-10 col-access-item-log"
                    >
                        <span class="font-12 gray_checkmark--text">{{
                            access_log_item.log_type == 'remote'? "Remote":"Physical"
                        }}</span>
                    </div>
                    <div
                        class="col-12 col-md-6 col-lg-2 col-xl-2 px10 mb-md-10 col-access-item-date"
                    >
                        <span class="font-12 gray_checkmark--text">{{
                           formatLogDate(access_log_item.date_log_in)
                        }}</span>
                    </div>
                    <div
                        class="col-12 col-md-6 col-lg-2 col-xl-2 px10 mb-sm-10 mb-md-10 col-access-item-time"
                    >
                        <span class="font-12 gray_checkmark--text">{{
                            formatLogTime(access_log_item.time_log_in)
                        }}</span>
                    </div>  
                    <div
                        class="col-12 col-md-6 col-lg-2 col-xl-1 px10 mb-sm-10 mb-md-10 col-access-item-time"
                    >
                        <span class="font-12 gray_checkmark--text">{{
                            formatLogTime(access_log_item.time_log_out)
                        }}</span>
                    </div>
                    <div
                        class="col-12 col-md-6 col-lg-2 col-xl-2 px10 text-center access-log-action col-access-item-action"
                    >
                        <div
                            class="flex flex-wrap items-center justify-center justify-start-small-medium user-detail-action"
                        >
                            <div class="action-sept"></div>
                            <VTooltip
                                :triggers="['hover']"
                                :popperTriggers="['hover']"
                            >
                                <button
                                    type="button"
                                    class="action-icon-btn action-btn-blueog cursor-pointer"
                                    v-on:click="accessLogEditFormToggle()"
                                >
                                    <img
                                        :src="JS_APP_URL + '/images/pencil.svg'"
                                        alt=""
                                        title=""
                                    />
                                </button>
                                <template #popper> Edit </template>
                            </VTooltip>
                            <VTooltip
                                :triggers="['hover']"
                                :popperTriggers="['hover']"
                                class="ml7 mr30"
                            >
                                <button
                                    v-on:click="deleteAccessLog()"
                                    type="button"
                                    class="delete-location-btn cursor-pointer"
                                >
                                    <img
                                        :src="JS_APP_URL + '/images/bin.svg'"
                                        alt=""
                                        title=""
                                    />
                                </button>
                                <template #popper> Delete </template>
                            </VTooltip>
                        </div>
                    </div>
                </div>
            </div>

            <editAccessLog
                v-else
                :access_log_item="access_log_item"
                @update-access-log-form-toggle="upateAccessLogFormToggle"
                @load-updated-access-log="loadUpdatedAccessLog"
            />
        </transition>
        <delete-access-log-modal
            v-if="is_delete_access_log_modal_shown"
            :access_log_id="delete_access_log_id"
            @close-model="deleteAccessLogToggle"
            @delete-access-log="deleteAccessLogSubmit"
        ></delete-access-log-modal>
    </div>
</template>
<script>
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
import axios from "axios";
import moment from "moment";
import plusIcon from "../../common/icons/plusIcon.vue";
import infoIcon from "../../common/icons/infoIcon.vue";
import editAccessLog from "./editAccessLog.vue";
import deleteAccessLogModal from "./deleteAccessLogModal.vue";
import mitt from 'mitt'
const emitter = mitt()
export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_edit_form_show: false,
            is_delete_access_log_modal_shown: false,
            delete_access_log_id: "",
        };
    },
    emits: ["close_other_accesslog_edit", "load-access-log-list", "updated-access-log", "deleted-access-log"],
    props: {
        access_log_item: {
            type: Object,
            default: () => {},
        }
    },
    components: {
        plusIcon,
        infoIcon,
        editAccessLog,
        deleteAccessLogModal,
    },
    mounted() {
        emitter.on(
            "close_other_accesslog_edit", (access_log_item_id) => {
                if (access_log_item_id !== this.access_log_item.id) {
                    this.is_edit_form_show = false;
                }
            }
        );
    },
    methods: {
        accessLogEditFormToggle() {
            if (this.is_edit_form_show == true) {
                this.is_edit_form_show = false;
            } else {
                this.is_edit_form_show = true;
                emitter.on(
                    "close_other_accesslog_edit",
                    this.access_log_item.id
                );
            }
        },
        upateAccessLogFormToggle(status = true) {
            this.$emit("load-access-log-list");
            this.is_edit_form_show = status;
        },
        loadUpdatedAccessLog(data) {
            this.$emit("updated-access-log", data);
        },
        formatLogTime(value) {
            return moment(String(value), ["hh:mm"]).format("hh:mm a");
        },
        formatLogDate(value) {
            return moment(String(value)).format("MM/DD/YYYY");
        },
        deleteAccessLog() {
            this.delete_access_log_id = this.access_log_item.id;
            this.is_delete_access_log_modal_shown = true;
            emitter.on(
                "close_other_accesslog_edit",
                this.delete_access_log_id
            );
        },
        deleteAccessLogToggle() {
            this.is_delete_access_log_modal_shown = false;
        },
        deleteAccessLogSubmit() {
            if (this.delete_access_log_id) {
                NProgress.start();
                axios
                    .post(JS_APP_URL + "/hipaa-logs/delete-accesslog", {
                        access_log_id: this.delete_access_log_id,
                    })
                    .then((response) =>  {
                        if (response["data"]["status"] == "Error") {
                            if (response["data"]["data"].length > 0) {
                                toastr.error(
                                    response["data"]["data"].join("</br>"),
                                    "Error"
                                );
                            } else {
                                toastr.error(
                                    response["data"]["message"],
                                    "Error"
                                );
                            }
                        } else {
                            toastr.success(
                                response["data"]["message"],
                                "Success"
                            );
                            setTimeout(() => {
                                this.$emit(
                                    "deleted-access-log",
                                    this.delete_access_log_id
                                );
                            }, 100);
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        NProgress.done();
                        this.is_delete_access_log_modal_shown = false;
                    });
            }
        },
    },
    created() {
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.is_edit_form_show = false;
                this.is_delete_access_log_modal_shown = false;
            }
        });
    },
};
</script>
