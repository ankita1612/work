<template>
    <form @submit.prevent="editAccessLogSubmit">
        <div class="user-detail-card pt10 pb15 px15 light mb10">
            <div class="row flex-auto -mx-10 mb20 mt10">
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{ 'form-group--error': v$.name.$error }"
                    >
                        <input
                            class="form-input location-input-box"
                            :class="{ 'form-error': v$.name.$error }"
                            type="text"
                            name="name"
                            v-model.trim="v$.name.$model"
                        />
                        <label
                            class="label location-input-label"
                            :class="{ 'label-float': v$.name.$model }"
                            >Name</label
                        >
                        <div v-if="v$.name.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.name.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.company_name.$error,
                        }"
                    >
                        <input
                            class="form-input location-input-box"
                            :class="{
                                'form-error': v$.company_name.$error,
                            }"
                            type="text"
                            name="company_name"
                            v-model.trim="v$.company_name.$model"
                        />
                        <label
                            class="label location-input-label"
                            :class="{
                                'label-float': v$.company_name.$model,
                            }"
                            >Company Name</label
                        >
                        <div v-if="v$.company_name.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.company_name.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-6 px10 mb15">
                    <div
                        class="flex flex-wrap items-center flex-auto justify-center justify-start-small-medium mt8"
                    >
                        <div
                            class="font-14 font-light gray_checkmark--text mr12 inline-flex items-center mb-md-10 mb-sm-0"
                        >
                            Log Type:
                        </div>
                        <div class="flex items-center flex-auto mb-0">
                            <div class="radio mr16">
                                <input
                                    id="edit_log_type_option_yes"
                                    name="edit_log_type_option"
                                    type="radio"
                                    value="physical"
                                    v-model.trim="v$.log_type.$model"
                                />
                                <label
                                    for="edit_log_type_option_yes"
                                    class="radio-label font-14 font-light gray_checkmark--text"
                                    >Physical</label
                                >
                            </div>
                            <div class="radio">
                                <input
                                    id="edit_log_type_option_no"
                                    name="edit_log_type_option"
                                    type="radio"
                                    value="remote"
                                    v-model.trim="v$.log_type.$model"
                                />
                                <label
                                    for="edit_log_type_option_no"
                                    class="radio-label font-14 font-light gray_checkmark--text"
                                    >Remote</label
                                >
                            </div>
                            <div v-if="v$.log_type.$errors.length > 0">
                                <div class="form-error-text">
                                    {{ v$.log_type.$errors[0].$message }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-3 col-xl-2 px10 mb10">
                    <div class="flex flex-auto items-center">
                        <div
                            class="mb-0 fill-width relative"
                            :class="{
                                'form-group--error': v$.date_log_in.$error,
                            }"
                        >
                            <datepicker
                                v-model:value="v$.date_log_in.$model"
                                format="MM/DD/YYYY"
                                valueType="YYYY-MM-DD"
                                titleFormat="MM-DD-YYYY"
                                :editable="false"
                                @focus="is_date_log_in_datepicker_focus = true"
                                @blur="is_date_log_in_datepicker_focus = false"
                                class="datepicker-input"
                                type="date"
                                :class="{ 'form-error': v$.date_log_in.$error }"
                            ></datepicker>
                            <label
                                class="label"
                                :class="{
                                    'label-float':
                                        date_log_in ||
                                        is_date_log_in_datepicker_focus,
                                }"
                                >Date Logged In</label
                            >
                            <div v-if="v$.date_log_in.$errors.length > 0">
                                <div class="form-error-text">
                                    {{ v$.date_log_in.$errors[0].$message }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-3 col-xl-2 px10 mb10">
                    <div class="flex flex-auto items-center">
                        <div
                            class="form-group mb-0 fill-width"
                            :class="{
                                'form-group--error': v$.time_log_in.$error,
                            }"
                        >
                            <datepicker
                                v-model:value="v$.time_log_in.$model"
                                format="hh:mm a"
                                valueType="HH:mm"
                                type="time"
                                :editable="false"
                                class="datepicker-input timepicker-input fill-width"
                                @focus="
                                    time_log_out = '';
                                    is_time_log_in_datepicker_focus = true;
                                "
                                @blur="is_time_log_in_datepicker_focus = false"
                                :class="{ 'form-error': v$.time_log_in.$error }"
                            ></datepicker>
                            <label
                                class="label"
                                :class="{
                                    'label-float':
                                        time_log_in ||
                                        is_time_log_in_datepicker_focus,
                                }"
                                >Time Logged In</label
                            >
                            <div v-if="v$.time_log_in.$errors.length > 0">
                                <div class="form-error-text">
                                    {{ v$.time_log_in.$errors[0].$message }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-3 col-xl-2 px10 mb10">
                    <div class="flex flex-auto items-center">
                        <div
                            class="form-group mb-0 fill-width"
                            :class="{
                                'form-group--error': v$.time_log_out.$error,
                            }"
                        >
                            <datepicker
                                v-model:value="v$.time_log_out.$model"
                                format="hh:mm a"
                                valueType="HH:mm"
                                type="time"
                                :editable="false"
                                class="datepicker-input timepicker-input fill-width"
                                @focus="is_time_log_out_datepicker_focus = true"
                                @blur="is_time_log_out_datepicker_focus = false"
                                :default-value="setDefaultLogIntime()"
                                :disabled-time="notBeforeLogInTime"
                                :class="{
                                    'form-error': v$.time_log_out.$error,
                                }"
                            ></datepicker>
                            <label
                                class="label"
                                :class="{
                                    'label-float':
                                        time_log_out ||
                                        is_time_log_out_datepicker_focus,
                                }"
                                >Time Logged Out</label>
                            <div v-if="v$.time_log_out.$errors.length > 0">
                                <div class="form-error-text">
                                    {{ v$.time_log_out.$errors[0].$message }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div
                class="flex items-center flex-wrap submit-cancel-buttons justify-center"
            >
                <div>
                    <button
                        type="submit"
                        class="btn-primary mlr-auto"
                        :disabled="disable_submit_button"
                    >
                        <span>Submit</span>
                    </button>
                </div>
                <div class="ml10">
                    <button
                        type="button"
                        class="btn-cancel-outline btn-cancel-form mlr-auto"
                        :disabled="disable_submit_button"
                        @click="closeAccessLogEditForm"
                    >
                        <span>Cancel</span>
                    </button>
                </div>
            </div>
        </div>
    </form>
</template>
<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import NProgress from "nprogress";
import { useVuelidate } from '@vuelidate/core';
import { required, maxLength, helpers } from "@vuelidate/validators";
import moment from "moment";
import {
    checkSpecialChars,
    checkSpecialCharsErrorMessage,
} from "../../common/customValidation";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            name: this.access_log_item.name,
            company_name: this.access_log_item.company_name,
            log_type: this.access_log_item.log_type,
            date_log_in: this.access_log_item.date_log_in,
            time_log_in: this.formatLogTime(this.access_log_item.time_log_in),
            time_log_out: this.formatLogTime(this.access_log_item.time_log_out),
            disable_submit_button: false,
            is_date_log_in_datepicker_focus: false,
            is_time_log_out_datepicker_focus: false,
            is_time_log_in_datepicker_focus: false,
            checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
        };
    },
    setup: () => ({ v$: useVuelidate() }),
    props: {
        access_log_item: {
            type: Object,
            default: () => {},
        },
    },
    components: {},
    emits: ["load-updated-access-log", "update-access-log-form-toggle"],
    watch: {
        time_log_in(val) {
            if (val == null) {
                this.time_log_out = null;
                this.v$.$touch();
            }
        },
    },
    validations() {
        let validationArray = {
            name: {
                required: helpers.withMessage("Please enter a name", required),
                maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            company_name: {
                required: helpers.withMessage("Please enter a company name", required),
                maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            log_type: {
                required: helpers.withMessage("Please select a log type", required),
            },
            date_log_in: {
                required: helpers.withMessage("Please select a logged in date", required),
            },
            time_log_in: {
                required: helpers.withMessage("Please select a logged in time", required),
            },
            time_log_out: {
                required: helpers.withMessage("Please select a logged out time", required),
            },
        };
        return validationArray;
    },
    methods: {
        formatLogTime(value) {
            return moment(String(value), ["HH:mm:ss"]).format("HH:mm");
        },
        async editAccessLogSubmit() {
            this.v$.$touch();
            const is_valid = await this.v$.$validate();
            if (is_valid) {
                NProgress.start();
                this.disable_submit_button = true;
                axios
                    .post(JS_APP_URL + "/hipaa-logs/update-accesslog", {
                        access_log_id: this.access_log_item.id,
                        name: this.name,
                        company_name: this.company_name,
                        log_type: this.log_type,
                        date_log_in: this.date_log_in,
                        time_log_in: this.time_log_in,
                        time_log_out: this.time_log_out,
                    })
                    .then((response) =>  {
                        if (response["data"]["status"] == "Error") {
                            if (response["data"]["data"].length > 0) {
                                toastr.error(
                                    response["data"]["data"].join("</br>"),
                                    "Error"
                                );
                            } else {
                                toastr.error(
                                    response["data"]["message"],
                                    "Error"
                                );
                            }
                        } else {
                            toastr.success(
                                response["data"]["message"],
                                "Success"
                            );
                            setTimeout(() => {
                                this.$emit(
                                    "load-updated-access-log",
                                    response["data"]["data"]
                                );
                                this.$emit(
                                    "update-access-log-form-toggle",
                                    false
                                );
                            }, 100);
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() =>  {
                        NProgress.done();
                        this.disable_submit_button = false;
                    });
            }
        },
        closeAccessLogEditForm() {
            this.$emit("update-access-log-form-toggle", false);
        },
        notBeforeLogInTime(date) {
            if (this.time_log_in) {
                const time_log_in_array = this.time_log_in.split(":");
                return (
                    date <
                    new Date(
                        new Date().setHours(
                            parseInt(time_log_in_array[0]),
                            parseInt(time_log_in_array[1]),
                            0,
                            0
                        )
                    )
                );
            } else {
                return true;
            }
        },
        setDefaultLogIntime() {
            if (this.time_log_in) {
                const time_log_in_array = this.time_log_in.split(":");
                return new Date(
                    new Date().setHours(
                        parseInt(time_log_in_array[0]),
                        parseInt(time_log_in_array[1]),
                        0,
                        0
                    )
                );
            } else {
                return new Date().setHours(0, 0, 0, 0);
            }
        },
    },
};
</script>
