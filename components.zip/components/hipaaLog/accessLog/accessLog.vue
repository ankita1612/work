<template>
    <div class="training-tab-content pt40">
        <div class="container">
            <div class="flex flex-wrap flex-auto items-center mb20">
                <h6 class="font-18 blueog--text mb0 mr10">Access Log</h6>
                <VTooltip
                    :triggers="['hover']"
                    :popperTriggers="['hover']"
                    style="height: 24px"
                    class="cursor-pointer"
                >
                    <span><info-icon></info-icon></span>
                    <template #popper>
                        The Access Log section is for your practice to log
                        Business Associates or individuals who access your
                        network or Protected Health Information. A PDF of the
                        Access Log can be found in your Policies and Procedures
                        section.
                    </template>
                </VTooltip>
                <button
                    v-on:click="toggleaddAccessLogForm()"
                    type="button"
                    class="plus-icon-btn ml3 mt1"
                >
                    <plus-icon></plus-icon>
                </button>
            </div>
            <transition name="simple-fade-transition">
                <add-access-log
                    v-if="this.is_add_form_show"
                    @add-access-log-form-toggle="addAccessLogFormToggle"
                    @load-access-log-list="loadAccessLogList"
                    :selected_location_id="this.selected_location_id"
                />
            </transition>

            <div class="access-log-listing mt50">
                <div class="px15">
                    <div class="row flex-auto -mx-10 mb10">
                        <div
                            class="col-12 col-md-6 col-lg-1 col-xl-1 px10 mb-md-10 col-access-item-name"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Name</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-6 col-lg-2 col-xl-2 px10 mb-md-10 col-access-item-company"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Company</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-6 col-lg-1 col-xl-1 px10 mb-md-10 col-access-item-log"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Log Type</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-6 col-lg-2 col-xl-2 px10 mb-md-10 col-access-item-date"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Date Logged In</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-6 col-lg-2 col-xl-2 px10 mb-sm-10 col-access-item-time"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Time Logged In</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-6 col-lg-2 col-xl-2 px10 mb-sm-10 col-access-item-time"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Time Logged Out</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-6 col-lg-2 col-xl-2 px10 text-center access-log-action col-access-item-action"
                        >
                            <span class="font-14 font_semibold blue--text ml60"
                                >Actions</span
                            >
                        </div>
                    </div>
                </div>
                <div>
                    <access-log-item
                        v-for="(access_log, index) in access_log_list"
                        :key="index"
                        :access_log_item="access_log"
                        @updated-access-log="updatedAccessLog"
                        @deleted-access-log="deletedAccessLog"
                    />
                    <div
                        v-if="
                            !is_full_page_loader_shown &&
                            access_log_list.length === 0
                        "
                        class=""
                    >
                        <div
                            class="user-detail-text font-14 gray_checkmark--text text-center light pt20 pb20"
                        >
                            <no-data-icon></no-data-icon>
                            <div class="font-14 text-center blueog--text">
                                No access log(s) available.
                            </div>
                        </div>
                    </div>
                </div>
                <InfiniteLoading @infinite="loadAccessLogList(false)" />
            </div>
            <full-page-loader
                v-if="is_full_page_loader_shown"
            ></full-page-loader>
        </div>
    </div>
</template>

<script scoped>
import plusIcon from "../../common/icons/plusIcon.vue";
import infoIcon from "../../common/icons/infoIcon.vue";
import addAccessLog from "./addAccessLog.vue";
import accessLogItem from "./accessLogItem.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../../common/fullPageLoader.vue";
import noDataIcon from "../../common/icons/noDataIcon.vue";
import axios from "axios";
import _ from "lodash";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_add_form_show: false,
            access_log_list: [],
            is_list_loading: false,
            per_page_records: 10,
            current_page: 1,
            total_page: 1,
            is_full_page_loader_shown: false,
            call_ajax: 1,
        };
    },
    components: {
        plusIcon,
        infoIcon,
        addAccessLog,
        accessLogItem,
        fullPageLoader,
        noDataIcon,
    },
    props: {
        selected_location_id: {
            type: Number,
            default: () => {},
        },
    },
    watch: {
        selected_location_id(newVal, oldVal) {
            this.loadAccessLogByLocation(true);
        },
    },
    mounted() {
        this.loadAccessLogList();
    },
    methods: {
        loadAccessLogByLocation() {
            this.loadAccessLogList(true);
        },
        toggleaddAccessLogForm() {
            if (this.is_add_form_show == true) {
                this.is_add_form_show = false;
            } else {
                this.is_add_form_show = true;
            }
        },
        addAccessLogFormToggle(status = true) {
            this.is_add_form_show = status;
        },
        loadAccessLogList(need_pagination_reset = false) {
            if (need_pagination_reset) {
                this.current_page = 1;
                this.total_page = 1;
                this.access_log_list = [];
            }
            if (this.current_page <= this.total_page && this.call_ajax == 1) {
                this.is_list_loading = true;
                this.is_full_page_loader_shown = true;
                this.call_ajax = 0;
                axios
                    .post(
                        JS_APP_URL + `/hipaa-logs/get-accesslog-by-location-id`,
                        {
                            location_id: this.selected_location_id,
                            per_page: this.per_page_records,
                            page: this.current_page,
                        }
                    )
                    .then((response) =>  {
                        if (response["data"]["status"] == "Success") {
                            let access_log_list_data = response.data.data;
                            this.access_log_list.push(
                                ...access_log_list_data.data
                            );
                            this.total_page = access_log_list_data.last_page;
                            if (this.access_log_list.length == 0) {
                                this.is_add_form_show = true;
                            } else {
                                this.is_add_form_show = false;
                            }
                            this.current_page = this.current_page + 1;
                            this.is_list_loading = false;
                        }else{
                            window.location = JS_APP_URL + "/dashboard";
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() =>  {
                        setTimeout(() => {
                            this.call_ajax = 1;
                            this.is_full_page_loader_shown = false;
                        }, 100);
                    });
            }
        },
        updatedAccessLog(access_log_updated = {}) {
            if (!_.isEmpty(access_log_updated)) {
                let found_index = _.findIndex(this.access_log_list, (o) => {
                    return o.id === access_log_updated.id;
                });
                if (found_index >= 0) {
                    this.access_log_list[found_index]=access_log_updated
                }
            }
        },
        deletedAccessLog(deleted_access_log_id = "") {
            if (deleted_access_log_id) {
                let found_index = _.findIndex(this.access_log_list, (o) => {
                    return o.id === deleted_access_log_id;
                });
                if (found_index >= 0) {
                    this.access_log_list.splice(found_index, 1);
                }
                if (this.access_log_list.length == 0) {
                    this.is_add_form_show = true;
                }
            }
        },
    },
    created(){
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.is_add_form_show = false;
            }
        });
    },
};
</script>
