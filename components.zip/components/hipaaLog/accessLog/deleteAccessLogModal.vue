<template>
    <transition name="modal">
        <div class="modal-mask">
            <div class="modal-wrapper animate__animated animate__zoomIn">
                <div class="modal-container Whoa-modal">
                    <button
                        v-if="!is_btn_disabled"
                        v-on:click="closeModal"
                        class="cursor-pointer modal-close"
                    >
                        <close-icon></close-icon>
                    </button>
                    <div class="text-center mlr-auto mb30 pt20">
                        <img
                            :src="JS_APP_URL + '/images/warning.svg'"
                            alt=""
                            title=""
                            class="warning-icon-modal"
                        />
                    </div>
                    <h2
                        class="font-24 font_semibold blueog--text line-normal text-center mb20"
                    >
                        Whoa!
                    </h2>
                    <p
                        class="text-center font-16 gray_checkmark--text line-normal mb30"
                    >
                        Are you sure you want to delete this Log? As a
                        reminder, the information will be automatically saved in
                        your <span class="font-italic">Abyde Drive - Archive</span>.
                    </p>
                    <div
                        class="flex flex-wrap items-center justify-center pb40"
                    >
                        <button
                            :disabled="is_btn_disabled"
                            v-on:click="closeModal"
                            class="btn-cancel-outline mx5"
                        >
                            CANCEL
                        </button>
                        <button
                            :disabled="is_btn_disabled"
                            v-on:click.once="deleteAccessLogSubmit"
                            class="btn-primary btn-width-136 mx5 px30 mt-xs-20"
                        >
                            YES DELETE!
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </transition>
</template>

<script scoped>
import closeIcon from "../../common/icons/closeIcon.vue";

export default {
    props: {
        access_log_id: {
            type: Number,
            default: () => 0,
        },
    },
    components: { closeIcon },
    emits: ["close-model", "delete-access-log"],
    data() {
        return {
            is_btn_disabled: false,
            JS_APP_URL: JS_APP_URL,
        };
    },
    methods: {
        closeModal() {
            this.$emit("close-model", false);
        },
        deleteAccessLogSubmit() {
            this.is_btn_disabled = true;
            this.$emit("delete-access-log");
        },
    },
    created() {
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27 && !this.is_btn_disabled) {
                this.$emit("close-model", false);
            }
        });
    },
    destroyed() {},
};
</script>
