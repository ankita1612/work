<template>
    <div class="training-tab-content pt40">
        <div class="container">
            <div class="flex flex-wrap flex-auto items-center mb30">
                <h6 class="font-18 blueog--text mb0 mr10">Asset Log</h6>
                <VTooltip
                    :triggers="['hover']"
                    :popperTriggers="['hover']"
                    style="height: 24px"
                    class="cursor-pointer"
                >
                    <span><info-icon></info-icon></span>
                    <template #popper>
                        The Asset Log section is for your practice to log all
                        devices that contain electronic protected health
                        information. Using the fields below identify all
                        information around any and all devices (computers,
                        storage devices, servers, phones, etc.) that could
                        contain patient information.
                    </template>
                </VTooltip>
                <button
                    type="button"
                    class="plus-icon-btn ml3 mt1"
                    @click="toggleAddAssetLogForm"
                >
                    <plus-icon></plus-icon>
                </button>
                <div class="import-btn-wrapper ml10">
                    <VTooltip :triggers="['hover']" :popperTriggers="['hover']">
                        <input
                            ref="import_file_upload"
                            type="file"
                            hidden
                            @change="importAssetLog"
                            accept=".xlsx, .xls"
                        />
                        <button
                            @click="onPickImportFile"
                            type="button"
                            class="import-btn"
                        >
                            <span class="import-btn-icon">
                                icon
                            </span>
                            <span>Import</span>
                        </button>
                        <template #popper>
                            <i class="text-center d-block"
                                >If preferred, you may import multiple asset log
                                records via excel file upload. Click here to
                                <b
                                    ><a
                                        class="downloadsamplelink font-300"
                                        :href="sample_import_doc"
                                        target="_blank"
                                        >download the Template File. </a
                                    ></b
                                >Once completed, click the IMPORT button to upload your asset log.</i
                            >
                        </template>
                    </VTooltip>
                </div>

                <div class="import-btn-wrapper ml15">
                    <button
                        @click="exportList"
                        type="button"
                        class="import-btn"
                        :disabled="asset_log_list.length == 0"
                    >
                    <span class="export-btn-icon">
                        icon
                    </span>
                    <span>EXPORT</span>
                    </button>
                </div>
            </div>
            <!-- Add asset log  -->
            <transition name="simple-fade-transition">
                <add-asset-log
                    v-if="is_add_asset_log_form_show"
                    :device_type_list="device_type_list"
                    :operating_system_list="operating_system_list"
                    :asset_encryption_list="asset_encryption_list"
                    :ephi_access_list="ephi_access_list"
                    :assigned_employee_list="assigned_employee_list"
                    :operating_location_list="operating_location_list"
                    :disposal_status_list="disposal_status_list"
                    :selected_location_id="selected_location_id"
                    @add-asset-log-form-toggle="cancelAddAssetLogForm"
                    @load-asset-log-list="loadAssetLogList()"
                />
            </transition>

            <!-- Asset log list -->
            <div class="access-log-listing mb30">
                <div class="flex flex-wrap flex-auto items-center mb20">
                    <h6 class="font-18 blueog--text mb0 mr10">Active Assets</h6>
                    <VTooltip
                        :triggers="['hover']"
                        :popperTriggers="['hover']"
                        style="height: 24px"
                        class="cursor-pointer"
                    >
                        <span><info-icon></info-icon></span>
                        <template #popper> Active Assets </template>
                    </VTooltip>
                </div>
                <div class="px15">
                    <div class="flex row flex-auto -mx-10 mb10">
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-2 px10 mb-md-10 mb-lg-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Device Type &amp; OS</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-md-10 mb-lg-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Name/ID</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Additional Operating Location</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Assignee</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Purchased</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-2 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Encryption</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-2 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >ePHI Access</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-2 px10 mb-md-10 text-center access-log-action"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Actions</span
                            >
                        </div>
                    </div>
                </div>

                <!-- Asset log list -->
                <asset-log-item
                    v-for="active_asset_log_item in activeAssetLogList"
                    :key="active_asset_log_item.id"
                    :active_asset_log_item="active_asset_log_item"
                    :device_type_list="device_type_list"
                    :operating_system_list="operating_system_list"
                    :asset_encryption_list="asset_encryption_list"
                    :ephi_access_list="ephi_access_list"
                    :assigned_employee_list="assigned_employee_list"
                    :disposal_status_list="disposal_status_list"
                    :operating_location_list="operating_location_list"
                    :selected_location_id="selected_location_id"
                    :is_active="true"
                    @load-updated-asset-log-data="loadUpdatedAssetLog"
                    @deleted-asset-log="loadDeletedAssetLog"
                    :change_index_value="index"
                />
                <div
                    v-if="
                        !is_full_page_loader_shown &&
                        activeAssetLogList.length === 0
                    "
                    class=""
                >
                    <div
                        class="user-detail-text font-14 gray_checkmark--text text-center light pt20 pb20"
                    >
                        <no-data-icon></no-data-icon>
                        <div class="font-14 text-center blueog--text">
                            No active asset log(s) available.
                        </div>
                    </div>
                </div>
            </div>
            <div class="access-log-listing mb30">
                <div class="flex flex-wrap flex-auto items-center mb20">
                    <h6 class="font-18 blueog--text mb0 mr10">
                        Inactive Assets
                    </h6>
                    <VTooltip
                        :triggers="['hover']"
                        :popperTriggers="['hover']"
                        style="height: 24px"
                        class="cursor-pointer"
                    >
                        <span><info-icon></info-icon></span>
                        <template #popper> Inactive Assets </template>
                    </VTooltip>
                </div>
                <div class="px15">
                    <div class="row flex-auto -mx-10 mb10">
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-md-10 mb-lg-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Device Type &amp; OS</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-1 col-xl-1 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Name/ID</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-1 col-xl-1 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Additional Operating Location</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-1 col-xl-1 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Assignee</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-1 col-xl-1 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Purchased</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Encryption</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-2 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >ePHI Access</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-1 col-xl-1 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Disposal Status</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-1 col-xl-1 px10 mb-md-10"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Disposal Date</span
                            >
                        </div>
                        <div
                            class="col-12 col-md-4 col-lg-2 col-xl-2 px10 mb-md-10 text-center access-log-action"
                        >
                            <span class="font-14 font_semibold blue--text"
                                >Actions</span
                            >
                        </div>
                    </div>
                </div>
                <!-- Asset log list -->
                <asset-log-item
                    v-for="inactive_asset_log_item in inactiveAssetLogList"
                    :key="inactive_asset_log_item.id"
                    :inactive_asset_log_item="inactive_asset_log_item"
                    :device_type_list="device_type_list"
                    :operating_system_list="operating_system_list"
                    :asset_encryption_list="asset_encryption_list"
                    :ephi_access_list="ephi_access_list"
                    :assigned_employee_list="assigned_employee_list"
                    :disposal_status_list="disposal_status_list"
                    :operating_location_list="operating_location_list"
                    :selected_location_id="selected_location_id"
                    :is_active="false"
                    @load-updated-asset-log-data="loadUpdatedAssetLog"
                    @deleted-asset-log="loadDeletedAssetLog"
                    :change_index_value="index"
                />
                <div
                    v-if="
                        !is_full_page_loader_shown &&
                        inactiveAssetLogList.length === 0
                    "
                    class=""
                >
                    <div
                        class="user-detail-text font-14 gray_checkmark--text text-center light pt20 pb20"
                    >
                        <no-data-icon></no-data-icon>
                        <div class="font-14 text-center blueog--text">
                            No inactive asset log(s) available.
                        </div>
                    </div>
                </div>
            </div>
            <full-page-loader
                v-if="is_full_page_loader_shown"
            ></full-page-loader>
        </div>
        <import-error-modal
          v-if="is_import_error_modal"
          :import_errors="import_errors_data"
          @close-model="openCloseImportModal"
        />
    </div>
</template>
<script>
import axios from "axios";
import plusIcon from "../../common/icons/plusIcon.vue";
import infoIcon from "../../common/icons/infoIcon.vue";
import noDataIcon from "../../common/icons/noDataIcon.vue";
import fullPageLoader from "../../common/fullPageLoader.vue";
import importIcon from "../../common/icons/importIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import addAssetLog from "./addAssetLog.vue";
import assetLogItem from "./assetLogItem.vue";
import _ from "lodash";
import importErrorModal from "../../common/includes/importErrorModal.vue";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_add_asset_log_form_show: false,
            is_full_page_loader_shown: false,
            device_type_list: [],
            operating_system_list: [],
            asset_encryption_list: [],
            ephi_access_list: [],
            assigned_employee_list: [],
            operating_location_list: [],
            disposal_status_list: [],
            asset_log_list: [],
            sample_import_doc: "",
            index: 0,
            is_import_error_modal: false,
            import_errors_data: []

        };
    },
    components: {
        plusIcon,
        noDataIcon,
        infoIcon,
        fullPageLoader,
        addAssetLog,
        assetLogItem,
        importIcon,
        importErrorModal
    },
    mounted() {
        this.loadAssetLogList();
        this.loadDeviceTypeList();
        this.loadOperatingSystemList();
        this.loadAssetEncryptionList();
        this.loadEHIAccessList();
        this.loadAssignedEmployeeList();
        this.loadOperatingLocationList();
        this.loadDisposalStatusList();
    },
    props: {
        selected_location_id: {
            type: Number,
            default: () => {},
        },
    },
    watch: {
        selected_location_id(val) {
            this.loadAssetLogList();
            this.loadAssignedEmployeeList();
            this.$refs.import_file_upload.value = null;
        },
    },
    methods: {
        loadDeletedAssetLog(deleted_asset_log_id = "") {
            if (deleted_asset_log_id) {
                let found_index = _.findIndex(this.asset_log_list, (o) => {
                    return o.id === deleted_asset_log_id;
                });
                if (found_index >= 0) {
                    this.asset_log_list.splice(found_index, 1);
                }
                if (this.asset_log_list.length == 0) {
                    this.is_add_asset_log_form_show = true;
                }
            }
        },
        loadUpdatedAssetLog(asset_log_item = {}) {
            if (!_.isEmpty(asset_log_item)) {
                let found_index = _.findIndex(this.asset_log_list, (o) => {
                    return o.id === asset_log_item.id;
                });
                if (found_index >= 0) {
                    this.asset_log_list[found_index]=asset_log_item;
                }
            }
        },
        toggleAddAssetLogForm() {
            this.is_add_asset_log_form_show = !this.is_add_asset_log_form_show;
        },
        cancelAddAssetLogForm(status = "true") {
            this.is_add_asset_log_form_show = status;
        },
        loadDeviceTypeList() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/hipaa-logs/get-device-type-list")
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.device_type_list = response.data.data;
                    }
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    setTimeout(() => {
                        this.is_full_page_loader_shown = false;
                    }, 100);
                });
        },
        loadOperatingSystemList() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/hipaa-logs/get-operating-system-list")
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.operating_system_list = response.data.data;
                    }
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    setTimeout(() => {
                        this.is_full_page_loader_shown = false;
                    }, 100);
                });
        },
        loadAssetEncryptionList() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/hipaa-logs/get-asset-encryption-list")
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.asset_encryption_list = response.data.data;
                    }
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    setTimeout(() => {
                        this.is_full_page_loader_shown = false;
                    }, 100);
                });
        },
        loadEHIAccessList() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/hipaa-logs/get-ephi-access-list")
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.ephi_access_list = response.data.data;
                    }
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    setTimeout(() => {
                        this.is_full_page_loader_shown = false;
                    }, 100);
                });
        },
        loadAssignedEmployeeList() {
            this.is_full_page_loader_shown = true;
            let obj = {
                id: "assigned_to_business_associate",
                first_name: "Assigned to",
                last_name: "Business Associate",
            };
            axios
                .get(
                    JS_APP_URL +
                        "/general/get-employee-list-by-location-id?location_id=" +
                        this.selected_location_id
                )
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        let employee_list = [];
                        employee_list = response.data.data;
                        employee_list.push(obj);
                        this.assigned_employee_list = employee_list;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    this.is_full_page_loader_shown = false;
                });
        },
        loadOperatingLocationList() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/hipaa-logs/get-operating-location-list")
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.operating_location_list = response.data.data;
                    }
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    setTimeout(() => {
                        this.is_full_page_loader_shown = false;
                    }, 100);
                });
        },
        loadDisposalStatusList() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/hipaa-logs/get-disposal-status-list")
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.disposal_status_list = response.data.data;
                    }
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    setTimeout(() => {
                        this.is_full_page_loader_shown = false;
                    }, 100);
                });
        },
        loadAssetLogList() {
            this.is_full_page_loader_shown = true;
            axios
                .post(JS_APP_URL + `/hipaa-logs/get-assetlog-by-location-id`, {
                    location_id: this.selected_location_id,
                })
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.asset_log_list = response.data.data.asset_log_list;
                        this.sample_import_doc =
                            response.data.data.sample_import_doc;
                        if (this.asset_log_list.length == 0) {
                            this.is_add_asset_log_form_show = true;
                        } else {
                            this.is_add_asset_log_form_show = false;
                        }
                    }else{
                        window.location = JS_APP_URL + "/dashboard";
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    setTimeout(() => {
                        this.is_full_page_loader_shown = false;
                    }, 100);
                });
        },
        exportList() {
            this.is_full_page_loader_shown = true;
            axios
                .post(JS_APP_URL + `/hipaa-logs/export-assetlog`, {
                    location_id: this.selected_location_id,
                })
                .then((response) => {
                    var link = document.createElement("a");
                    link.href = response["data"]["data"]["file"];
                    link.download = response["data"]["data"]["name"];
                    link.click();
                    link.remove();
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    this.is_full_page_loader_shown = false;
                });
        },
        importAssetLog(event) {
            var formData = new FormData();
            formData.append("import_file", event.target.files[0]);
            formData.append("location_id", this.selected_location_id);
            this.is_full_page_loader_shown = true;
            axios
                .post(JS_APP_URL + "/hipaa-logs/import-assetlog", formData, {
                    headers: {
                        "Content-Type": "multipart/form-data",
                    },
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if(response['data']['data'].length == 0){
                            this.openCloseImportModal(response['data']);
                         }else{
                            this.openCloseImportModal(response['data']);
                        }
                        this.loadAssetLogList();
                        this.index = this.index + 1;
                    } else {
                        if(response['data']['data'].length == 0){
                            toastr.success(response["data"]["message"], "Success");
                        }
                        this.loadAssetLogList();
                        this.index = this.index + 1;
                        setTimeout(() => {
                            this.$refs.import_file_upload.value = null;
                            if(response['data']['data'].length != 0){
                              this.openCloseImportModal(response['data']);
                            }
                        }, 100);
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    this.$refs.import_file_upload.value = null;
                    this.is_full_page_loader_shown = false;
                });
        },
        onPickImportFile() {
            this.$refs.import_file_upload.click();
        },
        openCloseImportModal(import_errors) {
            if(!this.is_import_error_modal) {
                this.is_import_error_modal = true
                this.import_errors_data = import_errors;
            } else {
                this.is_import_error_modal = false
            }
        },
    },
    created() {
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.is_add_asset_log_form_show = false;
            }
        });
    },
    computed: {
        activeAssetLogList() {
            let asset_log = this.asset_log_list;
            if (asset_log.length > 0) {
                const active_data = _.filter(asset_log, { status: "active" });
                return active_data;
            } else {
                return asset_log;
            }
        },
        inactiveAssetLogList() {
            let asset_log = this.asset_log_list;
            if (asset_log.length > 0) {
                const inactive_data = _.filter(asset_log, {
                    status: "inactive",
                });
                return inactive_data;
            } else {
                return asset_log;
            }
        },
    },
};
</script>
