<template>
    <div class="user-detail-card py20 px20 light mb10">
        <div class="add-access-log">
            <div class="row flex-auto -mx-10 mb10">
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.device_type.$error,
                        }"
                    >
                        <multiselect
                            v-model="v$.device_type.$model"
                            :options="device_type_list"
                            :close-on-select="true"
                            tag-placeholder=""
                            placeholder=""
                            label="name"
                            track-by="id"
                            :searchable="false"
                            :showLabels="false"
                            :taggable="false"
                        >
                            <template #noResult>
                                <div class="multiselect__noResult text-center">
                                    No results found
                                </div>
                            </template>
                            <template #noOptions>
                                <div class="multiselect__noOptions text-center">
                                    No data available
                                </div>
                            </template>
                        </multiselect>

                        <label
                            class="label label-select"
                            :class="{
                                'label-float': v$.device_type.$model != null,
                            }"
                            >Device Type</label
                        >
                        <div v-if="v$.device_type.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.device_type.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div class="flex items-center flex-auto mb-0">
                        <div
                            class="form-group flex-auto mb-0"
                            :class="{
                                'form-group--error': v$.operating_system.$error,
                            }"
                        >
                            <multiselect
                                v-model="v$.operating_system.$model"
                                :options="operating_system_list"
                                :close-on-select="true"
                                tag-placeholder=""
                                placeholder=""
                                label="name"
                                track-by="id"
                                :searchable="false"
                                :showLabels="false"
                                :taggable="false"
                            >
                                <template #noResult>
                                    <div class="multiselect__noResult text-center">
                                        No results found
                                    </div>
                                </template>
                                <template #noOptions>
                                    <div class="multiselect__noOptions text-center">
                                        No data available
                                    </div>
                                </template>
                            </multiselect>

                            <label
                                class="label label-select"
                                :class="{
                                    'label-float':
                                        v$.operating_system.$model != null,
                                }"
                                >Operating System</label
                            >
                            <div v-if="v$.operating_system.$errors.length > 0">
                                <div class="form-error-text">
                                    {{ v$.operating_system.$errors[0].$message }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="flex flex-wrap items-center flex-auto justify-center justify-start-small-medium mt10 asset-status-block"
                        :class="{ 'form-group--error': v$.status.$error }"
                    >
                        <div
                            class="font-14 font-light gray_checkmark--text mr12 inline-flex items-center mb-md-10 mb-sm-0"
                        >
                            Status:
                        </div>
                        <div class="flex items-center flex-auto mb-0">
                            <div class="radio mr16">
                                <input
                                    id="edit_asset_log_status_active"
                                    name="edit_asset_log_status"
                                    type="radio"
                                    value="active"
                                    v-model="v$.status.$model"
                                />
                                <label
                                    for="edit_asset_log_status_active"
                                    class="radio-label font-14 font-light gray_checkmark--text"
                                    >Active</label
                                >
                            </div>
                            <div class="radio">
                                <input
                                    id="edit_asset_log_status_inactive"
                                    name="edit_asset_log_status"
                                    type="radio"
                                    value="inactive"
                                    v-model="v$.status.$model"
                                />
                                <label
                                    for="edit_asset_log_status_inactive"
                                    class="radio-label font-14 font-light gray_checkmark--text"
                                    >Inactive</label
                                >
                            </div>
                            <div v-if="v$.status.$errors.length > 0">
                                <div class="form-error-text">
                                    {{ v$.status.$errors[0].$message }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="flex flex-auto mb-0"
                        :class="{ 'form-group--error': v$.name.$error }"
                    >
                        <div class="form-group flex-auto mb-0">
                            <input
                                class="form-input"
                                :class="{ 'form-error': v$.name.$error }"
                                type="text"
                                name="name"
                                v-model.trim="v$.name.$model"
                            />
                            <label
                                class="label location-input-label"
                                :class="{ 'label-float': v$.name.$model }"
                                >Name/ID</label
                            >
                            <div v-if="v$.name.$errors.length > 0">
                                <div class="form-error-text">
                                    {{ v$.name.$errors[0].$message }}
                                </div>
                            </div>
                        </div>
                        <div class="mt6 ml2">
                            <VTooltip
                                :triggers="['hover']"
                                :popperTriggers="['hover']"
                                style="height: 30px"
                                class="cursor-pointer"
                            >
                                <span><info-icon></info-icon></span>
                                <template #popper>
                                    Type in the name or asset ID that you would
                                    like associated with this device. This label
                                    should be unique for each device used by
                                    your organization.
                                </template>
                            </VTooltip>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.purchased_date.$error,
                        }"
                    >
                        <datepicker
                            v-model:value="v$.purchased_date.$model"
                            :disabled-date="disabledPurchasedDate"
                            format="MM/DD/YYYY"
                            valueType="YYYY-MM-DD"
                            titleFormat="MM-DD-YYYY"
                            :editable="false"
                            @focus="is_purchased_date_datepicker_focus = true"
                            @blur="is_purchased_date_datepicker_focus = false"
                            class="datepicker-input"
                            type="date"
                            :class="{ 'form-error': v$.purchased_date.$error }"
                        ></datepicker>
                        <label
                            class="label"
                            :class="{
                                'label-float':
                                    purchased_date ||
                                    is_purchased_date_datepicker_focus,
                            }"
                            >Date Purchased</label
                        >
                        <div v-if="v$.purchased_date.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.purchased_date.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.asset_encryption.$error,
                        }"
                    >
                        <multiselect
                            v-model="v$.asset_encryption.$model"
                            :options="asset_encryption_list"
                            :close-on-select="true"
                            tag-placeholder=""
                            placeholder=""
                            label="name"
                            track-by="id"
                            :searchable="false"
                            :showLabels="false"
                            :taggable="false"
                        >
                            <template #noResult>
                                <div class="multiselect__noResult text-center">
                                    No results found
                                </div>
                            </template>
                            <template #noOptions>
                                <div class="multiselect__noOptions text-center">
                                    No data available
                                </div>
                            </template>
                        </multiselect>

                        <label
                            class="label label-select"
                            :class="{
                                'label-float':
                                    v$.asset_encryption.$model != null,
                            }"
                            >Asset Encryption</label
                        >
                        <div v-if="v$.asset_encryption.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.asset_encryption.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.ephi_access.$error,
                        }"
                    >
                        <multiselect
                            v-model="v$.ephi_access.$model"
                            :options="ephi_access_list"
                            :close-on-select="true"
                            tag-placeholder=""
                            placeholder=""
                            label="name"
                            track-by="id"
                            :searchable="false"
                            :showLabels="false"
                            :taggable="false"
                        >
                            <template #noResult>
                                <div class="multiselect__noResult text-center">
                                    No results found
                                </div>
                            </template>
                            <template #noOptions>
                                <div class="multiselect__noOptions text-center">
                                    No data available
                                </div>
                            </template>
                        </multiselect>

                        <label
                            class="label label-select"
                            :class="{
                                'label-float': v$.ephi_access.$model != null,
                            }"
                            >ePHI Access</label
                        >
                        <div v-if="v$.ephi_access.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.ephi_access.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.assigned_employee.$error,
                        }"
                    >
                        <multiselect
                            v-model="v$.assigned_employee.$model"
                            :options="assigned_employee_list"
                            :close-on-select="true"
                            tag-placeholder=""
                            placeholder=""
                            :custom-label="customLabel"
                            track-by="id"
                            :searchable="true"
                            :showLabels="false"
                            :taggable="false"
                        >
                            <template #noResult>
                                <div class="multiselect__noResult text-center">
                                    No results found
                                </div>
                            </template>
                            <template #noOptions>
                                <div class="multiselect__noOptions text-center">
                                    No data available
                                </div>
                            </template>
                        </multiselect>

                        <label
                            class="label label-select"
                            :class="{
                                'label-float':
                                    v$.assigned_employee.$model != null,
                            }"
                            >Assigned Employee</label
                        >
                        <div v-if="v$.assigned_employee.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.assigned_employee.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10 mb15">
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.operating_location.$error,
                        }"
                    >
                        <multiselect
                            v-model="v$.operating_location.$model"
                            :options="operating_location_list"
                            :close-on-select="true"
                            tag-placeholder=""
                            placeholder=""
                            label="name"
                            track-by="id"
                            :searchable="false"
                            :showLabels="false"
                            :taggable="false"
                        >
                            <template #noResult>
                                <div class="multiselect__noResult text-center">
                                    No results found
                                </div>
                            </template>
                            <template #noOptions>
                                <div class="multiselect__noOptions text-center">
                                    No data available
                                </div>
                            </template>
                        </multiselect>

                        <label
                            class="label label-select"
                            :class="{
                                'label-float':
                                    v$.operating_location.$model != null,
                            }"
                            >Additional Operating Location</label
                        >
                        <div v-if="v$.operating_location.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.operating_location.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    class="col-12 col-md-6 col-lg-4 col-xl-3 px10 mb10"
                    v-show="v$.status.$model == 'inactive'"
                >
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.disposal_status.$error,
                        }"
                    >
                        <multiselect
                            v-model="v$.disposal_status.$model"
                            :options="disposal_status_list"
                            :close-on-select="true"
                            tag-placeholder=""
                            placeholder=""
                            label="name"
                            track-by="id"
                            :searchable="false"
                            :showLabels="false"
                            :taggable="false"
                        >
                            <template #noResult>
                                <div class="multiselect__noResult text-center">
                                    No results found
                                </div>
                            </template>
                            <template #noOptions>
                                <div class="multiselect__noOptions text-center">
                                    No data available
                                </div>
                            </template>
                        </multiselect>

                        <label
                            class="label label-select"
                            :class="{
                                'label-float':
                                    v$.disposal_status.$model != null,
                            }"
                            >Disposal Status</label
                        >
                        <div v-if="v$.disposal_status.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.disposal_status.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    class="col-12 col-md-6 col-lg-4 col-xl-3 px10 mb10"
                    v-show="v$.status.$model == 'inactive'"
                >
                    <div
                        class="form-group mb-0"
                        :class="{
                            'form-group--error': v$.disposal_date.$error,
                        }"
                    >
                        <datepicker
                            v-model:value="v$.disposal_date.$model"
                            :disabled-date="disabledDisposalDate"
                            format="MM/DD/YYYY"
                            valueType="YYYY-MM-DD"
                            titleFormat="MM-DD-YYYY"
                            :editable="false"
                            @focus="is_disposal_date_datepicker_focus = true"
                            @blur="is_disposal_date_datepicker_focus = false"
                            class="datepicker-input"
                            type="date"
                            :class="{ 'form-error': v$.disposal_date.$error }"
                        ></datepicker>
                        <label
                            class="label"
                            :class="{
                                'label-float':
                                    disposal_date ||
                                    is_disposal_date_datepicker_focus,
                            }"
                            >Disposal Date</label
                        >
                        <div v-if="v$.disposal_date.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.disposal_date.$errors[0].$message }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt10">
                <div
                    class="flex items-center justify-center flex-wrap flex-auto submit-cancel-buttons"
                >
                    <button
                        type="submit"
                        class="btn-primary mx7"
                        :disabled="disable_submit_button"
                        @click="updateAssetLog"
                    >
                        <span>Submit</span>
                    </button>
                    <button
                        type="button"
                        class="btn-cancel-outline mx7"
                        @click="cancelEditAssetLogForm"
                        :disabled="disable_submit_button"
                    >
                        <span>Cancel</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import axios from "axios";
import infoIcon from "../../common/icons/infoIcon.vue";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import {
    checkSpecialChars,
    checkSpecialCharsErrorMessage,
} from "../../common/customValidation";
import { useVuelidate } from '@vuelidate/core';
import { required, requiredIf, maxLength, helpers } from "@vuelidate/validators";

export default {
    data() {
        return {
            asset_log_id: "",
            name: "",
            purchased_date: "",
            status: "",
            disposal_date: "",
            device_type: null,
            operating_system: null,
            asset_encryption: null,
            ephi_access: null,
            operating_location: null,
            disposal_status: null,
            assigned_employee: null,
            is_purchased_date_datepicker_focus: false,
            is_disposal_date_datepicker_focus: false,
            disabledPurchasedDate: (date) => date <= new Date(1),
            disabledDisposalDate: (date) => date <= new Date(1),
            disable_submit_button: false,
            checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
            operating_location_na : { 'id': 4, "name": "N/A", "operating_location_id" : 4  }
        };
    },
    setup: () => ({ v$: useVuelidate() }),
    emits: ["cancel-edit-asset-log", "load-updated-asset-log", "close-asset-log-form"],
    components: {
        infoIcon,
    },
    watch: {
        status(val) {
            if (val === "active") {
                this.disposal_date = "";
                this.disposal_status = null;
            }
        },
        purchased_date(val) {
            if (val == null) {
                this.disabledDisposalDate = (date) => date <= new Date(1);
            } else {
                var modify_date = new Date(val);
                modify_date.setDate(modify_date.getDate() - 1);
                this.disabledDisposalDate = (date) => date < modify_date;
            }
        },
        disposal_date(val) {
            if (val == null) {
                this.disabledPurchasedDate = (date) =>
                    date <= new Date(1);
            } else {
                var modify_date = new Date(val);
                this.disabledPurchasedDate = (date) =>
                    date >= modify_date || date <= new Date(1);
            }
        },
    },
    props: {
        is_active: {},
        active_asset_log_item: {
            type: Object,
            default: () => {},
        },
        inactive_asset_log_item: {
            type: Object,
            default: () => {},
        },
        device_type_list: {
            type: Array,
            default: () => [],
        },
        operating_system_list: {
            type: Array,
            default: () => [],
        },
        asset_encryption_list: {
            type: Array,
            default: () => [],
        },
        ephi_access_list: {
            type: Array,
            default: () => [],
        },
        assigned_employee_list: {
            type: Array,
            default: () => [],
        },
        operating_location_list: {
            type: Array,
            default: () => [],
        },
        disposal_status_list: {
            type: Array,
            default: () => [],
        },
        selected_location_id: {
            type: Number,
            default: () => {},
        },
    },
    validations() {
        let validationArray = {
            device_type: {
                required: helpers.withMessage("Please select a device type", required),
            },
            operating_system: {
                required: helpers.withMessage("Please select an operating system", required),
            },
            status: {
                required: helpers.withMessage("Please select status", required),
            },
            name: {
                required: helpers.withMessage("Please enter a name/ID", required),
                maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            purchased_date: {
                required: helpers.withMessage("Please select a purchased date", required),
            },
            asset_encryption: {
                required: helpers.withMessage("Please select an asset encryption", required),
            },
            ephi_access: {
                required: helpers.withMessage("Please select an ePHI Access", required),
            },
            operating_location: {
                required: helpers.withMessage("Please select an additional operating location", required),
            },
            assigned_employee: {
                required: helpers.withMessage("Please select an assigned employee", required),
            },
            disposal_status: {
                required: helpers.withMessage('Please select a disposal status', requiredIf(() => {
                    return this.status === "inactive";
                })),
            },
            disposal_date: {
                required: helpers.withMessage('Please select a disposal date', requiredIf(() => {
                    return this.status === "inactive";
                })),
            },
        };
        return validationArray;
    },
    mounted() {
        this.setValueForAssetLogEdit();
    },
    methods: {
        customLabel(option) {
            if (option.first_name && option.last_name) {
                return `${option.first_name} ${option.last_name}`;
            } else {
                return ``;
            }
        },
        setValueForAssetLogEdit() {
            this.asset_log_id = this.is_active
                ? this.active_asset_log_item.id
                : this.inactive_asset_log_item.id;
            this.device_type = this.is_active
                ? this.active_asset_log_item.device_type
                : this.inactive_asset_log_item.device_type;
            this.operating_system = this.is_active
                ? this.active_asset_log_item.operating_system
                : this.inactive_asset_log_item.operating_system;
            this.status = this.is_active
                ? this.active_asset_log_item.status
                : this.inactive_asset_log_item.status;
            this.name = this.is_active
                ? this.active_asset_log_item.name
                : this.inactive_asset_log_item.name;
            this.purchased_date = this.is_active
                ? this.active_asset_log_item.purchased_date
                : this.inactive_asset_log_item.purchased_date;
            this.asset_encryption = this.is_active
                ? this.active_asset_log_item.asset_encryption
                : this.inactive_asset_log_item.asset_encryption;
            this.ephi_access = this.is_active
                ? this.active_asset_log_item.ephi_access
                : this.inactive_asset_log_item.ephi_access;
            this.operating_location = this.is_active
                ? ((this.active_asset_log_item.operating_location == null ? this.operating_location_na :  this.active_asset_log_item.operating_location))
                : ((this.inactive_asset_log_item.operating_location == null ? this.operating_location_na :  this.inactive_asset_log_item.operating_location));
            this.assigned_employee = this.setAssignEmployeeValue();
            this.disposal_status = !this.is_active
                ? this.inactive_asset_log_item.disposal_status
                : null;
            this.disposal_date = !this.is_active
                ? this.inactive_asset_log_item.disposal_date
                : null;
        },
        setAssignEmployeeValue() {
            let obj = {
                id: 'assigned_to_business_associate',
                first_name: "Assigned to",
                last_name: "Business Associate",
            };
            if (this.is_active) {
                if (this.active_asset_log_item.assigned_employee_id === "assigned_to_business_associate") {
                    this.active_asset_log_item.assigned_employee = obj;
                    return this.active_asset_log_item.assigned_employee;
                }else{
                    return this.active_asset_log_item.assigned_employee;
                }
            }
            if(!this.is_active){
                if (this.inactive_asset_log_item.assigned_employee_id === "assigned_to_business_associate") {
                    this.inactive_asset_log_item.assigned_employee = obj;
                    return this.inactive_asset_log_item.assigned_employee;
                }else{
                    return this.inactive_asset_log_item.assigned_employee;
                }
            }
        },
        cancelEditAssetLogForm() {
            this.$emit("cancel-edit-asset-log", false);
        },
        async updateAssetLog() {
            this.v$.$touch();
            const is_valid = await this.v$.$validate();
            if (is_valid) {
                NProgress.start();
                this.disable_submit_button = true;
                axios
                    .post(JS_APP_URL + "/hipaa-logs/update-assetlog", {
                        asset_log_id: this.asset_log_id,
                        location_id: this.selected_location_id,
                        device_type_id: this.device_type.id,
                        operating_system_id: this.operating_system.id,
                        status: this.status,
                        name: this.name,
                        purchased_date: this.purchased_date,
                        asset_encryption_id: this.asset_encryption.id,
                        ephi_access_id: this.ephi_access.id,
                        operating_location_id: this.operating_location
                            ? this.operating_location.id
                            : "",
                        assigned_employee_id: this.assigned_employee.id,
                        disposal_status_id: this.disposal_status
                            ? this.disposal_status.id
                            : "",
                        disposal_date: this.disposal_date,
                    })
                    .then((response) => {
                        if (response["data"]["status"] == "Error") {
                            if (response["data"]["data"].length > 0) {
                                toastr.error(
                                    response["data"]["data"].join("</br>"),
                                    "Error"
                                );
                            } else {
                                toastr.error(
                                    response["data"]["message"],
                                    "Error"
                                );
                            }
                        } else {
                            toastr.success(
                                response["data"]["message"],
                                "Success"
                            );
                            setTimeout(() => {
                                this.$emit(
                                    "load-updated-asset-log",
                                    response["data"]["data"]
                                );
                                this.$emit("close-asset-log-form", false);
                            }, 100);
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        setTimeout(() => {
                            NProgress.done();
                            this.disable_submit_button = false;
                        }, 100);
                    });
            }
        },
    },
};
</script>
