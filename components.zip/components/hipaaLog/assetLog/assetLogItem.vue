<template>
    <div>
        <transition name="simple-fade-transition" mode="out-in">
            <!-- edit asset log -->
            <edit-asset-log
                v-if="is_edit_asset_log_form"
                :active_asset_log_item="active_asset_log_item"
                :inactive_asset_log_item="inactive_asset_log_item"
                :is_active="is_active"
                :device_type_list="device_type_list"
                :operating_system_list="operating_system_list"
                :asset_encryption_list="asset_encryption_list"
                :ephi_access_list="ephi_access_list"
                :assigned_employee_list="assigned_employee_list"
                :operating_location_list="operating_location_list"
                :disposal_status_list="disposal_status_list"
                :selected_location_id="selected_location_id"
                @cancel-edit-asset-log="cancelAssetLogEditForm"
                @load-updated-asset-log="loadUpdatedAssetLog"
                @close-asset-log-form="cancelAssetLogEditForm"
            />
            <div
                v-else
                key="saved"
                class="user-detail-card py7 px15 light mb10"
            >
                <div class="row flex-auto -mx-10 items-center">
                    <div
                        class="col-12 col-md-4 col-lg-2 px10 mb-md-10"
                        :class="{
                            'col-xl-2': is_active,
                            'col-xl-1': !is_active,
                        }"
                    >
                        <div
                            class="user-detail-text font-12 gray_checkmark--text"
                        >
                            {{
                                is_active
                                    ? active_asset_log_item.device_type.name +
                                      ", " +
                                      active_asset_log_item.operating_system
                                          .name
                                    : inactive_asset_log_item.device_type.name +
                                      ", " +
                                      inactive_asset_log_item.operating_system
                                          .name
                            }}
                        </div>
                    </div>
                    <div
                        class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-md-10"
                    >
                        <div
                            class="user-detail-text font-12 gray_checkmark--text"
                        >
                            {{
                                is_active
                                    ? active_asset_log_item.name
                                    : inactive_asset_log_item.name
                            }}
                        </div>
                    </div>
                    <div
                        class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-md-10"
                    >
                        <div
                            class="user-detail-text font-12 gray_checkmark--text"
                        >
                            {{
                                is_active
                                    ? active_asset_log_item.operating_location !==
                                      null
                                        ? active_asset_log_item
                                              .operating_location.name
                                        : "N/A"
                                    : inactive_asset_log_item.operating_location !==
                                      null
                                    ? inactive_asset_log_item.operating_location
                                          .name
                                    : "N/A"
                            }}
                        </div>
                    </div>
                    <div
                        class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-md-10"
                    >
                        <div
                            v-if="is_active || !is_active"
                            class="user-detail-text font-12 gray_checkmark--text"
                        >
                            {{
                                getAssignEmployeeName(
                                    is_active,
                                    active_asset_log_item,
                                    inactive_asset_log_item
                                )
                            }}
                        </div>
                        <div
                            v-else
                            class="user-detail-text font-12 gray_checkmark--text"
                        >
                            -
                        </div>
                    </div>
                    <div
                        class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-md-10"
                    >
                        <div
                            class="user-detail-text font-12 gray_checkmark--text"
                        >
                            {{
                                is_active
                                    ? formatLogDate(
                                          active_asset_log_item.purchased_date
                                      )
                                    : formatLogDate(
                                          inactive_asset_log_item.purchased_date
                                      )
                            }}
                        </div>
                    </div>
                    <div
                        class="col-12 col-md-4 col-lg-2 px10 mb-sm-10"
                        :class="{
                            'col-xl-2': is_active,
                            'col-xl-1': !is_active,
                        }"
                    >
                        <div
                            class="user-detail-text font-12 gray_checkmark--text"
                        >
                            {{
                                is_active
                                    ? active_asset_log_item.asset_encryption
                                          .name
                                    : inactive_asset_log_item.asset_encryption
                                          .name
                            }}
                        </div>
                    </div>
                    <div
                        class="col-12 col-md-4 col-lg-2 col-xl-2 px10 mb-sm-10"
                    >
                        <div
                            class="user-detail-text font-12 gray_checkmark--text"
                        >
                            {{
                                is_active
                                    ? active_asset_log_item.ephi_access.name
                                    : inactive_asset_log_item.ephi_access.name
                            }}
                        </div>
                    </div>
                    <div
                        class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-sm-10"
                        v-if="!is_active"
                    >
                        <div
                            class="user-detail-text font-12 gray_checkmark--text"
                        >
                            {{
                                inactive_asset_log_item.disposal_status
                                    ? inactive_asset_log_item.disposal_status
                                          .name
                                    : null
                            }}
                        </div>
                    </div>
                    <div
                        class="col-12 col-md-4 col-lg-2 col-xl-1 px10 mb-sm-10"
                        v-if="!is_active"
                    >
                        <div
                            class="user-detail-text font-12 gray_checkmark--text"
                        >
                            {{
                                formatLogDate(
                                    inactive_asset_log_item.disposal_date
                                )
                            }}
                        </div>
                    </div>
                    <div
                        class="col-12 col-md-4 col-lg-2 col-xl-2 px10 text-center access-log-action mb-sm-10 mt-md-10"
                    >
                        <div  class="flex flex-wrap items-center">
                            <div class="action-sept"></div>
                            <div
                                class="flex flex-wrap items-center justify-end justify-start-small-medium user-detail-action"
                            >
                                <VTooltip
                                    :triggers="['hover']"
                                    :popperTriggers="['hover']"
                                    class="mx7"
                                >
                                    <button
                                        type="button"
                                        class="action-icon-btn action-btn-blueog cursor-pointer"
                                        @click="openAssetLogEditForm(is_active)"
                                    >
                                        <img
                                            :src="JS_APP_URL + '/images/pencil.svg'"
                                            alt=""
                                            title=""
                                        />
                                    </button>
                                    <template #popper> Edit </template>
                                </VTooltip>
                                <VTooltip
                                    :triggers="['hover']"
                                    :popperTriggers="['hover']"
                                    class="mx7"
                                >
                                    <button
                                        v-on:click="deleteAssetLog()"
                                        type="button"
                                        class="delete-location-btn cursor-pointer"
                                    >
                                        <img
                                            :src="JS_APP_URL + '/images/bin.svg'"
                                            alt=""
                                            title=""
                                        />
                                    </button>
                                    <template #popper> Delete </template>
                                </VTooltip>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
        <delete-asset-log-modal
            v-if="is_delete_asset_log_modal_shown"
            :asset_log_id="delete_asset_log_id"
            @close-model="is_delete_asset_log_modal_shown = false"
            @delete-asset-log="deleteAssetLogSubmit"
        ></delete-asset-log-modal>
    </div>
</template>
<script>
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import axios from "axios";
import infoIcon from "../../common/icons/infoIcon.vue";
import moment from "moment";
import editAssetLog from "./editAssetLog.vue";
import deleteAssetLogModal from "./deleteAssetLogModal.vue";
import mitt from 'mitt'
const emitter = mitt()
import _ from "lodash";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            delete_asset_log_id: "",
            is_edit_asset_log_form: false,
            is_delete_asset_log_modal_shown: false,
        };
    },
    emits: ["load-updated-asset-log-data", "close_other_asset_log_edit", "deleted-asset-log"],
    props: {
        is_active: {},
        inactive_asset_log_item: {
            type: Object,
            default: () => {},
        },
        active_asset_log_item: {
            type: Object,
            default: () => {},
        },
        device_type_list: {
            type: Array,
            default: () => [],
        },
        operating_system_list: {
            type: Array,
            default: () => [],
        },
        asset_encryption_list: {
            type: Array,
            default: () => [],
        },
        ephi_access_list: {
            type: Array,
            default: () => [],
        },
        assigned_employee_list: {
            type: Array,
            default: () => [],
        },
        operating_location_list: {
            type: Array,
            default: () => [],
        },
        disposal_status_list: {
            type: Array,
            default: () => [],
        },
        selected_location_id: {
            type: Number,
            default: () => {},
        },
        change_index_value: {
            type: Number,
        },
    },
    watch: {
        change_index_value() {
            this.is_edit_asset_log_form = false;
        },
    },
    mounted() {
            emitter.on("close_other_asset_log_edit", (id) => {
            if (this.is_active == true) {
                if (id !== this.active_asset_log_item.id) {
                    this.is_edit_asset_log_form = false;
                }
            } else {
                if (id !== this.inactive_asset_log_item.id) {
                    this.is_edit_asset_log_form = false;
                }
            }
        });
    },
    components: {
        infoIcon,
        editAssetLog,
        deleteAssetLogModal,
    },
    methods: {
        getAssignEmployeeName(
            is_active,
            active_asset_log_item,
            inactive_asset_log_item
        ) {
            if (is_active) {
                if (
                    active_asset_log_item.assigned_employee_id ===
                    "assigned_to_business_associate"
                ) {
                    return "Assigned to Business Associate";
                }
                if (active_asset_log_item.assigned_employee) {
                    return (
                        active_asset_log_item.assigned_employee.first_name +
                        " " +
                        active_asset_log_item.assigned_employee.last_name
                    );
                } else {
                    return "";
                }
            }
            if (!is_active) {
                if (
                    inactive_asset_log_item.assigned_employee_id ===
                    "assigned_to_business_associate"
                ) {
                    return "Assigned to Business Associate";
                }

                if (inactive_asset_log_item.assigned_employee) {
                    return (
                        inactive_asset_log_item.assigned_employee.first_name +
                        " " +
                        inactive_asset_log_item.assigned_employee.last_name
                    );
                } else {
                    return "";
                }
            }
        },
        loadUpdatedAssetLog(asset_log_item = {}) {
            this.$emit("load-updated-asset-log-data", asset_log_item);
        },
        formatLogDate(value) {
            return moment(String(value)).format("MM/DD/YYYY");
        },
        cancelAssetLogEditForm(status = "true") {
            this.is_edit_asset_log_form = status;
        },
        openAssetLogEditForm(is_active) {
            if (this.is_edit_asset_log_form == true) {
                this.is_edit_asset_log_form = false;
            } else {
                if (is_active) {
                    if (
                        this.active_asset_log_item.assigned_employee == null &&
                        this.active_asset_log_item.assigned_employee_id !==
                            "assigned_to_business_associate"
                    ) {
                        toastr.error(
                            "Oops! You can't edit this Log because the employee involved has been deleted/moved from your Account/Location",
                            "Error"
                        );
                    } else {
                        let find_employee = _.find(
                            this.assigned_employee_list,
                            (o) => {
                                return (
                                    o.id ==
                                    this.active_asset_log_item
                                        .assigned_employee_id
                                );
                            }
                        );
                        if (_.isUndefined(find_employee)) {
                            toastr.error(
                                "Oops! You can't edit this Log because the employee involved has been deleted/moved from your Account/Location",
                                "Error"
                            );
                        } else {
                            this.is_edit_asset_log_form = true;
                            this.$root.$emit(
                                "close_other_asset_log_edit",
                                this.active_asset_log_item.id
                            );
                        }
                    }
                } else {
                    if (
                        this.inactive_asset_log_item.assigned_employee ==
                            null &&
                        this.inactive_asset_log_item.assigned_employee_id !==
                            "assigned_to_business_associate"
                    ) {
                        toastr.error(
                            "Oops! You can't edit this Log because the employee involved has been deleted/moved from your Account/Location",
                            "Error"
                        );
                    } else {
                        let find_employee = _.find(
                            this.assigned_employee_list,
                            (o) => {
                                return (
                                    o.id ==
                                    this.inactive_asset_log_item
                                        .assigned_employee_id
                                );
                            }
                        );
                        if (_.isUndefined(find_employee)) {
                            toastr.error(
                                "Oops! You can't edit this Log because the employee involved has been deleted/moved from your Account/Location",
                                "Error"
                            );
                        } else {
                            this.is_edit_asset_log_form = true;
                            this.$root.$emit(
                                "close_other_asset_log_edit",
                                this.inactive_asset_log_item.id
                            );
                        }
                    }
                }
            }
        },
        deleteAssetLog() {
            if (this.is_active == true) {
                this.delete_asset_log_id = this.active_asset_log_item.id;
            } else {
                this.delete_asset_log_id = this.inactive_asset_log_item.id;
            }
            this.is_delete_asset_log_modal_shown = true;
            this.$root.$emit(
                "close_other_asset_log_edit",
                this.delete_asset_log_id
            );
        },
        deleteAssetLogSubmit() {
            if (this.delete_asset_log_id) {
                NProgress.start();
                axios
                    .post(JS_APP_URL + "/hipaa-logs/delete-assetlog", {
                        asset_log_id: this.delete_asset_log_id,
                    })
                    .then((response) => {
                        if (response["data"]["status"] == "Error") {
                            if (response["data"]["data"].length > 0) {
                                toastr.error(
                                    response["data"]["data"].join("</br>"),
                                    "Error"
                                );
                            } else {
                                toastr.error(
                                    response["data"]["message"],
                                    "Error"
                                );
                            }
                        } else {
                            toastr.success(
                                response["data"]["message"],
                                "Success"
                            );
                            setTimeout(() => {
                                this.$emit(
                                    "deleted-asset-log",
                                    this.delete_asset_log_id
                                );
                            }, 100);
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        NProgress.done();
                        this.is_delete_asset_log_modal_shown = false;
                    });
            }
        },
    },
    created() {
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.is_edit_asset_log_form = false;
            }
        });
    },
};
</script>
