import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import DatePicker from 'vue-datepicker-next';
import 'vue-datepicker-next/index.css';
import hipaaLog from "../hipaaLog/hipaaLog.vue";
import InfiniteLoading from "v3-infinite-loading";
import VueMask from '@devindex/vue-mask';

const app = createApp(hipaaLog)
app.use(VueMask);
app.use(FloatingVue);
app.component('datepicker', DatePicker)
app.component('multiselect', Multiselect);
app.component('InfiniteLoading', InfiniteLoading);
app.mount("#hipaa_log_app")
