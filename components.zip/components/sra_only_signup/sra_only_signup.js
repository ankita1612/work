import { createApp } from 'vue'
import signup from "./sra_only_signup.vue";
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.css';
import FloatingVue from 'floating-vue'
import 'floating-vue/dist/style.css'
import VueMask from '@devindex/vue-mask';

const app = createApp(signup);
app.component('multiselect', Multiselect);
app.use(VueMask);
app.use(FloatingVue);
app.mount('#sra_only_signup');
