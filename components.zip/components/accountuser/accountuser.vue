<template>
	<div>
		<header-after-login></header-after-login>
		<div class="container  pt20">
			<div class="flex items-center justify-center text-center flex-wrap mb50">
				<h1 class="location-dashbaord-title text-center font-24 font_semibold blueog--text line-normal mb10">
					Users & Contributors
				</h1>	
				<VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml6 mb10">
					<button @click="PlayExplainerVideoModalToggle('yes')" class="cursor-pointer svg-icon-height dashboard-video-icon mt4">
					<explainer-video-icon></explainer-video-icon>
					</button>
					<template #popper>
					Video Guide
					</template>
				</VTooltip>
			</div>
		</div>
		<div class="training-tabs-wrapper pb50">
            <div class="training-tab-nav">
                <div
                    class="container flex items-center flex-wrap justify-evenly"
                >
                    <button
                        type="button"
                        class="training-tab-nav-item font-21 mr50"
                        v-on:click="changeLogTab('users')"
                        :class="{ active: current_log_tab == 'users' }"
                    >
                        Account Users
                    </button>
                    <button
                        type="button"
                        class="training-tab-nav-item sharp-tab-item font-21 ml50"
                        v-on:click="changeLogTab('sra_contributor')"
                        :class="{ active: current_log_tab == 'sra_contributor' }"
                    >
                        SRA Contributors
                    </button>
                </div>
            </div>
			<accountusertab v-if="current_log_tab == 'users'" ></accountusertab>
			<sracontributortab v-if="current_log_tab == 'sra_contributor'"></sracontributortab>
        </div>
		<play-explainer-video-modal v-if="play_video_modal == true" :video_file="video_file"
      	:video_caption_file="video_caption_file" @close-model="PlayExplainerVideoModalToggle"></play-explainer-video-modal>
	</div>	
</template>

<script scoped>
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";

import explainerVideoIcon from "../common/icons/explainerVideoIcon.vue";
import playExplainerVideoModal from "../common/includes/playExplainerVideoModal.vue";
import accountusertab from "./accountusertab.vue";
import sracontributortab from "./sracontributor/sracontributortab.vue";
import _ from "lodash";

export default {
  data() {
    return {
      is_import_error_modal: false,
      import_errors_data: [],
      video_file: "hce_explainer_users_final.mp4",  
      video_caption_file: "hce_explainer_users_final.vtt",  
      play_video_modal: false,
      current_log_tab: "users",
    };
  },

  components: {
	  headerAfterLogin: headerAfterLogin,
	  explainerVideoIcon,
    playExplainerVideoModal,
	  accountusertab,
	  sracontributortab
  },

  validations: {
  },

  mounted() {
  },

  watch: {
  },

  computed: {},

  methods: {
	changeLogTab(log_type) {
            if (this.current_log_tab != log_type) {
                this.current_log_tab = log_type;
            } else {
                return false;
            }
        },
	PlayExplainerVideoModalToggle() {
      if (this.play_video_modal == true) {
        this.play_video_modal = false;
      } else {
        this.play_video_modal = true;
      }
    },
  },
};
</script>
