<template>
    <div>
        <transition name="simple-fade-transition" mode="out-in">
        <div v-if="!is_account_user_editing" key="saved" class="user-detail-card py7 px15 light mb20">
            <div class="row flex-auto -mx-10 items-center">
                <div class="col-12 col-md-5 col-lg-2 col-xl-2 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text" v-text="account_user_item.first_name"></div>
                </div>
                <div class="col-12 col-md-7 col-lg-2 col-xl-2 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text"  v-text="account_user_item.last_name"></div>
                </div>
                <div class="col-12 col-md-5 col-lg-3 col-xl-3 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text"  v-text="account_user_item.email"></div>
                </div>
                <div class="col-6 col-sm-6 col-md-7 col-lg-2 col-xl-3 px10">
                    <div class="flex-auto user-location-name-block word-wrap text-truncate white-no-wrap">
                        <VTooltip class="text-center fill-width" v-if="account_user_item.account_location_access.length == 1 && all_location_list.length > 1" :triggers="['hover']"  :popperTriggers="['hover']">
                            <span  class="user-admin-name font-12 gray_checkmark--text uppercase word-wrap text-truncate white-no-wrap tuncate-location-width" :title="account_user_item.account_location_access[0].location.location_nickname">{{account_user_item.account_location_access[0].location.location_nickname}}</span>
                            <template #popper>
                                <div class="white--text font-12 font_semibold mb2 text-center pb5 pt5">LOCATION ACCESS</div>
                                <div class="text-center seperator-line pt3 pb3" >{{account_user_item.account_location_access[0].location.location_nickname}}</div>
                            </template>
                        </VTooltip>
                        <button v-if="account_user_item.account_location_access.length > 1" type="button" class="user-location-icon cursor-pointer mt2">
                            <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                                <img :src="JS_APP_URL +'/images/location.svg'" alt="" title="">
                                <template #popper>
                                    <div class="white--text font-12 font_semibold mb2 text-center pb5 pt5">LOCATION ACCESS</div>
                                    <div class="text-center seperator-line pt3 pb3" v-for="(each_location, each_location_index) in account_user_item.account_location_access" v-bind:key="each_location_index" v-text="each_location.location.location_nickname"></div>
                                </template>
                            </VTooltip>
                        </button>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-2 px10">
                    <div class="flex flex-wrap items-center justify-end justify-start-small-medium user-detail-action">
                        <button type="button" class="user-location-icon user-hco-btn pr3" v-if="account_user_item.hipaa_compliance_officer.length > 0">
                            <VTooltip  :triggers="['hover']"  :popperTriggers="['hover']" style="height:24px">
                                <img :src="JS_APP_URL +'/images/hco-badge1.svg'" alt="" title="" class="cursor-pointer user-hco-icon">
                                <template #popper>
                                    <div v-if="all_location_list.length == 1" class="white--text font-12 font_semibold mb2 text-center">HCO LOCATION</div>
                                    <div v-if="all_location_list.length > 1" class="white--text font-12 font_semibold mb2 text-center pb5 pt5">HCO LOCATION(S)</div>
                                    <div v-for="(each_location, each_location_index) in account_user_item.hipaa_compliance_officer" v-bind:key="each_location_index" v-text="each_location.location.location_nickname" class="text-center seperator-line pt3 pb3"></div>
                                </template>
                            </VTooltip>
                        </button>
                        <div class="action-sept mr30 ml20"></div>
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                            <button v-on:click="(AUTH_USER.user_type == 'HCO' && AUTH_USER.id == account_user_item.id)?null:editAccountUserDetail()" type="button" class="action-icon-btn action-btn-blueog cursor-pointer" :disabled="AUTH_USER.user_type == 'HCO' && AUTH_USER.id == account_user_item.id">
                                <img :src="JS_APP_URL +'/images/pencil.svg'" alt="" title="">
                            </button>
                            <template #popper>
                                Edit
                            </template>
                        </VTooltip>
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml7">
                            <button v-on:click="(AUTH_USER.user_type == 'HCO' && AUTH_USER.id == account_user_item.id)?null:deleteAccountUserToggle()" type="button" class="delete-location-btn cursor-pointer" :disabled="AUTH_USER.user_type == 'HCO' && AUTH_USER.id == account_user_item.id">
                                <img :src="JS_APP_URL +'/images/bin.svg'" alt="" title="">
                            </button>
                            <template #popper>
                                Delete
                            </template>
                        </VTooltip>
                    </div>
                </div>
            </div>
        </div>
        <div v-else key="editing" class="user-detail-card pt18 pb22 px15 light mb20">
            <form @submit.prevent="editAccountUserSubmit">
                <div class="row flex-auto -mx-10 items-start">
                    <div class="col-12 col-md-12 col-lg-9 col-xl-9 px10">
                            <div class="row flex-auto -mx-10">
                                <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                    <div class="form-group" :class="{ 'form-group--error': v$.first_name.$errors.length }">
                                        <input class="form-input location-input-box" :class="{ 'form-error': v$.first_name.$errors.length }" type="text" name="first_name" v-model.trim="v$.first_name.$model">
                                        <label class="label location-input-label" :class="{ 'label-float': v$.first_name.$model }">First Name</label>
                                        <div v-if="v$.first_name.$errors.length > 0">
                                            <div class="form-error-text">
                                                {{ v$.first_name.$errors[0].$message }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                    <div class="form-group" :class="{ 'form-group--error': v$.last_name.$errors.length }">
                                        <input class="form-input location-input-box" :class="{ 'form-error': v$.last_name.$errors.length }" type="text" name="last_name" v-model.trim="v$.last_name.$model">
                                        <label class="label location-input-label" :class="{ 'label-float': v$.last_name.$model }">Last Name</label>
                                        <div v-if="v$.last_name.$errors.length > 0">
                                            <div class="form-error-text">
                                                {{ v$.last_name.$errors[0].$message }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                    <div class="form-group" :class="{ 'form-group--error': v$.email.$errors.length }">
                                        <input class="form-input location-input-box" :class="{ 'form-error': v$.email.$errors.length }" type="text" name="email" v-model.trim="v$.email.$model">
                                        <label class="label location-input-label" :class="{ 'label-float': v$.email.$model }">Email</label>
                                        <div v-if="v$.email.$errors.length > 0">
                                            <div class="form-error-text">
                                                {{ v$.email.$errors[0].$message }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="hippa-compliance-usercolumn px8 mb-sm-20 mb-md-10 mb-lg-10 self-center" :class="{ 'form-group--error': v$.edit_hco_option.$errors.length }">
                                    <div class="flex flex-auto flex-wrap mb-sm-20 self-center">
                                        <div class="font-14 font-light gray_checkmark--text mr8 inline-flex items-center">
                                            HIPAA Compliance Officer:
                                            <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" style="height: 27px;" class="cursor-pointer"><info-icon class="cursor-pointer ml2"></info-icon>
                                            <template #popper>
                                                The individual responsible for the planning, development, coordination and evaluation of the organization's HIPAA Compliance and health management activities.
                                            </template>
                                            </VTooltip>
                                        </div>
                                        <div class="form-group flex items-center mb-0" >
                                            <div class="radio mr16">
                                                <input @click="HCOClicked" @change="v$.edit_hco_option.$touch" v-model.trim="v$.edit_hco_option.$model" :id="'edit_hco_option_yes_'+account_user_item.id" name="edit_hco_option" type="radio" value="yes">
                                                <label :for="'edit_hco_option_yes_'+account_user_item.id" class="radio-label font-14 font-light gray_checkmark--text">Yes</label>
                                            </div>
                                            <div class="radio">
                                                <input @click="HCOClicked" @change="v$.edit_hco_option.$touch" v-model.trim="v$.edit_hco_option.$model" :id="'edit_hco_option_no_'+account_user_item.id" name="edit_hco_option" type="radio" value="no">
                                                <label :for="'edit_hco_option_no_'+account_user_item.id" class="radio-label font-14 font-light gray_checkmark--text">No</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div v-if="v$.edit_hco_option.$errors.length > 0">
                                        <div class="form-error-text">
                                            {{ v$.edit_hco_option.$errors[0].$message }}
                                        </div>
                                    </div>
                                </div>
                                <div v-if="edit_hco_option == 'yes' && all_location_list.length > 1" class="col-12 col-md-6 col-lg-5 col-xl-3 px10 mb-sm-20">
                                    <div class="form-group mb-0" :class="{ 'form-group--error': v$.selected_hco_locations.$errors.length }">
                                        <multiselect
                                        ref="select_hco"
                                        v-model="v$.selected_hco_locations.$model"
                                        tag-placeholder=""
                                        placeholder=""
                                        label="location_nickname"
                                        track-by="id"
                                        :options="all_location_list"
                                        :multiple="true"
                                        :close-on-select="false"
                                        @select="assignHCODropdownAddItem"
                                        @remove="assignHCODropdownRemoveItem"
                                        :showLabels="false"
                                        :taggable="false">
                                            <template #noResult>
                                                <div class="multiselect__noResult text-center">No results found</div>
                                            </template>
                                            <template #noOptions>
                                                <div class="multiselect__noOptions text-center">No data available</div>
                                            </template>
                                            <template #selection>
                                                <div class="multiselect__tags-wrap" v-if="selected_hco_locations.length > 1">
                                                    <span class="multiselect__tag">
                                                        <span>{{ selected_hco_locations.length }} Locations Selected</span>
                                                    </span>
                                                </div>
                                            </template>
                                        </multiselect>
                                        <label class="label label-select" :class="{ 'label-float': (selected_hco_locations.length > 0) }">Assigned HCO Location(s)</label>
                                        <div v-if="v$.selected_hco_locations.$errors.length > 0">
                                            <div class="form-error-text">
                                                {{ v$.selected_hco_locations.$errors[0].$message }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-5 col-xl-3 px10">
                                    <div v-if="all_location_list.length > 1" class="form-group mb-0" :class="{ 'form-group--error': v$.selected_access_locations.$errors.length }">
                                        <multiselect
                                        class="select-all-dropdown"
                                        v-model="v$.selected_access_locations.$model"
                                        tag-placeholder=""
                                        placeholder=""
                                        label="location_nickname"
                                        track-by="id"
                                        :options="local_all_location_list"
                                        group-values="group_option_list"
                                        group-label="select_all"
                                        :group-select="true"
                                        :multiple="true"
                                        :showLabels="false"
                                        :close-on-select="false"
                                        @remove="removeLocationAccess"
                                        :taggable="false">
                                            <template #noResult>
                                                <div class="multiselect__noResult text-center">No results found</div>
                                            </template>
                                            <template #selection>
                                                <div class="multiselect__tags-wrap" v-if="selected_access_locations.length > 1">
                                                    <span class="multiselect__tag">
                                                        <span>{{ selected_access_locations.length }} Locations Selected</span>
                                                    </span>
                                                </div>
                                            </template>
                                        </multiselect>
                                         <label class="label label-select" :class="{ 'label-float': (selected_access_locations.length > 0) }">Location Access</label>
                                         <div v-if="v$.selected_access_locations.$errors.length > 0">
                                            <div class="form-error-text">
                                                {{ v$.selected_access_locations.$errors[0].$message }}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-3 col-xl-3 pl10 pr0 mt-sm-20">
                        <div class="flex items-center flex-wrap submit-cancel-buttons">
                            <button
                            type="submit"
                            class="btn-primary mlr-auto"
                            :disabled="disable_accountuser_submit_btn"
                            >
                                <span>Submit</span>
                            </button>
                            <button
                            type="button"
                            class="btn-cancel-outline btn-cancel-form mlr-auto"
                            :disabled="disable_accountuser_submit_btn"
                            @click="cancelEditAccountUser"
                            >
                                <span>Cancel</span>
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        </transition>
        <delete-account-user-modal
        v-if="is_deleteaccountusermodal_shown"
        :account_user_id="deleteaccountusermodal_account_user_id"
        @close-model="deleteAccountUserToggle"
        @delete-account-user="deleteAccountUserSubmit"
        ></delete-account-user-modal>
        <already-hco-available-modal
        v-if="is_alreadyhcoavailablemodal_shown"
        @close-model="clsoeHCOAvailableToggle"
        @not-replace-hco="notReplaceHCO"
        ></already-hco-available-modal>
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from 'lodash';
import useVuelidate from "@vuelidate/core";
import { required, requiredIf, email, maxLength, helpers } from "@vuelidate/validators";
import deleteAccountUserModal from "./deleteAccountUserModal.vue";
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
import alreadyHcoAvailableModal from './alreadyHcoAvailableModal.vue';
import infoIcon from "../common/icons/infoIcon.vue";
import {checkSpecialChars, checkSpecialCharsErrorMessage}  from "../common/customValidation";
import mitt from 'mitt'
const emitter = mitt()

export default {
    data() {
        return {
        account_user_id: '',
        first_name: '',
        last_name: '',
        email: '',
        edit_hco_option: '',
        local_all_location_list : [{
            'select_all': 'Select All',
            'group_option_list': this.all_location_list,
        }],
        selected_access_locations: [],
        selected_hco_locations: [],
        is_account_user_editing: false,
        disable_accountuser_submit_btn: false,
        is_deleteaccountusermodal_shown: false,
        deleteaccountusermodal_account_user_id: "",
        is_alreadyhcoavailablemodal_shown: false,
        contrinutor_questions_count_arr: [],
        hco_available_location_id: "",
        check_hco_available_timer: null,
        JS_APP_URL: JS_APP_URL,
        JS_WORDPRESS_URL: JS_WORDPRESS_URL,
        AUTH_USER: AUTH_USER,
        checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage
        };
    },
    components: {
        deleteAccountUserModal: deleteAccountUserModal,
        clearDropdownIcon,
        alreadyHcoAvailableModal,
        infoIcon
    },
    props: {
        account_user_item:{
            type: Object,
            default: () => {}
        },
        all_location_list:{
            type: Array,
            default: () => []
        },
    },
    emits: ['close_other_user_edit', "updated-account-user", "adjust-HCO-list", "deleted-account-user"],
    setup: () => ({ v$: useVuelidate() }),
    validations() {
        var validationArray = {
            first_name: {
                required: helpers.withMessage("Please enter a first name", required),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
                maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
            },
            last_name: {
                required: helpers.withMessage("Please enter a last name", required),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
                maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
            },
            email: {
                email: helpers.withMessage("Please enter a valid email", email),
                required: helpers.withMessage("Please enter an email", required),
                maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
                isUnique: helpers.withMessage("Email address already in use", helpers.withAsync(async (value) => {
                    if (!value) return true;
                    if (this.v$.email.required.$invalid || this.v$.email.email.$invalid) return true;
                    this.disable_accountuser_submit_btn = true;
                    let check_promise = new Promise((resolve, reject) => {
                        if (this.check_hco_available_timer) {
                            clearTimeout(this.check_hco_available_timer);
                            this.check_hco_available_timer = null;
                        }
                        this.check_hco_available_timer = setTimeout(() => {
                            return fetch(JS_APP_URL + `/accountuser/check-unique-email-accountuser-primary-user/${value}/account_user/${this.account_user_id}`)
                            .then((response) => {
                                    if (response.ok) {
                                        resolve(response.text());
                                    } else {
                                        resolve(new Error("error"));
                                    }
                                },
                                (error) => {
                                    resolve(new Error("error"));
                                }
                            );
                        }, 500);
                    });
                    let response = await check_promise;
                    this.disable_accountuser_submit_btn = false;
                    return Boolean(response == "available" ? false : true);
                }))
            },
            selected_access_locations: {
                required: helpers.withMessage("Please select location(s)", requiredIf(() => {
                    return (this.all_location_list.length > 1)
                }))
            },
            edit_hco_option: {
                required: helpers.withMessage("Please select a HIPAA Compliance officer", required),
            },
            selected_hco_locations: {
                required: helpers.withMessage("Please select HCO location(s)", requiredIf(() => {
                    return (this.edit_hco_option == 'yes' && this.all_location_list.length > 1)
                }))
            }
        };
        return validationArray;
    },
    mounted() {
        emitter.on('close_other_user_edit', (account_user_id) => {
            if(account_user_id !== this.account_user_item.id){
                this.is_account_user_editing = false;
            }
        });
    },
    watch: {},
    computed: {},
    methods: {
        HCOClicked(){
            setTimeout(() => {
                if(this.all_location_list.length == 1 && this.edit_hco_option == 'yes'){
                    this.checkHCOAlreadySelected(this.all_location_list[0]);
                }
                if(this.all_location_list.length > 1 && this.edit_hco_option == 'no'){
                    // this.selected_access_locations = [];
                    this.selected_hco_locations = [];
                }
            }, 500);
        },
        assignHCODropdownAddItem(selectedOption, specificID){
            var found_index = _.findIndex(this.selected_access_locations, (o) => { return o.id === selectedOption.id; });
            if(found_index == -1){
                this.selected_access_locations.push(selectedOption);
            }
            this.checkHCOAlreadySelected(selectedOption, specificID);
        },
        assignHCODropdownRemoveItem(selectedOption, specificID){
            var found_index = _.findIndex(this.selected_access_locations, (o) => { return o.id === selectedOption.id; });
            if(found_index >= 0){
                this.selected_access_locations.splice(found_index, 1);
            }
        },
        editAccountUserDetail(){
            this.account_user_id = this.account_user_item.id;
            this.first_name = this.account_user_item.first_name;
            this.last_name = this.account_user_item.last_name;
            this.email = this.account_user_item.email;
            this.selected_access_locations = [];
            _.forEach(this.account_user_item.account_location_access, (value) => {
                    var is_found_location = _.find(this.all_location_list, (o) => { return o.id === value.location.id; });
                    if(!_.isUndefined(is_found_location)){
                        this.selected_access_locations.push(is_found_location);
                    }
            });
            this.contrinutor_questions_count_arr = [];
            _.forEach(this.account_user_item.account_location_access, (value) => {
                if(value.contrinutor_questions_count > 0) {
                    this.contrinutor_questions_count_arr.push({"location_id": value.location.id});
                }
            });         
            this.edit_hco_option = (this.account_user_item.hipaa_compliance_officer.length > 0)?'yes':'no';
            this.selected_hco_locations = [];
            _.forEach(this.account_user_item.hipaa_compliance_officer, (value) => {
                    this.selected_hco_locations.push(value.location);
            });
            setTimeout(() => {
                this.is_account_user_editing = true;
                emitter.emit('close_other_user_edit', this.account_user_id);
            }, 100);
        },
        editAccountUserSubmit(){
            this.v$.$touch();
            if (!this.v$.$invalid) {
                var location_access_new = new Array();
                var location_access_removed = new Array();
                var remove_questions_location = new Array();
                if(this.all_location_list.length > 1){
                    _.forEach(this.selected_access_locations, (value) => {
                    if(_.isUndefined( _.find(this.account_user_item.account_location_access, (o) => { return o.location.id == value.id; }))){
                        location_access_new.push({"location_id": value.id});
                    }
                    });
                    _.forEach(this.account_user_item.account_location_access, (value) => {
                    if(_.isUndefined( _.find(this.selected_access_locations, (o) => { return o.id == value.location.id; }))){
                        location_access_removed.push({"location_id": value.location.id});
                    }
                    });
                remove_questions_location = this.contrinutor_questions_count_arr.filter(location =>
                                    location_access_removed.some(remove_location =>
                                    remove_location.location_id === location.location_id
                                )
                        );
                }else{
                    if(this.account_user_item.account_location_access.length == 0){
                        location_access_new.push({"location_id": this.all_location_list[0].id});
                    }
                }
                var hco_location_new = new Array();
                var hco_location_removed = new Array();
                if(this.all_location_list.length > 1){
                    _.forEach(this.selected_hco_locations, (value) => {
                    if(_.isUndefined( _.find(this.account_user_item.hipaa_compliance_officer, (o) => { return o.location.id == value.id; }))){
                        hco_location_new.push({"location_id": value.id});
                    }
                    });
                    _.forEach(this.account_user_item.hipaa_compliance_officer, (value) => {
                    if(_.isUndefined( _.find(this.selected_hco_locations, (o) => { return o.id == value.location.id; }))){
                        hco_location_removed.push({"location_id": value.location.id});
                    }
                    });
                }else{
                    if(this.edit_hco_option == 'yes'){
                        if(this.account_user_item.hipaa_compliance_officer.length == 0){
                            hco_location_new.push({"location_id": this.all_location_list[0].id});
                        }
                    }else{
                        if(this.account_user_item.hipaa_compliance_officer.length > 0){
                            hco_location_removed.push({"location_id": this.all_location_list[0].id});
                        }
                    }
                }
                if(remove_questions_location.length > 0) {
                    toastr.error('You cannot remove location as this user has assigned as security risk analysis question. Please approve or reject answer for this contributor before unassign location.', "Error");
                    return false;
                }
                if(hco_location_removed.length > 0){
                    toastr.error('Seems like you are trying to remove an HCO for some location(s). Please assign a new HCO to change/remove the current HCO.', "Error");
                    return false;
                }
                NProgress.start();
                this.disable_accountuser_submit_btn = true;
                axios
                .post(JS_APP_URL + "/accountuser/edit-account-user", {
                    account_user_id: this.account_user_id,
                    first_name: this.first_name,
                    last_name: this.last_name,
                    email: this.email,
                    is_hipaa_compliance_officer: (this.edit_hco_option == 'yes')?1:0,
                    location_access_new: location_access_new,
                    location_access_removed: location_access_removed,
                    hco_location_new: hco_location_new,
                    hco_location_removed: hco_location_removed
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if(response["data"]['data'].length > 0){
                            toastr.error(response["data"]['data'].join('</br>'), "Error");
                        }else{
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        toastr.success(response["data"]["message"], "Success");
                        setTimeout(() => {
                            this.is_account_user_editing = false;
                            this.$emit("updated-account-user", response["data"]['data']);
                            this.$emit("adjust-HCO-list", hco_location_new, 'AU', this.account_user_id);
                        }, 100);
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.disable_accountuser_submit_btn = false;
                });
            }
        },
        deleteAccountUserToggle(status = true){
            this.deleteaccountusermodal_account_user_id = this.account_user_item.id;
            this.is_deleteaccountusermodal_shown = status;
            setTimeout(() => {
                emitter.emit('close_other_user_edit', this.account_user_item.id);
            }, 100);
        },
        deleteAccountUserSubmit(){
            if(this.deleteaccountusermodal_account_user_id){
                NProgress.start();
                axios
                .post(JS_APP_URL + "/accountuser/delete-account-user", {
                    account_user_id: this.deleteaccountusermodal_account_user_id
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if(response["data"]['data'].length > 0){
                            toastr.error(response["data"]['data'].join('</br>'), "Error");
                        }else{
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        toastr.success(response["data"]["message"], "Success");
                        setTimeout(() => {
                            this.$emit("deleted-account-user", this.deleteaccountusermodal_account_user_id);
                        }, 100);
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.is_deleteaccountusermodal_shown = false;
                });
            }
        },
        removeLocationAccess(value){
            if(_.isArray(value)){
                _.forEach(value, (each_loc) => {
                    var found_index = _.findIndex(this.selected_hco_locations, (o) => { return o.id === each_loc.id; });
                    if(found_index >= 0){
                        this.selected_hco_locations.splice(found_index, 1);
                    }
                });
            }else{
                var found_index = _.findIndex(this.selected_hco_locations, (o) => { return o.id === value.id; });
                if(found_index >= 0){
                    this.selected_hco_locations.splice(found_index, 1);
                }
            }
        },
        checkHCOAlreadySelected(selectedOption, id){
            NProgress.start();
            this.disable_accountuser_submit_btn = true;
            axios
            .get(JS_APP_URL + "/accountuser/check-hco-already-assigned/" + selectedOption.id + "/" + this.account_user_item.id + "/account_user")
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    this.is_alreadyhcoavailablemodal_shown = true;
                    this.hco_available_location_id = selectedOption.id;
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                NProgress.done();
                this.disable_accountuser_submit_btn = false;
            });
        },
        clsoeHCOAvailableToggle(){
            this.is_alreadyhcoavailablemodal_shown = false;
            this.hco_available_location_id = "";
            if(this.all_location_list.length > 1){
                this.$refs.select_hco.activate();
            }
        },
        notReplaceHCO(){
            if(this.all_location_list.length == 1){
                    this.edit_hco_option = 'no';
            }else{
                var found_index = _.findIndex(this.selected_hco_locations, (o) => { return o.id === this.hco_available_location_id; });
                if(found_index >= 0){
                    this.selected_hco_locations.splice(found_index, 1);
                }
                var found_index_AL = _.findIndex(this.selected_access_locations, (o) => { return o.id === this.hco_available_location_id; });
                if(found_index_AL >= 0){
                    this.selected_access_locations.splice(found_index_AL, 1);
                }
            }
            setTimeout(() => {
                this.clsoeHCOAvailableToggle();
            }, 100);
        },
        cancelEditAccountUser(){
            this.is_account_user_editing = false;
        }
    },
    created() {
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.is_account_user_editing = false;
            }
        });
    }
};
</script>
