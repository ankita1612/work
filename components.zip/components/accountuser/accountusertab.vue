<template>
<div class="training-tab-content pt40">
    <div class="container">
        <primary-compliance-officer :primary_user="primary_user" :all_location_list="all_location_list" @load-all-user-list="loadAllUserList" @updated-primary-user="updatedPrimaryUser" @adjust-HCO-list="adjustHCOList"></primary-compliance-officer>

        <filter-account-user-list :key="filter_component_key" @open-import-modal="openCloseImportModal" :sample_import_file_link="sample_import_file_link" :is_refresh_btn_shown="is_refresh_btn_shown" @apply-filter="applyFilter" :all_location_list="all_location_list" @add-account-user-form-toggle="addAccountUserFormToggle" :is_add_accountuser_shown="is_add_accountuser_shown" @reset-all-filter="resetAllFilter" @load-all-user-list="loadAllUserList"></filter-account-user-list>

        <transition name="simple-fade-transition">
            <add-account-user v-if="is_add_accountuser_shown" @add-account-user-form-toggle="addAccountUserFormToggle" :all_location_list="all_location_list" @load-all-user-list="loadAllUserList" @reset-all-filter="resetAllFilter"></add-account-user>
        </transition>

        <account-user-item v-for="(au_item, index) in account_user_list" v-bind:key="index" :account_user_item="au_item" :all_location_list="all_location_list" @load-all-user-list="loadAllUserList" @updated-account-user="updatedAccountUser" @adjust-HCO-list="adjustHCOList" @deleted-account-user="deletedAccountUser"></account-user-item>
        <div v-if="!is_full_page_loader_shown && account_user_list.length === 0" class="">
            <div class="user-detail-text font-14 gray_checkmark--text text-center">
                <no-data-icon></no-data-icon>
                <div class="font-14 text-center blueog--text">No account user(s) available.</div>
            </div>
        </div>
        <InfiniteLoading @infinite="loadAllUserList(false)" />
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
    <import-error-modal 
          v-if="is_import_error_modal"
          :import_errors="import_errors_data"
          @close-model="openCloseImportModal"
        />
</div>
</template>

<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import primaryComplianceOfficer from "./primaryComplianceOfficer.vue";
import filterAccountUserList from "./filterAccountUserList.vue";
import addAccountUser from "./addAccountUser.vue";
import accountUserItem from './accountUserItem.vue';
import fullPageLoader from '../common/fullPageLoader.vue';
import noDataIcon from '../common/icons/noDataIcon.vue';
import importErrorModal from "../common/includes/importErrorModal.vue";
import _ from "lodash";

export default {
    data() {
        return {
            filter_by_access_level: '',
            filter_by_location: [],
            search_query: "",
            primary_user: {},
            sample_import_file_link: "",
            account_user_list: [],
            is_add_accountuser_shown: false,
            all_location_list: [],
            is_list_loading: false,
            per_page_records: 10,
            current_page: 1,
            total_page: 1,
            filter_component_key: Math.random(),
            is_full_page_loader_shown: false,
            is_refresh_btn_shown: false,
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            is_import_error_modal: false,
            import_errors_data: [],
            sort_by: '',
            sort_by_dir: '',
            call_ajax: 1,
        };
    },
    components: {
        primaryComplianceOfficer: primaryComplianceOfficer,
        filterAccountUserList: filterAccountUserList,
        addAccountUser: addAccountUser,
        accountUserItem: accountUserItem,
        fullPageLoader: fullPageLoader,
        noDataIcon: noDataIcon,
        importErrorModal: importErrorModal,
    },
    props: {},
    watch: {},
    mounted() {
        this.loadLocationList();
    },
    methods: {
        addAccountUserFormToggle(status = true){
            this.is_add_accountuser_shown = status;
        },
        loadLocationList(){
            this.is_full_page_loader_shown = true;
            axios
            .get(JS_APP_URL + "/general/get-all-location-list")
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    this.all_location_list = response["data"]["data"];
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";    
                }
            })
            .then(() => {
                this.is_full_page_loader_shown = false;
            });
        },
        loadAllUserList(need_pagination_reset = false){
            if(need_pagination_reset){
                this.current_page = 1;
                this.total_page = 1;
                this.account_user_list = [];
            }
            if (this.current_page <= this.total_page && this.call_ajax == 1) {	
                this.call_ajax = 0;
                this.is_list_loading = true;	
                this.is_full_page_loader_shown = true;
                axios
                .post(JS_APP_URL + "/accountuser/get-all-user-list", {
                    filter_by_access_level: this.filter_by_access_level,
                    filter_by_location: _.map(this.filter_by_location, 'id'),
                    search_query: this.search_query,
                    sort_by: this.sort_by,
                    sort_by_dir: this.sort_by_dir,
                    search_query: this.search_query,
                    per_page: this.per_page_records,
                    page: this.current_page
                })
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        this.primary_user = response["data"]["data"]['primary_user'];
                        this.sample_import_file_link = response["data"]["data"]['sample_import_doc'];
                        var account_user_data = response["data"]["data"]['account_user_list'];

                        this.account_user_list.push(...account_user_data.data);
                        this.total_page = account_user_data.last_page;
                        if(this.account_user_list.length == 0 && this.search_query == '' && this.filter_by_location.length  == 0 && this.filter_by_access_level == ''){
                            this.is_add_accountuser_shown = true;
                        }
                        this.current_page = this.current_page + 1;
                        this.is_list_loading = false;
                        this.is_refresh_btn_shown = false;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";    
                    }
                })
                .then(() => {				
                    setTimeout(() => {
                        this.is_full_page_loader_shown = false;
                        this.call_ajax = 1;
                    }, 100);
                });
            }
        },
        applyFilter(search_params = {}){
            this.filter_by_access_level = search_params.filter_by_access_level;
            this.filter_by_location = search_params.filter_by_location;
            this.search_query = search_params.search_query;
            this.sort_by = search_params.sort_by;
            this.sort_by_dir = search_params.sort_by_dir;
            setTimeout(() => {
                this.loadAllUserList(true);
            }, 100);
        },
        resetAllFilter(){
            this.filter_by_access_level = '';
            this.filter_by_location = [];
            this.search_query = "";
            this.sort_by = '';
            this.sort_by_dir = '';
            this.filter_component_key = Math.random();
        },
        showRefreshListButton(){
            if(this.filter_by_access_level != "" || this.filter_by_location.length > 0 || this.search_query != ""){
                this.is_refresh_btn_shown = true;
            }
        },
        deletedAccountUser(account_user_id = ''){
            if(account_user_id){
                var found_index = _.findIndex(this.account_user_list, (o) => { return o.id === account_user_id; });
                if(found_index >= 0){
                    this.account_user_list.splice(found_index, 1);
                    if(this.account_user_list.length == 0){
                        this.showRefreshListButton();
                    }
                }
            }
        },
        updatedPrimaryUser(primary_user_updated = {}){
            if(!_.isEmpty(primary_user_updated)){
                this.primary_user = primary_user_updated;
            }
        },
        updatedAccountUser(account_user_updated = {}){
            if(!_.isEmpty(account_user_updated)){
                var found_index = _.findIndex(this.account_user_list, (o) => { return o.id === account_user_updated.id; });
                if(found_index >= 0){
                    this.account_user_list[found_index] = account_user_updated;
                    this.showRefreshListButton();
                }
            }
        },
        openCloseImportModal(import_errors) {
            if(!this.is_import_error_modal) {
                this.is_import_error_modal = true
                this.import_errors_data = import_errors;
            } else {
                this.is_import_error_modal = false
            }
        },
        adjustHCOList(new_hco_list, call_from, call_from_id){
            if(new_hco_list.length > 0){
                _.forEach(new_hco_list, (each_new_hco) => {
                    // check and remove from PCO
                    if(call_from != 'PCO' && this.primary_user.hipaa_compliance_officer.length > 0){
                        var found_index_pco = _.findIndex(this.primary_user.hipaa_compliance_officer, (o) => { return o.location_id === each_new_hco.location_id; });
                        if(found_index_pco >= 0){
                            this.primary_user.hipaa_compliance_officer.splice(found_index_pco, 1);
                        }
                    }
                    // check and remove from AU list
                    _.forEach(this.account_user_list, (each_account_user, each_account_user_KEY) => {
                        if(call_from_id != each_account_user.id && each_account_user.hipaa_compliance_officer.length > 0){
                            var found_index_au = _.findIndex(each_account_user.hipaa_compliance_officer, (o) => { return o.location_id === each_new_hco.location_id; });
                            if(found_index_au >= 0){
                                this.account_user_list[each_account_user_KEY].hipaa_compliance_officer.splice(found_index_au, 1);
                            }
                        }
                    });
                });
            }
        },
    },
    created() {},
};
</script>
