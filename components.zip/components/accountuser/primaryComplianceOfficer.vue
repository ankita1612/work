<template>
    <div>
        <div class="flex items-center mb20">
            <h6 class="font-18 blueog--text mb0 mr6 font-400">
                Primary Compliance Officer
            </h6>
            <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                <div class="cursor-pointer svg-icon-height">
                    <info-icon></info-icon>
                </div>
                <template #popper>
                    The PCO has access to all locations' information and account billing.
                </template>
            </VTooltip>
        </div>
        <transition name="simple-fade-transition" mode="out-in">
        <div v-if="!is_primary_user_editing" key="saved" class="user-detail-card py6 px15 light mb60">
            <div class="row flex-auto -mx-10 items-center">
                <div class="col-12 col-md-5 col-lg-2 col-xl-2 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text" v-text="primary_user.first_name"></div>
                </div>
                <div class="col-12 col-md-7 col-lg-2 col-xl-2 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text" v-text="primary_user.last_name"></div>
                </div>
                <div class="col-12 col-md-5 col-lg-3 col-xl-3 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text" v-text="primary_user.email"></div>
                </div>
                <div class="col-12 col-md-5 col-lg-2 col-xl-2 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text" v-text="primary_user.phone_number"></div>
                </div>
                <div class="col-2 col-sm-1 col-md-1 col-lg-2 col-xl-2 px10 text-right">
                    <button type="button" class="user-location-icon user-hco-btn mt2" v-if="primary_user.hipaa_compliance_officer && Object.keys(primary_user.hipaa_compliance_officer).length > 0">
                        <VTooltip  :triggers="['hover']"  :popperTriggers="['hover']">
                            <img :src="JS_APP_URL +'/images/hco-badge1.svg'" alt="" title="" class="cursor-pointer user-hco-icon">
                            <template #popper>
                                <div v-if="all_location_list.length == 1" class="white--text font-12 font_semibold mb2 text-center">HCO LOCATION</div>
                                <div v-if="all_location_list.length > 1" class="white--text font-12 font_semibold mb2 text-center pb5 pt5">HCO LOCATION(S)</div>
                                <div v-for="(each_location, each_location_index) in primary_user.hipaa_compliance_officer" v-bind:key="each_location_index" v-text="each_location.location.location_nickname" class="text-center seperator-line pt3 pb3"></div>
                            </template>
                        </VTooltip>
                    </button>
                </div>
                <div class="col-10 col-md-4 col-lg-2 col-xl-1 px10">
                    <div class="flex flex-wrap items-center justify-end justify-start-small-medium user-detail-action">

                        <div class="action-sept mr30"></div>
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                            <button v-on:click="(AUTH_USER.user_type == 'PCO')?editPrimaryUserDetail():null" type="button" class="action-icon-btn action-btn-blueog cursor-pointer" :disabled="AUTH_USER.user_type != 'PCO'">
                                <img :src="JS_APP_URL +'/images/pencil.svg'" alt="" title="">
                            </button>
                            <template #popper>
                                Edit
                            </template>
                        </VTooltip>
                    </div>
                </div>
            </div>
        </div>
        <div v-else key="editing" class="user-detail-card pt18 pb22 px15 light mb60 user-edit-card">
            <form @submit.prevent="primarycomplianceOfficerSubmit">
                <div class="row flex-auto -mx-10 items-start">
                        <div class="col-12 col-md-12 col-lg-9 col-xl-9 px10">
                                <div class="row flex-auto -mx-10">
                                    <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                        <div class="form-group" :class="{ 'form-group--error': v$.first_name.$errors.length }">
                                            <input class="form-input location-input-box" :class="{ 'form-error': v$.first_name.$errors.length }" type="text" name="first_name" v-model.trim="v$.first_name.$model">
                                            <label class="label location-input-label" :class="{ 'label-float': v$.first_name.$model }">First Name</label>
                                            <div v-if="v$.first_name.$errors.length > 0">
                                                <div class="form-error-text">
                                                    {{ v$.first_name.$errors[0].$message }}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                        <div class="form-group" :class="{ 'form-group--error': v$.last_name.$errors.length }">
                                            <input class="form-input location-input-box" :class="{ 'form-error': v$.last_name.$errors.length }" type="text" name="last_name" v-model.trim="v$.last_name.$model">
                                            <label class="label location-input-label" :class="{ 'label-float': v$.last_name.$model }">Last Name</label>
                                            <div v-if="v$.last_name.$errors.length > 0">
                                                <div class="form-error-text">
                                                    {{ v$.last_name.$errors[0].$message }}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                        <div class="form-group" :class="{ 'form-group--error': v$.email.$errors.length }">
                                            <input class="form-input location-input-box" :class="{ 'form-error': v$.email.$errors.length }" type="text" name="email" v-model.trim="v$.email.$model">
                                            <label class="label location-input-label" :class="{ 'label-float': v$.email.$model }">Email</label>
                                            <div v-if="v$.email.$errors.length > 0">
                                                <div class="form-error-text">
                                                    {{ v$.email.$errors[0].$message }}
                                                </div>
                                            </div>
                                        </div>
                                    </div>                                    
                                    <div class="col-12 px10  flex flex-wrap user-edit-column-height">
                                        <div class="row flex-auto -mx-10">
                                        <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10 mb-sm-10">
                                            <div class="form-group mb-0" :class="{ 'form-group--error': v$.phone_number.$errors.length }">
                                                <input v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent class="form-input location-input-box" :class="{ 'form-error': v$.phone_number.$errors.length }" type="text" name="phone_number" v-model.trim="v$.phone_number.$model">
                                                <label class="label location-input-label" :class="{ 'label-float': v$.phone_number.$model }">Company Phone Number</label>
                                                <div v-if="v$.phone_number.$errors.length > 0">
                                                    <div class="form-error-text">
                                                        {{ v$.phone_number.$errors[0].$message }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex flex-wrap items-center mb-md-10 self-center mr20 ml12">
                                            <div class="font-14 font-light gray_checkmark--text mr12 inline-flex items-center">
                                                HIPAA Compliance Officer:
                                                <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" style="height: 27px;" class="cursor-pointer"><info-icon class="cursor-pointer ml2"></info-icon>
                                                <template #popper>
                                                    The individual responsible for the planning, development, coordination and evaluation of the organization's HIPAA Compliance and health management activities.
                                                </template>                
                                                </VTooltip>
                                            </div>
                                            <div class="flex items-center" :class="{ 'form-group--error': v$.os_hco_option.$errors.length }">
                                                <div class="radio mr16">
                                                    <input @click="HCOClickedPCO" v-model.trim="v$.os_hco_option.$model" id="os_hco_option_yes" name="os_hco_option" type="radio" value="yes">
                                                    <label for="os_hco_option_yes" class="radio-label font-14 font-light gray_checkmark--text">Yes</label>
                                                </div>
                                                <div class="radio">
                                                    <input  @click="HCOClickedPCO" v-model.trim="v$.os_hco_option.$model" id="os_hco_option_no" name="os_hco_option" type="radio" value="no">
                                                    <label for="os_hco_option_no" class="radio-label font-14 font-light gray_checkmark--text">No</label>
                                                </div>
                                                <div v-if="v$.os_hco_option.$errors.length > 0">
                                                    <div class="form-error-text">
                                                        {{ v$.os_hco_option.$errors[0].$message }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div v-if="os_hco_option == 'yes' && hco_location_list.length > 1" class="col-12 col-md-6 col-lg-4 col-xl-3 px0 mt-md-10">
                                                <div class="form-group mb-0" :class="{ 'form-group--error': v$.selected_hco_locations.$errors.length }">
                                                <multiselect
                                                ref="select_hco"
                                                v-model="v$.selected_hco_locations.$model"
                                                tag-placeholder=""
                                                placeholder=""
                                                label="location_nickname"
                                                track-by="id"
                                                :options="hco_location_list"
                                                :multiple="true"
                                                :close-on-select="false"
                                                @select="checkHCOAlreadySelected"
                                                :showLabels="false"
                                                :taggable="false">
                                                    <template #noResult>
                                                        <div class="multiselect__noResult text-center">No results found</div>
                                                    </template>
                                                    <template #selection>
                                                        <div class="multiselect__tags-wrap" v-if="selected_hco_locations.length > 1">
                                                            <span class="multiselect__tag">
                                                                <span>{{ selected_hco_locations.length }} Locations Selected</span>
                                                            </span>
                                                        </div>
                                                    </template>
                                                </multiselect>
                                                <label class="label label-select" :class="{ 'label-float': (selected_hco_locations.length > 0) }">Assigned HCO Location(s)</label>
                                                <div v-if="v$.selected_hco_locations.$errors.length > 0">
                                                    <div class="form-error-text">
                                                        {{ v$.selected_hco_locations.$errors[0].$message }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>    
                                    </div>
                                </div>
                        </div>
                        <div class="col-12 col-md-12 col-lg-3 col-xl-3 pl10 pr0 mt-sm-20">
                            <div class="flex items-center flex-wrap submit-cancel-buttons">
                                <button :disabled="disable_primaryuser_submit_btn" type="submit" class="btn-primary mlr-auto">
                                    <span>Submit</span>
                                </button>
                                <button  @click="cancelEditPrimaryUserDetail" :disabled="disable_primaryuser_submit_btn" type="button" class="btn-cancel-outline btn-cancel-form mlr-auto">
                                    <span>Cancel</span>
                                </button>
                            </div>
                        </div>
                </div>
            </form>
        </div>
        </transition>
        <already-hco-available-modal
        v-if="is_alreadyhcoavailablemodal_shown"
        @close-model="clsoeHCOAvailableToggle"
        @not-replace-hco="notReplaceHCO"
        ></already-hco-available-modal>
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from 'lodash';
import useVuelidate from "@vuelidate/core";
import { required, requiredIf, email, maxLength, minLength, helpers } from "@vuelidate/validators";
import infoIcon from "../common/icons/infoIcon.vue"
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
import alreadyHcoAvailableModal from './alreadyHcoAvailableModal.vue';
import {checkSpecialChars, checkSpecialCharsErrorMessage}  from "../common/customValidation";

export default {
  data() {
    return {
      user_id: '',
      first_name: '',
      last_name: '',
      email: '',
      phone_number: '',
      os_hco_option: '',
      selected_hco_locations: [],
      hco_location_list: [],
      is_primary_user_editing: false,
      disable_primaryuser_submit_btn: false,
      is_alreadyhcoavailablemodal_shown: false,
      hco_available_location_id: "",
      check_hco_available_timer: null,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      AUTH_USER: AUTH_USER,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage
    };
  },
  components: {
      infoIcon,
      clearDropdownIcon,
      alreadyHcoAvailableModal
  },

  props: {
      primary_user:{
        type: Object,
        default: () => {}
      },
      all_location_list:{
        type: Array,
        default: () => []
      },
  },
  emits: ["updated-primary-user", "adjust-HCO-list"],
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
        first_name: {
            required: helpers.withMessage("Please enter a first name", required),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
        },
        last_name: {
            required: helpers.withMessage("Please enter a last name", required),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            maxLength: helpers.withMessage("ax 40 characters allowed", maxLength(40)),
        },
        email: {
            email: helpers.withMessage("Please enter a valid email", email),
            required: helpers.withMessage("Please enter an email", required),
            maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
            isUnique: helpers.withMessage("Email address already in use", helpers.withAsync(async (value) => {
                if (!value) return true;
                if (this.v$.email.required.$invalid || this.v$.email.email.$invalid) return true;
                this.disable_primaryuser_submit_btn = true;
                let check_promise = new Promise((resolve, reject) => {
                    if (this.check_hco_available_timer) {
                        clearTimeout(this.check_hco_available_timer);
                        this.check_hco_available_timer = null;
                    }
                    this.check_hco_available_timer = setTimeout(() => {
                        return fetch(JS_APP_URL + `/accountuser/check-unique-email-accountuser-primary-user/${value}/primary_user/${this.user_id}`)
                        .then(
                            (response) => {
                                if (response.ok) {
                                    resolve(response.text());
                                } else {
                                    resolve(new Error("error"));
                                }
                            },
                            (error) => {
                                resolve(new Error("error"));
                            }
                        );
                    }, 500);
                });
                var response = await check_promise;
                this.disable_primaryuser_submit_btn = false;
                return Boolean(response == "available" ? false : true);
            })),
        },
        phone_number: {
            required: helpers.withMessage('Please enter a company phone number', required),
            minLength: helpers.withMessage('Please enter a valid company phone number', minLength(12)),
            maxLength: helpers.withMessage('Please enter a valid company phone number', maxLength(12)),
        },
        os_hco_option: {
            required: helpers.withMessage("Please select a HIPAA Compliance officer", required),
        },
        selected_hco_locations: {
            required: helpers.withMessage("Please select HCO location(s)", requiredIf(() => {
                return (this.os_hco_option == 'yes' && this.hco_location_list.length > 1)
            }))
        }
    };
    return validationArray;
  },
  mounted() {},
  watch: {},
  methods: {
      HCOClickedPCO(){
        setTimeout(() => {
            if(this.hco_location_list.length == 1 && this.os_hco_option == 'yes'){
                this.checkHCOAlreadySelected(this.hco_location_list[0]);
            }   
            if(this.hco_location_list.length > 1 && this.os_hco_option == 'no'){
                this.selected_hco_locations = [];
            }   
        }, 500);
      },
      editPrimaryUserDetail(){
          this.user_id = this.primary_user.id;
          this.first_name = this.primary_user.first_name;
          this.last_name = this.primary_user.last_name;
          this.email = this.primary_user.email;
          this.phone_number = this.primary_user.phone_number;
          this.hco_location_list = this.all_location_list;
          this.selected_hco_locations = [];
          _.forEach(this.primary_user.hipaa_compliance_officer, (value) => {
                this.selected_hco_locations.push(value.location);
          });
          this.os_hco_option = (this.primary_user.hipaa_compliance_officer.length > 0)?'yes':'no';
          setTimeout(() => {
              this.is_primary_user_editing = true;
          }, 100);
      },
      primarycomplianceOfficerSubmit(){
        this.v$.$touch();
        if (!this.v$.$invalid) {
            var hco_location_new = new Array();
            var hco_location_removed = new Array();
            if(this.hco_location_list.length > 1){
                _.forEach(this.selected_hco_locations, (value) => {
                if(_.isUndefined( _.find(this.primary_user.hipaa_compliance_officer, (o) => { return o.location.id == value.id; }))){
                    hco_location_new.push({"location_id": value.id});
                }
                });
                _.forEach(this.primary_user.hipaa_compliance_officer, (value) => {
                if(_.isUndefined( _.find(this.selected_hco_locations, (o) => { return o.id == value.location.id; }))){
                    hco_location_removed.push({"location_id": value.location.id});
                }
                });
            }else{
                if(this.os_hco_option == 'yes'){
                    if(this.primary_user.hipaa_compliance_officer.length == 0){
                        hco_location_new.push({"location_id": this.hco_location_list[0].id});
                    }
                }else{
                    if(this.primary_user.hipaa_compliance_officer.length > 0){
                        hco_location_removed.push({"location_id": this.hco_location_list[0].id});
                    }
                }
            }
            if(hco_location_removed.length > 0){
                toastr.error('Seems like you are trying to remove an HCO for some location(s). Please assign a new HCO to change/remove the current HCO.', "Error");
                return false;
            }
            NProgress.start();
            this.disable_primaryuser_submit_btn = true;
            axios
            .post(JS_APP_URL + "/accountuser/edit-primary-user", {
                user_id: this.user_id,
                first_name: this.first_name,
                last_name: this.last_name,
                email: this.email,
                phone_number: this.phone_number,
                is_hipaa_compliance_officer: (this.os_hco_option == 'yes')?1:0,
                hco_location_new: hco_location_new,
                hco_location_removed: hco_location_removed
            })
            .then((response) => {
                if (response["data"]["status"] == "Error") {
                    if(response["data"]['data'].length > 0){
                        toastr.error(response["data"]['data'].join('</br>'), "Error");
                    }else{
                        toastr.error(response["data"]["message"], "Error");
                    }
                } else {
                    toastr.success(response["data"]["message"], "Success");
                    setTimeout(() => {
                        this.is_primary_user_editing = false;
                        document.getElementById("login_full_name").innerHTML = response["data"]['data']['first_name'] + " " + response["data"]['data']['last_name'];
                        this.$emit("updated-primary-user", response["data"]['data']);
                        this.$emit("adjust-HCO-list", hco_location_new, 'PCO', this.primary_user.id);
                    }, 100);
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                NProgress.done();
                this.disable_primaryuser_submit_btn = false;
            });
        }
      },
      checkHCOAlreadySelected(selectedOption, id){
        NProgress.start();
        this.disable_primaryuser_submit_btn = true;
        axios
        .get(JS_APP_URL + "/accountuser/check-hco-already-assigned/" + selectedOption.id + "/" + this.primary_user.id + "/user")
        .then((response) => {
            if (response["data"]["status"] == "Success") {
                this.is_alreadyhcoavailablemodal_shown = true;
                this.hco_available_location_id = selectedOption.id;
            }
        })
        .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
            }
        })
        .then(() => {
            NProgress.done();
            this.disable_primaryuser_submit_btn = false;
        });
      },
      clsoeHCOAvailableToggle(){
          this.is_alreadyhcoavailablemodal_shown = false;
          this.hco_available_location_id = "";
          if(this.hco_location_list.length > 1){
            this.$refs.select_hco.activate();
          }
      },
      notReplaceHCO(){
        if(this.hco_location_list.length == 1){
            this.os_hco_option = 'no';
        }else{
            var found_index = _.findIndex(this.selected_hco_locations, (o) => { return o.id === this.hco_available_location_id; });
            if(found_index >= 0){
              this.selected_hco_locations.splice(found_index, 1);
            }
        }
        setTimeout(() => {
            this.clsoeHCOAvailableToggle();
        }, 100);
      },
      cancelEditPrimaryUserDetail(){
        this.is_primary_user_editing = false;
      }
  },
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.is_primary_user_editing = false;
      }
    });
  }
};
</script>
