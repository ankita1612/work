<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container">
            <button v-on:click="notReplaceHCO" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb30 pt20">
              <img :src="JS_APP_URL + '/images/warning.svg'" alt="" title="" class="warning-icon-modal" />
            </div>
            <h2
              class="
                font-24 font_semibold blueog--text line-normal text-center mb20
              "
            >
              Are you sure?
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">This location already has an HCO assigned. Do you want to replace it?</p>
            <div class="flex flex-wrap items-center justify-center pb40">
                <button v-on:click="notReplaceHCO" class="btn-cancel-outline mx10 btn-width-120">No</button>
                <button v-on:click="closeModal" class="btn-primary mx10 px30 mt-xs-20 btn-width-120">YES</button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from '../common/icons/closeIcon.vue';

export default {
  props: {
  },
  emits: ["close-model", "not-replace-hco"],
  components:{closeIcon},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
    };
  },
  methods: {
    closeModal() {
      this.$emit("close-model");
    },
    notReplaceHCO() {
      this.$emit("not-replace-hco");
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("not-replace-hco");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
