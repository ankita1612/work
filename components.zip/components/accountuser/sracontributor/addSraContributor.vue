<template>
    <div>
        <form>
        <input type="hidden" id="gclid_field" name="gclid_field" value=""> 
        <div class="user-detail-card light px8 pt20">   
            <div class="add-user-form mb50 sra-contributor-add-form">
                <div class="account-user-add-row row items-start -mx-10">
                    <div class="col-12 px10">
                        <div class="row flex-auto -mx-10">
                            <div class="col-12 col-md-4 col-lg-3 col-xl-3 px10 mb22">
                                <div class="form-group mb-0" :class="{ 'form-group--error': v$.first_name.$errors.length }">
                                    <input class="form-input location-input-box" :class="{ 'form-error': v$.first_name.$errors.length }" type="text" name="first_name" v-model.trim="v$.first_name.$model">
                                    <label class="label location-input-label" :class="{ 'label-float': v$.first_name.$model }">First Name</label>
                                    <div v-if="v$.first_name.$errors.length > 0">
                                        <div class="form-error-text">
                                            {{ v$.first_name.$errors[0].$message }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-lg-3 col-xl-3 px10 mb22">
                                <div class="form-group mb-0" :class="{ 'form-group--error': v$.last_name.$errors.length }">
                                    <input class="form-input location-input-box" :class="{ 'form-error': v$.last_name.$errors.length }" type="text" name="last_name" v-model.trim="v$.last_name.$model">
                                    <label class="label location-input-label" :class="{ 'label-float': v$.last_name.$model }">Last Name</label>
                                    <div v-if="v$.last_name.$errors.length > 0">
                                        <div class="form-error-text">
                                            {{ v$.last_name.$errors[0].$message }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-lg-3 col-xl-3 px10 mb22">
                                <div class="form-group mb-0" :class="{ 'form-group--error': v$.company_name.$errors.length }">
                                    <input class="form-input location-input-box" :class="{ 'form-error': v$.company_name.$errors.length }" type="text" name="company_name" v-model.trim="v$.company_name.$model">
                                    <label class="label location-input-label" :class="{ 'label-float': v$.company_name.$model }">Company Name</label>
                                    <div v-if="v$.company_name.$errors.length > 0">
                                        <div class="form-error-text">
                                            {{ v$.company_name.$errors[0].$message }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-lg-3 col-xl-3 px10 mb22">
                                <div class="form-group mb-0" :class="{ 'form-group--error': v$.email.$errors.length }">
                                    <input class="form-input location-input-box" :class="{ 'form-error': v$.email.$errors.length }" type="text" name="email" v-model.trim="v$.email.$model">
                                    <label class="label location-input-label" :class="{ 'label-float': v$.email.$model }">Email</label>
                                    <div v-if="v$.email.$errors.length > 0">
                                        <div class="form-error-text">
                                            {{ v$.email.$errors[0].$message }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-3 col-lg-3 col-xl-3 px10  mb-sm-10">
                                <div v-if="all_location_list.length > 1" class="form-group mb-0" :class="{ 'form-group--error': v$.selected_access_locations.$errors.length }">
                                    <multiselect
                                    class="select-all-dropdown"
                                    v-model="v$.selected_access_locations.$model"
                                    tag-placeholder=""
                                    placeholder=""
                                    label="location_nickname"
                                    track-by="id"
                                    :options="local_all_location_list"
                                    group-values="group_option_list" 
                                    group-label="select_all" 
                                    :group-select="true"
                                    :multiple="true"
                                    :close-on-select="false"
                                    @remove="removeLocationAccess"
                                    :showLabels="false"
                                    :taggable="false">
                                        <template #noResult>
                                            <div class="multiselect__noResult text-center">No results found</div>
                                        </template>
                                        <template #selection>
                                            <div class="multiselect__tags-wrap" v-if="selected_access_locations.length > 1">
                                                <span class="multiselect__tag">
                                                    <span>{{ selected_access_locations.length }} Locations Selected</span>
                                                </span>
                                            </div>
                                        </template>
                                    </multiselect>
                                    <label class="label label-select" :class="{ 'label-float': (selected_access_locations.length > 0) }">Assigned Location(s)</label>
                                    <div v-if="v$.selected_access_locations.$errors.length > 0">
                                        <div class="form-error-text">
                                            {{ v$.selected_access_locations.$errors[0].$message }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-12 px10 mt-sm-20">
                        <div class="flex items-center flex-wrap submit-cancel-buttons mb14 justify-center">
                            <button
                                type="button"
                                class="btn-cancel-outline btn-cancel-form mx4"
                                :disabled="disable_addcontributor_submit_btn"
                                @click="cancelAddSraContributor"
                            >
                                <span>Cancel</span>
                            </button>
                            <button
                                type="button"
                                @click.once="AddSraContributorSubmit"
                                class="btn-primary mx4"
                                :disabled="disable_addcontributor_submit_btn"
                                id="btn-add-account-user"
                                :key="submit_button_key"
                            >
                                <span>Submit</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </form>
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
import infoIcon from "../../common/icons/infoIcon.vue"
toastr.options.preventDuplicates = true;
import useVuelidate from "@vuelidate/core";
import { required, requiredIf, email, maxLength, helpers } from "@vuelidate/validators";
import clearDropdownIcon from '../../common/icons/clearDropdownIcon.vue';
import _ from "lodash";
import {checkSpecialChars, checkSpecialCharsErrorMessage}  from "../../common/customValidation";

export default {
    data() {
        return {
        first_name: '',
        last_name: '',
        company_name: '',
        email: '',
        local_all_location_list : [{
            'select_all': 'Select All',
            'group_option_list': this.all_location_list,
        }],
        selected_access_locations: [],
        selected_hco_locations: [],
        add_hco_option: '',
        disable_addcontributor_submit_btn: false,
        is_alreadyhcoavailablemodal_shown: false,
        hco_available_location_id: "",
        check_hco_available_timer: null,
        JS_APP_URL: JS_APP_URL,
        JS_WORDPRESS_URL: JS_WORDPRESS_URL,
        checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
        APP_ENV: APP_ENV,
        submit_button_key: 1,
        };
    },
    setup: () => ({ v$: useVuelidate() }),
    validations() {
        var validationArray = {
        first_name:{
            required: helpers.withMessage("Please enter a first name", required),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
        },
        last_name:{
            required: helpers.withMessage("Please enter a last name", required),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
        },
        company_name:{
            required: helpers.withMessage("Please enter a company name", required),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
        },
        email:{
            email: helpers.withMessage("Please enter a valid email", email),
            required: helpers.withMessage("Please enter an email", required),
            maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
            isUnique: helpers.withMessage( "Email address already in use", helpers.withAsync(async (value) => {
                if (!value) return true;
                if (!this.v$.email.required || !this.v$.email.email) return true;
                this.disable_addcontributor_submit_btn = true;
                let check_promise = new Promise((resolve, reject) => {
                    if (this.check_hco_available_timer) {
                        clearTimeout(this.check_hco_available_timer);
                        this.check_hco_available_timer = null;
                    }
                    this.check_hco_available_timer = setTimeout(() => {
                        return fetch(JS_APP_URL + `/sra-contributor/check-unique-email-risk-analysis-contributor/${value}`)
                        .then(
                            (response) => {
                                if (response.ok) {
                                    resolve(response.text());
                                } else {
                                    resolve(new Error("error"));
                                }
                            },
                            (error) => {
                                resolve(new Error("error"));
                            }
                        );
                    }, 500);
                });
                let response = await check_promise;
                this.disable_addcontributor_submit_btn = false;
                return Boolean(response == "available" ? false : true);
            })),
        },
        selected_access_locations:{
            required: helpers.withMessage("Please select location(s)", requiredIf(() => {
                return (this.all_location_list.length > 1)
            }))
        },
        };
        return validationArray;
    },
    components: {clearDropdownIcon,infoIcon},
    props: {
        all_location_list:{
            type: Array,
            default: () => []
        },
    },
    emits: ["add-sra-contributor-form-toggle", "reset-all-filter", "load-all-sracontributor-list"],
    mounted() {},
    computed: {},
    methods: {
        removeLocationAccess(value, id){
            if(_.isArray(value)){
                _.forEach(value, (each_loc) => {
                    var found_index = _.findIndex(this.selected_hco_locations, (o) => { return o.id === each_loc.id; });
                    if(found_index >= 0){
                        this.selected_hco_locations.splice(found_index, 1);
                    }
                });
            }else{
                var found_index = _.findIndex(this.selected_hco_locations, (o) => { return o.id === value.id; });
                if(found_index >= 0){
                    this.selected_hco_locations.splice(found_index, 1);
                }
            }
        },
        AddSraContributorSubmit(){
            this.v$.$touch();
            if (!this.v$.$invalid) {
                this.disable_addcontributor_submit_btn = true;
                var location_access = new Array();
                var hco_location = new Array();
                if(this.all_location_list.length > 1){
                    _.forEach(this.selected_access_locations, (value) => {
                        location_access.push({"location_id": value.id});
                    });
                    _.forEach(this.selected_hco_locations, (value) => {
                        hco_location.push({"location_id": value.id});
                    });
                }else{
                    location_access.push({"location_id": this.all_location_list[0].id});
                    if(this.add_hco_option == 'yes'){
                        hco_location.push({"location_id": this.all_location_list[0].id});
                    }
                }
                NProgress.start();
                axios
                .post(JS_APP_URL + "/sra-contributor/add-risk-analysis-contributor", {
                    first_name: this.first_name,
                    last_name: this.last_name,
                    company_name: this.company_name,
                    email: this.email,
                    location_list: location_access,
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if(response["data"]['data'].length > 0){
                            toastr.error(response["data"]['data'].join('</br>'), "Error");
                        }else{
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        toastr.success(response["data"]["message"], "Success");
                        setTimeout(() => {
                            this.$emit("add-sra-contributor-form-toggle", false);
                            this.$emit("reset-all-filter");
                            this.$emit("load-all-sracontributor-list", true);
                        }, 100);
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.disable_addcontributor_submit_btn = false;
                    this.submit_button_key++;
                });
            }
            else{
                this.submit_button_key++;
            }
        },
        cancelAddSraContributor(){
            this.$emit("add-sra-contributor-form-toggle", false);
        }
    },
    created() {
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.$emit("add-sra-contributor-form-toggle", false);
            }
        });
    }
};
</script>
