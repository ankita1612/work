<template>
    <div class="training-tab-content pt40">
        <div class="container">
            <filter-sra-contributor-list :key="filter_component_key" @open-import-modal="openCloseImportModal" :sample_import_file_link="sample_import_file_link" :is_refresh_btn_shown="is_refresh_btn_shown" @apply-filter="applyFilter" :all_location_list="all_location_list" @add-sra-contributor-form-toggle="addSraContributorFormToggle" :is_add_contributor_shown="is_add_contributor_shown" @reset-all-filter="resetAllFilter" @load-all-sracontributor-list="loadAllSraContributorList"></filter-sra-contributor-list>
    
            <transition name="simple-fade-transition">
                <add-sra-contributor v-if="is_add_contributor_shown" @add-sra-contributor-form-toggle="addSraContributorFormToggle" :all_location_list="all_location_list" @load-all-sracontributor-list="loadAllSraContributorList" @reset-all-filter="resetAllFilter"></add-sra-contributor>
            </transition>
    
            <sra-contributor-item v-for="(au_item, index) in sra_contributor_list" v-bind:key="index" :sra_contributor_item="au_item" :all_location_list="all_location_list" @load-all-user-list="loadAllSraContributorList" @updated-sra-contributor="updatedSraContributor" @deleted-sra-contributor="deletedSraContributor"></sra-contributor-item>
            <div v-if="!is_full_page_loader_shown && sra_contributor_list.length === 0" class="">
                <div class="user-detail-text font-14 gray_checkmark--text text-center">
                    <no-data-icon></no-data-icon>
                    <div class="font-14 text-center blueog--text">No SRA contributor(s) available.</div>
                </div>
            </div>
            <InfiniteLoading @infinite="loadAllSraContributorList(false)" />
            <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
        </div>
        <import-error-modal 
          v-if="is_import_error_modal"
          :import_errors="import_errors_data"
          @close-model="openCloseImportModal"
        />
    </div>
    </template>
    
    <script>
    import axios from "axios";
    import toastr from "toastr";
    import "toastr/toastr.scss";
    toastr.options.preventDuplicates = true;
    import fullPageLoader from '../../common/fullPageLoader.vue';
    import noDataIcon from '../../common/icons/noDataIcon.vue';
    import filterSraContributorList from "./filterSraContributorList.vue";
    import addSraContributor from "./addSraContributor.vue";
    import sraContributorItem from "./sraContributorItem.vue";
    import importErrorModal from "../../common/includes/importErrorModal.vue";
    import _ from "lodash";
    
    export default {
        data() {
            return {
                filter_by_access_level: '',
                filter_by_location: [],
                search_query: "",
                sample_import_file_link: "",
                sra_contributor_list: [],
                is_add_contributor_shown: false,
                all_location_list: [],
                is_list_loading: false,
                per_page_records: 10,
                current_page: 1,
                total_page: 1,
                filter_component_key: Math.random(),
                is_full_page_loader_shown: false,
                is_refresh_btn_shown: false,
                JS_APP_URL: JS_APP_URL,
                JS_WORDPRESS_URL: JS_WORDPRESS_URL,
                is_import_error_modal: false,
                import_errors_data: [],
                sort_by: '',
                sort_by_dir: '',
                call_ajax: 1,
            };
        },
        components: {
            filterSraContributorList: filterSraContributorList,
            addSraContributor: addSraContributor,
            sraContributorItem: sraContributorItem,
            fullPageLoader: fullPageLoader,
            noDataIcon: noDataIcon,
            importErrorModal: importErrorModal,
        },
        props: {},
        watch: {},
        mounted() {
            this.loadLocationList();
        },
        methods: {
            addSraContributorFormToggle(status = true){
                this.is_add_contributor_shown = status;
            },
            loadLocationList(){
                this.is_full_page_loader_shown = true;
                axios
                .get(JS_APP_URL + "/general/get-all-location-list")
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        this.all_location_list = response["data"]["data"];
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";    
                    }
                })
                .then(() => {
                    this.is_full_page_loader_shown = false;
                });
            },
            loadAllSraContributorList(need_pagination_reset = false){
                if(need_pagination_reset){
                    this.current_page = 1;
                    this.total_page = 1;
                    this.sra_contributor_list = [];
                }
                if (this.current_page <= this.total_page && this.call_ajax == 1) {	
                    this.call_ajax = 0;
                    this.is_list_loading = true;	
                    this.is_full_page_loader_shown = true;
                    axios
                    .post(JS_APP_URL + "/sra-contributor/get-risk-analysis-contributor-list", {
                        filter_by_access_level: this.filter_by_access_level,
                        filter_by_location: _.map(this.filter_by_location, 'id'),
                        search_query: this.search_query,
                        sort_by: this.sort_by,
                        sort_by_dir: this.sort_by_dir,
                        search_query: this.search_query,
                        per_page: this.per_page_records,
                        page: this.current_page
                    })
                    .then((response) => {
                        if (response["data"]["status"] == "Success") {
                            this.sample_import_file_link = response["data"]["data"]['sample_import_file_link'];
                            var sra_contributor_data = response["data"]["data"]['sra_contributors_list'];
    
                            this.sra_contributor_list.push(...sra_contributor_data.data);
                            this.total_page = sra_contributor_data.last_page;
                            if(this.sra_contributor_list.length == 0 && this.search_query == '' && this.filter_by_location.length  == 0 && this.filter_by_access_level == ''){
                                this.is_add_contributor_shown = true;
                            }
                            this.current_page = this.current_page + 1;
                            this.is_list_loading = false;
                            this.is_refresh_btn_shown = false;
                        }
                    })
                    .catch((error) => {
                        toastr.error(error.response["data"]["message"], "Error");
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";    
                        }
                    })
                    .then(() => {				
                        setTimeout(() => {
                            this.is_full_page_loader_shown = false;
                            this.call_ajax = 1;
                        }, 100);
                    });
                }
            },
            applyFilter(search_params = {}){
                this.filter_by_access_level = search_params.filter_by_access_level;
                this.filter_by_location = search_params.filter_by_location;
                this.search_query = search_params.search_query;
                this.sort_by = search_params.sort_by;
                this.sort_by_dir = search_params.sort_by_dir;
                setTimeout(() => {
                    this.loadAllSraContributorList(true);
                }, 100);
            },
            resetAllFilter(){
                this.filter_by_access_level = '';
                this.filter_by_location = [];
                this.search_query = "";
                this.sort_by = '';
                this.sort_by_dir = '';
                this.filter_component_key = Math.random();
            },
            showRefreshListButton(){
                if(this.filter_by_access_level != "" || this.filter_by_location.length > 0 || this.search_query != ""){
                    this.is_refresh_btn_shown = true;
                }
            },
            deletedSraContributor(sra_contributor_id = ''){
                if(sra_contributor_id){
                    var found_index = _.findIndex(this.sra_contributor_list, (o) => { return o.id === sra_contributor_id; });
                    if(found_index >= 0){
                        this.sra_contributor_list.splice(found_index, 1);
                        if(this.sra_contributor_list.length == 0){
                            this.showRefreshListButton();
                        }
                    }
                }
            },
            updatedSraContributor(sra_contributor_updated = {}){
                if(!_.isEmpty(sra_contributor_updated)){
                    var found_index = _.findIndex(this.sra_contributor_list, (o) => { return o.id === sra_contributor_updated.id; });
                    if(found_index >= 0){
                        this.sra_contributor_list[found_index] = sra_contributor_updated;
                        this.showRefreshListButton();
                    }
                }
            },
            openCloseImportModal(import_errors) {
                if(!this.is_import_error_modal) {
                    this.is_import_error_modal = true
                    this.import_errors_data = import_errors;
                } else {
                    this.is_import_error_modal = false
                }
            },
        },
        created() {},
    };
    </script>
    