<template>
    <div>
        <transition name="simple-fade-transition" mode="out-in">
        <div v-if="!is_contributor_editing" key="saved" class="user-detail-card py7 px15 light mb20">
            <div class="row flex-auto -mx-10 items-center">
                <div class="col-12 col-md-5 col-lg-2 col-xl-2 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text" v-text="sra_contributor_item.first_name"></div>
                </div>
                <div class="col-12 col-md-7 col-lg-2 col-xl-2 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text"  v-text="sra_contributor_item.last_name"></div>
                </div>
                <div class="col-12 col-md-5 col-lg-2 col-xl-2 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text"  v-text="sra_contributor_item.company_name"></div>
                </div>
                <div class="col-12 col-md-5 col-lg-3 col-xl-3 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text"  v-text="sra_contributor_item.email"></div>
                </div>
                <div class="col-6 col-sm-6 col-md-7 col-lg-1 col-xl-1 px10">
                    <div class="flex-auto user-location-name-block word-wrap text-truncate white-no-wrap">
                        <VTooltip class="text-center fill-width" v-if="sra_contributor_item.risk_analysis_contributor_location.length == 1 && all_location_list.length > 1" :triggers="['hover']"  :popperTriggers="['hover']">
                            <span  class="user-admin-name font-12 gray_checkmark--text uppercase word-wrap text-truncate white-no-wrap tuncate-location-width" :title="sra_contributor_item.risk_analysis_contributor_location[0].location.location_nickname">{{sra_contributor_item.risk_analysis_contributor_location[0].location.location_nickname}}</span>
                            <template #popper>
                                <div class="white--text font-12 font_semibold mb2 text-center pb5 pt5">Assigned Location(s)</div>
                                <div class="text-center seperator-line pt3 pb3" >{{sra_contributor_item.risk_analysis_contributor_location[0].location.location_nickname}}</div>
                            </template>
                        </VTooltip>
                        <button v-if="sra_contributor_item.risk_analysis_contributor_location.length > 1" type="button" class="user-location-icon cursor-pointer mt2">
                            <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                                <img :src="JS_APP_URL +'/images/location.svg'" alt="" title="">
                                <template #popper>
                                    <div class="white--text font-12 font_semibold mb2 text-center pb5 pt5">Assigned Location(s)</div>
                                    <div class="text-center seperator-line pt3 pb3" v-for="(each_location, each_location_index) in sra_contributor_item.risk_analysis_contributor_location" v-bind:key="each_location_index" v-text="each_location.location.location_nickname"></div>
                                </template>
                            </VTooltip>
                        </button>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-2 col-xl-2 px10">
                    <div class="flex flex-wrap items-center justify-end justify-start-small-medium user-detail-action">
                        <div class="action-sept mr30 ml20"></div>
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                            <button v-on:click="editSraContributorDetail()" type="button" class="action-icon-btn action-btn-blueog cursor-pointer">
                                <img :src="JS_APP_URL +'/images/pencil.svg'" alt="" title="">
                            </button>
                            <template #popper>
                                Edit
                            </template>
                        </VTooltip>
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml7">
                            <button v-on:click="deleteSraContributorToggle()" type="button" class="delete-location-btn cursor-pointer">
                                <img :src="JS_APP_URL +'/images/bin.svg'" alt="" title="">
                            </button>
                            <template #popper>
                                Delete
                            </template>
                        </VTooltip>
                    </div>
                </div>
            </div>
        </div>
        <div v-else key="editing" >
            <form @submit.prevent="editSraContributorSubmit">
                <div class="user-detail-card light px8 pt20">
                    <div class="add-user-form mb50 sra-contributor-add-form">
                        <div class="account-user-add-row row items-start -mx-10">
                            <div class="col-12 px10">
                                    <div class="row flex-auto -mx-10">
                                        <div class="col-12 col-md-4 col-lg-3 col-xl-3 px10 mb22">
                                            <div class="form-group mb-0" :class="{ 'form-group--error': v$.first_name.$errors.length }">
                                                <input class="form-input location-input-box" :class="{ 'form-error': v$.first_name.$errors.length }" type="text" name="first_name" v-model.trim="v$.first_name.$model">
                                                <label class="label location-input-label" :class="{ 'label-float': v$.first_name.$model }">First Name</label>
                                                <div v-if="v$.first_name.$errors.length > 0">
                                                    <div class="form-error-text">
                                                        {{ v$.first_name.$errors[0].$message }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4 col-lg-3 col-xl-3 px10 mb22">
                                            <div class="form-group mb-0" :class="{ 'form-group--error': v$.last_name.$errors.length }">
                                                <input class="form-input location-input-box" :class="{ 'form-error': v$.last_name.$errors.length }" type="text" name="last_name" v-model.trim="v$.last_name.$model">
                                                <label class="label location-input-label" :class="{ 'label-float': v$.last_name.$model }">Last Name</label>
                                                <div v-if="v$.last_name.$errors.length > 0">
                                                    <div class="form-error-text">
                                                        {{ v$.last_name.$errors[0].$message }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4 col-lg-3 col-xl-3 px10 mb22">
                                            <div class="form-group mb-0" :class="{ 'form-group--error': v$.company_name.$errors.length }">
                                                <input class="form-input location-input-box" :class="{ 'form-error': v$.company_name.$errors.length }" type="text" name="company_name" v-model.trim="v$.company_name.$model">
                                                <label class="label location-input-label" :class="{ 'label-float': v$.company_name.$model }">Company Name</label>
                                                <div v-if="v$.company_name.$errors.length > 0">
                                                    <div class="form-error-text">
                                                        {{ v$.company_name.$errors[0].$message }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4 col-lg-3 col-xl-3 px10 mb22">
                                            <div class="form-group mb-0" :class="{ 'form-group--error': v$.email.$errors.length }">
                                                <input class="form-input location-input-box" :class="{ 'form-error': v$.email.$errors.length }" type="text" name="email" v-model.trim="v$.email.$model">
                                                <label class="label location-input-label" :class="{ 'label-float': v$.email.$model }">Email</label>
                                                <div v-if="v$.email.$errors.length > 0">
                                                    <div class="form-error-text">
                                                        {{ v$.email.$errors[0].$message }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-3 col-lg-3 col-xl-3 px10 mb-sm-10">
                                            <div v-if="all_location_list.length > 1" class="form-group mb-0" :class="{ 'form-group--error': v$.selected_access_locations.$errors.length }">
                                                <multiselect
                                                class="select-all-dropdown"
                                                v-model="v$.selected_access_locations.$model"
                                                tag-placeholder=""
                                                placeholder=""
                                                label="location_nickname"
                                                track-by="id"
                                                :options="local_all_location_list"
                                                group-values="group_option_list"
                                                group-label="select_all"
                                                :group-select="true"
                                                :multiple="true"
                                                :showLabels="false"
                                                :close-on-select="false"
                                                @remove="removeLocationAccess"
                                                :taggable="false">
                                                    <template #noResult>
                                                        <div class="multiselect__noResult text-center">No results found</div>
                                                    </template>
                                                    <template #selection>
                                                        <div class="multiselect__tags-wrap" v-if="selected_access_locations.length > 1">
                                                            <span class="multiselect__tag">
                                                                <span>{{ selected_access_locations.length }} Locations Selected</span>
                                                            </span>
                                                        </div>
                                                    </template>
                                                </multiselect>
                                                <label class="label label-select" :class="{ 'label-float': (selected_access_locations.length > 0) }">Assigned Location(s)</label>
                                                <div v-if="v$.selected_access_locations.$errors.length > 0">
                                                    <div class="form-error-text">
                                                        {{ v$.selected_access_locations.$errors[0].$message }}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="col-12 col-md-12 px10 mt-sm-20">
                                <div class="flex items-center flex-wrap submit-cancel-buttons mb14 justify-center">
                                    <button
                                    type="button"
                                    class="btn-cancel-outline btn-cancel-form mx4"
                                    :disabled="disable_sra_contributor_submit_btn"
                                    @click="cancelEditSraContributor"
                                    >
                                        <span>Cancel</span>
                                    </button>
                                    <button
                                    type="submit"
                                    class="btn-primary mx4"
                                    :disabled="disable_sra_contributor_submit_btn"
                                    >
                                        <span>Submit</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        </transition>
        <delete-sra-contributor-modal
        v-if="is_deletecontributormodal_shown"
        :sra_contributor_id="deletesracontributormodal_sra_contributor_id"
        @close-model="deleteSraContributorToggle"
        @delete-sra-contributor="deleteContributorSubmit"
        ></delete-sra-contributor-modal>
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from 'lodash';
import useVuelidate from "@vuelidate/core";
import { required, requiredIf, email, maxLength, helpers } from "@vuelidate/validators";
import deleteSraContributorModal from "./deleteSraContributorModal.vue";
import clearDropdownIcon from '../../common/icons/clearDropdownIcon.vue';
import infoIcon from "../../common/icons/infoIcon.vue";
import {checkSpecialChars, checkSpecialCharsErrorMessage}  from "../../common/customValidation";
import mitt from 'mitt'
const emitter = mitt()

export default {
    data() {
        return {
        sra_contributor_id: '',
        first_name: '',
        last_name: '',
        company_name: '',
        email: '',
        local_all_location_list : [{
            'select_all': 'Select All',
            'group_option_list': this.all_location_list,
        }],
        selected_access_locations: [],
        selected_hco_locations: [],
        is_contributor_editing: false,
        disable_sra_contributor_submit_btn: false,
        is_deletecontributormodal_shown: false,
        contrinutor_questions_count_arr: [],
        deletesracontributormodal_sra_contributor_id: "",
        check_hco_available_timer: null,
        JS_APP_URL: JS_APP_URL,
        JS_WORDPRESS_URL: JS_WORDPRESS_URL,
        AUTH_USER: AUTH_USER,
        checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage
        };
    },
    components: {
        deleteSraContributorModal: deleteSraContributorModal,
        clearDropdownIcon,
        infoIcon
    },
    props: {
        sra_contributor_item:{
            type: Object,
            default: () => {}
        },
        all_location_list:{
            type: Array,
            default: () => []
        },
    },
    emits: ['close_other_user_edit', "updated-sra-contributor", "deleted-sra-contributor"],
    setup: () => ({ v$: useVuelidate() }),
    validations() {
        var validationArray = {
            first_name: {
                required: helpers.withMessage("Please enter a first name", required),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
                maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
            },
            last_name: {
                required: helpers.withMessage("Please enter a last name", required),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
                maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
            },
            company_name:{
                required: helpers.withMessage("Please enter a company name", required),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
                maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
            },
            email: {
                email: helpers.withMessage("Please enter a valid email", email),
                required: helpers.withMessage("Please enter an email", required),
                maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
                isUnique: helpers.withMessage("Email address already in use", helpers.withAsync(async (value) => {
                    if (!value) return true;
                    if (this.v$.email.required.$invalid || this.v$.email.email.$invalid) return true;
                    this.disable_sra_contributor_submit_btn = true;
                    let check_promise = new Promise((resolve, reject) => {
                        if (this.check_hco_available_timer) {
                            clearTimeout(this.check_hco_available_timer);
                            this.check_hco_available_timer = null;
                        }
                        this.check_hco_available_timer = setTimeout(() => {
                            return fetch(JS_APP_URL + `/sra-contributor/check-unique-email-risk-analysis-contributor/${value}/${this.sra_contributor_id}`)
                            .then((response) => {
                                    if (response.ok) {
                                        resolve(response.text());
                                    } else {
                                        resolve(new Error("error"));
                                    }
                                },
                                (error) => {
                                    resolve(new Error("error"));
                                }
                            );
                        }, 500);
                    });
                    let response = await check_promise;
                    this.disable_sra_contributor_submit_btn = false;
                    return Boolean(response == "available" ? false : true);
                }))
            },
            selected_access_locations: {
                required: helpers.withMessage("Please select location(s)", requiredIf(() => {
                    return (this.all_location_list.length > 1)
                }))
            }
        };
        return validationArray;
    },
    mounted() {
        emitter.on('close_other_user_edit', (sra_contributor_id) => {
            if(sra_contributor_id !== this.sra_contributor_item.id){
                this.is_contributor_editing = false;
            }
        });
    },
    watch: {},
    computed: {},
    methods: {
        editSraContributorDetail(){
            this.sra_contributor_id = this.sra_contributor_item.id;
            this.first_name = this.sra_contributor_item.first_name;
            this.last_name = this.sra_contributor_item.last_name;
            this.company_name = this.sra_contributor_item.company_name;
            this.email = this.sra_contributor_item.email;
            this.selected_access_locations = [];
            _.forEach(this.sra_contributor_item.risk_analysis_contributor_location, (value) => {
                    var is_found_location = _.find(this.all_location_list, (o) => { return o.id === value.location.id; });
                    if(!_.isUndefined(is_found_location)){
                        this.selected_access_locations.push(is_found_location);
                    }
            });
            this.contrinutor_questions_count_arr = [];
            _.forEach(this.sra_contributor_item.risk_analysis_contributor_location, (value) => {
                if(value.contrinutor_questions_count > 0) {
                    this.contrinutor_questions_count_arr.push({"location_id": value.location.id});
                }
            });  
            this.selected_hco_locations = [];
            _.forEach(this.sra_contributor_item.hipaa_compliance_officer, (value) => {
                    this.selected_hco_locations.push(value.location);
            });
            setTimeout(() => {
                this.is_contributor_editing = true;
                emitter.emit('close_other_user_edit', this.sra_contributor_id);
            }, 100);
        },
        editSraContributorSubmit(){
            this.v$.$touch();
            if (!this.v$.$invalid) {
                var location_access_new = new Array();
                var location_access_removed = new Array();
                var remove_questions_location = new Array();
                if(this.all_location_list.length > 1){
                    _.forEach(this.selected_access_locations, (value) => {
                    if(_.isUndefined( _.find(this.sra_contributor_item.risk_analysis_contributor_location, (o) => { return o.location.id == value.id; }))){
                        location_access_new.push({"location_id": value.id});
                    }
                    });
                    _.forEach(this.sra_contributor_item.risk_analysis_contributor_location, (value) => {
                    if(_.isUndefined( _.find(this.selected_access_locations, (o) => { return o.id == value.location.id; }))){
                        location_access_removed.push({"location_id": value.location.id});
                    }
                    });
                    remove_questions_location = this.contrinutor_questions_count_arr.filter(location =>
                                    location_access_removed.some(remove_location =>
                                    remove_location.location_id === location.location_id
                                )
                        );
                }else{
                    if(this.sra_contributor_item.risk_analysis_contributor_location.length == 0){
                        location_access_new.push({"location_id": this.all_location_list[0].id});
                    }
                }
                if(remove_questions_location.length > 0) {
                    toastr.error('You cannot remove location as this contributor has assigned as security risk analysis question. Please approve or reject  answer for this contributor before unassign location.', "Error");
                    return false;
                }
                NProgress.start();
                this.disable_sra_contributor_submit_btn = true;
                axios
                .post(JS_APP_URL + "/sra-contributor/edit-risk-analysis-contributor", {
                    risk_analysis_contributor_id: this.sra_contributor_id,
                    first_name: this.first_name,
                    last_name: this.last_name,
                    company_name: this.company_name,
                    email: this.email,
                    location_work_new: location_access_new,
                    location_work_removed: location_access_removed,
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if(response["data"]['data'].length > 0){
                            toastr.error(response["data"]['data'].join('</br>'), "Error");
                        }else{
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        toastr.success(response["data"]["message"], "Success");
                        setTimeout(() => {
                            this.is_contributor_editing = false;
                            this.$emit("updated-sra-contributor", response["data"]['data']);
                        }, 100);
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.disable_sra_contributor_submit_btn = false;
                });
            }
        },
        deleteSraContributorToggle(status = true){
            this.deletesracontributormodal_sra_contributor_id = this.sra_contributor_item.id;
            this.is_deletecontributormodal_shown = status;
            setTimeout(() => {
                emitter.emit('close_other_user_edit', this.sra_contributor_item.id);
            }, 100);
        },
        deleteContributorSubmit(){
            if(this.deletesracontributormodal_sra_contributor_id){
                NProgress.start();
                axios
                .post(JS_APP_URL + "/sra-contributor/delete-risk-analysis-contributor", {
                    risk_analysis_contributor_id: this.deletesracontributormodal_sra_contributor_id
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if(response["data"]['data'].length > 0){
                            toastr.error(response["data"]['data'].join('</br>'), "Error");
                        }else{
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        toastr.success(response["data"]["message"], "Success");
                        setTimeout(() => {
                            this.$emit("deleted-sra-contributor", this.deletesracontributormodal_sra_contributor_id);
                        }, 100);
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.is_deletecontributormodal_shown = false;
                });
            }
        },
        removeLocationAccess(value){
            if(_.isArray(value)){
                _.forEach(value, (each_loc) => {
                    var found_index = _.findIndex(this.selected_hco_locations, (o) => { return o.id === each_loc.id; });
                    if(found_index >= 0){
                        this.selected_hco_locations.splice(found_index, 1);
                    }
                });
            }else{
                var found_index = _.findIndex(this.selected_hco_locations, (o) => { return o.id === value.id; });
                if(found_index >= 0){
                    this.selected_hco_locations.splice(found_index, 1);
                }
            }
        },
        cancelEditSraContributor(){
            this.is_contributor_editing = false;
        }
    },
    created() {
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.is_contributor_editing = false;
            }
        });
    }
};
</script>
