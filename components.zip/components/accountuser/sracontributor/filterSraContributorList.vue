<template>
    <div>
        <div class="account-user-filter flex flex-wrap justify-between items-center mb40">
          <div class="row flex-auto -mx-10">
            <div class="col-12 col-lg-12 col-xl-4 px10">
              <div class="flex flex-wrap flex-auto items-center">
                  <h6 class="font-18 blueog--text mb0 mr6">SRA Contributors</h6>
                  <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" style="height: 24px;" class="cursor-pointer">
                  <span><info-icon></info-icon></span>
                    <template #popper>
                        <i class="text-center d-block">Add trusted SRA Contributors from outside of your organization (example: an employee of a Business Associate) to assist in answering <span class="font-italic">Security Risk Analysis</span> (SRA) questions.</i>
                    </template>
                  </VTooltip>
                  <button v-on:click="toggleAddSraContributorForm" type="button" class="plus-icon-btn ml3 mt1">
                    <plus-icon></plus-icon>
                  </button>
                  <div class="import-btn-wrapper ml30">
                    <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                      <input :disabled="is_import_btn_disabled" ref="import_file_upload" type="file" hidden @change="importSraContributor" accept=".xlsx, .xls">
                      <button :disabled="is_import_btn_disabled" @click="onPickImportFile" type="button" class="import-btn"><span><import-icon></import-icon></span><span>Import</span></button>
                      <template #popper>
                        <i class="text-center d-block">If preferred, you may import multiple SRA Contributor's records via excel file upload.<br> Click here to <b><a class="downloadsamplelink font-300" :href="sample_import_file_link" target="_blank">download the Template File</a></b>. Once completed, click the IMPORT button to upload your SRA Contributors.</i>
                      </template>
                    </VTooltip>
                  </div>
                  <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" v-if="is_refresh_btn_shown">
                    <a v-on:click="resetAndLoadLatestData()" class="font-12 blueog--text ml10 font-italic font_semibold cursor-pointer d-block text-right">
                      <img :src="JS_APP_URL +'/images/refresh-list.png'" />
                    </a>
                    <template #popper>
                      Refresh SRA Contributor List
                    </template>
                  </VTooltip>
                </div>
              </div>
              <div class="col-12 col-lg-12 col-xl-8 px10">
                <div class="flex flex-wrap flex-auto" :class="[all_location_list.length == 1 ? 'single-location-filter-wrapper' : '']">
             
                    
                      <div class="row flex-auto -mx-10 items-center justify-end">
                        <div  v-if="all_location_list.length > 1" class="col-12 col-md-6 col-lg-3 col-xl-3 px10">
                          <div class="form-group account-filter-wrapper mb-0 max-width-location">
                            <multiselect 
                            v-model="selected_locations" 
                            tag-placeholder="" 
                            placeholder="" 
                            label="location_nickname" 
                            track-by="id" 
                            :options="all_location_list" 
                            :multiple="true" 
                            :close-on-select="true"
                            :searchable="false"
                            :showLabels="false"
                            @update:model-value="onChangeFilter"
                            :taggable="false">
                                <template #noResult>
                                    <div class="multiselect__noResult text-center">No results found</div>
                                </template>  
                                <template #selection>
                                    <div class="multiselect__tags-wrap" v-if="selected_locations.length > 1">
                                        <span class="multiselect__tag">
                                            <span>{{ selected_locations.length }} Locations Selected</span>
                                        </span>
                                    </div>
                                </template>                                      
                            </multiselect>	
                            <label class="label label-select" :class="{ 'label-float': (selected_locations.length > 0) }">Filter by Location</label>
                          </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10">
                            <div class="flex items-center">
                            <div class="form-group account-filter-wrapper mb-0 flex-auto">
                            <multiselect 
                            v-model="filter_selected_sort_by" 
                            :options="sort_by_options" 
                            :close-on-select="true" 
                            tag-placeholder="" 
                            placeholder="" 
                            label="text" 
                            track-by="id" 
                            @update:model-value="onChangeFilter"
                            :searchable="false"
                            :showLabels="false"
                            :taggable="false"
                            >
                                <template #noResult>
                                    <div class="multiselect__noResult text-center">No results found</div>
                                </template>   
                            </multiselect>
                            <label class="label label-select font-italic" :class="{ 'label-float': (filter_selected_sort_by != null) }">Sort by</label>                         
                            </div>
                            <img v-on:click="toggleSortDir" v-if="filter_selected_sort_by != null && filter_selected_sort_by_dir == 'ASC'" :src="JS_APP_URL + '/images/sort-up.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" />      
                            <img v-on:click="toggleSortDir" v-if="filter_selected_sort_by != null && filter_selected_sort_by_dir == 'DESC'" :src="JS_APP_URL + '/images/sort-down.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" /> 
                            </div>
                        </div> 
                        <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10">
                          <div class="form-group account-filter-wrapper mb-0">
                              <input @input="onChangeFilter" class="form-input form-input-search" type="text" v-model.trim="search_text">
                                <label class="label" :class="{ 'label-float': search_text }">Search</label>
                                <div
                                    class="search-btn-input">
                                    <img :src="JS_APP_URL +'/images/search.svg'" alt="" title="" />
                                </div>
                          </div>
                        </div>
                </div>
                </div>
            </div>
          </div>
        </div>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>

<script scoped>
import axios from "axios";
import fullPageLoader from "../../common/fullPageLoader.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import importIcon from '../../common/icons/importIcon.vue';
import infoIcon from '../../common/icons/infoIcon.vue';
import plusIcon from '../../common/icons/plusIcon.vue';
import clearDropdownIcon from '../../common/icons/clearDropdownIcon.vue';

export default {
  data() {
    return {
      selected_access_level: null,
      selected_locations: [],
      delay_timer: "",
      search_text: "",
      is_import_btn_disabled: false,
      is_full_page_loader_shown: false,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      filter_selected_sort_by: null,
      filter_selected_sort_by_dir: 'ASC',
      sort_by_options: [
            { id: 'first_name', text: 'First Name' },
            { id: 'last_name', text: 'Last Name' },
            { id: 'company_name', text: 'Company Name' },
            { id: 'email', text: 'Email' },            
      ],
    };
  },
  components: { importIcon, infoIcon, clearDropdownIcon, plusIcon,fullPageLoader},
  props: {
    is_add_contributor_shown:{
      type: Boolean,
      default: () => true
    },
    is_refresh_btn_shown:{
      type: Boolean,
      default: () => true
    },
    all_location_list:{
      type: Array,
      default: () => []
    },
    sample_import_file_link:{
      type: String,
      default: () => ""
    },
  },
  emits: ['add-sra-contributor-form-toggle', 'apply-filter', "reset-all-filter", "load-all-sracontributor-list", "open-import-modal"],
  mounted() {},
  watch: {},
  computed: {},
  methods: {
    toggleSortDir() {
      this.filter_selected_sort_by_dir = (this.filter_selected_sort_by_dir == 'ASC') ? 'DESC' : 'ASC';
      this.onChangeFilter();
    },
    toggleAddSraContributorForm(){
      this.$emit('add-sra-contributor-form-toggle', !this.is_add_contributor_shown)
    },
    onChangeFilter(){
      if (this.delay_timer) {
          clearTimeout(this.delay_timer);
          this.delay_timer = null;
      }
      this.delay_timer = setTimeout(() => {
        this.$emit('apply-filter', {search_query:this.search_text, filter_by_access_level: (this.selected_access_level != null)?this.selected_access_level.id:'', filter_by_location: this.selected_locations, sort_by: (this.filter_selected_sort_by != null) ? this.filter_selected_sort_by.id : '', sort_by_dir: this.filter_selected_sort_by_dir});
      }, 800);
    },
    onPickImportFile(){
      this.$refs.import_file_upload.click();
    },
    importSraContributor(event){ 
      var formData = new FormData();
      formData.append("import_file", event.target.files[0]);
      this.is_full_page_loader_shown = true;
      this.is_import_btn_disabled = true;
      axios
      .post(JS_APP_URL + "/sra-contributor/import-risk-analysis-contributor", formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response['data']['data'].length == 0){
                this.$emit("open-import-modal", response["data"]);
              }else{
                this.$emit("open-import-modal", response['data']);
              }
              setTimeout(() => {
                this.$refs.import_file_upload.value = null;
              }, 200);
          } else {
              if(response['data']['data'].length == 0){
                toastr.success(response["data"]["message"], "Success");
              }
              setTimeout(() => {
                  this.$emit("add-sra-contributor-form-toggle", false);
                  this.$emit("reset-all-filter");
                  this.$emit("load-all-sracontributor-list", true);
                  if(response['data']['data'].length != 0){
                    this.$emit("open-import-modal", response['data']);
                  }
              }, 100);
          }
      })
      .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";    
          }
      })
      .then(() => {
          this.is_full_page_loader_shown = false;
          this.is_import_btn_disabled = false;
      });
    },
    resetAndLoadLatestData(){
      this.$emit("reset-all-filter");
      this.$emit("load-all-sracontributor-list", true);
    },
  }
};
</script>
