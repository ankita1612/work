import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import 'floating-vue/dist/style.css';
import InfiniteLoading from "v3-infinite-loading";
import accountuser from "./accountuser.vue";
import VueMask from '@devindex/vue-mask';

const accountuser_app = createApp(accountuser);
accountuser_app.use(FloatingVue);
accountuser_app.use(VueMask);
accountuser_app.component('multiselect', Multiselect);
accountuser_app.component('InfiniteLoading', InfiniteLoading);
accountuser_app.mount("#accountuser_app");