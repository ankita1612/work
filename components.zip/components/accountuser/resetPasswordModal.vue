<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container">
            <button v-if="!disable_resetpassword_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb30 pt20">
              <img :src="JS_APP_URL + '/images/pass_lock.svg'" alt="" title="" />
            </div>
            <h2
              class="
                font-24 font_semibold
                blueog--text
                line-normal
                mb30
                text-center
              "
            >
              Reset Password
            </h2>
            <div class="modal-body">
              <form @submit.prevent="resetPasswordSubmit" class="reset-form">
                <div
                  class="form-group"
                  :class="{ 'form-group--error': v$.new_password.$errors.length }"
                >
                  <input
                    class="form-input"
                    :class="{ 'form-error': v$.new_password.$errors.length }"
                    id="new_password"
                    name="new_password"
                    v-model.trim="v$.new_password.$model"
                    :type="new_password_field_type"
                  />
                  <label
                    class="label"
                    :class="{ 'label-float': v$.new_password.$model }"
                    >New Password</label
                  >
                  <div v-if="v$.new_password.$errors.length > 0">
                    <div class="form-error-text">
                        {{ v$.new_password.$errors[0].$message }}
                    </div>
                  </div>
                  <button v-on:click="togglePasswordVisibility('new_password')" type="button" class="cursor-pointer pass-eye-icon">
                    <img v-if="new_password_field_type == 'password'" :src="JS_APP_URL + '/images/eye.svg'" alt="" title="" />
                    <img v-if="new_password_field_type == 'text'" :src="JS_APP_URL + '/images/eye-closed.svg'" alt="" title="" />
                  </button>
                </div>
                <div
                  class="form-group"
                  :class="{ 'form-group--error': v$.confirm_new_password.$errors.length }"
                >
                  <input
                    class="form-input"
                    :class="{ 'form-error': v$.confirm_new_password.$errors.length }"
                    id="confirm_new_password"
                    name="confirm_new_password"
                    v-model.trim="v$.confirm_new_password.$model"
                    :type="confirm_new_password_field_type"
                    @paste.prevent
                    @click.right.prevent
                  />
                  <label
                    class="label"
                    :class="{ 'label-float': v$.confirm_new_password.$model }"
                    >Confirm New Password</label
                  >
                  <div v-if="v$.confirm_new_password.$errors.length > 0">
                    <div class="form-error-text">
                        {{ v$.confirm_new_password.$errors[0].$message }}
                    </div>
                  </div>
                  <button v-on:click="togglePasswordVisibility('confirm_new_password')" type="button" class="cursor-pointer pass-eye-icon">
                      <img v-if="confirm_new_password_field_type == 'password'" :src="JS_APP_URL + '/images/eye.svg'" alt="" title="" />
                      <img v-if="confirm_new_password_field_type == 'text'" :src="JS_APP_URL + '/images/eye-closed.svg'" alt="" title="" />
                  </button>
                </div>
                <div class="text-center pt10 mb30">
                  <button
                    :disabled="disable_resetpassword_btn"
                    type="submit"
                    class="btn-primary mlr-auto"
                  >
                    <span>RESET PASSWORD</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import useVuelidate from "@vuelidate/core";
import { required, sameAs, minLength, helpers } from "@vuelidate/validators";
import closeIcon from '../common/icons/closeIcon.vue';
import { complexPassword  , complexPasswordErrorMseesage }  from "../common/customValidation";

export default {
  props: {
    user_id:{
      type: Number,
       default: () => 0
    },
    user_type:{
      type: String,
       default: () => ''
    },
  },
  emits: ["close-model"],
  data() {
    return {
      new_password: "",
      confirm_new_password: "",
      new_password_field_type: 'password',
      confirm_new_password_field_type: 'password',
      disable_resetpassword_btn: false,
      JS_APP_URL: JS_APP_URL,
    };
  },
  components:{
    closeIcon
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      new_password: {
        required: helpers.withMessage("Please enter a new password", required),
        minLength: helpers.withMessage("Password must have at least 6 letters", minLength(6)),
        isComplexPassword: helpers.withMessage(complexPasswordErrorMseesage, complexPassword),
      },
      confirm_new_password: {
        required: helpers.withMessage("Please enter a confirm password", required),
        confirmPassword: helpers.withMessage("Confirm password must match with original password", sameAs(this.new_password)),
      },
    }
    return validationArray;
  },
  methods: {
    togglePasswordVisibility(input_type){
      if(input_type == 'new_password'){
        this.new_password_field_type = (this.new_password_field_type == 'password')?'text':'password';
      }
      if(input_type == 'confirm_new_password'){
        this.confirm_new_password_field_type = (this.confirm_new_password_field_type == 'password')?'text':'password';
      }
    },
    resetPasswordSubmit() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        NProgress.start();
        this.disable_resetpassword_btn = true;
        var url = (this.user_type == 'primary_user')?JS_APP_URL + "/accountuser/change-primary-user-password":JS_APP_URL + "/accountuser/change-account-user-password";
        axios
          .post(url, {
            user_id: this.user_id,
            new_password: this.new_password,
            new_password_confirmation: this.confirm_new_password,
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
                if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
            } else {
                toastr.success(response["data"]["message"], "Success");
                this.$emit("close-model", false);
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            NProgress.done();
            this.disable_resetpassword_btn = false;
          });
      }
    },
    closeModal() {
      this.$emit("close-model", false);
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.disable_resetpassword_btn) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
