<template>
  <div>
    <header-after-login></header-after-login>
    <div class="container pt40 pb60">

      <div class="mlr-auto location-dropdon relative mb20">
        <switch-location :pass_selected_location_id="selected_location_id" :pass_updated_location_nickname_object="updated_location_nickname_object" @get-selected-location-id="getSelectedLocationId"></switch-location>
      </div>
          <h1 class="location-dashbaord-title text-center font-24 font_semibold blueog--text line-normal mb22 mb-sm-10 mb-md-10">Company Information</h1>


      <company-form :pass_selected_location_id="selected_location_id" @get-updated-location-nickname-object="getUpdatedLocationNicknameObject"></company-form>
    </div>
  </div>
</template>
<script scoped>
import switchLocation from './switchLocation.vue';
import companyForm from './companyForm.vue';
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      selected_location_id: parseInt(JS_LOCATION_ID),
      updated_location_nickname_object: {}
    };
  },
  components: {
    switchLocation,
    companyForm,
    headerAfterLogin
  },
  methods:{
    getSelectedLocationId(selected_location_id){
      this.selected_location_id = selected_location_id;
    },
    getUpdatedLocationNicknameObject(object){
      this.updated_location_nickname_object = object;
    },
  },
};
 </script>
