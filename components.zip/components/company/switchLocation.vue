<template>
  <div class="" v-if="all_location_list.length > 1">
    <multiselect 
    class="company-location-select"
    v-model="selected_location"
    placeholder=""
    :options="all_location_list" 
    track-by="id"  
    label="location_nickname"
    :multiple="false"              
    :close-on-select="true" 
    :showLabels="false"
    @update:model-value="onChangeLocationOption"
    :taggable="false"
    :allowEmpty="false">
    <template #noResult>
      <div class="multiselect__noResult text-center">
        No results found
      </div>
    </template>
    </multiselect>
    <label class="label label-select" :class="{ 'label-float': (selected_location_id > 0) }">Location</label>
  </div>
</template>
<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
export default {
  props: {
      pass_selected_location_id:{
        type: Number,
        default: () => {}
      },
      pass_updated_location_nickname_object:{
        type: Object,
        default: () => {}
      },
  },
  data() {
    return {
      all_location_list:[],
      selected_location_id: 0,
      selected_location: {},
      updated_location_nickname_object:{}
    };
  },
  emits: ["get-selected-location-id"],
  mounted() {
    this.loadLocationNicknameList();
    this.selected_location_id = this.pass_selected_location_id;
  },
  watch: {
      pass_updated_location_nickname_object(newVal, oldVal){
        this.objIndex = this.all_location_list.findIndex((obj => obj.id == newVal.id));
        this.all_location_list[this.objIndex].location_nickname = newVal.location_nickname;
      }
  },
  methods: {
    loadLocationNicknameList(){
      axios
      .get(JS_APP_URL + "/general/get-assigned-location-list")
      .then((response) =>{
        if(response["data"]["status"] == "Success") {
          this.all_location_list = response["data"]["data"];
          this.selected_location = this.all_location_list.find(object => object.id === this.selected_location_id);
          this.$emit("get-selected-location-id", this.selected_location_id);
        }
      })
      .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
      })
      .then(() => {
      });
    },
    onChangeLocationOption(){
      this.selected_location_id = this.selected_location.id;
      this.$emit("get-selected-location-id", this.selected_location_id);
    },
  }
};
 </script>