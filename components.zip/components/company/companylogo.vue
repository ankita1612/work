<template>
    <div>
        <div v-if="company_logo_url == '' || _.isNull(company_logo_url) == true">
            <div class="company-logo-upload text-center mlr-auto px10 py5 cursor-pointer fill-width mb45" v-tooltip="{
                content: `<span class='font-italic'>To include your company logo on all policy documents and forms sent through Abyde, upload a
                  copy of the logo here. If you would prefer not to have your logo displayed, feel free to skip
                  this section.</span>`,
                html: true,
                placement: 'right'
            }">
                <div class="font-16 font_semibold blueog--text company-logo-text">Company Logo</div>
                <div class="gray_checkmark--text">
                    <label class="company-logo-label font-10 font-italic">Click to select file to upload</label>
                    <input type="file" title="" @change="changeLogoEvent" id="logo" name="logo" class="logo" ref="logo"
                        accept="image/*" />
                </div>
            </div>
        </div>
        <div class="items-center justify-center mb40 text-center" v-else>
            <div class="company-logo-img text-center inline-flex items-center justify-center" v-tooltip="{
                content: `<span class='font-italic'>This logo will be used on your all policy documents and forms.</span>`,
                html: true,
                placement: 'right'
            }">
                <img :src="company_logo_url" alt="" title="" />
            </div>
            <div class="text-center mt15">
                <button type="button" class="remove-logo-btn btn-primary" v-on:click="removeCompanyLogo">
                    Remove Logo
                </button>
            </div>
        </div>
    </div>
</template>
<script scoped>

import toastr from "toastr";
import _ from 'lodash';
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
export default {
  props: {
    logo_url:{
      type: String,
      default: () => ""
    },
  },
  data() {
    return {
      company_logo: '',
      company_logo_url: '',
      _: _
    };
  },
  watch: {
    logo_url(newVal, oldVal){
        this.company_logo_url = newVal;
    }
  },
  computed:{},
  emits: ["get-logo-object"],
  methods: {
    changeLogoEvent() {
      this.company_logo = this.$refs.logo.files[0];
      var logoExtension = this.company_logo.name.split('.').pop().toLowerCase();
      var logoExtensionAllow = ['png','jpg','jpeg'];
      if(logoExtensionAllow.includes(logoExtension)){
        if(this.company_logo.size > 5000000){
            this.company_logo = '';
            this.$refs.logo.value=null;
            toastr.error("Please upload a logo file less than 5 MB", "Error");
        } else {
            this.company_logo_url = URL.createObjectURL(this.company_logo);
            this.$emit("get-logo-object", this.company_logo, this.company_logo_url);
        }
      } else {
        toastr.error("Allowed to upload logo with png, jpg and jpeg extensions only!", "Error");
        this.company_logo = '';
        this.$refs.logo.value=null;
      }
    },
    removeCompanyLogo(){
      this.company_logo_url = null;
      this.company_logo = '';
      this.$emit("get-logo-object", this.company_logo, this.company_logo_url);
    }
  }
}
</script>