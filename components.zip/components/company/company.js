import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.css';
import VueMask from '@devindex/vue-mask';
import company from "./company.vue";


const company_app = createApp(company);
company_app.use(FloatingVue);
company_app.use(VueMask);
company_app.component('multiselect', Multiselect);
company_app.mount("#company_app");
