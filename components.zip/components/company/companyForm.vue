<template>
    <div>
        <form @submit.prevent="companyInfoSubmit">
            <fieldset class="fieldset_border" :disabled="is_fieldset_disable == true" :class="{'disabled-fieldset': is_fieldset_disable == true}">
              <company-logo @get-logo-object="getLogoObject" :logo_url="logo"></company-logo>
              <div class="row flex-auto -mx-10 mb12">
                  <div class="col-12 col-md-6 col-lg-6 col-xl-4 col-29-company px10">
                      <div class="form-group" :class="{ 'form-group--error': v$.company_name.$errors.length }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.company_name.$errors.length }" type="text" id="company_name" name="company_name" v-model.trim="v$.company_name.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.company_name.$model }">Company Name</label>
                            <div v-if="v$.company_name.$errors.length > 0">
                                <div class="form-error-text">
                                    {{ v$.company_name.$errors[0].$message }}
                                </div>
                            </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-6 col-xl-4 col-29-company px10">
                      <div class="form-group" :class="{ 'form-group--error': v$.location_nickname.$errors.length }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.location_nickname.$errors.length }" type="text" id="location_nickname" name="location_nickname" v-model.trim="v$.location_nickname.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.location_nickname.$model }">Location Nickname</label>
                            <div v-if="v$.location_nickname.$errors.length > 0">
                                <div class="form-error-text">
                                    {{ v$.location_nickname.$errors[0].$message }}
                                </div>
                            </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-6 col-xl-2 col-20-company px10">
                      <div class="form-group" :class="{ 'form-group--error': v$.phone_no.$errors.length }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.phone_no.$errors.length }" type="text" id="phone_no" name="phone_no" v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent v-model.trim="v$.phone_no.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.phone_no.$model }">Phone Number</label>
                          <div v-if="v$.phone_no.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.phone_no.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-6 col-xl-2 col-20-company px10">
                      <div class="form-group" :class="{ 'form-group--error': v$.fax_no.$errors.length }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.fax_no.$errors.length }" type="text" id="fax_no" name="fax_no" v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent v-model.trim="v$.fax_no.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.fax_no.$model }">Fax Number</label>
                          <div v-if="v$.fax_no.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.fax_no.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-6 col-xl-4 col-37-company px10">
                      <div class="form-group" :class="{ 'form-group--error': v$.address.$errors.length  }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.address.$errors.length }" type="text" id="address" name="address" v-model.trim="v$.address.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.address.$model }">Address</label>
                          <div v-if="v$.address.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.address.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-6 col-xl-2 col-20-company px10">
                      <div class="form-group" :class="{ 'form-group--error': v$.city.$errors.length }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.city.$errors.length }" type="text" id="city" name="city" v-model.trim="v$.city.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.city.$model }">City</label>
                          <div v-if="v$.city.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.city.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-6 col-xl-2 col-20-company px10 company_select">
                      <div class="form-group" :class="{ 'form-group--error': v$.state_id.$errors.length }">
                          <multiselect
                          class="font-style-normal"
                          v-model.trim="state_obj"
                          placeholder=""
                          :options="all_state_list"
                          track-by="id"
                          label="state_name"
                          :multiple="false"
                          :disabled="is_fieldset_disable == true"
                          :close-on-select="true"
                          position="bottom"
                          :showLabels="false"
                          :taggable="false"
                          @update:model-value="onChangeStateOption"
                          :class="{ 'form-error': v$.state_id.$errors.length }"
                          :allowEmpty="false">
                            <template #noResult>
                              <div class="multiselect__noResult text-center">
                                No results found
                              </div>
                            </template>
                          </multiselect>
                          <label class="label label-select" :class="{ 'label-float': (v$.state_id.$model) }">State</label>
                          <div v-if="v$.state_id.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.state_id.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-6 col-xl-2 col-20-company px10">
                      <div class="form-group" :class="{ 'form-group--error': v$.zip_code.$errors.length }">
                          <input class="form-input location-input-box" :class="{ 'form-error': v$.zip_code.$errors.length }" type="text" id="zip_code" name="zip_code" v-mask="'00000'" @click.right.prevent @copy.prevent @paste.prevent v-model.trim="v$.zip_code.$model">
                          <label class="label location-input-label" :class="{ 'label-float': v$.zip_code.$model }">Zip Code</label>
                          <div v-if="v$.zip_code.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.zip_code.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-6 col-xl-2 col-20-company px10 company_select">
                    <div class="form-group" :class="{ 'form-group--error': v$.selected_ce_type.$errors.length }">
                      <multiselect
                        class="font-style-normal"
                        v-model.trim="selected_ce_type"
                        @update:model-value="removeOtherDetail"
                        placeholder=""
                        :options="all_ce_type_list"
                        track-by="id"
                        label="name"
                        :disabled="is_fieldset_disable == true"
                        position="bottom"
                        :showLabels="false"
                        :taggable="false"
                        :class="{ 'form-error': v$.selected_ce_type.$errors.length }"
                        :allowEmpty="true"
                      >
                        <template #noResult>
                          <div class="multiselect__noResult text-center">
                            No results found
                          </div>
                        </template>
                      </multiselect>
                      <label class="label label-select" :class="{ 'label-float': v$.selected_ce_type.$model != null }">Type of Covered Entity</label>
                      <div v-if="v$.selected_ce_type.$errors.length > 0">
                        <div class="form-error-text">
                          {{ v$.selected_ce_type.$errors[0].$message }}
                        </div>
                      </div>
                  </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6 col-xl-2 col-20-company px10"
                  v-if="selected_ce_type != null && selected_ce_type.name == 'Other'"
                >
                  <div
                    class="form-group"
                    :class="{ 'form-group--error': v$.other.$errors.length }"
                  >
                    <input
                      class="form-input location-input-box"
                      :class="{ 'form-error': v$.other.$errors.length }"
                      type="text"
                      id="other"
                      name="other"
                      v-model.trim="v$.other.$model"
                    />
                    <label
                      class="label location-input-label"
                      :class="{ 'label-float': v$.other.$model }"
                      >Other</label
                    >
                    <div v-if="v$.other.$errors.length > 0">
                      <div class="form-error-text">
                        {{ v$.other.$errors[0].$message }}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </fieldset>
            <div class="flex items-center flex-wrap justify-center">
                <button type="submit" class="btn-primary mx5" :disabled="is_submit_btn_disabled" v-if="!is_fieldset_disable" id="btn-edit-company-info">Submit</button>
                <button type="button" class="btn-cancel-outline btn-cancel-mobile mx5" :disabled="is_submit_btn_disabled" v-if="!is_fieldset_disable && company_info_completed == 1" v-on:click="cancelEditcompanyInfo()">Cancel</button>
                <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="mlr-auto" v-if="is_fieldset_disable && !is_submit_btn_disabled">
                    <a v-on:click="enableCompanyForm" class="action-icon-btn action-btn-blueog cursor-pointer mlr-auto" >
                        <img :src="JS_APP_URL +'/images/pencil.svg'" alt="Edit">
                    </a>
                    <template #popper>
                        <div class="text-center">Edit company details</div>
                    </template>
                </VTooltip>
            </div>
        </form>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from 'lodash';
import { useVuelidate } from '@vuelidate/core';
import { required, maxLength, minLength, helpers, requiredIf } from "@vuelidate/validators";
import companyLogo from './companylogo.vue';
import fullPageLoader from '../common/fullPageLoader.vue';
import infoIcon from '../common/icons/infoIcon.vue';
import { checkSpecialChars, checkSpecialCharsForAddress, checkSpecialCharsForAddressErrorMessage, checkSpecialCharsErrorMessage } from "../common/customValidation";
export default {
  props: {
    pass_selected_location_id:{
        type: Number,
        default: () => {}
    },
  },
  data() {
    return {
        JS_APP_URL: JS_APP_URL,
        APP_ENV: APP_ENV,
        location_id: '',
        company_name:'',
        location_nickname:'',
        location_nickname_from_data:'',
        address:'',
        city:'',
        zip_code:'',
        phone_no:'',
        fax_no:'',
        logo:'',
        state_id: 0,
        company_information:{},
        is_full_page_loader_shown: false,
        logo_object:{},
        all_state_list: [],
        state_obj: {},
        is_fieldset_disable: true,
        company_info_completed: '',
        is_submit_btn_disabled: false,
        check_hco_available_timer: null,
        updated_location_nickname_object: {},
        checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
        first_time_company_added: false,
        user_locations_number: 0,
        checkSpecialCharsForAddressErrorMessage: checkSpecialCharsForAddressErrorMessage,
        all_ce_type_list: [],
        selected_ce_type: null,
        other: null,
        AUTH_USER: AUTH_USER,
    };
  },
  components: {
    companyLogo,
    fullPageLoader,
    infoIcon
  },
  emits: ["get-updated-location-nickname-object"],
  setup: () => ({ v$: useVuelidate() }),
   validations() {
        return {
            company_name: {
                required: helpers.withMessage("Please enter a company name", required),
                maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            },
            location_nickname: {
                required: helpers.withMessage("Please enter a location nickname", required),
                maxLength: helpers.withMessage(" Max 100 characters allowed", maxLength(100)),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
                isUnique: helpers.withMessage("Location name must be unique.", helpers.withAsync(async (value) => {
                    if (!value) return true;
                    if (!this.v$.location_nickname.required) return true;
                    this.is_submit_btn_disabled = true;
                    let check_promise = new Promise((resolve, reject) => {
                        if (this.check_oso_available_timer) {
                            clearTimeout(this.check_oso_available_timer);
                            this.check_oso_available_timer = null;
                        }
                        this.check_oso_available_timer = setTimeout(() => {
                            return fetch(JS_APP_URL + `/company/check-unique-location-nickname-by-user/${value}/${this.location_id}`)
                                .then((response) => {
                                    if (response.ok) {
                                        resolve(response.text());
                                    } else {
                                        resolve(new Error("error"));
                                    }
                                },
                                    (error) => {
                                        resolve(new Error("error"));
                                    }
                                );
                        }, 500);
                    });
                    let response = await check_promise;
                    this.is_submit_btn_disabled = false;
                    return Boolean(response == "available" ? false : true);
                })
                ),
            },
            phone_no: {
                required: helpers.withMessage("Please enter a phone number", required),
                minLength: helpers.withMessage("Please enter a valid phone number", minLength(12)),
                maxLength: helpers.withMessage("Please enter a valid phone number", maxLength(12)),
            },
            fax_no: {
                minLength: helpers.withMessage("Please enter a valid fax number", minLength(12)),
                maxLength: helpers.withMessage("Please enter a valid fax number", maxLength(12)),
            },
            address: {
                required: helpers.withMessage("Please enter an address", required),
                checkSpecialCharsForAddress: helpers.withMessage(checkSpecialCharsForAddressErrorMessage, checkSpecialCharsForAddress),
                maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
            },
            city: {
                required: helpers.withMessage("Please enter a city", required),
                checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
                maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
            },
            zip_code: {
                required: helpers.withMessage("Please enter a zip code", required),
                minLength: helpers.withMessage("Please enter a valid zip code", minLength(5)),
                maxLength: helpers.withMessage("Please enter a valid zip code", maxLength(5)),
            },
            state_id: {
                required: helpers.withMessage("Please select a state", required),
            },
            selected_ce_type: {
              required: helpers.withMessage(
                "Please select covered entity type",
                required
              ),
            },
            other: {
              required: helpers.withMessage(
                "Please enter other detail",
                requiredIf(() => {
                  return (
                    this.selected_ce_type != null &&
                    this.selected_ce_type.name == "Other"
                  );
                })
              ),
              maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
              checkSpecialChars: helpers.withMessage(
                checkSpecialCharsErrorMessage,
                checkSpecialChars
              ),
            },
        }
    },
  mounted() {
    this.loadStateData();
    this.loadCETypeList();
  },
  watch: {
      pass_selected_location_id(newVal, oldVal){
        this.is_fieldset_disable = true,
        this.is_submit_btn_disabled = false,
        this.loadCompanyInfo(newVal);
      },
      logo_object(newVal, oldVal){},
  },
  methods:{
    async loadStateData(){
      try{
        const [request1, request2] = await Promise.all([
           this.loadStateList(),
        ]);
        await this.loadCompanyInfo(this.pass_selected_location_id);
      }
      catch(err){

      }
    },
    loadCompanyInfo(selected_location_id){
        this.is_full_page_loader_shown = true;
        this.v$.$reset();
        axios
        .get(JS_APP_URL + "/company/get-company-by-location-id/"+selected_location_id)
        .then((response) =>
        {
            if(response["data"]["status"] == "Success") {
                if(response["data"]["data"]){
                    this.company_information = response["data"]["data"];
                    this.location_id = this.company_information.id,
                    this.logo = this.company_information.logo;
                    this.company_name = this.company_information.company_name;
                    this.location_nickname = this.company_information.location_nickname;
                    this.location_nickname_from_data = this.company_information.location_nickname;
                    this.phone_no = this.company_information.phone_no;
                    this.fax_no = (this.company_information.fax_no == null)?'':this.company_information.fax_no;
                    this.address = this.company_information.address;
                    this.city = this.company_information.city;
                    this.state_id = this.company_information.state_id;
                    this.zip_code = this.company_information.zip_code;
                    this.company_info_completed = this.company_information.company_module_completed_count;
                    this.state_obj = this.company_information.state;
                    this.first_time_company_added = this.company_information.first_time_compnay_addedd
                    this.selected_ce_type = this.company_information.covered_entity_type;
                    this.other = this.company_information.other;
                    this.logo_object = {};
                    if(this.company_info_completed === 1){
                        this.is_fieldset_disable = true;
                    } else {
                        this.is_fieldset_disable = false;
                    }
                    this.user_locations_number = this.company_information.user_locations_number;
                } else {
                    window.location = JS_APP_URL + "/dashboard";
                }
            }else{
                window.location = JS_APP_URL + "/dashboard";
            }
        })
        .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
            }
        })
        .then(() => {
            setTimeout(() => {
                this.is_full_page_loader_shown = false;
            }, 500);
        });
    },
    async companyInfoSubmit(){
        this.v$.$touch();
        const is_valid = !this.v$.$invalid;
        if (is_valid) {
            NProgress.start();
            this.is_submit_btn_disabled = true;
            var formData = new FormData();
            if(this.logo_object.name){
                formData.append("logo", this.logo_object);
            }
            formData.append("location_id", this.location_id);
            formData.append("company_name", this.company_name);
            formData.append("location_nickname", this.location_nickname);
            formData.append("address", this.address);
            formData.append("city", this.city);
            formData.append("state_id", this.state_id);
            formData.append("zip_code", this.zip_code);
            formData.append("phone_no", this.phone_no);
            formData.append("fax_no", this.fax_no);
            formData.append("logo_url", this.logo);
            formData.append("ce_type_id", this.selected_ce_type.id);
            if(this.other != null) {
              formData.append("other", this.other);
            }       
            this.is_fieldset_disable = true;          
            axios
            .post(JS_APP_URL + "/company/edit-company", formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            })
            .then((response) => {
                if (response["data"]["status"] == "Error") {
                    if(response["data"]['data'].length > 0){
                        toastr.error(response["data"]['data'].join('</br>'), "Error");
                    }else{
                        toastr.error(response["data"]["message"], "Error");
                    }
                } else {
                    if(this.location_nickname_from_data!=this.location_nickname){
                        this.location_nickname_from_data = this.location_nickname;
                        this.updated_location_nickname_object = {
                            'id' : this.location_id,
                            'location_nickname': this.location_nickname
                        }
                        this.$emit("get-updated-location-nickname-object", this.updated_location_nickname_object);
                    }
                    this.company_info_completed = 1;
                    this.logo = response["data"]["data"];
                    if(APP_ENV == 'production') {
                        setTimeout(() => {
                            var metadata = {
                                first_time_company_added: this.first_time_company_added,
                                location_id: this.location_id,
                                location_nickname: this.location_nickname,
                                user_locations_number: this.user_locations_number
                            };
                            if(AUTH_USER.is_sra_user == 0) {
                              Intercom('trackEvent', 'company-status', metadata);
                            }
                        }, 200);
                    }
                    toastr.success(response["data"]["message"], "Success");
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                   window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
                this.logo_object = {};
                NProgress.done();
                this.is_submit_btn_disabled = false;
            });
        }
    },
    loadStateList(){
        axios
        .get(JS_APP_URL + "/general/get-state-list")
        .then((response) =>
        {
            if(response["data"]["status"] == "Success") {
                this.all_state_list = response["data"]["data"];
            }
        })
        .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
            }
        })
        .then(() => {
        });
    },
    onChangeStateOption(){
      if(_.isNull(this.state_obj) == false){
        this.state_id = this.state_obj.id;
      }else{
         this.state_id = null;
      }
    },
    getLogoObject(logo_object, logo){
        this.logo_object = logo_object;
        this.logo = logo;
    },
    enableCompanyForm(){
        this.is_fieldset_disable = false;
    },
    cancelEditcompanyInfo(){
        this.is_fieldset_disable = true;
        this.loadCompanyInfo(this.pass_selected_location_id);
    },
    
    loadCETypeList() {
        axios
          .get(JS_APP_URL + "/company/covered-entity-types")
          .then((response) => {
            if (response["data"]["status"] == "Success") {
              this.all_ce_type_list = response["data"]["data"];
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {});
      },

      removeOtherDetail() {
        this.other = null
      }
  },
};
 </script>
