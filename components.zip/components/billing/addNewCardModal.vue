<template>
  <div>
    <Teleport to="body">
      <transition name="modal">
        <div class="modal-mask modal-scrollable">
          <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
              <button v-if="!disable_addnewcard_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
              </button>
              <h2
                class="
                  font-24 font_semibold
                  blueog--text
                  line-normal
                  mb30
                  text-center
                "
              >
                Add New Card
              </h2>
              <div class="modal-body">
                <form @submit.prevent="addNewCardSubmit" class="add-card-detail-form mlr-auto" id="addNewCardForm">
                  <div class="row flex-auto -mx-10">
                    <div class="col-12 col-md-12 col-lg-12 col-xl-12 px10 mb25">
                        <div class="form-group mb-0" :class="{ 'form-group--error': v$.card_name.$error }">
                          <input
                            class="form-input"
                            :class="{ 'form-error': v$.card_name.$error }"
                            id="card_name"
                            name="card_name"
                            v-model.trim="v$.card_name.$model"
                            type="text"
                          />
                          <label class="label" :class="{ 'label-float': v$.card_name.$model }">Name on Card</label
                          >
                          <div v-if="v$.card_name.$errors.length > 0">
                            <div class="form-error-text">
                              {{ v$.card_name.$errors[0].$message }}
                            </div>
                          </div>
                        </div>
                      </div>
                  </div>
                  <div class="card_elements_container">
                      <div class="row flex-auto -mx-10">
                          <div class="col-12 col-md-12 col-lg-12 col-xl-12 px10 mb25">
                          <div class="form-group mb-0">
                              <div id="card-number" class="input empty"></div>
                              <label class="label">Card Number</label>
                          </div>
                          </div>
                      </div>
                      <div class="row flex-auto -mx-10">
                          <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10 mb25">
                          <div class="form-group mb-0">
                              <div id="card-expiration" class="input empty"></div>
                              <label class="label">Card Expiration</label>
                          </div>
                          </div>
                          <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10 mb25">
                          <div class="form-group mb-0">
                              <div id="card-cvc" class="input empty"></div>
                              <label class="label">CVV Code</label>
                          </div>
                          </div>
                      </div>
                  </div> 
                  <div class="text-center mb20">
                    <button
                      :disabled="disable_addnewcard_btn"
                      type="submit"
                      class="btn-primary mlr-auto"
                    >
                      <span>SUBMIT</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </transition>
    </Teleport>
    <div class="modal-backdrop"></div>
</div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from "@vuelidate/core";
import { required, maxLength, numeric, helpers } from "@vuelidate/validators";
import closeIcon from '../common/icons/closeIcon.vue';
import infoIcon from "../common/icons/infoIcon.vue";
import {checkSpecialChars, checkSpecialCharsErrorMessage}  from "../common/customValidation";

export default {
  props: {
    setup_intent_client_secret: {
      type: String,
      default: () => ''
    },
    stripe_payment_method: {
      type: Object,
      default: () => {}
    },
  },
  emits: ["close-model","update-stripe-payment-method"],
  data() {
    return {
      card_name: "",
      cardNumber: {},
      cardExpiry: {},
      cardCvc: {},
      disable_addnewcard_btn: false,
      JS_APP_URL: JS_APP_URL,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
      stripe_elements: {}
    };
  },
  components:{
    closeIcon,
    infoIcon
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      card_name: {
        required: helpers.withMessage("Please enter a card holder name", required),
        maxLength: helpers.withMessage("Max 50 characters allowed", maxLength(50)),
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars)
      },
    }
    return validationArray;
  },
  mounted() {
    this.stripeInit();
    this.initStripeElements();
  },
  methods: {
    stripeInit(){
      this.stripe_elements = stripe.elements({
            fonts: [
                {
                family: 'Proxima-Nova-L',
                src: 'url(https://hipaace.abyde.com/stripe_elements_fonts_2541896938763007482152019.php)'
                },
            ]
      });
    },
    initStripeElements(){
      var card_el_inputs = document.querySelectorAll('.card_elements_container .input');
      Array.prototype.forEach.call(card_el_inputs, (input) => {
        input.classList.add('form-input')
        input.addEventListener('focus', () => {
          input.classList.add('focused');
          input.querySelector('.label').classList.add('label-float');
        });
        input.addEventListener('blur', () => {
          input.classList.remove('focused');
          input.querySelector('.label').classList.remove('label-float');
        });
        input.addEventListener('keyup', () => {
          if (input.value.length === 0) {
            input.classList.add('empty');
          } else {
            input.classList.remove('empty');
          }
        });
      });
      var StripeElementStyles = {
        base: {
          color: '#495057',
          fontWeight: 400,
          fontFamily: 'Proxima-Nova-L',
          fontSize: '14px',
          fontSmoothing: 'antialiased',
          '::placeholder': {
            color: '#495057',
          },
          ':-webkit-autofill': {
            color: '#495057',
          },
        },
        invalid: {
          color: '#495057',
          '::placeholder': {
            color: '#FFCCA5',
          },
        },
      };
      var StripeElementClasses = {
        focus: 'focused',
        empty: 'empty',
        invalid: 'invalid',
      };
      this.cardNumber = this.stripe_elements.create('cardNumber', {
        style: StripeElementStyles,
        classes: StripeElementClasses,
        placeholder: '',
      });
      this.cardNumber.mount('#card-number');
      this.cardExpiry = this.stripe_elements.create('cardExpiry', {
        style: StripeElementStyles,
        classes: StripeElementClasses,
        placeholder: '',
      });
      this.cardExpiry.mount('#card-expiration');
      this.cardCvc = this.stripe_elements.create('cardCvc', {
        style: StripeElementStyles,
        classes: StripeElementClasses,
        placeholder: '',
      });
      this.cardCvc.mount('#card-cvc');
    },
    async addNewCardSubmit(){
      this.v$.$touch();
      const is_valid = await this.v$.$validate();
      if (is_valid) {
        var is_valid_Card_details = true;
        var card_el_inputs = document.querySelectorAll('.card_elements_container .input');
        Array.prototype.forEach.call(card_el_inputs, (input) => {
          if(input.classList.contains('empty')){
            is_valid_Card_details = false;
          }
        });
        if(is_valid_Card_details == false){
          toastr.error('Please enter valid card details', 'Error!');
          return false;
        }
        NProgress.start();
        this.disable_addnewcard_btn = true;
        stripe.confirmCardSetup(
          this.setup_intent_client_secret, {
          payment_method: {
              card: this.cardNumber,
              billing_details: {
                name: this.card_name
              },
            },
          }
          ).then((result) => {
            if (result.error) {
              NProgress.done();
              this.disable_addnewcard_btn = false;
              toastr.error(result.error.message, 'Error!')
            } else {
                this.$emit("update-stripe-payment-method", result.setupIntent);               
                axios
                .post(JS_APP_URL + "/billing/add-new-payment-method", {
                    payment_method_id: result.setupIntent.payment_method,
                    payment_method_type: 'card'
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if(response["data"]['data'].length > 0){
                            toastr.error(response["data"]['data'].join('</br>'), "Error");
                        }else{
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        toastr.success(response["data"]["message"], "Success");
                        setTimeout(() => {
                            this.$emit("close-model", false, 'yes');
                        }, 100);
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";    
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.disable_addnewcard_btn = false;
                });
            }
        });       
      }
    },
    closeModal() {
      this.$emit("close-model", false);
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.disable_addnewcard_btn) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  },
  beforeDestroy(){
    this.cardNumber.destroy();
    this.cardExpiry.destroy();
    this.cardCvc.destroy();
  }
};
</script>
