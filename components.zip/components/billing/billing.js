import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import moment from 'moment'
import InfiniteLoading from "v3-infinite-loading";
import billing from "./billing.vue";
import VueMask from '@devindex/vue-mask';

const billing_app = createApp(billing);
billing_app.use(VueMask);
billing_app.config.globalProperties.$filters = {
    formatDate(value) {
        if (value) {
            return moment.utc(String(value)).local().format('MM/DD/YYYY')
        }
    }
};
billing_app.use(FloatingVue);
billing_app.component('multiselect', Multiselect);
billing_app.component('InfiniteLoading', InfiniteLoading);
billing_app.mount("#billing_app");