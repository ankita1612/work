<template>
  <div>
    <header-after-login></header-after-login>
    <div class="container pt40 pb60">
      <h1 class="
          location-dashbaord-title
          text-center
          font-28 font_semibold
          blueog--text
          line-normal mb30
        ">
        Billing
      </h1>
      <div class="payment-info-block px14 py16 light mb50">
        <h4 class="font-22 font_semibold blueog--text mb12">Payment Information</h4>
        <div class="row flex-auto -mx-10" v-if="payment_method_data">
          <div class="col-12 col-md-7 col-lg-5 col-xl-5 px10 mb-sm-20 bank-card-column">
            <div class="bank-card cc-waves">
              <i class="fa fa-globe globe"></i>
              <div v-if="payment_method_data.type == 'bank_account'" class="bank_icon"></div>
              <div v-if="payment_method_data.type == 'card'" :class="payment_method_data.brand_class"></div>
              <div v-if="payment_method_data.type == 'card'" class="chip"></div>
              <div class="card-info">
                <p v-if="payment_method_data.type == 'bank_account'" v-html="payment_method_data.account_holder_name"></p>
                <p class="no mb8">XXXX  XXXX  XXXX  <span>{{payment_method_data.last4}}</span></p> 
                <div class="flex justify-between items-center">
                  <p v-if="payment_method_data.type == 'card'" :title="payment_method_data.name" class="name flex-auto">{{payment_method_data.name}}</p>
                  <p v-if="payment_method_data.type == 'bank_account'" :title="payment_method_data.bank_name" class="name flex-auto">{{payment_method_data.bank_name}}</p>
                  <p v-if="payment_method_data.type == 'card'" class="exp-date pt1"><span>Exp Date</span>: <span>{{payment_method_data.exp_month}}</span> / <span>{{payment_method_data.exp_year}}</span></p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-md-5 col-lg-7 col-xl-7 px10 self-center">
            <div class="mb10">
              <button
                type="button"
                class="btn-blue-outline"
                v-on:click="addNewCardToggle()"
                >
                Add new card
              </button>
            </div>
            <div>
              <button
                type="button"
                class="btn-blue-outline"
                v-on:click="LinkBankAccount()"
                >
                LINK NEW BANK ACCOUNT
              </button>
              <p class="font_normal font-13 font-italic mt10 blue--text">By clicking "Link New Bank Account" you agree to authorize payments pursuant to <a target="_blank" class="green--text" href="https://stripe.com/en-in/legal/ach-payments/authorization">these terms.</a></p>
              <p class="font_normal font-13 font-italic mt10 blue--text">By adding your card/bank, you allow Abyde to charge you for future payments in accordance with their terms. You can always cancel your subscription.</p>
            </div>              
          </div>
        </div>
      </div>

      <h4 class="font-22 font_semibold blueog--text mb12 pl15">Invoices</h4>
      <div>
        <div class="user-detail-card py8 px15 light mb6" v-for="(invoice, index) in invoice_list" v-bind:key="index">
          <div class="row flex-auto -mx-10 items-center">
            <div class="col-12 col-md-4 col-lg-6 col-xl-7 px10 mb-sm-10">
              <div class="font-16 font_semibold gray2--text word-break">
                #{{invoice.id}}
              </div>
            </div>
            <div class="col-12 col-md-2 col-lg-2 col-xl-2 px10 text-center mb-sm-10">
              <div class="font-12 font_semibold word-break" :class="(invoice.payment_status == 'paid')?'green--text':(invoice.payment_status == 'not_paid')?'red2--text':'yellow--text'">{{invoice.payment_status.toUpperCase().replace(/_/g, ' ')}}</div>
            </div> 
            <div class="col-12 col-md-2 col-lg-2 col-xl-1 px10 text-center mb-sm-10">
              <div class="font-12 font_semibold blueog--text word-break">{{ $filters.formatDate(invoice.created_at) }}</div>
            </div> 
            <div class="col-12 col-md-4 col-lg-2 col-xl-2 px10 text-right">
              <button class="btn-blue-outline btn-left-padding btn-left-white" v-on:click="downloadInvoice(invoice.id)">
                <div class="next-arrow-icon pdf-icon"> <pdf-icon></pdf-icon></div> <span>DOWNLOAD</span>
              </button>
            </div>                        
          </div>
        </div>
				<div v-if="!is_full_page_loader_shown && invoice_list.length === 0" class="">
					<div class="user-detail-text font-14 gray_checkmark--text text-center">
						<no-data-icon></no-data-icon>
						<div class="font-14 text-center blueog--text">No invoice(s) available.</div>
					</div>
				</div>
			</div>
      <InfiniteLoading @infinite="getInvoiceList" />
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    <add-new-card-modal v-if="is_add_new_card_modal_shown"  @close-model="addNewCardToggle" :setup_intent_client_secret="setup_intent_client_secret" :stripe_payment_method="stripe_payment_method" @update-stripe-payment-method="updateStripePaymentMethod" />
  </div>
</template>

<script>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../common/fullPageLoader.vue";
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import _ from "lodash";
import pdfIcon from "../common/icons/pdfIcon.vue";
import noDataIcon from "../common/icons/noDataIcon.vue";
import addNewCardModal from "./addNewCardModal.vue";

export default {
  data() {
    return {
      user_data: {},
      stripe_payment_method: {},
      setup_intent_client_secret: {},
      JS_APP_URL: JS_APP_URL,
      is_full_page_loader_shown: false,
      is_add_new_card_modal_shown: false,
      payment_method_data: '',
      is_list_loading: false,
      invoice_list: [],
      per_page_records: 10,
      current_page: 0,
      next_offset: null,
      call_ajax: 1,
    };
  },
  components: {
    fullPageLoader,
    headerAfterLogin,
    pdfIcon,
    noDataIcon,
    addNewCardModal
  },
  mounted() {
    this.getPaymentDetails();  
    this.initStripeSetupIntent();
    this.getInvoiceList();
  },
  methods: {
    initStripeSetupIntent(calling_type = ''){
      this.is_full_page_loader_shown = true;
      axios
          .get(JS_APP_URL + "/billing/get-stripe-setup-intent")
          .then((response) =>  {
            if (response["data"]["status"] == "Success") {
              this.setup_intent_client_secret = response["data"]["data"]['setup_intent_client_secret'];
              this.user_data = response["data"]["data"]['user_data'];
              if(calling_type == 'bank'){
                this.addNewBank();
              }
              if(calling_type == 'card'){
                this.is_add_new_card_modal_shown = true;
              }
            }else{
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            setTimeout(() => {
              this.is_full_page_loader_shown = false;
            }, 100);
          });
    },
    updateStripePaymentMethod(stripe_payment_method){
      this.stripe_payment_method = stripe_payment_method;
    },
    getInvoiceList(){
      if (this.is_list_loading == false && (this.next_offset !=null || this.current_page == 0) ) {
        this.call_ajax = 0;
        this.is_list_loading = true;	
        this.is_full_page_loader_shown = true;
        axios
          .post(JS_APP_URL + "/billing/get-invoice-list", {
            per_page: this.per_page_records,
            next_offset: this.next_offset
          })
          .then((response) => {
            if (response["data"]["status"] == "Success") {
              var invoice_data = response["data"]["data"];
              this.invoice_list.push(...invoice_data.list);
              this.next_offset = invoice_data.next_offset
              this.current_page++;
              this.is_list_loading = false;
            }else{
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";    
            }
          })
          .then(() => {				
            setTimeout(() => {
              this.is_full_page_loader_shown = false;
              this.call_ajax = 1;
            }, 100);
          });
      }
    },
    getPaymentDetails(){
      this.is_full_page_loader_shown = true;
      axios
      .get(JS_APP_URL + "/billing/get-payment_method")
      .then((response) => {
        if (response["data"]["status"] == "Success") {
          this.payment_method_data = response["data"]["data"];
          if(this.payment_method_data.type  == 'card'){
            if(response["data"]["data"]['brand'] == 'American Express' || response["data"]["data"]['brand'] == 'amex'){
              this.payment_method_data.brand_class = 'AmericanExpress';
            }
            else if(response["data"]["data"]['brand'] == 'Diners Club' || response["data"]["data"]['brand'] == 'diners'){
              this.payment_method_data.brand_class = 'DinersClub';
            }
            else if(response["data"]["data"]['brand'] == 'Discover' || response["data"]["data"]['brand'] == 'discover'){
              this.payment_method_data.brand_class = 'Discover';
            }
            else if(response["data"]["data"]['brand'] == 'JCB' || response["data"]["data"]['brand'] == 'jcb'){
              this.payment_method_data.brand_class = 'JCB';
            }
            else if(response["data"]["data"]['brand'] == 'MasterCard' || response["data"]["data"]['brand'] == 'mastercard'){
              this.payment_method_data.brand_class = 'MasterCard';
            }
            else if(response["data"]["data"]['brand'] == 'UnionPay' || response["data"]["data"]['brand'] == 'unionpay'){
              this.payment_method_data.brand_class = 'Unknown';
            }
            else if(response["data"]["data"]['brand'] == 'Visa' || response["data"]["data"]['brand'] == 'visa'){
              this.payment_method_data.brand_class = 'Visa';
            }else{
              this.payment_method_data.brand_class = 'Unknown';
            }
          }
        }else{
          if(response["data"]['data'].length > 0){
            toastr.error(response["data"]['data'].join('</br>'), "Error");
          }else{
            toastr.error(response["data"]["message"], "Error");
          }
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";    
        }
      })
      .then(() => {
        this.is_full_page_loader_shown = false;
      });
    },
    downloadInvoice(invoice_id){
      this.is_full_page_loader_shown = true;
      axios
          .post(JS_APP_URL + "/billing/download-invoice", {
            invoice_id: invoice_id
          })
          .then((response) => {
            if (response["data"]["status"] == "Success") {
              var link = document.createElement("a");
              link.download = response["data"]['data']['file_name'];
              link.href = response["data"]['data']['invoice_url'];
              link.target = '_blank';
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";    
            }
          })
          .then(() => {            
            setTimeout(() => {
              this.is_full_page_loader_shown = false;
            }, 100);
          });
    },
    addNewCardToggle(status = true, is_refresh_payment_method = 'no'){
      if(status == true){
        if(!_.isEmpty(this.stripe_payment_method) && this.stripe_payment_method.status == 'succeeded'){
          this.initStripeSetupIntent('card');
        }else{
          this.is_add_new_card_modal_shown = status;
        }
      }else{
        this.is_add_new_card_modal_shown = status;
      }
      if(is_refresh_payment_method == 'yes'){
        this.getPaymentDetails();
      }
    },
    LinkBankAccount(){
      if(!_.isEmpty(this.stripe_payment_method) && this.stripe_payment_method.status == 'succeeded'){
        this.initStripeSetupIntent('bank');
      }else{
        this.addNewBank();
      }
    },
    addNewBank(){
      this.is_full_page_loader_shown = true; 
      stripe.collectBankAccountForSetup({
        clientSecret: this.setup_intent_client_secret,
        params: {
        payment_method_type: 'us_bank_account',
        payment_method_data: {
            billing_details: {
            name: this.user_data.first_name + ' ' + this.user_data.last_name,
            email: this.user_data.email,
            },
        },
        },
        expand: ['payment_method'],
    })
      .then(({setupIntent, error}) =>{
        if (error) {
            toastr.error(error.message, 'Error!')
            this.is_full_page_loader_shown = false;
        } else if (setupIntent.status === 'requires_payment_method') {
            toastr.error('Failed to link your bank account. Please try again!', 'Error!')
            this.is_full_page_loader_shown = false;
        } else if (setupIntent.status === 'requires_confirmation') {
            stripe.confirmUsBankAccountSetup(this.setup_intent_client_secret)
            .then(({setupIntent, error})=>{
                if (error) {
                    toastr.error(error.message, 'Error!')
                    this.is_full_page_loader_shown = false;
                } else if (setupIntent.status === "requires_payment_method") {
                    toastr.error('Failed to link your bank account. Please try again!', 'Error!')
                    this.is_full_page_loader_shown = false;
                } else if (setupIntent.status === "succeeded") {
                    this.stripe_payment_method = setupIntent;
                    NProgress.start();
                    this.is_full_page_loader_shown = true;
                    axios
                    .post(JS_APP_URL + "/billing/add-new-payment-method", {
                        payment_method_id: setupIntent.payment_method,
                        payment_method_type: 'bank'
                    })
                    .then((response) => {
                        if (response["data"]["status"] == "Error") {
                            if(response["data"]['data'].length > 0){
                                toastr.error(response["data"]['data'].join('</br>'), "Error");
                            }else{
                                toastr.error(response["data"]["message"], "Error");
                            }
                        } else {
                            toastr.success(response["data"]["message"], "Success");
                            setTimeout(() => {
                                this.getPaymentDetails();
                            }, 100);
                        }
                    })
                    .catch((error) => {
                        toastr.error(error.response["data"]["message"], "Error");
                        this.is_full_page_loader_shown = false;
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        NProgress.done();
                        this.is_full_page_loader_shown = false;
                    });
                } else if (setupIntent.next_action?.type === "verify_with_microdeposits") {
                    console.log('THHIS SHOULD NOT HAPPEN AS WE HAVE NOT ENABLED MICRO DEPOSIT VERIFICATRION');
                    this.is_full_page_loader_shown = false;
                }
            });
        }
      });
    }
  },
};
</script>
