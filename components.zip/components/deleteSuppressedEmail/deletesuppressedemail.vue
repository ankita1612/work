<template>
  <div class="flex flex-col flex-auto min-fill-height">
    <header-before-login></header-before-login>
    <div class="flex-auto blueog">
      <div class="container fill-height text-center flex items-center justify-center">
        <div class="row">
          <div class="col-12 col-md-12">
            <div class="sign-in-box white mt50 mb50 pt40 pb40 px38">
              <div class="text-center sign-in-icon mlr-auto pb34 mb15">
                <img
                  :src="JS_APP_URL + '/images/abyde_a.svg'"
                  alt=""
                  title=""
                />
              </div>
              <div>
                <h2
                  class="font-25 font_semibold blueog--text mb20 mt20 text-center lh-1"
                >
                  Remove Email Form Suppression List
                </h2>
                <form @submit.prevent="submit">
                  <div
                    class="form-group"
                    :class="{ 'form-group--error': v$.email.$error }"
                  >
                    <input
                      class="form-input sign-in-input"
                      :class="{ 'form-error': v$.email.$error }"
                      id="email"
                      name="email"
                      v-model.trim="v$.email.$model"
                      type="text"
                    />
                    <label
                      class="label"
                      :class="{ 'label-float': v$.email.$model }"
                      >Email Address</label
                    >
                    <div v-if="v$.email.$errors.length > 0">
                      <div class="form-error-text">
                        {{ v$.email.$errors[0].$message }}
                      </div>
                    </div>
                  </div>
                  <div class="text-center pt10">
                    <button
                      :disabled="disable_signin_btn"
                      type="submit"
                      class="btn-primary mlr-auto"
                    >
                      <span>Submit</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <footer-before-login :is_reseller="'no'"></footer-before-login>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from "@vuelidate/core";
import { required, email, helpers, requiredIf, minLength, maxLength } from "@vuelidate/validators";
import headerBeforeLogin from "../common/includes/headerBeforeLogin.vue";
import footerBeforeLogin from "../common/includes/footerBeforeLogin.vue";
export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      email: "",
      disable_signin_btn: false,
    };
  },
  setup: () => ({ v$: useVuelidate() }),
  components: {
    headerBeforeLogin,
    footerBeforeLogin,
  },

  validations() {
    var validationsArr = {
      email: {
        required: helpers.withMessage("Please enter an email", required),
        email: helpers.withMessage("Please enter a valid email", email),
        maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
      },
    };
    return validationsArr;
  },
  mounted() {},

  watch: {},

  computed: {},

  methods: {
    async submit() {
      this.v$.$touch();
      const is_valid = await this.v$.$validate();
      if (is_valid) {
        NProgress.start();
        this.disable_signin_btn = true;
        axios
          .post(JS_APP_URL + "/remove-suppressed-email", {
            email: this.email,
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if (response["data"]["data"].length > 0) {
                toastr.error(response["data"]["data"].join("</br>"), "Error");
              } else {
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              this.v$.$reset();
              this.email = ''
              toastr.success(response["data"]["message"], "Success");
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
          })
          .then(() => {
            NProgress.done();
            this.disable_signin_btn = false;
          });
      }
    },
  },
};
</script>
