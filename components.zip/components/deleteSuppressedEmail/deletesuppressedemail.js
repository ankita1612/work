import { createApp } from "vue";
import FloatingVue from "floating-vue";
import "floating-vue/dist/style.css";
import deletesuppressedemail from "./deletesuppressedemail.vue";

const app = createApp(deletesuppressedemail);
app.use(FloatingVue);
app.mount("#delete_suppressed_email_app");
