import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import InfiniteLoading from "v3-infinite-loading";
import hipaagapassessment from './hipaagapassessment.vue';

const hipaa_gap_assessment_app = createApp(hipaagapassessment);
hipaa_gap_assessment_app.use(FloatingVue);
hipaa_gap_assessment_app.component('multiselect', Multiselect);
hipaa_gap_assessment_app.component('InfiniteLoading', InfiniteLoading);
hipaa_gap_assessment_app.mount("#hipaa_gap_assessment_app");