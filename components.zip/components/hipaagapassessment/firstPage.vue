<template>
    <div class="hipaa-grade-wrapper text-center py40">
        <h1 class="font-40 white--text font_semibold mb30">
            Is my practice HIPAA compliant?
        </h1>
        <h4 class="font-22 white--text font_light mb5">
            Curious if your practice is HIPAA compliant? 
        </h4>
        <h4 class="font-22 white--text font_light mb40">
            Utilize our FREE Gap Assessment tool to quickly determine if your practice is compliant with HIPAA's critical regulations.
        </h4>
        <div class="text-center mb30">
            <img
              :src="JS_APP_URL + '/images/HIPAA_Score_Questionmarks.png'"
              alt="HIPAA_Score_Questionmarks"
              class="HIPAA_doctor_thumb mx-auto"
            />
        </div>
        <div class="text-center mb12">
            <button
              type="submit"
              class="btn btn-white mlr-auto btn-width-136"
              @click="startButton"
            >
              Start
            </button>
        </div>
        <p class="font-16 white--text font-italic font_light">
            Approximately 5 minutes to complete
        </p>
        <quiz-start-modal 
            v-if="is_quiz_modal_show" 
            @close-model="startQuiz"
        />
    </div>
</template>

<script>
import quizStartModal from './quizStartModal.vue'

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            is_quiz_modal_show: false,
        }
    },
    emits: ['step-change'],
    components: {
        quizStartModal
    },
    methods: {
        startButton() {
            if(this.is_quiz_modal_show == false) {
                this.is_quiz_modal_show = true;
            }
        },
        startQuiz(is_start_quiz = false) {
            if(is_start_quiz == true) {
                this.$emit('step-change', 1);
            }else{
                this.is_quiz_modal_show = false
            }
        }
    }
}
</script>