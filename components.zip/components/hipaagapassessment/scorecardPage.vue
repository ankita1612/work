<template>
  <div class="hipaa-grade-meter">
    <div
      class="
        hipaa-grade-meter-header
        blueog
        py4
        row
        flex-auto
        justify-center
        items-center
      "
    >
      <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10">
        <h2>
          <span class="font-20 font-italic white--text"
            >Prepared specially for:</span
          >
          <span class="font-20 font_bold white--text">{{
            scorecard_info.visitor.company_name
          }}</span>
        </h2>
      </div>
      <div class="col-12 col-md-6 col-lg-6 col-xl-6 px10 text-right">
        <img
          :src="JS_APP_URL + '/images/Abyde_TM_white_logo.svg'"
          alt=""
          class="report_header_logo ml-auto"
        />
      </div>
    </div>
    <div class="py15 px20">
      <div class="row flex-auto items-center -mx-10 mb25">
        <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10">
          <h4 class="font-20 font_semibold gray2--text text-center mb20">
            Your HIPAA Grade
          </h4>
          <div id="gchart" class="text-center">
            <span
              class="visitorGradeLarge-label"
              :class="[
                scorecard_info.grade_scale.grade != ''
                  ? scorecard_info.grade_scale.grade + '_grade_label'
                  : '',
              ]"
            >
              {{ scorecard_info.grade_scale.grade }}</span
            >
          </div>
        </div>
        <div
          class="col-12 col-md-12 col-lg-6 col-xl-6 px10"
          v-if="Object.keys(scorecard_info.grade_scale).length > 0"
        >
          <div class="hipaa-grade-meter-box">
            <div
              class="
                hipaa-grade-meter-box-header
                font-20 font_semibold
                white--text
                blueog
                py8
                px10
              "
            >
              {{ scorecard_info.grade_scale.section_header }}
            </div>
            <div class="hipaa-grade-meter-body py10 px15">
              <p
                class="font-16 dark--text"
                v-html="scorecard_info.grade_scale.what_it_means"
              ></p>
            </div>
          </div>
        </div>
      </div>
      <div class="mb25" v-if="area_of_concern.length > 0">
        <div class="hipaa-grade-meter-box">
          <div
            class="
              hipaa-grade-meter-box-header
              font-20 font_semibold
              white--text
              blueog
              py8
              px10
            "
          >
            Areas of Concern
          </div>
          <div class="hipaa-grade-meter-body py10 px15">
            <h3 class="font-16 font_semibold dark--text mb6">
              Here are a few things to watch for based on your responses:
            </h3>
            <ul class="hipaa-grade-list font-16 dark--text pl30">
              <li v-for="(concern, index) in area_of_concern" :key="index">
                <div>{{ concern.answer.area_of_concern }}</div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="mb25">
        <div class="hipaa-grade-meter-box">
          <div
            class="
              hipaa-grade-meter-box-header
              font-20 font_semibold
              white--text
              blueog
              py8
              px10
            "
          >
            Next Steps
          </div>
          <div class="hipaa-grade-meter-body py10 px15">
            <h3 class="font-16 font_semibold dark--text mb6">
              We would be pumped to hear from you and make it easy to get
              started.
            </h3>
            <p class="font-16 dark--text">
              Do your results need a second set of eyes? We've got HIPAA experts
              for that!
              <a
                target="_blank"
                class="blueog--text cursor-pointer"
                :href="JS_APP_URL + '/hipaa-gap-assessment/selectstate'"
                >Click here</a
              >
              to schedule a 15-minute educational session with one of our team
              members.
            </p>
            <div class="my20 text-center">
              <button
                type="button"
                class="btn btn-blue btn-blueog mlr-auto btn-width-136"
                @click="showMap"
              >
                SCHEDULE YOUR REVIEW >>
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="text-center mb20">
        <button
          type="button"
          class="btn btn-blue mlr-auto btn-width-136"
          :disabled="is_download_btn_disalbed"
          @click="downloadScorecard"
        >
          Download Scorecard
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import * as d3 from "d3";
import * as chart from "./chart/chart.js";
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from "lodash";
import NProgress from "nprogress";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      attempted_answers: [],
      grade_scale: {},
      is_download_btn_disalbed:false
    };
  },

  props: {
    scorecard_info: Object,
  },

  mounted() {
    // generate chart
    const svg = d3
      .select("#gchart")
      .append("svg")
      .attr("class", "c-chart-gauge");
    const gaugeChart = new chart.GaugeChart({
      svg: svg,
      outerRadius: 180,
      innerRadius: 120,
    });
    gaugeChart.render();
    gaugeChart.animateTo(this.scorecard_info.grade_scale.chart_value); // 0 to 1
  },

  computed: {
    area_of_concern() {
      return _.filter(
        this.scorecard_info.attempted_answers,
        (vl) =>
          vl.answer.area_of_concern != null ||
          vl.answer.area_of_concern != undefined
      );
    },
  },

  methods: {
    showMap() {
      window.open(JS_APP_URL + '/hipaa-gap-assessment/selectstate');
    },

    downloadScorecard() {
      if (this.scorecard_info.download_url) {
        this.is_download_btn_disalbed = true
        NProgress.start();
        const filePath = this.scorecard_info.download_url.split("/");
        const fileName = filePath[filePath.length - 1];
        axios({
          url: this.scorecard_info.download_url,
          method: "GET",
          responseType: "blob",
        }).then((response) => {
          var fileURL = window.URL.createObjectURL(new Blob([response.data]));
          var fileLink = document.createElement("a");
          fileLink.href = fileURL;
          fileLink.setAttribute("download", 'Abyde HIPAA Scorecard for '+this.scorecard_info.visitor.company_name+'.pdf');
          document.body.appendChild(fileLink);
          fileLink.click();
        }).then(()=>{
          NProgress.done();
          this.is_download_btn_disalbed = false
        });
      }
    },
  },
};
</script>
