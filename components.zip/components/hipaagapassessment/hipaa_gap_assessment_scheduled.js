import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import InfiniteLoading from "v3-infinite-loading";
import hipaa_gap_assessment_scheduled from './hipaa_gap_assessment_scheduled.vue';

const gap_assessment_app = createApp(hipaa_gap_assessment_scheduled);
gap_assessment_app.use(FloatingVue);
gap_assessment_app.component('multiselect', Multiselect);
gap_assessment_app.component('InfiniteLoading', InfiniteLoading);
gap_assessment_app.mount("#gap_assessment_app");