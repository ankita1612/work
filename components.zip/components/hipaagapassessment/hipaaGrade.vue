<template>
  <div class="hipaa-map-block hipaa-grade-form">
    <div class="row flex-auto justify-center items-center -mx-10">
      <div class="col-12 col-md-12 col-lg-6 col-xl-7 px10"></div>
      <div class="col-12 col-md-12 col-lg-6 col-xl-5 px10">
        <div class="hipaa-score-form">
          <div
            class="
              hipaa-score-form-header
              blueog
              font-24
              text-center
              white--text
              font_semibold
              py6
            "
          >
            Tell us where to send your results!
          </div>
          <div class="hipaa-score-form-body py10 px15">
            <h4 class="gray2--text font-italic font-18 font_semibold mb6">
              Just one more step to get your report...
            </h4>
            <p class="font-13 gray2--text mb10">
              Who should we send your results to?
            </p>
            <form @submit.prevent="getScoreCard">
              <input type="hidden" id="gclid_field" name="gclid_field" value="">
              <div
                class="input-group mb10 relative"
                :class="{ 'form-group--error': v$.company_name.$errors.length }"
              >
                <input
                  type="text"
                  v-model.trim="v$.company_name.$model"
                  placeholder="Company Name"
                  class="form-control fill-width pl10"
                  :class="{
                    'form-error-border-bottom': v$.company_name.$errors.length,
                  }"
                />
                <div v-if="v$.company_name.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.company_name.$errors[0].$message }}
                  </div>
                </div>
              </div>
              <div
                class="input-group mb10 relative"
                :class="{ 'form-group--error': v$.contact_name.$errors.length }"
              >
                <input
                  type="text"
                  v-model.trim="v$.contact_name.$model"
                  placeholder="Contact Name"
                  class="form-control fill-width pl10"
                  :class="{
                    'form-error-border-bottom': v$.contact_name.$errors.length,
                  }"
                />
                <div v-if="v$.contact_name.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.contact_name.$errors[0].$message }}
                  </div>
                </div>
              </div>
              <div
                class="form-group gap-form-email relative"
                :class="{ 'form-group--error': v$.email.$errors.length }"
              >
                <input
                  type="email"
                  v-model.trim="v$.email.$model"
                  placeholder="Email Address"
                  class="form-control fill-width pl10"
                  :class="{ 'form-error-border-bottom': v$.email.$errors.length }"
                />
                <div v-if="v$.email.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.email.$errors[0].$message }}
                  </div>
                </div>
              </div>
              <div class="mb10 relative gap-assessment-multiselect" :class="{ 'form-group--error': v$.state_id.$errors.length }">
                <multiselect
                class="font-style-normal"
                v-model.trim="state_id"
                :options="all_state_list"
                track-by="id"
                label="state_name"
                :multiple="false"
                :close-on-select="true"
                position="bottom"
                :showLabels="false"
                :taggable="false"
                :allowEmpty="true"
                :clear-on-select="true">
                  <template #noResult>
                      <div class="multiselect__noResult text-center">No results found</div>
                  </template>
                  <template #noOptions>
                      <div class="multiselect__noOptions text-center">No data available</div>
                  </template>
                </multiselect>
                <label class="label label-select dropdown-label-blue" :class="{ 'label-float': (v$.state_id.$model) }">State</label>
                <div v-if="v$.state_id.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.state_id.$errors[0].$message }}
                  </div>
                </div>
              </div>
              
              
              <p class="font-13 gray2--text mb15">
                We hate spam too, and respect your privacy. We will NEVER share
                your email address and will use it only to communicate regarding
                your HIPAA analysis.
              </p>
              <button
                type="submit"
                class="btn btn-primary mlr-auto btn-width-136 mb10"
                :disabled="is_submit_btn_disabled"
              >
                SEND REPORT!
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, email, maxLength, helpers } from "@vuelidate/validators";
import { checkSpecialChars, checkSpecialCharsErrorMessage } from "../common/customValidation";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      email: "",
      contact_name: "",
      company_name: "",
      state_id:'',
      all_state_list:[],
      is_submit_btn_disabled: false,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
      APP_ENV: APP_ENV
    };
  },
  props: {
    quiz_answer_info: {},
    partner_info: Object,
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      company_name: { 
        required: helpers.withMessage("Please enter a company name", required), 
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars), 
        maxLength: helpers.withMessage("Max 50 characters allowed", maxLength(50)) 
      },
      contact_name: { 
        required: helpers.withMessage("Please enter a contact name", required), 
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars), 
        maxLength: helpers.withMessage("Max 50 characters allowed", maxLength(50)) 
      },
      state_id: { 
        required: helpers.withMessage("Please select a state", required) 
      },
      email: {
        required: helpers.withMessage("Please enter an email", required),
        email: helpers.withMessage("Please enter a valid email", email),
        maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100))
      },
    }
    return validationArray;
  },
  mounted() {
    this.loadStateList();
  },
  methods: {
    getScoreCard() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        this.is_submit_btn_disabled = true;
        NProgress.start();
        let contact_info = {
          company_name: this.company_name,
          contact_name: this.contact_name,
          email: this.email,
          state_id: this.state_id.id
        };
        
        if(APP_ENV == 'production') {
          const form = document.createElement('form');
          form.action = 'https://go.abyde.com/l/1071712/2024-12-09/dhmq9b'; 
          form.method = 'POST';
          form.target = '_blank'; 

          for (let key in contact_info) {
            if(key == 'state_id'){
              const input = document.createElement('input');
              input.type = 'hidden';
              input.name = 'state_name';
              input.value = this.state_id.state_code;
              form.appendChild(input);
            }else{
              const input = document.createElement('input');
              input.type = 'hidden';
              input.name = key;
              input.value = contact_info[key];
              form.appendChild(input);  
            }
            
          }
          document.body.appendChild(form);
          form.submit();
          document.body.removeChild(form);
        }

        if (this.partner_info.id) {
          contact_info.partner_id = this.partner_info.id;
        }
        axios
          .post(JS_APP_URL + "/hipaa-gap-assessment/save-answers", {
            contact_info: contact_info,
            quiz_info: this.quiz_answer_info,
          })
          .then((response) => {
            if (response["data"]["status"] == "Success") {
              let visitor_id = response["data"]["data"]["id"];
              axios
                .post(
                  JS_APP_URL + "/hipaa-gap-assessment/generate-visitor-scorecard",
                  {
                    visitor_id: visitor_id,
                  }
                )
                .then((response) => {
                  toastr.success(response["data"]["message"], "Success");
                  setTimeout(() => { 
                      NProgress.done();
                      this.is_submit_btn_disabled = false;
                      window.location = JS_APP_URL + "/login";
                   }, 1500);
                  
                })
                .catch((error) => {
                  toastr.error(error.response["data"]["message"], "Error");
                  if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                  }
                });
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
          });
      }
    },
    loadStateList(){
        axios
        .get(JS_APP_URL + "/hipaa-gap-assessment/get-state-list")
        .then((response) =>
        {
            if(response["data"]["status"] == "Success") {
                this.all_state_list = response["data"]["data"];
            }
        })
        .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
            }
        })
        .then(() => {
        });
    },
    
  },
};
</script>
