<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div
                class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                "
              >
                <h4 class="mb-sm-0 font-size-18">
                  Add New Security Risk Analysis
                </h4>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <question-item
                    :question_data="question_data"
                    q_key="0"
                    a_key="0"
                    :question_category_list="question_category_list"
                    :question_law_section_list="question_law_section_list"
                    :months_list="months_list"
                    :ongoing_question_list="ongoing_question_list"
                    :validation_status="validation_status"
                    ref="questionItem"
                  >
                  </question-item>
                  <div class="ms-4 mt-4">
                    <button
                      type="button"
                      @click="backToView()"
                      class="btn btn-danger w-md"
                    >
                      CANCEL
                    </button>
                    &nbsp;
                    &nbsp;
                    <button
                      :disabled="is_add_btn_disabled"
                      type="submit"
                      @click="addSraQuestionAnswer"
                      class="btn btn-primary w-md"
                    >
                      ADD
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import NProgress from "nprogress";
import _ from "lodash";
import fullPageLoader from "../../common/fullPageLoader.vue";
import questionItem from "./questionItem.vue";
export default {
  data() {
    return {
      validation_status: {},
      question_category_list: [],
      months_list: [],
      ongoing_question_list: [],
      question_data: {
        question_unique_id: this.generateuniqueID("que"),
        question_code: "",
        question: "",
        question_category_id: "",
        question_answer_layout: "radio",
        display_order: "",
        parent_question_id: "",
        parent_answer_id: "",
        parent_answer_index: "",
        is_remind: false,
        remind_months: "",
        ongoing_question_id: "",
        answers: [],
        question_law_section_id: "",
      },
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      is_full_page_loader_shown: false,
      is_add_btn_disabled: false,
      question_law_section_list: [],
    };
  },
  watch: {},
  components: {
    fullPageLoader,
    questionItem,
  },
  
  computed: {},
  
  mounted() {
    this.getSraCategoryList();
    this.getSraMonthsList();
    this.getOnGoingQuestionList();
    this.getSraLawSectionList();
  },
  methods: {
    generateuniqueID(arg_type) {
      return arg_type + "_" + new Date().valueOf();
    },

    addSraQuestionAnswer(e) {
      var is_form_valid = true;
      this.validation_status = this.$refs.questionItem.setValidationStatus();
      const key = Object.keys(this.validation_status)[0];
      let validateObj =  this.validation_status[key];
      validateObj.$touch();
      if (!validateObj.$dirty || (validateObj.$dirty && validateObj.$error) ){
        is_form_valid = false;
      }
      if (is_form_valid) {
        NProgress.start();
        // this.is_add_btn_disabled = true;
        axios
          .post(JS_APP_URL + "/pkO0OA17otP61RwETtNn/security-risk-analysis/add-security-risk-analysis", {
            question: [this.question_data],
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              toastr.success(response["data"]["message"], "Success");
              setTimeout(() => {
                window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/security-risk-analysis/view";
              }, 1000);
            }
          })
          .catch((error)=> {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
            }
          })
          .then(()=> {
            NProgress.done();
            // this.is_add_btn_disabled = false;
          });
      }
    },

    getSraCategoryList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL + "/pkO0OA17otP61RwETtNn/security-risk-analysis/get-sra-category-list"
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){8
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.question_category_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },

    getSraLawSectionList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL + "/pkO0OA17otP61RwETtNn/security-risk-analysis/get-sra-law-section-list"
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.question_law_section_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    getSraMonthsList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/security-risk-analysis/get-sra-months-list")
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.months_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    getOnGoingQuestionList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL +
            "/pkO0OA17otP61RwETtNn/security-risk-analysis/get-ongoing-question-list"
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.ongoing_question_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },

    backToView() {
      window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/security-risk-analysis/view";
    },
  },
};
</script>
