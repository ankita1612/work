<template>
  <div>
    <Teleport to="body">
      <transition name="modal">
        <div class="modal-mask modal-scrollable">
          <div class="modal-wrapper animate__animated animate__zoomIn modal-xl">
            <div class="modal-container">
              <div
                v-on:click="$emit('close-modal')"
                class="cursor-pointer modal-close"
              >
                <close-icon></close-icon>
              </div>
              <div class="row m-0">
                <div class="col-12">
                  <div class="text-start">
                    <h5 class="border-bottom border-light mb-3 pb-2">
                      View Security Risk Analysis Question Answer
                    </h5>
                    <table class="table table-bordered" v-if="get_view_sra_question_answer_details.question_answer_layout != 'radio'">
                      <thead>
                        <tr>
                          <th>Education</th>
                          <th>Remind</th>
                          <th>Month</th>
                          <th>Ongoing Code</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>{{ get_view_sra_question_answer_details.remind_option != null ? get_view_sra_question_answer_details.remind_option.education : '' }}</td>
                          <td>{{ get_view_sra_question_answer_details.remind_option ? 'Yes' : 'No' }}</td>
                          <td>{{ get_view_sra_question_answer_details.remind_option != null ? get_view_sra_question_answer_details.remind_option.remind_month : '' }}</td>
                          <td>{{ get_view_sra_question_answer_details.remind_option != null ? get_view_sra_question_answer_details.remind_option.ongoing_code.question_code : '' }}</td>
                        </tr>
                      </tbody>
                    </table>
                    <table class="table table-bordered" v-if="get_view_sra_question_answer_details.question_answer_layout != 'text'">
                      <thead>
                        <tr>
                          <th>Answer</th>
                          <th>Answer Code</th>
                          <th>Display Order</th>
                          <th v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">Score</th>
                          <th v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">Likelihood</th>
                          <th v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">Impact</th>
                          <th v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">Education</th>
                          <th v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">Remind</th>
                          <th v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">Month</th>
                          <th v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">Ongoing Code</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr v-for="(get_view_sra_question_answer_detail,index) in get_view_sra_question_answer_details.risk_analysis_question_answer_options" :key="index">
  
                          <td>{{ get_view_sra_question_answer_detail.answer }}</td>
                          <td>{{ get_view_sra_question_answer_detail.answer_code }}</td>
                          <td>{{ get_view_sra_question_answer_detail.display_order }}</td>
                          <td v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">{{ get_view_sra_question_answer_detail.score }}</td>
                          <td v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">{{ get_view_sra_question_answer_detail.likelihood }}</td>
                          <td v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">{{ get_view_sra_question_answer_detail.impact }}</td>
                          <td v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">{{ get_view_sra_question_answer_detail.remind_option != null ? get_view_sra_question_answer_detail.remind_option.education : '' }}</td>
                          <td v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">{{ get_view_sra_question_answer_detail.remind_option != null && get_view_sra_question_answer_detail.remind_option.remind_month  ? 'Yes' : 'No' }}</td>
                          <td v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">{{ get_view_sra_question_answer_detail.remind_option != null ? get_view_sra_question_answer_detail.remind_option.remind_month : '' }}</td>
                          <td v-if="get_view_sra_question_answer_details.question_answer_layout == 'radio'">{{ get_view_sra_question_answer_detail.remind_option != null && get_view_sra_question_answer_detail.remind_option.ongoing_code != null ? get_view_sra_question_answer_detail.remind_option.ongoing_code.question_code : '' }}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </transition>
    </Teleport>
    <div class="modal-backdrop"></div>
  </div>
  </template>
  <script scoped>
  import axios from "axios";
  import NProgress from "nprogress";
  import closeIcon from "../../common/icons/closeIcon.vue";
  import toastr from "toastr";
  import "toastr/toastr.scss";
  
  export default {
    data() {
      return {};
    },
     props: {
      get_view_sra_question_answer_details: {
        type: Object,
      },
    },
    emits: ["close-modal"],
    components: { closeIcon },
    mounted() {},
    methods: {},
    created() {
      // document.body.classList.add('modal-open');
      document.addEventListener("keydown", (e) => {
        if (e.keyCode == 27) {
          this.$emit("close-modal");
        }
      });
    },
    destroyed(){
      // document.body.classList.remove('modal-open');
    }
  };
  </script>
  
  <style>
  </style>
  