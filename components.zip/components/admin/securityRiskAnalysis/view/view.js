import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import securityRiskAnalysisView from "./view.vue";
import app from "../../common/includes/App.vue"
const view_app = createApp({
    template: `
    <app>
    <security-risk-analysis-view></security-risk-analysis-view>
    </app>
    `,
    components: {
        app,
        'security-risk-analysis-view': securityRiskAnalysisView,
    }
});
view_app.use(useVuelidate);
view_app.mount("#view_app");