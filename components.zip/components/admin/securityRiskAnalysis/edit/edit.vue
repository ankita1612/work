<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div
                class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                "
              >
                <h4 class="mb-sm-0 font-size-18">
                  Update Security Risk Analysis
                </h4>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <div>
                    <question-edit-item
                      :question_data="question_data"
                      q_key="0"
                      a_key="0"
                      :question_category_list="question_category_list"
                      :months_list="months_list"
                      :ongoing_question_list="ongoing_question_list"
                      :validation_status="validation_status"
                      @get-sra-question-details="getSraQuestionDetails"
                      ref="questionEditItem"
                    >
                    </question-edit-item>
                  </div>
                  <div class="ms-4 mt-4">
                    <button
                      type="button"
                      @click="backToView()"
                      class="btn btn-danger w-md"
                    >
                      CANCEL
                    </button>
                    &nbsp;
                    &nbsp;
                    <button
                      :disabled="is_edit_btn_disabled"
                      type="submit"
                      class="btn btn-primary w-md"
                      @click="updateSraQuestion"
                    >
                      UPDATE
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import NProgress from "nprogress";
import _ from "lodash";
import fullPageLoader from "../../common/fullPageLoader.vue";
import questionEditItem from "./questionEditItem.vue";
export default {
  data() {
    return {
      validation_status: {},
      question_category_list: [],
      months_list: [],
      ongoing_question_list: [],
      question_data: {},
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      SRA_QUESTION_ID: SRA_QUESTION_ID,
      is_full_page_loader_shown: false,
      is_edit_btn_disabled: false,
    };
  },
  watch: {},
  components: {
    fullPageLoader,
    questionEditItem,
  },

  computed: {},

  mounted() {
    this.getSraCategoryList();
    this.getSraMonthsList();
    this.getOnGoingQuestionList();
    this.getSraQuestionDetails();
  },
  methods: {
    generateuniqueID(arg_type) {
      return arg_type + "_" + new Date().valueOf();
    },
    getSraQuestionDetails() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL +
            "/pkO0OA17otP61RwETtNn/security-risk-analysis/get-sra-question-edit-detail/" +
            SRA_QUESTION_ID
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {           
            this.question_data = response.data.data;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    updateSraQuestion() {
     var is_form_valid = true;
     this.validation_status = this.$refs.questionItem.setValidationStatus();
      const key = Object.keys(this.validation_status)[0];
      let validateObj =  this.validation_status[key];
      validateObj.$touch();
      if (!validateObj.$dirty || (validateObj.$dirty && validateObj.$error) ){
        is_form_valid = false;
      }
      
      if (is_form_valid) {
        NProgress.start();
        this.is_edit_btn_disabled = true;
        axios
          .post(
            JS_APP_URL +
              "/pkO0OA17otP61RwETtNn/security-risk-analysis/update-sra-question",
            {

             question: [this.question_data],
            }
          )
          .then((response)=> {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              setTimeout(() => {
                window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/security-risk-analysis/view";
              }, 500);
              toastr.success(response["data"]["message"], "Success");
            }
          })
          .catch((error)=> {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
            }
          })
          .then(() => {
            this.is_edit_btn_disabled = false;
            NProgress.done();
          });
      }
    },
    getSraCategoryList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL + "/pkO0OA17otP61RwETtNn/security-risk-analysis/get-sra-category-list"
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.question_category_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    getSraMonthsList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/security-risk-analysis/get-sra-months-list")
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.months_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    getOnGoingQuestionList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL +
            "/pkO0OA17otP61RwETtNn/security-risk-analysis/get-ongoing-question-list"
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.ongoing_question_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    backToView() {
      window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/security-risk-analysis/view";
    },
  },
};
</script>
