import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import securityRiskAnalysisEdit from "./edit.vue";
import app from "../../common/includes/App.vue"
const edit_app = createApp({
    template: `
    <app>
    <security-risk-analysis-edit></security-risk-analysis-edit>
    </app>
    `,
    components: {
        app,
        'security-risk-analysis-edit': securityRiskAnalysisEdit,
    }
});
edit_app.use(useVuelidate);
edit_app.mount("#edit_app");