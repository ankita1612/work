<template>
  <div class="question-component">
    <div class="form-group">
      <div class="row m-0">
        <label
          v-if="question_data.parent_question_id == ''"
          class="col-lg-1 col-form-label text-start"
          >Question</label
        >
        <div
          class="col-lg-2"
          :class="{
            'form-group--error': v$.question_data.question_code.$error,
          }"
        >
          <input
            type="text"
            class="form-control"
            placeholder="Code"
            v-model.trim="v$.question_data.question_code.$model"
          />
          <div v-if="v$.question_data.question_code.$errors.length > 0">
            <div class="form-error-text">
                {{ v$.question_data.question_code.$errors[0].$message }}
            </div>
          </div>
        </div>

        <div
          class="col-lg-8"
          :class="{ 'form-group--error': v$.question_data.question.$error }"
        >
          <input
            type="text"
            class="form-control"
            placeholder="Question"
            v-model.trim="v$.question_data.question.$model"
          />
          <div v-if="v$.question_data.question.$errors.length > 0">
            <div class="form-error-text">
                {{ v$.question_data.question.$errors[0].$message }}
            </div>
          </div>
        </div>

        <div
          class="col-lg-2 mt-2"
          v-if="question_data.parent_question_id != ''"
        >
          <a
            href="javascript:void(0)"
            class=""
            @click="removeSubQuestion(q_key, a_key, question_data.question_id)"
          >
            <img
              title="Remove Sub Question"
              height="24px"
              class="ms-2"
              :src="JS_APP_URL + '/images/admin_remove_icon.png'"
            />
          </a>
        </div>
      </div>
      <div class="row m-0 pt-3">
        <label
          class="col-lg-1 col-form-label text-end"
          v-if="question_data.parent_question_id == ''"
        ></label>
        <div
          class="col-lg-4"
          :class="{
            'form-group--error': v$.question_data.question_category_id.$error,
          }"
        >
          <!-- category dorpdown -->
          <select
            class="form-select"
            v-model.trim="v$.question_data.question_category_id.$model"
          >
            <option value="" selected>Select Category</option>
            <option
              v-for="(category, index) in question_category_list"
              :key="index"
              :value="category.id"
            >
              {{ category.category_title }}
            </option>
          </select>
          <div v-if="v$.question_data.question_category_id.$errors.length > 0">
            <div class="form-error-text">
                {{ v$.question_data.question_category_id.$errors[0].$message }}
            </div>
          </div>
        </div>
        <div
          class="col-lg-3"
          :class="{
            'form-group--error': v$.question_data.display_order.$error,
          }"
        >
          <input
            type="text"
            class="form-control"
            placeholder="Display Order"
            v-model.trim="v$.question_data.display_order.$model"
          />
          <div v-if="v$.question_data.display_order.$errors.length > 0">
            <div class="form-error-text">
                {{ v$.question_data.display_order.$errors[0].$message }}
            </div>
          </div>
        </div>
      </div>
      <div
        class="row m-0 pt-3"
        v-if="
          question_data.question_answer_layout == 'text' ||
          question_data.question_answer_layout == 'checkbox'
        "
      >
        <label
          class="col-lg-1 col-form-label text-end"
          v-if="question_data.parent_question_id == ''"
        ></label>
        <div class="col-lg-1">
          <div class="form-check form-check-success mb-3">
            <input
              class="form-check-input"
              type="checkbox"
              :id="'Remind_' + question_data.question_unique_id"
              v-model.trim="question_data.is_remind"
              @change="is_remind_clear_question"
            />
            <label
              class="form-check-label"
              :for="'Remind_' + question_data.question_unique_id"
            >
              Remind
            </label>
          </div>
        </div>
        <div class="col-lg-6 mb-2">
          <div class="row" v-if="question_data.is_remind">
            <div
              class="col-lg-6"
              :class="{
                'form-group--error': v$.question_data.remind_months.$error,
              }"
            >
              <!-- month dorpdown -->
              <select
                class="form-select"
                v-model.trim="v$.question_data.remind_months.$model"
              >
                <option value="" selected>Select Months</option>
                <option
                  v-for="(months, index) in months_list"
                  :key="index"
                  :value="months.month_id"
                >
                  {{ months.month_name }}
                </option>
              </select>
              <div v-if="v$.question_data.remind_months.$errors.length > 0">
                <div class="form-error-text">
                    {{ v$.question_data.remind_months.$errors[0].$message }}
                </div>
              </div>
            </div>
            <div
              class="col-lg-6"
              :class="{
                'form-group--error':
                  v$.question_data.ongoing_question_id.$error,
              }"
            >
              <!-- og que dorpdown -->
              <select
                class="form-select"
                v-model.trim="v$.question_data.ongoing_question_id.$model"
              >
                <option value="" selected>Select Ongoing Question</option>
                <option
                  v-for="(ongoing_questions, index) in ongoing_question_list"
                  :key="index"
                  :value="ongoing_questions.id"
                >
                  {{ ongoing_questions.question_code }}
                </option>
              </select>
              <div v-if="v$.question_data.ongoing_question_id.$errors.length > 0">
                <div class="form-error-text">
                    {{ v$.question_data.ongoing_question_id.$errors[0].$message }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="form-group">
      <div class="row m-0 mt-3">
        <label
          class="col-lg-1 col-form-label text-start pt-0"
          v-if="question_data.parent_question_id == ''"
          >Layout</label
        >
        <div class="col-lg-1">
          <div class="form-check form-radio-primary mb-3">
            <input
              class="form-check-input"
              type="radio"
              value="radio"
              :id="'radio_' + question_data.question_unique_id"
              v-model.trim="question_data.question_answer_layout"
              @change="
                layoutChnaged('radio_' + question_data.question_unique_id)
              "
            />
            <label
              class="form-check-label"
              :for="'radio_' + question_data.question_unique_id"
            >
              Radio
            </label>
          </div>
        </div>
        <div class="col-lg-1">
          <div class="form-check form-radio-primary mb-3">
            <input
              class="form-check-input"
              type="radio"
              value="text"
              :id="'text_' + question_data.question_unique_id"
              v-model.trim="question_data.question_answer_layout"
              @change="
                layoutChnaged('text_' + question_data.question_unique_id)
              "
            />
            <label
              class="form-check-label"
              :for="'text_' + question_data.question_unique_id"
            >
              Text
            </label>
          </div>
        </div>
        <div class="col-lg-1">
          <div class="form-check form-radio-primary mb-3">
            <input
              class="form-check-input"
              type="radio"
              value="checkbox"
              :id="'checkbox_' + question_data.question_unique_id"
              v-model.trim="question_data.question_answer_layout"
              @change="
                layoutChnaged('checkbox_' + question_data.question_unique_id)
              "
            />
            <label
              class="form-check-label"
              :for="'checkbox_' + question_data.question_unique_id"
            >
              Checkbox
            </label>
          </div>
        </div>
      </div>
    </div>
    <div
      class="form-group"
      v-if="
        question_data.question_answer_layout == 'radio' ||
        question_data.question_answer_layout == 'checkbox'
      "
    >
      <div class="row m-0">
        <label
          class="col-lg-1 col-form-label text-start"
          v-if="question_data.parent_question_id == ''"
          >Answer</label
        >
        <div
          v-bind:class="[
            question_data.parent_question_id != '' ? 'col-lg-12' : 'col-lg-11',
          ]"
        >
          <div class="row">
            <div class="col-lg-12">
              <div class="row m-0">
                <div class="col-lg-4"></div>
                <div class="col-lg-3"></div>
                <div class="col-lg-4 text-end">
                  <a
                    href="javascript:void(0)"
                    @click="addAnswer(question_data.question_unique_id)"
                    class="btn btn-success waves-effect waves-light"
                    >ADD ANSWER</a
                  >
                </div>
                <div class="col-lg-1"></div>
              </div>
              <div
                class="row pt-3 m-0"
                :key="a_key"
                v-for="(ans_obj, a_key) in v$.question_data.answers"
              >
                <div class="row m-0">
                  <div class="col-lg-12">
                    <div class="row">
                      <div
                        class="col-lg-3 mb-2"
                        :class="{
                          'form-group--error': v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].answer_code.length > 0
                        }"
                      >
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Answer Code"
                          v-model.trim="ans_obj.answer_code"
                        />
                        <div v-if="v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].answer_code.length > 0">
                          <div class="form-error-text">{{ v$.question_data.answers.$each.$response.$errors[a_key].answer_code[0].$message}}</div>
                        </div>
                      </div>
                      <div
                        class="mb-2"
                        :class="{
                          'form-group--error': v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].answer.length > 0,
                          'col-lg-2':
                            question_data.question_answer_layout == 'radio',
                          'col-lg-8':
                            question_data.question_answer_layout == 'checkbox',
                        }"
                      >
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Answer"
                          v-model.trim="ans_obj.answer"
                        />
                        <div v-if="v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].answer.length > 0">
                          <div class="form-error-text">{{ v$.question_data.answers.$each.$response.$errors[a_key].answer[0].$message}}</div>
                        </div>
                      </div>
                      <div
                        v-if="question_data.question_answer_layout == 'radio'"
                        class="col-lg-2"
                        :class="{
                          'form-group--error': v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].score.length > 0,
                        }"
                      >
                        <input
                          type="number"
                          min="0"
                          max="10"
                          class="form-control"
                          placeholder="Score"
                          v-model.trim="ans_obj.score"
                        />
                        <div v-if="v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].score.length > 0">
                          <div class="form-error-text">{{ v$.question_data.answers.$each.$response.$errors[a_key].score[0].$message}}</div>
                        </div>
                      </div>
                      <div
                        v-if="question_data.question_answer_layout == 'radio'"
                        class="col-lg-2"
                        :class="{
                          'form-group--error': v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].likelihood.length > 0,
                        }"
                      >
                        <input
                          type="number"
                          min="0"
                          max="10"
                          class="form-control"
                          placeholder="Likelihood"
                          v-model.trim="ans_obj.likelihood"
                        />
                        <div v-if="v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].likelihood.length > 0">
                          <div class="form-error-text">{{ v$.question_data.answers.$each.$response.$errors[a_key].likelihood[0].$message}}</div>
                        </div>
                      </div>
                      <div
                        v-if="question_data.question_answer_layout == 'radio'"
                        class="col-lg-2"
                        :class="{
                          'form-group--error': v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].impact.length > 0,
                        }"
                      >
                        <input
                          type="number"
                          min="0"
                          max="10"
                          class="form-control"
                          placeholder="Impact"
                          v-model.trim="ans_obj.impact"
                        />
                        <div v-if="v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].impact.length > 0">
                          <div class="form-error-text">{{ v$.question_data.answers.$each.$response.$errors[a_key].impact[0].$message}}</div>
                        </div>
                      </div>
                      <div class="col-lg-1 text-left mt-2">
                        <a
                          href="javascript:void(0)"
                          @click="
                            removeAnswer(a_key, ans_obj.answer_id)
                          "
                          v-show="a_key > 0"
                          class=""
                        >
                          <img
                            title="Remove answer"
                            height="24px"
                            class="ml-1"
                            :src="JS_APP_URL + '/images/admin_remove_icon.png'"
                          />
                        </a>
                        <a
                          href="javascript:void(0)"
                          @click="
                            addQuestion(
                              question_data.question_unique_id,
                              ans_obj.answer_unique_id,
                              a_key
                            )
                          "
                          class=""
                        >
                          <img
                            title="Add Sub Question"
                            height="24px"
                            class=""
                            :src="JS_APP_URL + '/images/admin_add_icon.png'"
                          />
                        </a>
                      </div>
                    </div>
                    <div
                      class="row"
                      v-if="question_data.question_answer_layout == 'radio'"
                    >
                      <div class="col-lg-11 pl-2 pe-2">
                        <textarea
                          rows="1"
                          class="form-control"
                          placeholder="Education"
                          v-model.trim="ans_obj.education"
                        ></textarea>
                      </div>
                    </div>
                    <div
                      class="row pt-3"
                      v-if="question_data.question_answer_layout == 'radio'"
                    >
                      <div class="col-lg-1">
                        <div class="form-check form-check-success mb-3">
                          <input
                            class="form-check-input"
                            type="checkbox"
                            :id="'Remind_' + ans_obj.answer_unique_id"
                            v-model.trim="ans_obj.is_remind"
                            @change="is_remind_clear_answer(a_key)"
                          />
                          <label
                            class="form-check-label"
                            :for="'Remind_' + ans_obj.answer_unique_id"
                          >
                            Remind
                          </label>
                        </div>
                      </div>
                      <div class="col-lg-6 mb-2">
                        <div class="row" v-if="ans_obj.is_remind">
                          <div
                            class="col-lg-6"
                            :class="{
                              'form-group--error': v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].remind_months.length > 0,
                            }"
                          >
                            <!-- month dorpdown -->
                            <select
                              class="form-select"
                              v-model.trim="ans_obj.remind_months"
                            >
                              <option value="" selected>Select Months</option>
                              <option
                                v-for="(months, index) in months_list"
                                :key="index"
                                :value="months.month_id"
                              >
                                {{ months.month_name }}
                              </option>
                            </select>
                            <div v-if="v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].remind_months.length > 0">
                              <div class="form-error-text">{{ v$.question_data.answers.$each.$response.$errors[a_key].remind_months[0].$message}}</div>
                            </div>
                          </div>
                          <div
                            class="col-lg-6"
                            :class="{
                              'form-group--error':
                              v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].ongoing_question_id.length > 0,
                            }"
                          >
                            <!-- og que dorpdown -->
                            <select
                              class="form-select"
                              v-model.trim="ans_obj.ongoing_question_id"
                            >
                              <option value="" selected>
                                Select Ongoing Question
                              </option>
                              <option
                                v-for="(
                                  ongoing_questions, index
                                ) in ongoing_question_list"
                                :key="index"
                                :value="ongoing_questions.id"
                              >
                                {{ ongoing_questions.question_code }}
                              </option>
                            </select>
                            <div v-if="v$.question_data.answers.$error && v$.question_data.answers.$each.$response.$errors[a_key].ongoing_question_id.length > 0">
                              <div class="form-error-text">{{ v$.question_data.answers.$each.$response.$errors[a_key].ongoing_question_id[0].$message}}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="row m-0 subquestion_div"
                  :key="sub_key"
                  v-for="(subque_obj, sub_key) in ans_obj.sub_questions"
                >
                  <question-edit-item
                    :question_data="subque_obj"
                    :q_key="sub_key"
                    :a_key="a_key"
                    :question_category_list="question_category_list"
                    :months_list="months_list"
                    :ongoing_question_list="ongoing_question_list"
                    :validation_status="validation_status"
                    ref="questionEditItem"
                  >
                  </question-edit-item>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <delete-question-answer-modal
      v-if="is_delete_modal_shown"
      @close-modal="is_delete_modal_shown = false"
      @question-answer-deleted="questionAnswerDeleted"
      @sra-question-deleted="sraQuestionDeleted"
      :delete_modal_data="delete_modal_data"
    >
    </delete-question-answer-modal>
  </div>
</template>

<script scoped>
import _ from "lodash";
import useVuelidate from "@vuelidate/core";
import {
    required,
    helpers,
    requiredIf,
    integer,
    between
} from "@vuelidate/validators";
import deleteQuestionAnswerModal from "./deleteQuestionAnswerModal.vue";

export default {
  name: "question-edit-item",
  setup: () => ({ v$: useVuelidate() }),
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      is_delete_modal_shown: false,
      delete_modal_data: {},
      previous_selected_question_answer_type: "",
    };
  },

  props: [
    "question_data",
    "q_key",
    "a_key",
    "question_category_list",
    "months_list",
    "ongoing_question_list",
    "validation_status",
  ],
  validations() {
        return {
          question_data:{
            question: {
              required: helpers.withMessage(
                "Please enter a question",
                required
              )
            },
            question_code: {
              required: helpers.withMessage(
                "Please enter a code",
                required
              )
            },
            question_category_id: {
              required: helpers.withMessage(
                "Please select a category",
                required
              )
            },
            display_order: {
              required: helpers.withMessage(
                "Please enter a display order",
                required
              ),
              between: helpers.withMessage(
                "Must be a valid number",
                between(1,1000)
              ),
              integer: helpers.withMessage(
                "Must be a valid integer",
                integer
              )
            },
            remind_months: {
              requiredIf: helpers.withMessage("Please select a month",
                requiredIf(() => {
                  return this.question_data.is_remind
              })),
            },
            ongoing_question_id: {
              requiredIf: helpers.withMessage("Please select an ongoing question",
                requiredIf(() => {
                  return this.question_data.is_remind
              })),
            },
            answers: {
              $each: helpers.forEach({
                answer_code: {
                  required: helpers.withMessage("Please enter an answer code",required),
                  isUnique: helpers.withMessage("Answer codes must be unique. Please try again",((value) => {
                      if (value == "") return true;
                      let avail = this.question_data.answers.filter((ans) => {
                            return ans.answer_code.toLowerCase() === value.toLowerCase()
                      });
                      return (avail.length > 1) ? false : true;
                  })),
                },
                answer : {
                  required : helpers.withMessage("Please enter an answer",required)
                },
                score : {
                  requiredIf: helpers.withMessage("Please enter a score",
                    requiredIf(() => {
                      return this.question_data.question_answer_layout == "radio"
                    })
                  ),
                  between: helpers.withMessage("Must be between 0 to 10", between(1,10)),
                  integer: helpers.withMessage("Must be a valid integer", integer),
                },
                likelihood : {
                  requiredIf: helpers.withMessage("Please enter a likelihood",
                    requiredIf(() => {
                      return this.question_data.question_answer_layout == "radio"
                    })
                  ),
                  between: helpers.withMessage("Must be between 0 to 3", between(1,3)),
                  integer: helpers.withMessage("Must be a valid integer", integer),
                },
                impact : {
                  requiredIf: helpers.withMessage("Please enter a impact",
                    requiredIf(() => {
                      return this.question_data.question_answer_layout == "radio"
                    })
                  ),
                  between: helpers.withMessage("Must be between 0 to 3", between(1,3)),
                  integer: helpers.withMessage("Must be a valid integer", integer),
                },
                remind_months : {
                  requiredIf: helpers.withMessage("Please enter a month",
                    requiredIf((object) => object.is_remind)
                  )
                },
                ongoing_question_id : {
                  requiredIf: helpers.withMessage("Please enter an ongoing question",
                    requiredIf((object) => object.is_remind)
                  )
                },
                
              })
            }
                
          }
        }
  },
  watch: {},
  components: {
    deleteQuestionAnswerModal,
  },
  computed: {},
  mounted() {
    if (
      _.isUndefined(this.question_data.question_id) &&
      (this.question_data.question_answer_layout == "radio" ||
        this.question_data.question_answer_layout == "checkbox")
    ) {
      if (this.question_data.answers.length == 0) {
        this.addAnswer(this.question_data.question_unique_id);
      }
    }
    setTimeout(() => {
      this.validation_status[this.question_data.question_unique_id] = this.v$;
    }, 2000);
    // setTimeout(() => {
    //   this.previous_selected_question_answer_type = this.question_data.question_answer_layout;
    // }, 1500);
  },
  destroyed() {
    delete this.validation_status[this.question_data.question_unique_id];
  },
  methods: {
    setValidationStatus(){
      this.validation_status[this.question_data.question_unique_id] =  this.v$;
      return this.validation_status
    },
    layoutChnaged(id) {
      // const confirmed = document.querySelector(`#${id}`);
      // if (confirm("Are you sure want to change question type?\n\nYou will not be able to recover this information!")) {
      //   this.previous_selected_question_answer_type = this.question_data.question_answer_layout;
        this.question_data.answers = [];
        if (
          this.question_data.question_answer_layout == "radio" ||
          this.question_data.question_answer_layout == "checkbox"
        ) {
          this.addAnswer(this.question_data.que_unique_id);
        }
        this.question_data.is_remind = false;
        this.question_data.remind_months = "";
        this.question_data.ongoing_question_id = "";
      // } else {
      //   confirmed.checked = false;
      //   this.question_data.question_answer_layout = false;
      //   this.question_data.question_answer_layout = this.previous_selected_question_answer_type;
      // }
    },
    generateuniqueID(arg_type) {
      return arg_type + "_" + new Date().valueOf();
    },
    is_remind_clear_question() {
      if (this.question_data.is_remind == false) {
        this.question_data.remind_months = "";
        this.question_data.ongoing_question_id = "";
      }
    },
    is_remind_clear_answer(a_key) {
      if (this.question_data.answers[a_key].is_remind == false) {
        this.question_data.answers[a_key].remind_months = "";
        this.question_data.answers[a_key].ongoing_question_id = "";
      }
    },
    addAnswer(question_unique_id) {
      var answer_obj = {
        answer_unique_id: this.generateuniqueID("ans"),
        question_unique_id: question_unique_id,
        answer_code: "",
        answer: "",
        is_remind: false,
        remind_months: "",
        ongoing_question_id: "",
        score: "",
        likelihood: "",
        impact: "",
        education: "",
        sub_questions: [],
      };
      this.question_data.answers.push(answer_obj);
    },

    removeAnswer(a_key, answer_id) {
      if (answer_id) {
        this.delete_modal_data.delete_modal_selected_id = answer_id;
        this.delete_modal_data.question_answer_type = "answer";
        this.delete_modal_data.a_key = a_key;
        this.is_delete_modal_shown = true;
      } else {
        this.question_data.answers = this.question_data.answers.filter((_, i) => i !== a_key) 
      }
    },

    questionAnswerDeleted() {
      this.question_data.answers = this.question_data.answers.filter((_, i) => i !== this.delete_modal_data.a_key) 
      this.delete_modal_data = {};
      this.is_delete_modal_shown = false;
    },

    addQuestion(que_unique_id, ans_unique_id, a_key) {
      var que_obj = {
        question_unique_id: this.generateuniqueID("que"),
        question_code: "",
        question: "",
        question_category_id: "",
        question_answer_layout: "radio",
        display_order: "",
        parent_question_id: que_unique_id,
        parent_answer_id: ans_unique_id,
        parent_answer_index: a_key,
        is_remind: false,
        remind_months: "",
        ongoing_question_id: "",
        answers: [],
      };
      this.question_data.answers[a_key]["sub_questions"].push(que_obj);
    },

    removeSubQuestion(q_key, a_key, question_id) {
      if (question_id) {
        this.delete_modal_data.delete_modal_selected_id = question_id;
        this.delete_modal_data.question_answer_type = "question";
        this.delete_modal_data.a_key = a_key;
        this.delete_modal_data.q_key = q_key;
        this.is_delete_modal_shown = true;
      } else {
        var parent_ref = this.$parent;
        parent_ref.question_data.answers[a_key]["sub_questions"] = parent_ref.question_data.answers[a_key]["sub_questions"].filter((_, i) => i !== q_key)
      }
    },
    sraQuestionDeleted() {
      var parent_ref = this.$parent;
      parent_ref.question_data.answers[this.delete_modal_data.a_key]["sub_questions"] = parent_ref.question_data.answers[this.delete_modal_data.a_key]["sub_questions"].filter((_, i) => i !== this.delete_modal_data.q_key)
      this.delete_modal_data = {};
      this.is_delete_modal_shown = false;
    },
  },
};
</script>
