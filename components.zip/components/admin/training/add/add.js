import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';

import trainingAdd from "./add.vue";
import app from "../../common/includes/App.vue"
const add_app = createApp({
    template: `
    <app>
    <training-add></training-add>
    </app>
    `,
    components: {
        app,
        'training-add': trainingAdd,
    }
});
add_app.use(useVuelidate);
add_app.component('multiselect', Multiselect);
add_app.use(FloatingVue);
add_app.mount("#add_app");
