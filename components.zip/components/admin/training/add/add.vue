<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div
                class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                "
              >
                <h4 class="mb-sm-0 font-size-18">Add New Training</h4>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <form
                    @submit.prevent="addTraining"
                    enctype="multipart/form-data"
                  >
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.training_code.$error }"
                    >
                      <label
                        for="horizontal-firstname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Training Code</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Training Code"
                          id="horizontal-firstname-input"
                          v-model.trim="v$.training_code.$model"
                        />
                        <div v-if="v$.training_code.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.training_code.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.title.$error }"
                    >
                      <label
                        for="horizontal-firstname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Title</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Title"
                          id="horizontal-firstname-input"
                          v-model.trim="v$.title.$model"
                        />
                        <div v-if="v$.title.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.title.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>                    
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.title_for_list.$error }"
                    >
                      <label
                        for="horizontal-firstname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Title For List</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Title for List"
                          id="horizontal-firstname-input"
                          v-model.trim="v$.title_for_list.$model"
                        />
                        <div class="add-new-training-info-icon">
                          <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                            <div class="cursor-pointer svg-icon-height">
                                <info-icon></info-icon>
                            </div>
                            <template #popper>
                                This name will be shown on the training dashboard .
                            </template>
                          </VTooltip>
                        </div>                       

                        <div v-if="v$.title_for_list.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.title_for_list.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>                    
                    <div class="row mb-4" :class="{ 'form-group--error': v$.title_for_tab.$error }">
                      <label
                        for="horizontal-firstname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Title For Tab</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Title for Tab"
                          id="horizontal-firstname-input"
                          v-model.trim="v$.title_for_tab.$model"                          
                        />    
                        <div class="add-new-training-info-icon">
                          <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                              <div class="cursor-pointer svg-icon-height">
                                  <info-icon></info-icon>
                              </div>
                              <template #popper>
                                  This name will be shown on the training list tab.
                              </template>
                          </VTooltip>
                        </div>   
                        <div v-if="v$.title_for_tab.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.title_for_tab.$errors[0].$message }}
                          </div>
                        </div>                  
                      </div>
                    </div>                    
                    <div class="row mb-4">
                      <label class="col-sm-2 col-form-label text-end"
                        >Parent Training</label
                      >
                      <div class="col-sm-8">
                        <select
                          class="form-select"
                          v-model.trim="parent_training_id"                           
                        >
                          <option value="" selected>
                            Select parent training
                          </option>
                          <option
                            v-for="(
                              parent_training, index
                            ) in parent_training_list"
                            :key="index"
                            :value="parent_training.id"
                            class="fw-bold"                           
                          >
                            {{ parent_training.title }}
                          </option>
                        </select>
                        <div class="add-new-training-info-icon">
                          <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                              <div class="cursor-pointer svg-icon-height">
                                  <info-icon></info-icon>
                              </div>
                              <template #popper>
                                  Select parent training from here.
                              </template>
                          </VTooltip>   
                        </div>                        
                      </div>
                    </div> 
                                       
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.description.$error }"
                    >
                      <label
                        for="horizontal-lastname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Description</label
                      >
                      <div class="col-sm-8">
                        <editor
                          v-model.trim="v$.description.$model"
                          :api-key="TIYMCE_API_KEY"
                          @change="onDescriptionChange"
                          :init="{
                            height: 500,
                            menubar: true,
                            branding: false,
                            resize: false,
                            plugins: [
                              'advlist autolink lists link anchor',
                              'searchreplace',
                              'table paste',
                            ],
                            toolbar:
                              'undo redo | formatselect | bold italic | \
                                          alignleft aligncenter alignright alignjustify | \
                                          bullist numlist | removeformat',
                          }"
                        />
                        <div v-if="v$.description.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.description.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.video_file.$error }"
                    >
                      <label class="col-sm-2 col-form-label text-end"
                        >Video File</label
                      >
                      <div class="col-sm-8">
                        <input
                          accept="video/mp4"
                          class="form-control"
                          type="file"
                          @change="onVideoFileChange"
                        />

                        <div v-if="v$.video_file.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.video_file.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      class="row mb-4"
                      :class="{
                        'form-group--error': v$.video_poster_file.$error,
                      }"
                    >
                      <label class="col-sm-2 col-form-label text-end"
                        >Video Poster File</label
                      >
                      <div class="col-sm-8">
                        <input
                          accept=".jpg, .jpeg, .png"
                          class="form-control"
                          type="file"
                          @change="onVideoPosterFileChange"
                        />

                        <div v-if="v$.video_poster_file.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.video_poster_file.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      class="row mb-4"
                      :class="{
                        'form-group--error': v$.video_caption_file.$error,
                      }"
                    >
                      <label class="col-sm-2 col-form-label text-end"
                        >Video Caption File</label
                      >
                      <div class="col-sm-8">
                        <input
                          class="form-control"
                          accept=".vtt"
                          type="file"
                          @change="onVideoCaptionFileChange"
                        />

                        <div v-if="v$.video_caption_file.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.video_caption_file.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.training_type.$error }"
                    >
                      <label
                        for="horizontal-email-input"
                        class="col-sm-2 col-form-label text-end pt-0"
                        >Training Type</label
                      >
                      <div class="col-sm-8">
                        <input
                          class="form-check-input"
                          type="radio"
                          id="training_type_onetime"
                          name="training_type"
                          value="onetime"
                          v-model.trim="v$.training_type.$model"
                        />
                        <label
                          class="form-check-label"
                          for="training_type_onetime"
                        >
                          &nbsp;One time
                        </label>
                        <div v-if="v$.training_type.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.training_type.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div   
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.who_can_train.$error }"
                    >
                      <label
                        for="horizontal-email-input"
                        class="col-sm-2 col-form-label text-end pt-0"
                        >Who Can Train</label
                      >
                      <div class="col-sm-8">
                        <input
                          class="form-check-input"
                          type="radio"
                          id="who_can_train_hco"
                          name="who_can_train"
                          value="hco"
                          v-model.trim="v$.who_can_train.$model"
                          :disabled="is_hco_disabled"
                        />
                        <label class="form-check-label" for="who_can_train_hco">
                          &nbsp;HCO
                        </label>
                        <input
                          class="form-check-input ms-2"
                          type="radio"
                          id="who_can_train_employee"
                          name="who_can_train"
                          value="employee"
                          v-model.trim="v$.who_can_train.$model"
                          :disabled="is_employee_disabled"
                        />
                        <label
                          class="form-check-label"
                          for="who_can_train_employee"
                        >
                        &nbsp;Employee
                        </label>
                        <div v-if="v$.who_can_train.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.who_can_train.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.trigger_month.$error }"
                    >
                      <label
                        for="horizontal-firstname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Trigger Month</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Trigger Month"
                          id="horizontal-firstname-input"
                          v-model.trim="v$.trigger_month.$model"
                          
                        />
                        <div v-if="v$.trigger_month.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.trigger_month.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.display_order.$error }"
                    >
                      <label
                        for="horizontal-question-input"
                        class="col-sm-2 col-form-label text-end"
                        >Display Order</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Display Order"
                          id="horizontal-question-input"
                          v-model.trim="v$.display_order.$model"
                        />
                        <div v-if="v$.display_order.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.display_order.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row mb-4">
                      <label class="col-sm-2 col-form-label text-end"
                        >Notification Code</label
                      >
                      <div class="col-sm-8">
                        <select
                          class="form-select"
                          v-model.trim="notification_code"                           
                        >
                          <option value="" selected>
                            Select Notification
                          </option>
                          <option
                            v-for="(
                              notification, index
                            ) in notification_list"
                            :key="notification.code"
                            :value="notification.code"
                            class="fw-bold"                           
                          >
                            {{ notification.code }}
                          </option>
                        </select>
                        <div class="add-new-training-info-icon">
                          <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                              <div class="cursor-pointer svg-icon-height">
                                  <info-icon></info-icon>
                              </div>
                              <template #popper>
                                  Select notification code from here.
                              </template>
                          </VTooltip>                           
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-2"></div>
                      <div class="col-sm-8">
                        <div>
                          <button
                            type="button"
                            @click="backToView()"
                            class="btn btn-danger w-md"
                          >
                            CANCEL
                          </button>
                          &nbsp;
                          &nbsp;
                          <button
                            :disabled="is_add_btn_disabled"
                            type="submit"
                            class="btn btn-primary w-md"
                          >
                            ADD
                          </button>
                        </div>
                      </div>
                    </div>
                     
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import Editor from "@tinymce/tinymce-vue";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../../common/fullPageLoader.vue";
import useVuelidate from "@vuelidate/core";
import infoIcon from "../../../common/icons/infoIcon.vue"
import {
    required,
    between,
    integer,
    helpers,
    requiredIf,
} from "@vuelidate/validators";

const is_valid_video_file = (value) => {
  if (typeof value !== 'undefined'){
    if (value.length === 0) {
      return false;
    }
    var re = /(\.mp4)$/i;
    if (!re.exec(value.name)) {
      return false;
    } else {
      return true;
    }
  }else{
    return false;
  }
};

const is_valid_video_poster_file = (value) => {
  if (typeof value !== 'undefined'){
    if (value.length === 0) {
      return false;
    }
    var re = /(\.jpg|\.jpeg|\.png)$/i;
    if (!re.exec(value.name)) {
      return false;
    } else {
      return true;
    }
  }else{
    return false;
  }
};

const is_valid_video_caption_file = (value) => {
  if (typeof value !== 'undefined'){
    if (value.length === 0) {
      return false;
    }
    var re = /(\.vtt)$/i;
    if (!re.exec(value.name)) {
      return false;
    } else {
      return true;
    }
  }else{
    return false;
  }
};


export default {
  setup: () => ({ v$: useVuelidate() }),
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      TIYMCE_API_KEY: TIYMCE_API_KEY,
      training_code: "",
      title: "",
      title_for_tab: "",
      title_for_list: "",
      description: "",
      description_clean: '',
      video_file: "",
      video_poster_file: "",
      video_caption_file: "",
      // video_caption_file_extension: "",
      training_type: "",
      who_can_train: "",
      trigger_month: "",
      display_order: "",
      check_display_order_available_timer: null,
      is_add_btn_disabled: false,
      is_full_page_loader_shown: false,
      parent_training_list :[],
      parent_training_id: "",      
      is_hco_disabled: false ,
      is_employee_disabled: false,
      notification_code: "",
      notification_list:[]
    };
  },
  components: {
    fullPageLoader,
    Editor,
    infoIcon,
  },
  validations(){
    return {
      title : { required: helpers.withMessage("Please enter a title",required)},
      title_for_list : {         
        requiredIf: helpers.withMessage("Please enter a title for list",
          requiredIf(() => {            
            return this.parent_training_id == ''
        })),
      },  
      title_for_tab : { required: helpers.withMessage("Please enter a title for tab",required)},
      description : { required: helpers.withMessage("Please enter a description",required)},
      video_file : { isValidVideo: helpers.withMessage("Please select a video(mp4) file",is_valid_video_file)},
      video_poster_file : { isValidVideo: helpers.withMessage("Please select a valid image(jpg, jpeg, png) file",is_valid_video_poster_file)},
      video_caption_file : { isValidVideo: helpers.withMessage("Please select a valid video caption (.vtt) file",is_valid_video_caption_file)},
      training_type : { required: helpers.withMessage("Please select a training type",required)},
      who_can_train : { required: helpers.withMessage("Please select a who can train",required)},
      trigger_month: {
         between: helpers.withMessage(
            "Must be a valid number",
            between(1,1000)
          ),
          integer: helpers.withMessage(
            "Must be a valid integer",
            integer
          )
      },  
      display_order: {
              required: helpers.withMessage(
                "Please enter display order",
                required
              ),
              between: helpers.withMessage(
                "Must be a valid number",
                between(1,1000)
              ),
              integer: helpers.withMessage(
                "Must be a valid integer",
                integer
              ),
              isUnique : helpers.withMessage("Display order already use in selected training",
                helpers.withAsync(async (value) => {
                    if (!value) return true;
                    this.is_add_btn_disabled = true;
                    let check_promise = new Promise((resolve, reject) => {
                      if (this.check_display_order_available_timer) {
                        clearTimeout(this.check_display_order_available_timer);
                        this.check_display_order_available_timer = null;
                      }
                      this.check_display_order_available_timer = setTimeout(() => {
                        return fetch(
                          JS_APP_URL +
                            `/pkO0OA17otP61RwETtNn/training/check-unique-display-order/${value}`
                        ).then(
                          (response) => {
                            if (response.ok) {
                              resolve(response.text());
                            } else {
                              resolve(new Error("error"));
                            }
                          },
                          (error) => {
                            resolve(new Error("error"));
                          }
                        );
                      }, 500);
                    });
                    var response = await check_promise;
                    this.is_add_btn_disabled = false;
                    return Boolean(response == "available" ? false : true);
              }))
      },
      training_code : {
        required: helpers.withMessage("Please enter a training code",required),
        isUnique : helpers.withMessage("Training code already in use",
                    helpers.withAsync(async (value) => {
                      if (!value) return true;
                      if (
                        !this.v$.training_code.required ||
                        !this.v$.training_code
                      )
                        return true;
                        this.is_add_btn_disabled = true;
                        let check_promise = new Promise((resolve, reject) => {
                          if (this.check_training_code_available_timer) {
                            clearTimeout(this.check_training_code_available_timer);
                            this.check_training_code_available_timer = null;
                          }
                          this.check_training_code_available_timer = setTimeout(() => {
                            return fetch(
                              JS_APP_URL + `/pkO0OA17otP61RwETtNn/training/check-unique-training-code/${value}`
                            ).then(
                              (response) => {
                                if (response.ok) {
                                  resolve(response.text());
                                } else {
                                  resolve(new Error("error"));
                                }
                              },
                              (error) => {
                                resolve(new Error("error"));
                              }
                            );
                          }, 500);
                        });
                        var response = await check_promise;
                        this.is_add_btn_disabled = false;
                        return Boolean(response == "available" ? false : true);
                    }))
      }
    }
  },
  mounted() {    
    this.getParentTrainingList();
    this.getNotificationList(); 
  },
   watch: {
    parent_training_id(){  
     if(this.parent_training_id!='' && this.parent_training_id!=null){
        var training;                    
        for (training in this.parent_training_list) {                       
            if(this.parent_training_list[training].id == this.parent_training_id) {
                  this.who_can_train=this.parent_training_list[training].who_can_train
                  break;
            }
        }                  
        if(this.who_can_train == "hco")
        {         
          this.is_employee_disabled=true;
          this.is_hco_disabled=false;          
        }
        else if(this.who_can_train == "employee")
        {          
          this.is_employee_disabled=false;
          this.is_hco_disabled=true;          
        }        
      }else{         
           this.is_employee_disabled=false;
          this.is_hco_disabled=false;
      }
    }
  },
  computed: {},
  methods: {
    onDescriptionChange(event, editor) {
        this.description_clean = editor.getContent({format : 'text'});
    },
    onVideoFileChange(e) {
      this.video_file = e.target.files[0];
      this.is_add_btn_disabled = false;
    },
    onVideoPosterFileChange(e) {
      this.video_poster_file = e.target.files[0];
      this.is_add_btn_disabled = false;
    },
    onVideoCaptionFileChange(e) {
      // var file_name = (this.video_caption_file = e.target.files[0].name);
      // var file_ext = file_name.split(".").pop();
      // this.video_caption_file_extension = file_ext;
      this.video_caption_file = e.target.files[0];
      this.is_add_btn_disabled = false;
    },

    addTraining(e) {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        if(this.description_clean.trim() === ""){
          toastr.error('Please enter a valid description', "Error");
          return false;
        }
        NProgress.start();
        this.is_add_btn_disabled = true;
        e.preventDefault();

        let formData = new FormData();
        formData.append("training_code", this.training_code);
        formData.append("title", this.title);
        formData.append("title_for_list", this.title_for_list);
        formData.append("title_for_tab", this.title_for_tab);
        formData.append("parent_training_id", this.parent_training_id);
        formData.append("description", this.description);
        formData.append("video_file", this.video_file);
        formData.append("video_poster_file", this.video_poster_file);
        formData.append("video_caption_file", this.video_caption_file);
        // formData.append(
        //   "video_caption_file_extension",
        //   this.video_caption_file_extension
        // );
        formData.append("training_type", this.training_type);
        formData.append("who_can_train", this.who_can_train);
        formData.append("trigger_month", this.trigger_month);
        formData.append("display_order", this.display_order);
        formData.append("notification_code", this.notification_code);

        axios
          .post(JS_APP_URL + "/pkO0OA17otP61RwETtNn/training/add-training", formData, {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              toastr.success(response["data"]["message"], "Success");
              setTimeout(() => {
                window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/training/view";
              }, 1000);
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
            }
          })
          .then(() => {
            NProgress.done();
            //this.is_add_btn_disabled = false;
          });
      }
    },
    backToView() {
      window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/training/view";
    },    
    getParentTrainingList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/training/get-parent-training-list")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.parent_training_list = response["data"]["data"];
          } else {
            toastr.error(response["data"]["message"], "Error");
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    getNotificationList() {      
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/training/get-notification-list")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.notification_list = response["data"]["data"];
          } else {
            toastr.error(response["data"]["message"], "Error");
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },    
  },
};
</script>
<style scoped>
</style>
