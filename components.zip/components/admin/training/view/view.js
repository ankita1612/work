import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import trainingView from "./view.vue";
import app from "../../common/includes/App.vue"
const view_app = createApp({
    template: `
    <app>
    <training-view></training-view>
    </app>
    `,
    components: {
        app,
        'training-view': trainingView,
    }
});
view_app.use(useVuelidate);
view_app.mount("#view_app");
