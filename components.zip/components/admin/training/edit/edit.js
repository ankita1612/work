import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import VuePlyr from 'vue-plyr';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import 'vue-plyr/dist/vue-plyr.css';
import trainingEdit from "./edit.vue";
import app from "../../common/includes/App.vue"
const edit_app = createApp({
    template: `
    <app>
    <training-edit></training-edit>
    </app>
    `,
    components: {
        app,
        'training-edit': trainingEdit,
    }
});
edit_app.use(VuePlyr, {
    plyr: {}
});
edit_app.use(useVuelidate);
edit_app.component('multiselect', Multiselect);
edit_app.use(FloatingVue);
edit_app.mount("#edit_app");
