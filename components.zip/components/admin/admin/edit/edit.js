import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import adminEdit from "./edit.vue";
import app from "../../common/includes/App.vue"
const edit_app = createApp({
    template: `
    <app>
    <admin-edit></admin-edit>
    </app>
    `,
    components: {
        app,
        'admin-edit': adminEdit,
    }
});
edit_app.use(useVuelidate);
edit_app.component('multiselect', Multiselect);
edit_app.mount("#edit_app");