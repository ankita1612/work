import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import adminAdd from "./add.vue";
import app from "../../common/includes/App.vue"
const add_app = createApp({
    template: `
    <app>
    <admin-add></admin-add>
    </app>
    `,
    components: {
        app,
        'admin-add': adminAdd,
    }
});
add_app.use(useVuelidate);
add_app.component('multiselect', Multiselect);
add_app.mount("#add_app");