<template>
    <div>
      <div class="main-content">
        <div class="page-content">
          <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Add New Admin</h4>
                    </div>
                </div>
            </div>
    
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <form @submit.prevent="addAdmin">
                                <div class="row mb-4" :class="{ 'form-group--error': v$.first_name.$error }">
                                    <label for="horizontal-firstname-input" class="col-sm-2 col-form-label text-end">First Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" placeholder="Enter First Name" id="horizontal-firstname-input" v-model.trim="v$.first_name.$model">
                                        <div v-if="v$.first_name.$errors.length > 0">
                                          <div class="form-error-text">
                                              {{ v$.first_name.$errors[0].$message }}
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-4" :class="{ 'form-group--error': v$.last_name.$error }">
                                    <label for="horizontal-lastname-input" class="col-sm-2 col-form-label text-end">Last Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" placeholder="Enter Last Name" id="horizontal-lastname-input" v-model.trim="v$.last_name.$model">
                                        <div v-if="v$.last_name.$errors.length > 0">
                                          <div class="form-error-text">
                                              {{ v$.last_name.$errors[0].$message }}
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-4" :class="{ 'form-group--error': v$.email.$error }">
                                    <label for="horizontal-email-input" class="col-sm-2 col-form-label text-end">Email</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" placeholder="Enter Email" id="horizontal-email-input" v-model.trim="v$.email.$model">
                                        <div v-if="v$.email.$errors.length > 0">
                                          <div class="form-error-text">
                                              {{ v$.email.$errors[0].$message }}
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-4" :class="{ 'form-group--error': v$.password.$error }">
                                    <label for="horizontal-email-input" class="col-sm-2 col-form-label text-end">Password</label>
                                    <div class="col-md-8">
                                         <input class="form-control" type="password" placeholder="Enter Password" id="example-password-input" v-model.trim="v$.password.$model">
                                         <div v-if="v$.password.$errors.length > 0">
                                          <div class="form-error-text">
                                              {{ v$.password.$errors[0].$message }}
                                          </div>
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="row mb-4" :class="{ 'form-group--error': v$.selected_role.$error }">
                                    <label for="horizontal-email-input" class="col-sm-2 col-form-label text-end pt-0">Role</label>
                                    <div class="col-sm-8">
                                        <div class="form-check form-radio-outline form-radio-info mb-3" v-for="role in role_list" :key="role.id">
                                            <input class="form-check-input" type="radio" :id="'adminrole_'+role.id" name="role" :value="role.id" v-model.trim="v$.selected_role.$model">
                                            <label class="form-check-label" :for="'adminrole_'+role.id">
                                                {{ role.role }}
                                            </label>
                                        </div>
                                        <div v-if="v$.selected_role.$errors.length > 0">
                                          <div class="form-error-text">
                                              {{ v$.selected_role.$errors[0].$message }}
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                <div v-if="is_reseller_role" class="row mb-4" :class="{ 'form-group--error': v$.selected_reseller.$error }">
                                  <label for="horizontal-email-input" class="col-sm-2 col-form-label text-end pt-0"></label>
                                  <div class="col-sm-8"> 
                                    <multiselect
                                      class="font-style-normal"
                                      v-model.trim="v$.selected_reseller.$model"
                                      placeholder="Select Reseller(s)"
                                      :options="partner_resellers"
                                      track-by="id"
                                      label="name"
                                      :multiple="false"
                                      :allow-empty="false"
                                      :searchable="true"
                                      :showLabels="false"
                                      :taggable="false">
                                      <template #noResult>
                                        <div class="multiselect__noResult text-center">
                                          No results found
                                        </div>
                                      </template>
                                      <template #noOptions>
                                        <div class="multiselect__noOptions text-center">
                                          No data available
                                        </div>
                                      </template>
                                      <template #selection>
                                        <div class="multiselect__tags-wrap" v-if="selected_reseller.length > 1">
                                          <span class="multiselect__tag">
                                            <span>{{ selected_reseller.length }} Reseller Selected</span>
                                          </span>
                                        </div>
                                      </template>
                                    </multiselect>
                                    <div v-if="v$.selected_reseller.$errors.length > 0">
                                      <div class="form-error-text">
                                          {{ v$.selected_reseller.$errors[0].$message }}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-8">
                                        <div>
                                          <button
                                            type="button"
                                            @click="backToView"
                                            class="btn btn-danger w-md"
                                          >
                                            CANCEL
                                          </button>
                                          &nbsp;
                                          &nbsp;
                                          <button :disabled="is_add_btn_disabled" type="submit" class="btn btn-primary w-md">ADD</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    
          </div>
        </div>
      </div>
      <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
    </template>
    
    <script scoped>
    import axios from "axios";
    import NProgress from "nprogress";
    import toastr from "toastr";
    import "toastr/toastr.scss";
    toastr.options.preventDuplicates = true;
    import useVuelidate from "@vuelidate/core";
    import {
        required,
        requiredIf,
        email,
        maxLength,
        minLength,
        helpers,
    } from "@vuelidate/validators";
    import fullPageLoader from "../../common/fullPageLoader.vue";
    import {checkSpecialChars, checkSpecialCharsErrorMessage, complexPassword  , complexPasswordErrorMseesage }  from "../../../common/customValidation";
    
    export default {
      setup: () => ({ v$: useVuelidate() }),
      data() {
        return {
          JS_APP_URL: JS_APP_URL,
          JS_WORDPRESS_URL: JS_WORDPRESS_URL,
          role_list: {},
          first_name:'',
          last_name:'',
          email:'',
          password:'',
          selected_role:'',
          is_add_btn_disabled: false,
          is_full_page_loader_shown: false,
          check_admin_available_timer: null,
          is_reseller_role: false,
          selected_reseller: "",
          partner_resellers: []
        };
      },
      components: {
        fullPageLoader,
      },
      validations() {
            return {
                first_name: {
                    required: helpers.withMessage(
                        "Please enter a first name",
                        required
                    ),
                    maxLength: helpers.withMessage(
                        "Max 40 characters allowed",
                        maxLength(40)
                    ),
                    checkSpecialChars: helpers.withMessage(
                        checkSpecialCharsErrorMessage,
                        checkSpecialChars
                    ),
                },
                last_name: {
                    required: helpers.withMessage(
                        "Please enter a last name",
                        required
                    ),
                    maxLength: helpers.withMessage(
                        "Max 40 characters allowed",
                        maxLength(40)
                    ),
                    checkSpecialChars: helpers.withMessage(
                        checkSpecialCharsErrorMessage,
                        checkSpecialChars
                    ),
                },
                email: {
                    email: helpers.withMessage("Please enter a valid email", email),
                    required: helpers.withMessage(
                        "Please enter an email",
                        required
                    ),
                    maxLength: helpers.withMessage(
                        "Max 100 characters allowed",
                        maxLength(100)
                    ),
                    isUnique: helpers.withMessage(
                        "Email address already in use",
                        helpers.withAsync(async (value) => {
                          if (!value) return true;
                          this.is_add_btn_disabled = true;                
                          let check_promise = new Promise((resolve, reject) => {   
                              if (this.check_admin_available_timer) {
                                  clearTimeout(this.check_admin_available_timer)
                                this.check_admin_available_timer = null
                              }
                            this.check_admin_available_timer = setTimeout(() => {                    
                                  return fetch(JS_APP_URL + `/pkO0OA17otP61RwETtNn/admin/check-unique-email-admin/${value}`).then(response => {
                                      if (response.ok) {
                                          resolve(response.text())
                                      } else {
                                          resolve(new Error('error'))
                                      }
                                  }, error => {
                                      resolve(new Error('error'))
                                  })
                              }, 500);                                     
                          });
                          var response = await check_promise;
                          this.is_add_btn_disabled = false;
                          return Boolean((response == 'available')?false:true);
                        })
                    ),
                },
                password: {
                    required: helpers.withMessage('Please enter a password', required),
                    minLength: helpers.withMessage(' Password must contain at least one letter, one number and one special character', minLength(6)),
                    isComplexPassword: helpers.withMessage(complexPasswordErrorMseesage, complexPassword),
                },
                selected_role:{
                  required: helpers.withMessage('Please select a role',required)
                },
                selected_reseller: {
                  requiredIf: helpers.withMessage("Please select a reseller",
                    requiredIf(() => {
                        return this.is_reseller_role == true
                  })),
                }
            };
      },
      mounted() {
        this.getRoleList();   
        this.getPartnerReseller(); 
      },
      watch: {
        selected_role() {
          if(this.selected_role == 4) {
            this.is_reseller_role = true
          }else{
            this.is_reseller_role = false
            this.selected_reseller = ''
          }
        }
      },
      computed: {},
      methods:{
          backToView(){
            window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/admin/view";
          },
          getRoleList() { 
            this.is_full_page_loader_shown = true;
            axios
            .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/admin/get-role-list")
            .then((response) => {
              if (response["data"]["status"] == "Error") {
                if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
              } else {
                this.role_list = response['data']['data'];
              }
            })
            .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
              }
            })
            .then(() => {
              this.is_full_page_loader_shown = false;
            });
          },
          addAdmin(){
            this.v$.$touch();
            if (!this.v$.$invalid) {
              NProgress.start();
              this.is_add_btn_disabled = true;
              axios.post(JS_APP_URL  + "/pkO0OA17otP61RwETtNn/admin/add-admin",{
                first_name:this.first_name,
                last_name:this.last_name,
                email:this.email,
                password:this.password,
                selected_role:this.selected_role,
                partner_reseller_id: this.is_reseller_role?this.selected_reseller.id:null
              })
              .then((response) => {
                if (response["data"]["status"] == "Error") {
                  if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                  }else{
                    toastr.error(response["data"]["message"], "Error");
                  }
                } else {
                  toastr.success(response["data"]["message"], "Success");
                  setTimeout(() => {
                    window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/admin/view";
                  }, 1000);
                }
              })
              .catch((error)=> {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                  window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
                }
              })
              .then(()=> {
                //this.is_add_btn_disabled = false;
                NProgress.done();
               });
            }
          },
          getPartnerReseller() {
            this.is_full_page_loader_shown = true;
            axios
            .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/admin/get-partner-reseller-list")
            .then((response) => {
              if (response["data"]["status"] == "Error") {
                if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
              } else {
                this.partner_resellers = response['data']['data'];
              }
            })
            .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
              }
            })
            .then(() => {
              this.is_full_page_loader_shown = false;
            });
          }
      },  
    };
    </script>
    