import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import adminView from "./view.vue";
import app from "../../common/includes/App.vue"
const view_app = createApp({
    template: `
    <app>
    <admin-view></admin-view>
    </app>
    `,
    components: {
        app,
        'admin-view': adminView,
    }
});
view_app.use(useVuelidate);
view_app.mount("#view_app");
