import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import onGoingQuestionView from "./view.vue";
import app from "../../common/includes/App.vue"
const view_app = createApp({
    template: `
    <app>
    <on-going-question-view></on-going-question-view>
    </app>
    `,
    components: {
        app,
        'on-going-question-view': onGoingQuestionView,
    }
});
view_app.use(useVuelidate);
view_app.mount("#view_app");
