<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container">
            <div
              v-on:click="$emit('close-modal')"
              class="cursor-pointer modal-close"
            >
              <close-icon></close-icon>
            </div>
            <div class="row m-0">
              <div class="col-12">
                  <div class="text-start">
                    <h5 class="border-bottom border-light mb-3 pb-2">View Correlation</h5>
                  </div>
                  <p class="fs-6 text-start fw-bold fst-italic mb-3">If, Then</p>                
                  <div                
                    v-for="(
                      ongoing_view_correlation, index
                    ) in get_view_correlation_detail"
                    :key="index"
                  >
                    <p class="fs-6 text-start" v-if="ongoing_view_correlation.answer != null">
                      {{index + 1}}) {{ ongoing_view_correlation.question.question_code }} =
                      {{ ongoing_view_correlation.answer.answer }}
                    </p>
                    <p class="fs-6 text-start" v-else>
                      {{index + 1}}) {{ ongoing_view_correlation.question.question_code }} = Any answer
                    </p>
                  </div> 
                  <p v-if="get_view_correlation_detail.length == 0" class="fs-6 text-start fst-italic">No Correlation Available!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>
<script scoped>
import closeIcon from "../../common/icons/closeIcon.vue";
import "toastr/toastr.scss";

export default {
  data() {
    return {};
  },
  props: ["get_view_correlation_detail"],
  emits: ["close-modal"],
  components: { closeIcon },
  mounted() {},
  methods: {},
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-modal");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>

<style>
</style>
