<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div
                class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                "
              >
                <h4 class="mb-sm-0 font-size-18">Update Ongoing Question</h4>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <form @submit.prevent="updateOnGoingQuestion">
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.question_code.$error }"
                    >
                      <label
                        for="horizontal-question_code-input"
                        class="col-sm-2 col-form-label text-end"
                        >Question Code</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Question Code"
                          id="horizontal-question_code-input"
                          v-model.trim="v$.question_code.$model"
                        />
                        <div v-if="v$.question_code.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.question_code.$errors[0].$message }}
                          </div>
                       </div>
                      </div>
                    </div>
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.question.$error }"
                    >
                      <label
                        for="horizontal-question-input"
                        class="col-sm-2 col-form-label text-end"
                        >Question</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Question"
                          id="horizontal-question-input"
                          v-model.trim="v$.question.$model"
                        />
                        <div v-if="v$.question.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.question.$errors[0].$message }}
                          </div>
                       </div>
                      </div>
                    </div>
                    <div class="row mb-4">
                      <label
                        for="horizontal-email-input"
                        class="col-sm-2 col-form-label text-end pt-0"
                        >Status</label
                      >
                      <div class="col-md-8">
                        <div class="form-check form-switch form-switch-md mb-3" dir="ltr">
                            <input class="form-check-input" type="checkbox" id="ongoingquestion_status" v-model.trim="is_active">
                            <label class="form-check-label" for="ongoingquestion_status" v-text="(is_active)?'Active':'Inactive'"></label>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-sm-2"></div>
                      <div class="col-sm-8">
                        <div>
                          <button
                            type="button"
                            @click="backToView()"
                            class="btn btn-danger w-md"
                          >
                            CANCEL
                          </button>
                          &nbsp;
                          &nbsp;
                          <button
                            :disabled="is_edit_btn_disabled"
                            type="submit"
                            class="btn btn-primary w-md"
                          >
                            UPDATE
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import useVuelidate from "@vuelidate/core";
import {
    required,
    helpers,
} from "@vuelidate/validators";
import fullPageLoader from "../../common/fullPageLoader.vue";

export default {
  setup: () => ({ v$: useVuelidate() }),
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      ONGOINGQUESTION_ID: ONGOINGQUESTION_ID,
      question_code: "",
      question: "",
      is_active: "",
      is_edit_btn_disabled: false,
      is_full_page_loader_shown: false,
      check_order_display_available_timer: null,
      check_og_available_timer: null,
    };
  },
  components: {
    fullPageLoader,
  },
  validations() {
        return {
            question: {
                required: helpers.withMessage(
                    "Please enter a question",
                    required
                )
            },
            question_code: {
                required: helpers.withMessage(
                    "Please enter a question code",
                    required
                ),
                isUnique: helpers.withMessage(
                    "Question code is already in use",
                    helpers.withAsync(async (value) => {
                      if (!value) return true;
                      this.is_edit_btn_disabled = true;                
                      let check_promise = new Promise((resolve, reject) => {   
                          if (this.check_og_available_timer) {
                              clearTimeout(this.check_og_available_timer)
                              this.check_og_available_timer = null
                          }
                          this.check_og_available_timer = setTimeout(() => {                    
                              return fetch(JS_APP_URL + `/pkO0OA17otP61RwETtNn/ongoingquestion/check-unique-code/${value}/${this.ONGOINGQUESTION_ID}`).then(response => {
                                  if (response.ok) {
                                      resolve(response.text())
                                  } else {
                                      resolve(new Error('error'))
                                  }
                              }, error => {
                                  resolve(new Error('error'))
                              })
                          }, 500);                                     
                      });
                      var response = await check_promise;
                      this.is_edit_btn_disabled = false;
                      return Boolean((response == 'available')?false:true);
                    })
                ),
            }
        };
  },
  methods: {
    getOnGoingQuestionDetails() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL +
            "/pkO0OA17otP61RwETtNn/ongoingquestion/get-ongoingquestion-edit-detail/" +
            ONGOINGQUESTION_ID
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            let data = response.data.data;
            this.question_code = data.question_code;
            this.question = data.question;
            this.is_active =  (data.is_active == 1)?true:false;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    updateOnGoingQuestion() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        NProgress.start();
        this.is_edit_btn_disabled = true;
        axios
          .post(
            JS_APP_URL +
              "/pkO0OA17otP61RwETtNn/ongoingquestion/update-ongoingquestion",
            {
              ongoingquestion_id: ONGOINGQUESTION_ID,
              question_code: this.question_code,
              question: this.question,
              is_active: this.is_active
            }
          )
          .then((response)=> {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              setTimeout(() => {
                window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/ongoingquestion/view";
              }, 500);
              toastr.success(response["data"]["message"], "Success");
            }
          })
          .catch((error)=> {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
            }
          })
          .then(() => {
            //this.is_edit_btn_disabled = false;
            NProgress.done();
          });
      }
    },
    backToView() {
      window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/ongoingquestion/view";
    },
  },
  mounted() {
    this.getOnGoingQuestionDetails();
  },
};
</script>
