import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import onGoingQuestionEdit from "./edit.vue";
import app from "../../common/includes/App.vue"
const edit_app = createApp({
    template: `
    <app>
    <on-going-question-edit></on-going-question-edit>
    </app>
    `,
    components: {
        app,
        'on-going-question-edit': onGoingQuestionEdit,
    }
});
edit_app.use(useVuelidate);
edit_app.mount("#edit_app");
