import { createApp } from 'vue';
import login from "./login.vue";
const app = createApp(login);
import { useVuelidate } from '@vuelidate/core';
app.use(useVuelidate);
app.mount('#login_app')