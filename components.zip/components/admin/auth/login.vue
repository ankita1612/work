<template>
  <div class="account-pages my-5 pt-sm-5">
      <div class="container">
          <div class="row justify-content-center">
              <div class="col-md-8 col-lg-6 col-xl-5">
                  <div class="card overflow-hidden">
                      <div class="bg-primary bg-soft">
                          <div class="row">
                              <div class="col-12">
                                  <div class="text-primary p-4">
                                      <h5 class="text-primary">Welcome Back !</h5>
                                      <p class="mb-0">Sign in to HIPAA Admin.</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="card-body pt-0"> 
                          <div class="mt-4 mb-4">
                              <form class="form-horizontal" @submit.prevent="loginSubmit">
                                  <div class="mb-3" :class="{ 'form-group--error': v$.email.$errors.length }">
                                      <label for="email" class="form-label">Email</label>
                                      <input v-model.trim="v$.email.$model" name="email" type="text" class="form-control"  :class="{ 'border-danger': v$.email.$error }" id="email" placeholder="Enter email">
                                      <div v-if="v$.email.$errors.length > 0">
                                        <div class="form-error-text">
                                            {{ v$.email.$errors[0].$message }}
                                        </div>
                                      </div>
                                  </div>          
                                  <div class="mb-3" :class="{ 'form-group--error': v$.password.$errors.length }">
                                      <label class="form-label">Password</label>
                                      <input v-model.trim="v$.password.$model" type="password" name="password" id="password" :class="{ 'border-danger': v$.password.$errors.length }" class="form-control" placeholder="Enter password"> 
                                      <div v-if="v$.password.$errors.length > 0">
                                        <div class="form-error-text">
                                            {{ v$.password.$errors[0].$message }}
                                        </div>
                                      </div>
                                  </div>                                  
                                  <div class="mt-3 d-grid">
                                      <button  :disabled="disable_signin_btn" class="btn btn-primary waves-effect waves-light" type="submit">Log In</button>
                                  </div>
                              </form>
                          </div>      
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, email, maxLength, helpers } from "@vuelidate/validators";

export default {
  setup: () => ({ v$: useVuelidate() }),
  data() {
    return {
      email: "",
      password: "",
      disable_signin_btn: false,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  components: {
  },
  validations() {
    return {
        email: {
            required: helpers.withMessage('Please enter an email', required),
            email: helpers.withMessage('Please enter a valid email', email),
            maxLength: helpers.withMessage(
                    "Max 100 characters allowed",
                    maxLength(100)
                ),
        },
        password: {
            required: helpers.withMessage('Please enter a password', required),
        },
    }
  },
  mounted() {
    
  },
  watch: {},
  computed: {},
  methods: {
    loginSubmit() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        NProgress.start();
        this.disable_signin_btn = true;
        axios
        .post(JS_APP_URL + "/pkO0OA17otP61RwETtNn/login", {
          email: this.email,
          password: this.password,
        })
        .then((response)=> {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            setTimeout(() => {
              window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/dashboard";
            }, 500);
          }
        })
        .catch((error)=> {
          toastr.error(error.response["data"]["message"], "Error");
        })
        .then(()=> {
          NProgress.done();
          this.disable_signin_btn = false;
        });
      }
    },
  },
};
</script>
