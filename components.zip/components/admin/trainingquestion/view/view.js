import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import trainingQuestionView from "./view.vue";
import app from "../../common/includes/App.vue"
const view_app = createApp({
    template: `
    <app>
    <training-question-view></training-question-view>
    </app>
    `,
    components: {
        app,
        'training-question-view': trainingQuestionView,
    }
});
view_app.use(useVuelidate);
view_app.component('multiselect', Multiselect);
view_app.mount("#view_app");