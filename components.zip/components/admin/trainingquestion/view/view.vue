<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                ">
                <h4 class="mb-sm-0 font-size-18">Training Question List</h4>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <div class="row mb-2">
                      <div class="col-lg-3">
                        <div class="demo-content"><label>Show
                            <select v-model.trim="selected_show_entry" class="
                              custom-select custom-select-sm
                              form-control
                              form-control-sm
                              form-select
                              form-select-sm
                              d-inline-block
                              w-auto
                              ms-2
                              me-2
                            ">
                              <option :value="entry" v-for="entry in show_entry_list" :key="entry">
                                {{ entry }}
                              </option>
                            </select>
                            entries
                          </label></div>
                      </div>
                      <div class="col-sm-3 text-end">
                          
                      </div>
                      <div class="col-sm-3">
                          <multiselect v-model.trim="selected_training" :options="training_video_title_list"
                            label="title" placeholder="Filter by Training Title" :searchable="true" :showLabels="false"
                            :taggable="false">
                            <template #noResult>
                              <div class="multiselect__noResult text-center">
                                No results found
                              </div>
                            </template>
                            <template #noOptions>
                              <div class="multiselect__noOptions text-center">
                                No data available
                              </div>
                            </template>
                          </multiselect>
                      </div>
                      <div class="col-sm-3 text-end">
                        <div>
                          <div>
                            <label><span>Search:</span><input type="text" class="
                              form-control form-control-sm
                              d-inline-block
                              w-auto
                              ms-2
                            " v-model.trim="search" @input="applySearch()" placeholder="Search" /></label>
                          </div>
                        </div>
                      </div>
                  </div>

                  <div class="row">

                    <div class="col-xl-12">
                      <table class="
                          table table-responsive table-bordered
                          mb-0
                          dataTable
                          table-fixed
                        ">
                        <thead class="table-light">
                          <tr>
                            <th v-for="column in columns" :key="column.id" @click="sortByColumn(column.id)"
                              class="sorting" :class="[
                                column.id === sort_column
                                  ? sort_order == 'asc'
                                    ? 'sorting_asc'
                                    : 'sorting_desc'
                                  : '',
                              ]">
                              {{ column.text }}
                            </th>
                            <th>ACTION</th>
                          </tr>
                        </thead>
                        <tbody v-if="training_question.length > 0">
                          <tr v-for="(
                              training_question_view, index
                            ) in training_question" :key="index">
                            <td>{{ training_question_view.question }}</td>
                            <td>{{ training_question_view.training ? training_question_view.training.title : '' }}</td>
                            <td>{{ training_question_view.display_order }}</td>
                            <td>
                              {{
                                  training_question_view
                                    .training_question_answer_correct[0].answer
                              }}
                            </td>
                            <td>
                              <button title="Click to change status" @click="trainingQuestionStatusChangeModal(training_question_view.id)"
                                class="badge rounded-pill font-size-14 badge-soft-success border-0" :class="[
                                  training_question_view.is_active == 1
                                    ? 'badge-soft-success'
                                    : 'badge-soft-danger',
                                ]">{{
    training_question_view.is_active == 1
      ? "ACTIVE"
      : "INACTIVE"
}}</button>
                            </td>
                            <td>
                              {{
                                  formatDateTime(
                                    training_question_view.created_at
                                  )
                              }}
                            </td>
                            <td>
                              <!-- <a
                                title="Edit"
                                :href="
                                  JS_APP_URL +
                                  '/pkO0OA17otP61RwETtNn/training/edit/' +
                                  training_question_view.id
                                "
                                class="btn btn-primary waves-effect waves-light"
                                ><i
                                  class="
                                    bx bx-edit
                                    font-size-18
                                    align-middle
                                    me-0
                                  "
                                ></i
                              ></a> -->
                              <!-- <button title="Delete" type="button" @click="
                                deleteModalToggle(training_question_view.id)
                              " class="btn btn-danger waves-effect waves-light">
                                <i class="
                                    bx bx-trash
                                    font-size-18
                                    align-middle
                                    me-0
                                  "></i>
                              </button> -->
                              <button title="View Details" type="button" @click="
                                showTrainingQuestionDetailModalToggle(training_question_view.id)
                              " class="btn btn-info waves-effect waves-light">
                                <i class="
                                    bx
                                    bxs-book-content
                                    font-size-18
                                    align-middle
                                    me-0
                                  "></i>
                              </button>
                            </td>
                          </tr>
                        </tbody>
                        <tbody v-else>
                          <tr>
                            <td colspan="7" class="text-center">
                              No records available!
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="row mt-3">
                    <div class="col-xl-12">
                      <pagination v-if="training_question.length > 0" :current_page="current_page"
                        :total_page="total_page" :pagination_links="pagination_links" @change-page="changePage">
                      </pagination>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <delete-training-question-modal v-if="is_delete_modal_shown" @close-modal="is_delete_modal_shown = false"
      @training-question-deleted="trainingQuestionDeleted" :delete_modal_selected_id="delete_modal_selected_id">
    </delete-training-question-modal>

    <training-question-status-change-modal v-if="is_status_modal_shown" @close-modal="is_status_modal_shown = false"
      @training-question-status-change="trainingQuestionStatusChange"
      :status_modal_selected_id="status_modal_selected_id">
    </training-question-status-change-modal>

    <show-training-question-detail-modal v-if="is_training_question_detail_modal_shown"
      @close-modal="is_training_question_detail_modal_shown = false"
      :get_training_question_detail="get_training_question_detail">
    </show-training-question-detail-modal>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from "lodash";
import deleteTrainingQuestionModal from "./deleteTrainingQuestionModal.vue";
import trainingQuestionStatusChangeModal from "./trainingQuestionStatusChangeModal.vue";
import showTrainingQuestionDetailModal from "./showTrainingQuestionDetailModal.vue";
import fullPageLoader from "../../common/fullPageLoader.vue";
import moment from "moment";
import pagination from "../../common/pagination.vue";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      training_question: [],
      get_training_detail: "",
      search: null,
      total_page: "",
      current_page: 1,
      pagination_links: [],
      per_page: "",
      selected_show_entry: 10,
      show_entry_list: [10, 25, 50, 100],
      columns: [
        { id: "question", text: "QUESTION" },
        { id: "title", text: "TRAINING TITLE" },
        { id: "display_order", text: "DISPLAY ORDER" },
        { id: "answer", text: "CORRECT ANSWER" },
        { id: "is_active", text: "STATUS" },
        { id: "created_at", text: "ADDED DATE" },
      ],
      sort_column: "created_at",
      sort_order: "desc",
      is_delete_modal_shown: false,
      delete_modal_selected_id: "",
      is_full_page_loader_shown: false,
      training_video_title_list: [],
      selected_training: "",
      status_modal_selected_id: "",
      is_status_modal_shown: false,
      get_training_question_detail: {},
      is_training_question_detail_modal_shown: false
    };
  },
  components: {
    deleteTrainingQuestionModal,
    trainingQuestionStatusChangeModal,
    showTrainingQuestionDetailModal,
    fullPageLoader,
    pagination,
  },
  watch: {
    selected_show_entry(val) {
      this.current_page = 1;
      this.getTrainingQuestionList();
    },
    selected_training(val) {
      this.current_page = 1;
      this.getTrainingQuestionList();
    }
  },
  computed: {},
  mounted() {
    this.getTrainingQuestionList();
    this.getTrainingVideoTitleList();
  },
  methods: {
    formatDateTime(value) {
      return moment.utc(String(value)).local().format("MM/DD/YYYY hh:mm A");
    },
    trainingQuestionStatusChangeModal(id) {
      this.status_modal_selected_id = id;
      this.is_status_modal_shown = true;
    },
    trainingQuestionStatusChange() {
      this.current_page = this.current_page;
      this.getTrainingQuestionList('delete_action');
      this.is_status_modal_shown = false;
    },
    getTrainingQuestionList(call_from = "") {
      this.is_full_page_loader_shown = true;
      let params
      if (this.selected_training == null) {
        params = {
          search: this.search,
          selected_show_entry: this.selected_show_entry,
          page: this.current_page,
          sort_column: this.sort_column,
          sort_order: this.sort_order,
          selected_training: null
        }
      } else {
        params = {
          search: this.search,
          selected_show_entry: this.selected_show_entry,
          page: this.current_page,
          sort_column: this.sort_column,
          sort_order: this.sort_order,
          selected_training: this.selected_training.id
        }
      }
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/trainingquestion/training-question-list", {
          params
        })
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            let data = response.data.data;
            this.training_question = data.data;
            this.current_page = data.current_page;
            this.total_page = data.last_page;
            this.per_page = data.per_page;
            this.pagination_links = data.links;
            if (call_from == "delete_action" && this.training_question.length == 0) {
              this.search = null;
              this.getTrainingQuestionList();
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    getTrainingVideoTitleList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL + "/pkO0OA17otP61RwETtNn/trainingquestion/get-training-video-title-list"
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.training_video_title_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    deleteModalToggle(id) {
      this.delete_modal_selected_id = id;
      this.is_delete_modal_shown = true;
    },
    trainingQuestionDeleted() {
      this.current_page = 1;
      this.getTrainingQuestionList("delete_action");
      this.is_delete_modal_shown = false;
    },
    showTrainingQuestionDetailModalToggle(id) {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/trainingquestion/show-training-question-detail/" + id)
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.is_training_question_detail_modal_shown = true;
            let data = response.data.data;
            this.get_training_question_detail = data;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    sortByColumn(column) {
      if (column === this.sort_column) {
        this.sort_order = this.sort_order === "asc" ? "desc" : "asc";
      } else {
        this.sort_column = column;
        this.sort_order = "asc";
      }
      this.getTrainingQuestionList();
    },
    changePage(page) {
      this.current_page = page;
      this.getTrainingQuestionList();
    },
    applySearch() {
      this.current_page = 1;
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      this.timer = setTimeout(() => {
        this.getTrainingQuestionList();
      }, 500);
    },
  },
};
</script>