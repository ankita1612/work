<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn modal-xl">
          <div class="modal-container">
            <div
              v-on:click="$emit('close-modal')"
              class="cursor-pointer modal-close"
            >
              <close-icon></close-icon>
            </div>
            <div class="row m-0">
              <div class="col-12">
                <div class="text-start">
                  <h5 class="border-bottom border-light mb-3 pb-2">
                    View Training Question Answer Detail
                  </h5>
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th>Answer</th>
                        <th>Is Correct</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(get_training_question_answer_detail,index) in get_training_question_detail" :key="index">
                        <td>{{ get_training_question_answer_detail.answer}}</td>
                        <td>{{ get_training_question_answer_detail.is_correct_answer}}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import closeIcon from "../../common/icons/closeIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";

export default {
  data() {
    return {};
  },
   props: {
    get_training_question_detail: {
      type: Array,
    },
  },
  emits: ["close-modal"],
  components: { closeIcon },
  mounted() {},
  methods: {},
  created () {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-modal");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>

<style>
</style>
