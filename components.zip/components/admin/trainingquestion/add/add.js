import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import trainingQuestionAdd from "./add.vue";
import app from "../../common/includes/App.vue"
const add_app = createApp({
    template: `
    <app>
    <training-question-add></training-question-add>
    </app>
    `,
    components: {
        app,
        'training-question-add': trainingQuestionAdd,
    }
});
add_app.use(useVuelidate);
add_app.component('multiselect', Multiselect);
add_app.mount("#add_app");