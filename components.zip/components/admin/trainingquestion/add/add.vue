<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div
                class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                "
              >
                <h4 class="mb-sm-0 font-size-18">Add New Training Question</h4>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <form @submit.prevent="addTrainingQuestion">
                    <div
                      class="row mb-4"
                      :class="{
                        'form-group--error': v$.selected_training.$error,
                      }"
                    >
                      <label
                        for="horizontal-question_code-input"
                        class="col-sm-2 col-form-label text-end"
                        >Select Training Video</label
                      >
                      <div class="col-sm-8">
                        <multiselect
                          v-model.trim="v$.selected_training.$model"
                          :options="training_video_title_list"
                          label="title"
                          placeholder="Select Training Video"
                          :multiple="false"
                          :allow-empty="false"
                          :searchable="true"
                          :showLabels="false"
                          :taggable="false"
                          @update:model-value="onChange"
                        >
                        <template #noResult>
                          <div class="multiselect__noResult text-center">
                            No results found
                          </div>
                        </template>
                        <template #noOptions>
                          <div class="multiselect__noOptions text-center">
                            No data available
                          </div>
                        </template>
                        </multiselect>
                        <div v-if="v$.selected_training.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.selected_training.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.question.$error }"
                    >
                      <label
                        for="horizontal-question-input"
                        class="col-sm-2 col-form-label text-end"
                        >Question</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Question"
                          id="horizontal-question-input"
                          v-model.trim="v$.question.$model"
                        />
                        <div v-if="v$.question.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.question.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- <div class="row mb4">
                      <div class="col-sm-10 text-end mb-4">
                        <button
                          type="button"
                          @click="question_answer.push({ question_option: '' })"
                          class="btn btn-success waves-effect waves-light"
                          >ADD OPTION</button
                        >
                      </div>
                    </div> -->

                    <div
                      v-for="(v, index) in question_answer"
                      :key="index"
                    >
                      <div
                        class="row mb-4"
                        :class="{ 'form-group--error': v$.question_answer.$error }"
                      >
                        <label
                          for="horizontal-question-input"
                          class="col-sm-2 col-form-label text-end"
                          >Answer Option {{ parseInt(index) + 1 }}</label
                        >
                        <div class="col-sm-7">
                          <input
                            type="text"
                            class="form-control"
                            :placeholder="
                              'Enter Answer Option ' + (parseInt(index) + 1)
                            "
                            id="horizontal-question-input"
                            v-model.trim="v.question_option"
                          />
                          <div v-if="v$.question_answer.$error && v$.question_answer.$each.$response.$errors[index].question_option.length > 0">
                            <div class="form-error-text">{{ v$.question_answer.$each.$response.$errors[index].question_option[0].$message}} {{ parseInt(index) + 1 }}</div>
                          </div>
                        </div>
                        <div class="col-sm-2 mt-1">
                          <input
                            class="form-check-input"
                            type="radio"
                            :id="'question_option_key_' + index"
                            name="training_question_answer"
                            :value="index"
                            v-model.trim="is_training_question_answer_correct"
                          />
                          <label
                            class="form-check-label ms-1"
                            :for="'question_option_key_' + index"
                          >
                            Is Correct?
                          </label>
                          <a
                            href="javascript:void(0)"
                            class=""
                            @click="removeQuestionOption(index)"
                            v-show="index > 0"
                          >
                            <img
                              title="Remove Answer Option"
                              height="24px"
                              class="ms-2"
                              :src="
                                JS_APP_URL + '/images/admin_remove_icon.png'
                              "
                            />
                          </a>
                          <a
                            href="javascript:void(0)"
                            @click="addAnswerOption()"
                            v-show="index == 0"
                          >
                            <img
                              title="Add Answer Option"
                              height="24px"
                              class="ms-2"
                              :src="JS_APP_URL + '/images/admin_add_icon.png'"
                            />
                          </a>
                        </div>
                      </div>
                    </div>

                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.display_order.$error }"
                    >
                      <label
                        for="horizontal-question-input"
                        class="col-sm-2 col-form-label text-end"
                        >Display Order</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Display Order"
                          id="horizontal-question-input"
                          v-model.trim="v$.display_order.$model"
                        />
                        <div v-if="v$.display_order.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.display_order.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-2"></div>
                      <div class="col-sm-8">
                        <div>
                          <button
                            type="button"
                            @click="backToView()"
                            class="btn btn-danger w-md"
                          >
                            CANCEL
                          </button>
                          &nbsp;
                          &nbsp;
                          <button
                            :disabled="is_add_btn_disabled"
                            type="submit"
                            class="btn btn-primary w-md"
                          >
                            ADD
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import useVuelidate from "@vuelidate/core";
import {
    required,
    between,
    integer,
    helpers,
} from "@vuelidate/validators";
import fullPageLoader from "../../common/fullPageLoader.vue";

export default {
  setup: () => ({ v$: useVuelidate() }),
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      selected_training: "",
      question: "",
      question_answer: [
        {
          question_option: "",
        },
      ],
      is_training_question_answer_correct: "",
      training_video_title_list: [],
      is_add_btn_disabled: false,
      is_full_page_loader_shown: false,
      display_order: "",
      check_display_order_available_timer: null,
    };
  },
  components: {
    fullPageLoader,
  },
  validations() {
        return {
          selected_training: {
            required: helpers.withMessage(
              "Please select a training video",
              required
            )
          },
          question: {
            required: helpers.withMessage(
              "Please enter a question",
              required
            )
          },
          display_order: {
              required: helpers.withMessage(
                "Please enter display order",
                required
              ),
              between: helpers.withMessage(
                "Must be a valid number",
                between(1,1000)
              ),
              integer: helpers.withMessage(
                "Must be a valid integer",
                integer
              ),
              isUnique : helpers.withMessage("Display order already use in selected training",
                helpers.withAsync(async (value) => {
                    if (!value) return true;
                    this.is_add_btn_disabled = true;
                    let check_promise = new Promise((resolve, reject) => {
                      if (this.check_display_order_available_timer) {
                        clearTimeout(this.check_display_order_available_timer);
                        this.check_display_order_available_timer = null;
                      }
                      this.check_display_order_available_timer = setTimeout(() => {
                        return fetch(
                          JS_APP_URL +
                            `/pkO0OA17otP61RwETtNn/trainingquestion/check-unique-display-order/${value}/${this.selected_training.id}`
                        ).then(
                          (response) => {
                            if (response.ok) {
                              resolve(response.text());
                            } else {
                              resolve(new Error("error"));
                            }
                          },
                          (error) => {
                            resolve(new Error("error"));
                          }
                        );
                      }, 500);
                    });
                    var response = await check_promise;
                    this.is_add_btn_disabled = false;
                    return Boolean(response == "available" ? false : true);
              }))
          },
          question_answer: {
              $each: helpers.forEach({
                question_option : {
                  required : helpers.withMessage("Please enter a question answer option",required)
                }
              })
          }
        }
  },
  
  mounted() {
    this.getTrainingVideoTitleList();
  },
  watch: {},
  computed: {},
  methods: {
    addAnswerOption() {
      if (this.question_answer.length < 6) {
        this.question_answer.push({ question_option: "" });
      } else {
        toastr.error("You can add maximum 6 answers", "Error");
      }
    },
    removeQuestionOption(index) {
      this.question_answer = this.question_answer.filter((_, i) => i !== index) 
      this.is_training_question_answer_correct = "";
    },
    onChange(value) {
      this.display_order = "";
    },
    addTrainingQuestion() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        let AOArray = this.question_answer.map((item) => item.question_option);
        if (this.is_training_question_answer_correct === "") {
          toastr.error("Please select a correct answer", "Error");
        } else if (new Set(AOArray).size !== AOArray.length) {
          toastr.error("Please enter a unique answer option", "Error");
        } else {
          NProgress.start();
          this.is_add_btn_disabled = true;
          axios
            .post(JS_APP_URL + "/pkO0OA17otP61RwETtNn/trainingquestion/add-trainingquestion", {
              selected_training: this.selected_training.id,
              question: this.question,
              options: this.question_answer,
              is_training_question_answer_correct:
                this.is_training_question_answer_correct,
              display_order: this.display_order,
            })
            .then((response) => {
              if (response["data"]["status"] == "Error") {
                if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
              } else {
                toastr.success(response["data"]["message"], "Success");
                setTimeout(() => {
                  window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/trainingquestion/view";
                }, 1000);
              }
            })
            .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
              }
            })
            .then(() => {
              NProgress.done();
              //this.is_add_btn_disabled = false;
            });
        }
      }
    },
    getTrainingVideoTitleList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL + "/pkO0OA17otP61RwETtNn/trainingquestion/get-training-video-title-list"
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.training_video_title_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    backToView() {
      window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/trainingquestion/view";
    },
  },
};
</script>
