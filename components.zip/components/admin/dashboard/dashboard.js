import { createApp } from 'vue';
import dashboard from "./dashboard.vue";
import app from "../../admin/common/includes/App.vue"

const dashboard_app = createApp({
    template: `
    <app>
    <dashboard></dashboard>
    </app>
    `,
    components: {
        app,
        dashboard,
    }
});
dashboard_app.mount("#dashboard_app");