<template>
    <div>
      <div class="main-content">
        <div class="page-content">
          <div class="container-fluid">
              <div class="row">
                  <div class="col-12">
                      <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                          <h4 class="mb-sm-0 font-size-18">Dashboard</h4>
                      </div>
                  </div>
              </div>
              <div class="row">
                  <div class="col-md-3" v-if="AUTH_USER.partner_reseller_id == null">
                      <div class="card mini-stats-wid">
                          <div class="card-body">
                              <div class="d-flex">
                                  <div class="flex-grow-1">
                                      <p class="text-muted fw-medium">Admin</p>
                                      <h4 class="mb-0">{{dashboard_details['total_admin']}}</h4>
                                  </div>
    
                                  <div class="flex-shrink-0 align-self-center">
                                      <div class="mini-stat-icon avatar-sm rounded-circle bg-primary">
                                          <span class="avatar-title">
                                              <i class="bx bx-user-circle font-size-24"></i>
                                          </span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-3">
                      <div class="card mini-stats-wid">
                          <div class="card-body">
                              <div class="d-flex">
                                  <div class="flex-grow-1">
                                      <p class="text-muted fw-medium">User</p>
                                      <h4 class="mb-0">{{dashboard_details['total_user']}}</h4>
                                  </div>
    
                                  <div class="flex-shrink-0 align-self-center">
                                      <div class="mini-stat-icon avatar-sm rounded-circle bg-primary">
                                          <span class="avatar-title">
                                              <i class="bx bx-user font-size-24"></i>
                                          </span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-3" v-if="AUTH_USER.partner_reseller_id == null">
                      <div class="card mini-stats-wid">
                          <div class="card-body">
                              <div class="d-flex">
                                  <div class="flex-grow-1">
                                      <p class="text-muted fw-medium">What's New</p>
                                      <h4 class="mb-0">{{dashboard_details['total_whatsnew']}}</h4>
                                  </div>
    
                                  <div class="flex-shrink-0 align-self-center">
                                      <div class="mini-stat-icon avatar-sm rounded-circle bg-primary">
                                          <span class="avatar-title">
                                              <i class="bx bxs-megaphone font-size-24"></i>
                                          </span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-3" v-if="AUTH_USER.partner_reseller_id == null">
                      <div class="card mini-stats-wid">
                          <div class="card-body">
                              <div class="d-flex">
                                  <div class="flex-grow-1">
                                      <p class="text-muted fw-medium">SRA Question</p>
                                      <h4 class="mb-0">{{dashboard_details['total_sra']}}</h4>
                                  </div>
    
                                  <div class="flex-shrink-0 align-self-center">
                                      <div class="mini-stat-icon avatar-sm rounded-circle bg-primary">
                                          <span class="avatar-title">
                                              <i class="bx bx-question-mark font-size-24"></i>
                                          </span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-3" v-if="AUTH_USER.partner_reseller_id == null">
                      <div class="card mini-stats-wid">
                          <div class="card-body">
                              <div class="d-flex">
                                  <div class="flex-grow-1">
                                      <p class="text-muted fw-medium">Ongoing Question</p>
                                      <h4 class="mb-0">{{dashboard_details['total_og']}}</h4>
                                  </div>
    
                                  <div class="flex-shrink-0 align-self-center">
                                      <div class="mini-stat-icon avatar-sm rounded-circle bg-primary">
                                          <span class="avatar-title">
                                              <i class="bx bx-infinite font-size-24"></i>
                                          </span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-3" v-if="AUTH_USER.partner_reseller_id == null">
                      <div class="card mini-stats-wid">
                          <div class="card-body">
                              <div class="d-flex">
                                  <div class="flex-grow-1">
                                      <p class="text-muted fw-medium">Training</p>
                                      <h4 class="mb-0">{{dashboard_details['total_training']}}</h4>
                                  </div>
    
                                  <div class="flex-shrink-0 align-self-center">
                                      <div class="mini-stat-icon avatar-sm rounded-circle bg-primary">
                                          <span class="avatar-title">
                                              <i class="bx bxs-graduation font-size-24"></i>
                                          </span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-3" v-if="AUTH_USER.partner_reseller_id == null">
                      <div class="card mini-stats-wid">
                          <div class="card-body">
                              <div class="d-flex">
                                  <div class="flex-grow-1">
                                      <p class="text-muted fw-medium">Promocode</p>
                                      <h4 class="mb-0">{{dashboard_details['total_promocode']}}</h4>
                                  </div>
    
                                  <div class="flex-shrink-0 align-self-center">
                                      <div class="mini-stat-icon avatar-sm rounded-circle bg-primary">
                                          <span class="avatar-title">
                                              <i class="bx bx bxs-gift font-size-24"></i>
                                          </span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-3" v-if="AUTH_USER.partner_reseller_id == null && dashboard_details['total_badge_data'] > 0">
                      <div class="card mini-stats-wid">
                          <div class="card-body">
                              <div class="d-flex">
                                  <div class="flex-grow-1">
                                      <p class="text-muted fw-medium">Download Badge Report</p>
                                      <h4 class="mb-0"> &nbsp;</h4>
                                  </div>
    
                                  <div class="flex-shrink-0 align-self-center" style="cursor: pointer;" v-on:click="downloadBadgeUserReport()" title="Download Badge Report">
                                      <div class="mini-stat-icon avatar-sm rounded-circle bg-primary">
                                          <span class="avatar-title">
                                              <i class="bx bx bxs-download font-size-24"></i>
                                          </span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
      </div>
      <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
    </template>
    
    <script scoped>
    import axios from "axios";
    import toastr from "toastr";
    import "toastr/toastr.scss";
    toastr.options.preventDuplicates = true;
    
    import fullPageLoader from "../../common/fullPageLoader.vue";
    export default {
      data() {
        return {
          JS_APP_URL: JS_APP_URL,
          JS_WORDPRESS_URL: JS_WORDPRESS_URL,
          is_full_page_loader_shown: false,
          dashboard_details: [],
          AUTH_USER: AUTH_USER
        };
      },
      components: {
        fullPageLoader,
      },
      validations: {
      },
      mounted() {
        this.getDashboardDetails(); 
      },
      watch: {},
      computed: {},
      methods: {
        getDashboardDetails() {
          this.is_full_page_loader_shown = true;
          axios
            .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/dashboard/get-dashboard-details")
            .then((response) => {
              if (response["data"]["status"] == "Success") {
                this.dashboard_details = response.data.data;
              }
            })
            .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
              }
            })
            .then(() => {
              this.is_full_page_loader_shown = false;
            });
        },
        downloadBadgeUserReport() {
            window.location.href =
            JS_APP_URL +
            "/pkO0OA17otP61RwETtNn/dashboard/download-user-badge-email"
        }
      },
    };
    </script>
    