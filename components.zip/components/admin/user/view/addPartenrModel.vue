<template>
    <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask">
                <div class="modal-wrapper animate__animated animate__zoomIn">
                    <div class="modal-container">
                        <div
                            v-if="!is_add_btn_disabled"
                            @click="$emit('close-modal')"
                            class="cursor-pointer modal-close"
                        >
                            <close-icon></close-icon>
                        </div>
                        <div class="text-start mb-4">
                            <h3> Partner(s) </h3>
                        </div>
                        <div class="row margin0">
                            <form @submit.prevent="addPartners">
                                <div class="row mb-1">
                                    <label class="col-sm-4 col-form-label text-end">
                                        Select partners (Max 2)
                                    </label>
                                    <div class="col-sm-8">
                                        <tags-input 
                                            element-id="partners"   
                                        :existing-tags="all_partner_list"
                                            placeholder="Select partners (Max 2)"
                                            v-model="partner_obj"
                                            id-field="id"
                                            text-field="name"
                                            :limit=2
                                            :typeahead="true"
                                            typeahead-style="dropdown"
                                            :typeahead-show-on-focus="true"
                                            discard-search-text="Discard Search Results"
                                            :typeahead-hide-discard="true"
                                            :typeahead-max-results=0
                                            :typeahead-activation-threshold=0
                                            :only-existing-tags="true"
                                        ></tags-input>
                                    </div>
                                    <div class="col-sm-11 mt-3">
                                        <button :disabled="is_add_btn_disabled" type="submit" class="btn btn-dark w-md">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </Teleport>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import closeIcon from "../../common/icons/closeIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import "@james090500/vue-tagsinput/dist/style.css";
import _ from "lodash";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            is_btn_disabled: false,
            is_add_btn_disabled: false,
            partner_obj: [],
            new_partner: [],
            old_partner: [],
        };
    },
    props: {
        user_id: {
            type: Number
        },
        selected_user_partner: {
            type: Array,
            default: () => []
        },
        all_partner_list: {
            type: Array,
            default: () => []
        }
    },
    emits: ["user-partner-modify", "close-modal"],
    components: { closeIcon },
    mounted() {
        this.partner_obj = this.selected_user_partner.map((val) => ({
            id: val.partner.id,
            name: val.partner.name,
        }));
    },
    methods: {
        addPartners() {
            NProgress.start();
            this.is_add_btn_disabled = true;
            _.forEach(this.selected_user_partner, (value)=> {
                if (
                    _.isUndefined(
                        _.find(this.partner_obj, (o)=> {
                            return o.name == value.partner.name;
                        })
                    )
                ) {
                    this.old_partner.push({ partner_id: value.partner.id });
                }
            });
            _.forEach(this.partner_obj, (value)=> {
                if (
                    _.isUndefined(
                        _.find(this.selected_user_partner, (o)=> {
                            return o.partner.name == value.name;
                        })
                    )
                ) {
                    this.new_partner.push({ partner_id: value.id });
                }
            });
            axios
                .post(JS_APP_URL + "/pkO0OA17otP61RwETtNn/user/add-partner", {
                    user_id: this.user_id,
                    partner_id_list_old: this.old_partner,
                    partner_id_list_new: this.new_partner,
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if (response["data"]["data"].length > 0) {
                            toastr.error(
                                response["data"]["data"].join("</br>"),
                                "Error"
                            );
                        } else {
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        this.$emit("user-partner-modify");
                        this.$emit("close-modal");
                        toastr.success(response["data"]["message"], "Success");
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.is_add_btn_disabled = false;
                });
        },
    },
    created () {
        // document.body.classList.add("modal-open");
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27 && !this.is_add_btn_disabled) {
                this.$emit("close-modal");
            }
        });
    },
    destroyed() {
        // document.body.classList.remove("modal-open");
    },
};
</script>
