<template>
    <div class="expand_div table-responsive">
        <p v-if="user.renewal_estimation_amount_recieved == 'no'" class="text-center text-danger">* We unable to fetch values for Amount, Charge amount, Sales tax, Promo code fields. Please check this customer/user account details on Chargebee for more details.</p>
        <table
            id="expand_table"
            cellspacing="2"
            cellpadding="10"
            class="table-fixed"
        >
            <tbody>
                <tr>
                    <td class="text-center fw-bold">ACCOUNT</td>
                    <td class="text-center">
                        <span
                            class="btn btn-xs label-rounded cursor-pointer btn-sm"
                            :class="
                                user.user_details.is_account_verified == 1
                                    ? 'btn-success'
                                    : 'btn-danger'
                            "
                            @click="
                                userModifyModelToggle(
                                    'account_verified_status',
                                    user.user_details.is_account_verified
                                )
                            "
                        >
                            {{
                                user.user_details.is_account_verified != 0
                                    ? "VERIFIED"
                                    : "UNVERIFIED"
                            }}
                        </span>
                    </td>
                    <td class="text-center fw-bold">LOCATION(S)</td>
                    <td class="text-center">
                        <span
                            class="btn btn-xs btn-info label-rounded cursor-pointer btn-sm"
                            @click="locations()"
                        >
                            {{ user.user_details.locations_count }} / {{ user.location_limit }}
                           
                        </span>
                    </td>
                    <td class="text-center fw-bold">PAYMENT FREEZE</td>
                    <td class="text-center">
                        <span
                            class="btn btn-xs label-rounded btn-sm"
                            :class="
                                user.user_details.account_status == 'Unfrozen'
                                    ? 'btn-success'
                                    : 'btn-danger'
                            "
                            @click="
                                userModifyModelToggle(
                                    'payment_freeze_status',
                                    user.user_details.account_status
                                )
                            "
                        >
                            {{ user.user_details.account_status.toUpperCase() }}
                        </span>
                    </td>
                    <td class="text-center fw-bold">STATUS</td>
                    <td class="text-center">
                        <span
                            class="btn btn-xs label-rounded btn-sm"
                            :class="
                                user.user_details.is_active == 1
                                    ? 'btn-success'
                                    : 'btn-danger'
                            "
                        >
                            {{
                                user.user_details.is_active == 1
                                    ? "ACTIVE"
                                    : "INACTIVE"
                            }}
                        </span>
                    </td>
                </tr>
                <tr>
                    <td class="text-center fw-bold">PROMO</td>
                    <td class="text-center">
                        <span class="btn btn-xs btn-dark label-rounded cursor-pointer btn-sm text-break" >
                            {{
                                user.user_promocode == null
                                    ? "N/A"
                                    : user.user_promocode.promo_code +
                                      " | " +
                                      user.user_promocode.discount_percentage +
                                      "%"
                            }}
                        </span>
                    </td>
                    <td class="text-center fw-bold">AMOUNT($)</td>
                    <td class="text-center">
                        <span class="label-normal"> {{ user.amount }} </span>
                    </td>
                    <!-- <td class="text-center fw-bold">TRANSACTION FEE($)</td>
                    <td class="text-center">
                        <span class="label-normal"> {{ user.next_transaction_fee }} </span>
                    </td> -->
                    <td class="text-center fw-bold">SALES TAX</td>
                    <td class="text-center">
                        <span class="label-normal">
                            {{ user.sale_tax_amount }}({{ user.sale_tax_per }}%)
                        </span>
                    </td>
                </tr>
                <tr>
                    <td class="text-center fw-bold">PAYMENT TYPE</td>
                    <td class="text-center">
                        <span class="btn btn-xs btn-info label-rounded cursor-pointer btn-sm">
                            {{ (user.plan_type == "biannually") ? "BI-ANNUALLY" : user.plan_type.toUpperCase()}}</span>
                    </td>
                    <td class="text-center fw-bold">CHARGE AMOUNT</td>
                    <td class="text-center">
                        <span class="btn btn-xs btn-primary label-rounded cursor-pointer btn-sm">
                            $ {{ user.charge_amount }}
                        </span>
                    </td>
                    <td class="text-center fw-bold">EMPLOYEE(S)</td>
                    <td class="text-center" v-if="user.user_details.is_sra_user == 1">
                        <span
                            class="btn btn-xs btn-info label-rounded  btn-sm"
                        >
                            N/A
                            
                        </span>
                    </td>
                    <td class="text-center" v-else>
                        <span
                            class="btn btn-xs btn-info label-rounded cursor-pointer btn-sm"
                            @click="employeeListModalToggle()"
                        >
                            {{ user.user_details.employees_count }} / {{ user.employee_limit }}
                            
                        </span>
                    </td>
                    <td class="text-center fw-bold">ACCOUNT USER(S)</td>
                    <td class="text-center">
                        <span
                            class="btn btn-xs btn-primary label-rounded cursor-pointer btn-sm"
                            @click="accountUserListModalToggle()"
                        >
                            {{ user.user_details.account_users_count }}
                        </span>
                    </td>
                </tr>
                <tr>
                    <td class="text-center fw-bold">BUSINESS ASSOCIATE(S)</td>
                    <td class="text-center" v-if="user.user_details.is_sra_user == 1">
                        <span
                            class="btn btn-xs btn-dark label-rounded btn-sm"
                        >
                           N/A
                        </span>
                    </td>
                    <td class="text-center" v-else>
                        <span
                            class="btn btn-xs btn-dark label-rounded cursor-pointer btn-sm"
                            @click="businessAssociateListModalToggle()"
                        >
                            {{ user.user_details.business_associates_count }}
                        </span>
                    </td>
                    <td class="text-center fw-bold">Last Login</td>
                    <td class="text-center">
                        <span
                            v-if="user.user_details.last_login_details"
                            class="label-normal"
                        >
                        {{ $filters.formatDateTime(user.user_details.last_login_details.created_at) }}
                        </span>
                        <span
                            v-if="!user.user_details.last_login_details"
                            class="label-normal"
                        >
                            -
                        </span>
                    </td>
                    <td class="text-center fw-bold">
                        <span
                            class="btn btn-xs btn-primary label-rounded cursor-pointer btn-sm"
                            @click="viewUserAccount()"
                        >
                            View Account
                        </span>
                    </td>
                    <td class="text-center fw-bold">TAG(S)</td>
                    <td
                        class="text-center"
                        v-if="user.user_details.user_tags.length > 0"
                    >
                        <span
                            v-for="(tag, index) in user.user_details.user_tags"
                            :key="index"
                        >
                            {{ tag.tag_name
                            }}{{
                                user.user_details.user_tags.length - 1 != index
                                    ? ","
                                    : ""
                            }}
                        </span>
                    </td>
                    <td class="text-center" v-else>
                        <span class="label-normal"> - </span>
                    </td>
                    <td class="text-center">
                        <a title="Edit" @click="addTagModalToggle" class="btn"
                            ><i
                                class="bx bxs-edit font-size-22 align-middle me-0"
                            ></i
                        ></a>
                    </td>
                </tr>
                <tr>
                    <td class="text-center fw-bold">PARTNER(S)</td>
                    <td
                        colspan="2"
                        class="text-center"
                        v-if="user.user_details.user_partners.length > 0"
                    >
                        <span
                            v-for="(partner, index) in user.user_details.user_partners"
                            :key="index"
                        >
                            {{ partner.partner.name
                            }}{{
                                user.user_details.user_partners.length - 1 != index
                                    ? ","
                                    : ""
                            }}
                        </span>
                    </td>
                    <td class="text-center" v-else colspan="2">
                        <span class="label-normal"> - </span>
                    </td>
                    <td class="text-center">
                        <a
                            title="Edit"
                            @click="addPartnerModalToggle"
                            class="btn"
                            ><i
                                class="bx bxs-edit font-size-22 align-middle me-0"
                            ></i
                        ></a>
                    </td>

                    <td v-if="user.user_details.is_educational_account == 1" class="text-center fw-bold">STUDENT(S)</td>
                    <td v-if="user.user_details.is_educational_account == 1" class="text-center">
                        <span
                            class="btn btn-xs btn-info label-rounded cursor-pointer btn-sm"
                            @click="studentListModalToggle()"
                        >
                            {{ user.user_details.students_count }}
                        </span>
                    </td>
                </tr>
            </tbody>
        </table>
        <modify-user-details-model
            v-if="is_modify_modal_shown"
            @close-modal="is_modify_modal_shown = false"
            @user-detail-modify="userDetailModify"
            :call_from="call_from"
            :user_value="user_value"
            :user_id="user.user_details.id"
        />
        <employee-list-model
            v-if="is_employee_list_model_show"
            :user_id="user.user_details.id"
            @full-loader="fullLoader"
            @close-modal="employeeListModalToggle"
        />
        <account-user-list-model
            v-if="is_account_user_list_model_show"
            :user_id="user.user_details.id"
            @full-loader="fullLoader"
            @close-modal="accountUserListModalToggle"
        />
        <business-associate-list-model
            v-if="is_business_associate_list_model_show"
            :user_id="user.user_details.id"
            @full-loader="fullLoader"
            @close-modal="businessAssociateListModalToggle"
        />
        <add-tags-model
            v-if="is_add_tag_model_show"
            :user_id="user.user_details.id"
            :tags_details="user.user_details.user_tags"
            @close-modal="addTagModalToggle"
            @user-tag-modify="userTagModify"
        />
        <add-Partenr-model
            v-if="is_add_partner_model_show"
            :user_id="user.user_details.id"
            :selected_user_partner="user.user_details.user_partners"
            :all_partner_list="partner_list"
            @close-modal="addPartnerModalToggle"
            @user-partner-modify="userTagModify"
        />
        <student-list-model
            v-if="is_student_list_model_show"
            :user_id="user.user_details.id"
            @full-loader="fullLoader"
            @close-modal="studentListModalToggle"
        />
        <user-login-warning-model
            v-if="is_user_login_warning_modal_shown"
            @close-modal="is_user_login_warning_modal_shown = false"
        />
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import modifyUserDetailsModel from "./modifyUserDetailsModel.vue";
//import billingModel from "./billingModel.vue";
import employeeListModel from "./employeeListModel.vue";
import accountUserListModel from "./accountUserListModel.vue";
import businessAssociateListModel from "./businessAssociateListModel.vue";
import addTagsModel from "./addTagsModel.vue";
import addPartenrModel from "./addPartenrModel.vue";
import studentListModel from "./studentListModel.vue";
import userLoginWarningModel from "./userLoginWarningModel.vue";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            call_from: "",
            user_value: "",
            is_modify_modal_shown: false,
            user_promocode_id: "",
            is_employee_list_model_show: false,
            is_student_list_model_show: false,
            is_account_user_list_model_show: false,
            is_business_associate_list_model_show: false,
            is_add_tag_model_show: false,
            is_add_partner_model_show: false,
            account_package_change_details: {},
            partner_list:[],
            is_user_login_warning_modal_shown: false,
        };
    },
    emits: ["full-loader","get-user-detail"],
    props: {
        user: {},
        search: "",
        selected_show_entry: "",
        page: "",
        sort_column: "",
        sort_order: "",
        filter_by: ""
    },
    components: {
        modifyUserDetailsModel,
        employeeListModel,
        accountUserListModel,
        businessAssociateListModel,
        addTagsModel,
        addPartenrModel,
        studentListModel,
        userLoginWarningModel
    },
    mounted() {
        this.getPartnerList();
    },
    methods: {
        getPartnerList() {
            NProgress.start();
            axios
            .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/user/user-partner-list")
            .then((response) => {
            if(response["data"]["status"] == "Success") {
                this.partner_list = response["data"]["data"];
            }
            })
            .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
                window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/login";
            }
            })
            .then(() => {
                NProgress.done();
            });
        },
        fullLoader(status) {
            this.$emit("full-loader", status);
        },
        userModifyModelToggle(call_from = "", value) {
            this.call_from = call_from;
            (this.user_value = value), (this.is_modify_modal_shown = true);
        },
        userDetailModify() {
            this.$emit("get-user-detail", this.user.user_details.id);
            this.is_modify_modal_shown = false;
        },
        userTagModify() {
            this.$emit("get-user-detail", this.user.user_details.id);
        },
        userAccountPackageModify() {
            this.$emit("get-user-detail", this.user.user_details.id);
        },
        employeeListModalToggle() {
            if (this.is_employee_list_model_show == false) {
                this.is_employee_list_model_show = true;
            } else {
                this.is_employee_list_model_show = false;
            }
        },
        studentListModalToggle() {
            if (this.is_student_list_model_show == false) {
                this.is_student_list_model_show = true;
            } else {
                this.is_student_list_model_show = false;
            }
        },
        businessAssociateListModalToggle() {
            if (this.is_business_associate_list_model_show == false) {
                this.is_business_associate_list_model_show = true;
            } else {
                this.is_business_associate_list_model_show = false;
            }
        },
        accountUserListModalToggle() {
            if (this.is_account_user_list_model_show == false) {
                this.is_account_user_list_model_show = true;
            } else {
                this.is_account_user_list_model_show = false;
            }
        },
        addTagModalToggle() {
            if (this.is_add_tag_model_show == false) {
                this.is_add_tag_model_show = true;
            } else {
                this.is_add_tag_model_show = false;
            }
        },
        addPartnerModalToggle() {
            if (this.is_add_partner_model_show == false) {
                this.is_add_partner_model_show = true;
            } else {
                this.is_add_partner_model_show = false;
            }
        },
        locations() {
            const param = encodeURIComponent("search=" + this.search +
                "&selected_show_entry=" + this.selected_show_entry +
                "&page=" + this.page +
                "&sort_column=" + this.sort_column +
                "&sort_order=" + this.sort_order +
                "&filter_by=" + this.filter_by)
            window.location =
                JS_APP_URL +
                "/pkO0OA17otP61RwETtNn/location/view/" +
                this.user.user_details.id + "?" + param

        },
        viewUserAccount() {
            NProgress.start();
            axios
                .post(JS_APP_URL + "/pkO0OA17otP61RwETtNn/user/user-login-by-admin", {
                    user_id: this.user.user_details.id,
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if(response["data"]["data"]['is_user_logged_in'] == 1) {
                            this.is_user_login_warning_modal_shown = true
                        } else if (response["data"]["data"].length > 0) {
                            toastr.error(
                                response["data"]["data"].join("</br>"),
                                "Error"
                            );
                        } else {
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        window.open(JS_APP_URL + "/dashboard/", "_blank");
                        toastr.success(response["data"]["message"], "Success");
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                });
        },
    },
};
</script>
