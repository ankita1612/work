<template>
    <Teleport to="body">
        <transition name="modal">
        <div class="modal-mask">
          <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
              <div @click="$emit('close-modal')" class="cursor-pointer modal-close">
                <close-icon></close-icon>
              </div>
              <div class="text-center">
                <i class="bx bx-error-circle text-muted display-2"></i>
              </div>
              <p class="text-center mb-4 mt-4">We found that you are currently logged in with one of the account. Please click below link that will open a new tab of currently logged in account then please logout that account and come again here to log in to new customer account.</p>
              <p class="text-center mb-4 mt-4"><a :href="JS_APP_URL" @click="$emit('close-modal')" target="_blank">{{ JS_APP_URL }}</a></p>
              <div class="flex flex-wrap items-center justify-center pb40">
                 <button
                 class="btn btn-dark"
                  @click="$emit('close-modal')"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
        </transition>
    </Teleport>

    </template>

<script scoped>
import closeIcon from '../../common/icons/closeIcon.vue';
export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
        }
    },
    emits: ["close-modal"],
    components:{closeIcon},
}
</script>