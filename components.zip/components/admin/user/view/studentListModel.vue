<template>
<Teleport to="body">
    <transition name="modal">
        <div class="modal-mask pdf-modal-mask">
            <div class="pdf-modal-overlay"></div>
            <div
                class="modal-wrapper animate__animated animate__zoomIn w-50"
                :class="{ 'h-100': students.length > 3 }"
            >
                <div class="modal-container">
                    <div
                        v-on:click="$emit('close-modal')"
                        class="cursor-pointer modal-close"
                    >
                        <close-icon></close-icon>
                    </div>
                    <div class="text-start mb-4">
                        <h3>Students</h3>
                    </div>
                    <div
                        v-for="(student, index) in students"
                        :key="index"
                        class="card m-3 p-2 mt-5 bg-light"
                    >
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Name</label>
                                <p class="m-0">
                                    {{ student.first_name }}
                                    {{ student.last_name }}
                                </p>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Email</label>
                                <p class="m-0">{{ student.email }}</p>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Primary Education Location</label>
                                <p class="m-0">
                                    {{
                                        student.student_primary_work_location
                                            .location_nickname
                                    }}
                                </p>
                            </div>
                        </div>
                    </div>
                    <div v-if="students.length == 0">No student(s) available</div>
                </div>
            </div>
        </div>
    </transition>
</Teleport>
</template>
<script scoped>
import axios from "axios";
import closeIcon from "../../common/icons/closeIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import _ from "lodash";

export default {
    data() {
        return {
            students: {},
        };
    },
    props: {
        user_id: {},
    },
    emits: ["full-loader", "close-modal"],
    components: { closeIcon },
    mounted() {
        this.getStudent();
    },
    methods: {
        getStudent() {
            this.$emit("full-loader", true);
            axios
                .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/user/get-student/" + this.user_id)
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        let data = response.data.data;
                        this.students = data;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    this.$emit("full-loader", false);
                });
        },
        openAccessBlock(id) {
            var x = document.getElementById(id);
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        },
    },
    created() {
        // document.body.classList.add("modal-open");
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27) {
                this.$emit("close-modal");
            }
        });
    },
    destroyed() {
        // document.body.classList.remove("modal-open");
    },
};
</script>

<style></style>
