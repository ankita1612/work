<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <div
                class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                "
              >
                <h4 class="mb-sm-0 font-size-18">Users List</h4>
              </div>
            </div>
            <div class="col-sm-12 col-md-6 text-end">
              <label class="font-size-14">Select year:</label>
              <select
                v-model="selected_year"
                class="
                  form-select
                  w-auto
                  ms-2
                  me-2
                  d-inline-block
                ">
                  <option :value="year" v-for="year in export_year_List" :key="year">{{year}}</option>
                </select>
              <button class="btn btn-sm btn-info btn-rounded" @click="exportUserList">Export User List</button>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <div class="row mb-2">
                    <div class="col-sm-12 col-md-2">
                      <div>
                        <label
                          >Show
                          <select
                            v-model.trim="selected_show_entry"
                            @change="onChangeShowEntry()"
                            class="
                              custom-select custom-select-sm
                              form-control
                              form-control-sm
                              form-select
                              form-select-sm
                              d-inline-block
                              w-auto
                              ms-2
                              me-2
                            "
                          >
                            <option :value="entry" v-for="entry in show_entry_list" :key="entry">{{entry}}</option>
                          </select>
                          entries
                        </label>                        
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-4">
                        <a href="javascript:void(0)" class="btn btn-light btn-sm ms-3" :class="{'btn-dark':filter_users == 'active' }" role="button" @click="applyFilter('active')">ACTIVE</a>
                        <a href="javascript:void(0)" class="btn btn-light btn-sm ms-3" :class="{'btn-dark':filter_users == 'inactive' }" role="button" @click="applyFilter('inactive')">INACTIVE</a>
                        <a href="javascript:void(0)" class="btn btn-light btn-sm ms-3" :class="{'btn-dark':filter_users == 'frozen' }" role="button" @click="applyFilter('frozen')">FROZEN</a>
                    </div>
                    <div class="col-sm-12 col-md-6 text-end">
                      <div>
                        <label class="mb-0"
                          ><span>Search:</span
                          ><input
                            type="text"
                            class="
                              form-control form-control-sm
                              d-inline-block
                              w-auto
                              ms-2
                            "
                            v-model.trim="search"
                            @input="applySearch()"
                            placeholder="Search"
                        /></label>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-xl-12">
                      <table
                        class="
                          table table-responsive table-bordered
                          mb-0
                          dataTable
                          table-fixed
                        "
                      >
                        <thead class="table-light">
                          <tr>
                            <th
                              v-for="column in columns"
                              :key="column.id"
                              @click="sortByColumn(column.id)"
                              class="sorting"
                              :class="[(column.id === sort_column)?(sort_order == 'asc')?'sorting_asc':'sorting_desc':'']"
                            >
                              {{ column.text }}
                            </th>
                            <th>ACTION</th>
                          </tr>
                        </thead>
                        <user-list v-for="(user, index) in users" :key="index"
                        :user="user"
                        :search="search"
                        :selected_show_entry="selected_show_entry"
                        :page="current_page"
                        :sort_column="sort_column"
                        :sort_order="sort_order"
                        :filter_by="filter_users"
                        @full-loader-toggle="fullLoaderToggle"
                        :expand_toggle_flag="expand_toggle_flag" />
                        <tbody v-if="users.length == 0">
                          <tr>
                            <td colspan="5" class="text-center">
                              No records available!
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="row mt-3">
                    <div class="col-xl-12">
                      <pagination 
                      v-if="users.length > 0"
                      :current_page="current_page"
                      :total_page="total_page"
                      :pagination_links="pagination_links"
                      @change-page="changePage"
                      >
                      </pagination>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from "lodash";
import fullPageLoader from "../../common/fullPageLoader.vue";
import pagination from "../../common/pagination.vue";
import userList from './userlist.vue'


export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      is_full_page_loader_shown: false,
      users: [],
      search: null,
      filter_users: '',
      total_page: "",
      current_page: 1,
      pagination_links: [],
      per_page: "",
      selected_show_entry: 10,
      show_entry_list: [10, 25, 50, 100],
      sort_column: "created_at",
      sort_order: "desc",
      columns: [{"id": "company_name", "text": "Practice Name"}, {"id": "first_name", "text": "Primary Contact Name"}, {"id": "email", "text": "Email"}, {"id": "created_at", "text": "Sign Up Date"}, {"id": "reseller_name", "text": "Signup Partner"}, {"id": "is_sra_user", "text": "SRA Only"}],
      is_expand_shown: false,
      expand_toggle_flag: 0,
      selected_year: 2016,
      export_year_List:[]
    };
  },
  components: {
    fullPageLoader,
    pagination,
    userList
  },
  watch: {
  },
  computed: {},

  created() {
    let uri = window.location.search.substring(1);
    uri = decodeURIComponent(uri);
    let params = new URLSearchParams(uri);
    if( params.has('search') ){
        this.search = params.get('search');
        this.search = this.search == 'null' ? "" : this.search
    }
    if( params.has('selected_show_entry') ){
        this.selected_show_entry = params.get('selected_show_entry');
    }
    if( params.has('page') ){
        this.current_page = params.get('page');
    }
    if( params.has('sort_column') ){
        this.sort_column = params.get('sort_column');
    }
    if( params.has('sort_order') ){
        this.sort_order = params.get('sort_order');
    }
    if( params.has('filter_by') ){
        this.filter_users = params.get('filter_by');
    }
  },

  mounted() {
    this.getUsersList();
    this.getYears();
  },
  methods: {
    onChangeShowEntry(){
      this.current_page = 1;
      this.getUsersList();
    },
    fullLoaderToggle(status){
      this.is_full_page_loader_shown = status;
    },
    getUsersList() {
     this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/user/user-list", {
          params: {
            search: this.search,
            selected_show_entry: this.selected_show_entry,
            page: this.current_page,
            sort_column: this.sort_column,
            sort_order: this.sort_order,
            filter_by: this.filter_users
          },
        })
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            let data = response.data.data;
            this.users = data.data;
            this.current_page = data.current_page;
            this.total_page = data.last_page;
            this.per_page = data.per_page;
            this.pagination_links = data.links;
            this.expand_toggle_flag ++;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    sortByColumn(column) {
      if (column === this.sort_column) {
        this.sort_order = this.sort_order === "asc" ? "desc" : "asc";
      } else {
        this.sort_column = column;
        this.sort_order = "asc";
      }
      this.getUsersList();
    },
    changePage(page) {
      this.current_page = page;
      this.getUsersList();
    },
    applySearch() {
      this.current_page = 1;
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      this.timer = setTimeout(() => {
        this.getUsersList();
      }, 500);
    },
    applyFilter(filter_value) {
      if(this.filter_users != filter_value){
        this.filter_users = filter_value;
      }else{
        this.filter_users = "";
      }
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      this.timer = setTimeout(() => {
        this.getUsersList();
      }, 500);
    },
    getYears() {
      var current_year = new Date().getFullYear();
      for(var i = this.selected_year; i <= current_year; i++) {
        this.export_year_List.push(i);
      }
      return this.export_year_List;
    },
    exportUserList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + '/pkO0OA17otP61RwETtNn/user/export-users', {
          params: {
            year: this.selected_year,
          }
        })
        .then((response) => {
          var link = document.createElement('a');
          link.href = response['data']['data']['file'];
          link.download = response['data']['data']['name'];
          link.click();
          link.remove();
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    }
  },
};
</script>