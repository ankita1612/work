import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import VueTagsInput from '@james090500/vue-tagsinput';
import userView from "./view.vue";
import app from "../../common/includes/App.vue"
import moment from 'moment'
const view_app = createApp({
    template: `
    <app>
    <user-view></user-view>
    </app>
    `,
    components: {
        app,
        'user-view': userView,
    }
});


view_app.use(useVuelidate);
view_app.component('multiselect', Multiselect);
view_app.component('tags-input', VueTagsInput);
view_app.config.globalProperties.$filters = {
    formatDate(value) {
        if (value) {
            return moment.utc(String(value)).local().format("MM/DD/YYYY");
        }
    },
    formatDateTime(value) {
        if (value) {
            return moment.utc(String(value)).local().format("MM/DD/YYYY hh:mm A");
        }
    },
}
view_app.mount("#view_app");