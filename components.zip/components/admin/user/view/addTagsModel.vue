<template>
    <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask">
                <div class="modal-wrapper animate__animated animate__zoomIn">
                    <div class="modal-container">
                        <div v-if="!is_add_btn_disabled" @click="$emit('close-modal')" class="cursor-pointer modal-close">
                            <close-icon></close-icon>
                        </div>
                        <div class="text-start mb-4">
                            <h3> Tag(s) </h3>
                        </div>
                        <div class="row margin0">
                            <form @submit.prevent="addTags">
                                <div class="row mb-1">
                                    <div class="col-sm-8">
                                        <tags-input 
                                            v-model="tags"
                                            text-field="tag_name"
                                            :add-tags-on-blur="true"
                                            :limit=10
                                        ></tags-input>
                                    </div>
                                    <div class="col-sm-4">
                                        <button :disabled="is_add_btn_disabled" type="submit" class="btn btn-dark w-md">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </Teleport>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import closeIcon from '../../common/icons/closeIcon.vue';
import toastr from "toastr";
import "toastr/toastr.scss";
import "@james090500/vue-tagsinput/dist/style.css"
import _ from "lodash";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            is_btn_disabled: false,
            is_add_btn_disabled: false,
            tags:[],
            remove_tags:[],
            add_tage:[],
        }
    },
    props: {
        user_id:{},
        tags_details:{}
    },
    emits: ["user-tag-modify", "close-modal"],
    components:{closeIcon},
    mounted() {
        this.tags = this.tags_details
    },
    methods: {
        addTags(){
            NProgress.start();
            this.is_add_btn_disabled = true;
            _.forEach(this.tags_details, (value)=> {
                if(_.isUndefined( _.find(this.tags, (o)=> { return o.tag_name.toLowerCase() == value.tag_name.toLowerCase(); }))){
                    this.remove_tags.push(value.id);
                }
            });
            _.forEach(this.tags, (value)=> {
                if(_.isUndefined( _.find(this.tags_details, (o)=> { return o.tag_name.toLowerCase() == value.tag_name.toLowerCase(); }))){
                    this.add_tage.push({"tag_name": value.tag_name});
                }
            });
            axios
                .post(JS_APP_URL + "/pkO0OA17otP61RwETtNn/user/add-user-tag", {
                    add_tags: this.add_tage,
                    remove_tags:this.remove_tags,
                    user_id: this.user_id ,
                })
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if (response["data"]['data'].length > 0) {
                            toastr.error(response["data"]['data'].join('</br>'), "Error");
                        } else {
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        this.$emit("user-tag-modify");
                        this.$emit("close-modal");
                        toastr.success(response["data"]["message"], "Success");
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.is_add_btn_disabled = false;
                })
        }
    },
    created () {
        // document.body.classList.add('modal-open');
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27 && !this.is_add_btn_disabled) {
            this.$emit("close-modal");
            }
        });
    },
    destroyed(){
        // document.body.classList.remove('modal-open');
    }
}
</script>