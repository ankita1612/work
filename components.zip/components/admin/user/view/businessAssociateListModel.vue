<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask pdf-modal-mask">
        <div class="pdf-modal-overlay"></div>
        <div
          class="modal-wrapper animate__animated animate__zoomIn w-50"
          :class="{ 'h-100': business_associates.length > 3 }"
        >
          <div class="modal-container">
            <div
              @click="$emit('close-modal')"
              class="cursor-pointer modal-close"
            >
              <close-icon></close-icon>
            </div>
            <div class="text-start mb-4">
              <h3>Business Associates</h3>
            </div>
            <div v-for="(business_associate, index) in business_associates" :key="index" class="card m-3 p-2 mt-5 bg-light">
              <div class="row g-3">
                <div class="col-md-4">
                  <label class="form-label">Name</label>
                  <p class="m-0"> {{ business_associate.name }} </p>
                </div>
                <div class="col-md-4">
                  <label class="form-label">Email</label>
                  <p class="m-0"> {{ business_associate.email }} </p>
                </div>
                <div class="col-md-2">
                  <label class="form-label">Phone Number</label>
                  <p class="m-0"> {{ business_associate.phone_number }} </p>
                </div>
                <div class="col-md-2">
                  <label class="form-label">Expiration date</label>
                  <p class="m-0"  v-if="business_associate.expired_date != null &&  business_associate.expired_date != '' && business_associate.expired_date != 'null'"> {{ $filters.formatDate(business_associate.expired_date) }}</p>
                  <p class="m-0" v-else>None</p>
                </div>

              </div>
            </div>
            <div v-if="business_associates.length == 0">No business associate(s) available!</div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>
<script scoped>
import axios from "axios";
import closeIcon from "../../common/icons/closeIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import _ from "lodash";

export default {
  data() {
    return {
      business_associates: {},
    };
  },
  props: {
    user_id: {},
  },
  emits: ["full-loader", "close-modal"],
  components: { closeIcon },
  mounted() {
    this.getBusinessAssociate();
  },
  methods: {
    getBusinessAssociate() {
      this.$emit("full-loader", true);
      axios
        .get(
          JS_APP_URL + "/pkO0OA17otP61RwETtNn/user/get-business-associate/" + this.user_id
        )
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            let data = response.data.data;
            this.business_associates = data;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.$emit("full-loader", false);
        });
    },
    workLocationArrayToString(location_array) {
      var location_string = null;
      _.forEach(location_array, (value)=> {
        if (location_string == null) {
          location_string = value.location.location_nickname;
        } else {
          location_string =
            location_string + "</br>" + value.location.location_nickname;
        }
      });
      return location_string;
    },
    openAccessBlock(id){
      var x = document.getElementById(id);
      if (x.style.display === "none") {
        x.style.display = "block";
      } else {
        x.style.display = "none";
      }
    }
  },
  created() {
    // document.body.classList.add("modal-open");
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-modal");
      }
    });
  },
  destroyed() {
    // document.body.classList.remove("modal-open");
  },
};
</script>

<style>
</style>
