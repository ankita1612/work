<template>
  <tbody>
    <tr>
      <td>{{ user.company_name }}</td>
      <td>{{ user.first_name }} {{ user.last_name }}</td>
      <td>{{ user.email }}</td>
      <td>{{ $filters.formatDate(user.created_at) }}</td>
      <td>{{ user.reseller_name ?? 'Abyde' }}</td>
      <td>{{ user.is_sra_user ? 'Yes' : 'No' }}</td>
      <td>
        <button
          @click="expandToggle(user.id)"
          class="btn btn-sm btn-info expand-btn"
          v-if="is_expand_shown == false"
        >
          EXPAND VIEW
        </button>
        <button
          @click="expandToggle(user.id)"
          class="btn btn-sm btn-dark expand-btn"
          v-else
        >
          EXPANDED
        </button>
      </td>
    </tr>
    <tr v-if="is_expand_shown">
      <td colspan="7">
        <expand-toggle :user=user_details 
        :search="search"
        :selected_show_entry="selected_show_entry"
        :page="page"
        :sort_column="sort_column"
        :sort_order="sort_order"
        :filter_by="filter_by"
        @full-loader="fullLoader"
        @get-user-detail=getUserDetail />
      </td>
    </tr>
  </tbody>
</template>

<script>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import expandToggle from "./expandToggle.vue";

export default {
  data() {
    return {
      is_expand_shown: false,
      user_details :[]
    };
  },
  emits: ["full-loader-toggle"],
  props: {
    user: {},
    expand_toggle_flag:{},
    search: "",
    selected_show_entry: "",
    page: "",
    sort_column: "",
    sort_order: "",
    filter_by: ""
  },
  watch:{
    expand_toggle_flag(){
        this.is_expand_shown = false;
    }
  },
  components: {
    expandToggle,
  },
  methods: {
    expandToggle(id) {
      if(this.is_expand_shown == false){
        this.getUserDetail(id);
      } else{
          this.is_expand_shown = false;
      } 
    },
    fullLoader(status){
      this.$emit("full-loader-toggle", status);
    },
    getUserDetail(id) {
      NProgress.start();
      this.$emit("full-loader-toggle", true);
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/user/user-details/" + id)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.user_details = response.data.data;
            this.is_expand_shown = true;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
          this.$emit("full-loader-toggle", false);
        });
    },
  },
};
</script>

<style>
</style>