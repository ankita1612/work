<template>
  <Teleport to="body">
  <transition name="modal">
    <div class="modal-mask pdf-modal-mask">
      <div class="pdf-modal-overlay"></div>
      <div
        class="modal-wrapper animate__animated animate__zoomIn w-50"
        :class="{ 'h-100': account_users.length > 3 }"
      >
        <div class="modal-container">
          <div
            @click="$emit('close-modal')"
            class="cursor-pointer modal-close"
          >
            <close-icon></close-icon>
          </div>
          <div class="text-start mb-4">
            <h3>Account Users</h3>
          </div>
          <div v-for="(accountUser, index) in account_users" :key="index" class="card m-3 p-2 mt-5 bg-light">
            <div class="row g-3">
              <div class="col-md-4">
                <label class="form-label">Name</label>
                <p class="m-0"> {{ fullname(accountUser) }} </p>
              </div>
              <div class="col-md-5">
                <label class="form-label">Email</label>
                <p class="m-0"> {{ accountUser.email }} </p>
              </div>
              <div class="col-md-3">
                <label class="form-label">Action</label>
                <button
                  type="button"
                  class="btn btn-dark form-control btn-sm"
                  @click="openAccessBlock('collapseAccountUser' + index)"
                >
                  Access
                </button>
              </div>
              <div class="collapse" :id="'collapseAccountUser' + index" style="display:none;">
                <div class="row">
                  <div class="col-md-6">
                    <div class="card card-body">
                      <div class="card-title">HCO LOCATION </div>
                      <div class="card-text">
                        <p class="m-0" v-html="accountUser.hipaa_compliance_officer.length > 0 ?
                            locationArrayToString(
                              accountUser.hipaa_compliance_officer
                            ) : 'N/A'">
                        </p>
                      </div>
                    </div>
                    
                  </div>
                  <div class="col-md-6">
                    <div class="card card-body">
                      <div class="card-title">LOCATION ACCESS </div>
                      <div class="card-text">
                        <p class="m-0" v-html="accountUser.account_location_access.length > 0 ?
                            locationArrayToString(
                              accountUser.account_location_access
                            ) : 'N/A'">
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div v-if="account_users.length == 0">No account user(s) available!</div>
          </div>
        </div>
      </div>
    </div>
    </transition>
  </Teleport>
</template>
<script scoped>
import axios from "axios";
import closeIcon from "../../common/icons/closeIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import _ from "lodash";

export default {
  data() {
    return {
      account_users: {},
    };
  },
  props: {
    user_id: {},
  },
  emits: ["full-loader", "close-modal"],
  components: { closeIcon },
  mounted() {
    this.getAccountUser();
  },
  methods: {
    getAccountUser() {
      this.$emit("full-loader", true);
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/user/get-account-user/" + this.user_id)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            let data = response.data.data;
            this.account_users = data;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.$emit("full-loader", false);
        });
    },
    fullname(option) {
      return `${option.first_name} ${option.last_name}`;
    },
    locationArrayToString(location_array) {
      var location_string = null;
      _.forEach(location_array, (value)=> {
        if (location_string == null) {
          location_string = value.location.location_nickname;
        } else {
          location_string =
            location_string + "</br>" + value.location.location_nickname;
        }
      });
      return location_string;
    },
    openAccessBlock(id){
      var x = document.getElementById(id);
      if (x.style.display === "none") {
        x.style.display = "block";
      } else {
        x.style.display = "none";
      }
    }
  },
  created () {
    // document.body.classList.add("modal-open");
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-modal");
      }
    });
  },
  destroyed() {
    // document.body.classList.remove("modal-open");
  },
};
</script>

<style>
</style>
