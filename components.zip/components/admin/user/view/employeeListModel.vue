<template>
  <Teleport to="body">
  <transition name="modal">
    <div class="modal-mask pdf-modal-mask">
      <div class="pdf-modal-overlay"></div>
      <div
        class="
          modal-wrapper
          animate__animated animate__zoomIn
          w-50
        "
        :class="{ 'h-100': employees.length > 3 }"
      >
        <div class="modal-container">
          <div
            @click="$emit('close-modal')"
            class="cursor-pointer modal-close"
          >
            <close-icon></close-icon>
          </div>
          <div class="text-start mb-4">
            <h3>Employees</h3>
          </div>
          <div v-for="(employee, index) in employees" :key="index" class="card m-3 p-2 mt-5 bg-light">
            <div class="row g-3">
              <div class="col-md-4">
                <label class="form-label">Name</label>
                <p class="m-0">
                  {{ employee.first_name }} {{ employee.last_name }}
                </p>
              </div>
              <div class="col-md-4">
                <label class="form-label">Email</label>
                <p class="m-0"> {{ employee.email }} </p>
              </div>
              <div class="col-md-2">
                <label class="form-label">Action</label>
                <button
                  type="button"
                  class="btn btn-dark form-control btn-sm"
                  @click="openAccessBlock('collapseAccountUser'+index)"
                >
                  Access
                </button>
              </div>
              <div class="collapse" :id="'collapseAccountUser' + index" style="display:none;">
                <div class="row">
                  <div class="col-md-6">
                    <div class="card card-body">
                      <div class="card-title">
                        <label>Primary Work Location : </label>
                      </div>
                      <div class="card-text">
                        <span>{{
                          employee.employee_primary_work_location
                            .location_nickname
                        }}</span>
                      </div>
                    </div>
                    
                  </div>
                  <div class="col-md-6">
                    <div class="card card-body">
                      <div class="card-title">
                        <label>Secondary Work Location : </label>
                      </div>
                      <div class="card-text">
                        <span v-html="employee.employee_secondary_work_location.length == 0? 'NA' :
                            secondaryWorkLocation(
                              employee.employee_secondary_work_location
                            )">
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div v-if="employees.length == 0">No employee(s) available</div>
          </div>
        </div>
      </div>
    </div>
    </transition>
  </Teleport>
</template>
<script scoped>
import axios from "axios";
import closeIcon from "../../common/icons/closeIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import _ from "lodash";

export default {
  data() {
    return {
      employees: {},
    };
  },
  props: {
    user_id: {},
  },
  emits: ["full-loader", "close-modal"],
  components: { closeIcon },
  mounted() {
    this.getEmployee();
  },
  methods: {
    secondaryWorkLocation(location_array) {
      var location_string = null;
      _.forEach(location_array, (value)=> {
        if (location_string == null) {
          location_string = value.location.location_nickname;
        } else {
          location_string =
            location_string + "</br>" + value.location.location_nickname;
        }
      });
      return location_string;
    },
    getEmployee() {
      this.$emit("full-loader", true);
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/user/get-employee/" + this.user_id)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            let data = response.data.data;
            this.employees = data;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.$emit("full-loader", false);
        });
    },
    openAccessBlock(id){
      var x = document.getElementById(id);
      if (x.style.display === "none") {
        x.style.display = "block";
      } else {
        x.style.display = "none";
      }
    }
  },
  created () {
    // document.body.classList.add("modal-open");
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-modal");
      }
    });
  },
  destroyed() {
    // document.body.classList.remove("modal-open");
  },
};
</script>

<style>
</style>
