import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import promocodeAdd from "./add.vue";
import app from "../../common/includes/App.vue"
const add_app = createApp({
    template: `
    <app>
    <promocode-add></promocode-add>
    </app>
    `,
    components: {
        app,
        'promocode-add': promocodeAdd,
    }
});
add_app.use(useVuelidate);
add_app.mount("#add_app");