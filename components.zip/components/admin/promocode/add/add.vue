<template>
    <div>
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                <h4 class="mb-sm-0 font-size-18">Add New Promo Code</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">
                                <div class="card-body">
                                    <form @submit.prevent="addPromocode">
                                        <div class="row mb-4" :class="{ 'form-group--error': v$.promo_code.$error }">
                                            <label for="horizontal-firstname-input"
                                                class="col-sm-2 col-form-label text-end">Promo Code</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" placeholder="Enter Promo Code"
                                                    id="horizontal-firstname-input" v-model.trim="v$.promo_code.$model">
                                                    <div v-if="v$.promo_code.$errors.length > 0">
                                                        <div class="form-error-text">
                                                            {{ v$.promo_code.$errors[0].$message }}
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4"
                                            :class="{ 'form-group--error': v$.discount_percentage.$error }">
                                            <label for="horizontal-firstname-input"
                                                class="col-sm-2 col-form-label text-end">Discount Percentage</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control"
                                                    placeholder="Enter Discount Percentage " id="horizontal-firstname-input"
                                                    v-model.trim="v$.discount_percentage.$model">
                                                    <div v-if="v$.discount_percentage.$errors.length > 0">
                                                        <div class="form-error-text">
                                                            {{ v$.discount_percentage.$errors[0].$message }}
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-sm-2 col-form-label text-end">Flash Sale End Date</label>
                                            <div class="col-sm-8">
                                                <date-picker class="form-control" v-model:value="flash_sale_end_date"
                                                    format="MM-DD-YYYY" valueType="YYYY-MM-DD" titleFormat="MM-DD-YYYY"
                                                    :editable="false" placeholder="Select Date"></date-picker>
                                                <br>    
                                                <span class="float-start text-primary fs-6 mt-2">* Please select date as per GMT timezone.</span>
                                            </div>
                                        </div>
                                       <div class="row mb-4">
                                            <label for="horizontal-email-input" class="col-sm-2 col-form-label text-end pt-0">User Type</label>
                                             <div class="col-sm-8">
                                                <input
                                                class="form-check-input"
                                                type="radio"
                                                id="user_type_normal"
                                                name="user_type"
                                                value="Normal"
                                                v-model="user_type"
                                                
                                                />
                                                <label class="form-check-label" for="user_type_normal">
                                                &nbsp;Normal
                                                </label>
                                                <input
                                                class="form-check-input ms-2"
                                                type="radio"
                                                id="user_type_reseller"
                                                name="user_type"
                                                value="Reseller"
                                                v-model="user_type"                                                
                                                />
                                                <label
                                                class="form-check-label"
                                                for="user_type_reseller"
                                                >
                                                &nbsp;Reseller
                                                </label>                                               
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-2">
                                            </div>
                                            <div class="col-sm-8">
                                                <div>
                                                    <button type="button" @click="backToView()"
                                                        class="btn btn-danger w-md">
                                                        CANCEL
                                                    </button>
                                                    &nbsp;
                                                    &nbsp;
                                                    <button :disabled="is_add_btn_disabled" type="submit"
                                                        class="btn btn-primary w-md">ADD</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import DatePicker from 'vue-datepicker-next';
import "vue-datepicker-next/index.css";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import moment from "moment";
import { required, decimal, between , helpers } from "@vuelidate/validators";
import { useVuelidate } from '@vuelidate/core';
import fullPageLoader from "../../common/fullPageLoader.vue";



export default {
    setup: () => ({ v$: useVuelidate() }),
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            TIYMCE_API_KEY: TIYMCE_API_KEY,
            promo_code: '',
            discount_percentage: '',
            flash_sale_end_date: '',
            is_add_btn_disabled: false,
            is_full_page_loader_shown: false,
            user_type: 'Normal',
        };
    },
    components: {
        fullPageLoader,
        DatePicker
    },
    validations(){
        return {
            promo_code : {
                required : helpers.withMessage("Please enter a promo code",required),
                isUnique : helpers.withMessage("Promo code already in use",
                helpers.withAsync(async (value) => {
                    if (!value) return true;
                    this.is_add_btn_disabled = true;
                    let check_promise = new Promise((resolve, reject) => {
                        if (this.check_promocode_available_timer) {
                            clearTimeout(this.check_promocode_available_timer)
                            this.check_promocode_available_timer = null
                        }
                        this.check_promocode_available_timer = setTimeout(() => {
                            return fetch(JS_APP_URL + `/pkO0OA17otP61RwETtNn/promocode/check-unique-promocode/${value}`).then(response => {
                                if (response.ok) {
                                    resolve(response.text())
                                } else {
                                    resolve(new Error('error'))
                                }
                            }, error => {
                                resolve(new Error('error'))
                            })
                        }, 500);
                    });
                    var response = await check_promise;
                    this.is_add_btn_disabled = false;
                    return Boolean((response == 'available') ? false : true);
                }))
            },
            discount_percentage : { 
                required : helpers.withMessage("Please enter a discount percentage",required),
                decimal : helpers.withMessage("Please enter only number",decimal),
                between : helpers.withMessage("Please enter value between 0 to 100",between(0,100))
            }
        }
    },
    mounted() { },
    watch: {},
    computed: {},
    methods: {
        addPromocode() {
            this.v$.$touch();
            if (!this.v$.$invalid) {
                NProgress.start();
                this.is_add_btn_disabled = true;
                axios.post(JS_APP_URL + "/pkO0OA17otP61RwETtNn/promocode/add-promocode", {
                    promo_code: this.promo_code,
                    discount_percentage: this.discount_percentage,
                    flash_sale_end_date: this.flash_sale_end_date ? this.flash_sale_end_date : null, 
                    user_type: this.user_type, 
                })
                    .then((response) => {
                        if (response["data"]["status"] == "Error") {
                            if (response["data"]['data'].length > 0) {
                                toastr.error(response["data"]['data'].join('</br>'), "Error");
                            } else {
                                toastr.error(response["data"]["message"], "Error");
                            }
                        } else {
                            toastr.success(response["data"]["message"], "Success");
                            setTimeout(() => {
                                window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/promocode/view";
                            }, 1000);
                        }
                    })
                    .catch((error) =>{
                        toastr.error(error.response["data"]["message"], "Error");
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
                        }
                    })
                    .then(()=> {
                        NProgress.done();
                        //this.is_add_btn_disabled = false;
                    });
            }
        },
        backToView() {
            window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/promocode/view";
        },
    },
};
</script>
