import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import promocodeView from "./view.vue";
import app from "../../common/includes/App.vue"
const view_app = createApp({
    template: `
    <app>
    <promocode-view></promocode-view>
    </app>
    `,
    components: {
        app,
        'promocode-view': promocodeView,
    }
});
view_app.use(useVuelidate);
view_app.mount("#view_app");