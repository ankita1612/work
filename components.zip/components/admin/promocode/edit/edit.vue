<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                ">
                <h4 class="mb-sm-0 font-size-18">Update Promo Code</h4>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <form @submit.prevent="updatePromocode">
                    <div class="row mb-4" :class="{ 'form-group--error': v$.promo_code.$error }">
                      <label for="horizontal-question_code-input" class="col-sm-2 col-form-label text-end">Promo
                        Code</label>
                      <div class="col-sm-8">
                        <input type="text" class="form-control" placeholder="Enter Promo Code"
                          id="horizontal-question_code-input" v-model.trim="v$.promo_code.$model" />
                          <div v-if="v$.promo_code.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.promo_code.$errors[0].$message }}
                            </div>
                         </div>
                      </div>
                    </div>
                    <div class="row mb-4" :class="{ 'form-group--error': v$.discount_percentage.$error }">
                      <label for="horizontal-question-input" class="col-sm-2 col-form-label text-end">Discount
                        Percentage</label>
                      <div class="col-sm-8">
                        <input disabled type="text" class="form-control" placeholder="Enter Discount Percentage"
                          id="horizontal-question-input" v-model.trim="v$.discount_percentage.$model" />
                          <div v-if="v$.discount_percentage.$errors.length > 0">
                            <div class="form-error-text">
                                {{ v$.discount_percentage.$errors[0].$message }}
                            </div>
                         </div>
                      </div>
                    </div>
                    <div class="row mb-4">
                      <label class="col-sm-2 col-form-label text-end">Flash Sale End Date</label>
                      <div class="col-sm-8">
                        <date-picker class="form-control" v-model:value="flash_sale_end_date" format="MM-DD-YYYY"
                          titleFormat="MM-DD-YYYY" valueType="YYYY-MM-DD" :editable="false" placeholder="Select Date" :disabled="true">
                        </date-picker>
                      </div>
                    </div>                    
                    <div class="row mb-4">
                      <label for="horizontal-email-input" class="col-sm-2 col-form-label text-end pt-0">User Type</label>
                      <div class="col-sm-8">
                        <input class="form-check-input" type="radio" id="user_type_normal" name="user_type"
                          value="Normal" v-model.trim="user_type"  />
                        <label class="form-check-label" for="user_type_normal">
                          &nbsp;Normal
                        </label>
                        <input class="form-check-input ms-2" type="radio" id="user_type_employee" name="user_type"
                          value="Reseller" v-model.trim="user_type"  />
                        <label class="form-check-label" for="user_type_reseller" >
                          &nbsp;Reseller
                        </label>                        
                      </div>
                    </div>
                    <div class="row mb-4">
                      <label for="horizontal-email-input" class="col-sm-2 col-form-label text-end pt-0">Status</label>
                      <div class="col-md-8">
                        <div class="form-check form-switch form-switch-md mb-3" dir="ltr">
                          <input class="form-check-input" type="checkbox" id="promocode_status"
                            v-model.trim="is_active">
                          <label class="form-check-label" for="promocode_status"
                            v-text="(is_active) ? 'Active' : 'Inactive'"></label>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-2"></div>
                      <div class="col-sm-8">
                        <div>
                          <button type="button" @click="backToView()" class="btn btn-danger w-md">
                            CANCEL
                          </button>
                           &nbsp;
                           &nbsp;
                          <button :disabled="is_edit_btn_disabled" type="submit" class="btn btn-primary w-md">
                            UPDATE
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
import DatePicker from 'vue-datepicker-next';
import "vue-datepicker-next/index.css";
toastr.options.preventDuplicates = true;
import moment from "moment";
import { required , helpers } from "@vuelidate/validators";
import { useVuelidate } from '@vuelidate/core';
import fullPageLoader from "../../common/fullPageLoader.vue";

export default {
  setup: () => ({ v$: useVuelidate() }),
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      PROMOCODE_ID: PROMOCODE_ID,
      promo_code: "",
      discount_percentage: "",
      flash_sale_end_date: "",
      is_active: "",
      is_edit_btn_disabled: false,
      is_full_page_loader_shown: false,
      check_promocode_available_timer: null,
      user_type:''
    };
  },
  components: {
    fullPageLoader,
    DatePicker
  },
  validations(){
    return {
      promo_code : {
        required : helpers.withMessage("Please enter a promo code",required),
        isUnique : helpers.withMessage("Promo code already in use",
        helpers.withAsync(async (value) => {
          if (!value) return true;
          this.is_edit_btn_disabled = true;
          let check_promise = new Promise((resolve, reject) => {
            if (this.check_promo_code_available_timer) {
              clearTimeout(this.check_og_available_timer)
              this.check_promo_code_available_timer = null
            }
            this.check_promo_code_available_timer = setTimeout(() => {
              return fetch(JS_APP_URL + `/pkO0OA17otP61RwETtNn/promocode/check-unique-promocode/${value}/${this.PROMOCODE_ID}`).then(response => {
                if (response.ok) {
                  resolve(response.text())
                } else {
                  resolve(new Error('error'))
                }
              }, error => {
                resolve(new Error('error'))
              })
            }, 500);
          });
          var response = await check_promise;
          this.is_edit_btn_disabled = false;
          return Boolean((response == 'available') ? false : true);
        }))
      },
      discount_percentage : { required : helpers.withMessage("Please enter a discount percentage",required)}
    }
  },
  methods: {
    getPromocodeDetails() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL +
          "/pkO0OA17otP61RwETtNn/promocode/get-promocode-edit-detail/" +
          PROMOCODE_ID
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if (response["data"]['data'].length > 0) {
              toastr.error(response["data"]['data'].join('</br>'), "Error");
            } else {
              toastr.error(response["data"]["message"], "Error");
            }
          } else {
            let data = response.data.data;
            this.promo_code = data.promo_code;
            this.discount_percentage = data.discount_percentage;
            this.flash_sale_end_date = (data.flash_sale_end_date)?data.flash_sale_end_date:null;
            this.is_active = (data.is_active == 1) ? true : false;
            this.user_type = data.user_type;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    updatePromocode() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        NProgress.start();
        this.is_edit_btn_disabled = true;
        axios
          .post(
            JS_APP_URL +
            "/pkO0OA17otP61RwETtNn/promocode/update-promocode",
            {
              promocode_id: PROMOCODE_ID,
              promo_code: this.promo_code,
              discount_percentage: this.discount_percentage,
              flash_sale_end_date: this.flash_sale_end_date ? this.flash_sale_end_date : null,
              is_active: this.is_active,
              user_type: this.user_type
            }
          )
          .then((response) =>{
            if (response["data"]["status"] == "Error") {
              if (response["data"]['data'].length > 0) {
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              } else {
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              setTimeout(() => {
                window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/promocode/view";
              }, 500);
              toastr.success(response["data"]["message"], "Success");
            }
          })
          .catch((error) =>{
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
            }
          })
          .then(() => {
            //this.is_edit_btn_disabled = false;
            NProgress.done();
          });
      }
    },
    backToView() {
      window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/promocode/view";
    },
  },
  mounted() {
    this.getPromocodeDetails();
  },
};
</script>
