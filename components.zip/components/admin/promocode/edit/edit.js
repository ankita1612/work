import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import promocodeEdit from "./edit.vue";
import app from "../../common/includes/App.vue"
const edit_app = createApp({
    template: `
    <app>
    <promocode-edit></promocode-edit>
    </app>
    `,
    components: {
        app,
        'promocode-edit': promocodeEdit,
    }
});
edit_app.use(useVuelidate);
edit_app.mount("#edit_app");