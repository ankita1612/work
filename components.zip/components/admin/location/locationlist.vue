<template>
    <tbody>
        <tr>
            <td>{{ location.company_name }}</td>
            <td>{{ location.location_nickname }}</td>
            <td>{{ location.user.email }}</td>
            <td>
                <button
                    @click="expandToggle(location.id)"
                    class="btn btn-sm btn-info expand-btn"
                    v-if="is_expand_shown == false"
                >
                    EXPAND VIEW
                </button>
                <button
                    @click="expandToggle(location.id)"
                    class="btn btn-sm btn-dark expand-btn"
                    v-else
                >
                    EXPANDED
                </button>
            </td>
        </tr>
        <tr v-if="is_expand_shown">
            <td colspan="4">
                <expand-toggle
                    v-if="is_expand_shown"
                    :location="location_details"
                    @full-loader="fullLoader"
                    @get-location-detail="getLocationDetail"
                    @update_location_data="updateSingleLocation"
                />
            </td>
        </tr>
    </tbody>
</template>

<script>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import expandToggle from "./expandToggle.vue";

export default {
    data() {
        return {
            is_expand_shown: false,
            location_details: [],
        };
    },
    emits:["full-loader-toggle"],
    props: {
        location: {},
        expand_toggle_flag: {},
    },
    watch: {
        expand_toggle_flag() {
            this.is_expand_shown = false;
        },
    },
    components: {
        expandToggle,
    },
    methods: {
        expandToggle(id) {
            if (this.is_expand_shown == false) {
                this.getLocationDetail(id);
            } else {
                this.is_expand_shown = false;
            }
        },
        fullLoader(status) {
            this.$emit("full-loader-toggle", status);
        },
        getLocationDetail(id) {
            NProgress.start();
            this.$emit("full-loader-toggle", true);
            axios
                .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/location/get-location-detail/" + id)
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        this.location_details = response.data.data;
                        this.is_expand_shown = true;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    this.$emit("full-loader-toggle", false);
                });
        },
        updateSingleLocation(location_id) {
          this.getLocationDetail(location_id);
        },
    },
};
</script>

<style></style>
