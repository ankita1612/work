<template>
    <div class="expand_div table-responsive">
        <table
            id="expand_table"
            cellspacing="2"
            cellpadding="10"
            class="w-100"
        >
            <tbody>
                <tr>
                    <td class="text-center fw-bold">SRA COMPLETE</td>
                    <td class="text-center">
                        <span
                            class="btn label-rounded cursor-pointer btn-sm"
                            @click="downloadScorecard(location.id)"
                            :class="
                                location.sra_percentage_count.percentage == 100
                                    ? 'btn-success'
                                    : 'btn-danger'
                            "
                        >
                            {{ location.sra_percentage_count.percentage }}%
                        </span>
                    </td>
                    <td class="text-center fw-bold">OG COMPLETE</td>
                    <td class="text-center">
                        <span
                            class="btn label-rounded cursor-pointer btn-sm"
                            :class="
                                location.ongoing_compliance_percentage_count
                                    .percentage == 100
                                    ? 'btn-success'
                                    : 'btn-danger'
                            "
                        >
                            {{
                                location.sra_percentage_count.percentage == 100
                                    ? location
                                          .ongoing_compliance_percentage_count
                                          .percentage
                                    : 100
                            }}%
                        </span>
                    </td>
                    <td class="text-center fw-bold">NOTIFICATION(S)</td>
                    <td class="text-center">
                      <span class="btn btn-danger label-rounded cursor-pointer btn-sm" @click="notificationModalToggle()">
                        {{location.open_notifications_without_login_count}}
                      </span>
                    </td>
                    <td class="text-center fw-bold">HCO</td>
                    <td class="text-center">
                        <span
                            class="btn btn-xs label-rounded btn-sm"
                            v-if="location.hipaa_compliance_officer != null"
                        >
                            {{
                                location.hipaa_compliance_officer.hco.first_name.toUpperCase()
                            }}
                            {{
                                location.hipaa_compliance_officer.hco.last_name.toUpperCase()
                            }}
                        </span>
                        <span class="btn btn-xs label-rounded btn-sm" v-else>
                            -
                        </span>
                    </td>
                </tr>
                <tr>
                    <td class="text-center">
                        <span
                            class="btn label-rounded cursor-pointer btn-sm btn-primary"
                            @click="attachSFUniqueIdModalToggle()"
                        >
                            LINK UNIQUE ID FOR SF
                        </span>
                    </td>
                    <td class="text-center">
                        <span
                            v-if="location.salesforce_unique_id != null"
                            class="btn btn-xs label-rounded btn-sm"
                        >
                            <a
                                class="fw-bold text-info"
                                v-on:click="syncWithSF()"
                            >
                                SYNC with SF</a
                            >
                        </span>
                        <span class="btn btn-xs label-rounded btn-sm" v-else>
                            -
                        </span>
                    </td>
                </tr>
            </tbody>
        </table>
        <notification-list-modal
            v-if="notification_list_modal"
            :location_id="location.id"
            @full-loader="fullLoader"
            @close-modal="notificationModalToggle"
        />
        <attach-SF-unique-id-Modal
            v-if="is_attach_SF_unique_id_modal_open"
            :location_detail="location"
            :location_id="location.id"
            @full-loader="fullLoader"
            @close-modal="attachSFUniqueIdModalToggle"
            @updated_location_data="updateLocationData"
        />
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import notificationListModal from "./notificationListModel.vue";
import attachSFUniqueIdModal from "./attachSFUniqueIdModal.vue";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            notification_list_modal: false,
            is_attach_SF_unique_id_modal_open: false,
        };
    },
    emits:["full-loader","update_location_data"],
    props: {
        location: {},
    },
    components: {
        notificationListModal,
        attachSFUniqueIdModal,
    },
    mounted() {},
    methods: {
        fullLoader(status) {
            this.$emit("full-loader", status);
        },
        downloadScorecard(id) {
            if (this.location.sra_percentage_count.percentage == 100) {
                this.fullLoader(true);
                axios
                    .post(JS_APP_URL + "/pkO0OA17otP61RwETtNn/location/download-scorecard", {
                        location_id: id,
                    })
                    .then((response) => {
                        if (response["data"]["status"] == "Error") {
                            if (response["data"]["data"].length > 0) {
                                toastr.error(
                                    response["data"]["data"].join("</br>"),
                                    "Error"
                                );
                            } else {
                                toastr.error(
                                    response["data"]["message"],
                                    "Error"
                                );
                            }
                        } else {
                            const filePath =
                                response["data"]["data"].split("/");
                            const tempFileName = filePath[filePath.length - 1];
                            const fileName = tempFileName.split("?")[0];
                            axios({
                                url: response["data"]["data"],
                                method: "GET",
                                responseType: "blob",
                            }).then((response) => {
                                var fileURL = window.URL.createObjectURL(
                                    new Blob([response.data])
                                );
                                var fileLink = document.createElement("a");
                                fileLink.href = fileURL;
                                fileLink.setAttribute("download", fileName);
                                document.body.appendChild(fileLink);
                                fileLink.click();
                            });
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        this.fullLoader(false);
                    });
            }
        },
        syncWithSF() {
            this.fullLoader(true);
            axios
                .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/location/sync-sales-force/" + this.encryption(this.location.id))
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if (response["data"]["data"].length > 0) {
                            toastr.error(
                                response["data"]["data"].join("</br>"),
                                "Error"
                            );
                        } else {
                            toastr.error(
                                response["data"]["message"],
                                "Error"
                            );
                        }
                    } else {
                        toastr.success(
                                response["data"]["message"],
                                "Success"
                            );
                    }
                })
                .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                })
                .then(() => {
                   this.fullLoader(false);
                });
        },
        notificationModalToggle() {
            if (this.notification_list_modal == false) {
                this.notification_list_modal = true;
            } else {
                this.notification_list_modal = false;
            }
        },
        attachSFUniqueIdModalToggle() {
            if (this.is_attach_SF_unique_id_modal_open == false) {
                this.is_attach_SF_unique_id_modal_open = true;
            } else {
                this.is_attach_SF_unique_id_modal_open = false;
            }
        },
        updateLocationData(location_id) {
            this.syncWithSF();
            this.$emit("update_location_data", location_id);
        },
        encryption(params){
            var encoded = btoa(params);
            return encoded;
        },
    },
};
</script>
