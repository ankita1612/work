<template>
    <transition name="modal">
        <div class="modal-mask">
            <div class="modal-wrapper animate__animated animate__zoomIn">
                <div class="modal-container">
                    <div
                        v-if="!is_add_btn_disabled"
                        @click="$emit('close-modal')"
                        class="cursor-pointer modal-close"
                    >
                        <close-icon></close-icon>
                    </div>
                    <div class="text-start mb-4">
                        <h3>Link Unique ID for Salesforce</h3>
                    </div>
                    <div
                        v-if="
                            location_detail.salesforce_unique_id != null &&
                            open_form == false
                        "
                        class="row mb-1"
                    >
                        <div class="col-sm-4">
                            Current attached ID:<br>
                            <span
                            class="label label-rounded text-info"
                            >{{
                                location_detail.salesforce_unique_id
                            }}</span
                            >
                        </div>
                        <div class="col-sm-8">                            
                            <button
                                class="btn btn-danger"
                                @click="open_form = true"
                            >
                                Update Unique ID
                            </button>
                        </div>
                    </div>

                    <form
                        @submit.prevent="addUniqueId"
                        v-if="
                            open_form == true ||
                            location_detail.salesforce_unique_id == null
                        "
                    >
                        <div class="row mb-1">
                            <div class="col-sm-8">
                                <div
                                    class="form-group mb20 relative"
                                    :class="{
                                        'form-group--error':
                                            v$.unique_id.$error || unique_error.length > 0,
                                    }"
                                >
                                    <div>
                                        <input
                                            type="text"
                                            placeholder="Please enter valid SF unique id"
                                            class="form-control fill-width pl10"
                                            v-model.trim="v$.unique_id.$model"
                                            :class="{
                                                'form-error-border-bottom':
                                                    v$.unique_id.$error,
                                            }"
                                        />
                                    </div>
                                    <div v-if="v$.unique_id.$errors.length > 0">
                                        <div class="form-error-text">
                                            {{ v$.unique_id.$errors[0].$message }}
                                        </div>
                                    </div>
                                    <span
                                        class="form-error-text"
                                        v-if="unique_error.length > 0"
                                        >{{ unique_error }}</span
                                    >
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <button
                                    :disabled="is_add_btn_disabled"
                                    type="submit"
                                    class="btn btn-dark w-md"
                                >
                                    LINK NOW!
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </transition>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import closeIcon from "../../common/icons/closeIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import "@james090500/vue-tagsinput/dist/style.css";
import useVuelidate from "@vuelidate/core";
import {required, helpers } from "@vuelidate/validators";
export default {
    setup: () => ({ v$: useVuelidate() }),
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            is_btn_disabled: false,
            is_add_btn_disabled: false,
            unique_id: this.location_detail.salesforce_unique_id,
            unique_error: "",
            open_form: false,
        };
    },
    props: {
        location_id: {},
        location_detail: {},
    },
    emits:["updated_location_data","close-modal"],
    validations() {
            return {
                unique_id: {
                    required: helpers.withMessage(
                        "Please enter valid SF unique id",
                        required
                    )
                },
            };
    },
    components: { closeIcon },

    watch: {
        unique_id(val) {
            this.unique_error = "";
        },
    },
    methods: {
        addUniqueId() {
            this.v$.$touch();
            if (!this.v$.$invalid) {
                NProgress.done();
                axios
                    .post(JS_APP_URL + "/pkO0OA17otP61RwETtNn/location/edit-sales-force-id", {
                        location_id: this.location_id,
                        salesforce_unique_id: this.unique_id,
                    })
                    .then((response) => {
                        if (response["data"]["status"] == "Error") {
                            this.unique_error = response["data"]["data"][0];
                        } else {
                            this.$emit(
                                "updated_location_data",
                                this.location_id
                            );
                            this.open_form = false;
                        }
                    })
                    .catch((error) => {
                        toastr.error(
                            error.response["data"]["message"],
                            "Error"
                        );
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        NProgress.done();
                    });
            }
        },
    },
    created() {
        // document.body.classList.add("modal-open");
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27 && !this.is_add_btn_disabled) {
                this.$emit("close-modal");
            }
        });
    },
    destroyed() {
        // document.body.classList.remove("modal-open");
    },
};
</script>
