<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask pdf-modal-mask">
        <div class="pdf-modal-overlay"></div>
        <div
          class="modal-wrapper animate__animated animate__zoomIn w-50"
          :class="{ 'h-100': notifications.length > 3 }"
        >
          <div class="modal-container">
            <div
              v-on:click="$emit('close-modal')"
              class="cursor-pointer modal-close"
            >
              <close-icon></close-icon>
            </div>
            <div class="text-start mb-4">
              <h3>Open Notifications</h3>
            </div>
            <div
              class="row card bg-light border-dark"
              v-for="notification in notifications"
              :key="notification.id"
            >
              <div class="card-body">
                <div class="row g-0">
                  <h3 class="card-title text-start col-sm-6 col-md-8">{{getReplacedTitle(notification)}}</h3> 
                  <p class="text-end col-6 col-md-4">{{ $filters.formatDate(notification.updated_at) }}</p>
                </div>
                <p class="card-text text-start">{{getReplacedDescription(notification)}}</p>
              </div>
            </div>
            <div v-if="notifications.length == 0" >
              No notification(s) available!
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>
<script scoped>
import axios from "axios";
import closeIcon from "../../common/icons/closeIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";

export default {
  data() {
    return {
      notifications: {},
      JS_SUPPORT_EMAIL: SUPPORT_EMAIL,
      JS_SUPPORT_PHONE_NUMBER_DISPLAY: SUPPORT_PHONE_NUMBER_DISPLAY,
    };
  },
  props: {
    location_id: {},
  },
  emits: ["full-loader", "close-modal"],
  components: { closeIcon },
  mounted() {
    this.getNotification();
  },
  methods: {
    getReplacedTitle(each_noti) {
      if(each_noti.notification.code == 'HCE-AN15'){
        return each_noti.notification.title.replace('{%EMPLOYEE_NAME%}', each_noti.other_details);
      } else if(each_noti.notification.code == 'HCE-AN13') {
        return each_noti.notification.title.replace('{%VENDOR_NAME%}', each_noti.other_details);
      } else {
        return each_noti.notification.title;
      }
    },
    getReplacedDescription(each_noti){ 
        if (each_noti.notification.code == 'HCE-AN20') {
        var noti_desc =  each_noti.notification.description.replace('{%RENEWAL DATE%}', this.$filters.formatDateUTC(each_noti.other_details)); 
        noti_desc =  noti_desc.replace('{%SUPPORT_EMAIL%}', this.JS_SUPPORT_EMAIL);        
        return noti_desc.replace('{%SUPPORT_PHONE_NUMBER_DISPLAY%}', this.JS_SUPPORT_PHONE_NUMBER_DISPLAY);
      } if(each_noti.notification.code == 'HCE-AN13') {
        return each_noti.notification.description.replace('{%VENDOR_NAME%}', each_noti.other_details);
      } else {
        return each_noti.notification.description;
      }
    },
    getNotification() {
      this.$emit("full-loader", true);
      axios
        .get(
          JS_APP_URL + "/pkO0OA17otP61RwETtNn/location/get-notification/" + this.location_id
        )
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            let data = response.data.data;
            this.notifications = data;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.$emit("full-loader", false);
        });
    },
  },
  created() {
    // document.body.classList.add("modal-open");
    
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-modal");
      }
    });
  },
  destroyed() {
    // document.body.classList.remove("modal-open");
  },
};
</script>

<style>
</style>
