import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import locationView from "./view.vue";
import app from "../common/includes/App.vue"
import moment from "moment";

const view_app = createApp({
    template: `
    <app>
        <location-view></location-view>
    </app>
    `,
    components: {
        app,
        'location-view': locationView,
    }
});
view_app.config.globalProperties.$filters = {
    formatDate(value) {
       if (value) {
            return moment.utc(String(value)).local().format("MM/DD/YYYY");
       }
    },
    fromNow(value) {
        if (value) {
             return moment.utc(String(value)).local().format("YYYYMMDD");
        }
    },
    formatDateUTC(value) {
        if (value) {
             return moment(value).format("MM/DD/YYYY");
        }
    },
}
view_app.use(useVuelidate);
view_app.mount("#view_app");
