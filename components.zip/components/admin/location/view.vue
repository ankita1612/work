<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div
                class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                "
              >
                <h4 class="mb-sm-0 font-size-18">Locations List</h4>
                <a v-if="this.params" :href="JS_APP_URL + '/pkO0OA17otP61RwETtNn/user/view?' + params" class="btn btn-sm btn-info">Back to User</a>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <div class="row mb-2">
                    <div class="col-sm-12 col-md-2">
                      <div>
                        <label
                          >Show
                          <select
                            v-model.trim="selected_show_entry"
                            class="
                              custom-select custom-select-sm
                              form-control
                              form-control-sm
                              form-select
                              form-select-sm
                              d-inline-block
                              w-auto
                              ms-2
                              me-2
                            "
                          >
                            <option :value="entry" v-for="entry in show_entry_list" :key="entry">{{entry}}</option>
                          </select>
                          entries
                        </label>                        
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-10 text-end">
                      <div>
                        <label class="mb-0"
                          ><span>Search:</span
                          ><input
                            type="text"
                            class="
                              form-control form-control-sm
                              d-inline-block
                              w-auto
                              ms-2
                            "
                            v-model.trim="search"
                            @input="applySearch()"
                            placeholder="Search"
                        /></label>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-xl-12">
                      <table
                        class="
                          table table-responsive table-bordered
                          mb-0
                          dataTable
                          table-fixed
                        "
                      >
                        <thead class="table-light">
                          <tr>
                            <th
                              v-for="column in columns"
                              :key="column.id"
                              @click="(column.id != 'email')?sortByColumn(column.id):null"
                              :class="[
                                column.id === sort_column
                                  ? sort_order == 'asc'
                                    ? 'sorting_asc'
                                    : 'sorting_desc'
                                  : '', column.id == 'email' ? '' : 'sorting'
                              ]"
                            >
                              {{ column.text }}
                            </th>
                            <th>ACTION</th>
                          </tr>
                        </thead>
                        <location-list v-for="(location, index) in locations" :key="index"
                        :location="location"
                        @full-loader-toggle="fullLoaderToggle"
                        :expand_toggle_flag="expand_toggle_flag" />
                        <tbody v-if="locations.length == 0">
                          <tr>
                            <td colspan="4" class="text-center">
                              No records available!
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="row mt-3">
                    <div class="col-xl-12">
                      <pagination 
                      v-if="locations.length > 0"
                      :current_page="current_page"
                      :total_page="total_page"
                      :pagination_links="pagination_links"
                      @change-page="changePage"
                      >
                      </pagination>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div> 
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from "lodash";
import fullPageLoader from "../common/fullPageLoader.vue";
import pagination from "../common/pagination.vue";
import locationList from './locationlist.vue'

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      is_full_page_loader_shown: false,
      locations: [],
      search: null,
      total_page: "",
      current_page: 1,
      pagination_links: [],
      per_page: "",
      selected_show_entry: 10,
      show_entry_list: [10, 25, 50, 100],
      sort_column: "location_nickname",
      sort_order: "asc",
      columns: [{"id": "company_name", "text": "Practice Name"}, {"id": "location_nickname", "text": "Location Name"}, {"id": "email", "text": "User Email"}],
      is_expand_shown: false,
      expand_toggle_flag: 0,
      params: ""
    };
  },
  components: {
    fullPageLoader,
    pagination,
    locationList
  },
  computed: {},
  created() {
    this.params = window.location.search.substring(1);
  },
  mounted() {
    this.getLocationList();
  },
  watch: {
    selected_show_entry(val) {
      this.current_page = 1;
      this.getLocationList();
    },
  },
  methods: {
    fullLoaderToggle(status){
      this.is_full_page_loader_shown = status;
    },
    getLocationList() {
     this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/location/get-location-list/"+JS_USER_ID, {
          params: {
            search: this.search,
            selected_show_entry: this.selected_show_entry,
            page: this.current_page,
            sort_column: this.sort_column,
            sort_order: this.sort_order
          },
        })
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            let data = response.data.data;
            this.locations = data.data;
            this.current_page = data.current_page;
            this.total_page = data.last_page;
            this.per_page = data.per_page;
            this.pagination_links = data.links;
            this.expand_toggle_flag ++;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    sortByColumn(column) {
      if (column === this.sort_column) {
        this.sort_order = this.sort_order === "asc" ? "desc" : "asc";
      } else {
        this.sort_column = column;
        this.sort_order = "asc";
      }
      this.getLocationList();
    },
    changePage(page) {
      this.current_page = page;
      this.getLocationList();
    },
    applySearch() {
      this.current_page = 1;
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      this.timer = setTimeout(() => {
        this.getLocationList();
      }, 500);
    },
  },
};
</script>