<template>
    <div>
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                      <div class="col-sm-12 col-md-6">
                        <div
                          class="
                            page-title-box
                            d-sm-flex
                            align-items-center
                            justify-content-between
                          "
                        >
                          <h4 class="mb-sm-0 font-size-18">BA Promotion Response List</h4>

                        </div>
                      </div>
                      <div class="col-sm-12 col-md-6 text-end">
                        <label class="font-size-14">Filter Response:</label>
                          <select
                          @change="applyFilter()"
                          v-model="filter_list"
                          placeholder="Select Response"
                          class="
                            form-select
                            w-auto
                            ms-2
                            me-2
                            d-inline-block
                          ">
                            <option disabled value>Select Response</option>
                            <option :value="'yes'">Yes</option>
                            <option :value="'no'">No</option>
                            <option :value="'ask later'">Ask Later</option>
                          </select>
              
                        <button class="btn btn-sm btn-info btn-rounded" @click="exportBAPromotionList">Export BA Response List</button>
                      </div>
                       
                    </div>

                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row mb-2">
                                      <div class="col-sm-12 col-md-6">
                                        <div>
                                          <label
                                            >Show
                                            <select
                                              v-model.trim="selected_show_entry"
                                              class="
                                                custom-select custom-select-sm
                                                form-control
                                                form-control-sm
                                                form-select
                                                form-select-sm
                                                d-inline-block
                                                w-auto
                                                ms-2
                                                me-2
                                              "
                                            >
                                              <option :value="entry" v-for="entry in show_entry_list" :key="entry">{{entry}}</option>
                                            </select>
                                            entries
                                          </label>                        
                                        </div>
                                      </div>
                                      
                                      <div class="col-sm-12 col-md-6 text-end">
                                        <div>
                                          <label class="mb-0"
                                            ><span>Search:</span
                                            ><input
                                              type="text"
                                              class="
                                                form-control form-control-sm
                                                d-inline-block
                                                w-auto
                                                ms-2
                                              "
                                              v-model.trim="search"
                                              @input="applySearch()"
                                              placeholder="Search"
                                          /></label>
                                        </div>
                                      </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <table
                                                class="
                                                table table-responsive table-bordered
                                                mb-0
                                                dataTable
                                                table-fixed
                                                "
                                            >
                                                <thead class="table-light">
                                                    <tr>
                                                        <th
                                                        v-for="column in columns"
                                                        :key="column.id"
                                                        @click="(column.id != 'is_interested') ?sortByColumn(column.id) : null"
                                                        :class="[(column.id === sort_column)?(sort_order == 'asc')?'sorting_asc':'sorting_desc':'', column.id == 'is_interested' ? '' : 'sorting']"
                                                        >
                                                        {{ column.text }}
                                                        </th>
                                                       
                                                    </tr>
                                                </thead>
                                                <tbody v-if="promo_lists.length > 0">
                                                    <tr v-for="(promolist, index) in promo_lists" :key="index">
                                                        <td>{{ promolist.user_first_name }} {{ promolist.user_last_name }}</td>
                                                        <td>{{ promolist.user_email }}</td>
                                                        <td>{{ promolist.user_company_name }}</td>
                                                        <td>
                                                            <span
                                                                class="badge
                                                                  rounded-pill                                  
                                                                  font-size-14"
                                                                :class="
                                                                    promolist.is_interested == 1
                                                                        ? 'badge-soft-success'
                                                                        : (promolist.is_interested == 2
                                                                        ? 'badge-soft-primary'
                                                                        : 'badge-soft-dark')
                                                                "
                                                            >
                                                                {{
                                                                    promolist.is_interested == 1
                                                                        ? "YES"
                                                                        : (promolist.is_interested == 2
                                                                        ? "ASK LATER"
                                                                        : "NO")
                                                                }}
                                                            </span>
                                                        </td>
                                                        <td>{{ $filters.formatDateTime(promolist.created_at) }}</td>
                                                     
                                                    </tr>
                                                </tbody>
                                                <tbody v-else>
                                                    <tr>
                                                        <td colspan="5" class="text-center">
                                                        No records available!
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-xl-12">
                                            <pagination
                                            v-if="promo_lists.length > 0"
                                            :current_page="current_page"
                                            :total_page="total_page"
                                            :pagination_links="pagination_links"
                                            @change-page="changePage"
                                            >
                                            </pagination>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>

<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../common/fullPageLoader.vue";
import pagination from "../common/pagination.vue"

export default {
    data() {
        return {
            AUTH_USER: AUTH_USER,
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            promo_lists: [],
            search: null,
            total_page: "",
            current_page: 1,
            pagination_links: [],
            filter_list: '',
            per_page: "",
            selected_show_entry: 10,
            show_entry_list: [10, 25, 50, 100],
            columns: [{"id": "user_first_name", "text": "NAME"}, {"id": "user_email", "text": "EMAIL"}, {"id": "user_company_name", "text": "COMPANY"}, {"id": "is_interested", "text": "IS INTERESTED"}, {"id": "created_at", "text": "ANSWERED ON"}],
            sort_column: "created_at",
            sort_order: "desc",
            is_full_page_loader_shown: false
        }
    },
    components: {
        fullPageLoader,
        pagination,
    },
    watch: {
        selected_show_entry(val) {
            this.current_page = 1;
            this.getBAPromotionList();
        },
    },
    mounted() {
        this.getBAPromotionList();
    },
    methods: {
        getBAPromotionList() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + '/pkO0OA17otP61RwETtNn/logs/ba-promotion-list', {
                    params: {
                        search: this.search,
                        selected_show_entry: this.selected_show_entry,
                        page: this.current_page,
                        sort_column: this.sort_column,
                        sort_order: this.sort_order,
                        filter_by: this.filter_list

                    },
                })
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        let data = response.data.data;
                        this.promo_lists = data.data;
                        this.current_page = data.current_page;
                        this.total_page = data.last_page;
                        this.per_page = data.per_page;
                        this.pagination_links = data.links;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/login";
                    }
                })
                .then(() => {
                    this.is_full_page_loader_shown = false;
                })
        },
        sortByColumn(column) {
            if (column === this.sort_column) {
                this.sort_order = this.sort_order === "asc" ? "desc" : "asc";
            } else {
                this.sort_column = column;
                this.sort_order = "asc";
            }
                this.getBAPromotionList();
        },
        changePage(page) {
            this.current_page = page;
            this.getBAPromotionList();
        },
        applySearch() {
            this.current_page = 1;
            if (this.timer) {
                clearTimeout(this.timer);
                this.timer = null;
            }
            this.timer = setTimeout(() => {
                this.getBAPromotionList();
            }, 500);
        },
        applyFilter() {
          if (this.timer) {
            clearTimeout(this.timer);
            this.timer = null;
          }
          this.timer = setTimeout(() => {
            this.getBAPromotionList();
          }, 500);
        },
        exportBAPromotionList() {
            this.is_full_page_loader_shown = true;
            axios
              .get(JS_APP_URL + '/pkO0OA17otP61RwETtNn/logs/export-ba-promotion-list', {
                params: {
                  
                }
              })
              .then((response) => {
                var link = document.createElement('a');
                link.href = response['data']['data']['file'];
                link.download = response['data']['data']['name'];
                link.click();
                link.remove();
              })
              .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                  window.location = JS_APP_URL + "/login";
                }
              })
              .then(() => {
                this.is_full_page_loader_shown = false;
              });
      }
    }
}
</script>
