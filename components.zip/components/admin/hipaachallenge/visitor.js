import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import visitor from "./visitor.vue";
import app from "../common/includes/App.vue"
import moment from "moment";

const add_app = createApp({
    template: `
    <app>
        <visitor></visitor>
    </app>
    `,
    components: {
        app,
        'visitor': visitor,
    }
});
add_app.config.globalProperties.$filters = {
    formatDateTime(value) {
       if (value) {
            return moment.utc(String(value)).local().format("MM/DD/YYYY hh:mm A");
       }
   },
}
add_app.use(useVuelidate);
add_app.mount("#visitor_app");
