<template>
    <div>
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div
                                class="
                                page-title-box
                                d-sm-flex
                                align-items-center
                                justify-content-between
                                "
                            >
                                <h4 class="mb-sm-0 font-size-18">Visitor List</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row mb-2">
                                        <div class="col-sm-12 col-md-6">
                                            <div>
                                                <label
                                                >Show
                                                    <select
                                                        v-model.trim="selected_show_entry"
                                                        class="
                                                        custom-select custom-select-sm
                                                        form-control
                                                        form-control-sm
                                                        form-select
                                                        form-select-sm
                                                        d-inline-block
                                                        w-auto
                                                        ms-2
                                                        me-2
                                                        "
                                                    >
                                                        <option :value="entry" v-for="entry in show_entry_list" :key="entry">{{entry}}</option>
                                                    </select>
                                                    entries
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-6 text-end">
                                            <div>
                                                <label
                                                ><span>Search:</span
                                                ><input
                                                    type="text"
                                                    class="
                                                    form-control form-control-sm
                                                    d-inline-block
                                                    w-auto
                                                    ms-2
                                                    "
                                                    v-model.trim="search"
                                                    @input="applySearch()"
                                                    placeholder="Search"
                                                /></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <table
                                                class="
                                                table table-responsive table-bordered
                                                mb-0
                                                dataTable
                                                table-fixed
                                                "
                                            >
                                                <thead class="table-light">
                                                    <tr>
                                                        <th
                                                        v-for="column in columns"
                                                        :key="column.id"
                                                        @click="sortByColumn(column.id)"
                                                        class="sorting"
                                                        :class="[(column.id === sort_column)?(sort_order == 'asc')?'sorting_asc':'sorting_desc':'']"
                                                        >
                                                        {{ column.text }}
                                                        </th>
                                                        <th>DOWNLOAD SCORECARD</th>
                                                    </tr>
                                                </thead>
                                                <tbody v-if="visitors.length > 0">
                                                    <tr v-for="(visitor, index) in visitors" :key="index">
                                                        <td>{{ visitor.contact_name }}</td>
                                                        <td>{{ visitor.email }}</td>
                                                        <td>{{ visitor.company_name }}</td>
                                                        <td>{{visitor.partner != null ? visitor.partner.name : ''}}</td>
                                                        <td>{{ $filters.formatDateTime(visitor.created_at) }}</td>
                                                        <td>
                                                            <button class="btn btn-sm btn-info" @click="createSignUrl(visitor.scorecard)">
                                                                Download Scorecard
                                                            </button>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                                <tbody v-else>
                                                    <tr>
                                                        <td colspan="6" class="text-center">
                                                        No records available!
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="row mt-3">
                                        <div class="col-xl-12">
                                            <pagination
                                            v-if="visitors.length > 0"
                                            :current_page="current_page"
                                            :total_page="total_page"
                                            :pagination_links="pagination_links"
                                            @change-page="changePage"
                                            >
                                            </pagination>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>

<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../common/fullPageLoader.vue";
import pagination from "../common/pagination.vue"

export default {
    data() {
        return {
            AUTH_USER: AUTH_USER,
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            visitors: [],
            search: null,
            total_page: "",
            current_page: 1,
            pagination_links: [],
            per_page: "",
            selected_show_entry: 10,
            show_entry_list: [10, 25, 50, 100],
            columns: [{"id": "contact_name", "text": "NAME"}, {"id": "email", "text": "EMAIL"}, {"id": "company_name", "text": "COMPANY"}, {"id": "partner_name", "text": "PARTNER NAME"}, {"id": "created_at", "text": "QUIZ DATE & TIME"}],
            sort_column: "created_at",
            sort_order: "desc",
            is_delete_modal_shown: false,
            delete_modal_selected_id: "",
            is_full_page_loader_shown: false
        }
    },
    components: {
        fullPageLoader,
        pagination,
    },
    watch: {
        selected_show_entry(val) {
            this.current_page = 1;
            this.getVisitorList();
        },
    },
    mounted() {
        this.getVisitorList();
    },
    methods: {
        getVisitorList() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + '/pkO0OA17otP61RwETtNn/hipaachallenge/visitor-list', {
                    params: {
                        search: this.search,
                        selected_show_entry: this.selected_show_entry,
                        page: this.current_page,
                        sort_column: this.sort_column,
                        sort_order: this.sort_order,
                    },
                })
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        let data = response.data.data;
                        this.visitors = data.data;
                        this.current_page = data.current_page;
                        this.total_page = data.last_page;
                        this.per_page = data.per_page;
                        this.pagination_links = data.links;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/login";
                    }
                })
                .then(() => {
                    this.is_full_page_loader_shown = false;
                })
        },
        createSignUrl(file_name){
            this.is_full_page_loader_shown = true
            var scorecard_download_url ;
            var request = {
                params: {
                    file_path: '/hipaachallenge/'+ file_name,
                }
            }
            axios
            .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/hipaachallenge/get-sign-url",request)
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    scorecard_download_url = response.data.data;
                    this.downloadScorecard(scorecard_download_url,file_name)
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            }).then(()=>{
                this.is_full_page_loader_shown = false
            });
        },
        downloadScorecard(scorecard_download_url,file_name) {
            if (scorecard_download_url != null) {
                this.is_full_page_loader_shown = true
                axios({
                    url: scorecard_download_url,
                    method: "GET",
                    responseType: "blob",
                }).then((response) => {
                    var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                    var fileLink = document.createElement("a");
                    fileLink.href = fileURL;
                    fileLink.setAttribute("download", file_name);
                    document.body.appendChild(fileLink);
                    fileLink.click();
                }).then(()=>{
                    this.is_full_page_loader_shown = false
                });
            }
        },
        sortByColumn(column) {
            if (column === this.sort_column) {
                this.sort_order = this.sort_order === "asc" ? "desc" : "asc";
            } else {
                this.sort_column = column;
                this.sort_order = "asc";
            }
                this.getVisitorList();
        },
        changePage(page) {
            this.current_page = page;
            this.getVisitorList();
        },
        applySearch() {
            this.current_page = 1;
            if (this.timer) {
                clearTimeout(this.timer);
                this.timer = null;
            }
            this.timer = setTimeout(() => {
                this.getVisitorList();
            }, 500);
        },
    }
}
</script>
