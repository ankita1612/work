<template>
  <div>
    <nav>
        <ul class="pagination justify-content-end">
        <li
        class="page-item"  
        v-for="(pagination_item, index) in pagination_links" :key="index"
        :class="paginationClass(pagination_item)"
        >
        <a
        v-if="pagination_item.label.includes('Previous')"
        class="page-link"
        @click="changePage(current_page - 1, pagination_item)"
        href="javascript:void(0)"
        v-html="pagination_item.label"
        >                              
        </a>
        <a
        v-else-if="!pagination_item.label.includes('Previous') && !pagination_item.label.includes('Next')"
        class="page-link"
        @click="changePage(parseInt(pagination_item.label), pagination_item)"
        href="javascript:void(0)"
        v-html="pagination_item.label"
        >                              
        </a>
        <a
        v-else
        class="page-link"
        @click="changePage(current_page + 1, pagination_item)"
        href="javascript:void(0)"
        v-html="pagination_item.label"
        >                              
        </a>
        </li>
        </ul>
    </nav>
  </div>
</template>

<script scoped>

export default {
  data() {
    return {
    };
  },
  emits:["change-page"],
  props: ["pagination_links","current_page","total_page"],
  components: {
  },
  watch: {
  },
  computed: { 
  },
  mounted() {
  },
  methods: {
      paginationClass(pagination_item){
          if(pagination_item.label.includes('Previous')){
            return (this.current_page == 1)?'disabled':'';
          }else if(pagination_item.label.includes('Next')){
            return (this.current_page == this.total_page)?'disabled':'';
          }else if(pagination_item.label.includes('...')){
            return 'disabled';  
          }else{
            return (this.current_page == parseInt(pagination_item.label))?'active':'';
          }
      },
      changePage(page, pagination_item){
        if(this.current_page != parseInt(pagination_item.label)){
          this.$emit('change-page', page);
        }
      }
  }
};
</script>
