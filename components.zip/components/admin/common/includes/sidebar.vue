<template>
    <div class="vertical-menu">
        <div data-simplebar class="h-100">
            <div id="sidebar-menu">
                <ul class="metismenu list-unstyled" id="side-menu">
                    <li v-for="(eachModule, eachModuleKey, index) in allowed_modules" :key="index"
                        :class="[eachModule.is_open ? 'mm-active' : '']"
                        v-on:click="(eachModule.has_sub_menu) ? toggleMenu(eachModuleKey) : ''">
                        <a :href="(eachModule.has_sub_menu) ? 'javascript:void(0);' : JS_APP_URL + '/pkO0OA17otP61RwETtNn/' + eachModule.url_slug"
                            class="waves-effect" :class="[eachModule.has_sub_menu ? 'has-arrow' : '']">
                            <i class="bx" :class="eachModule.menu_icon"></i>
                            <span>{{ eachModule.name }}</span>
                        </a>
                        <ul v-if="eachModule.has_sub_menu" class="sub-menu" aria-expanded="false"
                            :class="[eachModule.is_open ? 'd-block' : 'd-none']">
                            <li :class="[eachModule.is_view_open ? 'mm-active' : '']"><a
                                    :href="JS_APP_URL + '/pkO0OA17otP61RwETtNn/' + eachModule.url_slug + '/view'" v-if="eachModule.name != 'HIPAA Challenge' && eachModule.name != 'Logs' && eachModule.name != 'HIPAA Gap Assessment'">View</a></li>
                            <li :class="[eachModule.is_add_open ? 'mm-active' : '']" v-if="eachModule.name != 'User' && eachModule.name != 'HIPAA Challenge' && eachModule.name != 'Logs' && eachModule.name != 'HIPAA Gap Assessment'"><a
                                    :href="JS_APP_URL + '/pkO0OA17otP61RwETtNn/' + eachModule.url_slug + '/add'">Add</a></li>
                            <li :class="[eachModule.is_view_open ? 'mm-active' : '']" v-if="eachModule.name == 'HIPAA Challenge' || eachModule.name == 'HIPAA Gap Assessment'"><a
                                    :href="JS_APP_URL + '/pkO0OA17otP61RwETtNn/' + eachModule.url_slug + '/visitor'">Visitor</a></li>
                            <li :class="[eachModule.is_view_open ? 'mm-active' : '']" v-if="eachModule.name == 'Logs'"><a
                                    :href="JS_APP_URL + '/pkO0OA17otP61RwETtNn/' + eachModule.url_slug + '/ba-promotion'">BA Promotion</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from "lodash";

export default {
    data() {
        return {
            current_url: [],
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
            allowed_modules: [],
            AUTH_USER: AUTH_USER
        };
    },
    components: {
    },
    validations: {
    },
    mounted() {
        this.current_url = new URL(window.location.href).pathname.split("/");
        this.getModuleAccess();
    },
    watch: {
    },
    computed: {},
    methods: {
        toggleMenu(menu_key) {
            this.allowed_modules[menu_key].is_open = !this.allowed_modules[menu_key].is_open
        },
        getModuleAccess() {
            axios
                .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/dashboard/get-module-access")
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        _.forEach(response.data.data.role.accessible_modules, (value)=> {
                            var menu_icon = '';
                            switch (value.url_slug) {
                                case 'dashboard':
                                    menu_icon = 'bx bx-home-circle'
                                    break;
                                case 'admin':
                                    menu_icon = 'bx bx-user-circle'
                                    break;
                                case 'user':
                                    menu_icon = 'bx bx-user'
                                    break;
                                case 'site-policies':
                                    menu_icon = 'bx bx-shield-quarter'
                                    break;
                                case 'ongoingquestion':
                                    menu_icon = 'bx-infinite'
                                    break;
                                case 'whatsnew':
                                    menu_icon = 'bx bxs-megaphone'
                                    break;
                                case 'security-risk-analysis':
                                    menu_icon = 'bx-question-mark'
                                    break;
                                case 'training':
                                    menu_icon = 'bx bxs-graduation'
                                    break;
                                case 'trainingquestion':
                                    menu_icon = 'bx-question-mark'
                                    break;
                                case 'promocode':
                                    menu_icon = 'bx bxs-gift'
                                    break;
                                case 'hipaachallenge':
                                    menu_icon = 'bx-question-mark'
                                    break;
                                case 'hipaagapassessment':
                                    menu_icon = 'bx-question-mark'
                                    break;
                                case 'logs':
                                    menu_icon = 'bx bxs-report'
                                    break;
                                default:
                                    menu_icon = ''
                            }
                            var is_view_open = false;
                            var is_add_open = false;
                            if(this.current_url[2] == value.url_slug){
                                if(!_.isUndefined(this.current_url[3])){
                                    if(this.current_url[3] == 'view' || this.current_url[3] == 'visitor'){
                                        is_view_open = true;
                                    }
                                    if(this.current_url[3] == 'add'){
                                        is_add_open = true;
                                    }
                                }
                            }
                            this.allowed_modules.push({
                                'id': value.id,
                                'name': value.name,
                                'url_slug': value.url_slug,
                                'is_open': (this.current_url.length > 0 && this.current_url[2] == value.url_slug) ? true : false,
                                'has_sub_menu': (value.url_slug == 'dashboard') ? false : true,
                                'menu_icon': menu_icon,
                                'is_view_open': is_view_open,
                                'is_add_open': is_add_open
                            });
                        });
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                });
        }
    },
};
</script>
