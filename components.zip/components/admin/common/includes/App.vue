<template>
<div>
    <header-after-login></header-after-login>
    <sidebar></sidebar>
    <slot></slot>
    <footer-after-login></footer-after-login>
</div>
</template>

<script scoped>
import headerAfterLogin from "./headerAfterLogin.vue";
import footerAfterLogin from "./footerAfterLogin.vue";
import sidebar from "./sidebar.vue";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  components: {
      headerAfterLogin,
      footerAfterLogin,
      sidebar,

  },
  validations: {
  },
  mounted() {
  },
  watch: {
  },
  computed: {},
  methods: {
  },
};
</script>
