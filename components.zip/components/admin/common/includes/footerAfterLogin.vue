<template>
<div>
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                   {{CURRENT_YEAR}} &copy; Abyde
                </div>
            </div>
        </div>
    </footer>
</div>
</template>

<script scoped>

export default {
  data () {
    return {
      CURRENT_YEAR: CURRENT_YEAR,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  components: {
  },
  validations: {
  },
  mounted () {
  },
  watch: {
  },
  computed: {},
  methods: {
  },
};
</script>
