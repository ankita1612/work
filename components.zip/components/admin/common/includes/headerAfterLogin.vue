<template>
<div>
    <header id="page-topbar">
        <div class="navbar-header">
            <div class="d-flex">
                <!-- LOGO -->
                <div class="navbar-brand-box d-flex justify-content-center align-items-center">
                <h1 class="text-white m-0">HIPAACE</h1>
                </div>

                <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect" id="vertical-menu-btn">
                    <i class="fa fa-fw fa-bars"></i>
                </button>
            </div>
            <div class="d-flex">
                <div class="me-3 text-end">            
                    <h5 class="mb-1">{{ AUTH_USER.first_name + " " + AUTH_USER.last_name }}</h5>
                    <a  :href="JS_APP_URL + '/pkO0OA17otP61RwETtNn/dashboard/logout'" class="text-danger"><i class="bx bx-power-off font-size-16 align-middle text-danger"></i> <span key="t-logout">Log Out</span></a>
                </div>
            </div>
        </div>
    </header>
</div>
</template>

<script scoped>

export default {
  data() {
    return {
      AUTH_USER: AUTH_USER,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  components: {
  },
  validations: {
  },
  mounted() {
  },
  watch: {
  },
  computed: {},
  methods: {
  },
};
</script>
