<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div
                class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                "
              >
                <h4 class="mb-sm-0 font-size-18">Update Site Policy</h4>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <form @submit.prevent="updateSitePolicies">
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.title.$error }"
                    >
                      <label
                        for="horizontal-firstname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Title</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Title"
                          id="horizontal-firstname-input"
                          v-model.trim="v$.title.$model"
                        />
                        <div v-if="v$.title.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.title.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.description.$error }"
                    >
                      <label
                        for="horizontal-lastname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Description</label
                      >
                      <div class="col-sm-8">
                        <editor
                          v-model.trim="v$.description.$model"
                          :api-key="TIYMCE_API_KEY"
                          @change="onDescriptionChange"
                          :init="{
                            height: 500,
                            menubar: true,
                            branding: false,
                            resize: false,
                            plugins: [
                              'advlist autolink lists link anchor',
                              'searchreplace',
                              'table paste',
                            ],
                            toolbar:
                              'undo redo | formatselect | bold italic | \
                                          alignleft aligncenter alignright alignjustify | \
                                          bullist numlist | removeformat',
                          }"
                        />
                        <div v-if="v$.description.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.description.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.display_order.$error }"
                    >
                      <label
                        for="horizontal-firstname-input"
                        class="col-sm-2 col-form-label"
                        >Display Order</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter First Name"
                          id="horizontal-firstname-input"
                          v-model.trim="v$.display_order.$model"
                        />
                        <div
                          class="form-error-text"
                          v-if="!v$.display_order.required"
                        >
                          Please enter display order.
                        </div>
                        <div
                          class="form-error-text"
                          v-if="
                            v$.display_order.required &&
                            !v$.display_order.isUnique
                          "
                        >
                          Please enter another order this order is all ready
                          use.
                        </div>
                      </div>
                    </div> -->
                    <div class="row">
                      <div class="col-sm-2"></div>
                      <div class="col-sm-8">
                        <div>
                          <button
                            type="button"
                            @click="backToView()"
                            class="btn btn-danger w-md"
                          >
                            CANCEL
                          </button>
                          &nbsp;
                          &nbsp;            
                          <button
                            :disabled="is_edit_btn_disabled"
                            type="submit"
                            class="btn btn-primary w-md"
                          >
                            UPDATE
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import Editor from "@tinymce/tinymce-vue";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../../common/fullPageLoader.vue";
import useVuelidate from "@vuelidate/core";
import {
    required,
    helpers,
} from "@vuelidate/validators";

export default {
  setup: () => ({ v$: useVuelidate() }),
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      TIYMCE_API_KEY: TIYMCE_API_KEY,
      SITE_POLICY_ID: SITE_POLICY_ID,
      title: "",
      description: "",
      description_clean: '',
      display_order: "",
      is_edit_btn_disabled: false,
      is_full_page_loader_shown: false,
      check_order_display_available_timer: null,
    };
  },
  components: {
    fullPageLoader,
    Editor,
  },
  validations(){  
    return {
      title: {
        required: helpers.withMessage(
          "Please enter a title",
          required
        )
      },
      description: {
        required: helpers.withMessage(
          "Please enter a description",
          required
        )
      }
    }
  },
  methods: {
    onDescriptionChange(event, editor) {
        this.description_clean = editor.getContent({format : 'text'});
    },
    getSitePoliciesDetails() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL +
            "/pkO0OA17otP61RwETtNn/site-policies/get-site-policies-edit-detail/" +
            SITE_POLICY_ID
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            let data = response.data.data;
            this.title = data.title;
            this.description = data.description;
            this.description_clean = data.description;
            this.display_order = data.display_order;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    updateSitePolicies() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        if(this.description_clean.trim() === ""){
          toastr.error('Please enter a valid description', "Error");
          return false;
        }
        NProgress.start();
        this.is_edit_btn_disabled = true;
        axios
          .post(
            JS_APP_URL +
              "/pkO0OA17otP61RwETtNn/site-policies/update-site-policies",
            {
              site_policy_id: SITE_POLICY_ID,
              title: this.title,
              description: this.description,
              display_order: this.display_order,
            }
          )
          .then((response)=> {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              setTimeout(() => {
                window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/site-policies/view";
              }, 500);
              toastr.success(response["data"]["message"], "Success");
            }
          })
          .catch((error)=> {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
            }
          })
          .then(() => {
            //this.is_edit_btn_disabled = false;
            NProgress.done();
          });
      }
    },
    backToView() {
      window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/site-policies/view";
    },
  },
  mounted() {
    this.getSitePoliciesDetails();
  },
};
</script>
