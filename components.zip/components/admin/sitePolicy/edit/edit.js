import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import sitePolicyEdit from "./edit.vue";
import app from "../../common/includes/App.vue"
const edit_app = createApp({
    template: `
    <app>
    <site-policy-edit></site-policy-edit>
    </app>
    `,
    components: {
        app,
        'site-policy-edit': sitePolicyEdit,
    }
});
edit_app.use(useVuelidate);
edit_app.mount("#edit_app");