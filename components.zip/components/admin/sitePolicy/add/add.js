import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import sitePolicyAdd from "./add.vue";
import app from "../../common/includes/App.vue"
const add_app = createApp({
    template: `
    <app>
    <site-policy-add></site-policy-add>
    </app>
    `,
    components: {
        app,
        'site-policy-add': sitePolicyAdd,
    }
});
add_app.use(useVuelidate);
add_app.mount("#add_app");