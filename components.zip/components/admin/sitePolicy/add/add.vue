<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
              <div class="col-12">
                  <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                      <h4 class="mb-sm-0 font-size-18">Add New Site Policy</h4>
                  </div>
              </div>
          </div>
  
          <div class="row">
              <div class="col-xl-12">
                  <div class="card">
                      <div class="card-body">
                          <form @submit.prevent="addSitePolicies">
                              <div class="row mb-4" :class="{ 'form-group--error': v$.title.$error }">
                                  <label for="horizontal-firstname-input" class="col-sm-2 col-form-label text-end">Title</label>
                                  <div class="col-sm-8">
                                      <input type="text" class="form-control" placeholder="Enter Title" id="horizontal-firstname-input" v-model.trim="v$.title.$model">
                                      <div v-if="v$.title.$errors.length > 0">
                                        <div class="form-error-text">
                                            {{ v$.title.$errors[0].$message }}
                                        </div>
                                      </div>
                                  </div>
                              </div>
                              <div class="row mb-4" :class="{ 'form-group--error': v$.description.$error }">
                                  <label for="horizontal-lastname-input" class="col-sm-2 col-form-label text-end">Description</label>
                                  <div class="col-sm-8">
                                      <editor
                                        v-model.trim="v$.description.$model" 
                                        :api-key="TIYMCE_API_KEY"
                                        @change="onDescriptionChange"
                                        :init="{
                                          height: 500,
                                          menubar: true,
                                          branding: false,
                                          resize: false,
                                          plugins: [
                                            'advlist autolink lists link anchor',
                                            'searchreplace',
                                            'table paste'
                                          ],
                                          toolbar:
                                            'undo redo | formatselect | bold italic | \
                                            alignleft aligncenter alignright alignjustify | \
                                            bullist numlist | removeformat'
                                        }"
                                      />
                                      <div v-if="v$.description.$errors.length > 0">
                                        <div class="form-error-text">
                                            {{ v$.description.$errors[0].$message }}
                                        </div>
                                      </div>
                                  </div>
                              </div>
  
                              <div class="row">
                                  <div class="col-sm-2">
                                  </div>
                                  <div class="col-sm-8">
                                      <div>
                                          <button
                                            type="button"
                                            @click="backToView()"
                                            class="btn btn-danger w-md"
                                          >
                                            CANCEL
                                          </button>
                                          &nbsp;
                                          &nbsp;
                                          <button :disabled="is_add_btn_disabled" type="submit" class="btn btn-primary w-md">ADD</button>
                                      </div>
                                  </div>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
  
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
  </template>
  
  <script scoped>
  import axios from "axios";
  import Editor from '@tinymce/tinymce-vue'
  import NProgress from "nprogress";
  import toastr from "toastr";
  import "toastr/toastr.scss";
  toastr.options.preventDuplicates = true;
  import fullPageLoader from "../../common/fullPageLoader.vue";
  import useVuelidate from "@vuelidate/core";
  import {
      required,
      helpers,
  } from "@vuelidate/validators";
  
  
  
  export default {
    setup: () => ({ v$: useVuelidate() }),
    data() {
      return {
        JS_APP_URL: JS_APP_URL,
        JS_WORDPRESS_URL: JS_WORDPRESS_URL,
        TIYMCE_API_KEY: TIYMCE_API_KEY,
        description_clean: '',
        title:'',
        description:'',
        is_add_btn_disabled: false,
        is_full_page_loader_shown: false,
      };
    },
    components: {
      fullPageLoader,
      Editor,
    },
    validations(){  
      return {
        title: {
          required: helpers.withMessage(
            "Please enter a title",
            required
          )
        },
        description: {
          required: helpers.withMessage(
            "Please enter a description",
            required
          )
        }
      }
    },
    mounted() {},
    watch: {},
    computed: {},
    methods:{
        onDescriptionChange(event, editor) {
          this.description_clean = editor.getContent({format : 'text'});
        },
        addSitePolicies(){
          this.v$.$touch();
          if (!this.v$.$invalid) {
            if(this.description_clean.trim() === ""){
              toastr.error('Please enter a valid description', "Error");
              return false;
            }
            NProgress.start();
            this.is_add_btn_disabled = true;
            axios.post(JS_APP_URL  + "/pkO0OA17otP61RwETtNn/site-policies/add-site-policies",{
              title:this.title,
              description:this.description,
            })
            .then((response) => {
              if (response["data"]["status"] == "Error") {
                  if(response["data"]['data'].length > 0){
                      toastr.error(response["data"]['data'].join('</br>'), "Error");
                  }else{
                      toastr.error(response["data"]["message"], "Error");
                  }
              } else {
                toastr.success(response["data"]["message"], "Success");
                setTimeout(() => {
                  window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/site-policies/view";
                }, 1000);
              }
            })
            .catch((error)=> {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
              }
            })
            .then(()=> {
              NProgress.done();
              //this.is_add_btn_disabled = false;
            });
          }
        },
         backToView() {
          window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/site-policies/view";
        },
    },  
  };
  </script>
  