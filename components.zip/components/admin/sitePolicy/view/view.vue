<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div
                class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                "
              >
                <h4 class="mb-sm-0 font-size-18">Site Policies</h4>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <div class="row mb-2">
                    <div class="col-sm-12 col-md-6">
                      <div>
                        <label
                          >Show
                          <select
                            v-model.trim="selected_show_entry"
                            class="
                              custom-select custom-select-sm
                              form-control
                              form-control-sm
                              form-select
                              form-select-sm
                              d-inline-block
                              w-auto
                              ms-2
                              me-2
                            "
                          >
                            <option :value="entry" v-for="entry in show_entry_list" :key="entry">{{entry}}</option>
                          </select>
                          entries
                        </label>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-6 text-end">
                      <div>
                        <label
                          ><span>Search:</span
                          ><input
                            type="text"
                            class="
                              form-control form-control-sm
                              d-inline-block
                              w-auto
                              ms-2
                            "
                            v-model.trim="search"
                            @input="applySearch()"
                            placeholder="Search"
                        /></label>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-xl-12">
                      <table
                        class="
                          table table-responsive table-bordered
                          mb-0
                          dataTable
                          table-fixed
                        "
                      >
                        <thead class="table-light">
                          <tr>
                            <th
                              v-for="column in columns"
                              :key="column.id"
                              @click="sortByColumn(column.id)"
                              class="sorting"
                              :class="[(column.id === sort_column)?(sort_order == 'asc')?'sorting_asc':'sorting_desc':'']"
                            >
                              {{ column.text }}
                            </th>
                            <th>ACTION</th>
                          </tr>
                        </thead>
                        <tbody v-if="site_policies.length > 0">
                          <tr v-for="(site_policy, index) in site_policies" :key="index">
                            <td>{{ site_policy.title }}</td>
                            <td>{{ site_policy.display_order }}</td>
                            <td>{{ formatDateTime(site_policy.created_at) }}</td>
                            <td>
                              
                              <a title="Edit" style="margin-right: 2px;" :href="JS_APP_URL + '/pkO0OA17otP61RwETtNn/site-policies/edit/' + site_policy.id" class="btn btn-primary waves-effect waves-light"><i class="bx bx-edit font-size-18 align-middle me-0"></i></a>
                              &nbsp;
                              <button title="Delete" type="button"  @click="deleteModalToggle(site_policy.id)" class="btn btn-danger waves-effect waves-light"><i class="bx bx-trash font-size-18 align-middle me-0"></i></button>
                            </td>
                          </tr>
                        </tbody>
                        <tbody v-else>
                          <tr>
                            <td colspan="4" class="text-center">
                              No records available!
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="row mt-3">
                    <div class="col-xl-12">
                      <pagination 
                      v-if="site_policies.length > 0"
                      :current_page="current_page"
                      :total_page="total_page"
                      :pagination_links="pagination_links"
                      @change-page="changePage"
                      >
                      </pagination>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <delete-site-policies-modal
      v-if="is_delete_modal_shown"
      @close-modal="is_delete_modal_shown = false"
      @site-policies-deleted="sitePoliciesDeleted"
      :delete_modal_selected_id="delete_modal_selected_id"
    >
    </delete-site-policies-modal>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from "lodash";
import deleteSitePoliciesModal from "./deleteSitePoliciesModal.vue";
import fullPageLoader from "../../common/fullPageLoader.vue";
import moment from 'moment';
import pagination from "../../common/pagination.vue";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      site_policies: [],
      search: null,
      total_page: "",
      current_page: 1,
      pagination_links: [],
      per_page: "",
      selected_show_entry: 10,
      show_entry_list: [10, 25, 50, 100],
      columns: [{"id": "title", "text": "TITLE"}, {"id": "display_order", "text": "DISPLAY ORDER"}, {"id": "created_at", "text": "ADDED DATE"}],
      sort_column: "created_at",
      sort_order: "desc",
      is_delete_modal_shown: false,
      delete_modal_selected_id: "",
      is_full_page_loader_shown: false
    };
  },
  components: {
    deleteSitePoliciesModal,
    fullPageLoader,
    pagination
  },
  watch: {
    selected_show_entry(val) {
      this.current_page = 1;
      this.getSitePoliciesList();
    },
  },
  computed: { 
  },
  mounted() {
    this.getSitePoliciesList();
  },
  methods: {
    formatDateTime(value){
      return moment.utc(String(value)).local().format('MM/DD/YYYY hh:mm A');
    },
    getSitePoliciesList(call_from = '') {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/site-policies/site-policies-list", {
          params: {
            search: this.search,
            selected_show_entry: this.selected_show_entry,
            page: this.current_page,
            sort_column: this.sort_column,
            sort_order: this.sort_order,
          },
        })
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            let data = response.data.data;
            this.site_policies = data.data;
            this.current_page = data.current_page;
            this.total_page = data.last_page;
            this.per_page = data.per_page;
            this.pagination_links = data.links;
            if(call_from == 'delete_action' && this.site_policies.length == 0){
              this.search = null;
              this.getSitePoliciesList();              
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    deleteModalToggle(id) {
      this.delete_modal_selected_id = id;
      this.is_delete_modal_shown = true;
    },
    sitePoliciesDeleted() {
      this.current_page = 1;
      this.getSitePoliciesList('delete_action');
      this.is_delete_modal_shown = false;
    },
    sortByColumn(column) {
      if (column === this.sort_column) {
        this.sort_order = this.sort_order === "asc" ? "desc" : "asc";
      } else {
        this.sort_column = column;
        this.sort_order = "asc";
      }
      this.getSitePoliciesList();
    },
    changePage(page) {
      this.current_page = page;
      this.getSitePoliciesList();
    },
    applySearch() {
      this.current_page = 1;
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      this.timer = setTimeout(() => {
        this.getSitePoliciesList();
      }, 500);
    },
  }
};
</script>
