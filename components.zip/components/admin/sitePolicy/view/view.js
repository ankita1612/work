import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import sitePolicyView from "./view.vue";
import app from "../../common/includes/App.vue"
const view_app = createApp({
    template: `
    <app>
    <site-policy-view></site-policy-view>
    </app>
    `,
    components: {
        app,
        'site-policy-view': sitePolicyView,
    }
});
view_app.use(useVuelidate);
view_app.mount("#view_app");