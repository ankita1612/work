<template>
<transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper animate__animated animate__zoomIn">
        <div class="modal-container">
          <div v-if="!is_btn_disabled" v-on:click="$emit('close-modal')" class="cursor-pointer modal-close">
            <close-icon></close-icon>
          </div>
          <div class="text-center">
            <i class="bx bx-error-circle text-muted" style="font-size: 100px"></i>
          </div>
          <p class="text-center mb-4 mt-4">Are you sure you want to delete this Site Policy? Once deleted you will not be able to recover information. </p>
          <div class="flex flex-wrap items-center justify-center pb40">
             <button
              type="button"
              class="btn btn-danger"
              data-dismiss="modal"
              @click="$emit('close-modal')"
              :disabled="is_btn_disabled"
            >
              NO
            </button>
            <button :disabled="is_btn_disabled" type="button" class="btn btn-primary ms-2" @click="deleteSitePolicies(delete_modal_selected_id)">
              YES
            </button>
          </div>
        </div>
      </div>
    </div>
  </transition>
  
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import closeIcon from '../../common/icons/closeIcon.vue';
import toastr from "toastr";
import "toastr/toastr.scss";

export default {
  data(){
    return {
      is_btn_disabled: false
    }
  },
  emits: ["site-policies-deleted", "close-modal"],
  props: ["delete_modal_selected_id"],
  components:{closeIcon},
  methods: {
    deleteSitePolicies(id) {
      NProgress.start();
      this.is_btn_disabled = true;
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/site-policies/site-policies-delete/" + id)        
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            toastr.success(response["data"]["message"], "Success");
            this.$emit("site-policies-deleted");
          }else{
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
          this.is_btn_disabled = false;
        });
    },
  },
   created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.is_btn_disabled) {
        this.$emit("close-modal");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>

<style>

</style>
