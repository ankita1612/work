import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import VuePlyr from 'vue-plyr';
import 'vue-plyr/dist/vue-plyr.css';
import whatsnewEdit from "./edit.vue";
import app from "../../common/includes/App.vue"
const edit_app = createApp({
    template: `
    <app>
    <whatsnew-edit></whatsnew-edit>
    </app>
    `,
    components: {
        app,
        'whatsnew-edit': whatsnewEdit,
    }
});
edit_app.use(useVuelidate);
edit_app.use(VuePlyr, {
    plyr: {}
});  
edit_app.component('multiselect', Multiselect);
edit_app.mount("#edit_app");
