<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div
                class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                "
              >
                <h4 class="mb-sm-0 font-size-18">Update What's New</h4>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <form
                    @submit.prevent="updateWhatsnew"
                    enctype="multipart/form-data"
                  >
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.title.$error }"
                    >
                      <label
                        for="horizontal-firstname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Title</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Title"
                          id="horizontal-firstname-input"
                          v-model.trim="v$.title.$model"
                        />
                        <div v-if="v$.title.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.title.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      class="row mb-4"
                      :class="{
                        'form-group--error': v$.short_description.$error,
                      }"
                    >
                      <label
                        for="horizontal-lastname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Short Description</label
                      >
                      <div class="col-sm-8">
                        <editor
                          v-model.trim="v$.short_description.$model"
                          :api-key="TIYMCE_API_KEY"
                          @change="onShortDescriptionChange"
                          :init="{
                            height: 500,
                            menubar: true,
                            branding: false,
                            resize: false,
                            plugins: [
                              'advlist autolink lists link anchor',
                              'searchreplace',
                              'table paste',
                            ],
                            toolbar:
                              'undo redo | formatselect | bold italic | \
                                          alignleft aligncenter alignright alignjustify | \
                                          bullist numlist | removeformat',
                          }"
                        />
                        <div v-if="v$.short_description.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.short_description.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.description.$error }"
                    >
                      <label
                        for="horizontal-lastname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Description</label
                      >
                      <div class="col-sm-8">
                        <editor
                          v-model.trim="v$.description.$model"
                          :api-key="TIYMCE_API_KEY"
                          @change="onDescriptionChange"
                          :init="{
                            height: 500,
                            menubar: true,
                            branding: false,
                            resize: false,
                            plugins: [
                              'advlist autolink lists link anchor',
                              'searchreplace',
                              'table paste',
                            ],
                            toolbar:
                              'undo redo | formatselect | bold italic | \
                                          alignleft aligncenter alignright alignjustify | \
                                          bullist numlist | removeformat',
                          }"
                        />
                        <div v-if="v$.description.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.description.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.file.$error }"
                    >
                      <label class="col-sm-2 col-form-label text-end"
                        >Media</label
                      >
                      <div class="col-sm-8">
                        <input
                          accept="image/*,video/*"
                          class="form-control"
                          type="file"
                          @change="onMediaChange"
                        />
                        <div v-if="v$.file.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.file.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="row mb-4">
                      <label class="col-sm-2 col-form-label text-end"
                        >Current Media</label
                      >
                      <div class="col-sm-4">
                        <img
                          v-if="current_media_type == 'image'"
                          :src="current_media_path"
                          class="img-fluid"
                        />
                        <vue-plyr
                          :options="plyr_options"
                          v-if="current_media_type == 'video'"
                        >
                          <video controls>
                            <source
                              :src="current_media_path"
                              type="video/mp4"
                            />
                          </video>
                        </vue-plyr>
                      </div>
                      <div class="col-sm-4"></div>
                    </div>

                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.post_date.$error }"
                    >
                      <label class="col-sm-2 col-form-label text-end"
                        >Post Date</label
                      >
                      <div class="col-sm-8">
                        <date-picker
                          class="form-control"
                          v-model:value="v$.post_date.$model"
                          format="MM-DD-YYYY"
                          titleFormat="MM-DD-YYYY"
                          valueType="YYYY-MM-DD"
                          :editable="false"
                        ></date-picker>
                        <br>    
                        <div v-if="v$.post_date.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.post_date.$errors[0].$message }}
                          </div>
                        </div>
                        <span class="float-start text-primary fs-6 mt-2">* Please select a date as per GMT timezone.</span>                       
                      </div>
                    </div>

                    <div class="row mb-4"> 
                      <label class="col-sm-2 col-form-label text-end"> Select State(s) </label>
                      <div class="col-sm-8"> 
                        <multiselect
                          class="font-style-normal"
                          v-model.trim="state_obj"
                          placeholder="Select State(s)"
                          :options="all_state_list"
                          track-by="id"
                          label="state_name"
                          :multiple="true"
                          :close-on-select="false"
                          position="bottom"
                          :showLabels="false"
                          :allowEmpty="true">
                          <template #noResult>
                            <div class="multiselect__noResult text-center">
                              No results found
                            </div>
                          </template>
                          <template #noOptions>
                            <div class="multiselect__noOptions text-center">
                              No data available
                            </div>
                          </template>
                          <template #selection>
                            <div class="multiselect__tags-wrap" v-if="state_obj.length > 1">
                              <span class="multiselect__tag">
                                <span>{{ state_obj.length }} States Selected</span>
                              </span>
                            </div>
                          </template>
                        </multiselect>
                      </div>
                    </div>

                    <div class="row mb-4">
                      <label
                        for="horizontal-email-input"
                        class="col-sm-2 col-form-label text-end pt-0"
                        >Status</label
                      >
                      <div class="col-md-8">
                        <div
                          class="form-check form-switch form-switch-md mb-3"
                          dir="ltr"
                        >
                          <input
                            class="form-check-input"
                            type="checkbox"
                            id="whatsnew_status"
                            v-model.trim="is_active"
                          />
                          <label
                            class="form-check-label"
                            for="whatsnew_status"
                            v-text="is_active ? 'Active' : 'Inactive'"
                          ></label>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-sm-2"></div>
                      <div class="col-sm-8">
                        <div>
                          <button
                            type="button"
                            @click="backToView()"
                            class="btn btn-danger w-md"
                          >
                            CANCEL
                          </button>
                          &nbsp;
                          &nbsp;
                          <button
                            :disabled="is_edit_btn_disabled"
                            type="submit"
                            class="btn btn-primary w-md"
                          >
                            UPDATE
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import Editor from "@tinymce/tinymce-vue";
import DatePicker from 'vue-datepicker-next';
import 'vue-datepicker-next/index.css';
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import useVuelidate from "@vuelidate/core";
import {
    required,
    helpers,
} from "@vuelidate/validators";
import fullPageLoader from "../../common/fullPageLoader.vue";
import moment from "moment";
import _ from "lodash";

const is_valid_image_video = (value) => {
  if (typeof value !== 'undefined'){
    if (value.length === 0) {
      return true;
    }
    var re = /(\.jpg|\.jpeg|\.mp4|\.png)$/i;
    if (!re.exec(value.name)) {
      return false;
    }else{
      return true;
    }
  }else{
    return true;
  }
}

export default {
  setup: () => ({ v$: useVuelidate() }),
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      WHATSNEW_ID: WHATSNEW_ID,
      TIYMCE_API_KEY: TIYMCE_API_KEY,
      title: "",
      short_description: "",
      short_description_clean: "",
      description: "",
      description_clean: '',
      post_date: "",
      file: [], // New changes
      media_type: "",
      current_media_type: "",
      current_media_path: "",
      is_active: "",
      is_edit_btn_disabled: false,
      is_full_page_loader_shown: false,
      check_order_display_available_timer: null,
      plyr_options: {
        title: this.title,
        controls: [
          "play-large",
          "play",
          "progress",
          "current-time",
          "mute",
          "volume",
          "captions",
          "airplay",
          "fullscreen",
        ],
      },
      all_state_list: [],
      state_obj: [],
      whatsnew_data: []
    };
  },
  components: {
    fullPageLoader,
    Editor,
    DatePicker,
  },
  validations(){
    return {
      title : {
        required: helpers.withMessage("Please enter a title",required),
      },
      short_description : {
        required: helpers.withMessage("Please enter a short description",required),
      },
      description : {
        required: helpers.withMessage("Please enter a description",required),
      },
      post_date : {
        required: helpers.withMessage("Please enter a post date",required),
      },
      file: {
        isValidImage: helpers.withMessage("Please select a valid image(jpg, png) or video(mp4) file",is_valid_image_video)
      }
    }
  },
  methods: {
    onShortDescriptionChange(event, editor) {
        this.short_description_clean = editor.getContent({format : 'text'});
    },
    onDescriptionChange(event, editor) {
      this.description_clean = editor.getContent({format : 'text'});
    },
    onMediaChange(e) {
      this.file = (typeof e.target.files[0] !== 'undefined')?e.target.files[0] : [];
      this.media_type = (typeof e.target.files[0] !== 'undefined')?e.target.files[0].type : "";
      this.is_edit_btn_disabled = false;
    },
    getWhatsnewDetails() {
      this.is_full_page_loader_shown = true;
      axios
        .get(
          JS_APP_URL + "/pkO0OA17otP61RwETtNn/whatsnew/get-whatsnew-edit-detail/" + WHATSNEW_ID
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.whatsnew_data = response.data.data;
            let data = response.data.data;
            this.title = data.title;
            this.short_description = data.short_description;
            this.short_description_clean = data.short_description;
            this.description = data.description;
            this.description_clean = data.description;
            this.post_date = data.post_date;
            this.is_active = data.is_active == 1 ? true : false;
            this.current_media_type = data.media_type;
            this.current_media_path = data.media_path;
            _.forEach(response.data.data.whatsnew_state, (value) => {
              var is_found_states = _.find(this.all_state_list, (o) => { 
                return o.id === value.states.id; 
              });
              if(!_.isUndefined(is_found_states)){
                this.state_obj.push(is_found_states);
              }
            }); 
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    updateWhatsnew() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        if(this.short_description_clean.trim() === ""){
          toastr.error('Please enter a valid short description', "Error");
          return false;
        }
        if(this.description_clean.trim() === ""){
          toastr.error('Please enter a valid description', "Error");
          return false;
        }
        var state_new = new Array();
        var state_remove = new Array();
        if(this.all_state_list.length > 1){
          _.forEach(this.state_obj, (value)=> {
            if(_.isUndefined( _.find(this.whatsnew_data.whatsnew_state, (o)=> { 
              return o.states.id == value.id; 
            }))){
                state_new.push({"state_id": value.id});
            }
          });
          _.forEach(this.whatsnew_data.whatsnew_state, (value)=> {
            if(_.isUndefined( _.find(this.state_obj, (o)=> { 
              return o.id == value.states.id; 
            }))){
              state_remove.push({"state_id": value.states.id});
            }
          });
        }

        NProgress.start();
        this.is_edit_btn_disabled = true;
        let formData = new FormData();
        formData.append("title", this.title);
        formData.append("short_description", this.short_description);
        formData.append("description", this.description);
        if (this.file) {
          formData.append("file", this.file);
        }
        formData.append("media_type", this.media_type);
        formData.append("post_date", this.post_date);
        formData.append("is_active", this.is_active);
        formData.append("whatsnew_id", WHATSNEW_ID);
        if(state_new.length > 0) {
          formData.append("state_new", JSON.stringify(state_new));
        }
        if(state_remove.length > 0) {
          formData.append("state_remove", JSON.stringify(state_remove));
        }

        axios
          .post(
            JS_APP_URL + "/pkO0OA17otP61RwETtNn/whatsnew/update-whatsnew",
            formData,
            {
              headers: {
                "Content-Type": "multipart/form-data",
              },
            }
          )
          .then((response)=> {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              setTimeout(() => {
                window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/whatsnew/view";
              }, 500);
              toastr.success(response["data"]["message"], "Success");
            }
          })
          .catch((error)=> {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
            }
          })
          .then(() => {
            //this.is_edit_btn_disabled = false;
            NProgress.done();
          });
      }
    },
    backToView() {
      window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/whatsnew/view";
    },
    getStateList() {
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/whatsnew/state-list")
        .then((response) => {
          if(response["data"]["status"] == "Success") {
            this.all_state_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
        });
    }
  },
  mounted() {
    this.getStateList();
    this.getWhatsnewDetails();
 },
};
</script>
