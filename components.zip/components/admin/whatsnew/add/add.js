import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import whatsnewAdd from "./add.vue";
import app from "../../common/includes/App.vue"
const add_app = createApp({
    template: `
    <app>
    <whatsnew-add></whatsnew-add>
    </app>
    `,
    components: {
        app,
        'whatsnew-add': whatsnewAdd,
    }
});
add_app.use(useVuelidate);
add_app.component('multiselect', Multiselect);
add_app.mount("#add_app");