<template>
  <div>
    <div class="main-content">
      <div class="page-content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div
                class="
                  page-title-box
                  d-sm-flex
                  align-items-center
                  justify-content-between
                "
              >
                <h4 class="mb-sm-0 font-size-18">Add New What's New</h4>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-12">
              <div class="card">
                <div class="card-body">
                  <form
                    @submit.prevent="addWhatsnew"
                    enctype="multipart/form-data"
                  >
                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.title.$error }"
                    >
                      <label
                        for="horizontal-firstname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Title</label
                      >
                      <div class="col-sm-8">
                        <input
                          type="text"
                          class="form-control"
                          placeholder="Enter Title"
                          id="horizontal-firstname-input"
                          v-model.trim="v$.title.$model"
                        />
                        <div v-if="v$.title.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.title.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      class="row mb-4"
                      :class="{
                        'form-group--error': v$.short_description.$error,
                      }"
                    >
                      <label
                        for="horizontal-lastname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Short Description</label
                      >
                      <div class="col-sm-8">
                        <editor
                          v-model.trim="v$.short_description.$model"
                          :api-key="TIYMCE_API_KEY"
                          @change="onShortDescriptionChange"
                          :init="{
                            height: 500,
                            menubar: true,
                            branding: false,
                            resize: false,
                            plugins: [
                              'advlist autolink lists link anchor',
                              'searchreplace',
                              'table paste',
                            ],
                            toolbar:
                              'undo redo | formatselect | bold italic | \
                                          alignleft aligncenter alignright alignjustify | \
                                          bullist numlist | removeformat',
                          }"
                        />
                        <div v-if="v$.short_description.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.short_description.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.description.$error }"
                    >
                      <label
                        for="horizontal-lastname-input"
                        class="col-sm-2 col-form-label text-end"
                        >Description</label
                      >
                      <div class="col-sm-8">
                        <editor
                          v-model.trim="v$.description.$model"
                          :api-key="TIYMCE_API_KEY"
                          @change="onDescriptionChange"
                          :init="{
                            height: 500,
                            menubar: true,
                            branding: false,
                            resize: false,
                            plugins: [
                              'advlist autolink lists link anchor',
                              'searchreplace',
                              'table paste',
                            ],
                            toolbar:
                              'undo redo | formatselect | bold italic | \
                                          alignleft aligncenter alignright alignjustify | \
                                          bullist numlist | removeformat',
                          }"
                        />
                        <div v-if="v$.description.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.description.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.file.$error }"
                    >
                      <label
                        class="col-sm-2 col-form-label text-end"
                        >Media</label
                      >
                      <div class="col-sm-8">
                        <input
                          accept="image/*,video/*"
                          class="form-control"
                          type="file"
                          @change="onMediaChange"
                        />
                        <div v-if="v$.file.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.file.$errors[0].$message }}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      class="row mb-4"
                      :class="{ 'form-group--error': v$.post_date.$error }"
                    >
                      <label
                        class="col-sm-2 col-form-label text-end"
                        >Post Date</label
                      >
                      <div class="col-sm-8">
                        <date-picker
                          class="form-control"
                          v-model:value="v$.post_date.$model"
                          format="MM-DD-YYYY"
                          valueType="YYYY-MM-DD"
                          titleFormat="MM-DD-YYYY"
                          :editable="false"
                          placeholder="Select Date"
                        ></date-picker>
                        <br>   
                        <div v-if="v$.post_date.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.post_date.$errors[0].$message }}
                          </div>
                        </div>
                        <span class="float-start text-primary fs-6 mt-2">* Please select date as per GMT timezone.</span>                        
                      </div>
                    </div>
                    <div class="row mb-4"> 
                      <label class="col-sm-2 col-form-label text-end"> Select State(s) </label>
                      <div class="col-sm-8"> 
                        <multiselect
                          class="font-style-normal"
                          v-model.trim="state_obj"
                          placeholder="Select State(s)"
                          :options="all_state_list"
                          track-by="id"
                          label="state_name"
                          :multiple="true"
                          :close-on-select="false"
                          position="bottom"
                          :showLabels="false"
                          :allowEmpty="true">
                          <template #noResult>
                            <div class="multiselect__noResult text-center">
                              No results found
                            </div>
                          </template>
                          <template #noOptions>
                            <div class="multiselect__noOptions text-center">
                              No data available
                            </div>
                          </template>
                          <template #selection>
                            <div class="multiselect__tags-wrap" v-if="state_obj.length > 1">
                              <span class="multiselect__tag">
                                <span>{{ state_obj.length }} States Selected</span>
                              </span>
                            </div>
                          </template>
                        </multiselect>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-sm-2"></div>
                      <div class="col-sm-8">
                        <div>
                          <button
                            type="button"
                            @click="backToView()"
                            class="btn btn-danger w-md"
                          >
                            CANCEL
                          </button>
                          &nbsp;
                          &nbsp;
                          <button
                            :disabled="is_add_btn_disabled"
                            type="submit"
                            class="btn btn-primary w-md"
                          >
                            ADD
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script scoped>
import axios from "axios";
import Editor from "@tinymce/tinymce-vue";
import DatePicker from 'vue-datepicker-next';
import 'vue-datepicker-next/index.css';
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import useVuelidate from "@vuelidate/core";
import {
    required,
    helpers,
} from "@vuelidate/validators";
import fullPageLoader from "../../common/fullPageLoader.vue";
import moment from "moment";

const is_valid_image_video = (value) => {
  if (typeof value !== 'undefined'){
    if (value.length === 0) {
      return false;
    }
    var re = /(\.jpg|\.jpeg|\.mp4|\.png)$/i;
    if (!re.exec(value.name)) {
      return false;
    }else{
      return true;
    }
  }else{
    return false;
  }
}

export default {
  setup: () => ({ v$: useVuelidate() }),
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      TIYMCE_API_KEY: TIYMCE_API_KEY,
      title: "",
      short_description: "",
      short_description_clean: "",
      description: "",
      description_clean: '',
      post_date: null,
      file: [], // New changes
      media_type: "",
      is_add_btn_disabled: false,
      is_full_page_loader_shown: false,
      all_state_list: [],
      state_obj: []
    };
  },
  components: {
    fullPageLoader,
    Editor,
    DatePicker,
  },
  validations(){
    return {
      title : {
        required: helpers.withMessage("Please enter a title",required),
      },
      short_description : {
        required: helpers.withMessage("Please enter a short description",required),
      },
      description : {
        required: helpers.withMessage("Please enter a description",required),
      },
      post_date : {
        required: helpers.withMessage("Please enter a post date",required),
      },
      file: {
        isValidImage: helpers.withMessage("Please select a valid image(jpg, png) or video(mp4) file",is_valid_image_video)
      }
    }
  },
  mounted() {
    this.getStateList();
  },
  watch: {},
  computed: {},
  methods: {
    onShortDescriptionChange(event, editor) {
        this.short_description_clean = editor.getContent({format : 'text'});
    },
    onDescriptionChange(event, editor) {
      this.description_clean = editor.getContent({format : 'text'});
    },
    onMediaChange(e) {
      this.file = (typeof e.target.files[0] !== 'undefined')?e.target.files[0] : [];
      this.media_type = (typeof e.target.files[0] !== 'undefined')? e.target.files[0].type : ""; 
      this.is_add_btn_disabled = false;
    },
    addWhatsnew(e) {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        if(this.short_description_clean.trim() === ""){
          toastr.error('Please enter a valid short description', "Error");
          return false;
        }
        if(this.description_clean.trim() === ""){
          toastr.error('Please enter a valid description', "Error");
          return false;
        }
        NProgress.start();
        this.is_add_btn_disabled = true;
        e.preventDefault();

        let formData = new FormData();
        formData.append("title", this.title);
        formData.append("short_description", this.short_description);
        formData.append("description", this.description);
        if (this.file) {
          formData.append("file", this.file);
        }
        formData.append("media_type", this.media_type);
        formData.append("post_date", this.post_date);
        if(this.state_obj.length > 0) {
          formData.append("states",JSON.stringify(this.state_obj));
        }

        axios
          .post(JS_APP_URL + "/pkO0OA17otP61RwETtNn/whatsnew/add-whatsnew", formData, {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
            } else {
              toastr.success(response["data"]["message"], "Success");0
              setTimeout(() => {
                window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/whatsnew/view";
              }, 1000);
            }
          })
          .catch((error)=> {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "pkO0OA17otP61RwETtNn/login";
            }
          })
          .then(()=> {
            NProgress.done();
            //this.is_add_btn_disabled = false;
          });
      }
    },
    backToView() {
      window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/whatsnew/view";
    },
    getStateList() {
      axios
        .get(JS_APP_URL + "/pkO0OA17otP61RwETtNn/whatsnew/state-list")
        .then((response) => {
          if(response["data"]["status"] == "Success") {
            this.all_state_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/pkO0OA17otP61RwETtNn/login";
          }
        })
        .then(() => {
        });
    }
  },
};
</script>
<style scoped>
</style>