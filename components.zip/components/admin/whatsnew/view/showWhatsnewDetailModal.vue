<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask pdf-modal-mask">
        <div class="pdf-modal-overlay"></div>
        <div class="modal-wrapper animate__animated animate__zoomIn modal-xl">
          <div class="modal-container">
            <div
              v-on:click="$emit('close-modal')"
              class="cursor-pointer modal-close"
            >
              <close-icon></close-icon>
            </div>
            <div class="row m-0">
              <div class="col-12 whatsnew-detail-item">
                <div class="text-start">
                  <h5 class="border-bottom border-light mb-3 pb-2">Post Details</h5>
                </div>
                <div v-if="get_whatsnew_detail.media_type == 'image'" class="float-end w-50 ms-4 mb-4">
                    <img
                    class="img-fluid"
                      v-bind:src="get_whatsnew_detail.media_path"
                    />
                </div>
                <div v-else class="float-end w-50 ms-4 mb-4">
                  <vue-plyr :options="plyr_options"  v-if="get_whatsnew_detail.media_type == 'video'">
                    <video
                      controls
                    >
                      <source
                        :src="get_whatsnew_detail.media_path"
                        type="video/mp4"
                      />
                    </video>
                  </vue-plyr>
                </div>
                <div class="">
                  <p class="fs-2 text-start font-weight-bold mb-2">{{ get_whatsnew_detail.title }}</p>
                  <p class="fs-6 text-start fw-bold fst-italic mb-3">{{ formattedPostDate(get_whatsnew_detail.post_date) }}</p>
                  <p class="fs-6 text-start" v-html="get_whatsnew_detail.description">
                  </p>
                  <br />                
                </div>              
              </div>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import closeIcon from "../../common/icons/closeIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import moment from "moment";

export default {
  data() {
    return {
      plyr_options: { 
        'title': this.get_whatsnew_detail.title,
        'controls': ['play-large', 'play', 'progress', 'current-time', 'mute', 'volume', 'captions','airplay', 'fullscreen']      
      }
    };
  },
  props: ["get_whatsnew_detail"],
  emits: ["close-modal"],
  components: { closeIcon },
  methods: {
    formattedPostDate(value) {
      return moment.utc(String(value)).local().format("MMMM DD, YYYY");
    }
  },
  created () {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-modal");
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>

<style>
</style>
