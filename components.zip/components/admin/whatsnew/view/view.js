import { createApp } from 'vue';
import { useVuelidate } from '@vuelidate/core';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import VuePlyr from 'vue-plyr';
import 'vue-plyr/dist/vue-plyr.css';
import whatsnewView from "./view.vue";
import app from "../../common/includes/App.vue"
const view_app = createApp({
    template: `
    <app>
    <whatsnew-view></whatsnew-view>
    </app>
    `,
    components: {
        app,
        'whatsnew-view': whatsnewView,
    }
});
view_app.use(useVuelidate);
view_app.use(VuePlyr, {
    plyr: {}
});  
view_app.component('multiselect', Multiselect);
view_app.mount("#view_app");