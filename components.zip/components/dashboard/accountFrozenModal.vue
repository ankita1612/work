<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container"  v-if="AUTH_USER.partner_reseller_id == null">
            <!-- <div class="text-center mlr-auto mb15 pt20">
              <img :src="JS_APP_URL + '/images/triangle-warning.svg'" alt="" title="" class="warning-icon-modal" />
            </div> -->
            <h2
              class="
                font-24 font_semibold blueog--text line-normal text-center mb20
              "
            >
              Account Frozen
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">Looks like your account has been frozen. Please update your billing information to continue using our product.</p>
            <div class="flex flex-wrap items-center justify-center">
                <a :href="JS_APP_URL + '/billing'" class="btn-primary-outline mx5">Go To BILLING</a>
                <a href="javascript:void(0)"  @click="logout()" class="btn-primary-outline mx5">Log Out</a>
            </div>
          </div>
          <div class="modal-container" v-else>
                <!-- <div class="text-center mlr-auto mb15 pt20">
              <img :src="JS_APP_URL + '/images/triangle-warning.svg'" alt="" title="" class="warning-icon-modal" />
            </div> -->
                <h2
                  class="
                font-24 font_semibold blueog--text line-normal text-center mb20
              "
                >
                  Account Frozen
                </h2>
                <p class="text-center font-16 gray_checkmark--text line-normal mb30">Attention! It looks like your account has been frozen. Please reach out to your contact below for further assistance.</p>
                <p class="item-center justify-center mb10"> {{ AUTH_USER.reseller.name }} </p>
                <p class="item-center justify-center mb10"> {{ AUTH_USER.reseller.contact_person }} </p>
                <p class="item-center justify-center mb10"> {{ AUTH_USER.reseller.phone_no }} </p>
                <div class="flex items-center justify-center">
                  <a href="javascript:void(0)"  @click="logout()" class="btn-primary-outline mx5">Log Out</a>
                </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";

export default {
  props: {
  },
  components:{},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      AUTH_USER: AUTH_USER
    };
  },
  methods: {
    logout() {
        axios
        .get(JS_APP_URL + "/dashboard/logout")
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            localStorage.setItem('is_logout', 'yes');
            setTimeout(() => {
              localStorage.clear();
              window.location = JS_APP_URL + "/login";
            }, 200);
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        });
    }
  },
  created() {
    // document.body.classList.add('modal-open');
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
