<template>
    <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask pdf-modal-mask">
                <div class="pdf-modal-overlay"></div>
                <div class="modal-wrapper animate__animated animate__zoomIn">
                    <div class="modal-container modal-new-changes">
                        <div class="text-center mlr-auto mb10 pt20">
                            <img
                                :src="JS_APP_URL + '/images/warning.svg'"
                                alt=""
                                title=""
                                class="warning-icon-modal"
                            />
                        </div>
                        <h2
                            class="font-24 font_semibold blueog--text line-normal text-center mb10"
                        >
                            Potential Compliance Risk: (⚠️)
                        </h2>
                        <p
                            class="text-center font-16 gray_checkmark--text line-normal mb20"
                        >
                            Your account has been flagged for shared email
                            addresses. In order to meet best practices for HIPAA compliance and to maximize the new Employee Portal experience, we recommend using unique emails for each employee.
                        </p>
                        <p
                            class="text-center font-16 gray_checkmark--text line-normal mb30"
                        >
                            Please update your employee emails accordingly, an
                            assigned practice email or personal email can be used.
                        </p>

                        <p
                            class="text-center font-16 gray_checkmark--text line-normal mb30"
                        >
                            Questions or Concerns? Reach out to Support.
                        </p>

                        <div class="flex flex-wrap items-center justify-center">
                            <button
                                type="submit"
                                class="btn-primary mlr-auto"
                                @click="gotIt()"
                            >
                                <span>GOT IT!</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </Teleport>
</template>

<script scoped>
export default {
    props: {},
    emits: ["got-it"],
    components: {},
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
        };
    },
    methods: {
        gotIt() {
            this.$emit("got-it");
        },
    },
    created() {
        // document.body.classList.add("modal-open");
    },
    destroyed() {
        // document.body.classList.remove("modal-open");
    },
};
</script>
