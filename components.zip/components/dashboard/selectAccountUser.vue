<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container">
              <button v-if="!disable_account_user_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                  <close-icon></close-icon>
              </button>
              <div class="text-center sign-in-icon mlr-auto mb10 pt10">
                <img :src="JS_APP_URL + '/images/user.svg'" alt="" title="" />
              </div>
              <h2 class="font-24 font_semibold blueog--text line-normal mb10 text-center">
                Users
              </h2>
              <div class="completecase-content mlr-auto">
                <div class="font-16 text-center gray_checkmark--text line-normal mb20">
                  Select user(s) to manage <span class="" :title="location_details.location_nickname">{{location_details.location_nickname}}</span>. As a note, the Primary Compliance Officer is a default user for all locations.
                </div>
                <div class="flex items-center flex-wrap flex-auto mb20">
                  <div class="row flex-auto justify-center -mx-10">
                    <div class="col-12 col-md-12 px10">
                          <form @submit.prevent="setAccountUserSubmit" class="fill-width">
                          <div class="form-group mb-0 mlr-auto location-dropdon"  :class="{ 'form-group--error': v$.select_account_user_id.$errors.length }">
                              <multiselect
                              v-model="v$.select_account_user_id.$model"
                              :options="account_user_list"
                              track-by="id"
                              :custom-label="customLabel"
                              placeholder=""
                              :multiple="true"
                              :searchable="true"
                              :showLabels="false"
                              :taggable="false"
                              :close-on-select="false"
                              :disabled="disable_account_user_submit_btn"
                              openDirection="bottom"
                              @select="checkForHCO"
                              @remove="checkForHCO"
                              >
                                  <template #noResult>
                                      <div class="multiselect__noResult text-center">No results found</div>
                                  </template>
                                  <template #noOptions>
                                      <div class="multiselect__noOptions text-center">No data available</div>
                                  </template>
                                  <template #selection>
                                      <div class="multiselect__tags-wrap" v-if="select_account_user_id.length > 1">
                                          <span class="multiselect__tag">
                                              <span>{{ select_account_user_id.length }} Users Selected</span>
                                          </span>
                                      </div>
                                  </template>
                              </multiselect>
                              <label class="label label-select" :class="{ 'label-float': (select_account_user_id.length > 0) }">User(s)</label>
                              <div v-if="v$.select_account_user_id.$errors.length > 0">
                                <div class="form-error-text">
                                  {{ v$.select_account_user_id.$errors[0].$message }}
                                </div>
                              </div>
                          </div>
                          <div class="text-center pt30">
                              <button
                              :disabled="disable_account_user_submit_btn || disable_submit_btn"
                              type="submit"
                              class="btn-primary mlr-auto"
                              >
                                  <span>Submit</span>
                              </button>
                          </div>
                      </form>
                    </div>
                    </div>
                </div>
              <p class="font-18 text-center gray_checkmark--text mb0">
                Don't see who you're looking for? Add a <a :href="JS_APP_URL + '/accountuser'" class="blueog--text cursor-pointer"> New User.</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, helpers } from "@vuelidate/validators";
import _ from 'lodash';
import closeIcon from '../common/icons/closeIcon.vue';
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';

export default {
  data() {
    return {
      select_account_user_id:[],
      disable_account_user_submit_btn:false,
      JS_APP_URL: JS_APP_URL,
      default_select_location_ids:[],
      disable_submit_btn: false,
      HCO_unselected_msg: 'Seems like you are trying to remove an HCO for this location(s). Please assign a new HCO to change/remove the current HCO.',
    };
  },
  props: {
    location_details: {
      required
    },
    account_user_list: {},
  },
  emits: ["close-model", "update-accountuser"],
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    return {
      select_account_user_id: {
        required: helpers.withMessage('Please select user(s)', required),
        isHcoExist:  helpers.withMessage(this.HCO_unselected_msg, value => {          
          if(this.location_details.hipaa_compliance_officer!=undefined  )
          {
            var selected_hco = this.select_account_user_id.find(
                (object) => object.id === parseInt(this.location_details.hipaa_compliance_officer.hco.id)
            );
            if(selected_hco == undefined && this.location_details.hipaa_compliance_officer.hco_type.split("\\")[2] == "AccountUser"){         
              return false;
            }
            else{         
              return true;
            }
          }
          return true;
          })
      }
    }
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener('keyup', (evt) => {
      if (evt.keyCode === 27 && !this.disable_account_user_submit_btn) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  },
  mounted() {
    _.forEach(this.location_details.account_location_access, (account_user) => {
        this.default_select_location_ids.push({
            id: account_user.account_user.id,
            first_name: account_user.account_user.first_name,
            last_name: account_user.account_user.last_name,
        });
    });
    this.select_account_user_id = this.default_select_location_ids;
  },
  components: {
    closeIcon,
    clearDropdownIcon
  },
  methods: {
    setAccountUserSubmit() {
     this.v$.$touch();
      if (!this.v$.$invalid) {
            this.disable_account_user_submit_btn =true;
            let account_user_id_removed = _.difference(_.map(this.default_select_location_ids, 'id'), _.map(this.select_account_user_id, 'id'));
            let account_user_id = _.difference(_.map(this.select_account_user_id, 'id') ,_.map(this.default_select_location_ids, 'id'));
            NProgress.start();
            axios
            .post(JS_APP_URL + "/dashboard/set-account-user",{
                location_id:this.location_details.id,
                account_user_id:account_user_id,
                account_user_id_removed:account_user_id_removed
            })
            .then((response) => {
            if (response["data"]["status"] == "Error") {
                if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
            } else {
                toastr.success(response["data"]["message"], "Success");                
                setTimeout(() => {
                    this.$emit("update-accountuser", Object.assign({}, response['data']['data']));
                    this.$emit("close-model", false);
                }, 100);
            }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
            NProgress.done();
            this.disable_account_user_submit_btn =false;
            });
      }
    },
     closeModal() {
      this.$emit("close-model", false);
    },
     resetSelectedAccountUser(){
        this.select_account_user_id = [];
    },
    customLabel(option) {
      return `${option.first_name} ${option.last_name}`
    },
    checkForHCO(option, id){      
      if(this.location_details.hipaa_compliance_officer!=undefined )
      {
        var selected_hco = this.select_account_user_id.find(
            (object) => object.id === parseInt(this.location_details.hipaa_compliance_officer.hco.id)
        );        
        if(selected_hco==undefined && this.location_details.hipaa_compliance_officer.hco_type.split("\\")[2] == "AccountUser"){                   
          if(option.id == this.location_details.hipaa_compliance_officer.hco.id){
            toastr.error(this.HCO_unselected_msg, "Error");
          }          
          this.disable_submit_btn=true;          
        }
        else{              
          this.disable_submit_btn=false;
        }
      }           
    }
  },
};
</script>
