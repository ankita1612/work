<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container">
              <button v-if="!disable_hco_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                  <close-icon></close-icon>
              </button>
              <div class="text-center sign-in-icon mlr-auto mb10 pt10">
                <img :src="JS_APP_URL + '/images/hco-badge.svg'" class="hco-badge-img" alt="" title="" />
              </div>
              <h2 class="font-24 font_semibold blueog--text line-normal mb10 text-center">
                HIPAA Compliance Officer
              </h2>
              <div class="completecase-content mlr-auto">
                <div class="font-16 text-center gray_checkmark--text line-normal mb20">
                  Please select an HCO for <span :title="location_details.location_nickname">{{location_details.location_nickname}}</span>.
                </div>
                <div class="flex items-center flex-wrap flex-auto mb20">
                  <div class="row flex-auto justify-center -mx-10">
                    <div class="col-12 col-md-12 px10">
                        <form @submit.prevent="setHCOSubmit" class="fill-width">
                          <div class="form-group mb-0 mlr-auto location-dropdon"  :class="{ 'form-group--error': v$.select_hco_id.$errors.length }">
                          <multiselect
                          class="font-style-normal"
                          v-model="v$.select_hco_id.$model"
                          :options="user_list"
                          track-by="unique_id"
                          :custom-label="customLabel"
                          placeholder=""
                          :searchable="true"
                          :showLabels="false"
                          :taggable="false"
                          :disabled="disable_hco_submit_btn"
                          openDirection="bottom"
                          >
                          <template #noResult>
                              <div class="multiselect__noResult text-center">No results found</div>
                          </template>
                          <template #noOptions>
                              <div class="multiselect__noOptions text-center">No data available</div>
                          </template>
                          </multiselect>
                          <label class="label label-select" :class="{ 'label-float': (select_hco_id && Object.keys(select_hco_id).length > 0 && Object.getPrototypeOf(select_hco_id) === Object.prototype) }">HCO</label>
                          <div v-if="v$.select_hco_id.$errors.length > 0">
                            <div class="form-error-text">
                              {{ v$.select_hco_id.$errors[0].$message }}
                            </div>
                          </div>
                      </div>
                      <div class="text-center pt30">
                          <button
                          :disabled="disable_hco_submit_btn"
                          type="submit"
                          class="btn-primary mlr-auto"
                          >
                              <span>Submit</span>
                          </button>
                      </div>
                      </form>
                    </div>
                  </div>
                </div>
                <p class="font-18 text-center gray_checkmark--text mb0">
                Don't see who you're looking for? Add a <a :href="JS_APP_URL + '/accountuser'" class="blueog--text cursor-pointer"> New User.</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, helpers } from "@vuelidate/validators";
import _ from 'lodash';
import closeIcon from '../common/icons/closeIcon.vue';

export default {
  data() {
    return {
      select_hco_id:{},
      disable_hco_submit_btn:false,
      JS_APP_URL: JS_APP_URL,
      APP_ENV: APP_ENV,
      AUTH_USER: AUTH_USER,
    };
  },
  props: {
    location_details: {
      required
    },
    user_list:{},
    location_limit_count: {
      type: Number,
      default: () => 0
    }
  },
  emits: ["close-model", 'update-hco'],
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      select_hco_id: {
        required: helpers.withMessage("Please select HCO", required),
      }
    }
    return validationArray;
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener('keyup', (evt) => {
      if (evt.keyCode === 27 && !this.disable_hco_submit_btn) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  },
  mounted() {
    if(this.location_details.hipaa_compliance_officer != null){
      this.select_hco_id = {
        'unique_id' : this.location_details.hipaa_compliance_officer.hco.id + '_' + ((this.location_details.hipaa_compliance_officer.hco_type.split("\\")[2] == "AccountUser")?'account_user':'user'),
        'hco_type' : (this.location_details.hipaa_compliance_officer.hco_type.split("\\")[2] == "AccountUser")?'account_user':'user',
        'id' : this.location_details.hipaa_compliance_officer.hco.id,
        'first_name' : this.location_details.hipaa_compliance_officer.hco.first_name,
        'last_name' : this.location_details.hipaa_compliance_officer.hco.last_name
      };
    }
  },
  components: {
    closeIcon
  },
  methods: {
    setHCOSubmit() {
     this.v$.$touch();
      if (!this.v$.$invalid) {
        NProgress.start();
        this.disable_hco_submit_btn = true;
        axios
        .post(JS_APP_URL + "/dashboard/set-hco",{
          location_id:this.location_details.id,
          user_id:this.select_hco_id.id,
          user_type:this.select_hco_id.hco_type,
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
              toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
              toastr.error(response["data"]["message"], "Error");
            }
          } else {
            toastr.success(response["data"]["message"], "Success");
            setTimeout(() => {
              if(APP_ENV == 'production') {
                var metadata = {
                  first_time_hco_added: response['data']['data']['first_time_hco_added'],
                  location_id: this.location_details.id,
                  location_nickname: this.location_details.location_nickname,
                  user_locations_number: this.location_limit_count
                };
                if(AUTH_USER.is_sra_user == 0) {
                  Intercom('trackEvent', 'hipaa-compliance-officer-status', metadata);
                }
              }
              this.$emit("close-model", false, this.location_details);
              this.$emit("update-hco", response['data']['data']['hco'],response['data']['data']['notification'],response['data']['data']['open_notifications_count'], response['data']['data']['training_counts']);
            }, 100);
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
          this.disable_hco_submit_btn = false;
        });
      }
    },
    closeModal() {
      this.$emit("close-model", false);
    },
    customLabel(option) {
      if(option.first_name && option.last_name){
        return `${option.first_name} ${option.last_name}`
      }else{
        return ``
      }
    },
  },
};
</script>
