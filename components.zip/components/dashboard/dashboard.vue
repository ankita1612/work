<template>
    <div>
        <header-after-login></header-after-login>
        <div class="container pt30 pb40">
            <location-input
                v-if="show_location_input"
                :location_limit_count="location_limit_count"
                :sample_import_file_link="sample_import_file_link"
            />
            <dashboard-single-location-view v-if="show_single_location_view && company_info_update_modal == false" :location_limit_count="location_limit_count.location_count"/>
            <full-page-loader
                v-if="is_full_page_loader_shown"
            ></full-page-loader>
            <account-frozen-modal
                v-if="is_account_frozen_modal_shown"
            ></account-frozen-modal>
            <account-renewal-modal
                v-if="is_account_renewal_modal_shown"
                @close-model="updateAutoRenewalPopupFlag"
                @remid-me-later="updateAutoRenewalPopupFlag"
                @sign-me-up="updateAutoRenewalPopupFlag"
            ></account-renewal-modal>
            <new-changes-modal
                v-if="is_new_changes_modal_shown"
                @got-it="updateNewChangesPopupTrackFlag"
            ></new-changes-modal>
            <shared-email-modal
                v-if="is_shared_email_popup_shown"
                @got-it="updateSharedEmailPopupTracks"
            ></shared-email-modal>
            <ba-promotion-modal 
                @close-model="promoModalToggle"
                v-if="show_ba_promo_modal"
            ></ba-promotion-modal>
            <covered-entity-update-modal
                @close-modal = "hideCompanyInfoUpdateModal"
                v-if="company_info_update_modal"
            ></covered-entity-update-modal>
            <badge-modal
                @close-modal="hideBadgeReportModal"
                :user_badge_data = "user_badge_data"                
                v-if = "show_badge_modal"      
            ></badge-modal>
        </div>         
    </div>
</template>

<script>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import locationInput from "./locationInput.vue";
import accountFrozenModal from "./accountFrozenModal.vue";
import dashboardSingleLocationView from "./dashboardSingleLocationView.vue";
import fullPageLoader from "../common/fullPageLoader.vue";
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import accountRenewalModal from "./accountRenewalModal.vue";
import newChangesModal from "./newChangesModal.vue";
import sharedEmailModal from "./sharedEmailsModal.vue";
import baPromotionModal from "./baPromotionModal.vue";
import coveredEntityUpdateModal from "./coveredEntityUpdateModal.vue";
import badgeModal from "./badgeModal.vue";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            JS_CALENDLY_URL: JS_CALENDLY_URL,
            show_location_input: undefined,
            show_single_location_view: undefined,
            location_limit_count: null,
            sample_import_file_link: null,
            is_full_page_loader_shown: false,
            is_account_frozen_modal_shown: false,
            is_account_renewal_modal_shown: false,
            is_new_changes_modal_shown: false,
            is_shared_email_popup_shown: false,
            AUTH_USER: AUTH_USER,
            show_ba_promo_modal : false,
            company_info_update_modal: false,   
            show_badge_modal: false,    
            user_badge_data: {},
            SUCCESS_MESSAGE: SUCCESS_MESSAGE        
        };
    },

    components: {
        locationInput,
        dashboardSingleLocationView,
        fullPageLoader,
        headerAfterLogin,
        accountFrozenModal,
        accountRenewalModal,
        newChangesModal,
        sharedEmailModal,
        baPromotionModal,
        coveredEntityUpdateModal,
        badgeModal
    },

    mounted() {
        if(this.SUCCESS_MESSAGE != null){
            toastr.success(this.SUCCESS_MESSAGE, "Success");
            if (window.location.search.includes("success")) {
                window.history.replaceState({}, document.title, window.location.pathname);
            }
        }
        if (["HCO","PCO"].indexOf(AUTH_USER['user_type']) > -1 && this.AUTH_USER['is_sra_user'] == 0){
            this.checkBaPromoPopup()
        }
        if (this.AUTH_USER["account_status"] == "Frozen") {
            this.is_account_frozen_modal_shown = true;
        }
        this.locationLimitCountCheck();    
        let show_popup = localStorage.getItem("shared_email_popup") == "false" ? false : true
        if(show_popup) {
            this.checkSharedEmailPopup();
        }           
        let show_company_info_update_modal = localStorage.getItem("show_company_info_update_modal") == "false" ? false : true
        if(show_company_info_update_modal && this.AUTH_USER["account_status"] != "Frozen") {
            this.showCompanyInfoUpdateModal();
        }

        let show_badge_modal = localStorage.getItem("show_badge_modal") == "false" ? false : true
        if (show_badge_modal && this.AUTH_USER["account_status"] != "Frozen" && ["PCO"].indexOf(AUTH_USER['user_type']) > -1) {        
            this.checkBadgeReportModal();
        }     
    },

    methods: {
        promoModalToggle(is_interested) {
            NProgress.start();
            // console.log(is_interested)
            axios
                .post(JS_APP_URL + "/dashboard/update-ba-promotion-responses",{ 
                    is_interested : is_interested
                })
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.show_ba_promo_modal = false;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                });
        },
        checkBaPromoPopup() {
            axios
                .get(JS_APP_URL + "/dashboard/check-ba-promotion-tracks")
                .then((response) => {
                    if (response.data.status == "Success" && this.AUTH_USER.is_admin_panel_login == 'false' ) {
                        this.show_ba_promo_modal = true
                    }
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                
        },        
        checkSharedEmailPopup() {
            NProgress.start();
            axios
                .get(JS_APP_URL + "/dashboard/check-shared-email-popup-tracks")
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.is_shared_email_popup_shown = true;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    localStorage.setItem("shared_email_popup", false);
                    NProgress.done();
                });
        },
        updateSharedEmailPopupTracks(){
            NProgress.start();
            axios
                .post(JS_APP_URL + "/dashboard/update-shared-email-popup-tracks")
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.is_shared_email_popup_shown = false;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                });
        },
        checkNewChangesPopup() {
            NProgress.start();
            axios
                .get(JS_APP_URL + "/dashboard/check-new-changes-popup-tracks")
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.is_new_changes_modal_shown = true;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                    // DISABLING AUTO RENEWAL POPUP  - KEEPING CODE/LOGIC FOR FUTURE USE
                    // this.checkAutoRenewalPopop();
                });
        },
        updateNewChangesPopupTrackFlag(){
            NProgress.start();
            axios
                .get(JS_APP_URL + "/dashboard/update-new-changes-popup-tracks-flag")
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.is_new_changes_modal_shown = false;
                            window.open(
                                JS_APP_URL+"/whatsnew/ODc=",
                                '_self'
                            );
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                });
        },
        updateAutoRenewalPopupFlag(close_type) {
            NProgress.start();
            axios
                .post(JS_APP_URL + "/dashboard/update-auto-renewal-popup-flag", {
                    close_type: close_type,
                })
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.is_account_renewal_modal_shown = false;
                        if (close_type == "sign_me_up") {
                            window.open(
                                JS_CALENDLY_URL+"/heatherabyde/annual-hipaa-evaluation",
                                "_blank"
                            );
                        }
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();
                });
        },
        checkAutoRenewalPopop() {
            NProgress.start();
            axios
                .get(JS_APP_URL + "/dashboard/auto-renewal-popup-check")
                .then((response) => {
                    if (response.data.status == "Success") {
                        this.is_account_renewal_modal_shown = true;
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    NProgress.done();                    
                });
        },
        locationLimitCountCheck() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/dashboard/location-limit-count")
                .then((response) => {
                    if (response["data"]["status"] == "Error") {
                        if (response["data"]["data"].length > 0) {
                            toastr.error(
                                response["data"]["data"].join("</br>"),
                                "Error"
                            );
                        } else {
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        this.location_limit_count = response.data.data;
                        if (
                            this.location_limit_count.location_limit >
                            this.location_limit_count.location_count
                        ) {
                            this.sample_import_file_link =
                                this.location_limit_count.sample_import_doc;
                            this.show_location_input = true;
                        } else {
                            this.show_single_location_view = true;
                        }
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                    this.is_full_page_loader_shown = false;                     
                    this.checkNewChangesPopup(); 
                });
        },
        showCompanyInfoUpdateModal() {
            axios
                .get(JS_APP_URL + "/dashboard/show-company-info-modal")
                .then((response) => {
                    if (response.data.status == "Success" && this.AUTH_USER.is_admin_panel_login == 'false' ) {
                        this.company_info_update_modal = true
                    }
                }).then(() => {
                    localStorage.setItem("show_company_info_update_modal", false);
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                
        },
        hideCompanyInfoUpdateModal(){
            this.company_info_update_modal = false
        },
        checkBadgeReportModal() {            
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/dashboard/show-badge-modal")
                .then((response) => {
                    let data = response.data.data;                    
                    if (response.data.status == "Success" && this.AUTH_USER.is_admin_panel_login == 'false' ) {
                        this.show_badge_modal = true       
                        this.user_badge_data = data;                 
                    }

                }).then(() => {
                    localStorage.setItem("show_badge_modal", false);
                    this.is_full_page_loader_shown = false;                     
                })
                .catch((error) => {
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })                
        },
        hideBadgeReportModal() {            
            this.show_badge_modal = false
        },
    },
};
</script>
