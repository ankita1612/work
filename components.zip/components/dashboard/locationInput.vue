<template>
  <div>

    <div class="text-center relative">
      <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="import-btn-tooltip" v-if="locations.length > 1">
          <input :disabled="is_import_btn_disabled" ref="import_locations_file_upload" type="file" accept=".xls, .xlsx" hidden @change="importLocation">
          <button :disabled="is_import_btn_disabled" @click="onPickImportFile" type="button" class="import-btn"><span><import-icon></import-icon></span><span>Import</span></button>
        <template #popper>
          <i class="text-center d-block fill-width">If preferred, you may import multiple locations via excel file upload.<br> Click here to <b><a class="downloadsamplelink" :href="sample_import_file_link" target="_blank">download the Template File</a></b>. Once completed, click the IMPORT button to upload your locations.</i>
        </template>
      </VTooltip>
    <h1
      v-if="AUTH_USER.is_sra_user == 0" v-text="location_limit_count.location_limit > 1?'HIPAA Compliance Programs':'HIPAA Compliance Program'"
      class="
        location-dashbaord-title
        text-center
        font-24 font_semibold
        blueog--text
        line-normal
        mb40
      ">
    </h1>
     <h1 class="
          location-dashbaord-title
          text-center
          font-24 font_semibold
          blueog--text
          line-normal
          mb40
        " v-else>HIPAA Security Risk Analysis
      </h1>
    </div>

    <div class="row justify-center">
      <div class="col-12 col-md-12 col-lg-6 col-xl-6" v-for="(location, index) in locations" :key="index">
        <div class="form-group" :class="{ 'form-group--error': v$.locations.$error }">
          <input class="form-input location-input-box" type="text" v-model="location.location_nickname" :class="{ 'form-error': v$.locations.$error && v$.locations.$each.$response.$errors[index].location_nickname.length > 0 }"/>
          <label class="label location-input-label" :class="{ 'label-float': location.location_nickname }">Location {{
            parseInt(location_limit_count.location_count) + parseInt(index) + 1}} 
            Nickname
          </label>
          <div v-if="v$.locations.$error && v$.locations.$each.$response.$errors[index].location_nickname.length > 0">
            <div class="form-error-text">{{ v$.locations.$each.$response.$errors[index].location_nickname[0].$message}}</div>
          </div>
        </div>
      </div>
    </div>
    <div class="text-center pt10">
      <button :disabled="disable_submit_btn" type="submit" class="btn-primary mlr-auto" @click="addLocations">
        <span>Submit</span>
      </button>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<script>
import axios from "axios";
import fullPageLoader from "../common/fullPageLoader.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, maxLength, helpers } from "@vuelidate/validators";
import importIcon from '../common/icons/importIcon.vue';
import {checkSpecialChars, checkSpecialCharsErrorMessage}  from "../common/customValidation";

export default {
  components: {importIcon, fullPageLoader},
  props: {
    location_limit_count: Object,
    sample_import_file_link:{
      type: String,
      default: () => ""
    },
  },

  data() {
    return {
      AUTH_USER: AUTH_USER,
      locations: [],
      disable_submit_btn: false,
      is_import_btn_disabled: false,
      is_full_page_loader_shown: false,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage
    };
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    return {
      locations: {
        $each: helpers.forEach({
          location_nickname: {
            required: helpers.withMessage("Please enter a location name", required),
            checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
            maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
            isUnique: helpers.withMessage("Location names must be unique. Please try again", (value) => {
              if (value == "") return true;
              let check = this.locations.filter(
                (loc) => {
                  return loc.location_nickname.toLowerCase().replace(/\s+/g, ' ').trim() === value.toLowerCase().replace(/\s+/g, ' ').trim()
                }
              );
              if (check.length > 1)
                return false;
              return true
            }),
          },
        }),
      },
    }
  },

  beforeMount() {
    let input_field_count = parseInt(this.location_limit_count.location_limit) - this.location_limit_count.location_count;
    for (
      let i = 0;
      i < input_field_count;
      i++
    ) {
      this.locations.push({ location_nickname: "" });
    }
  },

  methods: {
    async addLocations() {
      this.v$.$touch();
      const is_valid = await this.v$.$validate();
      if (is_valid) {
        this.is_full_page_loader_shown = true;
        this.disable_submit_btn = true;
        axios
          .post(JS_APP_URL + "/dashboard/add-locations", {
            locations: this.locations,
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              let data = response.data.data;
              setTimeout(() => {
                window.location = JS_APP_URL + "/dashboard";
              }, 1000);
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            this.is_full_page_loader_shown = false;
            this.disable_submit_btn = false;
          });
      }
    },
    onPickImportFile(){
      this.$refs.import_locations_file_upload.click();
    },
    importLocation(e){
      this.is_full_page_loader_shown = true;
      this.is_import_btn_disabled = true;
      const data = new FormData();
      data.append('import_file',e.target.files[0]);
      axios
        .post(JS_APP_URL + "/dashboard/import-location", data)
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            this.$refs.import_locations_file_upload.value = null;
            if(response["data"]['data'].length > 0){
              toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
              toastr.error(response["data"]["message"], "Error");
            }
          } else {
            toastr.success(response["data"]["message"], "Success");
            setTimeout(() => {
              location.reload();
            }, 800);
          }
        })
        .catch((error) => {
          this.$refs.import_locations_file_upload.value = null;
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
          this.is_import_btn_disabled = false;
        });
    }
  },
};
</script>
