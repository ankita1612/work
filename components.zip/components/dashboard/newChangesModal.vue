<template>
    <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask pdf-modal-mask">
                <div class="pdf-modal-overlay"></div>
                <div class="modal-wrapper animate__animated animate__zoomIn">
                    <div class="modal-container modal-new-changes">
                        <!-- <div class="text-center mlr-auto mb10 pt20">
                            <img
                                :src="JS_APP_URL + '/images/newchanges-popup-icon.png'"
                                alt=""
                                title=""
                                class="warning-icon-modal"
                            />
                        </div> -->
                        <h2
                            class="font-24 font_semibold blueog--text line-normal text-center mb10"
                        >
                            Abyde Software Updates!
                        </h2>
                        <p
                            class="text-center font-18 gray_checkmark--text line-normal mb10 font_semibold"
                        >
                            Hey there, Abyder! We've spiced things up a bit:
                        </p>
                        <ul class="list-item text-left">
                            <li><b>Dashboard:</b> More concise and HIPAA stats are now spotlighted.</li>
                            <li><b>Employee Management:</b> Easier deletion and dual location assignments for enterprise users.</li>
                            <li><b>Docs & Notifications:</b> Meet the 'Abyde Drive' and our new notification dot!</li>
                            <li><b>Access & Assignments:</b> Revamped for simpler user experience.</li>
                            <li><b>Scorecard:</b> Enhanced features and easy-to-access recommendations.</li>
                            <li><b>For Employees:</b> They can now peek into Policies & Procedures.</li>
                            <li><b>Breach Logs:</b> Editable and now auto-archives yearly.</li>
                        </ul>
                        <vue-plyr :options="plyr_options">
                        <video
                            controls
                            :data-poster="JS_APP_URL + '/images/newchanges-popup-poster.png'"
                        >
                            <source
                            :src="JS_APP_URL + '/videos/New_Changes.mp4'"
                            type="video/mp4"
                            />
                        </video>
                        </vue-plyr>
                        <!-- <p
                            class="text-center font-16 gray_checkmark--text line-normal mb10 font_italic"
                        >
                            Want more information? Click on below button to take a look at our most-recent What's New post.
                        </p> -->
                        <div class="flex flex-wrap items-center justify-center">
                            <button type="submit" class="btn-primary mlr-auto"  @click="gotIt()">
                                <span>GOT IT!</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </Teleport>
</template>

<script scoped>
export default {
    props: {},
    emits: ["got-it"],
    components: {
    },
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            plyr_options: { 
                'title': 'Abyde Software Updates!',
                'controls': ['play-large', 'play', 'progress', 'current-time', 'mute', 'volume', 'captions','airplay', 'fullscreen']      
            }
        };
    },
    methods: {
        gotIt() {
            this.$emit("got-it");
        }
    },
    created() {
        // document.body.classList.add("modal-open");
    },
    destroyed() {
        // document.body.classList.remove("modal-open");
    },
};
</script>
