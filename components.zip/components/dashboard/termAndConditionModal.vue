<template>
  <Teleport to="body">
    <transition name="modal">
      <div>
        <div class="modal-mask modal-scrollable access-right-modal">
          <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
              <button v-on:click="closeModal" class="cursor-pointer modal-close">
                  <close-icon></close-icon>
              </button>
              <div class="text-center mlr-auto mb20">
              <img :src="JS_APP_URL + '/images/abyde_a.svg'" alt="" title="" class="warning-icon-modal" />
              </div>
              <h2 class="font-24 font_semibold blueog--text line-normal mb10 text-center">
                Terms & Conditions
              </h2>
              <div class="completecase-content mlr-auto">
                  <div class="font-16 text-center gray_checkmark--text line-normal mb10">
                  By selecting to yes, you are authorizing Abyde to send an assessment tool to your Business Associates (BAs). This initiative is designed to assist BAs in reviewing and enhancing their practices in protecting protected health information (PHI). It is important to understand that this tool serves to identify areas of strength and potential improvement in PHI handling and is not intended as an audit, nor does it certify compliance with regulatory standards. Abyde’s role in this process is to facilitate the assessment on your behalf, aiming to promote best practices in PHI security. We recommend the use of the Abyde Business Associate platform for effective protection of PHI.
                  </div>
                  <div class="font-16 text-center gray_checkmark--text line-normal mb10">
                  However, please be aware that while this assessment is geared towards enhancing PHI protection, it does not eliminate the risk of data breaches entirely. The liability of a medical provider or entity in the event of a breach may depend on various factors beyond the scope of this assessment. Furthermore, we cannot guarantee that we will be able to contact all of your Business Associates. The ability to reach each BA may be affected by various factors.
                  </div>
                  <div class="font-16 text-center gray_checkmark--text line-normal mb10">
                  By proceeding with this action, you consent to Abyde sending this assessment to your BAs and acknowledge your understanding and agreement with the terms outlined in this disclaimer.
                  </div>
              </div>
                
            </div>
          </div>
        </div>
        <div class="modal-backdrop"></div> 
      </div> 
    </transition>
  </Teleport>
</template>

<script scoped>
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from 'lodash';
import closeIcon from '../common/icons/closeIcon.vue';

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      APP_ENV: APP_ENV
    };
  },
  props: {},
  emits: ["close-model"],
  mounted() {
    // Close modal with 'esc' key
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", false);
      }
    });
  },
  components: {
    closeIcon
  },
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
  },
};
</script>
