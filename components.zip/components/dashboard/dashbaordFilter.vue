<template>
  <div class="location-filter-wrapper">
    <div class="row flex-auto -mx-10 items-center justify-center">
      <div class="col-12 col-md-12 col-lg-12 col-filter-90 px10 pl0">
        <div class="row flex-auto -mx-10 justify-center flex">
          <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10">
            <div class="flex items-center">
            <div class="form-group flex-auto">
              <multiselect
                v-model="sort_by"
                :options="sort_by_options"
                label="name"
                placeholder=""
                @update:model-value="getLocationByFilter"
                :searchable="false"
                :showLabels="false"
                :taggable="false"
              >
                <template #noResult>
                  <div class="multiselect__noResult text-center">
                    No results found
                  </div>
                </template>
                <template #noOptions>
                  <div class="multiselect__noOptions text-center">
                    No data available
                  </div>
                </template>
              </multiselect>
              <label
                class="label label-select"
                :class="{
                  'label-float': (sort_by != null),
                }"
                >Sort by</label
              >
            </div>
            <img v-on:click="toggleSortDir" v-if="sort_by != null && sort_by_dir == 'ASC'" :src="JS_APP_URL +'/images/sort-up.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" />      
            <img v-on:click="toggleSortDir" v-if="sort_by != null && sort_by_dir == 'DESC'" :src="JS_APP_URL +'/images/sort-down.svg'" alt="" title="" class="cursor-pointer sort-arrow ml5" /> 
            </div>
          </div>
          
          <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10" v-if="AUTH_USER.user_type != 'USER'">
            <div class="form-group">
              <multiselect
                v-model="filter_by_selected_hco"
                :options="all_hco_list"
                label="first_name"
                placeholder=""
                :multiple="false"
                @update:model-value="getLocationByFilter"
                :searchable="true"
                :showLabels="false"
                :taggable="false"
                :custom-label="customLabel"
              >
                <template #noResult>
                  <div class="multiselect__noResult text-center">
                    No results found
                  </div>
                </template>
                <template #noOptions>
                  <div class="multiselect__noOptions text-center">
                    No data available
                  </div>
                </template>
              </multiselect>
              <label
                class="label label-select"
                :class="{
                  'label-float': (filter_by_selected_hco != null),
                }"
                >Filter by HCO</label
              >
            </div>
          </div>
          <div class="col-12 col-md-4 col-lg-4 col-xl-3 px10">
            <div class="form-group">
              <input
                class="form-input form-input-search"
                v-model.trim="search"
                id="search"
                type="text"
                :readonly="busy"
                @input="getLocationByFilter"
              />
              <label class="label" :class="{ 'label-float': search }">Search</label>
              <div class="search-btn-input">
                <img :src="JS_APP_URL + '/images/search.svg'" alt="" title="" />
              </div>
            </div>
          </div>
          <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from "lodash";
import fullPageLoader from "../common/fullPageLoader.vue";
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';

export default {
    props: {
        locations_nick_name: {
            type: Array
        },
        all_hco_list: {
            type: Array
        },
        busy: {
            type: Boolean
        }
    },
  emits: ["get-locations"],

  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      search: "",
      sort_by: null,
      sort_by_dir: "ASC",
      sort_by_options: [
        {"id" : "location_name", "name" : "Location Name"},
        {"id" : "open_notifications", "name" : "Open Notifications"},
        {"id" : "risk_levels", "name" : "Risk Levels"}
      ],
      filter_by_selected_hco: null,
      is_full_page_loader_shown: false,
      timer: "",
      AUTH_USER: AUTH_USER
    };
  },
  mounted() {
  },
  components: {
    fullPageLoader,
    clearDropdownIcon
  },
  watch:{
    all_hco_list(){
      if(this.filter_by_selected_hco){
        setTimeout(() => {
          var is_avail = _.find(this.all_hco_list, (each_hco) => { 
            return each_hco.id == this.filter_by_selected_hco.id && each_hco.type == this.filter_by_selected_hco.type
          });
          if(_.isUndefined(is_avail)){
            this.filter_by_selected_hco = null;
            this.getLocationByFilter();
          }
        }, 200);
      }
    }
  },
  methods: {
    toggleSortDir(){
      this.sort_by_dir = (this.sort_by_dir == 'ASC')?'DESC':'ASC';
      this.getLocationByFilter();
    },
    getLocationByFilter() {
      let query_param = "";
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      this.timer = setTimeout(() => {
        if (this.search) {
          query_param += "&q=" + this.search;
        }

        if (this.filter_by_selected_hco) {
          query_param +=
            "&user_id=" +
            this.filter_by_selected_hco.id +
            "&user_type=" +
            this.filter_by_selected_hco.type;
        }

        if (this.sort_by && this.sort_by_dir) {
          query_param += "&sort_by=" + this.sort_by.id;
          query_param += "&sort_by_dir=" + this.sort_by_dir;
        }

        this.$emit("get-locations", query_param);
      }, 500);
    },
    customLabel(option) {
      if (option.first_name && option.last_name) {
        return `${option.first_name} ${option.last_name}`;
      } else {
        return ``;
      }
    },
  },
};
</script>
