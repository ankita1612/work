<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container">
            <button v-if="!disable_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                  <close-icon></close-icon>
              </button>
            <div class="text-center sign-in-icon mlr-auto mb10 pt10">
              <img :src="JS_APP_URL + '/images/folder-big.svg'" alt="" title="" />
            </div>
            <h2
              class="font-24 font_semibold blueog--text line-normal mb10 text-center"
            >
              Update Company Information
            </h2>
            <div class="completecase-content mlr-auto">
              <div
                class="font-16 text-center gray_checkmark--text line-normal mb20"
              >
                Use the dropdown to select the type of Covered Entity that best
                describes your organization. This will be stored within the
                <i>Company Information Module</i> and help provide content specific to
                your field.
              </div>
              <div class="flex items-center flex-wrap flex-auto mb20">
                <div class="row flex-auto justify-center -mx-10">
                  <div class="col-12 col-md-12 px10">
                    <div
                      class="form-group"
                      :class="{
                        'form-group--error': v$.selected_ce_type.$errors.length,
                      }"
                    >
                      <multiselect
                        class="font-style-normal"
                        v-model.trim="selected_ce_type"
                        placeholder=""
                        :options="all_ce_type_list"
                        track-by="id"
                        label="name"
                        position="bottom"
                        :showLabels="false"
                        :taggable="false"
                        :class="{
                          'form-error': v$.selected_ce_type.$errors.length,
                        }"
                        :allowEmpty="true"
                      >
                        <template #noResult>
                          <div class="multiselect__noResult text-center">
                            No results found
                          </div>
                        </template>
                      </multiselect>
                      <label
                        class="label label-select"
                        :class="{
                          'label-float': v$.selected_ce_type.$model != null,
                        }"
                        >Type of Covered Entity</label
                      >
                      <div v-if="v$.selected_ce_type.$errors.length > 0">
                        <div class="form-error-text">
                          {{ v$.selected_ce_type.$errors[0].$message }}
                        </div>
                      </div>
                    </div>
                    <div
                      v-if="
                        selected_ce_type != null &&
                        selected_ce_type.name == 'Other'
                      "
                      class="form-group"
                      :class="{
                        'form-group--error': v$.other.$errors.length,
                      }"
                    >
                      <input
                        class="form-input form-input-search"
                        :class="{ 'form-error': v$.other.$errors.length }"
                        type="text"
                        id="other"
                        name="other"
                        v-model.trim="v$.other.$model"
                      />
                      <label
                        class="label"
                        :class="{ 'label-float': v$.other.$model }"
                        >Other</label
                      >
                      <div v-if="v$.other.$errors.length > 0">
                        <div class="form-error-text">
                          {{ v$.other.$errors[0].$message }}
                        </div>
                      </div>
                    </div>
                    <div class="text-center pt30">
                      <button
                        :disabled="disable_submit_btn"
                        type="submit"
                        class="btn-primary mlr-auto"
                        @click="addCoveredEntityForLocations()"
                      >
                        <span>Submit</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from "@vuelidate/core";
import { required, helpers, requiredIf, maxLength } from "@vuelidate/validators";
import {
  checkSpecialChars,
  checkSpecialCharsErrorMessage,
} from "../common/customValidation";
import NProgress from "nprogress";
import closeIcon from '../common/icons/closeIcon.vue';

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      all_ce_type_list: [],
      selected_ce_type: null,
      other: null,
      disable_submit_btn: false,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
    };
  },
  mounted() {
    this.loadCETypeList();
  },
  components: {
    closeIcon
  },
  watch: {
    selected_ce_type(newVal, oldVal) {
      this.other = null;
    },
  },
  setup: () => ({ v$: useVuelidate() }),
  emits: ["close-modal"],
  validations() {
    return {
      selected_ce_type: {
        required: helpers.withMessage(
          "Please select covered entity type",
          required
        ),
      },
      other: {
        required: helpers.withMessage(
          "Please enter other detail",
          requiredIf(() => {
            return (
              this.selected_ce_type != null &&
              this.selected_ce_type.name == "Other"
            );
          })
        ),
        maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
        checkSpecialChars: helpers.withMessage(
          checkSpecialCharsErrorMessage,
          checkSpecialChars
        ),
      },
    };
  },
  methods: {
    loadCETypeList() {
      axios
        .get(JS_APP_URL + "/company/covered-entity-types")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.all_ce_type_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },
    closeModal() {
      this.$emit("close-modal", false);
    },
    addCoveredEntityForLocations() {
      this.v$.$touch();
      const is_valid = !this.v$.$invalid;
      if (is_valid) {
        this.disable_submit_btn = true;
        NProgress.start();
        axios
          .post(JS_APP_URL + "/company/add-covered-entity-for-locations", {
            ce_type_id: this.selected_ce_type.id,
            other: this.other,
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if (response["data"]["data"].length > 0) {
                toastr.error(response["data"]["data"].join("</br>"), "Error");
              } else {
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              toastr.success(response["data"]["message"], "Success");
              setTimeout(() => {
                this.closeModal();
              }, 100);
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          }).then(() => {
          NProgress.done();
          this.disable_submit_btn = false;
        });;
      }
    },
  },
};
</script>
