<template>
    <Teleport to="body">
        <transition name="modal">
            <div class="modal-mask">
                <div class="modal-wrapper animate__animated animate__zoomIn">
                    <div class="modal-container">
                        <button
                            @click="closeModal"
                            class="cursor-pointer modal-close"
                        >
                            <close-icon></close-icon>
                        </button>
                        <div class="text-center mlr-auto mb15 pt20">
                            <img
                                :src="JS_APP_URL + '/images/audit_icon.png'"
                                alt=""
                                title=""
                                class="warning-icon-modal"
                            />
                        </div>
                        <h2
                            class="font-24 font_semibold blueog--text line-normal text-center mb20"
                        >
                            Time for your Annual HIPAA Evaluation!
                        </h2>
                        <p
                            class="text-center font-16 gray_checkmark--text line-normal mb30"
                        >
                            It's been a whole year of stress-free HIPAA compliance,
                            and it's time to schedule your annual HIPAA evaluation!
                        </p>
                        <p
                            class="text-center font-16 gray_checkmark--text line-normal mb30"
                        >
                            This optional evaluation includes a one-on-one review of
                            your HIPAA program, action items to correct any areas of
                            concern, and insights into current industry trends and
                            updates.
                        </p>
                        <p
                            class="text-center font-16 gray_checkmark--text line-normtygal mb30"
                        >
                            Schedule your brief 20-30 minute review now!
                        </p>
                        <div class="flex flex-wrap items-center justify-center">
                            <button type="submit" class="btn-primary mlr-auto"  @click="signMeUp()">
                                <span>SIGN ME UP!</span>
                            </button>
                        </div>
                        <div class="flex flex-wrap items-center justify-center">
                            <a href="javascript:void(0)" @click="remindMeLater()" class="blueog--text mt10 cursor-pointer text-decoration-underline">Remind me later!</a>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </Teleport>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";

export default {
    props: {},
    emits: ["close-model", "sign-me-up", "remid-me-later"],
    components: {
        closeIcon,
    },
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
        };
    },
    methods: {
        closeModal() {
            this.$emit("close-model", "remind_me_later");
        },
        signMeUp() {
            this.$emit("sign-me-up", "sign_me_up");
        },
        remindMeLater() {
            this.$emit("remid-me-later", "remind_me_later");
        },
    },
    created() {
        // document.body.classList.add("modal-open");
    },
    destroyed() {
        // document.body.classList.remove("modal-open");
    },
};
</script>
