import { createApp } from "vue";
import dashbaord from "./dashboard.vue";
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.css';
import VTooltip from 'floating-vue'
import 'floating-vue/dist/style.css'
import InfiniteLoading from "v3-infinite-loading";
import VuePlyr from "vue-plyr";
import "vue-plyr/dist/vue-plyr.css";
import VueMask from '@devindex/vue-mask';

const dashbaord_app = createApp(dashbaord);
dashbaord_app.use(VueMask);
dashbaord_app.use(VuePlyr, {
    plyr: {},
});
dashbaord_app.use(VTooltip);
dashbaord_app.component('InfiniteLoading', InfiniteLoading);
dashbaord_app.component('multiselect', Multiselect);
dashbaord_app.mount("#dashboard_app")