<template>
  <Teleport to="body">
    <transition name="modal">
      <div>
        <div class="modal-mask modal-scrollable access-right-modal">
          <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container abyde-certified-badge-modal">
              <button
                      @click="closeModal"
                      class="cursor-pointer modal-close"
                  >
                      <close-icon></close-icon>
              </button>
              <div v-if="user_badge_data.email_type=='MissingRequirements'" class="mt24">                
                <div class="text-center mlr-auto mb15 mt10">
                  <img :src="JS_APP_URL + '/images/abyde_certified_badge.svg'" class="abyde-certified-badge-gray" alt="" title="" />
                  </div>  
                  <h2 class="font-24 font_semibold blueog--text line-normal text-center mb10">
                    You’re Almost There! 
                  </h2>
                  <p class="font-16 text-999 font_normal mb4">You’re well on your way to earning the</p>
                  <p class="font-16 blueog--text font_semibold mb4">Abyde Certified – HIPAA for Covered Entities Badge for 2025</p>
                  <p class="font-16 text-999 font_normal mb15">– a recognition awarded to practices that meet key compliance milestones within the Abyde platform.</p>
                  <p class="font-16 text-999 font_normal mb15">The badge highlights your commitment to patient data security and builds valuable trust with your patients and partners.</p>
                  <p class="font-16 text-999 font_normal mb35"><a class="text-decoration-underline blueog--text" href="https://abyde.com/abyde-hipaa-certified-badges" target="_blank"><span class="font-16 blueog--text font_semibold">Explore</span></a> what the badge stands for and what steps remain – or schedule a quick walkthrough with our team below.</p>
                  <button class="btn-primary-outline h-32" @click="openScheduleRefresher()"> Schedule Refresher </button>               
              </div>            
              <div v-else class="mt24">               
                <div class="text-center mlr-auto mb5 mt10">
                  <img :src="JS_APP_URL + '/images/abyde_certified_badge.svg'" class="" alt="" title="" />
                </div>  
                <h2 class="font-24 font_semibold blueog--text line-normal text-center mb10">
                  You’ve Earned It!
                </h2>
                <p class="font-16 text-999 font_normal mb4">Congratulations! You’ve fulfilled all requirements to earn an </p>
                <p class="font-16 blueog--text font_semibold mb20">Abyde Certified – HIPAA for Covered Entities Badge for 2025!</p>
                <p class="font-16 text-999 font_normal mb15">Thank you for taking HIPAA compliance seriously and <br/> safeguarding Protected Health Information.</p>
                <p class="font-16 text-999 font_normal mb35">Learn more about your badge and why it matters <span class="font-16 blueog--text font_semibold"><a class="text-decoration-underline blueog--text" href="https://abyde.com/abyde-hipaa-certified-badges" target="_blank">here</a></span> – then use the link below to download and add it to your website. </p>
                <button class="btn-primary-outline h-32" @click="downloadBadge()" :disabled="btn_disabled"> DOWNLOAD BADGE </button>
              </div>
            </div>  
          </div>
        </div>
        <div class="modal-backdrop"></div>
      </div> 
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import closeIcon from "../common/icons/closeIcon.vue";
import _ from "lodash";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,                              
      btn_disabled: false,
    };
  },
  props: {  
    user_badge_data: {}
  },
  emits: ["close-modal"],
  components: { 
    closeIcon,
  },
  mounted() {
    this.setPopupOpen()
  },
  methods: {
    setPopupOpen()
    {   
        axios
        .get(JS_APP_URL + "/track-open-email-popup/"+ btoa(this.user_badge_data.id)+"/"+btoa("popup"))
        .then((response) => {
          if (response["data"]["status"] == "Success") {}
        })
        .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
            }
        });
    },
    closeModal() {
       this.$emit("close-modal");
    },
    openScheduleRefresher() { 
       window.open("https://calendly.com/ccsabyde/abyde-refresher");
    },
    downloadBadge()
    {  
        this.btn_disabled = true    
        axios
        .get(JS_APP_URL + "/track-open-attachment/"+ btoa(this.user_badge_data.id)+"/"+btoa("popup_attachment"))
        .then((response) => {
          if (response["data"]["status"] == "Success") {            
                  var link = document.createElement("a");                  
                  link.setAttribute("download", response["data"]['data']['file_name']);                  
                  link.setAttribute("href", JS_APP_URL + response["data"]['data']['download_url']);
                  link.setAttribute("target", '_blank');
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                  this.$emit("close-modal")
              }
        })
        .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
            }
        });
    }
  } 
};
</script>
