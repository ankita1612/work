<template>
  <Teleport to="body">
    <transition name="modal">
      <div>
        <div class="modal-mask modal-scrollable access-right-modal">
          <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
              <div class="text-center mlr-auto mb15 mt10">
              <img :src="JS_APP_URL + '/images/abyde_a.svg'" class="abyde-signup-logo" alt="" title="" />
              </div>  
              <h2 class="font-24 font_semibold blueog--text line-normal text-center mb30 ">
              Abyde wants to help your Business Associates!
              </h2>
              <p class="text-center font-16 gray_checkmark--text line-normal">
                  Curious if your Business Associates are also following industry best compliance practices? 
                  Well, we are one step ahead of you at <i>Abyde</i>.
              </p>
              </br>
              <p class="text-center font-16 gray_checkmark--text line-normal mb30">
                  Answer (YES!) below if you would like us to reach out to your Business Associates with a complimentary compliance assessment.
              </p>
              <div class="mb10">
                <a class="font-15 font_bold blue2--text text-decoration-underline cursor-pointer" @click="PlayVideoModalToggle('yes')">WATCH: Learn About Abyde's HIPAA BA Platform (&#60;2 min)</a>
              </div>
              <div class="form-group" :class="{ 'form-group--error': v$.is_accept_btn.$errors.length }">
              <div class="checkbox mb30">
                <input id="is_accept_btn" name="is_accept_btn" type="checkbox" :class="{ 'form-error': v$.is_accept_btn.$errors.length }" v-model="is_accept_btn">
                <label for="is_accept_btn" class="checkbox-label font-14 font_light gray_checkmark--text">I accept the </label><a class="font-14 font_semibold green--text text-decoration-underline cursor-pointer" @click="showTermsandCondition()">Disclaimer</a>
                <div v-if="v$.is_accept_btn.$errors.length > 0">
                  <div class="form-error-text" style="text-align: center !important;">
                      {{ v$.is_accept_btn.$errors[0].$message }}
                  </div>
                </div>
                </div> 
              </div>
              <div class="flex flex-wrap items-center justify-center pb10">
                  <button
                      v-on:click="notInterestedInPromo(2)"
                      class="btn-primary-outline mx5"
                      :disabled="btn_disabled"
                  >
                      Ask Me Later
                  </button>
                  <button
                      @click="interestedInPromo"
                      class="btn-primary btn-width-136 mx5 px30 mt-xs-20"
                      :disabled="btn_disabled"
                  >
                      YES!
                  </button>
              </div>
              <div class="flex flex-wrap items-center justify-center pb10">
                  <button
                      v-on:click="notInterestedInPromo(0)"
                      :disabled="btn_disabled"
                      class="btn-cancel-outline mx5" style="text-transform: none !important;">
                      No, please don't contact our BAs on our behalf
                  </button>
              </div>
              
            </div>
          </div>
        </div>
        <div class="modal-backdrop"></div> 
        <term-and-condition-modal
        v-if="show_terms_popup"
        @close-model="closeTermsAndCondition"
        />
        <play-video-modal
        v-if="play_video_modal == 'true'"
        :video_file_url="video_file_url"
        @close-model="PlayVideoModalToggle"
        @ended="videoEnded"
      ></play-video-modal>
      </div> 
    </transition>
  </Teleport>
</template>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import useVuelidate from "@vuelidate/core";
import { sameAs, helpers } from "@vuelidate/validators";
import closeIcon from "../common/icons/closeIcon.vue";
import termAndConditionModal from "./termAndConditionModal.vue"
import playVideoModal from "./playVideoModal.vue";
import _ from "lodash";

export default {
  props: {  
    
  },
  emits: ["close-model"],
  components: { 
    closeIcon,
    playVideoModal,
    termAndConditionModal
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    return {
      is_accept_btn: {
        sameAsRawValue: helpers.withMessage("Please agree with disclaimer", sameAs(true))
      } 
    }
    
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_interested : null,
      is_accept_btn : null,
      show_terms_popup : false,
      play_video_modal: false,
      video_file_url: null,
      btn_disabled: false,
    };
  },
  watch:{
   
  },
  methods: {
    notInterestedInPromo(user_response = 0) {
        // 0 for No, 2 for Ask Later 
        this.is_interested = user_response;
        this.btn_disabled = true
        this.$emit("close-model", this.is_interested);
    },
    async interestedInPromo() {
        this.v$.$touch();
        if (!this.v$.$invalid) {
          this.btn_disabled = true
          this.is_interested = 1;
          this.$emit("close-model", this.is_interested);
        }
    },
    showTermsandCondition() {
        this.show_terms_popup = true;
    },
    closeTermsAndCondition(){
        this.show_terms_popup = false;
    },
    PlayVideoModalToggle(is_api_call = 'yes') {
      if (this.play_video_modal == "true") {
        this.play_video_modal = "false";
      } else {
        if(is_api_call ==  'yes'){
            this.createSignUrl();
        }
        setTimeout(() => {
            if(this.video_file_url != null){
                this.play_video_modal = "true";
            }else{
                this.PlayVideoModalToggle('no');
            }
        }, 200);
      }
    },
    videoEnded(){
       this.play_video_modal = "false";
    },
    createSignUrl(){
        var request = {
            params: {
                file_path: 'common_media/hipaa_ba_popup_video.mp4',
                file_exp_time: 3600
            }
        }
        axios
        .get(JS_APP_URL + "/general/get-sign-url",request)
        .then((response) => {
            if (response["data"]["status"] == "Success") {
                this.video_file_url = response.data.data;
            }
        })
        .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
            }
        });
    },  
   
   },
 
};
</script>
