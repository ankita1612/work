<template>
  <div>
    <video oncontextmenu="return false;" ref="videoPlayer" class="video-js"  @ended="onPlayerEnded($event)" ></video>
  </div>
</template>

<script>
import videojs from 'video.js';

export default {
  name: 'VideoPlayer',
  props: {
    options: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  emits: ['ended'],
  data() {
    return {
      player: null
    }
  },
  mounted() {
    this.player = videojs(this.$refs.videoPlayer, this.options, () => {});
  },
  beforeDestroy() {
    if (this.player) {
      this.player.dispose();
    }
  },
  methods: {
    onPlayerEnded(){
      this.$emit('ended');
    }
  },
}
</script>