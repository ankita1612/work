<template>
  <div>
    <div class="relative flex items-center justify-center flex-wrap mb30">
      <h1 class="
          location-dashbaord-title
          text-center
          font-24 font_semibold
          blueog--text
          line-normal
        " v-if="AUTH_USER.is_sra_user == 0" v-text="locations_nick_name_list.length > 1?'HIPAA Compliance Programs':'HIPAA Compliance Program'">
      </h1>
      <h1 class="
          location-dashbaord-title
          text-center
          font-24 font_semibold
          blueog--text
          line-normal
        " v-else>HIPAA Security Risk Analysis
      </h1>

      <VTooltip v-if="AUTH_USER.is_sra_user == 0" :triggers="['hover']" :popperTriggers="['hover']" class="ml6">
        <button @click="PlayExplainerVideoModalToggle('yes')" class="cursor-pointer svg-icon-height dashboard-video-icon mt4">
          <explainer-video-icon></explainer-video-icon>
        </button>
        <template #popper>
          Video Guide
        </template>
      </VTooltip>

      <div class="location-view flex items-center d-none d-xl-flex" v-if="locations_nick_name_list.length > 1">
        <span class="font-18 blueog--text mr5">View:</span>
        <VTooltip :triggers="['hover']" :popperTriggers="['hover']" style="height: 32px;" class="cursor-pointer">
          <template #popper>
            Grid View
          </template>
          <button type="button" class="grid-view-btn cursor-pointer" :class="{ active: is_grid_view }"
            @click="changeLocationView('grid')">
            <span style="float:left"></span><span style="float:right"></span>
          </button>
        </VTooltip>
        <VTooltip :triggers="['hover']" :popperTriggers="['hover']" style="height: 32px;" class="cursor-pointer">
          <template #popper>
            List View
          </template>
          <button type="button" class="list-view-btn cursor-pointer ml4" :class="{ active: !is_grid_view }"
            @click="changeLocationView('list')">
            <span></span>
          </button>
        </VTooltip>
      </div>
    </div>

    <dashboard-filter v-if="locations_nick_name_list.length > 1" @get-locations="getLocationsBySeachValue"
      :key="refreshDashboardFilter" :locations_nick_name="locations_nick_name_list" :all_hco_list="all_hco_list_data"
      :busy="busy" />


    <div :class="{'pt40': locations_nick_name_list.length > 1}">
      <div class="row flex-auto -mx-10">
        <div class="col-12 px10 pb50" v-for="(location, loc_index) in locations" :key="location.id"
          :class="{ 'col-xl-6': is_grid_view, 'col-xl-12': !is_grid_view }">
          <div class="location-card pb40">
            <div class="
                  location-card-header
                  relative
                  flex
                  items-center
                  justify-center
                  text-center
                  py9
                ">
              <span class="
                    location-name
                    font-21 font_bold
                    white--text
                    line-normal
                  " :title="location.location_nickname">
                {{ location.location_nickname }}
              </span>
              <VDropdown class="location-notification-count popover__wrapper
                    flex
                    items-center
                    justify-center
                    white--text
                    font_bold
                    cursor-pointer" v-if="location.open_notifications_count > 0">
                <div class=" fill-height fill-width flex items-center justify-center" style="">
                  {{location.open_notifications_count}}</div>
                <template #popper>
                  <div class="notification-popover-content">
                    <h4 class="
                          font-16 font_semibold
                          blueog--text
                          mb10
                          text-center
                        ">
                      Notifications
                    </h4>
                    <div class="notification-popover-container scrollbar-style">
                      <div class="mb5 flex items-center justify-between" v-for="notification in location.notification"
                        :key="notification.id">
                        <a class="
                              noti-btn-link
                              font-12
                              gray_checkmark--text
                              font-400 font_normal
                              flex-auto mr5
                              cursor-pointer
                            " v-bind:title="getReplacedTitle(notification)"
                          @click="notificationRedirectUrl(notification.notification.redirect_url,location.id)">
                          {{getReplacedTitle(notification)}}
                        </a>
                        <div class="checkbox mt6 relative">
                          <input @change="completeNotificationStatus(notification.id, loc_index)"
                            :id="notification.id+'add_hco_option_yes'" :name="notification.id+'add_hco_option_yes'"
                            type="checkbox">
                          <label :for="notification.id+'add_hco_option_yes'"
                            class="checkbox-label font-14 font-light gray_checkmark--text"></label>
                        </div>
                      </div>
                    </div>
                    <hr class="noti-sept-line" />
                    <div class="text-center">
                      <a :href="JS_APP_URL + '/notification/' + encryption(location.id)"
                        class="font-14 font_semibold green--text hover-underline-animation noti-popover-link">
                        See All Notifications
                      </a>
                    </div>
                  </div>
                </template>
              </VDropdown>
            </div>
            <div class="location-card-content pb10 px20">
              <!-- account users -->
              <div class="location-card-row py8" v-if="AUTH_USER.user_type != 'USER'">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="JS_APP_URL + '/accountuser'" class="ds-btn-users">Users & Contributors</a>
                    </span>
                    <span
                      :class="{'notification-dot': notificationModuleStatus('accountuser', location.notification)}"></span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      We're all in this together!
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div class="
                            location-select-user-link
                            font-16 font_semibold
                            blueog--text
                        " v-if="location.account_location_access.length > 0 && location.accountuser_last_updated">
                      <span class="location-item-gray-text font-11 font-italic font_light no-hover">Last
                        Updated:</span><br />
                      {{
                      dateFormat(
                      location.accountuser_last_updated
                      )
                      }}
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-2 px-10 text-center full-colum-buttons"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <div class="scorecard-indecater-wrapper inline-flex items-center justify-center justify-start-small fill-width" v-if="location.account_location_access.length > 0 || location.contributor_location_count > 0">
                      <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="mx6">
                        <div class="cursor-pointer svg-icon-height">
                          <a :href="JS_APP_URL + '/accountuser'">
                            <div class="risk-circle users-circle font-14 font_semibold">{{ location.account_location_access.length }}
                            </div>
                          </a>
                        </div>
                        <template #popper>
                          Users
                        </template>
                      </VTooltip>
                      <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="mx6">
                        <div class="cursor-pointer svg-icon-height">
                          <a :href="JS_APP_URL + '/accountuser'">
                            <div class="risk-circle sra-contributor-circle font-14 font_semibold">{{ location.contributor_location_count }}
                            </div>
                          </a>
                        </div>
                        <template #popper>
                          SRA Contributors
                        </template>
                      </VTooltip>
                    </div>
                    <a v-else :href="JS_APP_URL + '/accountuser'">
                      <button type="button" class="location-card-btn ds-btn-users btn-primary-small d-inline-block">Add</button>
                    </a>
                  </div>
                </div>
              </div>
              <!-- hco -->
              <div class="location-card-row py8" v-if="AUTH_USER.user_type != 'USER'">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="JS_APP_URL + '/accountuser'" class="ds-btn-hco">HIPAA Compliance Officer</a>
                      <span
                        :class="{'notification-dot': notificationModuleStatus('accountuser', location.notification)}"></span>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      With great power comes great responsibility
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div class="
                            location-select-user-link
                            font-16 font_semibold
                            blueog--text
                        " v-if="location.hipaa_compliance_officer">
                      <span class="location-item-gray-text font-11 font-italic font_light no-hover">Last
                        Updated:</span><br />
                      {{
                      dateFormat(
                      location.hipaa_compliance_officer.updated_at
                      )
                      }}
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-2 px-10 text-center full-colum-buttons"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <button type="button" class="location-card-btn dash-hipaa-safety-btn ds-btn-hco"
                      @click="selectHCOToggle(true, location)" :class="[
                            (location.hipaa_compliance_officer) ? 'btn-blue' : 'btn-primary-small d-inline-block'
                        ]"
                      :title='location.hipaa_compliance_officer ? location.hipaa_compliance_officer.hco.first_name +" " +location.hipaa_compliance_officer.hco.last_name: ""'>
                      {{
                      location.hipaa_compliance_officer
                      ? location.hipaa_compliance_officer.hco.first_name +
                      " " +
                      location.hipaa_compliance_officer.hco.last_name
                      : "Add"
                      }}
                    </button>
                  </div>
                </div>
              </div>
              <!-- company info -->
              <div class="location-card-row py8">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="(!isModuleLocked('company', location)) ? JS_APP_URL + '/company/' + encryption(location.id) : 'javascript:void(0)'"
                        :class="{'text-locked': isModuleLocked('company', location), 'ds-btn-company-info': !isModuleLocked('company', location)}">Company
                        Information</a>
                      <span
                        :class="{'notification-dot': notificationModuleStatus('company', location.notification)}"></span>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      Don't be shy, tell us about yourself
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div class="
                            location-select-user-link
                            font-16 font_semibold
                            blueog--text
                        "
                      v-if="!isModuleLocked('company', location) && location.company_module_completed_count == 1 && location.updated_at">
                      <span class="location-item-gray-text font-11 font-italic font_light no-hover">Last
                        Updated:</span><br />
                      {{
                      dateFormat(
                      location.updated_at
                      )
                      }}
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-2 px-10 text-center full-colum-buttons"
                    :class="{ 'split-colum-buttons': is_grid_view }">

                    <a v-if="(location.company_module_completed_count == 0 || location.ce_type_id == null) && !isModuleLocked('company', location)"
                      :href="JS_APP_URL + '/company/' + encryption(location.id)"
                      class="location-card-btn btn-primary-small text-center d-inline-block ds-btn-company-info">Add
                    </a>
                    <button v-if="isModuleLocked('company', location)"
                      class="location-card-btn btn-locked-small-outline">locked</button>
                    <div
                      v-if="location.company_module_completed_count == 1 && !isModuleLocked('company', location) &&location.ce_type_id != null"
                      class="location-last-column-wrapper d-inline-block text-center ds-btn-company-info">
                      <a :href="JS_APP_URL + '/company/' + encryption(location.id)" class="d-inline-block">
                        <img :src="JS_APP_URL +'/images/Complete.png'" class="complete-img" alt="" title="">
                      </a>
                    </div>

                  </div>
                </div>
              </div>
              <!-- sra -->
              <div class="location-card-row py8">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="(!isModuleLocked('sra', location)) ? JS_APP_URL + '/security-risk-analysis/' +encryption(location.id) : 'javascript:void(0)'"
                        :class="{'text-locked': isModuleLocked('sra', location), 'ds-btn-security-risk-analysis': !isModuleLocked('sra', location)}">Security
                        Risk Analysis</a>
                      <span
                        :class="{'notification-dot': notificationModuleStatus('security-risk-analysis', location.notification)}"></span>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      Identifying risks and vulnerabilities has never been so painless
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div
                      v-if="!isModuleLocked('sra', location) && location.sra_percentage_count.percentage == 100 && ( location.sra_module_completed && location.sra_module_completed.is_completed && location.sra_module_completed.updated_at)"
                      class="location-select-user-link
                            font-16 font_semibold
                            blueog--text">

                      <span
                        class="location-item-gray-text font-11 font-italic font_light no-hover">Completed:</span><br />
                      {{
                      dateFormat(
                      location.sra_module_completed.updated_at
                      )
                      }}
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-2 px-10 text-center full-colum-buttons"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <div v-if="!isModuleLocked('sra', location) && location.sra_percentage_count.percentage == 0">
                      <a :href="JS_APP_URL + '/security-risk-analysis/' + encryption(location.id)" class="d-block">
                        <button type="button"
                          class="btn-primary-small location-card-btn d-inline-block ds-btn-security-risk-analysis">
                          start
                        </button>
                      </a>
                    </div>
                    <div
                      v-else-if="!isModuleLocked('sra', location) && location.sra_percentage_count.percentage > 0 && location.sra_percentage_count.percentage < 100"
                      class="text-center">
                      <a :href="JS_APP_URL + '/security-risk-analysis/' + encryption(location.id)"
                        class="d-inline-block ds-btn-security-risk-analysis">
                        <radial-progress-bar :diameter="44" :completed-steps="location.sra_percentage_count.percentage"
                          :total-steps="100" :inner-stroke-width="3" :stroke-width="3"
                          :start-color="get_sra_og_progress_color(location.sra_percentage_count.percentage)"
                          :stop-color="get_sra_og_progress_color(location.sra_percentage_count.percentage)"
                          :inner-stroke-color="inner_stroke_color">
                          <span class="font-14 sra-percent-text font_semibold red--text"
                            v-bind:style="{color: get_sra_og_progress_color(location.sra_percentage_count.percentage)}">{{
                            location.sra_percentage_count.percentage }}%</span>
                        </radial-progress-bar>
                      </a>
                    </div>
                    <div class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center
                        " v-if="!isModuleLocked('sra', location) && location.sra_percentage_count.percentage == 100">
                      <button type="button" class="complete-btn ds-btn-security-risk-analysis">
                        <a :href="JS_APP_URL + '/security-risk-analysis/' + encryption(location.id)">
                          <img :src="JS_APP_URL +'/images/Complete.png'" class="complete-img" alt="" title="">
                        </a>
                      </button>
                    </div>
                    <div class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center
                        " v-if="isModuleLocked('sra', location)">
                      <button type="button">
                        <a href="javascript:void(0)">
                          <img :src="JS_APP_URL +'/images/locked-sra.png'" class="locked-img" alt="" title="">
                        </a>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- scorecard -->
              <div class="location-card-row py8">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="(!isModuleLocked('scorecard', location)) ? JS_APP_URL + '/scorecard/' + encryption(location.id) : 'javascript:void(0)'"
                        :class="{'text-locked': isModuleLocked('scorecard', location), 'ds-btn-scorecard': !isModuleLocked('scorecard', location)}">Scorecard</a>
                    </span>
                    <span class="
                              location-item-gray-text location-description-text
                              font-12 font-italic no-hover ml10
                          " :class="{ 'd-xl-none': is_grid_view }">
                      Review the results of your SRA and view recommendations
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div v-if="!isModuleLocked('scorecard', location) && location.scorecard_last_updated" class="location-select-user-link
                            font-16 font_semibold
                            blueog--text">
                      <span class="location-item-gray-text font-11 font-italic font_light no-hover">Last
                        Updated:</span><br />
                      {{
                      dateFormat(
                      location.scorecard_last_updated
                      )
                      }}
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-2 px-10 text-center"
                    :class="{ 'split-colum-buttons': is_grid_view }" v-if="!isModuleLocked('scorecard', location)">
                    <div
                      class="scorecard-indecater-wrapper inline-flex items-center justify-center justify-start-small fill-width">
                      <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="mx6">
                        <div class="cursor-pointer svg-icon-height">
                          <a :href="JS_APP_URL + '/scorecard/' + encryption(location.id)">
                            <div class="risk-circle low-risk-circle font-14 font_semibold">{{ location.low_risk_count }}
                            </div>
                          </a>
                        </div>
                        <template #popper>
                          Low Risk
                        </template>
                      </VTooltip>
                      <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="mx6">
                        <div class="cursor-pointer svg-icon-height">
                          <a :href="JS_APP_URL + '/scorecard/' + encryption(location.id)">
                            <div class="risk-circle medium-risk-circle font-14 font_semibold ds-btn-scorecard">{{
                              location.medium_risk_count }}</div>
                          </a>
                        </div>
                        <template #popper>
                          Medium Risk
                        </template>
                      </VTooltip>
                      <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="mx6">
                        <div class="cursor-pointer svg-icon-height">
                          <a :href="JS_APP_URL + '/scorecard/' +encryption(location.id)">
                            <div class="risk-circle high-risk-circle font-14 font_semibold ds-btn-scorecard">{{
                              location.high_risk_count }}</div>
                          </a>
                        </div>
                        <template #popper>
                          High Risk
                        </template>
                      </VTooltip>
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-2 px-10 text-center full-colum-buttons"
                    :class="{ 'split-colum-buttons': is_grid_view }" v-if="isModuleLocked('scorecard', location)">
                    <div class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center
                        ">
                      <button type="button">
                        <a href="javascript:void(0)">
                          <img :src="JS_APP_URL +'/images/scorecard-locked.png'" class="locked-img-scorecard" alt=""
                            title="">
                        </a>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- employees -->
              <div class="location-card-row py8" v-if="AUTH_USER.is_sra_user == 0">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="(!isModuleLocked('employee', location)) ? JS_APP_URL + '/employee' : 'javascript:void(0)'"
                        :class="{'text-locked': isModuleLocked('employee', location), 'ds-btn-employee': !isModuleLocked('employee', location)}">Employees</a>
                      <span
                        :class="{'notification-dot': notificationModuleStatus('employee', location.notification)}"></span>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      Teamwork makes the dream work
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div class="
                            location-select-user-link
                            font-16 font_semibold
                            blueog--text
                        "
                      v-if="(location.employee_primary_work_location.length > 0 || location.employee_secondary_work_location.length > 0) && !isModuleLocked('employee', location) && location.employee_last_updated">
                      <span class="location-item-gray-text font-11 font-italic font_light no-hover">Last
                        Updated:</span><br />
                      {{
                      dateFormat(
                      location.employee_last_updated
                      )
                      }}
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-2 px-10 text-center full-colum-buttons"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <a :href="JS_APP_URL + '/employee'" class="d-inline-block"
                      v-if="!isModuleLocked('employee', location)">
                      <button type="button" class="btn-primary-small location-card-btn ds-btn-employee" :class="[
                            (location.employee_primary_work_location.length > 0 || location.employee_secondary_work_location.length > 0)? 'btn-blue': 'btn-primary-small d-inline-block'
                        ]">
                        {{
                        (location.employee_primary_work_location.length > 0 ||
                        location.employee_secondary_work_location.length > 0)
                        ? location.employee_primary_work_location.length +
                        location.employee_secondary_work_location.length
                        : "Add"
                        }}
                      </button>
                    </a>
                    <div class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center
                        " v-if="isModuleLocked('employee', location)">
                      <button class="location-card-btn btn-locked-small-outline">locked</button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="location-card-row py8" v-else-if="AUTH_USER.is_sra_user == 1">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a href="javascript:void(0)" class="text-locked ds-btn-employee">Employees</a>
                    </span>
                    <span class="location-item-gray-text location-description-text font-12 font-italic no-hover ml10" :class="{ 'd-xl-none': is_grid_view }">
                      Teamwork makes the dream work
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-2 px-10 text-center full-colum-buttons"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <a v-if="AUTH_USER.partner_reseller_id == null || this.AUTH_USER.is_admin_panel_login == 'true'" :href="(AUTH_USER.user_type == 'PCO') ? JS_APP_URL + '/sra-only-full-upgrade' : 'javascript:void(0)'">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard" :class="{ 'not-allowed': (AUTH_USER.user_type != 'PCO') }"/>
                    </a>
                    <a v-else-if="AUTH_USER.partner_reseller_id != null && this.AUTH_USER.is_admin_panel_login == 'false'" @click="showUpgradeRestrictionModalToggle">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard"/>
                    </a>
                  </div>
                </div>
              </div>
              <!-- Students -->
              <div class="location-card-row py8" v-if="AUTH_USER.is_educational_account == 1 && AUTH_USER.is_sra_user == 0">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="(!isModuleLocked('student', location)) ? JS_APP_URL + '/student' : 'javascript:void(0)'"
                        :class="{'text-locked': isModuleLocked('student', location), 'ds-btn-student' : !isModuleLocked('student', location)}">Students</a>
                      <span
                        :class="{'notification-dot': notificationModuleStatus('student', location.notification)}"></span>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      Teamwork makes the dream work
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div class="
                            location-select-user-link
                            font-16 font_semibold
                            blueog--text
                        "
                      v-if="location.student_primary_work_location.length > 0 && !isModuleLocked('student', location) && location.student_last_updated">
                      <span class="location-item-gray-text font-11 font-italic font_light no-hover">Last
                        Updated:</span><br />
                      {{
                      dateFormat(
                      location.student_last_updated
                      )
                      }}
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-2 px-10 text-center full-colum-buttons"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <a :href="JS_APP_URL + '/student'" class="d-inline-block"
                      v-if="!isModuleLocked('student', location)">
                      <button type="button" class="btn-primary-small location-card-btn ds-btn-student" :class="[
                            location.student_primary_work_location.length > 0 ? 'btn-blue': 'btn-primary-small d-inline-block'
                        ]">
                        {{
                        location.student_primary_work_location.length > 0
                        ? location.student_primary_work_location.length
                        : "Add"
                        }}
                      </button>
                    </a>
                    <div class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center
                        " v-if="isModuleLocked('student', location)">
                      <button class="location-card-btn btn-locked-small-outline">locked</button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="location-card-row py8" v-else-if="AUTH_USER.is_educational_account == 1 && AUTH_USER.is_sra_user == 1">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a href="javascript:void(0)" class="text-locked ds-btn-student">Students</a>
                    </span>
                    <span class="location-item-gray-text location-description-text font-12 font-italic no-hover ml10" :class="{ 'd-xl-none': is_grid_view }">
                      Teamwork makes the dream work
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-2 px-10 text-center full-colum-buttons"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <a v-if="AUTH_USER.partner_reseller_id == null || this.AUTH_USER.is_admin_panel_login == 'true'" :href="(AUTH_USER.user_type == 'PCO') ? JS_APP_URL + '/sra-only-full-upgrade' : 'javascript:void(0)'">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard" :class="{ 'not-allowed': (AUTH_USER.user_type != 'PCO') }"/>
                    </a>
                    <a v-else-if="AUTH_USER.partner_reseller_id != null && this.AUTH_USER.is_admin_panel_login == 'false'" @click="showUpgradeRestrictionModalToggle">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard"/>
                    </a>
                  </div>
                </div>
              </div>
              <!-- Disaster Recovery Plan -->
              <div class="location-card-row py8" v-if="AUTH_USER.is_sra_user == 0">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="(!isModuleLocked('disaster_recovery_plan', location)) ? JS_APP_URL + '/disaster-recovery-plan/' + encryption(location.id) : 'javascript:void(0)'"
                        :class="{'text-locked' : isModuleLocked('disaster_recovery_plan', location), 'ds-btn-disaster-recovery-plan': !isModuleLocked('disaster_recovery_plan', location)}">Disaster
                        Recovery Plan</a>
                      <span
                        :class="{'notification-dot': notificationModuleStatus('disaster-recovery-plan', location.notification)}"></span>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      In case of emergency!
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div class="
                            location-select-user-link
                            font-16 font_semibold
                            blueog--text
                        "
                      v-if="!isModuleLocked('disaster_recovery_plan', location) && location.disaster_recovery_plan_module_completed_count == 1 && location.disaster_last_updated">
                      <span class="location-item-gray-text font-11 font-italic font_light no-hover">Last
                        Updated:</span><br />
                      {{
                      dateFormat(
                      location.disaster_last_updated
                      )
                      }}
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-2 px-10 text-center full-colum-buttons"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <a v-if="location.disaster_recovery_plan_module_completed_count == 0 && !isModuleLocked('disaster_recovery_plan', location)"
                      :href="JS_APP_URL + '/disaster-recovery-plan/' + encryption(location.id)"
                      class="location-card-btn btn-primary-small text-center d-inline-block ds-btn-disaster-recovery-plan">
                      Add
                    </a>
                    <div
                      v-if="location.disaster_recovery_plan_module_completed_count == 1 && !isModuleLocked('disaster_recovery_plan', location)"
                      class="location-last-column-wrapper d-inline-block text-center ds-btn-disaster-recovery-plan">
                      <a :href="JS_APP_URL + '/disaster-recovery-plan/' + encryption(location.id)"
                        class="d-inline-block">
                        <img :src="JS_APP_URL +'/images/Complete.png'" class="complete-img" alt="" title="">
                      </a>
                    </div>
                    <button v-if="isModuleLocked('disaster_recovery_plan', location)"
                      class="location-card-btn btn-locked-small-outline">locked</button>
                  </div>
                </div>
              </div>
              <div class="location-card-row py8" v-else-if="AUTH_USER.is_sra_user == 1">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a href="javascript:void(0)" class="text-locked ds-btn-disaster-recovery-plan">Disaster Recovery Plan</a>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      In case of emergency!
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                  </div>
                  <div class="col-12 col-md-6 col-lg-3 col-xl-2 px-10 text-center full-colum-buttons"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <a v-if="AUTH_USER.partner_reseller_id == null || this.AUTH_USER.is_admin_panel_login == 'true'" :href="(AUTH_USER.user_type == 'PCO') ? JS_APP_URL + '/sra-only-full-upgrade' : 'javascript:void(0)'">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard" :class="{ 'not-allowed': (AUTH_USER.user_type != 'PCO') }"/>
                    </a>
                    <a v-else-if="AUTH_USER.partner_reseller_id != null && this.AUTH_USER.is_admin_panel_login == 'false'" @click="showUpgradeRestrictionModalToggle">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard"/>
                    </a>
                  </div>
                </div>
              </div>
              <!-- ongoing compliance -->
              <div class="location-card-row py8">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="(!isModuleLocked('ongoing', location)) ? JS_APP_URL + '/ongoing-compliance/' + encryption(location.id) : 'javascript:void(0)'"
                        :class="{'text-locked': isModuleLocked('ongoing', location), 'ds-btn-ongoing-compliance': !isModuleLocked('ongoing', location)}">Ongoing
                        Compliance</a>
                      <span
                        :class="{'notification-dot': notificationModuleStatus('ongoing-compliance', location.notification)}"></span>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      Protecting the privacy and security of data never stops!
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div class="
                            location-select-user-link
                            font-16 font_semibold
                            blueog--text
                        ">
                      <div
                        v-if="!isModuleLocked('ongoing', location) && location.ongoing_compliance_percentage_count.percentage == 100">

                        <span
                          class="location-item-gray-text font-11 font-italic font_light no-hover">Completed:</span><br />
                        {{
                        dateFormat(
                        (location.ongoing_last_completed)?location.ongoing_last_completed :
                        location.sra_module_completed.updated_at
                        )
                        }}
                      </div>
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-2 px-10 text-center"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <div
                      v-if="!isModuleLocked('ongoing', location) && location.ongoing_compliance_percentage_count.percentage == 0">
                      <a :href="JS_APP_URL + '/ongoing-compliance/' + encryption(location.id)" class="d-inline-block">
                        <button type="button"
                          class="btn-primary-small location-card-btn d-inline-block ds-btn-ongoing-compliance">
                          start
                        </button>
                      </a>
                    </div>
                    <div
                      v-else-if="!isModuleLocked('ongoing', location) && location.ongoing_compliance_percentage_count.percentage > 0 && location.ongoing_compliance_percentage_count.percentage < 100"
                      class="text-center">
                      <a :href="JS_APP_URL + '/ongoing-compliance/' + encryption(location.id)"
                        class="d-inline-block ds-btn-ongoing-compliance">
                        <radial-progress-bar :diameter="42"
                          :completed-steps="location.ongoing_compliance_percentage_count.percentage" :total-steps="100"
                          :inner-stroke-width="2" :stroke-width="2"
                          :start-color="get_sra_og_progress_color(location.ongoing_compliance_percentage_count.percentage)"
                          :stop-color="get_sra_og_progress_color(location.ongoing_compliance_percentage_count.percentage)"
                          :inner-stroke-color="inner_stroke_color">
                          <span class="font-14 sra-percent-text font_semibold red--text"
                            v-bind:style="{color: get_sra_og_progress_color(location.ongoing_compliance_percentage_count.percentage)}">{{
                            location.ongoing_compliance_percentage_count.percentage }}%</span>
                        </radial-progress-bar>
                      </a>
                    </div>
                    <div class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center ds-btn-ongoing-compliance
                        "
                      v-if="!isModuleLocked('ongoing', location) && location.ongoing_compliance_percentage_count.percentage == 100">
                      <button type="button" class="complete-btn ds-btn-ongoing-compliance">
                        <a :href="JS_APP_URL + '/ongoing-compliance/' + encryption(location.id)">
                          <img :src="JS_APP_URL +'/images/Complete.png'" class="complete-img" alt="" title="">
                        </a>
                      </button>
                    </div>
                    <div class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center
                        " v-if="isModuleLocked('ongoing', location)">
                      <button type="button">
                        <a href="javascript:void(0)">
                          <img :src="JS_APP_URL +'/images/locked-sra.png'" class="locked-img" alt="" title="">
                        </a>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- training -->
              <div class="location-card-row py8" v-if="AUTH_USER.is_sra_user == 0">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="(!isModuleLocked('training', location)) ? JS_APP_URL + '/training/' + encryption(location.id) : 'javascript:void(0)'"
                        :class="{'text-locked': isModuleLocked('training', location), 'ds-btn-training': !isModuleLocked('training', location)}">HIPAA
                        Training</a>
                      <span
                        :class="{'notification-dot': !isModuleLocked('training', location) && notificationModuleStatus('training', location.notification)}"></span>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      Watch the video, take the quiz, print your certificate. It's that easy
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div class="
                            location-select-user-link
                            font-16 font_semibold
                            blueog--text
                        " v-if="!isModuleLocked('training', location) && location.training_last_updated">
                      <span class="location-item-gray-text font-11 font-italic font_light no-hover">Last
                        Updated:</span><br />
                      {{
                      dateFormat(
                      location.training_last_updated
                      )
                      }}
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-2 px-10 text-center"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <div
                      class="scorecard-indecater-wrapper inline-flex items-center justify-center justify-start-small fill-width"
                      v-if="!isModuleLocked('training', location) && (location.training_counts.pending_invites > 0 || location.training_counts.unassigned_invites > 0)">

                      <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="mx6"
                        v-if="location.training_counts.pending_invites > 0">
                        <div class="cursor-pointer svg-icon-height">
                          <a :href="JS_APP_URL + '/training/' + encryption(location.id)">
                            <div class="risk-circle medium-risk-circle font-14 font_semibold ds-btn-scorecard">
                              {{ location.training_counts.pending_invites > 99 ? "99+" :
                              location.training_counts.pending_invites }}
                            </div>
                          </a>
                        </div>
                        <template #popper>
                          Pending ({{ location.training_counts.pending_invites }})
                        </template>
                      </VTooltip>
                      <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="mx6"
                        v-if="location.training_counts.unassigned_invites > 0">
                        <div class="cursor-pointer svg-icon-height">
                          <a :href="JS_APP_URL + '/training/' + encryption(location.id)">
                            <div class="risk-circle high-risk-circle font-14 font_semibold ds-btn-scorecard">
                              {{ location.training_counts.unassigned_invites > 99 ? "99+" :
                              location.training_counts.unassigned_invites }}
                            </div>
                          </a>
                        </div>
                        <template #popper>
                          Unassigned ({{ location.training_counts.unassigned_invites }})
                        </template>
                      </VTooltip>
                    </div>
                    <div class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center ds-btn-ongoing-compliance
                        "
                      v-if="!isModuleLocked('training', location) && location.training_counts.pending_invites == 0 && location.training_counts.unassigned_invites == 0">
                      <button type="button" class="complete-btn ds-btn-ongoing-compliance">
                        <a :href="JS_APP_URL + '/training/' + encryption(location.id)">
                          <img :src="JS_APP_URL +'/images/Complete.png'" class="complete-img" alt="" title="">
                        </a>
                      </button>
                    </div>
                    <div class="location-last-column-wrapper d-inline-block text-center"
                      v-if="isModuleLocked('training', location)">
                      <button type="button" class="hipaa-training-book-btn">
                        <a href="javascript:void(0)">
                          <img :src="JS_APP_URL + '/images/book-active.svg'" alt="" title=""
                            :class="{'img-locked': (isModuleLocked('training', location))}" />
                        </a>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="location-card-row py8" v-else-if="AUTH_USER.is_sra_user == 1">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a href="javascript:void(0)" class="text-locked ds-btn-training">HIPAA Training</a>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      Watch the video, take the quiz, print your certificate. It's that easy
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-2 px-10 text-center"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <a v-if="AUTH_USER.partner_reseller_id == null || this.AUTH_USER.is_admin_panel_login == 'true'" :href="(AUTH_USER.user_type == 'PCO') ? JS_APP_URL + '/sra-only-full-upgrade' : 'javascript:void(0)'">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard" :class="{ 'not-allowed': (AUTH_USER.user_type != 'PCO') }"/>
                    </a>
                    <a v-else-if="AUTH_USER.partner_reseller_id != null && this.AUTH_USER.is_admin_panel_login == 'false'" @click="showUpgradeRestrictionModalToggle">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard"/>
                    </a>
                  </div>
                </div>
              </div>
              <!-- Business associate Portal -->
              <div class="location-card-row py8" v-if="AUTH_USER.is_sra_user == 0">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="(!isModuleLocked('businessassociates', location)) ? JS_APP_URL + '/business-associates' : 'javascript:void(0)'"
                        :class="{'text-locked': isModuleLocked('businessassociates', location), 'ds-btn-businessassociate': !isModuleLocked('businessassociates', location)}">Business
                        Associate Portal</a>
                      <span
                        :class="{'notification-dot': notificationModuleStatus('business-associates', location.notification)}"></span>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      Manage all of your BAAs in one place
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div class="
                            location-select-user-link
                            font-16 font_semibold
                            blueog--text
                        "
                      v-if="!isModuleLocked('businessassociates', location) && location.business_associates_last_updated && location.business_associates_location_count > 0">
                      <span class="location-item-gray-text font-11 font-italic font_light no-hover">Last
                        Updated:</span><br />
                      {{
                      dateFormat(
                      location.business_associates_last_updated
                      )
                      }}
                    </div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-2 px-10 text-center"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <div class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center
                        ">
                        <a :href="JS_APP_URL + '/business-associates'" class="d-inline-block" v-if="!isModuleLocked('businessassociates', location)">
                        <button
                          type="button"
                          class="btn-primary-small location-card-btn"
                              :class="[
                              (location.business_associates_location_count > 0)? 'btn-blue': 'btn-primary-small d-inline-block'
                          ]"
                        >
                          {{
                              (location.business_associates_location_count > 0)
                              ? location.business_associates_location_count
                              : "Add"
                          }}
                        </button>
                      </a>
                      <div
                        class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center
                        "
                        v-if="isModuleLocked('businessassociates', location)"
                        >
                        <button class="location-card-btn btn-locked-small-outline">locked</button>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="location-card-row py8" v-else-if="AUTH_USER.is_sra_user == 1">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a href="javascript:void(0)"
                        class="text-locked ds-btn-businessassociate">Business
                        Associate Portal</a>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      Manage all of your BAAs in one place
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-2 px-10 text-center"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <a v-if="AUTH_USER.partner_reseller_id == null || this.AUTH_USER.is_admin_panel_login == 'true'" :href="(AUTH_USER.user_type == 'PCO') ? JS_APP_URL + '/sra-only-full-upgrade' : 'javascript:void(0)'">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard" :class="{ 'not-allowed': (AUTH_USER.user_type != 'PCO') }"/>
                    </a>
                    <a v-else-if="AUTH_USER.partner_reseller_id != null && this.AUTH_USER.is_admin_panel_login == 'false'" @click="showUpgradeRestrictionModalToggle">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard"/>
                    </a>
                  </div>
                </div>
              </div>
              <!-- policies -->
              <div class="location-card-row py8" v-if="AUTH_USER.is_sra_user == 0">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="(!isModuleLocked('policy', location)) ? JS_APP_URL + '/procedures-policies-forms/' + encryption(location.id) : 'javascript:void(0)'"
                        :class="{'text-locked': isModuleLocked('policy', location), 'ds-btn-policy-procedure': !isModuleLocked('policy', location)}">Policies
                        &amp; Procedures</a>
                      <span
                        :class="{'notification-dot': notificationModuleStatus('procedures-policies-forms', location.notification)}"></span>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      Your organization's HIPAA playbook
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div class="
                            location-select-user-link
                            font-16 font_semibold
                            blueog--text
                        " v-if="!isModuleLocked('policy', location) && location.policy_last_updated">
                      <span class="location-item-gray-text font-11 font-italic font_light no-hover">Last
                        Updated:</span><br />
                      {{
                      dateFormat(
                      location.policy_last_updated
                      )
                      }}
                    </div>

                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-2 px-10 text-center"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <div class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center
                        ">
                      <button type="button" class="hipaa-training-book-btn">
                        <a :href="(!isModuleLocked('policy', location)) ? JS_APP_URL + '/procedures-policies-forms/' + encryption(location.id) : 'javascript:void(0)'"
                          :class="{'ds-btn-policy-procedure': !isModuleLocked('policy', location)}">
                          <img :src="JS_APP_URL + '/images/files.svg'" alt="" title=""
                            :class="{'img-locked': isModuleLocked('policy', location)}" />
                        </a>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="location-card-row py8" v-else-if="AUTH_USER.is_sra_user == 1">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a href="javascript:void(0)"
                        class="text-locked ds-btn-policy-procedure">Policies
                        &amp; Procedures</a>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      Your organization's HIPAA playbook
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-2 px-10 text-center"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <a v-if="AUTH_USER.partner_reseller_id == null || this.AUTH_USER.is_admin_panel_login == 'true'" :href="(AUTH_USER.user_type == 'PCO') ? JS_APP_URL + '/sra-only-full-upgrade' : 'javascript:void(0)'">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard" :class="{ 'not-allowed': (AUTH_USER.user_type != 'PCO') }"/>
                    </a>
                    <a v-else-if="AUTH_USER.partner_reseller_id != null && this.AUTH_USER.is_admin_panel_login == 'false'" @click="showUpgradeRestrictionModalToggle">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard"/>
                    </a>
                  </div>
                </div>
              </div>
              <!-- HIPAA logs -->
              <div class="location-card-row py8" v-if="AUTH_USER.is_sra_user == 0">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a :href="(!isModuleLocked('hipaa_logs', location)) ? JS_APP_URL + '/hipaa-logs/'+encryption(location.id) + '/breachlog' : 'javascript:void(0)'"
                        :class="{'text-locked' : isModuleLocked('hipaa_logs', location), 'ds-btn-hipaa-logs': !isModuleLocked('hipaa_logs', location)}">HIPAA
                        Logs</a>
                      <span
                        :class="{'notification-dot': notificationModuleStatus('hipaa-logs', location.notification)}"></span>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      View and update your access log or submit a new breach log
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                    <div class="
                            location-select-user-link
                            font-16 font_semibold
                            blueog--text
                        " v-if="!isModuleLocked('hipaa_logs', location) && location.hipaa_log_last_updated">
                      <span class="location-item-gray-text font-11 font-italic font_light no-hover">Last
                        Updated:</span><br />
                      {{
                      dateFormat(
                      location.hipaa_log_last_updated
                      )
                      }}
                    </div>

                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-2 px-10 text-center"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <div class="
                            location-last-column-wrapper
                            d-inline-block
                            text-center
                        ">
                      <button type="button" class="osha-training-book-btn">
                        <a :href="(!isModuleLocked('hipaa_logs', location)) ? JS_APP_URL + '/hipaa-logs/'+encryption(location.id) + '/breachlog' : 'javascript:void(0)'"
                          :class="{'ds-btn-hipaa-logs' : !isModuleLocked('hipaa_logs', location)}">
                          <img :src="JS_APP_URL + '/images/log-file.svg'" alt="" title=""
                            :class="{'img-locked' : isModuleLocked('hipaa_logs', location)}" />
                        </a>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="location-card-row py8" v-else-if="AUTH_USER.is_sra_user == 1">
                <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-12 col-lg-7 col-xl-7 px-10" :class="{ 'split-colum-user': is_grid_view }">
                    <span class="font-18 font_semibold location-card-title mr6">
                      <a href="javascript:void(0)"
                        class="text-locked ds-btn-hipaa-logs">HIPAA
                        Logs</a>
                    </span>
                    <span class="
                            location-item-gray-text location-description-text
                            font-12 font-italic no-hover ml10
                        " :class="{ 'd-xl-none': is_grid_view }">
                      View and update your access log or submit a new breach log
                    </span>
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-3 px-10 text-center"
                    :class="{ 'split-colum-locked': is_grid_view }">
                  </div>
                  <div class="col-12 col-md-6 col-lg-2 col-xl-2 px-10 text-center"
                    :class="{ 'split-colum-buttons': is_grid_view }">
                    <a v-if="AUTH_USER.partner_reseller_id == null || this.AUTH_USER.is_admin_panel_login == 'true'" :href="(AUTH_USER.user_type == 'PCO') ? JS_APP_URL + '/sra-only-full-upgrade' : 'javascript:void(0)'">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard" :class="{ 'not-allowed': (AUTH_USER.user_type != 'PCO') }"/>
                    </a>
                    <a v-else-if="AUTH_USER.partner_reseller_id != null && this.AUTH_USER.is_admin_panel_login == 'false'" @click="showUpgradeRestrictionModalToggle">
                      <img  :src="JS_APP_URL + '/images/upgrade.svg'" alt="" title="" class="mx-auto cursor-pointer upgrade-icon-dashboard"/>
                    </a>
                  </div>
                </div>
              </div>
              <!-- delete location -->
              <div class="text-center pt20 relative location-card-bottom-div">
                <span class="bottom-noti-link-wrapper">
                  <a :href="JS_APP_URL + '/notification/' + encryption(location.id)"
                    class="font-14 font_semibold green--text bottom-noti-link hover-underline-animation"
                    :class="{ 'bottom-noti-link-split': is_grid_view }">
                    See All Notifications
                  </a>
                </span>
                <!-- <button title="Location remove feature is not available as of now. Please contact our support team for more details." disabled="disabled" type="button" class="delete-location-btn text-center">
                    <img
                        :src="JS_APP_URL + '/images/bin.svg'"
                        alt=""
                        title=""
                        class="mlr-auto"
                    />
                    </button> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-if="!is_full_page_loader_shown && locations.length === 0">
      <div class="user-detail-text font-14 gray_checkmark--text text-center">
        <no-data-icon></no-data-icon>
        <div class="font-14 text-center blueog--text">
          No location(s) available.
        </div>
      </div>
    </div>
    <InfiniteLoading @infinite="getLocations" />
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    <select-hco v-if="show_hco_popup" :location_details="location_details_for_pop" :user_list="user_list_for_hco"
      :location_limit_count="location_limit_count" @update-hco="updateHCO" @close-model="selectHCOToggle" />

    <play-explainer-video-modal v-if="play_video_modal == true" :video_file="video_file"
      :video_caption_file="video_caption_file" @close-model="PlayExplainerVideoModalToggle"></play-explainer-video-modal>
    <show-upgrade-restriction-modal
        v-if="is_upgrade_restriction_modal_shown"
        @close-model="showUpgradeRestrictionModalToggle"        >
    </show-upgrade-restriction-modal>
  </div>
</template>

<script>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import moment from "moment";
import dashboardFilter from "./dashbaordFilter.vue";
import fullPageLoader from "../common/fullPageLoader.vue";
import selectAccountUser from "./selectAccountUser.vue";
import selectHco from "./selectHCO.vue";
import noDataIcon from "../common/icons/noDataIcon.vue";
import RadialProgressBar from "vue3-radial-progress";
import _ from 'lodash';
import InfiniteLoading from "v3-infinite-loading";
import explainerVideoIcon from "../common/icons/explainerVideoIcon.vue";
import playExplainerVideoModal from "../common/includes/playExplainerVideoModal.vue";
import showUpgradeRestrictionModal from "../common/includes/showUpgradeRestrictionModal.vue";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      locations: [],
      page: 1,
      total_page: 1,
      busy: false,
      per_page: 6,
      is_grid_view: true,
      location_nickname_filter: [],
      is_full_page_loader_shown: false,
      show_account_user_popup: false,
      location_details_for_pop: "",
      show_hco_popup: false,
      query_param: "",
      refreshDashboardFilter: 0,
      locations_nick_name_list: [],
      all_hco_list_data: [],
      continue_start_color_outer: "#C72121",
      inner_stroke_color: "#ADB4BB",
      AUTH_USER: AUTH_USER,
      notification_redirect_url_array: ['company', 'security-risk-analysis', 'scorecard', 'disaster-recovery-plan', 'ongoing-compliance', 'training', 'procedures-policies-forms', 'hipaa-logs'],
      value: {},
      user_list_for_hco:[],
      video_file: "hce_explainer_dashboard_final.mp4",  
      video_caption_file: "hce_explainer_dashboard_final.vtt",  
      account_user_list:[],
      play_video_modal: false,
      is_upgrade_restriction_modal_shown: false,
    };
  },
  props: {
    location_limit_count: {
      type: Number,
      default: () => 0
    }
  },

  components: {
    dashboardFilter,
    fullPageLoader,
    selectAccountUser,
    selectHco,
    noDataIcon,
    RadialProgressBar,
    InfiniteLoading,
    explainerVideoIcon,
    playExplainerVideoModal,
    showUpgradeRestrictionModal
  },
  mounted() {
    if(this.AUTH_USER.dashboard_view == 'grid'){
      this.is_grid_view = true
    }
    if(this.AUTH_USER.dashboard_view == 'list'){
      this.is_grid_view = false
    }
    this.getLocationsNickname();
    this.getAllSelectedHCOUser();
  },
  directives: {},
  methods: {
    PlayExplainerVideoModalToggle() {
      if (this.play_video_modal == true) {
        this.play_video_modal = false;
      } else {
        this.play_video_modal = true;
      }
    },
    isModuleLocked(module_name, location_data){
      if(module_name == 'company' || module_name == 'employee' || module_name == 'student'){
        return (location_data.hipaa_compliance_officer)?false:true
      }
      if(module_name == 'training') {
        return (location_data.hipaa_compliance_officer && location_data.sra_module_completed && location_data.sra_module_completed.is_completed && location_data.active_employee_primary_work_location_count > 0)?false:true
      }
      if(module_name == 'disaster_recovery_plan' || module_name == 'hipaa_logs'){
        return (location_data.hipaa_compliance_officer && location_data.company_module_completed_count == 1 && location_data.sra_module_completed && location_data.sra_module_completed.is_completed && (location_data.employee_primary_work_location.length > 0 || location_data.employee_secondary_work_location.length > 0))?false:true
      }
      if(module_name == 'sra'){
        return (location_data.hipaa_compliance_officer && location_data.company_module_completed_count == 1)?false:true
      }
      if(module_name == 'scorecard' || module_name == 'ongoing'){
        return (location_data.hipaa_compliance_officer && location_data.company_module_completed_count == 1 && location_data.sra_module_completed && location_data.sra_module_completed.is_completed)?false:true
      }
      if(module_name == 'businessassociates' || module_name == 'policy'){
        return (location_data.hipaa_compliance_officer && location_data.company_module_completed_count == 1 && location_data.sra_module_completed && location_data.sra_module_completed.is_completed && location_data.disaster_recovery_plan_module_completed_count == 1 &&(location_data.employee_primary_work_location.length > 0 || location_data.employee_secondary_work_location.length > 0))?false:true
      }
      return true
    },
    changeLocationView(view_type){
      if((this.is_grid_view && view_type == 'grid') || (!this.is_grid_view && view_type == 'list')){
        return false;
      }
      NProgress.start();
      axios
        .post(JS_APP_URL + "/dashboard/change-dashboard-view",{
          dashboard_view:view_type,
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
              toastr.error(response["data"]["message"], "Error");
          } else {
            this.is_grid_view = (view_type == 'grid')?true:false;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        })
    },
    get_sra_og_progress_color(percentage){
      if(percentage <= 69){
        return "#C72121";
      }else if(percentage > 69 && percentage <= 89){
        return "#FAC224";
      }else{
        return "#7FC361";
      }
    },
    dateFormat(date) {
      return moment(date).format("MM/DD/YYYY");
    },
    getLocations() {
      if (this.page <= this.total_page && this.busy != true) {
        this.is_full_page_loader_shown = true;
        this.busy = true;
        axios
          .get(
            JS_APP_URL +
              "/dashboard/get-locations-list?page=" +
              this.page + '&per_page='+this.per_page +
              this.query_param
          )
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              let data = response.data.data;
              this.locations.push(...data.location_list.data);
              this.total_page = data.location_list.last_page;
              this.page = this.page + 1;
              this.busy = false;
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            this.is_full_page_loader_shown = false;
          });
      }
    },

    getLocationsBySeachValue(query_param) {
      this.total_page = 1;
      this.page = 1;
      this.locations = [];
      this.query_param = query_param;
      this.getLocations();
    },

    getLocationsReload(is_hco_update = false) {
      this.total_page = 1;
      this.page = 1;
      this.locations = [];
      this.getLocations();
      if (is_hco_update) {
        this.getAllSelectedHCOUser();
      }
    },

    selectHCOToggle(status = true, location = "") {
      if(status == true) {
        this.location_details_for_pop = location;
        this.user_list_for_hco = [];
        this.getUserListForHCO();
      } else {
        this.show_hco_popup = status;
      }
    },

    getLocationsNickname() {
      axios
        .get(JS_APP_URL + "/general/get-assigned-location-list")
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            let data = response.data.data;
            this.locations_nick_name_list = data;
            if (this.locations_nick_name_list.length == 1) {
                this.is_grid_view = false;
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },

    getAllSelectedHCOUser() {
      NProgress.start();
      axios
        .get(JS_APP_URL + "/dashboard/get-all-selected-hco-user")
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            let data = response.data.data;
            this.all_hco_list_data = data.account_user;
            if (data.user) {
              this.all_hco_list_data.push(data.user);
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        });
    },
    completeNotificationStatus(id, index){
      NProgress.start();
      axios
        .post(JS_APP_URL + "/notification/change-notification-status",{
          location_notification_id:id,
          status: 'complete',
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
              toastr.error(response["data"]["message"], "Error");
          } else {
            this.locations[index].open_notifications_count = response["data"]["data"].length
            this.locations[index].notification = response["data"]["data"]
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        })
    },
    notificationRedirectUrl(url,location_id, notification) {
      if(this.notification_redirect_url_array.includes(url)) {
        window.location = JS_APP_URL+'/'+url+'/'+this.encryption(location_id);
      } else if(url == 'student_training') {
        let redirect_url = JS_APP_URL+'/training/'+this.encryption(location_id)+'/'+url;
        window.location = redirect_url;
      } else{
        if(url != '#'){
          window.location = JS_APP_URL+'/'+url;
        }
      }
    },
    notificationModuleStatus(moduleString, notification) {
      let check_module_notification = _.find(notification, (element) => {
        return element.notification.redirect_url == moduleString;
      });
      if(typeof check_module_notification === "undefined"){
        return false
      }else{
        return true
      }
    },
    encryption(params){
      var encoded = btoa(params);
      return encoded;
    },

    getAccountUserList(){
        NProgress.start();
        axios
        .get(JS_APP_URL + "/dashboard/account-user-list")
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            let data = response.data.data;
            this.account_user_list = data;
            this.show_account_user_popup = true;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
        })
        .then(() => {
          NProgress.done();
        });
    },
    getReplacedTitle(each_noti) {
      if (each_noti.notification.code == 'HCE-AN15') {
        return each_noti.notification.title.replace('{%EMPLOYEE_NAME%}', each_noti.other_details);
      } if(each_noti.notification.code == 'HCE-AN13') {
        return each_noti.notification.title.replace('{%VENDOR_NAME%}', each_noti.other_details);
      } else {
        return each_noti.notification.title;
      }
    },
    getUserListForHCO(){
      NProgress.start();
      axios
      .get(JS_APP_URL + "/dashboard/user-list-for-hco?location_id="+this.location_details_for_pop.id)
      .then((response) => {
        if (response["data"]["status"] == "Error") {
          if(response["data"]['data'].length > 0){
              toastr.error(response["data"]['data'].join('</br>'), "Error");
          }else{
              toastr.error(response["data"]["message"], "Error");
          }
        } else {
          let data = response.data.data;
          this.user_list_for_hco[0] = data.user;
          this.user_list_for_hco.push(...data.account_user)
          this.show_hco_popup = true;
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
      })
      .then(() => {
        NProgress.done();
      });
    },
    updateHCO(new_hco,notification,open_notifications_count,training_counts) {
        var index = _.findIndex(this.locations, (o) => {
            return o.id == new_hco.location_id
        })
        this.locations[index]['hipaa_compliance_officer'] = new_hco;
        this.locations[index]['notification'] = notification;
        this.locations[index]['open_notifications_count'] = open_notifications_count;
        this.locations[index]["training_counts"] = training_counts;
    },
    updateAccountUser(new_account_users) {
        var index = _.findIndex(this.locations, (o) => {
            return o.id == new_account_users.id
        });
        if (index !== -1) {
          this.locations[index] = new_account_users;
        }
    },
    showUpgradeRestrictionModalToggle(status = true) {
      this.is_upgrade_restriction_modal_shown = status;
    },
  },
};
</script>
