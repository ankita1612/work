<template>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" version="1.1" width="20" height="20" x="0" y="0" viewBox="0 0 481.882 481.882" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
<path xmlns="http://www.w3.org/2000/svg" style="" d="M60.235,28.913C60.235,12.943,73.178,0,89.148,0h212.028l120.471,101.195v351.774  c0,15.97-12.943,28.913-28.913,28.913H89.148c-15.97,0-28.913-12.943-28.913-28.913V28.913z" fill="#203c72" data-original="#ef5350" class=""/>
<path xmlns="http://www.w3.org/2000/svg" style="" d="M301.176,0v72.282c0,15.97,12.943,28.913,28.913,28.913h91.558" fill="#12213e" data-original="#d32f2f" class=""/>
<g xmlns="http://www.w3.org/2000/svg">
	<path class="pdf-text" style="" d="M150.904,305.536H139.61v34.643h-25.005v-104.38h32.986c28.469,0,44.732,11.144,44.732,34.04   C192.316,294.4,175.601,305.536,150.904,305.536z M147.893,253.568h-8.282v33.89h9.186c11.294,0,17.769-5.429,17.769-17.626   C166.566,258.846,160.392,253.568,147.893,253.568z" fill="#ffffff" data-original="#ffffff"/>
	<path class="pdf-text" style="" d="M231.77,340.179h-28.318v-104.38h26.511c26.82,0,52.412,8.584,52.412,51.674   C282.376,329.924,257.822,340.179,231.77,340.179z M233.57,253.869h-5.12v68.239h5.12c13.704,0,22.889-7.379,22.889-34.65   C256.474,259.607,246.679,253.869,233.57,253.869z" fill="#ffffff" data-original="#ffffff"/>
	<path class="pdf-text" style="" d="M325.888,253.568v27.422h36.45v17.92h-36.45v41.269h-25.156v-104.38h68.834l-2.56,17.769   L325.888,253.568L325.888,253.568z" fill="#ffffff" data-original="#ffffff"/>
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
</g></svg>

</template>

<script scoped>
export default {};
</script>
