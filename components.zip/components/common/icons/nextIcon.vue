<template>
	<svg id="svg2716" height="25" viewBox="0 0 6.3499999 6.3500002" width="25" xmlns="http://www.w3.org/2000/svg"><g id="layer1" transform="translate(0 -290.65)"><path id="path6684" d="m3.1662272 290.7244c-1.7147066 0-3.11143814 1.39673-3.11143814 3.11144 0 1.7147 1.39673154 3.10937 3.11143814 3.10937 1.7147064 0 3.1093709-1.39467 3.1093709-3.10937 0-1.71471-1.3946645-3.11144-3.1093709-3.11144zm.2578653 1.7849a.26460982.26460982 0 0 1 .1891358.0801l1.0588501 1.05885a.26460982.26460982 0 0 1 0 .3731l-1.0588501 1.05834a.26460982.26460982 0 1 1 -.375171-.37311l.6077149-.60719h-2.0040121a.2646485.2646485 0 0 1 0-.52917h2.0019451l-.6056479-.60565a.26460982.26460982 0 0 1 .1860352-.45527z" font-variant-ligatures="normal" font-variant-position="normal" font-variant-caps="normal" font-variant-numeric="normal" font-variant-alternates="normal" font-feature-settings="normal" text-indent="0" text-align="start" text-decoration-line="none" text-decoration-style="solid" text-decoration-color="rgb(0,0,0)" text-transform="none" text-orientation="mixed" white-space="normal" shape-padding="0" isolation="auto" mix-blend-mode="normal" solid-color="rgb(0,0,0)" solid-opacity="1" vector-effect="none" paint-order="stroke fill markers"/></g></svg>
</template>

<script scoped>
export default {};
</script>
