<template>
	<svg xmlns="http://www.w3.org/2000/svg" width="18.121" height="17.868" viewBox="0 0 18.121 17.868">
  <g id="search_1_" data-name="search (1)" transform="translate(-0.001 0.002)">
    <path id="Path_217"  data-name="Path 217" d="M294.16,288.216l.456.456.533.53.205.207,1.064-1.064-1.193-1.194Z" transform="translate(-283.499 -276.746)" fill="#5d6d7e"/>
    <path id="Path_218" data-name="Path 218" d="M340.076,335.92l3.671,3.67a1.525,1.525,0,1,1-2.156,2.156l-3.67-3.671Z" transform="translate(-326.072 -324.328)" fill="#fac224"/>
    <path id="Path_219" data-name="Path 219" d="M383.42,341.969h0l.3-.3,3.673,3.672a1.232,1.232,0,0,1,0,1.74.218.218,0,0,1-.15.061.21.21,0,0,1-.15-.359.809.809,0,0,0,0-1.143Z" transform="translate(-369.923 -329.87)" fill="#f9be0d"/>
    <path id="Path_220" data-name="Path 220" d="M329.5,329.623l2.156-2.156-.159-.161a.533.533,0,0,0-.755,0l-1.4,1.4a.532.532,0,0,0,0,.753Z" transform="translate(-317.649 -315.875)" fill="#373f43"/>
    <path id="Path_221" class="search-bg-path" data-name="Path 221" d="M43.824,53.487a5.654,5.654,0,1,0-5.654-5.654A5.654,5.654,0,0,0,43.824,53.487Z" transform="translate(-37.185 -41.234)" fill="#cee2f2"/>
    <path id="Path_222" class="search-round-path" data-name="Path 222" d="M122.554,64.85a.5.5,0,0,0-.445-.222,4.918,4.918,0,0,0-2.192.659.5.5,0,1,0,.5.862,3.956,3.956,0,0,1,1.75-.524.5.5,0,0,0,.468-.524A.473.473,0,0,0,122.554,64.85Z" transform="translate(-115.73 -62.867)" fill="#fff"/>
    <path id="Path_223" class="search-round-path" data-name="Path 223" d="M60.271,110.123a.525.525,0,0,0-.1-.109.5.5,0,0,0-.7.072,4.942,4.942,0,0,0-.739,4.984.5.5,0,1,0,.925-.378,3.96,3.96,0,0,1,.589-3.976A.5.5,0,0,0,60.271,110.123Z" transform="translate(-56.648 -106.501)" fill="#fff"/>
    <g id="layer1" transform="translate(0.001 -0.002)">
      <path id="path9585" class="search-round-path" d="M11.013,22.918a6.53,6.53,0,1,0,10.812-5.306l1-.192a.618.618,0,0,0-.181-1.223l-2.63.507a.619.619,0,0,0-.494.725l.5,2.577a.619.619,0,1,0,1.215-.232l-.239-1.25a5.283,5.283,0,1,1-3.785-1.287A.62.62,0,0,0,17.146,16a6.545,6.545,0,0,0-6.133,6.92Z" transform="translate(-11.001 -15.998)" fill="#373f43"/>
    </g>
  </g>
</svg>
</template>

<script scoped>
export default {};
</script>
