<template>
	<svg id="Layer_1" height="20" className="location-svg" viewBox="0 0 512 512" width="18" xmlns="http://www.w3.org/2000/svg" data-name="Layer 1"><path d="m256 512c-29.484-37.014-72.778-92.6-110.211-149.814-63.641-97.303-76.989-148.866-76.989-174.986 0-103.217 83.967-187.2 187.192-187.2s187.208 83.983 187.208 187.2c0 85.7-126.418 248.708-187.2 324.8zm116.312-324.8a116.318 116.318 0 1 0 -116.32 116.32 116.467 116.467 0 0 0 116.32-116.32z" fill-rule="evenodd"/></svg>
</template>

<script scoped>
export default {};
</script>
