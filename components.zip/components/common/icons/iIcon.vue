<template>
<svg xmlns="http://www.w3.org/2000/svg" width="7" height="28" viewBox="0 0 7 28">
  <g id="i_Icon" data-name="i Icon" transform="translate(-13.494 -4)">
    <text id="_" data-name="!" transform="translate(13.494 27)" fill="#373f43" font-size="28" font-family="ProximaNova-Semibold, Proxima Nova" font-weight="600"><tspan x="0" y="0">!</tspan></text>
  </g>
</svg>

</template>

<script scoped>
export default {};
</script>
