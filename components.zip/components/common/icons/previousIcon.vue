<template>
	<svg xmlns="http://www.w3.org/2000/svg"  version="1.1" width="20" height="20" x="0" y="0" viewBox="0 0 473.654 473.654"><g>
      <circle xmlns="http://www.w3.org/2000/svg" className="arrow-circle"  cx="236.827" cy="236.827" r="236.827" fill="#203c72" data-original="#4abc96" />
      <path xmlns="http://www.w3.org/2000/svg" className="arrow-path" d="M338.465,207.969c-43.487,0-86.975,0-130.459,0c11.08-11.08,22.161-22.161,33.241-33.245  c25.56-25.56-14.259-65.084-39.883-39.456c-27.011,27.011-54.018,54.022-81.029,81.033c-10.841,10.841-10.549,28.907,0.213,39.669  c27.011,27.007,54.018,54.018,81.029,81.025c25.56,25.56,65.084-14.259,39.456-39.883c-11.013-11.013-22.026-22.026-33.039-33.035  c43.357,0,86.713,0,130.066,0C374.283,264.077,374.604,207.969,338.465,207.969z" fill="#ffffff" data-original="#ffffff" />
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      <g xmlns="http://www.w3.org/2000/svg">
      </g>
      </g></svg>
</template>

<script scoped>
export default {};
</script>
