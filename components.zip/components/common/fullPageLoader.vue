<template>
	<div class="full-page-loader"></div>
</template>

<script scoped>

export default {
  data() {
    return {};
  },
  components: {},
  mounted() {},
  watch: {},
  computed: {},
  methods: {},
};
</script>
