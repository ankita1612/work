<template>
  <div class="mt-auto dark py20">
    <div class="footer-container container text-center flex items-center justify-center">
      <a :href="JS_WORDPRESS_URL" target="_blank" class="mr16"><img :src="JS_APP_URL + '/images/logo_footer.svg'" alt="" title="" class="logo"></a>
      <ul class="footer-nav font-14 white--text font_normal mb0">
        <li><span>COPYRIGHT © {{CURRENT_YEAR}} ABYDE</span></li>
        <li><a class="footer-link white--text" :href="(is_reseller == 'yes')?JS_WORDPRESS_URL + '/reseller-terms-and-conditions':JS_WORDPRESS_URL + '/terms-conditions'" target="_blank">TERMS &amp; CONDITIONS</a></li>
        <li><a class="footer-link white--text" :href="JS_WORDPRESS_URL + '/privacy-policy'" target="_blank">PRIVACY POLICY</a></li>
        <li><a class="footer-link white--text" :href="JS_WORDPRESS_URL + '/abyde-security-measures'" target="_blank">SECURITY MEASURES </a></li>
        <li><a class="footer-link white--text" :href="JS_WORDPRESS_URL + '/electronic-signature-terms-of-use'" target="_blank"> E-SIGNATURE TERMS</a></li>
      </ul>
    </div>
  </div>
</template>

<script scoped>
import moment from "moment";

export default {
  data() {
    return {
      CURRENT_YEAR: CURRENT_YEAR,
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  props: {
      is_reseller: {
          type: String,
          default: () => "no",
      },
  },
  components: {},
  mounted() {},
  watch: {},
  computed: {},
  methods: {},
};
</script>
