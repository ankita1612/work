<template>
<div class="main-wrapper">
  <div class="dashboard-header py20">
    <div class="container">
      <div class="flex items-center justify-between">
      <div class="mmenu_btn hidden-xl">
        <span></span>
        <span></span>
        <span></span>
      </div>
      <div class="logo-dashboard cursor-pointer">
        <a v-on:click="redirectAction"
          class="dashboard-logo-text font-43 blueog--text uppercase line-normal">
          HIPAA
          <span class="logo-small-text">FOR COVERED ENTITIES</span>
        </a>
      </div>
      <div class="hipaa-logo-wrapper hidden-sm cursor-pointer" v-bind:class="{ 'hipaa-logo-wrapper-reseller': JS_EMPLOYEE_DATA != null && JS_EMPLOYEE_DATA.user.partner_reseller_id != null }">
        <a v-on:click="redirectAction">
              <div v-if="JS_EMPLOYEE_DATA.user.partner_reseller_id != null && JS_EMPLOYEE_DATA.user.reseller.logo !== ''">
                <img :src="JS_APP_URL + '/images/partner/' + JS_EMPLOYEE_DATA.user.reseller.logo"
                  class="logo-center logo-center-reseller"
                  alt=""
                  title="">
              </div>
              <div v-else>
                <img
                  :src="JS_APP_URL + '/images/abyde_a_logo.svg'"
                  class="logo-center"
                  alt=""
                  title=""
                />
              </div>
        </a>
      </div>
      <div class="header-user-detail flex flex-wrap items-center">
        <div class="flex items-center ">
          <div v-if="JS_EMPLOYEE_DATA" class="header-user-info flex flex-col justify-end dark--text mr30 hidden-sm">
            <div class="header-user-name font-18 font_bold" :title="JS_EMPLOYEE_DATA.first_name + ' ' + JS_EMPLOYEE_DATA.last_name">
            {{JS_EMPLOYEE_DATA.first_name + " "+ JS_EMPLOYEE_DATA.last_name}}
          </div>
            <div class="font-12 font_normal text-right">
              Employee
            </div>
          </div>
          <a v-if="current_url[2] != 'agreement'" class="osha-portal-button text-center mr8" href="javascript:void(0)"  @click="employeePortalOshahcToggle()">
            <img :src="JS_APP_URL + '/images/abyde.svg'" class="osha-portal-button-img" alt="" title="" />
            <div class="font-16 blueog--text font_semibold osha-portal-button-text">OSHA HC</div>
          </a>
          <a v-if="current_url[2] != 'agreement'" class="employee-portal-logout text-center" :href="JS_APP_URL + '/employeeportal/logout'">
            <img :src="JS_APP_URL + '/images/padlock.svg'" class="employee-portal-logout-img" alt="" title="" />
            <div class="font-12 blue--text font_semibold osha-portal-button-text">Log Out</div>
          </a>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;

export default {
  data() {
    return {
      JS_EMPLOYEE_DATA: JS_EMPLOYEE_DATA,
      JS_APP_URL: JS_APP_URL,
      JS_OSHA_HC_APP_URL: JS_OSHA_HC_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      current_url: new URL(window.location.href).pathname.split("/")
    };
  },
  components: {},
  mounted() {},
  watch: {},
  computed: {},
  methods: {
    redirectAction(){
      window.location = JS_APP_URL + "/employeeportal/dashboard";
    },
    employeePortalOshahcToggle(){
      NProgress.start();
      axios
        .post(JS_OSHA_HC_APP_URL + "/employee-portal-osha-hc-toggle",{
            stripe_customer_id: this.JS_EMPLOYEE_DATA.user.stripe_customer_id,
            user_email: this.JS_EMPLOYEE_DATA.user.email,
            employee_email: this.JS_EMPLOYEE_DATA.email
        },{
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            common:{}
          },
          withCredentials: true
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
          } else {
            if(response["data"]['data']["is_user_found"] == 1){
              setTimeout(() => {
                window.location = response["data"]['data']["redirect_url"];
              }, 500);
            }else{
              toastr.error("We have not found your account for OSHA HC. Please contact your Primary Compliance Officer.", "Error");
            }
          }
        })
        .catch((error) => {
            toastr.error('Portal switching failed!', "Error");
        })
        .then(() => {
          NProgress.done();
        });
    },
  },
};
</script>
