<template>
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper animate__animated animate__zoomIn">
        <div class="modal-container">
          <button type="button" v-on:click="closeModal" class="cursor-pointer modal-close">
            <close-icon></close-icon>
          </button>
          <div class="text-center mlr-auto mb20">
            <img :src="JS_APP_URL + '/images/abyde_a.svg'" alt="" title="" class="warning-icon-modal" />
          </div>
          <h2
            class="
              font-24 font_semibold blueog--text line-normal text-center mb10
            "
          >
            <span v-if="AUTH_USER.partner_reseller_id == null || (AUTH_USER.partner_reseller_id != null && AUTH_USER.is_admin_panel_login == 'true')">Never stress over HIPAA and OSHA again!</span>
            <span v-else>Add New Product</span>
          </h2>
          <p class="text-center font-16 gray_checkmark--text line-normal mb20" v-if="AUTH_USER.partner_reseller_id == null || (AUTH_USER.partner_reseller_id != null && AUTH_USER.is_admin_panel_login == 'true')">You're already experiencing stress-free HIPAA so why not enjoy the same peace of mind in your OSHA compliance program too? Click the button below to check out your subscription plan and get started!</p>
          <p class="text-center font-16 gray_checkmark--text line-normal mb20" v-else>Please contact <a :href="'mailto:' + AUTH_USER.reseller.email" class="blueog--text">{{ AUTH_USER.reseller.email }}</a> to get a subscription quote.</p>
          <div class="flex flex-wrap items-center justify-center mb20 mt20" v-if="AUTH_USER.partner_reseller_id == null || (AUTH_USER.partner_reseller_id != null && AUTH_USER.is_admin_panel_login == 'true')">
              <button v-on:click="scheduleADemo()" type="button" class="btn-primary btn-width-136 mx5 px30 mt-xs-20">SCHEDULE A DEMO</button>
              <button v-on:click="addOSHAHCProduct()" type="button" class="btn-primary btn-width-136 mx5 px30 mt-xs-20">SEE PRICING</button>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import closeIcon from '../../common/icons/closeIcon.vue'

export default {
  emits: ["close-model", "show-additional-products"],
  components:{closeIcon},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_OSHA_HC_APP_URL: JS_OSHA_HC_APP_URL,
      JS_CALENDLY_URL : JS_CALENDLY_URL,
      JS_WORDPRESS_URL : JS_WORDPRESS_URL,
      AUTH_USER: AUTH_USER
    };
  },
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
    addOSHAHCProduct(){
       this.$emit("close-model", false);
       this.$emit("show-additional-products", false);
    },
    scheduleADemo(){
      window.open(JS_WORDPRESS_URL + '/osha-resources', '_blank');
    }
  },
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.is_submit_btn_diabled) {
        this.$emit("close-model", false);
      }
    });
  },
};
</script>
