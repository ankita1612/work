<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container">
            <button type="button" v-on:click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>         
            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb10">
              Upgrade
            </h2>          
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">
              Please contact <a :href="'mailto:' + AUTH_USER.reseller.email" class="blueog--text">{{ AUTH_USER.reseller.email }}</a> to get an upgrade quote            
            </p>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from '../../common/icons/closeIcon.vue'

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      AUTH_USER: AUTH_USER
    };
  },
  emits: ["close-model"],
  components:{closeIcon},
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
