<template>
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper animate__animated animate__zoomIn">
        <div class="modal-container">
          <form @submit.prevent="activateHIPAAEmergencySubmit">
          <button v-if="!disable_help_emergency_submit_btn" type="button" v-on:click="closeModal" class="cursor-pointer modal-close">
            <close-icon></close-icon>
          </button>
          <div class="text-center mlr-auto mb20">
            <img :src="JS_APP_URL + '/images/alaram-light.svg'" alt="" title="" class="warning-icon-modal" />
          </div>
          <div class="flex items-center justify-center flex-wrap">
            <h2
              class="
                font-24 font_semibold blueog--text line-normal text-center mb10
              "
            >
              Help! HIPAA Emergency!
            </h2>
            <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml6 mb10 mb-md-5 mb-sm-5">
              <button @click.prevent="PlayExplainerVideoModalToggle('yes')" class="cursor-pointer svg-icon-height dashboard-video-icon mt4">
                <explainer-video-icon></explainer-video-icon>
              </button>
              <template #popper>
                Video Guide
              </template>
            </VTooltip>
          </div>
          <p v-if="all_location_list.length == 1" class="text-center font-16 gray_checkmark--text line-normal mb20">Has your organization been visited or contacted by HIPAA enforcement? Activate your HIPAA Protection Program and get immediate support!</p>
          <p v-if="all_location_list.length > 1" class="text-center font-16 gray_checkmark--text line-normal mb30">Has your organization been visited or contacted by HIPAA enforcement? Select the affected location below to activate your HIPAA Protection Program and get immediate support!</p>
          <div v-if="all_location_list.length > 1" class="form-group mb-0 mlr-auto location-dropdon" :class="{ 'form-group--error': v$.selected_access_locations.$error }">
              <multiselect
              v-model="v$.selected_access_locations.$model"
              tag-placeholder=""
              placeholder=""
              label="location_nickname"
              track-by="id"
              :options="all_location_list"
              :multiple="true"
              :close-on-select="false"
              :showLabels="false"
              :disabled="disable_help_emergency_submit_btn"
              :taggable="false">
                <template #noResult>
                    <div class="multiselect__noResult text-center">
                    No results found
                    </div>
                </template>
                <template #selection>
                    <div class="multiselect__tags-wrap" v-if="selected_access_locations.length > 1">
                    <span class="multiselect__tag">
                        <span>{{ selected_access_locations.length }} Locations Selected</span>
                    </span>
                    </div>
                </template>
              </multiselect>
              <label class="label label-select" :class="{ 'label-float': (selected_access_locations.length > 0) }">Location(s)</label>
              <div v-if="v$.selected_access_locations.$errors.length > 0">
                <div class="form-error-text">
                    {{ v$.selected_access_locations.$errors[0].$message }}
                </div>
              </div>
          </div>
          <div class="flex flex-wrap items-center justify-center mb20 mt20">
              <button :disabled="disable_help_emergency_submit_btn" type="submit" class="btn-primary btn-width-136 mx5 px30 mt-xs-20">ACTIVATE!</button>
          </div>
          <p class="text-center font-16 gray_checkmark--text line-normal mb0 font-italic">Prefer to reach out to our team directly?</p>
          <p class="text-center font-16 gray_checkmark--text line-normal mb5 font-italic">Give us a call at <a class="blueog--text" :href="'tel:'+SUPPORT_PHONE_NUMBER">{{SUPPORT_PHONE_NUMBER_DISPLAY}} x2</a></p>
          </form>
        </div>
      </div>
    </div>
  </transition>
  <play-explainer-video-modal v-if="play_video_modal == true" :video_file="video_file"
      :video_caption_file="video_caption_file" @close-model="PlayExplainerVideoModalToggle"></play-explainer-video-modal>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { requiredIf, helpers } from "@vuelidate/validators";
import closeIcon from '../../common/icons/closeIcon.vue';
import explainerVideoIcon from "../icons/explainerVideoIcon.vue";
import playExplainerVideoModal from "../includes/playExplainerVideoModal.vue";

export default {
  props: {
    all_location_list:{
      type: Array,
      default: () => []
    }
  },
  components:{
    closeIcon,
    explainerVideoIcon,
    playExplainerVideoModal
  },
  data() {
    return {
      selected_access_locations: [],
      disable_help_emergency_submit_btn: false,
      JS_APP_URL: JS_APP_URL,
      SUPPORT_PHONE_NUMBER: SUPPORT_PHONE_NUMBER,
      SUPPORT_PHONE_NUMBER_DISPLAY: SUPPORT_PHONE_NUMBER_DISPLAY,
      video_file: "hce_explainer_help_button_final.mp4",  
      video_caption_file: "hce_explainer_help_button_final.vtt",  
      play_video_modal: false,
    };
  },
  emits: ["close-model"],
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    return {
        selected_access_locations: {
            requiredIf: helpers.withMessage("Please select location(s)",
                requiredIf(() => {
                    return (this.all_location_list.length > 1)
                })),
        },
    };
  },
  methods: {
    PlayExplainerVideoModalToggle() {
      if (this.play_video_modal == true) {
        this.play_video_modal = false;
      } else {
        this.play_video_modal = true;
      }
    },
    closeModal() {
      this.$emit("close-model", false);
    },
    activateHIPAAEmergencySubmit(){
        this.v$.$touch();
        if (!this.v$.$invalid) {
          NProgress.start();
          this.disable_help_emergency_submit_btn = true;
          axios
          .post(JS_APP_URL + "/dashboard/help-hipaa-emergency", {
              selected_access_locations: (this.all_location_list.length > 1)?this.selected_access_locations:this.all_location_list
          })
          .then((response) => {
              if (response["data"]["status"] == "Error") {
                  if(response["data"]['data'].length > 0){
                      toastr.error(response["data"]['data'].join('</br>'), "Error");
                  }else{
                      toastr.error(response["data"]["message"], "Error");
                  }
              } else {
                  toastr.success(response["data"]["message"], "Success");
                  setTimeout(() => {
                      this.$emit("close-model", false);
                  }, 100);
              }
          })
          .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                  window.location = JS_APP_URL + "/login";
              }
          })
          .then(() => {
              NProgress.done();
              this.disable_help_emergency_submit_btn = false;
          });
        }
    }
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.disable_help_emergency_submit_btn) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
