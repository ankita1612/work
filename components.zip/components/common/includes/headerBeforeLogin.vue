<template>
	<div class="header-container container flex items-center flex-wrap py18">
    <a :href="JS_WORDPRESS_URL" target="_blank" class="logo-wrapper" >
      <img :src="JS_APP_URL + '/images/logo.svg'" alt="" title="" class="logo">
    </a>
    <div class="header-links flex-wrap flex  font_normal ml50">
      <a href="javascript:void(0)" class="header-link-item items-center relative px55 mt4 active" :class="{'header-link-item-signup' : is_signup_page}">
        <div class="relative">
          <!-- <span class="header-text-small font-10 gray_checkmark--text">For</span> -->
          <div class="header-text-big font-24 gray_checkmark--text uppercase">HIPAA CE</div>
        </div>
      </a>
      <a :href="JS_OSHA_HC_APP_URL + '/login'" class="header-link-item items-center relative relative px55 mt4" :class="{'header-link-item-signup' : is_signup_page}">
        <div class="relative">
          <!-- <span class="header-text-small font-10 gray_checkmark--text">For</span> -->
          <div class="header-text-big font-24 gray_checkmark--text uppercase">OSHA HC</div>
        </div>
      </a>
        <a :href="HIPAA_BA_APP_URL + '/login'" class="header-link-item items-center relative relative px55 mt4" :class="{'header-link-item-signup' : is_signup_page}">
        <div class="relative">
            <!-- <span class="header-text-small font-10 gray_checkmark--text">For</span> -->
            <div class="header-text-big font-24 gray_checkmark--text uppercase">HIPAA BA</div>
        </div>
        </a>
    </div>
  </div>
</template>

<script scoped>

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      JS_OSHA_HC_APP_URL: JS_OSHA_HC_APP_URL,
      HIPAA_BA_APP_URL: HIPAA_BA_APP_URL,
      is_signup_page: false
    };
  },
  components: {},
  mounted() {
    if (window.location.href.indexOf("signup") > -1) {
      this.is_signup_page = true
    }
  },
  watch: {},
  computed: {},
  methods: {},
};
</script>
