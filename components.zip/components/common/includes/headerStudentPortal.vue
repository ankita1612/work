<template>
    <div class="main-wrapper">
        <div class="dashboard-header py21">
            <div class="container">
                <div class="flex items-center justify-between">
                    <div class="mmenu_btn hidden-xl">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div class="logo-dashboard cursor-pointer">
                        <a v-on:click="redirectAction" class="dashboard-logo-text font-43 blueog--text uppercase line-normal">
                            HIPAA
                            <span class="logo-small-text">FOR COVERED ENTITIES</span>
                        </a>
                    </div>
                    <div class="hipaa-logo-wrapper hidden-sm cursor-pointer" v-bind:class="{ 'hipaa-logo-wrapper-reseller': JS_STUDENT.user.partner_reseller_id != null }">
                        <a v-on:click="redirectAction">
                            <div  v-if="JS_STUDENT.user.partner_reseller_id != null && JS_STUDENT.user.reseller.logo !== ''">
                                <img :src="JS_APP_URL + '/images/partner/' + JS_STUDENT.user.reseller.logo" class="logo-center logo-center-reseller" alt="" title="" />
                            </div>
                            <div v-else>
                                <img :src="JS_APP_URL + '/images/abyde_a_logo.svg'" class="logo-center" alt="" title="" />
                            </div>
                        </a>
                    </div>
                    <div class="header-user-detail flex flex-wrap items-center">
                        <div class="flex items-center ">
                            <div class="header-user-info flex flex-col justify-end dark--text mr30 hidden-sm">
                                <div class="header-user-name font-18 font_bold" :title="JS_STUDENT.first_name + ' ' + JS_STUDENT.last_name">
                                    {{JS_STUDENT.first_name + " "+ JS_STUDENT.last_name}}
                                </div>
                                <div class="font-12 font_normal text-right">
                                    Student
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            JS_STUDENT: JS_STUDENT,
            JS_TRAINING_INVITE: JS_TRAINING_INVITE,
            JS_APP_URL: JS_APP_URL,
            JS_WORDPRESS_URL: JS_WORDPRESS_URL,
        };
    },
    components: {},
    mounted() {},
    watch: {},
    computed: {},
    methods: {
        redirectAction(){
            location.reload();
        }
    },
}
</script>