<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask modal-scrollable">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container">
            <button type="button" v-on:click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb20">
              <img :src="JS_APP_URL + '/images/header_pop_contact.png'" alt="" title="" class="warning-icon-modal" style="max-width:75px" />
            </div>
            <h2
              class="
                font-24 font_semibold blueog--text line-normal text-center mb10
              "
            >
              Support
            </h2>
            <p v-if="AUTH_USER.is_sra_user == 0" class="text-center font-14 gray_checkmark--text line-normal mb15">
              For general questions, live chat, and quick answers, try <a href="javascript:Intercom('show');" class="blueog--text">Intercom.</a><br>Or call <a href="tel:800.594.0883" class="blueog--text">800.594.0883 x2</a> to reach our industry-leading customer success team.
            </p>
            <p v-else class="text-center font-16 gray_checkmark--text line-normal mb15">
              For more information on upgrading to our full-featured platform call <a href="tel:800.594.0883" class="blueog--text">800.594.0883 x2</a> or email (<a href="mailto:support@abyde.com" class="blueog--text">support@abyde.com</a>) to get in touch with our industry-leading customer success team.
            </p>
            <p v-if="AUTH_USER.is_sra_user == 0" class="text-center font-14 gray_checkmark--text line-normal mb20">
                If you would like to file a support ticket, fill out the fields below.<br> You will receive an email confirmation and we will respond as soon as possible.
            </p>

            <div v-if="AUTH_USER.is_sra_user == 0">
              <form ref="ticketForm" @submit.prevent="submitForm"
                  action="https://webto.salesforce.com/servlet/servlet.WebToCase?encoding=UTF-8&orgId=00D0b000000wo2y"
                  method="POST" class="submit-ticket-grid mlr-auto">
                  <input type=hidden name="orgid" v-model="orgid">
                  <input type=hidden name="retURL" v-model="retURL">

                  <div class="submit-ticket-label self-center font-14 font_semibold blueog--text">Company
                  </div>
                  <div class="form-group mb-0" :class="{ 'form-group--error': v$.company.$error }">
                      <input class="form-input" :class="{ 'form-error': v$.company.$error }" id="company"
                          type="text" name="company" v-model.trim="v$.company.$model">
                      <label class="label" :class="{ 'label-float': v$.company.$model }">Company</label>
                      <div v-if="v$.company.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.company.$errors[0].$message }}
                          </div>
                      </div>
                  </div>
                  <div class="submit-ticket-label self-center font-14 font_semibold blueog--text">Contact Name
                  </div>
                  <div class="form-group mb-0" :class="{ 'form-group--error': v$.name.$error }">
                      <input class="form-input" id="name" type="text" name="name"
                          :class="{ 'form-error': v$.name.$error }" v-model.trim="v$.name.$model">
                      <label class="label" :class="{ 'label-float': v$.name.$model }">Contact Name</label>
                      <div v-if="v$.name.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.name.$errors[0].$message }}
                          </div>
                      </div>
                  </div>

                  <div class="submit-ticket-label self-center font-14 font_semibold blueog--text">Email</div>
                  <div class="form-group mb-0" :class="{ 'form-group--error': v$.email.$error }">
                      <input class="form-input" id="email" type="text" name="email"
                          :class="{ 'form-error': v$.email.$error }" v-model.trim="v$.email.$model">
                      <label class="label" :class="{ 'label-float': v$.email.$model }">Email</label>
                      <div v-if="v$.email.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.email.$errors[0].$message }}
                          </div>
                      </div>
                  </div>

                  <div class="submit-ticket-label self-center font-14 font_semibold blueog--text">Phone</div>
                  <div class="form-group mb-0" :class="{ 'form-group--error': v$.phone.$error }">
                      <input v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent
                          class="form-input" id="phone" type="text" name="Account_Phone__c"
                          :class="{ 'form-error': v$.phone.$error }" v-model.trim="v$.phone.$model">
                      <label class="label" :class="{ 'label-float': v$.phone.$model }">Phone</label>
                      <div v-if="v$.phone.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.phone.$errors[0].$message }}
                          </div>
                      </div>
                  </div>

                  <div class="submit-ticket-label self-center font-14 font_semibold blueog--text">Issue Type</div>
                  <div class="form-group mb-0" :class="{ 'form-group--error': v$.selected_site_submission_type.$error }">
                      <multiselect 
                          v-model="selected_site_submission_type" 
                          :options="site_submission_type_list" 
                          :close-on-select="true"
                          tag-placeholder="" 
                          placeholder="" 
                          label="name" 
                          track-by="id" 
                          :searchable="false"
                          :showLabels="false" 
                          :taggable="false"
                          >
                          <template #noResult>
                              <div class="multiselect__noResult text-center">
                                  No results found
                              </div>
                          </template>
                      </multiselect>
                      <input type="hidden" name="00NQo00000PSJVx" :value="selected_site_submission_type?.name || ''" />
                      <label class="label label-select"
                          :class="{ 'label-float': (selected_site_submission_type != null) }">Type</label>
                      <div v-if="v$.selected_site_submission_type.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.selected_site_submission_type.$errors[0].$message }}
                          </div>
                      </div>
                  </div>


                  <div class="submit-ticket-label self-center font-14 font_semibold blueog--text">Product(s)
                      Affected</div>
                  <div class="form-group mb-0" :class="{ 'form-group--error': v$.selected_product.$error }">
                      <multiselect 
                          v-model="selected_product" 
                          :options="product_list" 
                          :close-on-select="true"
                          tag-placeholder="" 
                          placeholder="" 
                          label="name" 
                          track-by="id" 
                          :searchable="false"
                          :showLabels="false" 
                          :taggable="false"
                          >
                          <template #noResult>
                              <div class="multiselect__noResult text-center">
                                  No results found
                              </div>
                          </template>
                      </multiselect>
                      <input type="hidden" name="00N5a00000DGL6F" :value="selected_product?.name || ''" />
                      <label class="label label-select"
                          :class="{ 'label-float': (selected_product != null) }">Products</label>
                      <div v-if="v$.selected_product.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.selected_product.$errors[0].$message }}
                          </div>
                      </div>
                  </div>

                  <div id="subject"
                      class="submit-ticket-label self-center font-14 font_semibold blueog--text">Subject</div>
                  <div class="form-group mb-0" :class="{ 'form-group--error': v$.subject.$error }">
                      <input id="subject" name="subject" class="form-input" type="text"
                          :class="{ 'form-error': v$.subject.$error }" v-model.trim="v$.subject.$model">
                      <label class="label" :class="{ 'label-float': v$.subject.$model }">Subject</label>
                      <div v-if="v$.subject.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.subject.$errors[0].$message }}
                          </div>
                      </div>
                  </div>

                  <div class="submit-ticket-label self-start font-14 font_semibold blueog--text">Description
                  </div>
                  <div class="mb-0" :class="{ 'form-group--error': v$.description.$error }">
                      <textarea rows="1" class="textarea form-input" placeholder="" id="description"
                          name="description" :class="{ 'form-error': v$.description.$error }"
                          v-model.trim="v$.description.$model"></textarea>
                      <div v-if="v$.description.$errors.length > 0">
                          <div class="form-error-text">
                              {{ v$.description.$errors[0].$message }}
                          </div>
                      </div>
                  </div>
                  <input type="hidden" id="external" name="external" v-model="external" />
                  <div></div>
                  <div class="text-left">
                      <button type="submit" :disabled="disable_submit_btn"
                          class="btn-blue-outline btn-width-120 ml20">
                          <span>Submit</span>
                      </button>
                  </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
  <div class="modal-backdrop"></div>
</template>

<script scoped>
import closeIcon from '../../common/icons/closeIcon.vue'
import { useVuelidate } from '@vuelidate/core';
import { required, email, minLength, maxLength, helpers } from "@vuelidate/validators";
import NProgress from "nprogress";
import { checkSpecialChars, checkSpecialCharsErrorMessage } from "../customValidation";
import axios from "axios";
import toastr from "toastr";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      AUTH_USER: AUTH_USER,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      JS_OSHA_HC_APP_URL: JS_OSHA_HC_APP_URL,
      selected_product: null,
      selected_site_submission_type: null,
      company: AUTH_USER.company_name,
      name: AUTH_USER.first_name + " " + AUTH_USER.last_name,
      orgid: '00D0b000000wo2y',
      retURL: JS_APP_URL + '/dashboard',
      phone: AUTH_USER.phone_number,
      email: AUTH_USER.email,
      subject: '',
      description: '',
      external: 1,
      disable_btn: false,
      product_list: [
          {
              id: 1,
              name: "HIPAA CE"
          }
      ],
      site_submission_type_list: [
          {
              id: 1,
              name: "Product Guidance/How To"
          },
          {
              id: 2,
              name: "Compliance Question"
          },
          {
              id: 3,
              name: "Tech Issue/Error Message"
          },
          {
              id: 4,
              name: "Billing/Accounting"
          },
          {
              id: 5,
              name: "Feature Request/Feedback"
          },
          {
              id: 6,
              name: "Breach Incident"
          }
      ],
      disable_submit_btn: false,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage
    };
  },
  components:{closeIcon},
  emits: ["close-model"],
  mounted() {
    if(this.AUTH_USER.is_sra_user == 0){
        this.checkOtherProductsPurchased();
    }
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
      var validationArray = {
          company: {
              required: helpers.withMessage('Please enter a company', required),
              maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
              checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
          },
          name: {
              required: helpers.withMessage('Please enter a name', required),
              maxLength: helpers.withMessage('Max 80 characters allowed', maxLength(80)),
              checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
          },
          email: {
              required: helpers.withMessage('Please enter an email', required),
              email: helpers.withMessage('Please enter a valid email', email),
              maxLength: helpers.withMessage(
                  "Max 100 characters allowed",
                  maxLength(100)
              ),
          },
          phone: {
              required: helpers.withMessage('Please enter a phone number', required),
              minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
              maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
          },
          subject: {
              required: helpers.withMessage('Please enter a subject', required),
              maxLength: helpers.withMessage('Max 80 characters allowed', maxLength(80)),
          },
          description: {
              required: helpers.withMessage('Please enter a description', required),
              maxLength: helpers.withMessage('Max 1000 characters allowed', maxLength(1000)),
          },
      };
      validationArray.selected_product = {
          required: helpers.withMessage('Please select a product', required)
      };
      validationArray.selected_site_submission_type = {
          required: helpers.withMessage('Please select a type', required)
      };
      return validationArray;
  },
  methods: {
    checkOtherProductsPurchased() {
        NProgress.start();
        this.disable_btn = !this.disable_btn
        axios
            .post(JS_OSHA_HC_APP_URL + "/check-email-already-signup", {
                email: this.AUTH_USER.PCO_email
            })
            .then((response) => {
                if (response["data"]['status'] == 'Success') {
                    if(response["data"]['data']['is_availabe'] == 1){
                        const newProducts = [
                            { id: 2, name: "HIPAA CE/OSHA HC" },
                            { id: 3, name: "OSHA HC" }
                        ];
                        this.product_list.splice(2, 0, ...newProducts);
                    }else{
                        if(this.AUTH_USER.is_sra_user == 1){
                            this.product_list = [
                                {
                                    id: 1,
                                    name: "SRA Only"
                                }
                            ];
                        }
                    }
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
            })
            .then(() => {
                NProgress.done();
                this.disable_btn = !this.disable_btn
            });
    },
    closeModal() {
      this.$emit("close-model", false);
    },
    async submitForm() {
        this.v$.$touch();
        const is_valid = !this.v$.$invalid;
        if (is_valid) {
            NProgress.start();
            this.disable_submit_btn = true;
            const message = encodeURIComponent("Form submitted successfully");
            const separator = this.retURL.includes("?") ? "&" : "?";
            this.retURL = `${this.retURL}${separator}success=${message}`;
            let retInput = this.$refs.ticketForm.querySelector("input[name='retURL']");
            if (retInput) {
                retInput.value = this.retURL;
            }
            this.$refs.ticketForm.submit();
            NProgress.done();
        }
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
