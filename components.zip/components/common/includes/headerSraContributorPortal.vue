<template>
  <div class="dashboard-header pt12 pb10">
      <div class="container">
        <div class="flex items-center justify-center">
          <div class="cursor-pointer text-center">
            <a :href="JS_WORDPRESS_URL" class="vendor-header-logo d-inline-block">
               <div v-if="JS_LOCATION_DATA != null && JS_LOCATION_DATA.user.partner_reseller_id != null && JS_LOCATION_DATA.user.reseller.logo !== ''">
                <img :src="JS_APP_URL + '/images/partner/' + JS_LOCATION_DATA.user.reseller.logo" alt="" title="" class="logo-center logo-center-reseller" />
               </div>
               <div v-else>
                <img :src="JS_APP_URL + '/images/abyde.svg'" alt="" title="" />
               </div>
            </a> 
          </div>
      </div>
    </div>
  </div>
</template>

<script scoped>

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_LOCATION_DATA: JS_LOCATION_DATA,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  components: {},
  mounted() {},
  watch: {},
  computed: {},
  methods: {},
};
</script>
