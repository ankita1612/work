<template>
    <div>
      <video oncontextmenu="return false;" ref="videoPlayer" class="video-js" ></video>
    </div>
  </template>
  
  <script>
  import videojs from 'video.js';
  
  export default {
    name: 'VideoPlayer',
    props: {
      video_file_url:String,
      vtt_file_url:String
    },
    data() {
      return {
        player: null,
        videoOptions: {
          autoplay: true,
          controls: true,
          sources: [
            {
              src:
                this.video_file_url,
                type: 'video/mp4'
            }
          ],
          tracks: [
            {
              src: this.vtt_file_url,
              kind:'captions',
            }
          ]
        },
      }
    },
    mounted() {
      this.player = videojs(this.$refs.videoPlayer, this.videoOptions, () => {});
    },
    beforeDestroy() {
      if (this.player) {
        this.player.dispose();
      }
    },
  }
  </script>