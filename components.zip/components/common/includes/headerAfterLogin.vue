<template>
  <div class="main-wrapper">
    <div class="dashboard-header py17">
      <div class="container">
        <div class="flex items-center justify-between">
          <div class="mmenu_btn hidden-xl">
            <span></span>
            <span></span>
            <span></span>
          </div>
          <div class="logo-dashboard cursor-pointer">
            <a :href="JS_APP_URL + '/dashboard'"
              class="
                dashboard-logo-text
                font-43
                blueog--text
                uppercase
                line-normal
              " v-if="AUTH_USER.is_sra_user == 0"
            >
              HIPAA
              <span class="logo-small-text">FOR COVERED ENTITIES</span>
            </a>
            <a :href="JS_APP_URL + '/dashboard'"
              class="
                dashboard-logo-text
                font-43
                blueog--text
                uppercase
                line-normal
              " 
              v-else
            >
              SRA
              <span class="sra-only-logo-small-text">FOR COVERED ENTITIES</span>
            </a>
          </div>
          <div class="hipaa-logo-wrapper hidden-sm cursor-pointer" v-bind:class="{ 'hipaa-logo-wrapper-reseller': AUTH_USER.partner_reseller_id != null }">
            <span class="header-a-dot" v-bind:class="{ 'header-a-dot-reseller': AUTH_USER.partner_reseller_id != null }" v-if="is_show_header_green_dot">DOT</span>
            <a :href="JS_APP_URL + '/dashboard'">
                <div v-if="AUTH_USER.partner_reseller_id != null && AUTH_USER.reseller.logo !== ''">
                    <img :src="JS_APP_URL + '/images/partner/' + AUTH_USER.reseller.logo"
                    class="logo-center logo-center-reseller"
                    alt=""
                    title="">
                </div>
                <div v-else>
                    <img
                        :src="JS_APP_URL + '/images/abyde_a_logo.svg'"
                        class="logo-center"
                        alt=""
                        title=""
                    />
                </div>
            </a>
          </div>
          <div class="header-user-detail flex flex-wrap items-center">
            <div class="flex items-center">
              <div
                class="cursor-pointer megaphone-icon mr20 relative"
                @click=" (is_all_location_added) ? showWhatsnewSlider(true) : null"
                :class="{
                  'animated': ( (WHATSNEW_SEEN_STATUS == null || (WHATSNEW_SEEN_STATUS && WHATSNEW_SEEN_STATUS.is_seen == 0)) && is_all_location_added),
                  'not-allowed' : !is_all_location_added
                }"
              >
                <img
                  :src="JS_APP_URL + '/images/megaphone.svg'"
                  alt="Whatsnew"
                  title=""
                />
              </div>
              <div
                class="header-user-info dark--text text-right mr10 hidden-sm"
              >
                <div
                  class="header-user-name font-18 font_bold d-inline-block"
                  id="login_full_name" :title=" AUTH_USER.first_name + '' + AUTH_USER.last_name"
                >
                  {{ AUTH_USER.first_name + " " + AUTH_USER.last_name }}
                </div>
                <div
                  class="font-12 font_normal text-right"
                  id="login_company_name"
                >
                  {{ AUTH_USER.user_type_display }}
                </div>
              </div>
              <div class="relative popover__wrapper header-menu cursor-pointer">
                <VDropdown
                  @show="headerMenuShow"
                  @hide="headerMenuHide"
                  autoSize="min"
                  compute-transform-origin
                >
                  <button
                    type="button"
                    class="cursor-pointer header-setting-icon pr0"
                    :class="[isMenuShown ? 'header-setting-animate' : '']"
                  >
                    <img
                      :src="JS_APP_URL + '/images/settings.svg'"
                      alt=""
                      title=""
                    />
                    Setting Icon
                  </button>
                  <template #popper>
                    <div class="px18 py18 header-popover-container">
                      <div class="mb5 text-center font_bold font-12 hidden-xl">
                        {{ AUTH_USER.first_name}}
                      </div>
                      <div class="mb15 text-center font-11 hidden-xl">
                        {{ AUTH_USER.user_type_display }}
                      </div>
                      <div class="flex justify-between flex-wrap mb15 text-center">
                        <a
                        :href="(is_all_location_added && AUTH_USER.is_sra_user == 0) ? JS_APP_URL + '/abyde-drive': (AUTH_USER.user_type == 'PCO' ? '/sra-only-full-upgrade' : 'javascript:void(0)')"
                          class="header-user-popover-item"
                          :class="{'not-allowed' : !is_all_location_added, 'header-sra-only-disable-menu' : AUTH_USER.is_sra_user == 1}"
                        >
                          <div class="header-user-popover-img">
                            <img
                              :src="JS_APP_URL + '/images/drive-icon.svg'"
                              alt=""
                              title=""
                              class="mx-auto"
                            />
                          </div>
                          <div
                            class="
                              header-user-popover-link
                              blue--text
                              font-14 font_semibold
                            "
                          >
                            A Drive
                          </div>
                        </a>
                        <a v-if="AUTH_USER.user_type == 'PCO' && (AUTH_USER.partner_reseller_id == null || (AUTH_USER.partner_reseller_id != null && AUTH_USER.is_admin_panel_login == 'true'))"
                          :href="(is_all_location_added) ? JS_APP_URL + '/billing' : 'javascript:void(0)'"
                          class="header-user-popover-item"
                          :class="{'not-allowed' : !is_all_location_added}"
                        >
                          <div class="header-user-popover-img">
                            <img
                              :src="JS_APP_URL + '/images/card.svg'"
                              alt=""
                              title=""
                              class="mx-auto"
                            />
                          </div>
                          <div
                            class="
                              header-user-popover-link
                              blue--text
                              font-14 font_semibold
                            "
                          >
                            Billing
                          </div>
                        </a>
                        <a
                          v-close-popper
                          href="javascript:void(0)"
                          @click="(is_all_location_added) ? helpEmergencyModalToggle() : null"
                          class="header-user-popover-item"
                          :class="{'not-allowed' : !is_all_location_added, 'header-sra-only-disable-menu' : AUTH_USER.is_sra_user == 1}"
                        >
                          <div class="header-user-popover-img">
                            <img
                              :src="JS_APP_URL + '/images/alarm.svg'"
                              alt=""
                              title=""
                              class="mx-auto"
                            />
                          </div>
                          <div
                            class="
                              header-user-popover-link
                              blue--text
                              font-14 font_semibold
                            "
                          >
                            Help!
                          </div>
                        </a>
                        <a 
                            v-close-popper                            
                            href="#"
                            class="header-user-popover-item"
                            @click="!is_all_location_added ? 'javascript:void(0)' : upgradeAccount()"
                            v-if="AUTH_USER.user_type === 'PCO'"
                              :class="{ 'not-allowed': !is_all_location_added}"
                        >                        
                          <div class="header-user-popover-img">
                            <img
                              :src="JS_APP_URL + '/images/green_check.svg'"
                              alt=""
                              title=""
                              class="mx-auto"
                            />
                          </div>
                          <div
                            class="
                              header-user-popover-link
                              blue--text
                              font-14 font_semibold
                            "
                          >
                            Upgrade
                          </div>
                        </a>
                        <a
                          class="header-user-popover-item"
                          v-close-popper
                          href="javascript:void(0)"
                          @click="(is_all_location_added) ? contactModalToggle() : null"
                          :class="{'not-allowed' : !is_all_location_added, 'header-sra-only-disable-menu' : AUTH_USER.is_sra_user == 1}"
                        >
                          <div class="header-user-popover-img">
                            <img
                              :src="JS_APP_URL + '/images/header_pop_contact.png'"
                              alt=""
                              title=""
                              class="mx-auto header-pop-contact-img"
                            />
                          </div>
                          <div
                            class="
                              header-user-popover-link
                              blue--text
                              font-14 font_semibold
                            "
                          >
                            Support
                          </div>
                        </a>
                        <a
                         class="header-user-popover-item"
                         @click="(is_all_location_added) ? openReferralProgram() : null"
                         :class="{'not-allowed' : !is_all_location_added}"
                        >
                          <div class="header-user-popover-img">
                            <img
                              :src="JS_APP_URL + '/images/header_referral.png'"
                              alt=""
                              title=""
                              class="mx-auto header-pop-referral-img"
                            />
                          </div>
                          <div
                            class="
                              header-user-popover-link
                              blue--text
                              font-14 font_semibold
                            "
                          >
                            Referral
                          </div>
                        </a>
                        
                        <a
                          href="javascript:void(0)"
                          class="header-user-popover-item"
                          @click="(is_logout_btn_disabled)?null:logout()"
                        >
                          <div class="header-user-popover-img">
                            <img
                              :src="JS_APP_URL + '/images/logout.svg'"
                              alt=""
                              title=""
                              class="mx-auto"
                            />
                          </div>
                          <div
                            class="
                              header-user-popover-link
                              blue--text
                              font-14 font_semibold
                            "
                          >
                            Log Out
                          </div>
                        </a>
                      </div>
                      <div class="mb10 text-center" v-if="AUTH_USER.is_sra_user == 0">
                        <a
                          v-close-popper
                          href="javascript:void(0)"
                          @click="(is_all_location_added)? oshahcToggle(): null"
                          class="header-user-popover-item self-center mt10"
                          :class="{'not-allowed' : !is_all_location_added, 'osha-header-popover-item mt0':!(AUTH_USER.user_type === 'PCO')}"
                        >
                          <div class="hippa-logo-menu">
                            <div class="header-user-popover-link">
                              <img
                                :src="JS_APP_URL + '/images/abyde_small.svg'"
                                alt=""
                                title=""
                                class="mx-auto"
                              />
                            </div>
                            <div
                              class="
                                header-menu-hipaa-link
                                font-15 font_semibold
                                blueog--text
                                uppercase
                              "
                            >
                              OSHA HC
                            </div>
                          </div>
                        </a>
                      </div>
                      <div class="text-center">
                        <a
                          :href="(is_all_location_added) ? JS_APP_URL + '/site-policies' : 'javascript:void(0)'"
                          class="
                            font-12 font_semibold
                            green--text
                            menu-privacy-link
                            hover-underline-animation
                          "
                          :class="{'not-allowed' : !is_all_location_added}"
                          >Privacy &amp; Terms</a
                        >
                      </div>
                      <div class="text-center mt5" v-if="(AUTH_USER.partner_reseller_id == null || (AUTH_USER.partner_reseller_id != null && AUTH_USER.is_admin_panel_login == 'true')) && AUTH_USER.is_sra_user == 0">
                        <a
                           v-close-popper
                           href="javascript:void(0)"
                           v-if="AUTH_USER.user_type == 'PCO' || AUTH_USER.user_type == 'HCO'"
                           @click="(is_all_location_added)?showAdditionalProducts():null"
                          class="
                            btn btn-blue
                          "
                          :class="{'not-allowed' : !is_all_location_added}"
                          >ADD NEW PRODUCT</a
                        >
                      </div>
                    </div>
                  </template>
                </VDropdown>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div
      class="sidebar-backdrop"
      @click="hideWhatsnewSlider(false)"
      v-if="is_brackdrop"
    ></div>
    <transition name="slide">
      <whatsnew-slider
        key="saved"
        v-if="is_whatsnew_panel_open"
        :is_panel_open="is_whatsnew_panel_open"
        :whatsnewlist="whatsnew_list"
        @hide-whatsnew-slider="hideWhatsnewSlider"
      />
    </transition>
    <help-emergency-modal
      v-if="is_help_emergency_modal_shown"
      @close-model="helpEmergencyModalToggle"
      :all_location_list="all_location_list"
    >
    </help-emergency-modal>
    <contact-modal
      v-if="is_contact_modal_shown"
      @close-model="contactModalToggle"
    >
    </contact-modal>
    <osha-hc-product-modal
    v-if="is_osha_hc_product_modal_shown"
    @close-model="oshaHCProductToggle"
    @show-additional-products="showAdditionalProducts"
    >
    </osha-hc-product-modal>
    <show-additional-products-modal
      v-if="show_additional_products_modal"
      @show-additional-products="showAdditionalProducts"
      :email="AUTH_USER.PCO_email"
      :addition_product_list="addition_product_list"
      action="inside"
    ></show-additional-products-modal>
    <show-upgrade-restriction-modal
        v-if="is_upgrade_restriction_modal_shown"
        @close-model="showUpgradeRestrictionModalToggle"        >
    </show-upgrade-restriction-modal>
  </div>
</template>
<style scoped>
</style>
<script scoped>
import whatsnewSlider from "../../whatsnew/whatsnewSlider.vue";
import axios from "axios";
import helpEmergencyModal from "./helpEmergencyModal.vue";
import oshaHcProductModal from "./oshaHcProductModal.vue";
import showAdditionalProductsModal from "../../signup_new_product/showAdditionalProductsModal.vue";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import moment from "moment-timezone";
import contactModal from "./contactModal.vue";
import showUpgradeRestrictionModal from "./showUpgradeRestrictionModal.vue";
import _ from 'lodash';

export default {
  data() {
    return {
      isMenuShown: false,
      is_help_emergency_modal_shown: false,
      is_osha_hc_product_modal_shown: false,
      all_location_list: [],
      AUTH_USER: AUTH_USER,
      JS_APP_URL: JS_APP_URL,
      JS_OSHA_HC_APP_URL: JS_OSHA_HC_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      is_whatsnew_panel_open: false,
      is_brackdrop: false,
      //WHATSNEW_SEEN_STATUS: WHATSNEW_SEEN_STATUS,
      WHATSNEW_SEEN_STATUS: null,
      whatsnew_list: [],
      is_all_location_added: true,
      is_show_header_green_dot: false,
      is_logout_btn_disabled: false,
      is_contact_modal_shown: false,
      is_upgrade_restriction_modal_shown: false,
      show_additional_products_modal: false,
      addition_product_list: [{
        "id": "oshahc",
        "name": "OSHA HC",
        "full_name": "OSHA for Healthcare"
      }],
      is_show_ticket_form_modal: false
    };
  },
  components: {
    whatsnewSlider,
    helpEmergencyModal,
    contactModal,
    showAdditionalProductsModal,
    oshaHcProductModal,
    showUpgradeRestrictionModal
  },
  mounted() {
    this.loadLocationList();
    this.locationLimitCountCheck();
    this.getWhatsnewSeenFlag();
    this.checkOpennotificationHeaderGreenDot();
  },
  emits: ["location-limit-count"],
  watch: {},
  computed: {},
  methods: {
    showAdditionalProducts(){
      if(!this.show_additional_products_modal){
        this.checkOtherProductsPurchased();
      }else{
        this.show_additional_products_modal = !this.show_additional_products_modal;
      }
    },
    checkOtherProductsPurchased(){
      NProgress.start();
        axios
      .post(JS_OSHA_HC_APP_URL + "/check-email-already-signup", {
        email: AUTH_USER.PCO_email
      })
      .then((response) => {
        if (response["data"]["status"] == "Error") {
          if(response["data"]['data'].length > 0){
            toastr.error(response["data"]['data'].join('</br>'), "Error");
          }else{
            toastr.error(response["data"]["message"], "Error");
          }
        } else {
          if(response["data"]['data']['is_availabe'] == 1){
            const is_found_product_index = _.findIndex(this.addition_product_list, (o) => { return o.id === 'oshahc'; });
            if(is_found_product_index >= 0){
              this.addition_product_list.splice(is_found_product_index, 1);
            }
          }
          if(this.addition_product_list.length > 0){
            this.show_additional_products_modal = !this.show_additional_products_modal;
          }else{
              toastr.error('Oops, You do not have any new products to purchase!', "Error");
          }
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
      })
      .then(() => {
        NProgress.done();
      });
    },
    openReferralProgram(){
       window.open(JS_WORDPRESS_URL + '/abyde-referral-program',"_blank");
    },
    oshahcToggle(){
      NProgress.start();
      axios
        .post(JS_OSHA_HC_APP_URL + "/osha-hc-toggle",{
            stripe_customer_id: this.AUTH_USER.stripe_customer_id,
            email: this.AUTH_USER.email,
            timezone: moment.tz.guess()
        },{
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            common:{}
          },
          withCredentials: true
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
          } else {
            if(response["data"]['data']["is_user_found"] == 1){
              setTimeout(() => {
                window.location = response["data"]['data']["redirect_url"];
              }, 500);
            }else{
              if(this.AUTH_USER.user_type == "USER"){
                toastr.error("We have not found your account for OSHA HC. Please contact your Primary Compliance Officer.", "Error");
              }else{
                this.oshaHCProductToggle();
              }
            }
          }
        })
        .catch((error) => {
            toastr.error('Product switching failed!', "Error");
        })
        .then(() => {
          NProgress.done();
        });
    },
    oshaHCProductToggle(status = true) {
      this.is_osha_hc_product_modal_shown = status;
    },
    headerMenuShow() {
      this.isMenuShown = true;
    },
    headerMenuHide() {
      this.isMenuShown = false;
    },
    showWhatsnewSlider() {
        if (this.whatsnew_list.length <= 0) {
            this.getWhatsnew();
        }
      this.is_whatsnew_panel_open = true;
      this.is_brackdrop = true;
    },
    hideWhatsnewSlider() {
      this.is_whatsnew_panel_open = false;
      setTimeout(() => {
        this.is_brackdrop = false;
      }, 300);
    },
    loadLocationList() {
      axios
        .get(JS_APP_URL + "/general/get-assigned-location-list")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.all_location_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },
    checkOpennotificationHeaderGreenDot(){
      axios
        .get(JS_APP_URL + "/general/get-assigned-location-list-open-notification-count")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.is_show_header_green_dot = (response["data"]["data"]['total_open_notifications'] > 0)?true:false;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },
    locationLimitCountCheck() {
      axios
        .get(JS_APP_URL + "/dashboard/location-limit-count")
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            var location_limit_data = response.data.data;
            this.$emit('location-limit-count', response.data.data.location_count);
            if (parseInt(location_limit_data.location_limit) > parseInt(location_limit_data.location_count)) {
              this.is_all_location_added = false;
            } else {
              this.is_all_location_added = true;
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
        });
    },
    helpEmergencyModalToggle(status = true) {
      if(this.AUTH_USER.is_sra_user == 0) {
        this.is_help_emergency_modal_shown = status;
      } else if (this.AUTH_USER.is_sra_user == 1 && AUTH_USER.user_type == 'PCO') {
        window.location = JS_APP_URL + "/sra-only-full-upgrade";
      }
    },
    contactModalToggle(status = true) {
      if(this.AUTH_USER.is_sra_user == 0) {
        this.is_contact_modal_shown = status;
      } else if (this.AUTH_USER.is_sra_user == 1 && AUTH_USER.user_type == 'PCO') {
        window.location = JS_APP_URL + "/sra-only-full-upgrade";
      }
    },
    showUpgradeRestrictionModalToggle(status = true) {
      this.is_upgrade_restriction_modal_shown = status;
    },
    getWhatsnew() {
      axios
        .get(JS_APP_URL + "/whatsnew/list?page=1&per_page=4")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.whatsnew_list = response.data.data.data;
            if (
              !response.data.data.seen_status ||
              (response.data.data.seen_status &&
                response.data.data.seen_status.is_seen == 0)
            ) {
              if(AUTH_USER.is_demo_account !== 1){
                this.addWhatsnewSeenFlag();
              }
            }
          } else {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },

    addWhatsnewSeenFlag() {
      axios
        .get(JS_APP_URL + "/whatsnew/add-whatsnew-seen-flag")
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.WHATSNEW_SEEN_STATUS = response.data.data;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },

    getWhatsnewSeenFlag() {
      axios
        .get(JS_APP_URL + "/whatsnew/get-whatsnew-seen-flag")
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.WHATSNEW_SEEN_STATUS = response.data.data;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },

    logout() {
      this.is_logout_btn_disabled = true;
        axios
        .get(JS_APP_URL + "/dashboard/logout")
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            localStorage.setItem('is_logout', 'yes');
            setTimeout(() => {
              localStorage.clear();
              window.location = JS_APP_URL + "/login";
            }, 200);
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_logout_btn_disabled = false;
        });
    },
    upgradeAccount() {                 
        if (this.AUTH_USER.partner_reseller_id != null && this.AUTH_USER.reseller.logo !== '' && this.AUTH_USER.is_admin_panel_login == 'false') 
        {
            this.showUpgradeRestrictionModalToggle();
        }
        else if (this.is_all_location_added) {
          if (this.AUTH_USER.is_sra_user == 1) {
            window.location.href = JS_APP_URL + '/sra-only-upgrade';
          }else{
            window.location.href = JS_APP_URL + '/upgrade';
          }
        }       
    }
  },
};
</script>
