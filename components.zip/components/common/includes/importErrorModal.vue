<template>
      <transition name="modal">
        <div class="modal-mask">
          <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
                        <button
                            v-if="!is_btn_disabled"
                            v-on:click="closeModal"
                            class="cursor-pointer modal-close"
                        >
                            <close-icon></close-icon>
                        </button>
                        <div class="text-center mlr-auto mb30 pt20">
                            <img
                                :src="JS_APP_URL + '/images/warning.svg'"
                                alt=""
                                title=""
                                class="warning-icon-modal"
                            />
                        </div>
                        <h2
                            class="font-24 font_semibold blueog--text line-normal mb30 text-center"
                        >
                            {{ import_errors.message }}
                        </h2>
                        <div class="text-center drive-move-wrapper">
                            <ul
                                v-for="(error, index) in import_errors.data"
                                :key="index"
                            >
                                <li>
                                    <p>{{ error }}</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
</template>

<script scoped>
import closeIcon from "../../common/icons/closeIcon.vue";

export default {
    components: { closeIcon },
    data() {
        return {
            is_btn_disabled: false,
            JS_APP_URL: JS_APP_URL,
        };
    },
    props: {
        import_errors: {
            type: Object,
            default: () => {},
        },
    },
    emits: ["close-model", "modal-open"],
    methods: {
        closeModal() {
            this.$emit("close-model", false);
        },
    },
    created() {
        document.addEventListener("keydown", (e) => {
            if (e.keyCode == 27 && !this.is_btn_disabled) {
                this.$emit("close-model", false);
            }
        });
    },
    destroyed() {
        document.body.classList.remove("modal-open");
    },
};
</script>
