<template>
    <Teleport to="body" >
      <transition name="modal">
        <div class="modal-mask" v-if="show_popup == 2">
          <div
            class="modal-wrapper video-modal animate__animated animate__zoomIn"
          >
            <div class="modal-container Whoa-modal video-modal-container">
              <button @click="closeModal" class="cursor-pointer modal-close">
                <close-icon></close-icon>
              </button>
                <explainer-video-player 
                  v-if="video_file_url != null && vtt_file_url != null"
                  :video_file_url="video_file_url"
                  :vtt_file_url="vtt_file_url" />
            </div>
          </div>
        </div>
      </transition>
    </Teleport>
  </template>
  
  <script scoped>
  import closeIcon from "../../common/icons/closeIcon.vue";
  import explainerVideoPlayer from "../../common/includes/explainerVideoPlayer.vue";
  import axios from "axios";
  import toastr from "toastr";
  import "toastr/toastr.scss";
  toastr.options.preventDuplicates = true;
  
  export default {
    data() {
      return {
        JS_APP_URL: JS_APP_URL,
        video_file_url: null,
        vtt_file_url: null,
        show_popup: 0
      };
    },
    components: {
      closeIcon,
      explainerVideoPlayer
    },
    props: {
      video_file:String,
      video_caption_file:String,
      user_type:{
        type: String,
        default:'general' 
      },

    },
    emits: ["close-model", 'ended'],
    created() {
      document.addEventListener("keydown", (e) => {
        if (e.keyCode == 27) {
          this.$emit("close-model");
        }
      });
    },
    mounted() {
      this.createSignUrl(this.video_file, 'video_file', 3600);
      this.createSignUrl(this.video_caption_file, 'vtt_file');
    },
    destroyed(){},
    methods: {
      closeModal() {
        this.$emit("close-model");
      },
      createSignUrl(file_name,file_type,file_time = 600){
            var signurl_prefix=(this.user_type=="employeeportal")?'employeeportal':'general';
            var request = {
                params: {
                    file_path: 'explainer_videos/'+ file_name,
                    file_exp_time: file_time
                }
            }
            axios
            .get(JS_APP_URL + "/"+signurl_prefix+"/get-sign-url",request)
            .then((response) => {
                if (response["data"]["status"] == "Success") {
                    if(file_type == 'video_file'){
                        this.video_file_url = response.data.data;
                    }
                    if(file_type == 'vtt_file'){
                        this.vtt_file_url = response.data.data;
                    }
                    this.show_popup = this.show_popup + 1;                    
                }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            });
        },
    },
  };
  </script>
  <style>
    @import 'video.js/dist/video-js.css';
  </style>
  