import { helpers } from "@vuelidate/validators";

export const checkSpecialChars = helpers.regex(/^[a-z\d\-'!_.,()&\s]+$/i);

export const checkSpecialCharsErrorMessage = "Valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !";

export const checkSpecialCharsForAddress = helpers.regex(/^[a-z\d\-'!_.,()#&\s]+$/i);

export const checkSpecialCharsForAddressErrorMessage = "Valid characters are A-Z a-z 0-9 . _ - , & ( ) ' ! #";

export const complexPasswordErrorMseesage = "Password must contain at least one letter, one number and one special character";

export const complexPassword = (value) => {
    const containsUppercase = /[A-Z]/.test(value);
    const containsLowercase = /[a-z]/.test(value);
    const containsNumber = /[0-9]/.test(value);
    const containsSpecial = /[#?!@$%^&*-]/.test(value);
    return (
        (containsUppercase || containsLowercase) &&
        containsNumber &&
        containsSpecial
    );
}

export const alphaNumValidator = helpers.regex(/^[a-zA-Z0-9 _-]*$/);
