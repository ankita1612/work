<template>
  <div>
    <header-after-login></header-after-login>
    <div class="container pt40 pb60">
      <full-page-loader v-if="is_full_page_loader_shown" />
      <!-- First screen code as per design  -->
      <first-page
        v-if="show_sra_start_page"
        :selected_location_id="selected_location_id"
        @show-page="showPage"
        @toggle-loader="toggleLoader"
        @change-current-location="changeCurrentLocation"
        current_page="first_page"
      />
      <!-- end first screen code -->

      <!-- second screen code -->
      <question-detail
        v-if="show_question_detail_page"
        :pagination="pagination_type"
        @show-page="showPage"
        @toggle-loader="toggleLoader"
        :selected_location="selected_location"
        :has_multi_locations="has_multi_locations"
      />
      <!-- end second screen code -->

      <!-- Third screen code -->
      <first-page
        v-if="show_sra_completed_page"
        :selected_location_id="selected_location_id"
        @show-page="showPage"
        @toggle-loader="toggleLoader"
        @change-current-location="changeCurrentLocation"
        current_page="completed_page"
      />
      <!-- end third screen code -->
    </div>
  </div>
</template>

<script>
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../common/fullPageLoader.vue";
import questionDetail from "./questionDetail.vue";
import firstPage from "./firstPage.vue";
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";

export default {
  data () {
    return {
      JS_APP_URL: JS_APP_URL,
      selected_location_id: parseInt(JS_LOCATION_ID),
      show_sra_start_page: true,
      show_question_detail_page: false,
      show_sra_completed_page: false,
      pagination_type: "first",
      selected_location: {},
      is_full_page_loader_shown: false,
      has_multi_locations: false,
    };
  },

  components: {
    fullPageLoader,
    questionDetail,
    firstPage,
    headerAfterLogin
  },

  methods: {
    toggleLoader(status = false) {
      this.is_full_page_loader_shown = status;
    },

    changeCurrentLocation(location, locaction_count = 0) {
      this.selected_location = location;
      this.selected_location_id = location.id;
      if (locaction_count > 1) {
        this.has_multi_locations = true;
      }
    },

    showPage(page = "", type = "") {
      switch (page) {
        case "question_detail_page":
          this.show_sra_start_page = false;
          this.show_question_detail_page = true;
          this.show_sra_completed_page = false;
          this.pagination_type = type;
          break;
        case "completed_page":
          this.show_sra_start_page = false;
          this.show_question_detail_page = false;
          this.show_sra_completed_page = true;
          break;
        case "first_page":
        default:
          this.show_sra_start_page = true;
          this.show_question_detail_page = false;
          this.show_sra_completed_page = false;
          break;
      }
    },
  },
};
</script>
