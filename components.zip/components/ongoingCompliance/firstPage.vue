<template>
  <div>
    <div class="mlr-auto mb20 location-dropdon relative" v-if="all_locations.length > 1">
      <multiselect
        class="company-location-select"
        v-model="selected_location"
        :options="all_locations"
        label="location_nickname"
        :taggable="false"
        :multiple="false"
        :close-on-select="true"
        :showLabels="false"
        track-by="id"
        placeholder=""
        :allowEmpty="false"
      >
      <template #noResult>
        <div class="multiselect__noResult text-center">
          No results found
        </div>
      </template>
      </multiselect>
      <label class="label label-select label-float">Location</label>
    </div>
    <h1
      class="
        location-dashbaord-title
        text-center
        font-24 font_semibold
        blueog--text
        line-normal
        mb30
        mb-md-10 mb-sm-10
      "
    >
      Ongoing Compliance
    </h1>
    <div v-if="current_page == 'first_page'">
      <div class="security-progress-wrapper mb50">
        <radial-progress-bar
          class="sra-start-progress"
          :diameter="200"
          :completed-steps="percentage_count.percentage"
          :total-steps="total_steps_outer"
          :start-color="start_color_outer"
          :stop-color="start_color_outer"
          :inner-stroke-color="inner_stroke_color"
          :inner-stroke-width="6"
          :stroke-width="6"
        >
          <h1 class="sra-percent-text font_semibold">
            {{ percentage_count.percentage }}%
          </h1>
          <p class="sra-completed-text">Completed</p>
        </radial-progress-bar>
      </div>
      <p class="font-20 black--text text-center mb50">
        Please answer the following questions as part of your ongoing compliance.
      </p>
      <div class="text-center sra-first-buttons">
        <button
          type="button"
          class="btn-primary mx-auto d-inline-block px30 mt-xs-20 mx5"
          @click="
            showPage(
              'question_detail_page',
              percentage_count.percentage ? 'resume' : 'first'
            )
          "
        >
          {{ percentage_count.percentage ? "Continue" : "Start" }}
        </button>
      </div>
    </div>
    <div v-if="current_page == 'completed_page'">
      <div class="security-progress-wrapper mb40 text-center">
        <radial-progress-bar
          class="sra-completed-progress"
          :diameter="200"
          :completed-steps="100"
          :total-steps="100"
          :start-color="start_color_outer"
          :stop-color="start_color_outer"
          :inner-stroke-color="inner_stroke_color"
          :inner-stroke-width="6"
          :stroke-width="6"
        >
          <h1 class="sra-percent-text font_semibold">100%</h1>
          <p class="sra-completed-text">Completed</p>
        </radial-progress-bar>
      </div>
      <p class="font-20 black--text text-center mb50">
        Your ongoing compliance questions have been completed. Check back for additional questions at a later date.
      </p>
      <div class="text-center">
          <a :href="JS_APP_URL + '/scorecard/' + encryption(selected_location.id)">
        <button
          type="submit"
          class="
            btn-blueog-outline
            go-to-btn
            mx-auto
            d-inline-block
            mt-xs-20
            mx5
          "
        >
          Go To Scorecard
        </button>
        </a>
        <button
          type="button"
          class="
            btn-primary-outline
            go-to-btn
            mx-auto
            d-inline-block
            mt-xs-20
            mx5
          "
          v-if="is_demo_account == 1"
          @click="
            addRandomOngoingQuestionForDemoAccount()
          "
        >
          Demo - Continue
        </button>
      </div>
    </div>
  </div>
</template>
<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import RadialProgressBar from "vue3-radial-progress";

export default {
  props: {
    selected_location_id: {
      type: Number,
    },
    current_page: {
      type: String,
    },
  },

  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      all_locations: [],
      selected_location: {},
      total_steps_outer: 100,
      start_color_outer: "#CCCCCC",
      inner_stroke_color: "#CCCCCC",
      percentage_count: {},
      is_show_start_over_model: false,
      is_demo_account: AUTH_USER.is_demo_account,
      APP_ENV: APP_ENV,
      AUTH_USER: AUTH_USER,
    };
  },
  emits: ["show-page", "change-current-location", "toggle-loader"],
  components: {
    RadialProgressBar
  },

  mounted() {
    this.$emit("toggle-loader", true);
    this.loadLocationNicknameList();    
  },

  watch: {
    selected_location(val) {
      this.$emit("change-current-location", val, this.all_locations.length);
      this.riskAnalysisStatus(val.id);
      // this.setRadialStartOuterColor();
    },
    percentage_count(val){
      if(val.percentage <= 69){
        this.start_color_outer = "#C72121";
      }else if(val.percentage > 69 && val.percentage <= 89){
        this.start_color_outer = "#FAC224";
      }else{
        this.start_color_outer = "#7FC361";
      }
    }
  },

  methods: {
    // setRadialStartOuterColor(){
    //   this.start_color_outer = "#CCCCCC";
    //   setTimeout(() => {
    //     this.start_color_outer = (this.current_page == 'completed_page')?"#7FC361":"#C72121";
    //   }, 1000);
    // },
    loadLocationNicknameList() {
      axios
        .get(JS_APP_URL + "/general/get-assigned-location-list")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.all_locations = response["data"]["data"];
            this.selected_location = this.all_locations.find(
              (object) => object.id === this.selected_location_id
            );
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },

    riskAnalysisStatus(location_id) {
      this.$emit("toggle-loader", true);
      axios
        .get(
          JS_APP_URL +
            "/ongoing-compliance/ongoing-compliance-status?location_id=" +
            location_id
        )
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]["message"] == "Complete SRA first") {
                window.location = JS_APP_URL + "/dashboard";
            }else{
                if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
            }
          }
          if (response["data"]["status"] == "Success") {
            let data = response["data"]["data"];
            this.percentage_count = data;
            setTimeout(() => {
              if(APP_ENV == 'production') {
                var metadata = {
                  first_time_og_added: data['first_time_og_added'],
                  location_id: location_id,
                  location_nickname: this.selected_location.location_nickname,
                  user_locations_number: this.all_locations.length
                };
                if(AUTH_USER.is_sra_user == 0) {
                  Intercom('trackEvent', 'ongoing-status', metadata);
                }
              }
            }, 1000);
            if (data.percentage == 100) {
              this.$emit("toggle-loader", false);
              this.showPage("completed_page");
            } else {
                this.showPage();
            }
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.$emit("toggle-loader", false);
        });
    },

    addRandomOngoingQuestionForDemoAccount(){
      this.$emit("toggle-loader", true);
      axios
        .post(
          JS_APP_URL + "/ongoing-compliance/add-random-ongoing-question-for-demo-account",
          {
            location_id : this.selected_location_id
          }
        )
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.showPage('question_detail_page', 'resume')
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.$emit("toggle-loader", false);
        });
    },

    showPage(page = "", type = "") {
      this.$emit("show-page", page, type);
    },
    encryption(params){
      var encoded = btoa(params);
      return encoded;
    }
  },
};
</script>
