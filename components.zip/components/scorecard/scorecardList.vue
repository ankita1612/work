<template>
  <div>
    <div class="scorecard-card mb10" :class="risk_level_class">
      <div v-if="is_edit_mode">
        <div>
          <div
            class="scorecard-review-date font-12 font-italic gray_checkmark--text"
            v-if="
              attempted_question['risk_analysis_attempted_question'][0][
                'next_remind_date'
              ] != null
            "
          >
            <VTooltip
              :triggers="['hover']"
              :popperTriggers="['hover']"
              class="cursor-pointer"
            >
              <div>
                Review by<span class="font-14"
                  >:
                  {{$filters.formatDate(attempted_question["risk_analysis_attempted_question"][0]["next_remind_date"])}}</span
                >
              </div>
              <template #popper>
                The review by date indicates the timeframe, based on your answer, that this
                question should be reviewed or updated within in order to reduce risk and
                implement appropriate corrective actions. You will receive an ongoing
                compliance question reminder to review this question on the indicated date,
                if your answer has not yet been updated.
              </template>
            </VTooltip>
          </div>
          <div class="relative scorecard-quetion-block mb18">
            <div class="font-16 font_light">
              {{ attempted_question["question_category"]["category_title"] }}
            </div>
            <div class="flex flex-wrap quetion-wrapper">
              <span class="font-19 font_semibold quetion-no-text"
                >Q{{ loop_index + 1 }}.</span
              >
              <div
                class="font-19 font_semibold quetion-text"
                v-html="attempted_question['question']"
              ></div>
            </div>
          </div>
          <div class="edit-toggle-state">
            <div class="row flex-auto -mx-10 items-center mb14">
              <div class="col-12 col-md-12 col-lg-9 col-xl-8 px10">
                <div class="flex items-center flex-wrap">
                  <div
                    class="scorecard-answers-edit answer-option-item font-19 blueog--text mb-md-10"
                    v-for="(option, index) in attempted_question[
                      'risk_analysis_question_answer_options'
                    ]"
                    :key="index"
                  >
                    <div v-if="attempted_question['question_answer_layout'] == 'radio'">
                      <input
                        type="radio"
                        class="answer-option-radio"
                        :value="option['id']"
                        v-model="selected_answers"
                        :id="option['id']"
                        :checked="
                          option.id ==
                          attempted_question['risk_analysis_attempted_question'][0][
                            'attempted_question_answer'
                          ][0]['answer_content']['id']
                        "
                      />

                      <label
                        :for="option['id']"
                        class="answer-option-lable font-19 blueog--text"
                      >
                        {{ option["answer"] }}
                      </label>
                    </div>
                    <div v-if="attempted_question['question_answer_layout'] == 'checkbox'">
                      <input
                        type="checkbox"
                        class="answer-option-radio"
                        :value="option['id']"
                        v-model="selected_answers"
                        :id="option['id']"
                        :checked="
                          option.id ==
                          attempted_question['risk_analysis_attempted_question'][0][
                            'attempted_question_answer'
                          ][0]['answer_content']['id']
                        "
                      />

                      <label
                        :for="option['id']"
                        class="answer-option-lable font-19 blueog--text"
                      >
                        {{ option["answer"] }}
                      </label>
                    </div>
                  </div>
                  <div
                    class="flex-auto"
                    v-if="attempted_question['question_answer_layout'] == 'text'"
                  >
                    <div class="text-center">
                      <textarea
                        class="textarea form-input"
                        v-model.trim="answer"
                      ></textarea>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-md-12 col-lg-3 col-xl-4 px10 text-right">
                <div class="flex items-center flex-wrap justify-end submit-cancel-buttons">
                  <button
                    type="button"
                    class="btn-cancel-outline btn-width-136 px30 mt-xs-20 mx4"
                    @click="cancelEditAnswer"
                    :disabled="disable_submit_btn"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    class="btn-primary btn-width-136 px30 mt-xs-20 mx4 mb-lg-10"
                    @click="editAnswer"
                    :disabled="disable_submit_btn"
                  >
                    Submit
                  </button>
                </div>
              </div>
            </div>
            <div class="row flex-auto -mx-10 items-center mb14">
              <div class="col-12 col-md-10 col-lg-6 col-xl-6 px10">
                <div class="form-group gray-bg-input mb-0">
                  <textarea
                    rows="3"
                    cols="50"
                    class="comment-textarea form-input"
                    v-model.trim="note"
                    :maxLength="max_characters_comment"
                  ></textarea>
                  <label
                    class="label label-select"
                    :class="{ 'label-float': note.length > 0 }"
                    >Notes</label
                  >
                </div>
                <div class="relative textarea-remaining-text">
                  <div
                    class="font-10 fotn-light gray_checkmark--text text-right textarea-character-count"
                  >
                    {{ max_characters_comment - note.length }} Characters Remaining
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div v-else>
        <div
          class="scorecard-review-date font-12 font-italic gray_checkmark--text"
          v-if="
            attempted_question['risk_analysis_attempted_question'][0][
              'next_remind_date'
            ] != null
          "
        >
          <VTooltip
            :triggers="['hover']"
            :popperTriggers="['hover']"
            class="cursor-pointer"
          >
            <div>
              Review by<span class="font-14"
                >:
                {{ $filters.formatDate(attempted_question["risk_analysis_attempted_question"][0]["next_remind_date"])}}</span
              >              
            </div>
            <template #popper>
              The review by date indicates the timeframe, based on your answer, that this
              question should be reviewed or updated within in order to reduce risk and
              implement appropriate corrective actions. You will receive an ongoing
              compliance question reminder to review this question on the indicated date,
              if your answer has not yet been updated.
            </template>
          </VTooltip>
        </div>
        <div class="relative scorecard-quetion-block mb18">
          <div class="font-16 font_light">
            {{ attempted_question["question_category"]["category_title"] }}
          </div>
          <div class="flex flex-wrap quetion-wrapper">
            <span class="font-19 font_semibold quetion-no-text"
              >Q{{ loop_index + 1 }}.</span
            >
            <div
              class="font-19 font_semibold quetion-text"
              v-html="attempted_question['question']"
            ></div>
          </div>
        </div>
        <div
          class="edit-complete-state"
          v-if="attempted_question['question_answer_layout'] == 'radio'"
        >
          <div class="row flex-auto -mx-10 items-center justify-between mb15">
            <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10 mb-sm-0">
              <div class="scorecard-answers-option font-19 blueog--text active mb-md-20">
                {{
                  attempted_question["risk_analysis_attempted_question"][0][
                    "attempted_question_answer"
                  ][0]["answer_content"]["answer"]
                }}
              </div>
            </div>
            <div
              class="col-12 col-md-12 col-lg-5 col-xl-5 px10 mb-sm-20 self-center"
              v-if="
                (attempted_question['risk_analysis_attempted_question'][0]['note'] != null && attempted_question['risk_analysis_attempted_question'][0]['note'] != '')
              "
            >
            <div class="scorecard-note-text" v-if="is_edit_mode == false">
              {{attempted_question['risk_analysis_attempted_question'][0]['note']}}
              <label class="label location-input-label label-float">Notes</label>
            </div>
              <div v-else class="form-group gray-bg-input mb-0">
                <textarea
                  rows="3"
                  cols="50"
                  class="comment-textarea form-input"
                  v-model="
                    attempted_question['risk_analysis_attempted_question'][0]['note']
                  "
                ></textarea>
                <label class="label location-input-label label-float">Notes</label>
              </div>
            </div>
            <div class="col-6 col-md-6 col-lg-1 col-xl-1 px10 self-center inline-flex">
              <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="">
                <a
                  class="action-icon-btn action-btn-blueog cursor-pointer"
                  v-on:click="toogleEditModel"
                >
                  <img :src="JS_APP_URL + '/images/pencil.svg'" alt="Edit" />
                </a>
                <template #popper> Edit </template>
              </VTooltip>
              <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="inline-block ml6">
                <a class="cursor-pointer" :class="attempted_question.risk_analysis_contributor_question.length > 0 ? 'abyde-blue-flag-icon' : 'abyde-flag-icon'" v-on:click="toogleAskContributorModel(attempted_question['id'])">
                </a>
                <template #popper> Send this question to one or more <span class="font-italic">SRA Contributors</span> or <span class="font-italic">Users</span> assigned to this location.
                </template>
              </VTooltip>               
            </div>
          </div>
          <div class="relative">
            <div
              class="risk-indicator low-risk-indicator flex items-center"
              :class="{
                'risk-indicator-closed out': is_recommendations_show == false,
                'risk-indicator-open': is_recommendations_show == true,
              }"
              @click="recommandationToggle"
            >
              <span class="risk-name font-12 font_semibold" :class="text_color_class"
                >{{
                  attempted_question["risk_analysis_attempted_question"][0][
                    "attempted_question_answer"
                  ][0]["answer_content"]["risk_level"]
                }}
                Risk</span
              >
              <div class="risk-indicator-img">
                <a>
                  <img :src="risk_level_image" alt="Edit" />
                </a>
              </div>
            </div>
            <div
              class="recommmendation-block"
              :class="{
                'recommmendation-low-risk':
                  is_recommendations_show == true &&
                  (attempted_question['risk_analysis_attempted_question'][0][
                    'attempted_question_answer'
                  ][0]['answer_content']['risk_level'] == 'Low' ||
                    attempted_question['risk_analysis_attempted_question'][0][
                      'attempted_question_answer'
                    ][0]['answer_content']['risk_level'] == 'Very Low'),
                'recommmendation-medium-risk':
                  is_recommendations_show == true &&
                  attempted_question['risk_analysis_attempted_question'][0][
                    'attempted_question_answer'
                  ][0]['answer_content']['risk_level'] == 'Medium',
                'recommmendation-high-risk':
                  is_recommendations_show == true &&
                  (attempted_question['risk_analysis_attempted_question'][0][
                    'attempted_question_answer'
                  ][0]['answer_content']['risk_level'] == 'High' ||
                    attempted_question['risk_analysis_attempted_question'][0][
                      'attempted_question_answer'
                    ][0]['answer_content']['risk_level'] == 'Very High'),
              }"
            >
              <transition name="slide-fade">
                <div v-if="is_recommendations_show == true">
                  <div>
                    <span class="font_semibold gray2--text">Likelihood/Impact: </span>
                    <div class="d-inline">
                      {{
                        attempted_question["risk_analysis_attempted_question"][0][
                          "attempted_question_answer"
                        ][0]["answer_content"]["likelihood_text"]
                      }}/{{
                        attempted_question["risk_analysis_attempted_question"][0][
                          "attempted_question_answer"
                        ][0]["answer_content"]["impact_text"]
                      }}
                    </div>
                  </div>
                  <div
                    v-if="
                      attempted_question['risk_analysis_attempted_question'][0][
                        'attempted_question_answer'
                      ][0]['answer_content']['remind_option_detail'] != null &&
                      attempted_question['risk_analysis_attempted_question'][0][
                        'attempted_question_answer'
                      ][0]['answer_content']['remind_option_detail']['education']"
                  >
                    <span class="font_semibold gray2--text">Recommendations: </span>
                    <div
                      class="d-inline"
                      v-html="
                        attempted_question['risk_analysis_attempted_question'][0][
                          'attempted_question_answer'
                        ][0]['answer_content']['remind_option_detail']['education']
                      "
                    ></div>
                  </div>
                </div>
              </transition>
            </div>
          </div>
        </div>
        <div class="edit-complete-state checkbox-view" v-else>
        <div class="row flex-auto -mx-10 items-center mb15 justify-between">
          <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10 mb-sm-10">
            <div
              class="scorecard-answer-textbox font-16 blueog--text text-center inline-flex items-center justify-center mb-md-20"
              v-if="attempted_question['question_answer_layout'] == 'text'"
            >
              {{
                attempted_question["risk_analysis_attempted_question"][0][
                  "attempted_question_answer"
                ][0]["answer"]
              }}
            </div>
            <div
              class="flex flex-wrap -mx-10 mb-md-10"
              v-if="attempted_question['question_answer_layout'] == 'checkbox'"
            >
              <div
                class="scorecard-checkbox-view-item inline-flex items-center justify-center font-19 blueog--text active"
                v-for="(attempted_question_answer, index) in attempted_question[
                  'risk_analysis_attempted_question'
                ][0]['attempted_question_answer']"
                :key="index"
              >
                {{ attempted_question_answer["answer_content"]["answer"] }}
              </div>
            </div>
          </div>
          <div
            class="col-12 col-md-12 col-lg-5 col-xl-5 px10 mb-sm-20 self-center"
            v-if="
              (attempted_question['risk_analysis_attempted_question'][0]['note'] != null && attempted_question['risk_analysis_attempted_question'][0]['note'] != '')
            "
          >
            <div class="form-group gray-bg-input mb-0">
              <textarea
                cols="50"
                class="comment-textarea form-input"
                disabled
                v-model="
                  attempted_question['risk_analysis_attempted_question'][0]['note']
                "
              ></textarea>
              <label class="label location-input-label label-float">Notes</label>
            </div>
          </div>
          <div class="col-6 col-md-6 col-lg-1 col-xl-1 px10 self-center inline-flex">
            <VTooltip :triggers="['hover']" :popperTriggers="['hover']">
              <a
                class="action-icon-btn action-btn-blueog cursor-pointer mlr-auto"
                v-on:click="toogleEditModel"
              >
                <img :src="JS_APP_URL + '/images/pencil.svg'" alt="Edit" />
              </a>
              <template #popper> Edit </template>
            </VTooltip>
            <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="inline-block ml6">
              <a class="cursor-pointer" :class="attempted_question.risk_analysis_contributor_question.length > 0 ? 'abyde-blue-flag-icon' : 'abyde-flag-icon'" v-on:click="toogleAskContributorModel(attempted_question['id'])">
              </a>
              <template #popper> Send this question to another Abyde user and/ or SRA Contributor assigned to this location. </template>
            </VTooltip>
          </div>
        </div>
      </div>        
      </div>      
      <contributor-question 
        v-if="attempted_question.risk_analysis_contributor_question.length > 0" 
        :sra_contributor_question_list="attempted_question.risk_analysis_contributor_question" 
        :user_company_name="user_company_name" 
        :question_id="question_id" 
        :location_id="attempted_question.risk_analysis_attempted_question[0].location_id" 
        @refresh-modal="refreshQuestionList"
        :question_number = "loop_index"
      ></contributor-question>
    </div>
    <ask-contributor-modal 
      v-if="this.is_show_ask_contributor_modal" 
      :sra_contributor_list="sra_contributor_list" 
      :user_list="user_list" 
      @close-model="askContributorModalToggle" 
      :question_id="question_id" 
      :location_id="attempted_question.risk_analysis_attempted_question[0].location_id"
      :risk_analysis_contributor_question="attempted_question.risk_analysis_contributor_question"
      :question_text = "attempted_question['question']"
      :question_number = "loop_index"
    ></ask-contributor-modal>
  </div>
</template>

<script>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
import contributorQuestion from "./contributorQuestion.vue";
import askContributorModal from "./askContributorModal.vue";
import abydeFlag from "../common/icons/abydeFlag.vue";
import _ from 'lodash';

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_edit_mode: false,
      is_show_ask_contributor_modal: false,
      // current_location_id: 1,
      selected_answers: [],
      note: "",
      answer: "",
      risk_level_class: "",
      risk_level_image: "",
      is_recommendations_show: false,
      text_color_class: "",
      disable_submit_btn: false,
      max_characters_comment: 1000,
      sra_contributor_list: [],      
      user_list: [],
      question_id: 0,
      location_id: 0,
    };
  },
  components: {
    contributorQuestion,
    askContributorModal,
    abydeFlag
  },
  emits: ["get-attempted-question"],
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.initialDataLoad();
      }
    });
    this.question_id = this.attempted_question['id'];
    this.location_id = this.selected_location.id
  },
  props: {
    attempted_question: {
      type: Object,
    },
    selected_location: {},
    loop_index: "",
    user_company_name: String,
  },
  watch: {
    attempted_question(val) {
      this.initialDataLoad();
    },
    note(val) {
      this.note = val.replace(/\n|\r|  +/g, "");
    },
  },
  mounted() {
    this.initialDataLoad();
  },
  methods: {
    cancelEditAnswer() {
      this.initialDataLoad();
    },
    toogleEditModel() {
      if (this.is_edit_mode == true) {
        this.is_edit_mode = false;
      } else {
        this.is_edit_mode = true;
      }
    },
    toogleAskContributorModel(question_id) {   
      this.question_id = question_id
      this.location_id = this.selected_location.id
      // this.is_show_ask_contributor_modal = !this.is_show_ask_contributor_modal;
      NProgress.start();
      axios
      .get(JS_APP_URL + "/scorecard/fetch-all-contributors", {
          params: { location_id: this.selected_location.id, question_id: question_id }
      })
      .then((response) => {
        if (response["data"]["status"] == "Success") {
          this.sra_contributor_list = response["data"]["data"]['external'];
          this.user_list = response["data"]["data"]['internal'];          
          this.is_show_ask_contributor_modal = true;
        } else {
          if(response["data"]['data'].length > 0){
              toastr.error(response["data"]['data'].join('</br>'), "Error");
          }else{
              toastr.error(response["data"]["message"], "Error");
          }
        }
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";
        }
      })
      .then(() => {
        NProgress.done();
      });
    },
    askContributorModalToggle(type){
      this.is_show_ask_contributor_modal = !this.is_show_ask_contributor_modal;
      if(type == "refresh") {
        this.$emit("get-attempted-question", this.selected_location.id);
      }
    },
    refreshQuestionList(){
      this.$emit("get-attempted-question", this.selected_location.id);
    },
    checkBothArrayEquals(array1, array2) {
      if (array1.length === array2.length) {
        return array1.every((element) => {
          if (array2.includes(element)) {
            return true;
          }
          return false;
        });
      }
      return false;
    },
    editAnswer() {
      var is_answer_changed = false;
      var is_note_changed = false;
      var attempted_note =
        this.attempted_question["risk_analysis_attempted_question"][0]["note"] != null
          ? this.attempted_question["risk_analysis_attempted_question"][0]["note"]
          : "";
      if (attempted_note != this.note) {
        is_note_changed = true;
      }
      if (
        this.attempted_question["question_answer_layout"] == "text" &&
        this.attempted_question["risk_analysis_attempted_question"][0][
          "attempted_question_answer"
        ][0]["answer"] != this.answer
      ) {
        is_answer_changed = true;
      }
      if (
        this.attempted_question["question_answer_layout"] == "radio" &&
        this.attempted_question["risk_analysis_attempted_question"][0][
          "attempted_question_answer"
        ][0]["answer_content"]["id"] != this.selected_answers
      ) {
        is_answer_changed = true;
      }
      if (this.attempted_question["question_answer_layout"] == "checkbox") {
        var chk_selected_answer_ids = [];
        _.forEach(
          this.attempted_question["risk_analysis_attempted_question"][0][
            "attempted_question_answer"
          ],
          (value) => {
            chk_selected_answer_ids.push(value.answer_content.id);
          }
        );
        if (!this.checkBothArrayEquals(chk_selected_answer_ids, this.selected_answers)) {
          is_answer_changed = true;
        }
      }
      if (!is_note_changed && !is_answer_changed) {
        toastr.error(
          "Please change your answer/note in order to save your data",
          "Error"
        );
        return false;
      }
      NProgress.start();
      this.disable_submit_btn = true;
      if (!Array.isArray(this.selected_answers)) {
        this.selected_answers = [this.selected_answers];
      }
      let payload;
      if (this.attempted_question["question_answer_layout"] == "text") {
        if (this.answer == null || this.answer == "") {
          toastr.error("Please enter an answer", "Error");
          this.disable_submit_btn = false;
          NProgress.done();
          return;
        }
        payload = {
          attempted_question_id: this.attempted_question[
            "risk_analysis_attempted_question"
          ][0]["id"],
          answer: this.answer,
        };
      } else {
        if (this.attempted_question["question_answer_layout"] == "checkbox") {
          if (this.selected_answers.length < 1) {
            toastr.error("Please select answer(s)", "Error");
            this.disable_submit_btn = false;
            NProgress.done();
            return;
          }
        }
        payload = {
          attempted_question_id: this.attempted_question[
            "risk_analysis_attempted_question"
          ][0]["id"],
          answer_id: this.selected_answers,
        };
      }
      if (is_note_changed) {
        axios
          .post(JS_APP_URL + "/scorecard/edit-note", {
            attempted_question_id: this.attempted_question[
              "risk_analysis_attempted_question"
            ][0]["id"],
            note: this.note,
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if (response["data"]["data"].length > 0) {
                toastr.error(response["data"]["data"].join("</br>"), "Error");
              } else {
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              if (!is_answer_changed) {
                this.toogleEditModel();
                this.$emit("get-attempted-question", this.selected_location.id);
              }
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            if (!is_answer_changed) {
              this.disable_submit_btn = false;
              NProgress.done();
            }
          });
      }
      if (is_answer_changed) {
        axios
          .post(JS_APP_URL + "/scorecard/edit-answer", payload)
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if (response["data"]["data"].length > 0) {
                toastr.error(response["data"]["data"].join("</br>"), "Error");
              } else {
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              this.toogleEditModel();
              this.$emit("get-attempted-question", this.selected_location.id);
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            this.disable_submit_btn = false;
            NProgress.done();
          });
      }
    },
    recommandationToggle() {
      if (this.is_recommendations_show == true) {
        this.is_recommendations_show = false;
      } else {
        this.is_recommendations_show = true;
      }
    },
    initialDataLoad() {
      this.resetInitialData();
      if (
        this.attempted_question["risk_analysis_attempted_question"][0]["note"] != null
      ) {
        this.note = this.attempted_question["risk_analysis_attempted_question"][0][
          "note"
        ];
      }
      if (this.attempted_question["question_answer_layout"] == "radio") {
        this.selected_answers = this.attempted_question[
          "risk_analysis_attempted_question"
        ][0]["attempted_question_answer"][0]["answer_content"]["id"];
        var risk_level = this.attempted_question["risk_analysis_attempted_question"][0][
          "attempted_question_answer"
        ][0]["answer_content"]["risk_level"];

        if (risk_level == "Low" || risk_level == "Very Low") {
          this.risk_level_class = "scorecard-low-risk";
          this.text_color_class = "green--text";
          if (risk_level == "Low") {
            this.risk_level_image = JS_APP_URL + "/images/low.png";
          } else {
            this.risk_level_image = JS_APP_URL + "/images/very-low.png";
          }
        }
        if (risk_level == "Medium") {
          this.text_color_class = "yellow--text";
          this.risk_level_class = "scorecard-medium-risk";
          this.risk_level_image = JS_APP_URL + "/images/medium.png";
        }
        if (risk_level == "High" || risk_level == "Very High") {
          this.text_color_class = "red--text";
          this.risk_level_class = "scorecard-high-risk";
          if (risk_level == "High") {
            this.risk_level_image = JS_APP_URL + "/images/high.png";
          } else {
            this.risk_level_image = JS_APP_URL + "/images/very-high.png";
          }
        }
      }
      if (this.attempted_question["question_answer_layout"] == "checkbox") {
        this.selected_answers = [];
        _.forEach(
          this.attempted_question["risk_analysis_attempted_question"][0][
            "attempted_question_answer"
          ],
          (value) => {
            this.selected_answers.push(value.answer_content.id);
          }
        );
        let answer_array = this.attempted_question["risk_analysis_attempted_question"][0][
          "attempted_question_answer"
        ];
        this.attempted_question["risk_analysis_attempted_question"][0][
          "attempted_question_answer"
        ] = _.sortBy(answer_array, [
          (o) => {
            return o.answer_content.id;
          },
        ]);
      }
      if (this.attempted_question["question_answer_layout"] == "text") {
        this.answer = this.attempted_question["risk_analysis_attempted_question"][0][
          "attempted_question_answer"
        ][0]["answer"];
      }
    },
    resetInitialData() {
      this.is_edit_mode = false;
      this.selected_answers = [];
      this.note = "";
      this.answer = "";
      this.risk_level_class = "";
      this.risk_level_image = "";
      this.is_recommendations_show = false;
      this.text_color_class = "";
      this.disable_submit_btn = false;
      this.max_characters_comment = 1000;
    },
  },
};
</script>

<style></style>
