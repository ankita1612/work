<template>
    <Teleport to="body">
      <transition name="modal">
        <div>
          <div class="modal-mask modal-scrollable">
            <div class="modal-wrapper modal-score-questions animate__animated animate__zoomIn">
              <div class="modal-container">
                  <button v-if="!disable_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                      <close-icon></close-icon>
                  </button>
                <div class="text-center mlr-auto mb5">
                    <img
                    :src="JS_APP_URL + '/images/sra_flag_big.svg'"
                    alt=""
                    title=""
                    class="warning-icon-modal"
                    />
                </div>                
                  <h2 class="font-20 font_semibold blueog--text line-normal mb30 text-center">
                    Send Question to Contributor
                  </h2>
                  <div class="text-left mlr-auto col-11">
                    <h4 class="font-20 blueog--text line-normal mb20">
                      <span class="font_semibold">Contributor:</span> <span class="gray_checkmark--text">{{ question_details.risk_analysis_contributor_question[0].contributor_user_acntuser.first_name }} {{ question_details.risk_analysis_contributor_question[0].contributor_user_acntuser.last_name }}</span>
                    </h4>
                    <h4 class="font-20 blueog--text line-normal mb20">
                      <span class="font_semibold">Q{{ this.question_index+1 }}:</span> <span class="font-italic gray_checkmark--text">{{ question_details.question.trim() }}</span>
                    </h4>
                    <h4 class="font-20 blueog--text line-normal mb20">
                      <span class="font_semibold">Current Answer: </span> 
                      <span v-for="(attemptQuestionAnswer, index) in question_details.risk_analysis_attempted_question[0].attempted_question_answer" :key="index"> 
                        <span v-if="attemptQuestionAnswer.answer_content" class="font-italic gray_checkmark--text">
                          {{ attemptQuestionAnswer.answer_content.answer }}<span v-if="index !== question_details.risk_analysis_attempted_question[0].attempted_question_answer.length - 1">, </span> 
                        </span> 
                        <span v-else class="font-italic gray_checkmark--text">{{ attemptQuestionAnswer.answer }}</span>
                      </span>
                    </h4>
                    <div class="form-group gray-bg-input mb-0">
                      <textarea
                      rows="3"
                      cols="50"
                      class="comment-textarea form-input font-italic mb20 contributor-form-input"
                      readonly
                      :value="question_details.risk_analysis_attempted_question[0].note"
                      >
                      </textarea>
                      <label class="label location-input-label label-float">Notes</label>
                    </div>
                  </div>
                  <div class="completecase-content mlr-auto">
                    <div class="flex items-center flex-wrap flex-auto mb20">
                      <div class="row flex-auto justify-center -mx-10">
                        <div class="col-12 col-md-12 px10">
                          <form class="fill-width">
                            <div class="checkbox mb10">
                                <input  v-model="send_mail_all_questions"  class="form-check-input" id='refresher' name="send_mail_all_questions" type="checkbox" :true-value="'1'" :false-value="'0'"/>
                                <label for="refresher" class="checkbox-label font-14 font-light gray_checkmark--text">(Optional) Send All Pending Questions ({{ question_details.send_question_cout }}) to selected Contributors.</label>
                            </div>    
                            <div class="font-14 text-center gray_checkmark--text line-normal mb25 pl3">
                                If you have more than one question for a contributor, it’s recommended<br/> to send all questions in one batch.  
                              </div>                                                
                            <div class="flex flex-wrap items-center flex-auto justify-center mt20">
                              <button type="button" class="btn-cancel-outline mx15 btn-width-120 h-32" v-on:click="closeModal">Cancel</button>
                              <button type="button" @click.once="sendQuestionSubmit" class="btn-primary-outline mx15 btn-width-120 h-32">Send</button>
                            </div>
                        </form>
                        </div>
                        </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-backdrop"></div>
        </div>
      </transition>
    </Teleport>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </template>
  
  <script scoped>
  import axios from "axios";
  import NProgress from "nprogress";
  import toastr from "toastr";
  import "toastr/toastr.scss";
  toastr.options.preventDuplicates = true;
  import _ from 'lodash';
  import closeIcon from '../common/icons/closeIcon.vue';
  import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
  import fullPageLoader from "../common/fullPageLoader.vue";
  
  export default {
    data() {
      return {
        disable_submit_btn:false,
        JS_APP_URL: JS_APP_URL,
        risk_analysis_contributor_question_id: "",
        send_mail_all_questions: 0,
        is_full_page_loader_shown: false,
      };
    },
    props: {
        question_details: Object,
        sra_contributor_list: Array,
        user_list: Array,
        question_id: Number,
        location_id: Number,
        current_index: Number,
        question_index: Number
    },
    emits: ["close-model", "refresh-list","question-detail"],
    created() {
      document.addEventListener('keyup', (evt) => {
        if (evt.keyCode === 27 && !this.disable_submit_btn) {
          this.$emit("close-model", false);
        }
      });
      this.risk_analysis_contributor_question_id = this.question_details.risk_analysis_contributor_question[0].id;
    },
    computed: {
    },
    components: {
      fullPageLoader,
      closeIcon,
      clearDropdownIcon
    },
    methods: {
      sendQuestionSubmit() {
          this.is_full_page_loader_shown = true;
          NProgress.start();
          axios
          .post(JS_APP_URL + "/scorecard/send-request-to-contributor",{
              risk_analysis_contributor_question_id: this.risk_analysis_contributor_question_id,
              send_all: this.send_mail_all_questions,
              location_id: this.location_id
          })
          .then((response) => {
          if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
          } else {
              toastr.success(response["data"]["message"], "Success");  
              this.$emit("refresh-list", "send_question");
              
          }
          })
          .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                  window.location = JS_APP_URL + "/login";
              }
          })
          .then(() => {
          NProgress.done();
          this.disable_submit_btn =false;
          this.is_full_page_loader_shown = false;
          });
      },
       closeModal() {
        this.$emit("close-model", false);
      },
    },
  };
  </script>
  