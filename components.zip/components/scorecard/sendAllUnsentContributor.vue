<template>
    <Teleport to="body">
      <transition name="modal">
        <div class="modal-mask">
          <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
                <button v-if="!disable_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                    <close-icon></close-icon>
                </button>
              <div class="text-center mlr-auto mb15">
                  <img
                  :src="JS_APP_URL + '/images/envelop-upload.svg'"
                  alt=""
                  title=""
                  class="warning-icon-modal"
                  />
              </div>                 
                <h2 class="font-24 font_semibold blueog--text line-normal mb30 text-center">
                  Send all unsent SRA questions to selected Contributors?
                </h2>
                <div class="completecase-content mlr-auto">
                    <div class="font-16 text-center gray_checkmark--text line-normal mb20">
                        You currently have ({{ this.unsend_question_count }}) question(s) selected for Contributors yet to be sent. It’s recommended to send all questions at once.  
                    </div>
                  <div class="flex items-center flex-wrap flex-auto mb20">
                    <div class="row flex-auto justify-center -mx-10">
                      <div class="col-12 col-md-12 px10">
                          <div class="col-12 col-md-12 px10">
                            <div class="flex flex-wrap items-center flex-auto justify-center mt10">
                                <button type="button" class="btn-cancel-outline mx15 btn-width-120 h-32" v-on:click="closeModal">CANCEL</button>
                                <button type="button" @click.once="sendAllUnsentSubmit" class="btn-primary-outline mx15 btn-width-120 h-32 " :disabled="this.unsend_question_count == 0">SEND</button>
                            </div>
                          </div>
                      </div>
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </transition>
    </Teleport>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </template>
  
  <script scoped>
  import axios from "axios";
  import NProgress from "nprogress";
  import toastr from "toastr";
  import "toastr/toastr.scss";
  toastr.options.preventDuplicates = true;
  import _ from 'lodash';
  import closeIcon from '../common/icons/closeIcon.vue';
  import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
  import fullPageLoader from "../common/fullPageLoader.vue";
  
  export default {
    data() {
      return {
        disable_submit_btn:false,
        JS_APP_URL: JS_APP_URL,
        send_reminder_all_questions: 0,
        is_full_page_loader_shown: false,
      };
    },
    props: {
        unsend_question_count: Number,
        location_id: Number,
    },
    emits: ["close-model", "refresh-list"],
    created() {
      document.addEventListener('keyup', (evt) => {
        if (evt.keyCode === 27 && !this.disable_submit_btn) {
          this.$emit("close-model", false);
        }
      });
    },
    computed: {
    },
    components: {
        fullPageLoader,
        closeIcon,
        clearDropdownIcon
    },
    methods: {
      sendAllUnsentSubmit() {
          this.is_full_page_loader_shown = true;
          NProgress.start();
          axios
          .post(JS_APP_URL + "/scorecard/send-request-to-contributor",{
              risk_analysis_contributor_question_id: 0,
              send_all: 1,
              location_id: this.location_id
          })
          .then((response) => {
          if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
          } else {
              toastr.success(response["data"]["message"], "Success");  
                setTimeout(() => {
                    this.$emit("refresh-list", this.location_id);
                }, 100);
          }
          })
          .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                  window.location = JS_APP_URL + "/login";
              }
          })
          .then(() => {
          NProgress.done();
          this.disable_submit_btn =false;
          this.is_full_page_loader_shown = false;
          });
      },
       closeModal() {
        this.$emit("close-model", false);
      },
    },
  };
  </script>
  