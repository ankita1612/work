<template>
    <div class="container pt40 pb60">
      <div class="row flex-auto -mx-10 mb10">
        <div class="col-12 col-md-12 col-lg-12 col-xl-4 px10 mb-sm-20">
          <button
            type="button"
            class="btn-blue-outline btn-left-icon"
            @click="closeScorecarHistory"
          >
            <div class="prev-arrow-icon"><previous-icon></previous-icon></div>
            BACK TO Scorecard
          </button>
        </div>
        <div class="col-12 col-md-12 col-lg-12 col-xl-4 px10" v-if="all_locations.length>1">
           <div class="form-group gray-bg-input mb-0 location-dropdon mlr-auto">
                <multiselect
                class="company-location-select"
                v-model="local_selected_location"
                :options="all_locations"
                label="location_nickname"
                :taggable="false"
                :multiple="false"
                :close-on-select="true"
                :showLabels="false"
                track-by="id"
                placeholder=""
                :allowEmpty="false"
              >
              <template #noResult>
                <div class="multiselect__noResult text-center">
                    No results found
                  </div>
                </template>
              </multiselect>
              <label class="label label-select label-float" >Location</label>
            </div>
        </div>
      </div>
      <h1 class="
        location-dashbaord-title
        text-center
        font-24 font_semibold
        blueog--text
        line-normal mb30
      ">
      Scorecard History
    </h1>

        <!-- <div class="flex flex-wrap flex-auto justify-end justify-start-small-medium mb30">
              <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" style="padding-top: 5px;" class="cursor-pointer" v-if="has_old_history > 0"><info-icon class="cursor-pointer ml2"></info-icon>
                <template #popper>
                    You can not filter list of old scorecard history
                </template>
              </VTooltip>
              <div class="form-group mb-0 filter-item">
                <multiselect
                  v-model="filter_risk_level"
                  :options="risk_level_option"
                  :taggable="false"
                  track-by="id"
                  label="text"
                  :multiple="false"
                  :close-on-select="true"
                  :showLabels="false"
                  placeholder=""
                  :searchable="false"
                  @update:model-value="getScorecardHistory"
                  >
                  </multiselect>
                  <label class="label label-select" :class="{ 'label-float': (filter_risk_level != null) }" >Sort by Risk Levels</label>
              </div>
        </div> -->

        <div class="user-detail-card py10 px15 light mb15"
        v-for="data in scorecard_history_data" :key="data.id">
            <div class="row flex-auto -mx-10 items-center">
                <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10 mb-md-10">
                    <div class="font-16 font_semibold gray2--text">Risk Analysis</div>
                </div>
                <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10 mb-md-10">
                    <span class="font-9 gray_checkmark--text font-italic margin-4-right-txt">Created On:</span>
                    <span class="font-12 font_semibold blueog--text">{{ $filters.formatDate(data.created_at)}}</span>
                    <span class="font-9 gray_checkmark--text font-italic margin-4-right-txt margin-2-left-txt">at</span>
                    <span class="font-12 font_semibold blueog--text">{{ $filters.formatTime(data.created_at)}}</span>
                </div>
                <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10 mb-sm-20">
                    <div class="inline-flex items-center justify-center fill-width justify-start-small-medium" v-if="data['low_risk_count'] != null || data['medium_risk_count'] != null || data['high_risk_count'] != null">
                          <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="mr12">
                              <div class="cursor-pointer svg-icon-height">
                                  <div class="risk-circle low-risk-circle font-14 font_semibold">{{data['low_risk_count']}}</div>
                              </div>
                              <template #popper>
                                  Low Risk
                              </template>
                          </VTooltip>
                          <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="mr12">
                              <div class="cursor-pointer svg-icon-height">
                                  <div class="risk-circle medium-risk-circle font-14 font_semibold">{{data['medium_risk_count']}}</div>
                              </div>
                              <template #popper>
                                  Medium Risk
                              </template>
                          </VTooltip>
                          <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                              <div class="cursor-pointer svg-icon-height">
                                  <div class="risk-circle high-risk-circle font-14 font_semibold">{{data['high_risk_count']}}</div>
                              </div>
                              <template #popper>
                                  High Risk
                              </template>
                          </VTooltip>
                    </div>
                    <!-- <div class="inline-flex items-center justify-center fill-width justify-start-small-medium" v-else>
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="mr12">
                            <div class="cursor-pointer svg-icon-height">
                                <div class="risk-circle low-risk-circle font-14 font_semibold">0</div>
                            </div>
                            <template #popper>
                                This is old history, you can't see risk level for this report
                            </template>
                        </VTooltip>
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="mr12">
                            <div class="cursor-pointer svg-icon-height">
                                <div class="risk-circle medium-risk-circle font-14 font_semibold">0</div>
                            </div>
                            <template #popper>
                                This is old history, you can't see risk level for this report
                            </template>
                        </VTooltip>
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                            <div class="cursor-pointer svg-icon-height">
                                <div class="risk-circle high-risk-circle font-14 font_semibold">0</div>
                            </div>
                            <template #popper>
                                This is old history, you can't see risk level for this report
                            </template>
                        </VTooltip>
                    </div> -->
                </div>
                <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10 inline-flex items-center justify-between scorecard-history-download">
                    <div class="action-sept"></div>
                    <button class="btn-blue-outline btn-left-padding btn-left-white justify-start-small-medium"
                    @click="downloadScorecardHistory(data.id)"
                    :disabled="download_button">
                      <div class="next-arrow-icon pdf-icon"> <pdf-icon></pdf-icon></div> <span>DOWNLOAD</span>
                    </button>
                </div>
            </div>
        </div>
        <div v-if="scorecard_history_data.length === 0 && is_full_page_loader_shown == false" class="">
          <div class="user-detail-text font-14 gray_checkmark--text text-center">
            <no-data-icon></no-data-icon>
            <div class="font-14 text-center blueog--text">No data available.</div>
          </div>
        </div>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>
</template>

<script>
import axios from "axios";
import previousIcon from "../common/icons/previousIcon.vue";
import pdfIcon from '../common/icons/pdfIcon.vue';
import fullPageLoader from "../common/fullPageLoader.vue";
import noDataIcon from '../common/icons/noDataIcon.vue';
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
import moment from "moment-timezone";
import infoIcon from "../common/icons/infoIcon.vue";

export default {
  components: {
    previousIcon,
    pdfIcon,
    fullPageLoader,
    noDataIcon,
    clearDropdownIcon,
    infoIcon
  },
  data() {
    return {
       JS_APP_URL: JS_APP_URL,
       local_selected_location : this.selected_location,
       is_full_page_loader_shown:false,
       scorecard_history_data:[],
       download_button:false,
       filter_risk_level: null,
       has_old_history: 0,
       risk_level_option:[
        {
          "id":"Highest-Lowest","text": "Highest - Lowest"
        },
        {
          "id":"Lowest-Highest","text": "Lowest - Highest"
        },
       ],
    }
  },
  emits: ["change-select-loction", "scorecard-history-page-toggle"],
   props:{
        all_locations: {
            type: Array
        },
        selected_location:{}
    },
    watch: {
      local_selected_location(val) {
         this.$emit('change-select-loction',val);
         this.filter_risk_level = null;
         this.getScorecardHistory()
      },
    },
    mounted() {
      this.getScorecardHistory()
    },
    methods: {
      closeScorecarHistory(){
        this.$emit('scorecard-history-page-toggle')
      },
      getScorecardHistory(){
        this.is_full_page_loader_shown = true;
        axios
        .get(JS_APP_URL + "/scorecard/history", { params: { location_id: this.local_selected_location.id,
         risk_level:(this.filter_risk_level != null)?this.filter_risk_level.id:''} })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            this.scorecard_history_data = response["data"]["data"]["data"];
            this.has_old_history = response["data"]["data"]["has_old_history"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
      },
      downloadScorecardHistory(id){
        this.is_full_page_loader_shown = true;
        this.download_button = true;
         axios
        .post(JS_APP_URL + "/scorecard/download-scorecar-historyd-by-id",{
          scorecard_download_history_id:id,
          timezone:moment.tz.guess()
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            const filePath = response["data"]["data"].split("/");
            const tempFileName = filePath[filePath.length - 1];
            const fileName = tempFileName.split("?")[0];
            axios({
                  url: response["data"]["data"],
                  method: 'GET',
                  responseType: 'blob',
              }).then((response) => {
                  var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                  var fileLink = document.createElement('a');
                  fileLink.href = fileURL;
                  fileLink.setAttribute('download', fileName);
                  document.body.appendChild(fileLink);
                  fileLink.click();
              });
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.download_button = false;
          this.is_full_page_loader_shown = false;
        });
      },
    },
}
</script>

<style>

</style>
