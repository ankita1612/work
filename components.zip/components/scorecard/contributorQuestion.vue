<template>
    <div class="report-training-item relative pb10 mb32 mt30 flex flex-wrap">
      <div class="table-responsive">
        <table class="report-training-table" border="0" cellpadding="4" cellspacing="5">
          <thead>
              <tr>
              <th style="width: 16.66%">Contributor Name </th>
              <th style="width: 16.66%">Company</th>
              <th style="width: 16.66%">Date Sent</th>
              <th style="width: 16.66%">Contributor Answer</th>
              <th style="width: 16.66%"></th>
              </tr>
          </thead>
          <contributor-question-list v-for="(sra_contributor_data, index) in sra_contributor_question_list" :loop_index="index" :sra_contributor_data="sra_contributor_data" @open-modal="toogleSendQuesToContributorModal" :user_company_name="user_company_name"></contributor-question-list>
        </table>
      </div>
    </div>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    <send-question-contributor-modal 
      v-if="is_show_send_question_modal" 
      :question_details="question_details" 
      :current_index="current_index"
      @close-model="closeModalToggle('send_question')" 
      @refresh-list="refreshCloseModalToggle"
      @question-detail="updateQuestionDetails" 
      :location_id="location_id"
      :question_index="question_number">
    </send-question-contributor-modal>
    <send-reminder-question-modal 
      v-if="is_show_send_reminder_modal" 
      :risk_analysis_contributor_question_id="this.sra_cntri_question_id" 
      :current_index="current_index"
      @question-detail="updateQuestionDetails" 
      @close-model="closeModalToggle('send_reminder')" 
      @refresh-list="refreshCloseModalToggle" 
      :location_id="location_id">
    </send-reminder-question-modal>
    <review-question-contributor-modal
      v-if="is_show_review_question_modal" 
      :question_details="question_details" 
      :current_index="current_index"
      @question-detail="updateQuestionDetails" 
      @close-model="closeModalToggle('reviewed_question')" 
      @refresh-list="refreshCloseModalToggle" 
      :location_id="location_id"
      :question_index="question_number"
      :contributor_status="this.contributor_status">
    </review-question-contributor-modal>
    <delete-assigned-contributor-modal
      v-if="is_show_delete_contributor_modal"
      @close-model="closeModalToggle('contributor_delete')"
      :risk_analysis_contributor_question_id="this.sra_cntri_question_id"
      :contributor_status="this.contributor_status"
      @delete-assigned-contributor="deleteAssignedContributor"
    ></delete-assigned-contributor-modal>
  </template>
  
  <script>
  import axios from "axios"
  import toastr from "toastr";
  import "toastr/toastr.scss";
  import NProgress from "nprogress";
  import fullPageLoader from "../common/fullPageLoader.vue";
  import pendingTraining from "../common/icons/pendingTraining.vue";
  import sendQuestionContributorModal from "./sendQuestionContributorModal.vue";
  import sendReminderQuestionModal from "./sendReminderQuestionModal.vue";
  import contributorQuestionList from "./contributorQuestionList.vue";
  import reviewQuestionContributorModal from "./reviewQuestionContributorModal.vue";
  import deleteAssignedContributorModal from "./deleteAssignedContributorModal.vue";
  export default {
      data() {
          return {
              JS_APP_URL: JS_APP_URL,
              employee_type:"",
              is_full_page_loader_shown: false,
              is_show_send_question_modal: false,
              is_show_send_reminder_modal: false,
              is_show_review_question_modal: false,
              is_show_delete_contributor_modal: false,
              employees: [],
              play_video_modal: false,  
              AUTH_USER: AUTH_USER,     
              sra_cntri_question_id:0,
              question_details: [],
              current_index: null,
              contributor_status: '',
          }
      },
      props: {
          sra_contributor_question_list:{},
          user_company_name: String,
          question_id: Number,
          location_id: Number,
          question_number: Number,
      },
     emits: ['close-model', "refresh-modal"],
      components: {
          fullPageLoader,
          sendQuestionContributorModal,
          pendingTraining,
          sendReminderQuestionModal,
          contributorQuestionList,
          reviewQuestionContributorModal,
          deleteAssignedContributorModal,
      },
      watch: {
      },
      mounted() {
      },
      computed:{
      },
      methods: {
        toogleSendQuesToContributorModal(sra_cntri_question_id, status,index, contributor_status='') {
          this.is_full_page_loader_shown = true;
          this.current_index = index;
          if(status == "Assigned") {
            this.sra_cntri_question_id = sra_cntri_question_id;
            NProgress.start();
              axios
              .get(JS_APP_URL + "/scorecard/get-contributor-question-detail",{
                  params: { risk_analysis_contributor_question_id: this.sra_cntri_question_id,
                            question_id: this.question_id,
                            location_id: this.location_id,
                            status: status}
              })
              .then((response) => {
              if (response["data"]["status"] == "Error") {
                  if(response["data"]['data'].length > 0){
                      toastr.error(response["data"]['data'].join('</br>'), "Error");
                  }else{
                      toastr.error(response["data"]["message"], "Error");
                  }
              } else {
                  this.question_details = response["data"]["data"];
                  if(status == "Assigned") {
                    this.is_show_send_question_modal = true;               
                  }
              }
              })
              .catch((error) => {
                  toastr.error(error.response["data"]["message"], "Error");
                  if (error.response.status === 401) {
                      window.location = JS_APP_URL + "/login";
                  }
              })
              .then(() => {
                NProgress.done();
                this.is_full_page_loader_shown = false
              });
          } else if (status == "Pending") {
            this.sra_cntri_question_id = sra_cntri_question_id;
            this.is_show_send_reminder_modal = true;  
            this.is_full_page_loader_shown = false;
          }
          if(status == "Reviewed" || status == "Approved" || status == "Rejected") {
            this.sra_cntri_question_id = sra_cntri_question_id;
            this.contributor_status = status;
            NProgress.start();
              axios
              .get(JS_APP_URL + "/scorecard/get-contributor-question-detail",{
                  params: { risk_analysis_contributor_question_id: this.sra_cntri_question_id,
                            question_id: this.question_id,
                            location_id: this.location_id,
                            status: status }
              })
              .then((response) => {
              if (response["data"]["status"] == "Error") {
                  if(response["data"]['data'].length > 0){
                      toastr.error(response["data"]['data'].join('</br>'), "Error");
                  }else{
                      toastr.error(response["data"]["message"], "Error");
                  }
              } else {
                  this.question_details = response["data"]["data"];
                  this.is_show_review_question_modal = true;               
              }
              })
              .catch((error) => {
                  toastr.error(error.response["data"]["message"], "Error");
                  if (error.response.status === 401) {
                      window.location = JS_APP_URL + "/login";
                  }
              })
              .then(() => {
                NProgress.done();
                this.is_full_page_loader_shown = false
              });
          }
          else if(status == "contributor_delete") {
            this.sra_cntri_question_id = sra_cntri_question_id;
            this.is_show_delete_contributor_modal = true;
            this.is_full_page_loader_shown = false;
            this.contributor_status = contributor_status;
          }
        },
        refreshCloseModalToggle(type) {
          if(type == "send_question") {
            this.is_show_send_question_modal = !this.is_show_send_question_modal;
            this.$emit("refresh-modal");
          } else if(type == "send_reminder") {
            this.is_show_send_reminder_modal = !this.is_show_send_reminder_modal;
            this.$emit("refresh-modal");
          } else if(type == "reviewed_question") {
            this.is_show_review_question_modal = !this.is_show_review_question_modal;
            this.$emit("refresh-modal");
          } else if(type == "contributor_delete") {
            this.is_show_delete_contributor_modal = false;
            this.$emit("refresh-modal");
          }
        },
        closeModalToggle(type) {
          if(type == "send_question") {
            this.is_show_send_question_modal = !this.is_show_send_question_modal;
          } else if(type == "send_reminder") {
            this.is_show_send_reminder_modal = !this.is_show_send_reminder_modal;
          }else if(type == "reviewed_question") {
            this.is_show_review_question_modal = !this.is_show_review_question_modal;            
          } else if(type == "contributor_delete") {
            this.is_show_delete_contributor_modal = false;
          }
        },
        deleteAssignedContributor(sra_cntri_question_id) {
            this.is_full_page_loader_shown = true;
            NProgress.start();
            axios
            .post(JS_APP_URL + "/scorecard/delete-assigned-contributor",{
             risk_analysis_contributor_question_id: sra_cntri_question_id
            })
            .then((response) => {
            if (response["data"]["status"] == "Error") {
                if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
            } else {
                toastr.success(response["data"]["message"], "Success");
                this.refreshCloseModalToggle("contributor_delete");    
            }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
              NProgress.done();
              this.is_full_page_loader_shown = false
            });
        },
        updateQuestionDetails(sra_cntri_question_id,index) {
          this.is_full_page_loader_shown = true;
          NProgress.start();
          axios
          .get(JS_APP_URL + "/scorecard/get-contributor-question-answer-detail",{
              params: { risk_analysis_contributor_question_id: this.sra_cntri_question_id }
          })
          .then((response) => {
          if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
          } else {
            if(this.current_index != null) {
                this.sra_contributor_question_list[index] = response["data"]["data"];
                this.is_show_send_question_modal = false;
                this.is_show_send_reminder_modal = false;
                this.is_show_review_question_modal = false;
                this.current_index = null;         
            }      
          }
          })
          .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                  window.location = JS_APP_URL + "/login";
              }
          })
          .then(() => {
            NProgress.done();
            this.is_full_page_loader_shown = false
          });
        },
      }
  }
  </script>