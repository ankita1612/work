<template>
    <Teleport to="body">
      <transition name="modal">
        <div>
          <div class="modal-mask modal-scrollable">
            <div class="modal-wrapper modal-score-questions animate__animated animate__zoomIn">
              <div class="modal-container">
                  <button v-if="!disable_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                      <close-icon></close-icon>
                  </button>
                <div class="text-center mlr-auto mb5">
                    <img
                    :src="JS_APP_URL + '/images/sra_flag_big.svg'"
                    alt=""
                    title=""
                    class="warning-icon-modal"
                    />
                </div>                
                  <h2 class="font-24 font_semibold blueog--text line-normal mb20 text-center">
                    Ask An SRA Contributor
                  </h2>
                    <h4 class="font-24  blueog--text line-normal mb10 text-center">
                      Q{{question_number+1}}:  <span class="font-italic gray_checkmark--text">{{question_text.trim()}}</span>
                    </h4>
                  <div class="completecase-content mlr-auto">
                    <div class="font-16 text-center gray_checkmark--text line-normal mb25">
                      Select SRA Contributor(s) or User(s) below.<br>
                      After confirming, click <span class="font-italic">SEND</span> to email the <span class="font-italic">SRA Contributor Portal</span>.
                    </div>
                    <div class="flex items-center flex-wrap flex-auto mb20">
                      <div class="row flex-auto justify-center -mx-10">
                        <div class="col-12 col-md-11 px10">
                            <form class="row flex-auto justify-center -mx-10">
                              <div class="col-12 col-md-6 px10">
                                <div class="form-group mb-0 mlr-auto location-dropdon">
                                    <multiselect
                                    :options="sra_contributor_list"
                                    v-model="select_sra_contributor_id"
                                    openDirection="bottom"
                                    track-by="id"
                                    :custom-label="customLabel"
                                    placeholder=""
                                    :multiple="true"
                                    :searchable="true"
                                    :showLabels="false"
                                    :taggable="false"
                                    :close-on-select="false"
                                    :disabled="disable_submit_btn"
                                    @select="checkAllowToUnselect"
                                    @remove="checkAllowToUnselect"
                                    >
                                        <template #noResult>
                                            <div class="multiselect__noResult text-center">No results found</div>
                                        </template>
                                        <template #noOptions>
                                            <div class="multiselect__noOptions text-center">No SRA contributor available</div>
                                        </template>
                                        <template #selection>
                                            <div class="multiselect__tags-wrap" v-if="select_sra_contributor_id.length > 1">
                                                <span class="multiselect__tag">
                                                    <span>{{ select_sra_contributor_id.length }} Contributors Selected</span>
                                                </span>
                                            </div>
                                        </template>
                                    </multiselect>
                                    <label class="label label-select" :class="{ 'label-float': (select_sra_contributor_id.length > 0) }">SRA Contributors</label>                                  
                                </div>
                              </div>
                              <div class="col-12 col-md-6 px10">
                                <div class="form-group mb-0 mlr-auto location-dropdon">
                                    <multiselect
                                    :options="user_list"
                                    v-model="select_users_id"
                                    openDirection="bottom"
                                    track-by="id"
                                    :custom-label="usersLabel"
                                    placeholder=""
                                    :multiple="true"
                                    :searchable="true"
                                    :showLabels="false"
                                    :taggable="false"
                                    :close-on-select="false"
                                    :disabled="disable_submit_btn"
                                    >
                                        <template #noResult>
                                            <div class="multiselect__noResult text-center">No results found</div>
                                        </template>
                                        <template #noOptions>
                                            <div class="multiselect__noOptions text-center">No user available</div>
                                        </template>
                                        <template #selection>
                                            <div class="multiselect__tags-wrap" v-if="select_users_id.length > 1">
                                                <span class="multiselect__tag">
                                                    <span>{{ select_users_id.length }} Users Selected</span>
                                                </span>
                                            </div>
                                        </template>
                                    </multiselect>
                                    <label class="label label-select" :class="{ 'label-float': (select_users_id.length > 0) }">Users</label>                                  
                                </div>
                              </div>
                              <div class="col-12 col-md-12 px10">
                                <div class="flex flex-wrap items-center flex-auto justify-center mt30">
                                  <button type="button" class="btn-cancel-outline mx15 btn-width-120 h-32" v-on:click="closeModal">CANCEL</button>
                                  <button type="button" @click.once="askSRAContributorSubmit" class="btn-primary-outline mx15 btn-width-120 h-32 " :disabled="select_sra_contributor_id.length <= 0 && select_users_id.length <= 0">CONFIRM</button>
                                </div>
                              </div>
                            </form>
                        </div>
                        </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-backdrop"></div>
        </div>
      </transition>
    </Teleport>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </template>
  
  <script scoped>
  import axios from "axios";
  import NProgress from "nprogress";
  import fullPageLoader from "../common/fullPageLoader.vue";
  import toastr from "toastr";
  import "toastr/toastr.scss";
  toastr.options.preventDuplicates = true;
  import { useVuelidate } from '@vuelidate/core';
  import { required, helpers, requiredIf } from "@vuelidate/validators";
  import _ from 'lodash';
  import closeIcon from '../common/icons/closeIcon.vue';
  import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
  
  export default {
    data() {
      return {
        select_sra_contributor_id: [],
        old_select_sra_contributor_id:[],
        select_users_id: [],
        old_select_users_id:[],
        disable_submit_btn:false,
        JS_APP_URL: JS_APP_URL,
        default_select_sra_contributor_ids:[],
        default_select_users_ids:[],
        is_full_page_loader_shown: false,
        contributor_unselected_msg: 'You are now allowed to unselect contributor whose status is either pending, reviewed.',
        check_sra_unassign_available_timer: null,
        check_user_unassign_available_timer: null,
      };
    },
    props: {
        sra_contributor_list: Array,
        user_list: Array,
        question_id: Number,
        location_id: Number,
        question_number: Number,
        risk_analysis_contributor_question: {},        
        question_text: ""
    },    
    emits: ["close-model", "get-updated-doc"],        
    created() {
      document.addEventListener('keyup', (evt) => {
        if (evt.keyCode === 27 && !this.disable_submit_btn) {
          this.$emit("close-model", 'close');
        }
      });
    },
    computed: {
    },
    components: {
      fullPageLoader,
      closeIcon,
      clearDropdownIcon
    },
    methods: {
      checkAllowToUnselect(option, id) {      
      },
      customLabel(option) {
        return `${option.first_name} ${option.last_name}`
      },
      usersLabel(option) {
        return `${option.first_name} ${option.last_name}`
      },
      askSRAContributorSubmit() {            
          var sra_contributor_selected_new = [];
          var users_selected_new = [];

          _.forEach(this.select_sra_contributor_id,(value) => {
            sra_contributor_selected_new.push({"contributor_id": value.id, "contributor_type": "sra_contributor"});
          });
          _.forEach(this.select_users_id,(value) => {
            users_selected_new.push({"contributor_id": value.id, "contributor_type": value.morph_type});
          });
          let mergedArray = [...sra_contributor_selected_new, ...users_selected_new];          
          this.disable_submit_btn =true;
          this.is_full_page_loader_shown = true;
            NProgress.start();
            axios
            .post(JS_APP_URL + "/scorecard/save-contributors",{
                contributors_list: mergedArray,
                question_id: this.question_id,
                location_id: this.location_id
            })
            .then((response) => {
            if (response["data"]["status"] == "Error") {
                if(response["data"]['data'].length > 0){
                    toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                    toastr.error(response["data"]["message"], "Error");
                }
            } else {
                toastr.success(response["data"]["message"], "Success");                
                setTimeout(() => {
                    this.$emit("close-model", 'refresh');
                }, 100);
            }
            })
            .catch((error) => {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(() => {
            NProgress.done();
            this.is_full_page_loader_shown = false
            this.disable_submit_btn =false;
            });        
      },
       closeModal() {
        this.$emit("close-model", 'close');
      },
    },
  };
  </script>
  