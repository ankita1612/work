<template>
    <Teleport to="body">
      <transition name="modal">
        <div>
          <div class="modal-mask modal-scrollable">
            <div class="modal-wrapper modal-score-questions animate__animated animate__zoomIn">
              <div class="modal-container">
                  <button v-if="!disable_submit_btn" v-on:click="closeModal(question_details.risk_analysis_contributor_question[0].is_review_read, question_details.risk_analysis_contributor_question[0].id)" class="cursor-pointer modal-close">
                      <close-icon></close-icon>
                  </button>
                <div class="text-center mlr-auto mb5">
                    <img
                    :src="JS_APP_URL + '/images/sra_flag_big.svg'"
                    alt=""
                    title=""
                    class="warning-icon-modal"
                    />
                </div>                  
                  <h2 class="font-20 font_semibold blueog--text line-normal mb30 text-center">
                    Review SRA Contributor Answer?
                  </h2>
                  <div class="text-left mlr-auto col-11">
                    <h4 class="font-20  blueog--text line-normal mb20">
                      <span class="font_semibold"> Contributor:</span> <span class="gray_checkmark--text">{{ question_details.risk_analysis_contributor_question[0].contributor_user_acntuser.first_name }} {{ question_details.risk_analysis_contributor_question[0].contributor_user_acntuser.last_name }}</span>
                    </h4>
                    <h4 class="font-20  blueog--text line-normal mb20">
                      <span class="font_semibold"> Q{{ question_index+1 }}:</span> <span class="font-italic gray_checkmark--text">{{ question_details.question.trim() }}</span>
                    </h4>
                    <h4 class="font-20  blueog--text line-normal mb20">
                      <span class="font_semibold"> Answer: </span> 
                      <span v-for="(attemptQuestionAnswer, index) in question_details.risk_analysis_contributor_question[0].contributor_attempted_question_answer" :key="index"> 
                        <span v-if="attemptQuestionAnswer.contributor_answer_content" class="font-italic gray_checkmark--text">
                          {{ attemptQuestionAnswer.contributor_answer_content.answer }}<span v-if="index !== question_details.risk_analysis_contributor_question[0].contributor_attempted_question_answer.length - 1">, </span>
                        </span>
                        <span v-else class="font-italic gray_checkmark--text"> {{ attemptQuestionAnswer.answer }}</span>
                      </span>
                    </h4>
                    <div class="form-group gray-bg-input mb-0">
                      <textarea rows="3" cols="50" class="comment-textarea form-input font-italic contributor-form-input" maxlength="1000" spellcheck="false" readonly>{{ question_details.risk_analysis_contributor_question[0].notes }}</textarea>
                      <label class="label label-select label-float">Notes</label>
                    </div>
                  </div>
                  <div class="completecase-content mlr-auto">
                    <div class="flex items-center flex-wrap flex-auto mb20">
                      <div class="row flex-auto justify-center -mx-10">
                        <div class="col-12 col-md-12 px10">                        
                          <div v-if="contributor_status=='Reviewed'" class="flex flex-wrap items-center flex-auto justify-center mt20">
                            <button class="btn-cancel-outline mx15 btn-width-120 h-32" @click.once="approveRejectAnswer('Rejected')">Reject</button>
                            <button class="btn-primary-outline mx15 btn-width-120 h-32 " @click.once="approveRejectAnswer('Approved')">Approve</button>
                            </div>
                          <div v-else-if="contributor_status=='Approved'" class="flex flex-wrap items-center flex-auto justify-center mt20">
                            <button class="btn-cancel-outline mx15 btn-width-120 h-32" @click.once="approveRejectAnswer('Rejected')">Reject</button>
                            <button class="btn-primary mx15 btn-width-120 h-32 ">Approve</button>
                          </div>                                               
                          <div v-else-if="contributor_status=='Rejected'" class="flex flex-wrap items-center flex-auto justify-center mt20">
                            <button class="btn-cancel mx15 btn-width-120 h-32">Reject</button>
                            <button class="btn-primary-outline mx15 btn-width-120 h-32 " @click.once="approveRejectAnswer('Approved')">Approve</button>
                          </div>                                               
                        </div>
                        </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-backdrop"></div>
        </div>
      </transition>
    </Teleport>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </template>
  
  <script scoped>
  import axios from "axios";
  import toastr from "toastr";
  import "toastr/toastr.scss";
  toastr.options.preventDuplicates = true;
  import _ from 'lodash';
  import closeIcon from '../common/icons/closeIcon.vue';
  import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
  import fullPageLoader from "../common/fullPageLoader.vue";
  
  export default {
    data() {
      return {
        disable_submit_btn:false,
        JS_APP_URL: JS_APP_URL,        
        is_full_page_loader_shown: false,        
      };
    },
    props: {
        question_details: Object,
        sra_contributor_list: Array,
        user_list: Array,
        question_id: Number,
        location_id: Number,
        current_index: Number,
        question_index: Number,
        contributor_status: String
    },
    mounted() { 
      if (this.question_details.risk_analysis_contributor_question[0].contributor_attempted_question_answer == undefined)
      {
        window.location = JS_APP_URL + "/dashboard"; 
      }
    },
    emits: ["close-model", "refresh-list","question-detail"],
    created() {
      document.addEventListener('keyup', (evt) => {
        if (evt.keyCode === 27 && !this.disable_submit_btn) {
          this.$emit("close-model", false);
        }
      });      
    },
    computed: {
    },
    components: {
      closeIcon,
      clearDropdownIcon,
      fullPageLoader
    },
    methods: {
      approveRejectAnswer(contri_answer_status) {
        this.is_full_page_loader_shown = true;
        let answer_id = this.question_details.risk_analysis_contributor_question[0].contributor_attempted_question_answer.map((item) => {
          return item.answer_id;
        });
        axios
        .post(JS_APP_URL + "/scorecard/approve-reject-contributor-answer",{
            attempted_question_id: this.question_details.risk_analysis_attempted_question['0'].id,
            answer_id: answer_id,
            answer: this.question_details.risk_analysis_contributor_question[0].contributor_attempted_question_answer[0].answer ? this.question_details.risk_analysis_contributor_question[0].contributor_attempted_question_answer[0].answer : null,           
            contri_answer_status: contri_answer_status,
            risk_analysis_contributor_question_id:  this.question_details.risk_analysis_contributor_question['0'].id,   
        })
        .then((response) => {
        if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
        } else {
            toastr.success(response["data"]["message"], "Success");  
            if (contri_answer_status == "Approved") {
              setTimeout(() => {
                  this.$emit("refresh-list", "reviewed_question");
              }, 100);
            } else {
              this.$emit("question-detail",this.risk_analysis_contributor_question_id,this.current_index);
            }                   
        }
        })
        .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
                window.location = JS_APP_URL + "/login";
            }
        })
        .then(() => {
          this.disable_submit_btn =false;
          this.is_full_page_loader_shown = false;
        });
       
      },
      closeModal(is_review_read, risk_analysis_contributor_question_id) {      
        this.$emit("close-model", "reviewQuestionContributorModal");
        if(!is_review_read) {
          this.$emit("question-detail",risk_analysis_contributor_question_id,this.current_index);
        }
      },
    },
  };
  </script>
  