<template>
    <Teleport to="body">
      <transition name="modal">
          <div class="modal-mask">
              <div class="modal-wrapper animate__animated animate__zoomIn">
                  <div class="modal-container Whoa-modal">
                      <button
                          v-if="!is_btn_disabled"
                          v-on:click="closeModal"
                          class="cursor-pointer modal-close"
                      >
                          <close-icon></close-icon>
                      </button>
                      <div class="text-center mlr-auto mb30 pt20">
                          <img
                              :src="JS_APP_URL + '/images/warning.svg'"
                              alt=""
                              title=""
                              class="warning-icon-modal"
                          />
                      </div>
                      <h2
                          class="font-24 font_semibold blueog--text line-normal text-center mb20"
                          v-if="contributor_status=='Pending'"
                      >
                          Delete Pending Contributor Question?
                      </h2>
                      <h2
                          class="font-24 font_semibold blueog--text line-normal text-center mb20"
                          v-else
                      >
                          Whoa!
                      </h2>
                      <p
                          class="text-center font-16 gray_checkmark--text line-normal mb30"
                          v-if="contributor_status=='Pending'"
                      >
                          Deleting a question that is pending a response will inactivate the link to the <span class="font-italic">SRA Contributor Portal</span> that was previously emailed to this Contributor.
                      </p>
                      <p
                          class="text-center font-16 gray_checkmark--text line-normal mb30"
                          v-else
                      >
                          Are you sure you want to remove this SRA Contributor?
                      </p>
                      <div
                          class="flex flex-wrap items-center justify-center pb40"
                      >
                          <button
                              :disabled="is_btn_disabled"
                              v-on:click="closeModal"
                              class="btn-cancel-outline mx5"
                          >
                              CANCEL
                          </button>
                          <button
                              v-if="contributor_status=='Pending'"
                              :disabled="is_btn_disabled"
                              v-on:click.once="deleteAssignedContributorModal"
                              class="btn-primary btn-width-136 mx5 px30 mt-xs-20"
                          >
                              Delete
                          </button>
                          <button
                              v-else
                              :disabled="is_btn_disabled"
                              v-on:click.once="deleteAssignedContributorModal"
                              class="btn-primary btn-width-136 mx5 px30 mt-xs-20"
                          >
                              REMOVE SRA CONTRIBUTOR
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      </transition>
    </Teleport>
  </template>
  
  <script scoped>
  import closeIcon from "../common/icons/closeIcon.vue";
  
  export default {
      props: {
        risk_analysis_contributor_question_id:  Number,
        contributor_status:  String,
      },
      components: { closeIcon },
      data() {
          return {
              is_btn_disabled: false,
              JS_APP_URL: JS_APP_URL,
          };
      },
      emits: ["close-model", "delete-assigned-contributor"],
      methods: {
          closeModal() {
              this.$emit("close-model", false);
          },
          deleteAssignedContributorModal() {
                this.is_btn_disabled= true
                this.$emit("delete-assigned-contributor", this.risk_analysis_contributor_question_id);
          },
      },
      created() {
          document.addEventListener("keydown", (e) => {
              if (e.keyCode == 27 && !this.is_btn_disabled) {
                  this.$emit("close-model", false);
              }
          });
      },
  };
  </script>
  