import { createApp } from 'vue';
import scorecard from "./scorecard.vue";
const app = createApp(scorecard);

import { useVuelidate } from '@vuelidate/core';
import FloatingVue from 'floating-vue'
import 'floating-vue/dist/style.css'
import Multiselect from 'vue-multiselect';
//import infiniteScroll from 'vue-infinite-scroll' //it is not useing so commented out
import 'vue-multiselect/dist/vue-multiselect.css';
import moment from 'moment'
import VueMask from '@devindex/vue-mask';

app.use(VueMask);
app.config.productionTip = false
app.config.globalProperties.$filters = {
    formatDate(value) {
        if (value) {
            return moment.utc(String(value)).local().format("MM/DD/YYYY");
        }
    },
    formatTime(value) {
        if (value) {
            return moment.utc(String(value)).local().format("hh:mm A");
        }
    },
}

app.use(FloatingVue);
app.component('multiselect', Multiselect);
app.use(useVuelidate);
// app.use(infiniteScroll)
app.mount("#scorecard_app")
