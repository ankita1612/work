<template>
    <Teleport to="body">
      <transition name="modal">
        <div class="modal-mask">
          <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
                <button v-if="!disable_submit_btn" v-on:click="closeModal" class="cursor-pointer modal-close">
                    <close-icon></close-icon>
                </button>
              <div class="text-center mlr-auto mb15">
                  <img
                  :src="JS_APP_URL + '/images/envelop-upload.svg'"
                  alt=""
                  title=""
                  class="warning-icon-modal"
                  />
              </div>                 
                <h2 class="font-24 font_semibold blueog--text line-normal mb30 text-center">
                  Send a reminder for this SRA question?
                </h2>
                <div class="completecase-content mlr-auto">
                    <div class="font-16 text-center gray_checkmark--text line-normal mb20">
                        Abyde will send an email reminder to your SRA Contributor to review and answer this question.
                    </div>
                  <div class="flex items-center flex-wrap flex-auto mb20">
                    <div class="row flex-auto justify-center -mx-10">
                      <div class="col-12 col-md-12 px10">
                        <form class="fill-width">
                          <div class="checkbox mb10">
                              <input  v-model="send_reminder_all_questions"  class="form-check-input" id='refresher' name="send_reminder_all_questions" type="checkbox" :true-value="'1'" :false-value="'0'"/>
                              <label for="refresher" class="checkbox-label font-16 font-light gray_checkmark--text">Send reminder for all pending questions</label>
                          </div> 
                          <div class="text-center pt10">
                             <button type="button" @click.once="sendReminderSubmit" class="btn-primary-outline mx15  h-32 " >Send reminder</button>
                          </div>
                      </form>
                      </div>
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </transition>
    </Teleport>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </template>
  
  <script scoped>
  import axios from "axios";
  import NProgress from "nprogress";
  import toastr from "toastr";
  import "toastr/toastr.scss";
  toastr.options.preventDuplicates = true;
  import _ from 'lodash';
  import closeIcon from '../common/icons/closeIcon.vue';
  import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
  import fullPageLoader from "../common/fullPageLoader.vue";
  
  export default {
    data() {
      return {
        disable_submit_btn:false,
        JS_APP_URL: JS_APP_URL,
        send_reminder_all_questions: 0,
        is_full_page_loader_shown: false,
      };
    },
    props: {
        risk_analysis_contributor_question_id: Number,
        location_id: Number,
        current_index: Number

    },
    emits: ["close-model", "get-updated-doc", "refresh-list",,"question-detail"],
    created() {
      document.addEventListener('keyup', (evt) => {
        if (evt.keyCode === 27 && !this.disable_submit_btn) {
          this.$emit("close-model", false);
        }
      });
    },
    computed: {
    },
    components: {
        fullPageLoader,
        closeIcon,
        clearDropdownIcon
    },
    methods: {
      sendReminderSubmit() {
          this.is_full_page_loader_shown = true;
          NProgress.start();
          axios
          .post(JS_APP_URL + "/scorecard/send-reminder-to-contributor",{
              risk_analysis_contributor_question_id: this.risk_analysis_contributor_question_id,
              send_all: this.send_reminder_all_questions,
              location_id: this.location_id
          })
          .then((response) => {
          if (response["data"]["status"] == "Error") {
              if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
              }else{
                  toastr.error(response["data"]["message"], "Error");
              }
          } else {
              toastr.success(response["data"]["message"], "Success");   
              if (this.send_reminder_all_questions == 1) {
                setTimeout(() => {
                    this.$emit("refresh-list", "send_reminder");
                }, 100);
              } else {
                this.$emit("question-detail",this.risk_analysis_contributor_question_id,this.current_index);
              }             
          }
          })
          .catch((error) => {
              toastr.error(error.response["data"]["message"], "Error");
              if (error.response.status === 401) {
                  window.location = JS_APP_URL + "/login";
              }
          })
          .then(() => {
          NProgress.done();
          this.disable_submit_btn =false;
          this.is_full_page_loader_shown = false;
          });
      },
       closeModal() {
        this.$emit("close-model", false);
      },
    },
  };
  </script>
  