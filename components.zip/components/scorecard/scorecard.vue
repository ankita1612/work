<template>
  <div>
    <header-after-login></header-after-login>
    <div v-if="scorecard_history_page == true">
      <scorecard-history :all_locations=all_locations :selected_location=selected_location
        @scorecard-history-page-toggle=scorecardHistoryPageToggle
        @change-select-loction=changeSelectLoction></scorecard-history>
    </div>
    <div class="container pt40 pb60" v-else>
      <div class="row flex-auto -mx-10 mb30 items-center justify-center">
        <div class="scorecard-history-button inline-flex flex-wrap mb-sm-10 mb15 mr-auto">
          <button class="btn-blue-outline btn-left-padding mr10" @click="downloadScorecard(selected_location.id)"
            :disabled="download_button">
            <div class="next-arrow-icon pdf-icon">
              <pdf-icon>
              </pdf-icon>
            </div>
            DOWNLOAD
          </button>
        </div>
        <div class="col-12 col-md-8 col-lg-6 col-xl-3 px10 mb15" v-if="all_locations.length > 1">
          <div class="form-group gray-bg-input mb-0 mlr-auto location-dropdon">
            <multiselect class="company-location-select" v-model="selected_location" :options="all_locations"
              label="location_nickname" :taggable="false" :multiple="false" :close-on-select="true" :showLabels="false"
              track-by="id" placeholder="" :allowEmpty="false">
              <template #noResult>
                <div class="multiselect__noResult text-center">
                  No results found
                </div>
              </template>
            </multiselect>
            <label class="label label-select label-float">Location</label>
          </div>
        </div>
        <div class="scorecard-history-button inline-flex flex-wrap mb-sm-10 mb15 ml-auto">
          <button class="btn-blue-outline btn-view-history" @click="scorecardHistoryPageToggle">
            <div class="next-arrow-icon"> <search-icon></search-icon></div> VIEW HISTORY
          </button> 
        </div>
        <div class="col-12 col-md-12 col-lg-12 col-xl-12 px10">
          <div class="flex items-center justify-center flex-wrap">
          <h1
            class="location-dashbaord-title text-center font-24 font_semibold blueog--text line-normal mb0 mb-sm-10 mb-md-10">
            Scorecard</h1>
            <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml6 mb-md-10 mb-sm-10">
              <button @click="PlayExplainerVideoModalToggle('yes')" class="cursor-pointer svg-icon-height dashboard-video-icon mt4">
                <explainer-video-icon></explainer-video-icon>
              </button>
              <template #popper>
                Video Guide
              </template>
           </VTooltip>
          </div>
        </div>
      </div>
      <p class="font-16 font_regular black--text text-center mb26">The Scorecard contains each Security Risk Analysis question, your answer, and an associated risk level. View or change your answer, add comments and view risk, recommendations and action steps for mitigation.</p>

      <div class="row flex-auto -mx-10 items-center justify-end mb28">
        <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10 mb-md-20">
          <div class="flex flex-wrap flex-auto items-center">
            <div class="row -mx-10 items-center flex-auto">
              <div class="col-12 col-md-6 col-lg-5 col-xl-4 px10 mb-md-10 ask-contibutor-col">
                <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="relative">
                  <button class="btn-blue-outline btn-view-history btn-ask-flag" :disabled="this.total_contributor_count == 0" :class="{ 'btn-view-history-active': isAskContributorActive  }" @click="search_question_by_contributor()">
                    <div class="next-arrow-icon ask-flag-icon" > </div> ASK A CONTRIBUTOR
                  </button>  
                  <template #popper>
                        Filter to <span class="font-italic">ASK A CONTRIBUTOR</span> flagged questions.
                    </template>
                </VTooltip>              
              </div>
              <div class="pr10 pb5">
                <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="mx6">
                  <div class="cursor-pointer svg-icon-height">
                    <button type="button" v-on:click="toogleUnsentContributorModal" class="btn-primary-outline  btn-width-120 h-32">Send ({{ send_question_count }})</button>
                  </div>
                  <template #popper>
                    Questions selected for<br> Contributors (not yet sent)
                  </template>
                </VTooltip>
              </div>
              <div class="col-12 col-md-6 col-lg-4 col-xl-4 pr10 pl5 mb-md-10">
                <div class="form-group gray-bg-input mb-0">
                  <multiselect :disabled="this.total_contributor_count == 0" class="" v-model="contributor_status" :options="contributor_question_status" 
                    :taggable="false" :multiple="true" :close-on-select="true" :showLabels="false" placeholder=""
                    :searchable="false"  @update:model-value="getAttemptedQuestionList(selected_location.id)" label="name" track-by="id">
                    <template #noResult>
                        <div class="multiselect__noResult text-center">
                            No results found
                        </div>
                    </template>
                    <template #noOptions>
                        <div class="multiselect__noOptions text-center">
                            No data available
                        </div>
                    </template>
                    <template #selection>
                        <div class="multiselect__tags-wrap" v-if="contributor_status.length > 1">
                            <span class="multiselect__tag">
                            <span>{{ contributor_status.length }}  Status Selected</span>
                            </span>
                        </div>
                    </template>
                  </multiselect>
                  <label class="label label-select font-italic"
                    :class="{ 'label-float': (contributor_status != '') }">Filter by Status</label>
                </div>
              </div>
            </div>
          </div>          
        </div>
        <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10">
          <div class="flex flex-wrap flex-auto items-center">
            <div class="row -mx-10 items-center flex-auto scorecard-filter-row">
              <div class="col-12 col-md-6 col-lg-4 col-xl-4 px10 mb-md-10">
                <div class="form-group gray-bg-input mb-0">
                  <multiselect class="" v-model="selected_category" :options="all_category" label="category_title"
                    :taggable="false" :multiple="true" :close-on-select="true" :showLabels="false" placeholder=""
                    :searchable="false" track-by="id" @update:model-value="getAttemptedQuestionList(selected_location.id)">
                    <template #noResult>
                        <div class="multiselect__noResult text-center">
                            No results found
                        </div>
                    </template>
                    <template #noOptions>
                        <div class="multiselect__noOptions text-center">
                            No data available
                        </div>
                    </template>
                    <template #selection>
                        <div class="multiselect__tags-wrap" v-if="selected_category.length > 1">
                            <span class="multiselect__tag">
                            <span>{{ selected_category.length }}  Categories Selected</span>
                            </span>
                        </div>
                    </template>
                  </multiselect>
                  <label class="label label-select font-italic"
                    :class="{ 'label-float': (selected_category != '') }">Filter by Safeguard</label>
                </div>
              </div>
              <div class="col-12 col-md-6 col-lg-4 col-xl-4 px10 mb-md-10">
                <div class="form-group gray-bg-input mb-0">
                  <multiselect class="scorecard-filter-by-risk" v-model="selected_risk_level" :options="risk_level" :taggable="false"
                    :multiple="true" :close-on-select="true" :showLabels="false" placeholder="" :searchable="false"
                    @update:model-value="getAttemptedQuestionList(selected_location.id)">
                        <template #noResult>
                            <div class="multiselect__noResult text-center">
                                No results found
                            </div>
                        </template>
                        <template #noOptions>
                            <div class="multiselect__noOptions text-center">
                                No data available
                            </div>
                        </template>
                        <template #selection>
                            <div class="multiselect__tags-wrap" v-if="selected_risk_level.length > 1">
                                <span class="multiselect__tag">
                                <span>{{ selected_risk_level.length }}  Risk Level Selected</span>
                                </span>
                            </div>
                        </template>
                  </multiselect>
                  <label class="label label-select font-italic"
                    :class="{ 'label-float': (selected_risk_level != '') }">Filter by Risk Level</label>
                </div>
              </div>
              <div class="col-12 col-md-6 col-lg-4 col-xl-4 px10">
                <div class="form-group mb-0">
                  <input class="form-input form-input-search" v-model.trim="search" id="search" type="text"
                    @input="applySearch()" />
                  <label class="label font-italic" :class="{ 'label-float': search }">Search</label>
                  <div class="search-btn-input">
                    <img :src="JS_APP_URL + '/images/search.svg'" alt="" title="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div v-for="(attempted_question, index) in attempted_question_list" :key="attempted_question.id">
        <scorecard-list :loop_index="index" :attempted_question="attempted_question"
          :selected_location="selected_location" @get-attempted-question="getAttemptedQuestionList" :user_company_name="account_user_company_name" @refresh-list="refreshListAPI"></scorecard-list>
      </div>
      <div v-if="attempted_question_list.length === 0 && is_full_page_loader_shown == false" class="">
        <div class="user-detail-text font-14 gray_checkmark--text text-center">
          <no-data-icon></no-data-icon>
          <div class="font-14 text-center blueog--text">No Question available.</div>
        </div>
      </div>
      <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    </div>

    <play-explainer-video-modal v-if="play_video_modal == true" :video_file="video_file"
      :video_caption_file="video_caption_file" @close-model="PlayExplainerVideoModalToggle"></play-explainer-video-modal>
    <send-all-unsent-contributor v-if="is_show_unsent_modal"
      @close-model="closeModalToggle"
      :unsend_question_count="this.send_question_count"
      :location_id="this.location_id"
      @refresh-list="refreshQuestionsList"></send-all-unsent-contributor>
  </div>
</template>

<script scoped>
import pdfIcon from "../common/icons/pdfIcon.vue";
import searchIcon from "../common/icons/searchIcon.vue";
import axios from "axios";
import toastr from "toastr";
import NProgress from "nprogress";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../common/fullPageLoader.vue";
import scorecardList from "./scorecardList.vue";
import scorecardHistory from "./scorecardHistory.vue";
import noDataIcon from '../common/icons/noDataIcon.vue';
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
import _ from 'lodash';
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import moment from "moment-timezone";
import explainerVideoIcon from "../common/icons/explainerVideoIcon.vue";
import playExplainerVideoModal from "../common/includes/playExplainerVideoModal.vue";
import sendAllUnsentContributor from "./sendAllUnsentContributor.vue";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      all_locations: [],
      selected_location: {},
      is_full_page_loader_shown: false,
      attempted_question_list: [],
      risk_level: [],
      selected_risk_level: "",
      all_category: [],            
      contributor_question_status:[
        { id: 'Assigned', name: 'Send' },
        { id: 'Pending', name: 'Pending' },
        { id: 'Reviewed', name: 'Review' },
        { id: 'Approved', name: 'Approved' },
        { id: 'Rejected', name: 'Rejected' }],
      selected_category: "",
      contributor_status:"",
      search: "",
      download_button: false,
      scorecard_history_page: false,
      APP_ENV: APP_ENV,
      video_file: "hce_explainer_scorecard_final.mp4",  
      video_caption_file: "hce_explainer_scorecard_final.vtt",  
      play_video_modal: false,
      account_user_company_name: "",
      show_questions_who_has_contributors: 0,
      isAskContributorActive : false,
      total_contributor_count: 0,
      send_question_count: 0,
      is_show_unsent_modal: false,
      location_id:0,
      AUTH_USER: AUTH_USER,
    };
  },
  components: {
    pdfIcon,
    searchIcon,
    fullPageLoader,
    scorecardList,
    noDataIcon,
    clearDropdownIcon,
    scorecardHistory,
    headerAfterLogin,
    explainerVideoIcon,
    playExplainerVideoModal,
    sendAllUnsentContributor
  },
  watch: {
    selected_location(val) {
      this.reetAllFilters();
      this.getAttemptedQuestionList(val.id);
    },
    attempted_question_list(val) {
      if (val.length == 0) {
        this.download_button = true
      } else {
        this.download_button = false
      }
    }
  },

  mounted() {
    this.loadLocationNicknameList();
    this.getCategoryList();
    // this.getAttemptedQuestionList(parseInt(JS_LOCATION_ID));
  },
  created() { },
  methods: {
    createSignUrl(file_name,file_type,file_time = 600){
      var request = {
          params: {
              file_path: 'explainer_videos/'+ file_name,
              file_exp_time: file_time
          }
      }
      axios
      .get(JS_APP_URL + "/general/get-sign-url",request)
      .then((response) => {
          if (response["data"]["status"] == "Success") {
              if(file_type == 'poster_file'){
                  this.video_poster_file_url = response.data.data;
              }
              if(file_type == 'video_file'){
                  this.video_file_url = response.data.data;
              }
              if(file_type == 'vtt_file'){
                  this.vtt_file_url = response.data.data;
              }
          }
      })
      .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
          }
      });
    },
    PlayExplainerVideoModalToggle() {
      if (this.play_video_modal == true) {
        this.play_video_modal = false;
      } else {
        this.play_video_modal = true;
      }
    },
    reetAllFilters() {
      this.selected_category = "";
      this.contributor_status = "";
      this.search = "";
      this.selected_risk_level = "";
      this.show_questions_who_has_contributors = 0;
      this.isAskContributorActive = false;
      this.total_contributor_count = 0;
    },
    loadLocationNicknameList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/general/get-assigned-location-list")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.all_locations = response["data"]["data"];
            this.selected_location = this.all_locations.find(
              (object) => object.id === parseInt(JS_LOCATION_ID)
            );
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {

        });
    },
    applySearch() {
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      this.timer = setTimeout(() => {
        this.getAttemptedQuestionList(this.selected_location.id)
      }, 500);
    },
    getAttemptedQuestionList(location_id) {
      this.is_full_page_loader_shown = true;
      let category_ids = ""
      let contributor_status_arr = []      
      if (this.selected_category != "") {
        category_ids = _.map(this.selected_category, "id");
      }
      if (this.contributor_status != "") {
        contributor_status_arr = _.map(this.contributor_status, "id");
      }
      
      axios
        .post(JS_APP_URL + "/scorecard/attempted-question-list", {
          location_id: location_id,
          category_id: category_ids,
          risk_level: this.selected_risk_level,
          search: this.search,
          show_questions_who_has_contributors: this.show_questions_who_has_contributors,
          contributor_status: contributor_status_arr,
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if (response["data"]["message"] == "Complete SRA first") {
              window.location = JS_APP_URL + "/dashboard";
            } else {
              if (response["data"]['data'].length > 0) {
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              } else {
                toastr.error(response["data"]["message"], "Error");
              }
            }
            if (location_id != parseInt(JS_LOCATION_ID)) {
              this.getAttemptedQuestionList(parseInt(JS_LOCATION_ID))
            }
          } else {
            this.risk_level = response["data"]["data"]["risk_levels"];
            this.attempted_question_list =
              response["data"]["data"]["attempted_questions"];
            this.account_user_company_name = response["data"]["data"]["location_company_name"];
            this.total_contributor_count = response["data"]["data"]["total_contributors"];
            this.send_question_count = response["data"]["data"]["send_question_count"];
            this.location_id = location_id;
            setTimeout(() => {
              if(APP_ENV == 'production') {
                var metadata = {
                  first_scorecard_added: response['data']['data']['first_time_scorecard_added'],
                  location_id: location_id,
                  location_nickname: this.selected_location.location_nickname,
                  user_locations_number: this.all_locations.length
                };
                if(AUTH_USER.is_sra_user == 0) {
                  Intercom('trackEvent', 'scorecard-status', metadata);
                }
              }
            }, 1000);
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });


    },
    refreshListAPI(location_id) {
      this.getAttemptedQuestionList(location_id);
    },
    getCategoryList() {
      axios
        .get(JS_APP_URL + "/scorecard/category-list")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.all_category = response["data"]["data"];            
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {

        });
    },
    downloadScorecard(location_id) {
      this.is_full_page_loader_shown = true;
      this.download_button = true
      let category_ids = ""
      let contributor_status_arr = []
      if (this.selected_category != "") {
        category_ids = _.map(this.selected_category, "id");
      }
      if (this.contributor_status != "") {
        contributor_status_arr = _.map(this.contributor_status, "id");
      }
      axios
        .post(JS_APP_URL + "/scorecard/download", {
          location_id: location_id,
          category_id: category_ids,
          risk_level: this.selected_risk_level,
          search: this.search,
          timezone: moment.tz.guess(),
          show_questions_who_has_contributors: this.show_questions_who_has_contributors,
          contributor_status: contributor_status_arr,
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if (response["data"]['data'].length > 0) {
              toastr.error(response["data"]['data'].join('</br>'), "Error");
            } else {
              toastr.error(response["data"]["message"], "Error");
            }
            this.download_button = false
            this.is_full_page_loader_shown = false;
          } else {
            const filePath = response["data"]["data"].split("/");
            const tempFileName = filePath[filePath.length - 1];
            const fileName = tempFileName.split("?")[0];
            axios({
              url: response["data"]["data"],
              method: 'GET',
              responseType: 'blob',
            }).then((response) => {
              var fileURL = window.URL.createObjectURL(new Blob([response.data]));
              var fileLink = document.createElement('a');
              fileLink.href = fileURL;
              fileLink.setAttribute('download', fileName);
              document.body.appendChild(fileLink);
              fileLink.click();
              this.download_button = false
              this.is_full_page_loader_shown = false;
            });
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
          this.download_button = false
          this.is_full_page_loader_shown = false;
        });
    },
    scorecardHistoryPageToggle() {
      if (this.scorecard_history_page == true) {
        this.scorecard_history_page = false
      } else {
        this.scorecard_history_page = true
      }
    },
    changeSelectLoction(location) {
      this.selected_location = location
    },
    search_question_by_contributor()
    { 
      this.isAskContributorActive = !this.isAskContributorActive
      this.show_questions_who_has_contributors = (this.show_questions_who_has_contributors == 1 ? 0 : 1 );
      this.getAttemptedQuestionList(this.selected_location.id);
    },
    toogleUnsentContributorModal() {
      this.is_show_unsent_modal = true;
    },
    closeModalToggle() {
        this.is_show_unsent_modal = !this.is_show_unsent_modal;
    },
    refreshQuestionsList(location_id) {
      this.is_show_unsent_modal = false;
      this.getAttemptedQuestionList(location_id);
    }
  },
  
};
</script>

<style></style>
