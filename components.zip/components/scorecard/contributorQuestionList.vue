<template>
    <tbody>
        <tr>
            <td>
                <div><span class="font-italic"><i>{{sra_contributor_data.contributor_user_acntuser.first_name}} {{ sra_contributor_data.contributor_user_acntuser.last_name }}<span v-if="sra_contributor_data.contributor_user_acntuser.deleted_at != null">(Deleted)</span></i></span></div>
            </td>
            <td class="font-italic"><span v-if="sra_contributor_data.contributor_user_acntuser.company_name">{{sra_contributor_data.contributor_user_acntuser.company_name}}</span>
                <span v-else>{{ this.user_company_name }}</span>
            </td>
            <td><span v-if="sra_contributor_data.invite_sent_date">{{ $filters.formatDate(sra_contributor_data.invite_sent_date) }}</span> 
                <span v-else>N/A</span>
            </td>
            <td class="font-italic"><span v-if="sra_contributor_data.contributor_attempted_question_answer.length > 0"> <span v-for="(answer_details, index) in sra_contributor_data.contributor_attempted_question_answer" :key="index"><span v-if="answer_details.contributor_answer_content">{{answer_details.contributor_answer_content.answer}}<span v-if="index !== sra_contributor_data.contributor_attempted_question_answer.length - 1">, </span></span> <span v-else>{{answer_details.answer}}</span> </span>  </span>
                <span v-else> - </span>
            </td>
            <td class="">
                <div class="flex flex-wrap items-center justify-center justify-start-small-medium contributor-action-buttons">
                     
                <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml7 relative">
                    <span class="scorcard-contributor-dot" v-if="sra_contributor_data.status == 'Reviewed' && sra_contributor_data.is_review_read == 0"></span>
                    <button  type="button" class="action-icon-btn action-btn-blue cursor-pointer" 
                        :class="{'send-action-btn' : sra_contributor_data.status == 'Assigned' || sra_contributor_data.status === 'Approved',
                                'pending-action-btn' : sra_contributor_data.status == 'Pending',
                                'review-action-btn' : sra_contributor_data.status == 'Reviewed',
                                'rejected-action-btn' : sra_contributor_data.status == 'Rejected'
                         }"
                         v-on:click="toogleSendQuesToContributorModal(sra_contributor_data.id, sra_contributor_data.status)">
                        <span  class="pending-svg-icon inline-flex items-center justify-center" v-if="sra_contributor_data.status == 'Assigned'"><send-icon></send-icon></span>
                        <span  class="pending-svg-icon inline-flex items-center justify-center" v-else-if="sra_contributor_data.status == 'Pending'"><pendingfile-icon></pendingfile-icon></span>
                        <span  class="pending-svg-icon inline-flex items-center justify-center" v-else-if="sra_contributor_data.status == 'Reviewed'"><review-icon></review-icon></span>
                        <span  class="pending-svg-icon inline-flex items-center justify-center" v-else-if="sra_contributor_data.status == 'Approved'"><approved-icon></approved-icon></span>
                        <span  class="pending-svg-icon inline-flex items-center justify-center" v-else-if="sra_contributor_data.status == 'Rejected'"><rejected-icon></rejected-icon></span>
                    </button>
                    <template #popper>
                        <span v-if="sra_contributor_data.status == 'Assigned'">Send Question to Contributor</span>
                        <span v-else-if="sra_contributor_data.status == 'Pending'">Send Reminder to Contributor</span>
                        <span v-else-if="sra_contributor_data.status == 'Reviewed'">Review Contributor's Answer</span>
                        <span v-else-if="sra_contributor_data.status == 'Approved'">Answer Approved</span>
                        <span v-else-if="sra_contributor_data.status == 'Rejected'">Answer Rejected</span>
                    </template>
                </VTooltip> 
                <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml7">
                    <button  type="button" class="delete-location-btn cursor-pointer"
                    :disabled="sra_contributor_data.status == 'Reviewed'"
                    v-on:click="toogleSendQuesToContributorModal(sra_contributor_data.id, 'contributor_delete', sra_contributor_data.status)">
                        <img :src="JS_APP_URL +'/images/bin.svg'" alt="" title="" class="mlr-auto">
                    </button>
                    <template #popper>
                        Delete
                    </template>
                </VTooltip>                                                                                                     
                </div>
            </td>
        </tr>            
        </tbody>
  </template>
  
  <script>
  import pendingTraining from "../common/icons/pendingTraining.vue";
import sendIcon from "../common/icons/sendIcon.vue";
import pendingfileIcon from "../common/icons/pendingfileIcon.vue"
import reviewIcon from "../common/icons/reviewIcon.vue"
import rejectedIcon from "../common/icons/rejectedIcon.vue"
import approvedIcon from "../common/icons/approvedIcon.vue"
  export default {
      data() {
          return {
              JS_APP_URL: JS_APP_URL,
              is_full_page_loader_shown: false,
              AUTH_USER: AUTH_USER,     
              sra_cntri_question_id:0,
          }
      },
      props: {
          sra_contributor_data:{},
          user_company_name: String,
          question_id: Number,
          location_id: Number,
          loop_index: Number,
      },
     emits: ['close-model', "open-modal"],
      components: {          
          pendingTraining,
          pendingfileIcon,
          sendIcon,
          reviewIcon,
          rejectedIcon,
          approvedIcon
      },
      watch: {
      },
      mounted() {
      },
      computed:{
      },
      methods: {
        toogleSendQuesToContributorModal(sra_cntri_question_id, status, contributor_status = '') {
            this.$emit("open-modal", sra_cntri_question_id, status,this.loop_index, contributor_status);
        },
      }
  }
  </script>