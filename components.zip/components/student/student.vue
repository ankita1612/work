<template>
    <div>
        <header-after-login></header-after-login>
        <div class="container pt30 pb60">
            <h1 class="page-center-title text-center font-24 font_semibold blueog--text line-normal mb40">Students</h1>

            <filter-student :key="filter_component_key" :all_class_list="all_class_list"
                :is_add_student_shown="is_add_student_shown" :is_refresh_btn_shown="is_refresh_btn_shown"
                :sample_import_file_link="sample_import_file_link" @add-student-form-toggle="addStudentFormToggle"
                @apply-filter="applyFilter" @reset-all-filter="resetAllFilter" @load-student-list="loadStudentList" @open-import-modal="openCloseImportModal">
            </filter-student>

            <transition name="simple-fade-transition">
                <add-student v-if="is_add_student_shown" :all_class_list="all_class_list" :all_location_list="all_location_list"
                    @add-student-form-toggle="addStudentFormToggle" @load-student-list="loadStudentList"
                    @reset-all-filter="resetAllFilter"></add-student>
            </transition>

                <student-item v-for="(student_item, index) in student_list" v-bind:key="index" :student_item="student_item"
                    :all_class_list="all_class_list"
                    :all_location_list="all_location_list"
                    @load-student-list="loadStudentList" @deleted-student="deleteStudent"
                    @updated-student="updatedStudent"></student-item>
                <div v-if="!is_full_page_loader_shown && student_list.length === 0" class="">
                    <div class="user-detail-text font-14 gray_checkmark--text text-center">
                        <no-data-icon></no-data-icon>
                        <div class="font-14 text-center blueog--text">No student(s) available.</div>
                    </div>
                </div>
            <InfiniteLoading @infinite="loadStudentList(false)" />

            <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>

        </div>
            <import-error-modal 
                v-if="is_import_error_modal"
                :import_errors="import_errors_data"
                @close-model="openCloseImportModal"
            />
    </div>
</template>
<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from '../common/fullPageLoader.vue';
import addStudent from "./addStudent.vue"
import filterStudent from "./filterStudent.vue"
import studentItem from "./studentItem.vue"
import noDataIcon from '../common/icons/noDataIcon.vue';
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import importErrorModal from "../common/includes/importErrorModal.vue";
import _ from "lodash";

export default {
    data() {
        return {
            JS_APP_URL: JS_APP_URL,
            student_list: [],
            all_class_list: [],
            all_location_list: [],
            filter_by_class: [],
            is_full_page_loader_shown: false,
            is_add_student_shown: false,
            is_refresh_btn_shown: false,
            sample_import_file_link: '',
            sort_by: '',
            sort_by_dir: '',
            search_query: "",
            filter_component_key: Math.random(),
            per_page_records: 10,
            current_page: 1,
            is_list_loading: false,
            total_page: 1,
            is_import_error_modal: false,
            import_errors_data: [],
            call_ajax: 1
        };
    },
    components: {
        addStudent,
        filterStudent,
        studentItem,
        fullPageLoader,
        noDataIcon,
        headerAfterLogin,
        importErrorModal
    },
    validations: {
    },
    mounted() {
        this.loadLocationList()
        this.loadClassList();
    },
    watch: {
    },
    computed: {

    },
    methods: {
        loadLocationList() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/general/get-student-module-location-list")
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        this.all_location_list = response["data"]["data"];
                        if (this.all_location_list.length == 0) {
                            window.location = JS_APP_URL + "/dashboard";
                        }
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                });
        },
        loadClassList() {
            this.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/student/get-student-class-list")
                .then((response) => {
                    if (response["data"]["status"] == "Success") {
                        this.all_class_list = response["data"]["data"];
                    }
                })
                .catch((error) => {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(() => {
                });
        },
        addStudentFormToggle(status = true) {
            this.is_add_student_shown = status;
        },
        applyFilter(search_params = {}) {
            this.filter_by_class = search_params.filter_by_class;
            this.sort_by = search_params.sort_by;
            this.sort_by_dir = search_params.sort_by_dir;
            this.search_query = search_params.search_query;
            setTimeout(() => {
                this.loadStudentList(true);
            }, 100);
        },
        resetAllFilter() {
            this.sort_by = '';
            this.sort_by_dir = '';
            this.filter_by_class = [];
            this.search_query = "";
            this.filter_component_key = Math.random();
        },
        loadStudentList(need_pagination_reset = false) {
            if (need_pagination_reset) {
                this.current_page = 1;
                this.total_page = 1;
                this.student_list = [];
            }
            if (this.current_page <= this.total_page && this.call_ajax == 1) {
                this.is_list_loading = true;
                this.is_full_page_loader_shown = true;
                this.call_ajax = 0;
                axios
                    .post(JS_APP_URL + "/student/get-student-list", {
                        filter_by_class: _.map(this.filter_by_class, 'id'),
                        sort_by: this.sort_by,
                        sort_by_dir: this.sort_by_dir,
                        search_query: this.search_query,
                        per_page: this.per_page_records,
                        page: this.current_page
                    })
                    .then((response) => {
                        if (response["data"]["status"] == "Success") {
                            var student_data = response["data"]["data"]['student_list'];
                            this.sample_import_file_link = response["data"]["data"]['sample_import_file_link'];
                            this.student_list.push(...student_data.data);
                            this.total_page = student_data.last_page;
                            if (this.student_list.length == 0 && this.search_query == '' && this.filter_by_class.length == 0 && this.sort_by == '') {
                                this.is_add_student_shown = true;
                            }
                            this.current_page = this.current_page + 1;
                            this.is_list_loading = false;
                            this.is_refresh_btn_shown = false;
                        }
                    })
                    .catch((error) => {
                        toastr.error(error.response["data"]["message"], "Error");
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(() => {
                        setTimeout(() => {
                            this.call_ajax = 1;
                            this.is_full_page_loader_shown = false;
                        }, 100);
                    });
            }
        },
        deleteStudent(student_id = '') {
            if (student_id) {
                var found_index = _.findIndex(this.student_list, (o) => { return o.id === student_id; });
                if (found_index >= 0) {
                    this.student_list.splice(found_index, 1);
                    if (this.student_list.length == 0) {
                        this.showRefreshListButton();
                    }
                }
            }
        },
        updatedStudent(student_updated = {}) {
            if (!_.isEmpty(student_updated)) {
                var found_index = _.findIndex(this.student_list, (o) => { return o.id === student_updated.id; });
                if (found_index >= 0) {
                    this.student_list[found_index] = student_updated;
                    this.showRefreshListButton();
                }
            }
        },
        showRefreshListButton() {
            if (this.sort_by != "" || this.filter_by_class.length > 0 || this.search_query != "") {
                this.is_refresh_btn_shown = true;
            }
        },
        openCloseImportModal(import_errors) {
            if(!this.is_import_error_modal) {
                this.is_import_error_modal = true
                this.import_errors_data = import_errors;
            } else {
                this.is_import_error_modal = false
            }
        },
    }
};
</script>