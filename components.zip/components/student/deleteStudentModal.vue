<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button v-if="!is_btn_disabled" v-on:click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb30 pt20">
              <img :src="JS_APP_URL + '/images/warning.svg'" alt="" title="" class="warning-icon-modal" />
            </div>
            <h2
              class="
                font-24 font_semibold blueog--text line-normal text-center mb20
              "
            >
              Whoa!
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">Are you sure you want to delete this Student? As a reminder, their information will be saved in your <i>Abyde Drive - Archive.</i></p>
            <div class="flex flex-wrap items-center justify-center pb40">
                <button :disabled="is_btn_disabled" v-on:click="closeModal" class="btn-cancel-outline mx5">CANCEL</button>
                <button :disabled="is_btn_disabled" v-on:click.once="deleteStudentSubmit" class="btn-primary btn-width-136 mx5 px30 mt-xs-20">YES DELETE!</button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script>
import closeIcon from '../common/icons/closeIcon.vue';

export default {
  props: {
    student_id:{
      type: Number,
       default: () => 0
    }
  },
  emits: ["close-model", "delete-student"],
  components:{closeIcon},
  data() {
    return {
      is_btn_disabled: false,
      JS_APP_URL: JS_APP_URL,
    };
  },
  methods: {
    closeModal() {
      this.$emit("close-model", false);
    },
    deleteStudentSubmit () {
      this.is_btn_disabled = true;
      this.$emit("delete-student");
    },
  },
  created () {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !this.is_btn_disabled) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
