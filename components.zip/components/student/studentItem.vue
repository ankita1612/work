<template>
  <div>
    <transition name="simple-fade-transition" mode="out-in">
      <div v-if="!is_student_editing" key="saved" class="user-detail-card py10 px15 light mb15">
        <div class="row flex-auto -mx-10 items-center">
          <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10">
            <div class="row flex-auto -mx-10">
              <div class="col-12 col-md-6 col-lg-6 col-xl-7 px10">
                <div class="user-detail-text font-14 gray_checkmark--text mb10" v-text="student_item.first_name"></div>
              </div>
              <div class="col-12 col-md-6 col-lg-6 col-xl-5 px10">
                <div class="user-detail-text font-14 gray_checkmark--text mb10" v-text="student_item.last_name"></div>
              </div>
              <div class="col-12 col-md-6 col-lg-6 col-xl-7 px10">
                <div class="user-detail-text font-14 gray_checkmark--text" v-text="student_item.email"></div>
              </div>
              <div class="col-12 col-md-6 col-lg-6 col-xl-5 px10">
                <div class="user-detail-text font-14 gray_checkmark--text" v-text="student_item.phone_number"></div>
              </div>
            </div>
          </div>
          <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10">
            <div class="row flex-auto -mx-10 items-center">
              <div class="col-12 col-sm-6 col-md-8 col-lg-6 col-xl-8 px10">
                <div class="flex items-center justify-between student-location-icon">
                  <div class="flex flex-auto flex-wrap items-center">
                    <div class="col-12 col-sm-6 px4">
                      <div class="user-detail-text font-12 gray_checkmark--text text-center uppercase word-break text-truncate white-no-wrap tuncate-location-width"
                        v-if="student_item.student_primary_work_location && Object.keys(student_item.student_primary_work_location).length > 0 && all_location_list.length > 1"
                        v-text="student_item.student_primary_work_location.location_nickname" :title="student_item.student_primary_work_location.location_nickname"></div>
                    </div>
                    <div class="col-12 col-sm-4 px4">
                      <div class="user-detail-text font-12 gray_checkmark--text text-center uppercase word-break"
                        v-if="student_item.student_class && Object.keys(student_item.student_class).length > 0"
                        v-text="student_item.student_class.class_name"></div>
                    </div>
                    <div class="col-12 col-sm-2 px2 text-center student-key-icon">
                      <button type="button" class="user-location-icon">
                        <VTooltip :triggers="['hover']" :popperTriggers="['hover']">
                          <img :src="JS_APP_URL + '/images/key-employee.svg'" alt="" title="" class="cursor-pointer"
                            width="22" height="22" />
                          <template #popper>
                            <div class="white--text font-12 font_semibold mb2 text-center">Access</div>
                            <div class="text-center">{{
                              student_item.imaging_device_access == 'No' ?
                              'No Imaging Device Access' : 'Imaging Device Access' }} </div>
                            <div class="text-center">{{
                              student_item.full_network_access == 'No' ? 'No Full Network Access' : 'Full Network Access'
                            }} </div>
                            <div class="text-center">{{
                              student_item.full_software_access == 'No' ?
                              'No Full Software Access' : 'Full Software Access' }} </div>
                          </template>
                        </VTooltip>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4 col-lg-6 col-xl-4 px10">

                <div class="flex flex-wrap items-center justify-end user-detail-action">
                  <div class="flex flex-wrap items-center">
                    <div class="action-sept ml20 mr-auto"></div>
                    <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml20">
                      <button @click="downloadAgreement(student_item.id)" type="button"
                        class="action-icon-btn action-btn-blue cursor-pointer complete-action-btn pdf-round-btn">
                        <span
                          class="pending-svg-icon inline-flex items-center justify-center"><pdf-icon></pdf-icon></span>
                      </button>
                      <template #popper>
                        Agreement
                      </template>
                    </VTooltip>
                    <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml7">
                      <button v-on:click="editStudent" type="button"
                        class="action-icon-btn action-btn-blueog cursor-pointer">
                        <img :src="JS_APP_URL + '/images/pencil.svg'" alt="" title="">
                      </button>
                      <template #popper>
                        Edit
                      </template>
                    </VTooltip>
                    <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml7">
                      <button v-on:click="deleteStudentToggle" type="button" class="delete-location-btn cursor-pointer">
                        <img :src="JS_APP_URL + '/images/bin.svg'" alt="" title="" class="mlr-auto">
                      </button>
                      <template #popper>
                        Delete
                      </template>
                    </VTooltip>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div v-else key="editing" class="user-detail-card py20 pb26 px15 light mb15">
        <form @submit.prevent="editStudentSubmit">

          <div class="row flex-auto -mx-10">
            <div class="col-12 col-md-6 col-lg-3 col-xl-3 col-20 px10 mb-md-10 mb-lg-10">
              <div class="form-group mb-0" :class="{ 'form-group--error': v$.first_name.$errors.length }">
                <input class="form-input location-input-box" :class="{ 'form-error': v$.first_name.$errors.length }" type="text"
                  name="first_name" v-model.trim="v$.first_name.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.first_name.$model }">First
                  Name</label>
                <div v-if="v$.first_name.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.first_name.$errors[0].$message }}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10 col-20 mb-md-10 mb-lg-10">
              <div class="form-group mb-0" :class="{ 'form-group--error': v$.last_name.$errors.length }">
                <input class="form-input location-input-box" :class="{ 'form-error': v$.last_name.$errors.length }" type="text"
                  name="last_name" v-model.trim="v$.last_name.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.last_name.$model }">Last
                  Name</label>
                <div v-if="v$.last_name.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.last_name.$errors[0].$message }}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10 col-20 mb-md-10 mb-lg-10">
              <div class="form-group mb-0" :class="{ 'form-group--error': v$.email.$errors.length }">
                <input class="form-input location-input-box" :class="{ 'form-error': v$.email.$errors.length }" type="text"
                  name="email" v-model.trim="v$.email.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.email.$model }">Email</label>
                <div v-if="v$.email.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.email.$errors[0].$message }}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3 col-xl-3 px10 col-20 mb-md-10 mb-lg-10">
              <div class="form-group mb-0" :class="{ 'form-group--error': v$.phone_number.$errors.length }">
                <input v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent class="form-input location-input-box"
                  :class="{ 'form-error': v$.phone_number.$errors.length }" type="text" name="phone_number"
                  v-model.trim="v$.phone_number.$model">
                <label class="label location-input-label" :class="{ 'label-float': v$.phone_number.$model }">Phone
                  Number</label>
                <div v-if="v$.phone_number.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.phone_number.$errors[0].$message }}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-4 col-lg-3 col-xl-3 col-20 px10 mb-md-10 mb-lg-10">
              <div class="form-group mb-0" :class="{ 'form-group--error': v$.selected_class.$errors.length }">
                <multiselect v-model="selected_class" :options="all_class_list" :close-on-select="true" tag-placeholder=""
                  placeholder="" label="class_name" track-by="id" :searchable="true" :showLabels="false"
                  :taggable="false">
                  <template #noResult>
                    <div class="multiselect__noResult text-center">No results found</div>
                  </template>
                </multiselect>
                <label class="label label-select" :class="{ 'label-float': (selected_class != null) }">Class</label>
                <div v-if="v$.selected_class.$errors.length > 0">
                  <div class="form-error-text">
                    {{ v$.selected_class.$errors[0].$message }}
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 col-lg-5 col-xl-4 px10">
              <div class="flex flex-wrap flex-auto items-center mt15">
                <h6 class="font-14 gray_checkmark--text mr6">Imaging Device Access</h6>
                <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="cursor-pointer" style="height:24px">
                  <span><info-icon></info-icon></span>
                  <template #popper>
                    Does the student have imaging device access?
                  </template>
                </VTooltip>
                <div class="form-group flex items-center flex-wrap flex-auto ml6 mb-0">
                  <div class="radio mr16">
                    <input v-model.trim="v$.imaging_device_access.$model" :id="'imaging_device_access_yes_'+student_item.id"
                      name="imaging_device_access" type="radio" value="Yes">
                    <label :for="'imaging_device_access_yes_'+student_item.id"
                      class="radio-label font-14 font-light gray_checkmark--text">Yes</label>
                  </div>
                  <div class="radio">
                    <input v-model.trim="v$.imaging_device_access.$model" :id="'imaging_device_access_no_'+student_item.id"
                      name="imaging_device_access" type="radio" value="No">
                    <label :for="'imaging_device_access_no_'+student_item.id"
                      class="radio-label font-14 font-light gray_checkmark--text">No</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4 col-xl-4 px10">
              <div class="flex flex-wrap flex-auto items-center mt15">
                <h6 class="font-14 gray_checkmark--text mr6">Full Network Access</h6>
                <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="cursor-pointer" style="height:24px">
                  <span><info-icon></info-icon></span>
                  <template #popper>
                    Does the student have access to all areas of your internal IT network?
                  </template>
                </VTooltip>
                <div class="form-group flex items-center flex-wrap flex-auto ml6 mb-0">
                  <div class="radio mr16">
                    <input v-model.trim="v$.full_network_access.$model" :id="'full_network_access_yes_'+student_item.id"
                      name="full_network_access" type="radio" value="Yes">
                    <label :for="'full_network_access_yes_'+student_item.id"
                      class="radio-label font-14 font-light gray_checkmark--text">Yes</label>
                  </div>
                  <div class="radio">
                    <input v-model.trim="v$.full_network_access.$model" :id="'full_network_access_no_'+student_item.id"
                      name="full_network_access" type="radio" value="No">
                    <label :for="'full_network_access_no_'+student_item.id"
                      class="radio-label font-14 font-light gray_checkmark--text">No</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4 col-xl-4 px10">
              <div class="flex flex-wrap flex-auto items-center mt15">
                <h6 class="font-14 gray_checkmark--text items-center mr6">Full Software Access</h6>
                <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="cursor-pointer" style="height:24px">
                  <span><info-icon></info-icon></span>
                  <template #popper>
                    Does the student have full access to your EHR software?
                  </template>
                </VTooltip>
                <div class="form-group flex items-center flex-wrap flex-auto ml6 mb-0">
                  <div class="radio mr16">
                    <input v-model.trim="v$.full_software_access.$model" :id="'full_software_access_yes_'+student_item.id"
                      name="full_software_access" type="radio" value="Yes">
                    <label :for="'full_software_access_yes_'+student_item.id"
                      class="radio-label font-14 font-light gray_checkmark--text">Yes</label>
                  </div>
                  <div class="radio">
                    <input v-model.trim="v$.full_software_access.$model" :id="'full_software_access_no_'+student_item.id"
                      name="full_software_access" type="radio" value="No">
                    <label :for="'full_software_access_no_'+student_item.id"
                      class="radio-label font-14 font-light gray_checkmark--text">No</label>
                  </div>
                </div>
              </div>
            </div>
            <div v-if="all_location_list.length > 1" class="col-12 px10 mt15 mb-md-10">
              <div class="row -mx-10">
                <div class="col-12 col-md-6 col-lg-4 col-xl-3 pl10 pl10">
                  <div class="flex flex-wrap">
                    <div class="form-group mr4 flex-auto primary-work-select mb-0"
                      :class="{ 'form-group--error': v$.selected_primary_work_location.$errors.length }">
                      <multiselect v-model="selected_primary_work_location" :options="all_location_list"
                        :close-on-select="true" tag-placeholder="" placeholder="" label="location_nickname" track-by="id"
                        :searchable="true" :showLabels="false" :taggable="false">
                        <template #noResult>
                          <div class="multiselect__noResult text-center">No results found</div>
                        </template>
                      </multiselect>
                      <label class="label label-select"
                        :class="{ 'label-float': (selected_primary_work_location != null) }">Primary Education Location</label>
                      <div v-if="v$.selected_primary_work_location.$errors.length > 0">
                        <div class="form-error-text">
                          {{ v$.selected_primary_work_location.$errors[0].$message }}
                        </div>
                      </div>
                    </div>
                    <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="cursor-pointer mt8" style="">
                      <span><info-icon></info-icon></span>
                      <template #popper>
                        Primary Education Location
                      </template>
                    </VTooltip>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12">
              <div class="flex items-center flex-wrap justify-center mt6" :class="{ 'mt25': all_location_list.length <= 1 }">
                <button :disabled="disable_edit_student_submit_btn" type="submit" class="btn-primary mx5">
                  <span>Submit</span>
                </button>
                <button :disabled="disable_edit_student_submit_btn" type="button" class="btn-cancel-outline mx5"
                  @click="cancelEditStudent">
                  <span>Cancel</span>
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </transition>
    <delete-student-modal v-if="is_delete_student_modal_shown" :student_id="delete_student_modal_student_id"
      @close-model="deleteStudentToggle" @delete-student="deleteStudentSubmit"></delete-student-modal>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from 'lodash';
import { useVuelidate } from '@vuelidate/core';
import { required, email, minLength, maxLength, helpers } from "@vuelidate/validators";
import deleteStudentModal from "./deleteStudentModal.vue";
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
import pdfIcon from "../common/icons/pdfIcon.vue"
import infoIcon from "../common/icons/infoIcon.vue"
import { checkSpecialChars, checkSpecialCharsErrorMessage } from "../common/customValidation";
import fullPageLoader from '../common/fullPageLoader.vue';
import mitt from 'mitt'
const emitter = mitt()

export default {
  data() {
    return {
      student_id: "",
      first_name: "",
      last_name: "",
      email: "",
      phone_number: "",
      selected_class: null,
      imaging_device_access: 'No',
      full_network_access: 'No',
      full_software_access: 'No',
      selected_primary_work_location: null,
      is_student_editing: false,
      disable_edit_student_submit_btn: false,
      check_student_available_timer: null,
      is_delete_student_modal_shown: false,
      delete_student_modal_student_id: "",
      JS_APP_URL: JS_APP_URL,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
      show_access_right_modal: false,
      all_location_list_for_access_rights: [],
      student_access_rights_count: this.student_item.student_access_rights_count,
      is_full_page_loader_shown: false,
    };
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      first_name: {
        required: helpers.withMessage("Please enter a first name", required),
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
      },
      last_name: {
        required: helpers.withMessage("Please enter a last name", required),
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        maxLength: helpers.withMessage("Max 40 characters allowed", maxLength(40)),
      },
      email: {
        required: helpers.withMessage("Please enter an email", required),
        email: helpers.withMessage("Please enter a valid email", email),
        maxLength: helpers.withMessage("Max 100 characters allowed", maxLength(100)),
        isUnique: helpers.withMessage('Email address already in use', helpers.withAsync(async (value) => {
          if (!value) return true;
          if (!this.v$.email.required || !this.v$.email.email) return true;
            this.disable_edit_student_submit_btn = true;
            let check_promise = new Promise((resolve, reject) => {
              if (this.check_student_available_timer) {
                clearTimeout(this.check_student_available_timer)
                this.check_student_available_timer = null
              }
              this.check_student_available_timer = setTimeout(() => {
                return fetch(JS_APP_URL + `/student/check-unique-email-student/${value}/` + this.student_id)
                .then(response => {
                  if (response.ok) {
                    resolve(response.text())
                  } else {
                    resolve(new Error('error'))
                  }
                }, error => {
                  resolve(new Error('error'))
                })
              }, 500);
            });
            var response = await check_promise;
            this.disable_edit_student_submit_btn = false;
            return Boolean((response == 'available')?false:true);
        }))
      },
      phone_number: {
        required: helpers.withMessage("Please enter a phone number", required),
        minLength: helpers.withMessage("Please enter a valid phone number", minLength(12)),
        maxLength: helpers.withMessage("Please enter a valid phone number", maxLength(12)),
      },
      selected_class: {
        required: helpers.withMessage("Please select a class", required),
      },
      imaging_device_access: {
        required: helpers.withMessage("Does the student have imaging device access?", required)
      },
      full_network_access: {
        required: helpers.withMessage(" ", required)
      },
      full_software_access: {
        required: helpers.withMessage("", required)
      },
    };
    if (this.all_location_list.length > 1) {
      validationArray.selected_primary_work_location = { 
        required: helpers.withMessage("Please select a primary education location", required) 
      };
    }
    return validationArray;
  },
  props: {
    student_item: {
      type: Object,
      default: () => { }
    },
    all_location_list: {
      type: Array,
      default: () => []
    },
    all_class_list: {
      type: Array,
      default: () => []
    }
  },
  emits: ["deleted-student", 'close_other_student_edit', "updated-student"],
  components: {
    deleteStudentModal,
    clearDropdownIcon,
    pdfIcon,
    infoIcon,
    fullPageLoader
  },
  mounted() {
    emitter.on('close_other_student_edit', (student_id) => {
      if (student_id !== this.student_item.id) {
        this.is_student_editing = false;
      }
    });
  },
  methods: {
    editStudent() {
      this.student_id = this.student_item.id;
      this.first_name = this.student_item.first_name;
      this.last_name = this.student_item.last_name;
      this.email = this.student_item.email;
      this.phone_number = this.student_item.phone_number;
      this.selected_primary_work_location = this.student_item.student_primary_work_location;
      this.selected_class = this.student_item.student_class,
        this.imaging_device_access = this.student_item.imaging_device_access,
        this.full_network_access = this.student_item.full_network_access,
        this.full_software_access = this.student_item.full_software_access,
        setTimeout(() => {
          this.is_student_editing = true;
          emitter.emit('close_other_student_edit', this.student_id);
        }, 100);
    },
    editStudentSubmit() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        NProgress.start();
        this.disable_edit_student_submit_btn = true;
        axios
          .post(JS_APP_URL + "/student/edit-student", {
            student_id: this.student_id,
            first_name: this.first_name,
            last_name: this.last_name,
            email: this.email,
            phone_number: this.phone_number,
            primary_work_location_id: (this.all_location_list.length == 1) ? this.all_location_list[0].id : this.selected_primary_work_location.id,
            class_id: this.selected_class.id,
            imaging_device_access: this.imaging_device_access,
            full_network_access: this.full_network_access,
            full_software_access: this.full_software_access,
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if (response["data"]['data'].length > 0) {
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              } else {
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              toastr.success(response["data"]["message"], "Success");
              setTimeout(() => {
                this.is_student_editing = false;
                this.$emit("updated-student", response["data"]['data']);
              }, 100);
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            NProgress.done();
            this.disable_edit_student_submit_btn = false;
          });
      }
    },
    deleteStudentToggle(status = true) {
      this.delete_student_modal_student_id = this.student_item.id;
      this.is_delete_student_modal_shown = status;
      setTimeout(() => {
        emitter.emit('close_other_student_edit', this.student_item.id);
      }, 100);
    },
    deleteStudentSubmit() {
      if (this.delete_student_modal_student_id) {
        NProgress.start();
        axios
          .post(JS_APP_URL + "/student/delete-student", {
            student_id: this.delete_student_modal_student_id
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if (response["data"]['data'].length > 0) {
                toastr.error(response["data"]['data'].join('</br>'), "Error");
              } else {
                toastr.error(response["data"]["message"], "Error");
              }
            } else {
              toastr.success(response["data"]["message"], "Success");
              setTimeout(() => {
                this.$emit("deleted-student", this.delete_student_modal_student_id);
              }, 100);
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            NProgress.done();
            this.is_delete_student_modal_shown = false;
          });
      }
    },
    cancelEditStudent() {
      this.is_student_editing = false;
    },
    changeAccessRightsCount(count) {
      this.student_access_rights_count = count;
    },
    downloadAgreement(student_id) {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/student/download-agreement?student_id=" + student_id)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            var link = document.createElement("a");
            link.setAttribute("href", response["data"]['data']['download_url']);
            link.setAttribute("download", response["data"]['data']['file_name']);
            link.setAttribute("target", '_blank');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          setTimeout(() => {
            this.is_full_page_loader_shown = false;
          }, 100);
        });
    },
  },
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.is_student_editing = false;
      }
    });
  }
};
</script>
