<template>
  <div>
    <form @submit.prevent="addStudentSubmit">
      <div class="add-student-row row -mx-10 mb40">
        <div class="col-12 col-md-6 col-lg-3 col-xl-3 col-20 px10 mb-md-10 mb-lg-10">
          <div class="form-group mb-0" :class="{ 'form-group--error': v$.first_name.$errors.length }">
            <input class="form-input location-input-box" :class="{ 'form-error': v$.first_name.$errors.length }" type="text"
              name="first_name" v-model.trim="v$.first_name.$model">
            <label class="label location-input-label" :class="{ 'label-float': v$.first_name.$model }">First
              Name</label>
            <div v-if="v$.first_name.$errors.length > 0">
              <div class="form-error-text">
                {{ v$.first_name.$errors[0].$message }}
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-3 col-xl-3 col-20 px10 mb-md-10 mb-lg-10">
          <div class="form-group mb-0" :class="{ 'form-group--error': v$.last_name.$errors.length }">
            <input class="form-input location-input-box" :class="{ 'form-error': v$.last_name.$errors.length }" type="text"
              name="last_name" v-model.trim="v$.last_name.$model">
            <label class="label location-input-label" :class="{ 'label-float': v$.last_name.$model }">Last Name</label>
            <div v-if="v$.last_name.$errors.length > 0">
              <div class="form-error-text">
                {{ v$.last_name.$errors[0].$message }}
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-3 col-xl-3 col-20 px10 mb-md-10 mb-lg-10">
          <div class="form-group mb-0" :class="{ 'form-group--error': v$.email.$errors.length }">
            <input class="form-input location-input-box" :class="{ 'form-error': v$.email.$errors.length }" type="text"
              name="email" v-model.trim="v$.email.$model">
            <label class="label location-input-label" :class="{ 'label-float': v$.email.$model }">Email</label>
            <div v-if="v$.email.$errors.length > 0">
              <div class="form-error-text">
                {{ v$.email.$errors[0].$message }}
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-3 col-xl-3 col-20 px10 mb-md-10 mb-lg-10">
          <div class="form-group mb-0" :class="{ 'form-group--error': v$.phone_number.$errors.length }">
            <input v-mask="'000-000-0000'" @click.right.prevent @copy.prevent @paste.prevent class="form-input location-input-box"
              :class="{ 'form-error': v$.phone_number.$errors.length }" type="text" name="phone_number"
              v-model.trim="v$.phone_number.$model">
            <label class="label location-input-label" :class="{ 'label-float': v$.phone_number.$model }">Phone
              Number</label>
            <div v-if="v$.phone_number.$errors.length > 0">
              <div class="form-error-text">
                {{ v$.phone_number.$errors[0].$message }}
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-3 col-xl-3 col-20 px10 mb-md-10 mb-lg-10">
          <div class="form-group mb-0" :class="{ 'form-group--error': v$.selected_class.$errors.length }">
            <multiselect v-model="selected_class" :options="all_class_list" :close-on-select="true" tag-placeholder=""
              placeholder="" label="class_name" track-by="id" :searchable="true" :showLabels="false" :taggable="false">
              <template #noResult>
                <div class="multiselect__noResult text-center">No results found</div>
              </template>
            </multiselect>
            <label class="label label-select" :class="{ 'label-float': (selected_class != null) }">Class</label>
            <div v-if="v$.selected_class.$errors.length > 0">
              <div class="form-error-text">
                {{ v$.selected_class.$errors[0].$message }}
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-4 px10">
          <div class="flex flex-wrap flex-auto items-center mt15">
            <h6 class="font-14 gray_checkmark--text mr6">Imaging Device Access</h6>
            <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="cursor-pointer" style="height:25px">
              <span><info-icon></info-icon></span>
              <template #popper>
                Does the student have imaging device access?
              </template>
            </VTooltip>
            <div class="flex items-center flex-wrap flex-auto ml6">
              <div class="radio mr16">
                <input v-model.trim="v$.imaging_device_access.$model" id="imaging_device_access_yes"
                  name="imaging_device_access" type="radio" value="Yes">
                <label for="imaging_device_access_yes"
                  class="radio-label font-14 font-light gray_checkmark--text">Yes</label>
              </div>
              <div class="radio">
                <input v-model.trim="v$.imaging_device_access.$model" id="imaging_device_access_no"
                  name="imaging_device_access" type="radio" value="No">
                <label for="imaging_device_access_no"
                  class="radio-label font-14 font-light gray_checkmark--text">No</label>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-4 px10">
          <div class="flex flex-wrap flex-auto items-center mt15">
            <h6 class="font-14 gray_checkmark--text mr6">Full Network Access</h6>
            <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="cursor-pointer" style="height:25px">
              <span><info-icon></info-icon></span>
              <template #popper>
                Does the student have access to all areas of your internal IT network?
              </template>
            </VTooltip>
            <div class="flex items-center flex-wrap flex-auto ml6">
              <div class="radio mr16">
                <input v-model.trim="v$.full_network_access.$model" id="full_network_access_yes"
                  name="full_network_access" type="radio" value="Yes">
                <label for="full_network_access_yes"
                  class="radio-label font-14 font-light gray_checkmark--text">Yes</label>
              </div>
              <div class="radio">
                <input v-model.trim="v$.full_network_access.$model" id="full_network_access_no"
                  name="full_network_access" type="radio" value="No">
                <label for="full_network_access_no"
                  class="radio-label font-14 font-light gray_checkmark--text">No</label>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-4 col-xl-4 px10">
          <div class="flex flex-wrap flex-auto items-center mt15">
            <h6 class="font-14 gray_checkmark--text mr6">Full Software Access</h6>
            <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="cursor-pointer" style="height:25px">
              <span><info-icon></info-icon></span>
              <template #popper>
                Does the student have full access to your EHR software?
              </template>
            </VTooltip>
            <div class="flex items-center flex-wrap flex-auto ml6">
              <div class="radio mr16">
                <input v-model.trim="v$.full_software_access.$model" id="full_software_access_yes"
                  name="full_software_access" type="radio" value="Yes">
                <label for="full_software_access_yes"
                  class="radio-label font-14 font-light gray_checkmark--text">Yes</label>
              </div>
              <div class="radio">
                <input v-model.trim="v$.full_software_access.$model" id="full_software_access_no"
                  name="full_software_access" type="radio" value="No">
                <label for="full_software_access_no"
                  class="radio-label font-14 font-light gray_checkmark--text">No</label>
              </div>
            </div>
          </div>
        </div>
        <div v-if="all_location_list.length > 1" class="col-12 px10 mt15 mb-md-10">
          <div class="row -mx-10">
            <div class="col-12 col-md-6 col-lg-4 col-xl-3 pl10 pr0">
            <div class="flex flex-wrap">
              <div class="form-group mb-0 flex-auto mr4 primary-work-select" :class="{ 'form-group--error': v$.selected_primary_work_location.$errors.length }">
                <multiselect v-model="selected_primary_work_location" :options="all_location_list" :close-on-select="true"
                  tag-placeholder="" placeholder="" label="location_nickname" track-by="id" :searchable="true"
                  :showLabels="false" :taggable="false">
                  <template #noResult>
                    <div class="multiselect__noResult text-center">No results found</div>
                  </template>
                </multiselect>
                <label class="label label-select"
                  :class="{ 'label-float': (selected_primary_work_location != null) }">Primary Education Location</label>
                  <div v-if="v$.selected_primary_work_location.$errors.length > 0">
                    <div class="form-error-text">
                      {{ v$.selected_primary_work_location.$errors[0].$message }}
                    </div>
                  </div>
              </div>
                <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="cursor-pointer mt8" style="height:25px">
                  <span><info-icon></info-icon></span>
                  <template #popper>
                    Primary Education Location
                  </template>
                </VTooltip>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 px10">
          <div class="flex items-center flex-wrap justify-center mt6" :class="{ 'mt30': all_location_list.length <= 1 }">
            <button :disabled="disable_add_student_submit_btn" type="submit" class="btn-primary mx5">
              <span>Submit</span>
            </button>
            <button :disabled="disable_add_student_submit_btn" type="button" class="btn-cancel-outline mx5"
              @click="cancelAddStudent()">
              <span>Cancel</span>
            </button>
          </div>
        </div>
      </div>
    </form>
  </div>
</template>
<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import { useVuelidate } from '@vuelidate/core';
import { required, email, minLength, maxLength, helpers } from "@vuelidate/validators";
import _ from 'lodash';
import infoIcon from "../common/icons/infoIcon.vue"
import clearDropdownIcon from '../common/icons/clearDropdownIcon.vue';
import { checkSpecialChars, checkSpecialCharsErrorMessage } from "../common/customValidation";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
      first_name: '',
      last_name: '',
      email: '',
      phone_number: '',
      selected_primary_work_location: null,
      selected_class: null,
      imaging_device_access: 'No',
      full_network_access: 'No',
      full_software_access: 'No',
      disable_add_student_submit_btn: false,
      check_student_available_timer: null
    };
  },
  props: {
    all_location_list: {
      type: Array,
      default: () => []
    },
    all_class_list: {
      type: Array,
      default: () => []
    }
  },
  emits: ["add-student-form-toggle", "reset-all-filter", "load-student-list"],
  components: {
    infoIcon,
    clearDropdownIcon,
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      first_name: {
        required: helpers.withMessage('Please enter a first name', required),
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
      },
      last_name: {
        required: helpers.withMessage('Please enter a last name', required),
        checkSpecialChars: helpers.withMessage(checkSpecialCharsErrorMessage, checkSpecialChars),
        maxLength: helpers.withMessage('Max 40 characters allowed', maxLength(40)),
      },
      email: {
        required: helpers.withMessage('Please enter an email', required),
        email: helpers.withMessage('Please enter a valid email', email),
        maxLength: helpers.withMessage('Max 100 characters allowed', maxLength(100)),
        isUnique: helpers.withMessage('Email address already in use', helpers.withAsync(async (value) => {
          if (!value) return true;
          if (!this.v$.email.required || !this.v$.email.email) return true;
            this.disable_add_student_submit_btn = true;
            let check_promise = new Promise((resolve, reject) => {
              if (this.check_student_available_timer) {
                clearTimeout(this.check_student_available_timer)
                this.check_student_available_timer = null
              }
              this.check_student_available_timer = setTimeout(() => {
                return fetch(JS_APP_URL + `/student/check-unique-email-student/${value}`)
                .then(response => {
                  if (response.ok) {
                    resolve(response.text())
                  } else {
                    resolve(new Error('error'))
                  }
                }, error => {
                  resolve(new Error('error'))
                })
              }, 500);
            });
            var response = await check_promise;
            this.disable_add_student_submit_btn = false;
            return Boolean((response == 'available')?false:true);
        }))
      },
      phone_number: {
        required: helpers.withMessage('Please enter a phone number', required),
        minLength: helpers.withMessage('Please enter a valid phone number', minLength(12)),
        maxLength: helpers.withMessage('Please enter a valid phone number', maxLength(12)),
      },
      selected_class: {
        required: helpers.withMessage('Please select a class', required),
      },
      imaging_device_access: {
        required: helpers.withMessage("Please select an imaging device access", required),
      },
      full_network_access: {
        required: helpers.withMessage("Please select s full network access", required),
      },
      full_software_access: {
        required: helpers.withMessage("Please select s full software access", required),
      },
    };
    if (this.all_location_list.length > 1) {
      validationArray.selected_primary_work_location = { 
        required: helpers.withMessage('Please select a primary education location', required)
      };
    }
    return validationArray;
  },
  methods: {
    cancelAddStudent(){
      this.$emit("add-student-form-toggle", false);
    },
    addStudentSubmit() {
      this.v$.$touch();
      if (!this.v$.$invalid) {
        NProgress.start();
        this.disable_add_student_submit_btn = true;
        axios
          .post(JS_APP_URL + "/student/add-student", {
            first_name: this.first_name,
            last_name: this.last_name,
            email: this.email,
            phone_number: this.phone_number,
            primary_work_location_id: (this.all_location_list.length == 1) ? this.all_location_list[0].id : this.selected_primary_work_location.id,
            class_id: this.selected_class.id,
            imaging_device_access: this.imaging_device_access,
            full_network_access: this.full_network_access,
            full_software_access: this.full_software_access,
          })
          .then((response) => {
            if (response["data"]["status"] == "Error") {
              if (response["data"]['data'].length > 0) {
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
                } else {
                  toastr.error(response["data"]["message"], "Error");
                }
            } else {
              toastr.success(response["data"]["message"], "Success");
              setTimeout(() => {
                this.$emit("add-student-form-toggle", false);
                this.$emit("reset-all-filter");
                this.$emit("load-student-list", true);
              }, 100);
            }
          })
          .catch((error) => {
            toastr.error(error.response["data"]["message"], "Error");
            if (error.response.status === 401) {
              window.location = JS_APP_URL + "/login";
            }
          })
          .then(() => {
            NProgress.done();
            this.disable_add_student_submit_btn = false;
          });
      }
    },
  },
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("add-student-form-toggle", false);
      }
    });
  }
};
</script>
