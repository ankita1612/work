 <template>
   <div class="light px30 pt20 pb10 policies-item mb8" :class="{ 'policies-item-more': (read_more == true) }">
        <h4 class="font-22 font_semibold blueog--text line-normal mb10">
          {{site_policy.title}}
        </h4>
        <div class="policies-content font-12 black--text line-normal mb10" >
          <span class="policies-content-visible" v-if="read_more == false" v-html="sortDescription">
          </span>
          <span class="policies-content-visible" v-if="read_more == true" v-html="site_policy.description">
          </span>
        </div>
        <div class="text-right" v-if="this.description_length > 500">
          <a
           @click="toggleReadmore"
            class="font-14 green--text hover-underline-animation read-more-link"
           :class="{ 'read-less-link': (read_more == true) }"
            >
            <span v-if="read_more == false">Read More</span>
            <span v-else>Read Less</span>
            &nbsp;<img
              :src="JS_APP_URL + '/images/down-chevron.svg'"
              class="down-icon"
              alt=""
              title=""
            />
          </a>
        </div>
        
      </div>
</template>

<style scoped>
</style>

<script scoped>
import _ from 'lodash';

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      read_more:false,
      description_length:"",
    };
  },
   props:{
        site_policy: {
            type: Object
        },
    },
    computed: {
      sortDescription(){
        if(this.site_policy.description.length >= 500){
          const last_index = this.site_policy.description.slice(0, 500).lastIndexOf(".");
          return this.site_policy.description.substring(0, last_index + 1);
        }else{
          return this.site_policy.description;
        }
      }
    },
    mounted() {
        this.description_length = this.site_policy.description.length
    },
  methods: {
    toggleReadmore(){
      if(this.read_more == true){
        this.read_more = false
      }else{
        this.read_more = true    
      }
    }
  },
};
</script>