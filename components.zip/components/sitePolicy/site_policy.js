import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import InfiniteLoading from "v3-infinite-loading";
import sitepolicy from "./sitePolicy.vue";
import VueMask from '@devindex/vue-mask';

const sitepolicy_app = createApp(sitepolicy);
sitepolicy_app.use(VueMask);
sitepolicy_app.use(FloatingVue);
sitepolicy_app.component('multiselect', Multiselect);
sitepolicy_app.component('InfiniteLoading', InfiniteLoading);
sitepolicy_app.mount("#sitepolicy_app");