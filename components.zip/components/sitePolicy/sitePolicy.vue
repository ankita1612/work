<template>
  <div>
    <header-after-login></header-after-login>
    <div class="container pt40 pb60">
      <h1
        class="
          location-dashbaord-title
          text-center
          font-28 font_semibold
          blueog--text
          line-normal
          mb40
        "
      >
        Abyde Site Policies
      </h1>
      <site-policy-item v-for="site_policy in site_policy_details" :key="site_policy.id"
      :site_policy = "site_policy" ></site-policy-item>
    </div>
     <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
  </div>
</template>

<style scoped>
</style>

<script scoped>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import sitePolicyItem from "./sitePolicyItem.vue";
import fullPageLoader from "../common/fullPageLoader.vue";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_full_page_loader_shown:false,
      site_policy_details:[],
    };
  },
  mounted() {
    this.getSitePolicy()
  },
  components: {
    headerAfterLogin,
    sitePolicyItem,
    fullPageLoader
  },
  methods: {
    getSitePolicy(){
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/site-policies/get-site-policies")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.site_policy_details = response.data.data
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    }
  },
};
</script>