import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import selectState from "./selectstate.vue";
import VueMask from '@devindex/vue-mask';


const app = createApp(selectState)
app.use(VueMask);
app.use(FloatingVue)
app.mount("#consultation_app")
