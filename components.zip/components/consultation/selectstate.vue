<template>
  <div class="flex flex-col flex-auto min-fill-height">
    <div class="header-container py18">
      <div class="container flex items-center justify-center flex-wrap relative">
        <a :href="JS_WORDPRESS_URL" target="_blank" class="logo-wrapper" >
          <img :src="JS_APP_URL + '/images/logo.svg'" alt="" title="" class="logo">
        </a>
        <div class="flex-wrap flex  font_normal">
          <a :href="JS_WORDPRESS_URL" class="font_semibold font-45 blueog--text hipaa-map-header-title">
            Compliance Consultation
          </a>
        </div>
        <a :href="partner.link" class="hipaa-partner-logo" target="_blank" v-if="partner && Object.keys(partner).length > 0">
          <img :src="JS_APP_URL + '/images/partner/'+partner.logo" alt="Abyde" class=""/>
        </a>
      </div>
  </div>
    <div class="main-content flex-auto">
      <div class="container">
        <div class="hipaa-map-block">
          <div>
            <h3 class="font_semibold text-center blueog--text font-26 mt20 mb6">
             We're looking forward to speaking with you!
            </h3>
            <h4 class="font_light text-center blueog--text font-20 mb20">
             To schedule your compliance consultation, please pick your state.
            </h4>
            <div id="map" style="height: 400px"></div>
          </div>
        </div>
      </div>
    </div>
    <div class="dark py40">
			<div class="container">
        <div class="row flex-auto -mx-10 hipaa-footer">
					<div class="col-12 col-sm-5 col-md-6 col-lg-6 col-xl-6 px10 mb-sm-10 text--white">
						Copyright &copy; {{CURRENT_YEAR}} Abyde
					</div>
					<div class="col-12 col-sm-7 col-md-6 col-lg-6 col-xl-6 px10 text-right">
						<a class="btn px10" :href="JS_WORDPRESS_URL + '/terms-conditions'">TERMS AND CONDITIONS</a>
						<a class="btn px10" :href="JS_WORDPRESS_URL + '/privacy-policy'">PRIVACY POLICY</a>
					</div>
        </div>
			</div>
    </div>
  </div>
</template>

<script>
import jsVectorMap from "jsvectormap";
import "./maps/us-aea-en";
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from "lodash";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      CURRENT_YEAR: CURRENT_YEAR,
      selectedStateCode: "",
      all_state_list: [],
      partner: {}
    };
  },
  created() {
    let uri = window.location.pathname;
    uri = uri.split("/");
    if (uri[3]) {
      this.getPartnerInfo(uri[3]);
    }
  },
  mounted() {
    this.generateUSGraph();
    this.loadStateList();
  },
  methods: {
    generateUSGraph() {
      new jsVectorMap({
        selector: "#map",
        map: "us_aea_en",
        showTooltip: true,
        zoomOnScroll: false,
        regionsSelectable: true,
        regionsSelectableOne: true,
        regionStyle: {
          initial: {
            fill: '#b5b5b5',
            stroke: "#ffffff",
            strokeWidth: 1,
            strokeOpacity: 0.25,
            fillOpacity: 1
          },
          hover: {
            fill: '#3399d1',
            fillOpacity: 1
          },
          selected: {
            fill: '#3399d1',
            fillOpacity: 1
          },
          selectedHover: {
            fill: '#3399d1',
            fillOpacity: 1
          }
        },
        onRegionClick:(event, code) => {
          this.selectedStateCode = code.toUpperCase();
          this.gotoCalendlyLink();
        },
      });
    },
    gotoCalendlyLink() {
      if(this.selectedStateCode != ''){
        var foundState = _.find(this.all_state_list,(state) => {
          return 'US-'+state.state_code == this.selectedStateCode
        });
        if(!_.isUndefined(foundState)){
          let link = foundState.calendly_link.consultation_calendly_link;
          if(this.partner && Object.keys(this.partner).length > 0){
            link = link + '?a5=' + this.partner.name;
          }
          window.open(
            link,
            '_blank'
          );
        }else{
          window.open(
            JS_WORDPRESS_URL + '/contact-us',
            '_blank'
          );
        }
      }else{
        window.open(
          JS_WORDPRESS_URL + '/contact-us',
          '_blank'
        );
      }
    },
    openURL(link) {
      window.open(link, "_blank");
    },
    loadStateList() {
      axios
        .get(JS_APP_URL + "/consultation/get-state-list")
        .then((response) => {
          if(response["data"]["status"] == "Success") {
            this.all_state_list = response["data"]["data"];
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
        });
    },
    getPartnerInfo(slug) {
      axios
        .post(JS_APP_URL + "/consultation/partner-info", {
          slug: slug,
        })
        .then((response) => {
          this.partner = response.data.data;
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {});
    },
  },
};
</script>
