import { createApp } from "vue";
import consultationcheduled from './consultationcheduled.vue';
const app = createApp(consultationcheduled)
app.mount("#consultationcheduled_app")
