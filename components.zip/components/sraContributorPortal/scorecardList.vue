<template>
  <div>
    <div v-if="is_edit_mode">
      <div class="scorecard-card mb50" :class="risk_level_class">
        <div class="relative scorecard-quetion-block mb18">
          <div class="font-16 font_light">
            {{ attempted_question["question"]["question_category"]["category_title"] }}
          </div>
          <div class="flex flex-wrap quetion-wrapper">
            <span class="font-19 font_semibold quetion-no-text">Q{{ loop_index + 1 }}.</span>
            <div
              class="font-19 font_semibold quetion-text"
              v-html="attempted_question['question']['question']"
            ></div>
          </div>
        </div>
        <div class="edit-toggle-state">
          <div class="row flex-auto -mx-10 items-center mb14">
            <div class="col-12 col-md-12 col-lg-9 col-xl-8 px10">
              <div class="flex items-center flex-wrap">
                <div
                  class="scorecard-answers-edit answer-option-item font-19 blueog--text mb-md-10"
                  v-for="(option, index) in attempted_question['question'][
                    'risk_analysis_question_answer_options'
                  ]"
                  :key="index"
                >
                  <div v-if="attempted_question['question']['question_answer_layout'] == 'radio'">
                    <input
                      type="radio"
                      class="answer-option-radio"
                      :value="option['id']"
                      v-model="selected_answers"
                      :id="option['id']"
                      :checked="
                        option.id ==
                        attempted_question['attempted_response']['answer'][0]
                      "
                    />
                    <label
                      :for="option['id']"
                      class="answer-option-lable font-19 blueog--text"
                    >
                      {{ option["answer"] }}
                    </label>
                  </div>
                  <div v-if="attempted_question['question']['question_answer_layout'] == 'checkbox'">
                    <input
                      type="checkbox"
                      class="answer-option-radio"
                      :value="option['id']"
                      v-model="selected_answers"
                      :id="option['id']"
                      :checked="
                        option.id ==
                        attempted_question['attempted_response']['answer'][0]
                      "
                    />
                    <label
                      :for="option['id']"
                      class="answer-option-lable font-19 blueog--text"
                    >
                      {{ option["answer"] }}
                    </label>
                  </div>
                </div>
                <div
                  class="flex-auto"
                  v-if="attempted_question['question']['question_answer_layout'] == 'text'"
                >
                  <div class="text-center">
                    <textarea
                      class="textarea form-input"
                      v-model.trim="answer"
                    ></textarea>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-md-12 col-lg-3 col-xl-4 px10 text-right">
              <div class="flex items-center flex-wrap justify-end submit-cancel-buttons">
                <button
                  type="button"
                  class="btn-cancel-outline btn-width-136 px30 mt-xs-20 mx4"
                  @click="cancelEditAnswer"
                  :disabled="disable_submit_btn"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  class="btn-primary btn-width-136 px30 mt-xs-20 mx4 mb-lg-10"
                  @click="editAnswer"
                  :disabled="disable_submit_btn"
                >
                  Submit
                </button>
              </div>
            </div>
          </div>
          <div class="row flex-auto -mx-10 items-center mb14">
            <div class="col-12 col-md-10 col-lg-7 col-xl-7 px10">
              <div class="form-group gray-bg-input mb-0">
                <textarea
                  rows="3"
                  cols="50"
                  class="comment-textarea form-input"
                  v-model.trim="note"
                  :maxLength="max_characters_comment"
                ></textarea>
                <label
                  class="label label-select"
                  :class="{ 'label-float': note.length > 0 }"
                >
                  Notes
                </label>
              </div>
              <div class="relative textarea-remaining-text">
                <div
                  class="font-10 fotn-light gray_checkmark--text text-right textarea-character-count"
                >
                  {{ max_characters_comment - note.length }} Characters Remaining
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-else>
      <div class="scorecard-card mb50" :class="risk_level_class">
        <div class="relative scorecard-quetion-block mb18">
          <div class="font-16 font_light">
            {{ attempted_question['question']["question_category"]["category_title"] }}
          </div>
          <div class="flex flex-wrap quetion-wrapper">
            <span class="font-19 font_semibold quetion-no-text">Q{{ loop_index + 1 }}.</span>
            <div
              class="font-19 font_semibold quetion-text"
              v-html="attempted_question['question']['question']"
            ></div>
          </div>
        </div>
        <div
          class="edit-complete-state"
          v-if="attempted_question['question']['question_answer_layout'] == 'radio'"
        >
          <div class="row flex-auto -mx-10 items-center justify-between mb15">
            <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10 mb-sm-0">
              <div class="scorecard-answers-option font-19 blueog--text active mb-md-20">
                {{
                  attempted_question['attempted_response']['answer_obj']['answer']
                }}
              </div>
            </div>
            <div
              class="col-12 col-md-12 col-lg-5 col-xl-5 px10 mb-sm-20 self-center"
              v-if="
                (attempted_question['attempted_response']['note'] != null && attempted_question['attempted_response']['note'] != '')
              "
            >
              <div class="scorecard-note-text" v-if="is_edit_mode == false">
                {{attempted_question['attempted_response']['note']}}
                <label class="label location-input-label label-float">Notes</label>
              </div>
              <div v-else class="form-group gray-bg-input mb-0">
                <textarea
                  rows="3"
                  cols="50"
                  class="comment-textarea form-input"
                  v-model="
                    attempted_question['attempted_response']['note']
                  "
                ></textarea>
                <label class="label location-input-label label-float">Notes</label>
              </div>
            </div>
            <div class="col-12 col-md-12 col-lg-1 col-xl-1 px10 self-center">
              <VTooltip :triggers="['hover']" :popperTriggers="['hover']">
                <a
                  class="action-icon-btn action-btn-blueog cursor-pointer mlr-auto"
                  v-on:click="toogleEditModel"
                >
                  <img :src="JS_APP_URL + '/images/pencil.svg'" alt="Edit" />
                </a>
                <template #popper> Edit </template>
              </VTooltip>
            </div>
          </div>
        </div>
        <div class="edit-complete-state checkbox-view" v-else>
          <div class="row flex-auto -mx-10 items-center mb15 justify-between">
            <div class="col-12 col-md-12 col-lg-6 col-xl-6 px10 mb-sm-10">
              <div
                class="scorecard-answer-textbox font-16 blueog--text text-center inline-flex items-center justify-center mb-md-20"
                v-if="attempted_question['question']['question_answer_layout'] == 'text'"
              >
                {{
                  attempted_question['attempted_response']['answer']
                }}
              </div>
              <div
                class="flex flex-wrap -mx-10 mb-md-10"
                v-if="attempted_question['question']['question_answer_layout'] == 'checkbox'"
              >
                <div
                  class="scorecard-checkbox-view-item inline-flex items-center justify-center font-19 blueog--text active"
                  v-for="(attempted_question_answer, index) in attempted_question['attempted_response']['answer_obj']"
                  :key="index"
                >
                  {{ attempted_question_answer["answer"] }}
                </div>
              </div>
            </div>
            <div
              class="col-12 col-md-12 col-lg-5 col-xl-5 px10 mb-sm-20 self-center"
              v-if="
                (attempted_question['attempted_response']['note'] != null && attempted_question['attempted_response']['note'] != '')
              "
            >
              <div class="scorecard-note-text" v-if="is_edit_mode == false">
                {{attempted_question['attempted_response']['note']}}
                <label class="label location-input-label label-float">Notes</label>
              </div>
              <div v-else class="form-group gray-bg-input mb-0">
                <textarea
                  rows="3"
                  cols="50"
                  class="comment-textarea form-input"
                  v-model="
                    attempted_question['attempted_response']['note']
                  "
                ></textarea>
                <label class="label location-input-label label-float">Notes</label>
              </div>
            </div>
            <div class="col-12 col-md-12 col-lg-1 col-xl-1 px10 self-center">
              <VTooltip :triggers="['hover']" :popperTriggers="['hover']">
                <a
                  class="action-icon-btn action-btn-blueog cursor-pointer mlr-auto"
                  v-on:click="toogleEditModel"
                >
                  <img :src="JS_APP_URL + '/images/pencil.svg'" alt="Edit" />
                </a>
                <template #popper> Edit </template>
              </VTooltip>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
import _ from 'lodash';

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_edit_mode: false,
      selected_answers: [],
      note: "",
      answer: "",
      risk_level_class: "scorecard-low-risk",
      risk_level_image: "",
      text_color_class: "",
      disable_submit_btn: false,
      max_characters_comment: 1000,
    };
  },
  emits: ["get-attempted-question","update-edit-mode"],
  created() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.initialDataLoad();
      }
    });
  },
  props: {
    attempted_question: {
      type: Object,
    },
    loop_index: "",
  },
  watch: {
    attempted_question(val) {
      this.initialDataLoad();
    },
    note(val) {
      this.note = val.replace(/\n|\r|  +/g, "");
    },
    is_edit_mode(newVal) {
      this.$emit('update-edit-mode', { index: this.loop_index, value: newVal });
    }
  },
  mounted() {
    this.initialDataLoad();
  },
  methods: {
    cancelEditAnswer() {
      this.initialDataLoad();
    },
    toogleEditModel() {
      if (this.is_edit_mode == true) {
        this.is_edit_mode = false;
      } else {
        this.is_edit_mode = true;
      }
    },
    checkBothArrayEquals(array1, array2) {
      if (array1.length === array2.length) {
        return array1.every((element) => {
          if (array2.includes(element)) {
            return true;
          }
          return false;
        });
      }
      return false;
    },
    editAnswer() {
      var is_answer_changed = false;
      var is_note_changed = false;
      var attempted_note =
        this.attempted_question["attempted_response"]["note"] != null
          ? this.attempted_question["attempted_response"]["note"]
          : "";
      if (attempted_note != this.note) {
        is_note_changed = true;
      }
      if (
        this.attempted_question["question"]["question_answer_layout"] == "text" &&
        this.attempted_question["attempted_response"]["answer"] != this.answer
      ) {
        is_answer_changed = true;
      }
      if (
        this.attempted_question["question"]["question_answer_layout"] == "radio" &&
        this.attempted_question["attempted_response"]["answer"] != this.selected_answers
      ) {
        is_answer_changed = true;
      }
      if (this.attempted_question["question"]["question_answer_layout"] == "checkbox") {
        if (!this.checkBothArrayEquals(this.attempted_question["attempted_response"]["answer"], this.selected_answers)) {
          is_answer_changed = true;
        }
      }
      if (!is_note_changed && !is_answer_changed) {
        toastr.error(
          "Please change your answer/note in order to save your data",
          "Error"
        );
        return false;
      }

      NProgress.start();
      this.disable_submit_btn = true;
     
      let payload;
      if (this.attempted_question['question']["question_answer_layout"] == "text") {
        if (this.answer == null || this.answer == "") {
          toastr.error("Please enter an answer", "Error");
          this.disable_submit_btn = false;
          NProgress.done();
          return;
        }
        payload = {
          answer: this.answer,
          note: this.note
        };
      } else {

        if (this.attempted_question['question']["question_answer_layout"] == "checkbox") {
          if (
            (Array.isArray(this.selected_answers) && this.selected_answers.length < 1) ||
            (typeof this.selected_answers === 'string' && this.selected_answers.trim() === '')
          ) {
            toastr.error("Please select answer(s)", "Error");
            this.disable_submit_btn = false;
            NProgress.done();
            return;
          }
        }
       
        let answer_obj;
        if (!Array.isArray(this.selected_answers)) {
          answer_obj = this.attempted_question.question.risk_analysis_question_answer_options.find(
            (item) => item.id === this.selected_answers
          );
          this.selected_answers = [this.selected_answers];
        } else {
          
          answer_obj = this.attempted_question.question.risk_analysis_question_answer_options.filter(
            (item) => Object.values(this.selected_answers).includes(item.id)
          );
        }
        payload = {
          answer: this.selected_answers,
          answer_obj: answer_obj,
          note: this.note,
        };
      }
      
      if (is_note_changed || is_answer_changed) {
          this.toogleEditModel();
          this.$emit("get-attempted-question",payload,this.loop_index);
      }
      this.disable_submit_btn = false;
      NProgress.done();

    },
   
    initialDataLoad() {
      this.resetInitialData();
      if (
        this.attempted_question["attempted_response"]["note"] != null
      ) {
        this.note = this.attempted_question["attempted_response"][
          "note"
        ];
      }
      if (this.attempted_question["question"]["question_answer_layout"] == "radio") {
        this.selected_answers = this.attempted_question["attempted_response"]["answer"][0];
      }
      if (this.attempted_question["question"]["question_answer_layout"] == "checkbox") {
        this.selected_answers = this.attempted_question["attempted_response"]["answer"];
      }
      if (this.attempted_question["question"]["question_answer_layout"] == "text") {
        this.answer = this.attempted_question["attempted_response"]["answer"];
      }
    },
    resetInitialData() {
      this.is_edit_mode = false;
      this.selected_answers = [];
      this.note = "";
      this.answer = "";
      this.risk_level_image = "";
      this.text_color_class = "";
      this.disable_submit_btn = false;
      this.max_characters_comment = 1000;
    },
  },
};
</script>

<style></style>
