<template>
<Teleport to="body">
    <transition name="modal">
    <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
        <div class="modal-container">
            <button type="button" v-on:click="closeModal" class="cursor-pointer modal-close">
            <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb20">
              <img :src="JS_APP_URL + '/images/checklist.svg'" alt="" title="" class="" style="max-width:45px" />
            </div>
            <h2 class="font-24 font_semibold blueog--text line-normal text-center mb10">
            Review Note
            </h2>
            <div class="form-group gray-bg-input mb-0">
              <textarea
                cols="50"
                class="comment-textarea form-input contributor-form-input"
                readonly
                :value="review_note"
                >
                </textarea>
                <label class="label location-input-label label-float">Notes</label>
              </div>
          
        </div>
        </div>
    </div>
    </transition>
</Teleport>
</template>
  
<script scoped>
  import closeIcon from '../common/icons/closeIcon.vue'
  
  export default {
    data() {
      return {
        JS_APP_URL: JS_APP_URL,
      };
    },
    props: {
      review_note : ''
    },
    components:{closeIcon},
    emits: ["close-model"],
    methods: {
      closeModal() {
        this.$emit("close-model", false);
      },
    },
    created() {
      document.addEventListener("keydown", (e) => {
        if (e.keyCode == 27) {
          this.$emit("close-model", false);
        }
      });
    }
  };
</script>
  