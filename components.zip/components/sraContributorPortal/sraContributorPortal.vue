<template>
    <div>
      <header-sra-contributor-portal />
      <full-page-loader v-if="is_full_page_loader_shown" />
      <div class="container pt30 pb60">
        <div v-if="progress_step != 0" class="font-24 font_semibold blueog--tex text-center mb15 line-normal">Contributor Portal</div>
        <p v-if="progress_step != 0" class="font-16 text-999 line-normal text-center mb20">Please review and answer the question(s) sent from {{ JS_LOCATION_DATA.company_name || '' }}.</p>
        <div v-if="progress_step != 0" class="vendor-onboarding-steps ba-agreement-steps flex flex-wrap mlr-auto line-normal mb35">
            <button type="button" class="vendor-onboarding-step-item flex-auto" :class="{'active' : progress_step == 1}"><div class="font_semibold font-14">Step 1 </div><div class="font_light font-13">Company Information</div></button>
            <button type="button" class="vendor-onboarding-step-item flex-auto" :class="{'active' : progress_step == 2}"><div class="font_semibold font-14">Step 2 </div><div class="font_light font-13">Answer Question(s)</div></button>
            <button type="button" class="vendor-onboarding-step-item flex-auto" :class="{'active' : progress_step == 3}"><div class="font_semibold font-14">Step 3 </div><div class="font_light font-13">Review and Complete</div></button>
        </div>
        <div v-if="progress_step == 1" class="vendor-onboarding-content mlr-auto mb29">
          <div class="font-22 blueog--text font_bold line-normal text-center mb5">{{ JS_LOCATION_DATA.company_name || '' }}</div>
          <div  class="font-22 blueog--text font_bold line-normal text-center">Primary Address:</div>
          <div class="font-22 blueog--text font_bold text-center mb20 line-normal">{{JS_LOCATION_DATA.address + ', ' + JS_LOCATION_DATA.city }}  <br> {{ JS_LOCATION_DATA.state.state_name + ', ' + JS_LOCATION_DATA.zip_code}} </div>
          <div style="max-width:752px; margin:0 auto;">
            <p class="font-16 text-999 mb20 line-normal">{{ JS_LOCATION_DATA.company_name || '' }} - {{ JS_LOCATION_DATA.location_nickname || '' }} is requesting your assistance to answer one or more HIPAA compliance questions for their Security Risk Analysis (SRA).</p>
            <p class="font-16 text-999 mb20 line-normal">Abyde conveniently provides a secure and automated SRA Contributor Portal for assistance on SRA questions.</p>
            <p class="font-16 text-999 mb20 line-normal font_bold">Follow the Steps:</p>
            <ol type="1" class="list-decimal pl18 mt0">
              <li><p class="font-16 text-999 line-normal">Click <span class="font-italic">START</span> below to load the question(s)</p></li>
              <li><p class="font-16 text-999 line-normal">Submit answers and optionally add notes</p></li>
              <li><p class="font-16 text-999 line-normal">Review &amp; Complete</p></li>
            </ol>
            <div class="text-red font-15 mb15">NOTE: Partial progress will not be saved and answers will not be sent until Step 3 of the SRA Contributor Portal is completed.</div>
            <p class="font-16 text-999 mb20 line-normal">Thank you in advance for taking HIPAA compliance seriously and securing Protected Health Information.</p>
          </div>
          <div class="text-center">
              <button type="button"
              class="btn-primary mx-auto mt40 d-inline-block px30 mt-xs-20 mlr-auto" @click="startAgreementProcess()">
              Start 
              </button>
          </div>

        </div>
        <div v-if="progress_step == 2" class="vendor-onboarding-content mlr-auto mb29">
          <question-detail @show-review="showReviewPage"/>
        </div>
        <div v-if="progress_step == 3 && all_questions && all_questions.length" class="vendor-onboarding-content mlr-auto mb29">
          <div v-for="(question, index) in all_questions" :key="question.id">
            <scorecard-list :loop_index="index" :attempted_question="question"  @update-edit-mode="updateEditMode" @get-attempted-question="getAttemptedQuestion" ></scorecard-list>
          </div>
          <div class="text-center">
            <button type="button" :disabled="is_btn_disabled" class="btn-primary mx-auto mt20 d-inline-block px30 mt-xs-20 mlr-auto" @click="completeContributorAnswer" >
            Complete 
            </button>
          </div>
        </div>
      </div>
      <complete-modal v-if="is_complete_modal_shown" :question_count="JS_QUESTION_COUNT"></complete-modal>
    </div>
</template>

<script scoped>
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from 'lodash';
import headerSraContributorPortal from '../common/includes/headerSraContributorPortal.vue';
import fullPageLoader from "../common/fullPageLoader.vue";
import questionDetail from "./questionDetail.vue";
import scorecardList from "./scorecardList.vue";
import completeModal from "./completeModal.vue";
import { isArray } from "lodash";
import axios from "axios";
import NProgress from "nprogress";

export default {
  data() {
    return {
      progress_step: 1,
      all_questions: [],
      is_full_page_loader_shown: false,
      JS_LOCATION_DATA: JS_LOCATION_DATA,
      JS_QUESTION_COUNT: JS_QUESTION_COUNT,
      is_btn_disabled: false,
      editModeStates: {},
      is_complete_modal_shown: false,
    };
  },
  components: {
    headerSraContributorPortal,
    fullPageLoader,
    questionDetail,
    scorecardList,
    completeModal
  },
  watch: {
    editModeStates: {
      deep: true,
      handler(newVal) {
        this.is_btn_disabled = Object.values(newVal).some(state => state === true);
      }
    }
  },
  mounted() {
    if(!JS_QUESTION_COUNT || JS_QUESTION_COUNT == 0){
      this.is_complete_modal_shown = true;
    }
  },
  created() {
    if(!JS_CONTRIBUTOR_DATA || !JS_LOCATION_DATA) {
      this.is_full_page_loader_shown = true;
      toastr.error("Seems like your contributor portal link has been expired!. Please contact support.", "Error");
      setTimeout(() => {
        window.location = JS_APP_URL + "/login";
      }, 1500);
    }
  },
  methods: {
    startAgreementProcess(){
      this.progress_step++;
    },
    showReviewPage(all_questions){
      this.all_questions = all_questions;
      this.progress_step++;
    },
    getAttemptedQuestion(payload,index){
      this.all_questions[index]['attempted_response'] = payload;
    },
    completeContributorAnswer(){
      this.is_btn_disabled = true;
      NProgress.start();
      let payload = {
        'location_id': this.JS_LOCATION_DATA.id,
        'question_answer': [],
      };
      const question_answers = this.all_questions.flatMap(question => {
        if (question.question.question_answer_layout === "text") {
          return [{
                risk_analysis_contributor_question_id: question.id,
                notes: question.attempted_response.note ?? null,
                answer: question.attempted_response.answer
          }];
        } else if (isArray(question.attempted_response.answer)) {
          return question.attempted_response.answer.map(answer => ({
              risk_analysis_contributor_question_id: question.id,
              notes: question.attempted_response.note ?? null,
              answer_id: answer
          }));
        }
        return [];
      });
      payload.question_answer = question_answers;
      axios
        .post(
          JS_APP_URL + "/sra-contributorportal/add-sra-contributor-complete-record",
          payload
        )
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.is_complete_modal_shown = true;
          } else {
            toastr.error(response["data"]["message"], "Error");
            setTimeout(() => {
              window.location = JS_APP_URL + "/login";
            }, 2000);
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_btn_disabled = false;
          NProgress.done();
        });
    },
    updateEditMode({ index, value }) {
      this.editModeStates[index] = value;
    }
  },
 
};
</script>
