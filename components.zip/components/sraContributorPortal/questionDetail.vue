<template>
  <div v-if="loaded">
    <full-page-loader v-if="is_full_page_loader_shown" />
    <h1 class="font-24 font_semibold blueog--text text-center mb-md-20 mb25">
      Security Risk Analysis
    </h1>
    <div class="security-progress-wrapper mb24">
      <radial-progress-bar class="sra-quetions-progress" :diameter="200" :completed-steps="percentage_count.percentage"
        :total-steps="total_steps_outer" :start-color="start_color_outer" :stop-color="start_color_outer"
        :inner-stroke-color="inner_stroke_color" :inner-stroke-width="3" :stroke-width="6">
        <h1 class="sra-percent-text font_semibold" v-bind:style="{ color: start_color_outer }">
          {{ percentage_count.percentage }}%
        </h1>
        <h3 class="sra-completed-text">Completed</h3>
      </radial-progress-bar>
    </div>
    <div class="text-center mb2">
      <span class="
              font-25 font_semibold
              blue--text
              inline-flex
              items-center
              flex-wrap
            ">
        {{ question_detail.question.question_category.category_title }}
        <VTooltip :triggers="['hover']" :popperTriggers="['hover']" style="height: 24px;" class="cursor-pointer ml10">
          <span><info-icon></info-icon></span>
          <template #popper>
            {{ question_detail.question.question_category.category_description ?
              question_detail.question.question_category.category_description : question_detail.question_category.category_title }}
          </template>
        </VTooltip>
      </span>
    </div>
    <div class="text-center mb18">
      <span class="
              font-16
              gray_checkmark--text
              inline-flex
              items-center
              flex-wrap
            ">
        {{ question_detail.question.question_law_section ? question_detail.question.question_law_section.title : "" }}
      </span>
    </div>
    <p class="font-25 black--text text-center mb50 quetion-text" v-html="question_detail.question.question">
    </p>
    <div class="sra-quetions-wrapper mlr-auto">
      <div class="row flex-auto justify-center -mx-10 mb15" v-if="question_detail.question.question_answer_layout == 'radio'">
        <div class="col-12 col-md-12 col-lg-4 col-xl-4 mb-md-20 px10"
          v-for="answer_opt in question_detail.question.risk_analysis_question_answer_options" :key="answer_opt.id">
          <div class="answer-option-item">
            <input type="radio" class="answer-option-radio" :id="'radio ' + answer_opt.id" :value="answer_opt.id"
              v-model="selected_answers" />
            <label class="answer-option-lable font-20 blueog--text" :for="'radio ' + answer_opt.id">{{ answer_opt.answer
            }}</label>
          </div>
        </div>
      </div>

      <div class="row flex-auto justify-center -mx-10 mb15" v-if="question_detail.question.question_answer_layout == 'checkbox'">
        <div class="col-12 col-md-12 col-lg-4 col-xl-4 mb-md-20 px10"
          v-for="answer_opt in question_detail.question.risk_analysis_question_answer_options" :key="answer_opt.id">
          <div class="answer-option-item">
            <input type="checkbox" class="answer-option-radio" :id="'radio ' + answer_opt.id" :value="answer_opt.id"
              v-model="selected_answers" />
            <label class="answer-option-lable font-20 blueog--text" :for="'radio ' + answer_opt.id">{{ answer_opt.answer
            }}</label>
          </div>
        </div>
      </div>

      <div v-if="question_detail.question.question_answer_layout == 'text'">
        <div class="mb15 relative">
          <textarea rows="4" class="textarea form-input" v-model.trim="answer_txt"></textarea>
          <label class="label location-input-label" :class="{ 'label-float': answer_txt }">Please enter an answer</label>
        </div>
      </div>

      <div v-if="show_error" class="mb10 font-12 red2--text">
        <div v-if="question_detail.question.question_answer_layout == 'radio'" class="text-center font-16 font_bold">
          * Please select an answer to continue
        </div>
        <div v-if="question_detail.question.question_answer_layout == 'checkbox'" class="text-center font-16 font_bold">
          * Please select answer(s) to continue
        </div>
        <div v-if="question_detail.question.question_answer_layout == 'text'" class="text-center font-16 font_bold">
          * Please enter an answer to continue
        </div>
      </div>

      
      <div class="flex items-start justify-between w-full ">
        <button :disabled="!has_review_note" type="button" class="
                btn-blue-outline btn-width-136
                h-32
                d-inline-flex items-center
                px30
                mt-xs-20
                mr15
              "
              @click="reviewNoteModalToggle()"
              >
              <span class="header-a-dot" v-if="has_review_note">DOT</span>
              <img :src="JS_APP_URL +'/images/checklist_note_btn.svg'" alt="" title="" class="mr4">
          <span class="mt2">REVIEW NOTE</span>
        </button>

        <div class="relative sra-add-comment mx-4 flex-1">
          <div v-if="toggle_comment_box">
            <div class="text-center sra-textarea-wrapper">
              <div class="textarea-box relative">
                <textarea rows="4" class="textarea form-input" :maxLength="max_characters_comment"
                  v-model.trim="note_txt"></textarea>
                <label class="label location-input-label" :class="{ 'label-float': note_txt }">Add Note</label>
                <button type="button" class="bin-btn" @click="
                  () => {
                    this.note_txt = '';
                  }
                ">
                  <img :src="JS_APP_URL + '/images/bin.svg'" alt="" title="">
                </button>
              </div>
              <div class="relative text-left font-11 save-hint-text">
                Your note will be saved upon hitting button NEXT
              </div>
              <div class="relative textarea-remaining-text">
                <div class="
                        font-10
                        fotn-light
                        gray_checkmark--text
                        text-right
                        textarea-character-count
                      ">
                  {{ reamining_characters_comment }} Characters Remaining
                </div>
              </div>
            </div>
          </div>
        </div>

        <button type="button" class="
                btn-blue-outline btn-width-136
                h-32
                d-inline-block
                px30
                mt-xs-20
                ml22
                justify-end flex
              " @click="toggleCommentBox" :disabled="is_btn_disabled">
          ADD NOTE
        </button>
      </div>

      <div class="text-center relative mt12">
        <div class="text-left mb-md-20">
        <button type="button" class="btn-blue-outline btn-width-136 prev-btn" @click="loadPreviousQuestion" v-if="current_question > 0"
            :disabled="is_btn_disabled">
            Back
        </button>
        </div>
      
        <button type="submit" class="btn-primary btn-width-136 h-32 d-inline-block px30 next-btn"
          @click="loadNextQuestion" :disabled="is_btn_disabled">
          Next
        </button>
      </div>
    </div>
  </div>
  <review-note-modal
  v-if="show_review_note_modal"
  @close-model="reviewNoteModalToggle"
  :review_note="(question_detail.attempted_question && question_detail.attempted_question[0]) ? question_detail['attempted_question'][0]['note'] : ''"
  />
</template>

<script>
import axios from "axios";
import RadialProgressBar from "vue3-radial-progress";
import previousIcon from "../common/icons/previousIcon.vue";
import infoIcon from "../common/icons/infoIcon.vue";
import binIcon from "../common/icons/binIcon.vue";
import toastr from "toastr";
import "toastr/toastr.scss";
import _ from 'lodash';
import fullPageLoader from "../common/fullPageLoader.vue";
import reviewNoteModal from "./reviewNoteModal.vue";

let given_answer = "";
let given_note = "";

export default {
  props: {
  },
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_LOCATION_DATA: JS_LOCATION_DATA,
      JS_CONTRIBUTOR_ID:JS_CONTRIBUTOR_ID,
      JS_CONTRIBUTOR_TYPE:JS_CONTRIBUTOR_TYPE,
      current_question:0,
      inner_stroke_color: "#CCCCCC",
      percentage_count: {},
      total_steps_outer: 100,
      start_color_outer: "#CCCCCC",
      start_color_inner: "#203C72",
      strokeLinecap: "",
      all_questions: {},
      question_detail: {},
      toggle_comment_box: false,
      selected_answers: [],
      last_answer_data: {},
      answer_txt: "",
      note_txt: "",
      has_previous: false,
      loaded: false,
      show_error: false,
      max_characters_comment: 1000,
      reamining_characters_comment: 1000,
      is_btn_disabled: false,
      has_comment: false,
      is_full_page_loader_shown: true,
      is_exit_pressed: false,
      has_review_note: false,
      show_review_note_modal: false
    };
  },
  emits: [ "show-page",'show-review'],
  components: {
    RadialProgressBar,
    previousIcon,
    infoIcon,
    binIcon,
    fullPageLoader,
    reviewNoteModal
  },

  mounted() {
    this.loadQuestion();
  },

  watch: {
    percentage_count(val) {
      if (val.percentage <= 69) {
        this.start_color_outer = "#C72121";
      } else if (val.percentage > 69 && val.percentage <= 89) {
        this.start_color_outer = "#FAC224";
      } else {
        this.start_color_outer = "#7FC361";
      }
    },
    selected_answers(val) {
      this.show_error = false;
    },
    answer_txt(val) {
      if (val != "") {
        this.show_error = false;
      }
    },
    note_txt(val) {
      this.note_txt = (val) ? val.replace(/\n|\r|  +/g, "") : "";
      if (val) {
        this.reamining_characters_comment =
          this.max_characters_comment - val.length;
      } else {
        this.reamining_characters_comment = this.max_characters_comment;
      }
    },
  },

  methods: {
    getPercentageCount() {
      var total_questions = this.all_questions.length;
      var attempted_questions_count = this.all_questions.filter(q => q.attempted_response !== undefined).length;
      var per = 0
      if (total_questions > 0) {
          per = (attempted_questions_count / total_questions) * 100;
      }
      this.percentage_count = {
        'total_questions' : total_questions,
        'attempted_questions' : attempted_questions_count,
        'percentage' : Math.round(per)
      }
    },
   
    loadQuestion() {
      this.is_full_page_loader_shown = true;
      this.has_comment = false;
      this.selected_answers = [];
      this.is_btn_disabled = true;
      let payload = {
        location_id: this.JS_LOCATION_DATA.id,
        contributor_id: this.JS_CONTRIBUTOR_ID,
        contributor_type: this.JS_CONTRIBUTOR_TYPE
      };

      axios
      .post(
        JS_APP_URL + "/sra-contributorportal/load-risk-analysis-question",
        payload
      )
      .then((response) => {
        if (response["data"]["status"] == "Success") {
          let data = response["data"]["data"];
          this.note_txt = "";
          this.answer_txt = "";
          if (data.question_detail == null) {
              this.$emit("show-page");
              toastr.error('There is some technical issue. Please contact Abyde support!', "Error");
          } else {
            this.all_questions = data.question_detail;
            this.question_detail = data.question_detail[0];
            this.current_question = 0;
            if (this.question_detail['attempted_question'][0] && this.question_detail['attempted_question'][0]['note'] != null) {
              this.has_review_note = true;
            } else {
              this.has_review_note = false;
            }
            this.getPercentageCount();
          }
        } else {
          toastr.error(response["data"]["message"], "Error");          
          window.location = JS_APP_URL + "/login";
          return false;
        }
        this.loaded = true;
        this.toggle_comment_box = false;
        this.is_btn_disabled = false;
        this.is_full_page_loader_shown = false;
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";
        }
      });
    },

    loadPreviousQuestion() {
      this.current_question--;
      this.toggle_comment_box = false;
      if (this.current_question >= 0) {
        this.question_detail = this.all_questions[this.current_question];
        
        if (this.question_detail.attempted_response) {
          this.note_txt = this.question_detail.attempted_response.note;
          if (this.note_txt) {
            this.has_comment = true;
            this.toggle_comment_box = true;

          }
          given_note = this.question_detail.attempted_response.note;

          if (this.question_detail.question.question_answer_layout == "text") {
            this.answer_txt = this.question_detail.attempted_response.answer;
            given_answer = this.answer_txt;
          } else if (this.question_detail.question.question_answer_layout == "checkbox") {

            this.selected_answers = this.question_detail.attempted_response.answer;
            given_answer = [...this.selected_answers];
          } else if (this.question_detail.question.question_answer_layout == "radio") {

            this.selected_answers = this.question_detail.attempted_response.answer[0];
            given_answer = this.selected_answers;
          }
        }
        else{
          this.answer_txt = "";
          this.note_txt = "";
          this.show_error = false;
          this.has_comment = false;
          this.toggle_comment_box = false;

        }

        if (this.question_detail['attempted_question'][0] && this.question_detail['attempted_question'][0]['note'] != null) {
          this.has_review_note = true;
        } else {
          this.has_review_note = false;
        }
      }
      else{
        this.current_question = 0
      }
    },

    loadNextQuestion() {
      this.is_exit_pressed = false;
      this.toggle_comment_box = false;
      let check_ans_same;
      if (this.question_detail.question.question_answer_layout == "text") {
        check_ans_same = given_answer == this.answer_txt;
      } else if (this.question_detail.question.question_answer_layout != "text") {
        if (_.isArray(this.selected_answers)) {
          check_ans_same = _.isEqual(
            _.sortBy(this.selected_answers),
            _.sortBy(given_answer)
          );
        } else {
          check_ans_same = this.selected_answers == given_answer;
        }
      }

      if (given_answer == "" || (given_answer != "" && (this.note_txt != given_note || !check_ans_same))) {
        given_answer = "";
        this.saveAnswer(check_ans_same);
      } else {

        this.last_answer_data = {
          question_id: this.question_detail.id,
        };
        if (this.question_detail.question.question_answer_layout != "text") {
          this.last_answer_data.answer_id = this.selected_answers;
        }
        this.selected_answers = [];
        given_answer = "";
      }
      if (!this.show_error) {
        this.current_question++;
      }
      //Load Next Question
      if (this.current_question < this.all_questions.length && !this.show_error) {
        this.question_detail = this.all_questions[this.current_question];
        if (this.question_detail.attempted_response) {
          this.note_txt = this.question_detail.attempted_response.note;
          if (this.note_txt && this.note_txt != "") {
            this.has_comment = true;
            this.toggle_comment_box = true;

          }
          given_note = this.question_detail.attempted_response.note;

          if (this.question_detail.question.question_answer_layout == "text") {
            this.answer_txt = this.question_detail.attempted_response.answer;
            given_answer = this.answer_txt;
          } else if (this.question_detail.question.question_answer_layout == "checkbox") {
            this.selected_answers = this.question_detail.attempted_response.answer;
            given_answer = [...this.selected_answers];
          } else if (this.question_detail.question.question_answer_layout == "radio") {
            this.selected_answers = this.question_detail.attempted_response.answer[0];
            given_answer = this.selected_answers;
          }
        }
        else{
          this.answer_txt = "";
          this.note_txt = "";
          this.show_error = false;
          this.has_comment = false;
          this.toggle_comment_box = false;


        }
        if (this.question_detail['attempted_question'][0] && this.question_detail['attempted_question'][0]['note'] != null) {
          this.has_review_note = true;
        } else {
          this.has_review_note = false;
        }
        this.getPercentageCount();
      }

      if (this.current_question == (this.all_questions.length ) && !this.show_error) {
        this.$emit("show-review", this.all_questions);
      }
    },

    toggleCommentBox() {
      if (this.toggle_comment_box) {
        this.toggle_comment_box = false;
        this.note_txt = "";
      } else {
        this.has_comment = false;
        this.toggle_comment_box = true;
      }
    },

    removeComment() {
      this.note_txt = "";
      this.has_comment = false;
    },

    reviewNoteModalToggle(status = true) {
      this.show_review_note_modal = status;
    },

    saveAnswer() {
      let payload = {}
      payload.note = this.note_txt;
      if (this.question_detail.question.question_answer_layout == "text") {
        if (this.answer_txt == "") {
          this.show_error = true;
        } else {
          payload.answer = this.answer_txt;
        }
      } else {
        if (this.selected_answers) {
          if (this.selected_answers.length <= 0) {
            this.show_error = true;
          } else {
            if (!Array.isArray(this.selected_answers)) {
              payload.answer = [this.selected_answers];
              payload.answer_obj = this.question_detail.question.risk_analysis_question_answer_options.find(
                (item) => item.id === this.selected_answers
              );
             
            } else {
              payload.answer = this.selected_answers;
              payload.answer_obj = this.question_detail.question.risk_analysis_question_answer_options.filter(
                (item) => Object.values(this.selected_answers).includes(item.id)
              );
            }
          }
        }
      }
      if (!this.show_error) {
        this.all_questions[this.current_question].attempted_response = payload;
        this.last_answer_data = payload;
        this.selected_answers = [];
        this.note_txt = "";
        this.answer_txt = "";
        if (this.is_exit_pressed) {
          this.$emit("show-page");
        }
      }
    }

  },
};
</script>
