<template>
  <Teleport to="body">
    <transition name="modal">
        <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
            <div class="modal-container">
            <div class="text-center mlr-auto mb30 pt20">
                <img :src="JS_APP_URL + '/images/envelop-done.svg'" alt="" title="" class="warning-icon-modal" />
            </div>
            <h2
                class="
                font-24 font_semibold blueog--text line-normal text-center mb20
                "
            >
                Congratulations!
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb15">
              <span v-if="question_count > 0">Thank you for completing the SRA questions.</span>
              <span v-else>Your assigned questions have been finished. No further questions are available for now.</span>
            </p>
            <div class="flex flex-wrap items-center justify-center pb40">
                <button  v-on:click="goToLogin" class="btn-blueog-outline mx5">CLOSE WINDOW</button>
            </div>
            </div>
        </div>
        </div>
    </transition>
  </Teleport>
</template>

<script scoped>

export default {
  components:{},
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  props: {
    question_count: Number
  },
  methods: {
    
    goToLogin(){
      window.location = JS_WORDPRESS_URL;
    }
  }
};
</script>
