<template>
  <div>
    <header-after-login></header-after-login>
      <div class="container pt40 pb60">
        <div class="relative text-center">
          <a :href="JS_APP_URL + '/dashboard/'" class="btn-blue-outline prev-btn">
            <div class="prev-arrow-icon"><previous-icon></previous-icon></div>
              Back
          </a>        
          <h1 class="
              location-dashbaord-title
              text-center
              font-28 font_semibold
              blueog--text
              line-normal mb25
            ">
            Ready to elevate your compliance game?
          </h1> 
        </div>
      <p class="text-center font-16 font_normal black--text mb40">Upgrade your account to Abyde’s full-featured compliance platform. Enter your total number of locations and select your employee range across all locations for a pro-rated upgrade quote.</p>       
      <div class="upgrade-inputs flex justify-center">
        <div class="form-group upgrade-input-item" :class="{ 'form-group--error': v$.user_current_location_limit.$errors.length }">
            <input v-mask="'000'" @click.right.prevent @copy.prevent @paste.prevent class="form-input" :class="{ 'form-error': v$.user_current_location_limit.$errors.length }" type="text" id="user_current_location_limit" name="user_current_location_limit" v-model.trim="v$.user_current_location_limit.$model">
            <label class="label font_light" :class="{ 'label-float': v$.user_current_location_limit.$model }">Total Locations</label>
            <div v-if="v$.user_current_location_limit.$errors.length > 0">
              <div class="form-error-text">
                {{ v$.user_current_location_limit.$errors[0].$message }}
              </div>
            </div>
        </div>
        <div class="form-group upgrade-input-item">
            <div class="col-12 col-20-company px0">
                <div :class="{ 'form-group--error': v$.user_current_employee_limit.$errors.length }">
                    <multiselect
                    class="font-style-normal"
                    v-model.trim="employee_limit_obj"
                    placeholder=""
                    :options="all_employee_limit_list"
                    track-by="id"
                    label="limit"
                    :multiple="false"
                    :close-on-select="true"
                    position="bottom"
                    :showLabels="false"
                    :taggable="false"
                    @update:model-value="onEmployeeLimitOption"
                    :class="{ 'form-error': v$.user_current_employee_limit.$error.length }"
                    :allowEmpty="false">
                    <template #noResult>
                      <div class="multiselect__noResult text-center">No results found</div>
                    </template>
                    </multiselect>
                    <label class="label label-select" :class="{ 'label-float': (v$.user_current_employee_limit.$model) }">Total Employees</label>
                    <div v-if="v$.user_current_employee_limit.$errors.length > 0">
                      <div class="form-error-text">
                        {{ v$.user_current_employee_limit.$errors[0].$message }}
                      </div>
                    </div>
                </div>
            </div>
        </div>        
      </div>
      <div class="text-center">
        <div class="sra-upgrade-column flex flex-wrap">
            <div class="pricing-box pricing-hippa pricing-active">
              <div class="pricing-box-header text-center pricing-single-header">
                <div class="pricing-logo-text mt1">
                  <span class="pricing-box-heading">HIPAA</span>
                  <span class="info_bg inline product_tipso tipso_style hipaace_info_bg">

                    <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" style="height: 27px;" class="cursor-pointer"><info-icon class="cursor-pointer ml2"></info-icon>
                    <template #popper>
                        Under HIPAA, Covered Entities are the health plans and care providers who directly handle and must safeguard patients' protected health information (PHI).
                    </template>
                    </VTooltip>                    
                  </span>
                  <br/>
                  <sub>FOR COVERED ENTITIES</sub>
                </div>
              </div>
              <div class="pricing-content text-center">
                <div class="pricing-price">
                  <div class="d-flex justify-center mb6"><span class="pricing-value">{{numberFormatter().format(monthly_amount)}}</span> <span class="pricing-year self-end">/mo</span></div>
                  <div class="pricing-tax-text">*Billed {{(plan_type == 'yearly')?'Annually':'Bi-Annually'}}</div>
                  <div class="pricing-tax-text">*Not including applicable state &amp; local sales tax</div>
                </div>
              </div>
              <transition name="modal">
                    <div class="pricing-price-more" :class="{'active': show_more_details_toggle}" >
                      <p class="pricing-desc pb6">HIPAA for Covered Entities - the easiest software you will ever use.</p>
                      <p class="pricing-desc">- Digital documentation</p>
                      <p class="pricing-desc">- Dynamically generated policies</p>
                      <p class="pricing-desc">- Security Risk Assessment</p>
                      <p class="pricing-desc">- Training on your time</p>
                      <p class="pricing-desc">- Automated notifications</p>
                      <p class="pricing-desc">- Unrivaled education</p>
                      <p class="pricing-desc">- Breach Portal</p>
                      <p class="pricing-desc pb6">- Digital file storage</p>
                    </div>
              </transition>
              <div class="product_more_details_link">
                <a @click="expandProductDetails">{{(show_more_details_toggle)?'Less':'More'}} details
                 <img :src="JS_APP_URL + '/images/down-small-arrow.svg'" alt="" title="" class="ml5" />
                </a>
              </div> 
            </div>
          <div class="sra-upgrade-box">
            <div class="flex flex-wrap relative sra-promo-div mb50">
              <button class="pricing-time-item" :class="{'pricing-time-item-selected': plan_type == 'yearly'}" @click="getPaymentAmountByType('yearly')">ANNUALLY</button>
              <button class="pricing-time-item" :class="{'pricing-time-item-selected': plan_type == 'biannually'}" @click="getPaymentAmountByType('biannually')">BI-ANNUALLY</button>
              <button class="sra-usd-button" @click="hidePromoDiv" v-if="this.is_show_promo_div == false">$</button>
              <div class="promo-code-box relative" v-if="this.is_show_promo_div">
                <input type="text" v-model.trim = "entered_promocode" class="promo-code-input font_semibold font-13 uppercase full-width" placeholder="Promo code">
                <button v-if="Object.keys(promocode_data).length == 0" v-on:click="applyPromocode()" class="promo-btn font_semibold font-13 uppercase white--text blueog2" type="button">Apply</button>
                <button v-if="Object.keys(promocode_data).length > 0" v-on:click="removePromocode()" type="button" class="promo-btn font_semibold font-13 uppercase white--text remove-btn">REMOVE</button>
              </div>
              <div class="get-free-xtra get-free-xtra-locked-both">
                <img :src="JS_APP_URL + '/images/free-arrow.svg'" alt="" title="" />
                Get 10% off when you pay upfront!
                </div>
              </div>
              <div class="sra-upgrade-div">
                <div class="font-28 font_semibold blue--text mb18">Upgrade Amount</div>
                <div class="flex items-center justify-center">
                  <div class="upgrade-amount-block flex items-center justify-center flex-col light mb12 mlr-auto">
                      <div class="upgrade-price font-55 blue--text font_semibold line-normal">{{numberFormatter().format(upgrade_amount)}}</div>
                      <div class="font-14 black--text font_light font-italic mt10" v-if="Object.keys(promocode_data).length > 0 && promocode_data.discount_type == 'percentage'">Includes {{promocode_data.discount_percentage}}% Discount</div>
                      <div class="font-14 black--text font_light font-italic mt10" v-if="Object.keys(promocode_data).length > 0 && promocode_data.discount_type == 'fixed_amount'">Includes ${{promocode_data.discount_amount / 100}} Discount</div>
                      <div class="font-italic dark--text font-14 font_light" v-if="plan_type == 'yearly'">Includes 10% Annual Discount</div>
                  </div>
                  </div>
                  <div class="font_semibold blue--text font-16 mb10">Your Next {{(plan_type == 'yearly')?'Yearly':'Bi-Annually'}} Payment Amount: {{numberFormatter().format(next_yearly_payment_amount)}}</div>
                  <div class="font_semibold blue--text font-16 mb10" v-if="save_credit_amount != 0">Your credit amount {{numberFormatter().format(save_credit_amount)}} will be add in next payment.</div>
              </div>
          </div>
        </div>

        <div class="font-16 blue--text font_semibold mt10" v-if="sales_tax.length > 0">
          Above price is inclusive of below Sales Tax (State & Local):
          <p class="font-14 black--text font_light font-italic mt5" v-for="(st, index) in sales_tax" :key="index">                        
           {{st.percentage}}
          </p>
        </div>
        
        <p class="font-16 black--text mb30 mt30" >
          Note: Upgrade amount is pro-rated based on renewal date and will be charged<br class="hidden-sm hidden-md"/> immediately. Renewal pricing will include the full upgrade amount for the next year. Questions? Contact Us below. 
        </p>
        <div class="flex justify-center align-center flex-wrap mt20">
          <button type="button" class="btn-primary btn-blue btn-sra-contact h-32 mx30" @click="contactModalToggle">Contact Us</button>
          <button type="button" class="btn-primary btn-upgrade h-32 mx30" :disabled="is_upgrade_btn_disabled" @click="upgradeConfirmToggle"><span>Upgrade now!</span></button>
        </div>

      </div>
      </div>
      <contact-modal 
        v-if="is_contact_modal_shown"
        @close-model="contactModalToggle"
      >
      </contact-modal>
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    <upgrade-confirm-modal 
        v-if="is_upgradeconfirmmodal_shown"
        @close-model="upgradeConfirmToggle"
        @call-do-upgrade="doUpgrade"
    >
    </upgrade-confirm-modal>
  </div>
</template>

<script>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import _ from 'lodash';
import { useVuelidate } from '@vuelidate/core';
import { required, numeric, helpers } from "@vuelidate/validators";
import contactModal from "../common/includes/contactModal.vue";
import fullPageLoader from "../common/fullPageLoader.vue";
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import infoIcon from "../common/icons/infoIcon.vue";
import previousIcon from "../common/icons/previousIcon.vue";
import upgradeConfirmModal from "./upgradeConfirmModal.vue";

export default {
  data() {
    return {
      JS_SUPPORT_EMAIL : SUPPORT_EMAIL,
      JS_APP_URL: JS_APP_URL,
      is_full_page_loader_shown: false,
      employee_max_limit:'',
      location_max_limit:'',
      user_current_employee_limit:'',
      user_current_location_limit:'',
      user_current_location_limit_old:'',
      user_current_employee_limit_old:'',
      all_employee_limit_list: [],
      employee_limit_obj: {},
      is_upgrade_btn_disabled: true,
      plan_type: 'yearly',
      sales_tax: [],
      promocode_data: {},
      is_contact_modal_shown:false,
      is_upgradeconfirmmodal_shown:false,
      show_more_details_toggle: false,
      next_yearly_payment_amount: 0,
      monthly_amount: 0,
      upgrade_amount: 0,
      save_credit_amount: 0,
      entered_promocode: '',
      is_show_promo_div: false,
      AUTH_USER: AUTH_USER,
    };
  },
  components: {
    contactModal,
    fullPageLoader,
    headerAfterLogin,
    infoIcon,
    previousIcon,
    upgradeConfirmModal,
  },
  setup: () => ({ v$: useVuelidate() }),
  validations() {
    var validationArray = {
      user_current_location_limit:{
        required: helpers.withMessage("Please enter a new location limit", required),
        numeric: helpers.withMessage("Please enter a valid location limit", numeric)
      },
      user_current_employee_limit: {
        required: helpers.withMessage("Please select an employee limit", required),
      }
    };
    return validationArray;
  },
  mounted() {
    this.loadUserCurrentPlanInformation();
  },
  watch: {
      user_current_employee_limit(newVal, oldVal){
      },
      user_current_location_limit: _.debounce(function(newVal, oldVal){
          if(newVal == ''){
            this.is_upgrade_btn_disabled = true;
          }
          else if(newVal != oldVal )
          {
              this.on_location_limit_change()
          }
      }, 1000)
  },
  methods: {
    numberFormatter(){
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
      });
    },
    loadUserCurrentPlanInformation(){
      this.is_full_page_loader_shown = true;
      axios
      .get(JS_APP_URL + "/sra-only-full-upgrade/get-location-employee-information")
      .then((response) => {
        this.all_employee_limit_list = response["data"]["data"]["employee_limit"];
        this.user_current_location_limit = response["data"]["data"]["user_current_location_limit"];
        this.user_current_employee_limit = response["data"]["data"]["employee_limit"][0]['limit'];
        this.employee_limit_obj = response["data"]["data"]["employee_limit"][0];
        this.user_current_employee_limit_old = response["data"]["data"]["employee_limit"][0];
        this.user_current_location_limit_old = response["data"]["data"]["user_current_location_limit"];
        this.employee_max_limit = response["data"]["data"]["employee_max_limit"];
        this.location_max_limit = response["data"]["data"]["location_max_limit"];
        this.calculateprice();
      })
      .catch((error) => {
        toastr.error(error.response["data"]["message"], "Error");
        if (error.response.status === 401) {
          window.location = JS_APP_URL + "/login";
        }
      })
      .then(() => {
        setTimeout(() => {
          this.is_full_page_loader_shown = false;
        }, 500);
      });
    },
    onEmployeeLimitOption(){
      if(_.isNull(this.employee_limit_obj) == false){
        this.user_current_employee_limit = this.employee_limit_obj.limit;
        if(this.employee_limit_obj.max_limit >= this.employee_max_limit){
          toastr.success("Wow, that's a large organization! Please contact us at "+this.JS_SUPPORT_EMAIL+" so we can provide you with special pricing.", "Success");
          this.employee_limit_obj = this.user_current_employee_limit_old;
          this.user_current_employee_limit = this.employee_limit_obj.limit;
          this.is_upgrade_btn_disabled = true;
          this.user_current_location_limit = this.user_current_location_limit_old;
        }
        this.calculateprice();
      }else{
        this.user_current_employee_limit = '';
      }
    },
    on_location_limit_change(){
      this.v$.$touch();
      if (!this.v$.$invalid) {
        if(this.user_current_location_limit > this.location_max_limit){
          toastr.success("Wow, that's a large organization! Please contact us at "+this.JS_SUPPORT_EMAIL+" so we can provide you with special pricing.", "Success");
          this.user_current_location_limit = this.user_current_location_limit_old;
          this.employee_limit_obj = this.user_current_employee_limit_old;
          this.is_upgrade_btn_disabled = true;
          return false;
        }
        if(this.user_current_location_limit == this.user_current_location_limit_old){
          this.is_upgrade_btn_disabled = true;
          this.calculateprice();
        }
        if(this.user_current_location_limit < this.user_current_location_limit_old){
          toastr.error("You can't downgrade package!", "Error");
          this.user_current_location_limit = this.user_current_location_limit_old;
          this.is_upgrade_btn_disabled = true;
          return false;
        }
        
        if(this.user_current_location_limit != this.user_current_location_limit_old){
          this.calculateprice();
        }
      }
    },
    calculateprice(){
      this.v$.$touch();
      if (!this.v$.$invalid) {
        this.is_full_page_loader_shown = true;
        NProgress.start();
        var formData = new FormData();
        formData.append("location_limit", this.user_current_location_limit);
        formData.append("employee_max_limit", this.employee_limit_obj.max_limit);
        formData.append("plan_type", this.plan_type);
        if(!_.isEmpty(this.entered_promocode)) {
          formData.append("entered_promocode", this.entered_promocode);
        } else {
          formData.append("entered_promocode", '');
        }
        if (this.AUTH_USER.reseller !== undefined) {
          formData.append("user_type", 'Reseller');
        } else {
          formData.append("user_type", 'Normal');
        }
        axios
        .post(JS_APP_URL + "/sra-only-full-upgrade/get-chargebee-price-upgrade-estimation", formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        })
        .then((response) => {
            if (response["data"]["status"] == "Error") {
                this.is_upgrade_btn_disabled = true;
                if(response["data"]['data'].length > 0){
                  toastr.error(response["data"]['data'].join('</br>'), "Error");
                }else{
                  if(!_.isUndefined(response["data"]['data']['error_type']) && response["data"]['data']['error_type'] == 'coupon'){
                    this.entered_promocode = '';
                    this.promocode_data = {};
                  }
                  toastr.error(response["data"]["message"], "Error");
                }
            } else {
              this.next_yearly_payment_amount = response["data"]["data"]["next_yearly_payment_amount"];
              this.monthly_amount = response["data"]["data"]["monthly_amount"];
              this.upgrade_amount = response["data"]["data"]["upgrade_amount"];
              this.save_credit_amount = response["data"]["data"]["save_credit_amount"];
              this.is_upgrade_btn_disabled = false;
              if(response["data"]['data']['discounts']){
                this.promocode_data = response["data"]['data']['discounts'];
              }
              if(response["data"]['data']['taxes']){
                this.sales_tax = response["data"]['data']['taxes'];
              }else{
                this.sales_tax = [];
              }
            }
        })
        .catch((error) => {
          this.is_upgrade_btn_disabled = true;
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
          this.is_full_page_loader_shown = false;
        })
      }
    },
    doUpgrade(){
      this.v$.$touch();
      if (!this.v$.$invalid) {
        this.is_full_page_loader_shown = true;
        this.is_upgrade_btn_disabled = true;
        NProgress.start();
        if(this.upgrade_amount < 0.50 && this.upgrade_amount > 0) {
          NProgress.done();
          this.is_full_page_loader_shown = false;
          this.is_upgradeconfirmmodal_shown = false;
          toastr.error("Amount must be at least $0.50 usd.", "Error");
          return false;
        }
        var formData = new FormData();
        formData.append("location_limit", this.user_current_location_limit);
        formData.append("employee_limit", this.user_current_employee_limit);
        formData.append("employee_max_limit", this.employee_limit_obj.max_limit);
        formData.append("plan_type", this.plan_type);
        if(!_.isEmpty(this.promocode_data)) {
          formData.append("entered_promocode", this.promocode_data.id);
        } else {
          formData.append("entered_promocode", '');
        }
        if (this.AUTH_USER.reseller !== undefined) {
          formData.append("user_type", 'Reseller');
        } else {
          formData.append("user_type", 'Normal');
        }
        axios
        .post(JS_APP_URL + "/sra-only-full-upgrade/doupgrade", formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            this.is_upgrade_btn_disabled = true;
            toastr.error(response["data"]["message"], "Error");
          } else {
            toastr.success(response["data"]["message"], "Success");
            setTimeout(() => {                  
              window.location = JS_APP_URL + "/dashboard";
            }, 500);
          }
        })
        .catch((error) => {
          this.is_upgrade_btn_disabled = true;
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
          this.is_full_page_loader_shown = false;
          this.is_upgradeconfirmmodal_shown = false;
        })
      }
    },
    upgradeConfirmToggle(status = true){
      this.v$.$touch();
      if (!this.v$.$invalid) {
        this.is_upgradeconfirmmodal_shown = status;
      }
    },
    contactModalToggle(){
      this.is_contact_modal_shown = !this.is_contact_modal_shown;
    },
    expandProductDetails() {
      this.show_more_details_toggle = !this.show_more_details_toggle;
    },
    getPaymentAmountByType(type) {
      this.plan_type = type;
      this.calculateprice();
    },
    applyPromocode(){
      if(this.entered_promocode != ''){
        this.calculateprice();
      }else{
        toastr.error('Please enter a promo code!', 'Error!');
      }
    },
    removePromocode(){
      this.entered_promocode = '';
      this.promocode_data = {};
      this.calculateprice();
    },
    hidePromoDiv() {
      this.is_show_promo_div = true;
    },
  },
};
</script>