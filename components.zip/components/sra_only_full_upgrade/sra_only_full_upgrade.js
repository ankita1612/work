import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import 'floating-vue/dist/style.css';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import VueMask from '@devindex/vue-mask';
import upgrade from "./sra_only_full_upgrade.vue";

const upgrade_app = createApp(upgrade);
upgrade_app.use(VueMask);
upgrade_app.use(FloatingVue);
upgrade_app.component('multiselect', Multiselect);
upgrade_app.mount("#sra_only_full_upgrade");
