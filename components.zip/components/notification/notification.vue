<template>
  <div>
    <header-after-login></header-after-login>
    <div class="container pt30">
      <div class="flex justify-center flex-wrap mb15 relative">
        <div class="col-12 col-md-12 col-lg-12 col-xl-4 px10" v-if="all_locations.length>1">
          <div class="form-group mb-0 location-dropdon mlr-auto">
              <multiselect
                class="company-location-select"
                v-model="selected_location"
                :options="all_locations"
                label="location_nickname"
                :taggable="false"
                :multiple="false"
                :close-on-select="true"
                :showLabels="false"
                track-by="id"
                placeholder=""
                :allowEmpty="false"
              >
                <template #noResult>
                  <div class="multiselect__noResult text-center">
                    No results found
                  </div>
                </template>
              </multiselect>
              <label class="label label-select label-float" >Location</label>
          </div>
        </div>
      </div>
      <div class="flex items-center justify-center flex-wrap">
        <h1
          class="
            location-dashbaord-title
            text-center
            font-24 font_semibold
            blueog--text
            line-normal
            mb30
            mb-sm-10 mb-md-10
          "
        >
          Notifications
        </h1>
        <VTooltip :triggers="['hover']" :popperTriggers="['hover']" class="ml6 mb30 mb-md-10 mb-sm-10">
            <button @click="PlayExplainerVideoModalToggle('yes')" class="cursor-pointer svg-icon-height dashboard-video-icon mt4">
              <explainer-video-icon></explainer-video-icon>
            </button>
            <template #popper>
              Video Guide
            </template>
        </VTooltip>
      </div>
    </div>

    <div class="training-tabs-wrapper pb50">
      <div class="training-tab-nav">
        <div class="container flex items-center justify-between flex-wrap">
          <button
            type="button"
            class="training-tab-nav-item font-21 mr2"
            :class="{ active: active_tab == 'open' }"
             @click="changeTab('open')"
          >
            Open
          </button>
          <button
            type="button"
            class="training-tab-nav-item sharp-tab-item font-21 mr2"
            :class="{ active: active_tab == 'completed' }"
            @click="changeTab('completed')"
          >
            Completed 
          </button>
          <button
            type="button"
            class="training-tab-nav-item sharp-tab-item font-21"
            :class="{ active: active_tab == 'all' }"
            @click="changeTab('all')"
          >
            All
          </button>
        </div>
      </div>    
       <notification-list 
       :active_tab="active_tab"
       :selected_location="selected_location" /> 
    </div>
   
    <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>

    <play-explainer-video-modal v-if="play_video_modal == true" :video_file="video_file"
      :video_caption_file="video_caption_file" @close-model="PlayExplainerVideoModalToggle"></play-explainer-video-modal>
  </div>
</template>

<script>
import axios from "axios";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../common/fullPageLoader.vue";
import headerAfterLogin from "../common/includes/headerAfterLogin.vue";
import notificationList from './notificationList.vue';
import explainerVideoIcon from "../common/icons/explainerVideoIcon.vue";
import playExplainerVideoModal from "../common/includes/playExplainerVideoModal.vue";

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      is_full_page_loader_shown: false,
      selected_location:"",
      all_locations:[],
      active_tab:"",
      video_file: "hce_explainer_notifications_final.mp4",  
      video_caption_file: "hce_explainer_notifications_final.vtt",  
      play_video_modal: false,
    };
  },
  components: {
    fullPageLoader,
    headerAfterLogin,
    notificationList,
    explainerVideoIcon,
    playExplainerVideoModal
  },
  mounted() {
    this.loadLocationNicknameList()
  },
  methods: {
    PlayExplainerVideoModalToggle() {
      if (this.play_video_modal == true) {
        this.play_video_modal = false;
      } else {
        this.play_video_modal = true;
      }
    },
    loadLocationNicknameList() {
      this.is_full_page_loader_shown = true;
      axios
        .get(JS_APP_URL + "/general/get-assigned-location-list")
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            this.all_locations = response["data"]["data"];
            this.selected_location = this.all_locations.find(
              (object) => object.id === parseInt(JS_LOCATION_ID)
            );
            this.active_tab = "open"
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        });
    },
    changeTab(tab_name){
      this.active_tab = tab_name;
    }
  },
};
</script>
