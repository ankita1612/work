<template>
    <div class="training-tab-content pt20">
        <div class="container">
          <div class="flex justify-end mb20" v-if="is_show_search_box">
            <div class="col-12 col-md-4 col-lg-3 col-xl-2 px0">
                <input
                  class="form-input form-input-search"
                  v-model.trim="search_query"
                  id="search"
                  type="text"
                  @input="applySearch()"
                />
                <label
                  class="label font-italic"
                  :class="{ 'label-float': search_query }"
                  >Search</label
                >
                <div class="search-btn-input">
                  <img
                    :src="JS_APP_URL + '/images/search.svg'"
                    alt=""
                    title=""
                  />
                </div>
              </div>
          </div>     
          <div>     
            <div class="user-detail-card py14 px15 light mb10" v-for="notification in notifications" :key="notification.id">
              <div class="row flex-auto -mx-10 items-center">
                  <div class="col-12 col-md-4 col-lg-5 col-xl-4 px10 mb-sm-10" @click="redirectUrl(notification.notification.redirect_url)">
                      <div class="font-16 font_semibold gray2--text cursor-pointer">{{getReplacedTitle(notification)}} </div>
                  </div>
                  <div class="col-12 col-md-4 col-lg-4 col-xl-5 px10 mb-sm-10 font-14 gray2--text">
                  {{getReplacedDescription(notification)}}
                  </div>
                  <div class="col-12 col-md-4 col-lg-3 col-xl-3 px10 flex flex-wrap justify-end items-center justify-start-small">
                    <span class="font-10 gray_checkmark--text font-italic mr4" v-if="notification.is_completed == 0">Sent On: </span>
                    <span class="font-10 gray_checkmark--text font-italic mr4" v-if="notification.is_completed == 1">Completed On: </span>
                    <span class="font-14 blueog--text font_semibold">{{ $filters.formatDate(notification.updated_at) }}</span>
                      <div class="radio ml28" v-if="notification.is_completed == 1 && (notification.notification.code == 'HCE-AN4' || notification.notification.code == 'HCE-AN7' || notification.notification.code == 'HCE-AN20')"> 
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="cursor-pointer">
                          <input @click="changeNotificationStatus(notification,'restore')" :id="notification.id+'add_hco_option_yes'" :name="notification.id+'add_hco_option_yes'" type="radio"  checked>
                          <label :for="notification.id+'add_hco_option_yes'" class="radio-label font-14 font-light gray_checkmark--text"></label>
                            <template #popper>
                              Restore
                            </template>
                        </VTooltip>
                      </div>
                      <div class="checkbox ml28" v-else>
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="cursor-pointer">
                          <input @change="changeNotificationStatus(notification,notification.is_completed ? 'restore' : 'complete')" :id="notification.id+'add_hco_option_yes'" :name="notification.id+'add_hco_option_yes'" type="checkbox" :checked="notification.is_completed" >
                          <label :for="notification.id+'add_hco_option_yes'" class="checkbox-label font-14 font-light gray_checkmark--text"></label>
                            <template #popper>
                              {{notification.is_completed ? "Restore" : "Mark as Completed"}}
                            </template>
                        </VTooltip>
                      </div>
                  </div>
              </div>
            </div>
          </div>   
          <InfiniteLoading @infinite="getOpenNotification(false)" />
          <div v-if="!is_full_page_loader_shown && notifications.length === 0" class="">
            <div class="user-detail-text font-14 gray_checkmark--text text-center">
              <no-data-icon></no-data-icon>
              <div class="font-14 text-center blueog--text">No notification(s) available.</div>
            </div>
          </div>                          
        </div>
        <restore-warning-modal 
          v-if="is_show_restore_warning_modal" 
          @close-model="closeRestoreWarmingModal"
          :restore_warning_txt="restore_warning_txt"
          ></restore-warning-modal>
        <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
      </div>
</template>

<script>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import fullPageLoader from "../common/fullPageLoader.vue";
import noDataIcon from '../common/icons/noDataIcon.vue';
import restoreWarningModal from "./restoreWarningModal.vue"
import _ from 'lodash';

export default {
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_SUPPORT_EMAIL: SUPPORT_EMAIL,
      JS_SUPPORT_PHONE_NUMBER_DISPLAY: SUPPORT_PHONE_NUMBER_DISPLAY,
      is_full_page_loader_shown: false,
      search_query:null,
      notifications:[],
      is_show_search_box:true,
      per_page_records:10,
      current_page: 1,
		  total_page: 1,
      is_list_loading:true,
      is_show_restore_warning_modal: false,
      restore_warning_txt: "",
      redirect_url_array: ['company', 'security-risk-analysis', 'scorecard', 'disaster-recovery-plan', 'ongoing-compliance', 'training', 'procedures-policies-forms', 'hipaa-logs'],
      call_ajax: 1,
    };
  },
  components: {
    fullPageLoader,
    noDataIcon,
    restoreWarningModal
  },
  props:{
    selected_location:{Object},
    active_tab:{}
  },
  watch:{
    selected_location(newValue, oldValue){
      if(oldValue){
        this.search_query = null;
        this.getOpenNotification(true);
      }
    },
    active_tab(){
      this.search_query = null;
      this.getOpenNotification(true);
    }
  },
  methods: {
    getReplacedTitle(each_noti) {
      if (each_noti.notification.code == 'HCE-AN15') {
        return each_noti.notification.title.replace('{%EMPLOYEE_NAME%}', each_noti.other_details);
      } if(each_noti.notification.code == 'HCE-AN13') {
        return each_noti.notification.title.replace('{%VENDOR_NAME%}', each_noti.other_details);
      } else {
        return each_noti.notification.title;
      }
    },
    getReplacedDescription(each_noti){
      if (each_noti.notification.code == 'HCE-AN20') {
        let noti_desc =  each_noti.notification.description.replace('{%RENEWAL DATE%}', this.$filters.formatDateUTC(each_noti.other_details));
        noti_desc =  noti_desc.replace('{%SUPPORT_EMAIL%}', this.JS_SUPPORT_EMAIL);        
        return noti_desc.replace('{%SUPPORT_PHONE_NUMBER_DISPLAY%}', this.JS_SUPPORT_PHONE_NUMBER_DISPLAY); 
      } if(each_noti.notification.code == 'HCE-AN13') {
        return each_noti.notification.description.replace('{%VENDOR_NAME%}', each_noti.other_details); 
      } else {
        return each_noti.notification.description;
      }
        
    },
    redirectUrl(url) {
      if(this.redirect_url_array.includes(url)) {
        window.location = JS_APP_URL+'/'+url+'/'+ btoa(this.selected_location.id);
      } else if(url == 'student_training') {
        let redirect_url = JS_APP_URL+'/training/'+btoa(this.selected_location.id)+'/'+url;
        window.location = redirect_url;
      } else{
        if(url != '#'){
          window.location = JS_APP_URL+'/'+url; 
        }
      }
    },
    applySearch(){
       if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      this.timer = setTimeout(() => {
        this.getOpenNotification(true)
      }, 500);
    },
    getOpenNotification(need_pagination_reset = false) {
      if(need_pagination_reset){
        this.current_page = 1;
        this.total_page = 1;
        this.notifications = [];
		  }
      if (this.current_page <= this.total_page && this.call_ajax==1 && this.active_tab != '') {
        this.call_ajax = 0;
        this.is_list_loading = true
        this.is_full_page_loader_shown = true;
        if(this.active_tab == 'open'){
          var request = {
            params: {
              location_id: this.selected_location.id,
              notification_type:'incomplete',
              search:this.search_query,
              per_page: this.per_page_records,
              page: this.current_page
            }
          }
        }
         if(this.active_tab == 'completed'){
          var request = {
            params: {
              location_id: this.selected_location.id,
              notification_type:'complete',
              search:this.search_query,
              per_page: this.per_page_records,
              page: this.current_page
            }
          }
        }
         if(this.active_tab == 'all'){
          var request = {
            params: {
              location_id: this.selected_location.id,
              notification_type:'all',
              search:this.search_query,
              per_page: this.per_page_records,
              page: this.current_page
            }
          }
        }
        axios
        .get(JS_APP_URL + "/notification/notification-list",request)
        .then((response) => {
          if (response["data"]["status"] == "Success") {
            if(this.search_query == null && response.data.data.data.length == 0){
              this.is_show_search_box = false
            }else{
              this.is_show_search_box = true
            }
            this.notifications.push(...response.data.data.data);
            this.total_page = response.data.data.last_page;
            this.current_page = this.current_page + 1;
            this.is_list_loading = false;
          }
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          this.is_full_page_loader_shown = false;
        })
        .finally(() => {
          this.call_ajax = 1;
        });
      }
    },
    closeRestoreWarmingModal() {
      this.is_show_restore_warning_modal = false;
    },
    changeNotificationStatus(notification,status) {
      if (status == 'restore' && (notification.notification.code == 'HCE-AN4' || notification.notification.code == 'HCE-AN7' || notification.notification.code == 'HCE-AN20')){
        if(notification.notification.code == 'HCE-AN4' || notification.notification.code == 'HCE-AN7') {
          this.is_show_restore_warning_modal = true
          this.restore_warning_txt = "Unfortunately, you cannot restore Security Risk Analysis and Ongoing Compliance notifications."
        } else if (notification.notification.code == 'HCE-AN20') {
          this.is_show_restore_warning_modal = true
          this.restore_warning_txt = "Unfortunately, you cannot restore Auto-Renewal notification."
        }
      } else {
        NProgress.start();
        axios
        .post(JS_APP_URL + "/notification/change-notification-status",{
          location_notification_id:notification.id,
          status: status,
        })
        .then((response) => {
          if (response["data"]["status"] == "Error") {
            if(response["data"]['data'].length > 0){
                toastr.error(response["data"]['data'].join('</br>'), "Error");
            }else{
                toastr.error(response["data"]["message"], "Error");
            }
          } else {
            if(this.active_tab != 'all') {
              setTimeout(() => {
                this.ChangeStatus(notification.id);
              }, 100);
            }else{
              notification.is_completed = !notification.is_completed
            }
          }          
        })
        .catch((error) => {
          toastr.error(error.response["data"]["message"], "Error");
          if (error.response.status === 401) {
            window.location = JS_APP_URL + "/login";
          }
        })
        .then(() => {
          NProgress.done();
        })
      }
    },
    ChangeStatus(notification_id = ''){
      if(notification_id){
        var found_index = _.findIndex(this.notifications, (o) => { return o.id === notification_id; });
        if(found_index >= 0){
          this.notifications.splice(found_index, 1);
        }
      }
    },    
  },
};
</script>