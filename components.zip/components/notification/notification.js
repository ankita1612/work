import { createApp } from "vue";
import FloatingVue from 'floating-vue';
import Multiselect from 'vue-multiselect';
import 'vue-multiselect/dist/vue-multiselect.css';
import 'floating-vue/dist/style.css';
import InfiniteLoading from "v3-infinite-loading";
import notification from "./notification.vue";
import moment from "moment";
import VueMask from '@devindex/vue-mask';

const notification_app = createApp(notification);
notification_app.use(VueMask);
notification_app.config.globalProperties.$filters = {
    formatDate(value) {
        if (value) {
            return moment.utc(String(value)).local().format("MM/DD/YYYY");
        }
    },
    formatDateUTC(value) {
        if (value) {
            return moment(value).format("MM/DD/YYYY");
        }
    },
};
notification_app.use(FloatingVue);
notification_app.component('multiselect', Multiselect);
notification_app.component('InfiniteLoading', InfiniteLoading);
notification_app.mount("#notification_app");
