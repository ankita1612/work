<template>
  <Teleport to="body">
    <transition name="modal">
      <div class="modal-mask">
        <div class="modal-wrapper animate__animated animate__zoomIn">
          <div class="modal-container Whoa-modal">
            <button @click="closeModal" class="cursor-pointer modal-close">
              <close-icon></close-icon>
            </button>
            <div class="text-center mlr-auto mb10 pt20">
              <img
                :src="JS_APP_URL + '/images/alert.svg'"
                alt=""
                title=""
                class="warning-icon-modal"
              />
            </div>
            <h2
              class="
                font-24 font_semibold
                blueog--text
                line-normal
                text-center
                mb20
              "
            >
              Oops!   
            </h2>
            <p class="text-center font-16 gray_checkmark--text line-normal mb30">
              {{ restore_warning_txt }}
            </p>
            <div class="flex flex-wrap items-center justify-center pb40">
              <button @click="closeModal" class="btn-primary-outline h-32">
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </Teleport>
</template>

<script scoped>
import closeIcon from "../common/icons/closeIcon.vue";

export default {
  components: { closeIcon },
  props: {
    restore_warning_txt: String
  },
  emits: ["close-model"],
  data() {
    return {
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
    };
  },
  methods: {
    closeModal() {
      this.$emit("close-model");
    },
  },
  created() {
    // document.body.classList.add('modal-open');
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        this.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
