<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Config;

class GeneralEmail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $temp_data;
    public $data;
    public $general_email_view_file;

    /**
     * Create a new message instance.
     *
     * @param array $temp_data
     * @param array $data
     * @return void
     */
    public function __construct(array $temp_data, array $data)
    {
        $this->temp_data = $temp_data;
        $this->data = $data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $message = $this->view($this->data['general_email_view_file'])
            ->with($this->temp_data);

        if ($this->data['from']) {
            $message->from($this->data['from'], Config::get('app.brand_name'));
        }

        if ($this->data['notify_to']) {
            $message->cc($this->data['notify_to']);
        }

        if ($this->data['attachment']) {
            if (is_array($this->data['attachment'])) {
                foreach ($this->data['attachment'] as $attachment) {
                    $message->attach($attachment);
                }
            } else {
                $message->attach($this->data['attachment']);
            }
        }

        $message->to($this->data['to'])->subject($this->data['subject']);

        return $message;
    }
}
