<?php

namespace App\Exceptions;

use App\Traits\ApiResponser;
use Exception;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Support\Facades\Auth;
use Throwable;

class Handler extends ExceptionHandler
{
    use ApiResponser;

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     */
    public function register()
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }

    // protected function unauthenticated($request, AuthenticationException $exception)
    // {
    //     if ($request->expectsJson()) {
    //         if (in_array('auth:admin', $request->route()->middleware())) {
    //             if(!Auth::guard('admin')->check()){
    //                 return $this->logoutError('Logout', 200);
    //             }
    //         }
    //         if (in_array('auth:user', $request->route()->middleware()) || in_array('auth:account_user', $request->route()->middleware())) {
    //             if(!Auth::guard('user')->check() && !Auth::guard('account_user')->check()){
    //                 return $this->logoutError('Logout', 200);
    //             }
    //         }
    //     }
    // }
}
