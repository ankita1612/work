<?php

namespace App\Events;

use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class DownloadLogEvent
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $user_id;

    public $file;

    public $location_id;

    /**
     * Create a new event instance.
     */
    public function __construct($user_id, $file = null, $location_id = null)
    {
        $this->user_id = $user_id;
        $this->file = $file;
        $this->location_id = $location_id;
    }
}
