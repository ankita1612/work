<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class HipaaGapAssessmentQuestionAnswerOption extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'question_id',
        'answer_code',
        'answer',
        'point',
        'display_order',
        'is_active',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function question(): BelongsTo
    {
        return $this->belongsTo(HipaaGapAssessmentQuestion::class, 'question_id');
    }

    public function subQuestionNested(): HasMany
    {
        return $this->hasMany(HipaaGapAssessmentQuestion::class, 'parent_answer_id')->with(['hipaaGapAssessmentQuestionAnswerOptionNested']);
    }

    public function subQuestions(): HasMany
    {
        return $this->hasMany(HipaaGapAssessmentQuestion::class, 'parent_answer_id');
    }

    public function answer()
    {
        return $this->morphOne(HipaaGapAssessmentAttemptedQuestion::class, 'answer');
    }
}
