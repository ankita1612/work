<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AbydeDriveFileShare extends Model
{
    use HasFactory,SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'from_loc_id',
        'to_loc_id',
        'abyde_drive_file_id',
        'user_id',
        'user_type',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    
    public function toLocation()
    {
        return $this->belongsTo(Location::class, 'to_loc_id');
    }

    public function fromLocation()
    {
        return $this->belongsTo(Location::class, 'from_loc_id');
    }

    public function file()
    {
        return $this->belongsTo(AbydeDriveFile::class, 'abyde_drive_file_id', 'id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
