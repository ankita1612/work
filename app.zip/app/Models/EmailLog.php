<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmailLog extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'to_email',
        'from_email',
        'cc_email',
        'subject',
        'body',
        'attachment',
        'user_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
    ];

    public static function boot()
    {
        parent::boot();
        static::created(function ($email_log) {
            $email_logs = EmailLog::select('id')->where('created_at', '<=', Carbon::now()->subDays(90)->toDateTimeString())->orderBy('id')->pluck('id');
            EmailLog::whereIn('id', $email_logs)->delete();
        });
    }
}
