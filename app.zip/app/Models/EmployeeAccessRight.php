<?php

namespace App\Models;

use App\Observers\EmployeeAccessRightObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmployeeAccessRight extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'employee_id',
        'location_id',
        'facility_access_key',
        'full_facility_access',
        'full_software_access',
        'software_admin_privilages',
        'full_network_access',
        'network_admin_privilages',
        'security_code',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public static function boot()
    {
        parent::boot();
        EmployeeAccessRight::observe(EmployeeAccessRightObserver::class);
    }
}
