<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Whatsnew extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'whatsnew';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'title',
        'short_description',
        'description',
        'is_active',
        'media',
        'media_type',
        'post_date',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    /**
     * Get data where is_active is 1
     */
    public function scopeIsActive($query)
    {
        return $query->where('is_active', '=', 1);
    }

    public function whatsnewState(): HasMany
    {
        return $this->hasMany(WhatsnewState::class, 'whatsnew_id', 'id');
    }

    public static function boot()
    {
        parent::boot();
        static::deleted(function ($whatsnew) {
            $whatsnew->whatsnewState()->get()->each(function ($wn) {
                $wn->delete();
            });
        });
    }
}
