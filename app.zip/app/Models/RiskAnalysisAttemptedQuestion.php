<?php

namespace App\Models;

use App\Observers\RiskAnalysisAttemptedQuestionObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class RiskAnalysisAttemptedQuestion extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'question_id',
        'location_id',
        'note',
        'next_remind_date',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function attemptedQuestionAnswer(): HasMany
    {
        return $this->hasMany(RiskAnalysisAttemptedQuestionAnswer::class, 'attempted_question_id')->orderBy('answer_id');
    }

    public function question(): BelongsTo
    {
        return $this->belongsTo(RiskAnalysisQuestion::class, 'question_id');
    }

    /**
     * Cause a delete of a risk analysis question to cascade to children so they are also deleted.
     */
    public static function boot()
    {
        parent::boot();
        static::deleting(function ($ra_answers) {
            $ra_answers->attemptedQuestionAnswer()->delete();
        });
        RiskAnalysisAttemptedQuestion::observe(RiskAnalysisAttemptedQuestionObserver::class);
    }
}
