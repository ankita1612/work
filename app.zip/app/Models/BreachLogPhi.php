<?php

namespace App\Models;

use App\Observers\BreachLogPhiObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class BreachLogPhi extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'breach_log_id',
        'phi_type_id',
        'other_details',
        'created_at',
        'updated_at',
    ];

    //relation with phi type table
    public function PhiTypeName(): BelongsTo
    {
        return $this->belongsTo(BreachLogPhiType::class, 'phi_type_id');
    }

    public static function boot()
    {
        parent::boot();
        BreachLogPhi::observe(BreachLogPhiObserver::class);
    }
}
