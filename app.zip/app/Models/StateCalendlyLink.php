<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StateCalendlyLink extends Model
{
    use HasFactory;

    protected $fillable = [
        'state_id',
        'consultation_representative',
        'consultation_calendly_link',
        'demo_representative',
        'demo_calendly_link',
        'webinar_representative',
        'webinar_calendly_link',
    ];

    public function state(): BelongsTo
    {
        return $this->belongsTo(State::class);
    }
}
