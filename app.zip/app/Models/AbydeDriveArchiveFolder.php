<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class AbydeDriveArchiveFolder extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'folder_name',
        'description',
        'parent_folder_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    public function abydeDriveArchiveFolderLocation(): HasMany
    {
        if (request()->has('folder_id')) {
            return $this->hasMany(AbydeDriveArchiveFolderLocation::class, 'archive_folder_id')->where('location_id', '=', request()->location_id);
        } else {
            return $this->hasMany(AbydeDriveArchiveFolderLocation::class, 'archive_folder_id');
        }

    }

    public function parentFolders(): HasOne
    {
        return $this->hasOne(self::class, 'id', 'parent_folder_id');
    }

    public function subFolder(): HasMany
    {
        return $this->hasMany(self::class, 'parent_folder_id');
    }

    public function subFolders(): HasMany
    {
        return $this->hasMany(self::class, 'parent_folder_id')->with([
            'subFolders', 'abydeDriveArchiveFolderLocation.abydeDriveArchiveFile', 'abydeDriveArchiveFolderLocation.location.user',
        ])
            ->whereHas('abydeDriveArchiveFolderLocation');
    }

    public function findTopParentId($id)
    {
        $parent = optional(AbydeDriveArchiveFolder::find($id))->parentFolders;

        return $parent ? $this->findTopParentId($parent->id) : $id;
    }
}
