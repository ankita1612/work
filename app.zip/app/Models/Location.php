<?php

namespace App\Models;

use App\Observers\LocationObserver;
use App\Traits\GetLoginUserData;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Location extends Model
{
    use GetLoginUserData, HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'old_hipaa_id',
        'user_id',
        'company_name',
        'location_nickname',
        'address',
        'city',
        'state_id',
        'zip_code',
        'phone_no',
        'fax_no',
        'logo',
        'created_at',
        'updated_at',
        'salesforce_unique_id',
        'ce_type_id',
        'other',
        'training_anchor_date',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function hipaaComplianceOfficer(): HasOne
    {
        return $this->hasOne(HipaaComplianceOfficer::class, 'location_id');
    }

    public function accountLocationAccess(): HasMany
    {
        return $this->hasMany(AccountUserLocationAccess::class, 'location_id');
    }

    public function employeeSecondaryWorkLocation(): HasMany
    {
        return $this->hasMany(EmployeeSecondaryWorkLocation::class, 'location_id');
    }

    public function employeePrimaryWorkLocation(): HasMany
    {
        return $this->hasMany(Employee::class, 'primary_work_location_id');
    }

    public function activeEmployeePrimaryWorkLocation(): HasMany
    {
        return $this->hasMany(Employee::class, 'primary_work_location_id')->isActive();
    }

    public function studentPrimaryWorkLocation(): HasMany
    {
        return $this->hasMany(Student::class, 'primary_work_location_id');
    }

    public function employeeAccessRight(): HasOne
    {
        return $this->hasOne(EmployeeAccessRight::class, 'location_id');
    }

    public function businessAssociatesUser(): HasMany
    {
        return $this->hasMany(BusinessAssociates::class, 'user_id');
    }

    public function state(): BelongsTo
    {
        return $this->belongsTo(State::class, 'state_id');
    }

    public function companyModuleCompleted(): HasOne
    {
        return $this->hasOne(ModuleCompletedStatus::class, 'location_id')->where('module', 'company_info')->where('is_completed', 1);
    }

    public function disasterRecoveryPlanModuleCompleted(): HasOne
    {
        return $this->hasOne(ModuleCompletedStatus::class, 'location_id')->where('module', 'disaster_recovery_plan')->where('is_completed', 1);
    }

    public function sraModuleCompleted(): HasOne
    {
        return $this->hasOne(ModuleCompletedStatus::class, 'location_id')->where('module', 'risk_analysis')->where('is_completed', 1);
    }

    public function localFirstResponder(): HasOne
    {
        return $this->hasOne(LocalFirstResponder::class, 'location_id')->select(['id', 'location_id', 'updated_at']);
    }

    public function businessAssociatesLocation(): HasMany
    {
        return $this->hasMany(BusinessAssociatesLocation::class, 'location_id');
    }

    public function attemptedQuestion(): HasMany
    {
        return $this->hasMany(RiskAnalysisAttemptedQuestion::class, 'location_id');
    }
    public function contributorQuestion(): HasMany
    {
        return $this->hasMany(RiskAnalysisContributorQuestion::class, 'location_id');
    }
    public function contributorLocation(): HasMany
    {
        return $this->hasMany(RiskAnalysisContributorLocation::class, 'location_id');
    }
    public function high_risk()
    {
        return $this->attemptedQuestion()
            ->with('question')
            ->whereHas('question', function ($q) {
                $q->where('question_answer_layout', 'radio');
                $q->where('is_active', 1);
            })
            ->with('attemptedQuestionAnswer.answerContent')
            ->whereHas('attemptedQuestionAnswer.answerContent', function ($q) {
                $q->where('score', '>=', 7);
            });
    }

    public function medium_risk()
    {
        return $this->attemptedQuestion()
            ->with('question')
            ->whereHas('question', function ($q) {
                $q->where('question_answer_layout', 'radio');
                $q->where('is_active', 1);
            })
            ->with('attemptedQuestionAnswer.answerContent')
            ->whereHas('attemptedQuestionAnswer.answerContent', function ($q) {
                $q->where('score', '>=', 4)->where('score', '<=', 6);
            });
    }

    public function low_risk()
    {
        return $this->attemptedQuestion()
            ->with('question')
            ->whereHas('question', function ($q) {
                $q->where('question_answer_layout', 'radio');
                $q->where('is_active', 1);
            })
            ->with('attemptedQuestionAnswer.answerContent')
            ->whereHas('attemptedQuestionAnswer.answerContent', function ($q) {
                $q->where('score', '>=', 1)->where('score', '<=', 3);
            });
    }

    public function notifications(): HasMany
    {
        return $this->hasMany(LocationNotification::class, 'location_id');
    }

    public function openNotifications()
    {
        $user_data = $this->getLoginUserData();
        if ($user_data['user_type'] == 'USER') {
            $user_data['user_type'] = 'User';
        }
        $query = $this->hasMany(LocationNotification::class, 'location_id')->where('is_completed', 0);
        $query->whereHas('notification.userNotification', function ($q) use ($user_data) {
            $q->where('user_type', $user_data['user_type']);
        });

        return $query;
    }

    public function abydeDriveArchiveFolders(): HasMany
    {
        return $this->hasMany(AbydeDriveArchiveFolderLocation::class, 'location_id');
    }

    public function abydeDriveFile(): HasMany
    {
        return $this->hasMany(AbydeDriveFile::class, 'location_id');
    }

    public function abydeDriveFolder(): HasMany
    {
        return $this->hasMany(AbydeDriveFolder::class, 'location_id');
    }

    public function disasterCommunicationAuthority(): HasMany
    {
        return $this->hasMany(DisasterCommunicationAuthority::class, 'location_id');
    }

    public function disasterCommunicationEmployee(): HasMany
    {
        return $this->hasMany(DisasterCommunicationEmployee::class, 'location_id');
    }

    public function disasterCommunicationMedia(): HasMany
    {
        return $this->hasMany(DisasterCommunicationMedia::class, 'location_id');
    }

    public function disasterCommunicationPartnerVendor(): HasMany
    {
        return $this->hasMany(DisasterCommunicationPartnerVendor::class, 'location_id');
    }

    public function disasterCommunicationPatient(): HasMany
    {
        return $this->hasMany(DisasterCommunicationPatient::class, 'location_id');
    }

    public function disasterRecoveryLead(): HasMany
    {
        return $this->hasMany(DisasterRecoveryLead::class, 'location_id');
    }

    public function disasterVendor(): HasMany
    {
        return $this->hasMany(DisasterVendor::class, 'location_id');
    }

    public function disastervalnerability(): HasMany
    {
        return $this->hasMany(DisasterVulnerability::class, 'location_id');
    }

    public function trainingLocation(): HasMany
    {
        return $this->hasMany(TrainingLocation::class, 'location_id');
    }

    public function scorecardDownloadHistory(): HasMany
    {
        return $this->hasMany(ScorecardDownloadHistory::class, 'location_id');
    }

    public function ongoingRiskAnalysisQuestion(): HasMany
    {
        return $this->hasMany(OngoingRiskAnalysisQuestion::class, 'location_id');
    }

    public function moduleCompletedStatus(): HasMany
    {
        return $this->hasMany(ModuleCompletedStatus::class, 'location_id');
    }

    public function locationModuleLastUpdate(): HasMany
    {
        return $this->hasMany(LocationModuleLastUpdate::class, 'location_id');
    }

    public function openNotificationsWithoutLogin(): HasMany
    {
        return $this->hasMany(LocationNotification::class, 'location_id')
            ->where('is_completed', 0);
    }

    public function disasterVendorManual(): HasMany
    {
        return $this->hasMany(DisasterVendorManual::class, 'location_id');
    }

    public function accessLog(): HasMany
    {
        return $this->hasMany(AccessLog::class, 'location_id');
    }

    public function assetLog(): HasMany
    {
        return $this->hasMany(AssetLog::class, 'location_id');
    }

    public function breachLog(): HasMany
    {
        return $this->hasMany(BreachLog::class, 'location_id');
    }

    public function businessAssociatesAgreement(): HasMany
    {
        return $this->hasMany(BusinessAssociatesAgreement::class, 'location_id');
    }

    public function policyVersioning(): HasOne
    {
        return $this->hasOne(PolicyVersioning::class, 'location_id');
    }

    public function previousAttemptedQuestion(): HasMany
    {
        return $this->hasMany(RiskAnalysisPreviousAttemptedQuestionAnswer::class, 'location_id');
    }

    public function coveredEntityType(): BelongsTo
    {
        return $this->belongsTo(CoveredEntityType::class, 'ce_type_id');
    }

    public static function boot()
    {
        parent::boot();
        static::deleted(function ($loc) {
            $loc->hipaaComplianceOfficer()->delete();
            $loc->localFirstResponder()->delete();
            // $loc->abydeDriveArchiveFile()->delete();
            $loc->abydeDriveFile()->delete();
            $loc->disasterCommunicationAuthority()->delete();
            $loc->disasterCommunicationEmployee()->delete();
            $loc->disasterCommunicationMedia()->delete();
            $loc->disasterCommunicationPartnerVendor()->delete();
            $loc->disasterCommunicationPatient()->delete();
            $loc->disasterRecoveryLead()->delete();
            $loc->disasterVendor()->delete();
            $loc->disastervalnerability()->delete();
            $loc->disasterVendorManual()->delete();
            $loc->employeeSecondaryWorkLocation()->delete();
            $loc->accountLocationAccess()->delete();
            $loc->notifications()->delete();
            $loc->trainingLocation()->delete();
            $loc->scorecardDownloadHistory()->delete();
            $loc->ongoingRiskAnalysisQuestion()->delete();
            $loc->moduleCompletedStatus()->delete();
            $loc->locationModuleLastUpdate()->delete();
            $loc->previousAttemptedQuestion()->delete();
            foreach ($loc->attemptedQuestion as $row) {
                $row->attemptedQuestionAnswer()->delete();
                $row->delete();
            }
            foreach ($loc->abydeDriveFolder as $row) {
                $row->delete();
            }
            foreach ($loc->abydeDriveArchiveFolders as $row) {
                $row->delete();
            }
            $loc->accessLog()->delete();
            $loc->assetLog()->delete();
            $loc->breachLog()->delete();
            $loc->businessAssociatesAgreement()->delete();
            $loc->policyVersioning()->delete();
            foreach ($loc->employeePrimaryWorkLocation as $emp) {
                $emp->delete();
            }
            foreach ($loc->studentPrimaryWorkLocation as $std) {
                $std->delete();
            }

            $loc->contributorLocation()->delete();
            foreach ($loc->contributorQuestion as $row) {
                $row->contributorAttemptedQuestionAnswer()->delete();
                $row->delete();
            }
            $loc->businessAssociatesLocation()->delete();                        
        });
        Location::observe(LocationObserver::class);
    }
}
