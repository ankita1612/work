<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class TrainingQuestion extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'old_hipaa_id',
        'training_id',
        'question',
        'display_order',
        'is_active',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function training(): BelongsTo
    {
        return $this->belongsTo(Training::class, 'training_id', 'id');
    }

    public function trainingQuestionAnswer(): HasMany
    {
        return $this->hasMany(TrainingQuestionAnswer::class, 'training_question_id');
    }

    public function trainingQuestionAnswerCorrect(): HasMany
    {
        return $this->hasMany(TrainingQuestionAnswer::class, 'training_question_id')->where('is_correct_answer', 'yes');
    }

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [];

    /**
     * Get data where is_active is 1
     */
    public function scopeIsActive($query)
    {
        return $query->where('is_active', '=', 1);
    }

    /**
     * Cause a delete of a training question to cascade to all option so they are also deleted.
     */
    public static function boot()
    {
        parent::boot();
        static::deleted(function ($training_question) {
            foreach ($training_question->trainingQuestionAnswer as $answer_option) {
                $answer_option->delete();
            }
        });
    }
}
