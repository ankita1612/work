<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SraOnlyLocationLimitPrice extends Model
{
    use HasFactory;

    protected $fillable = [
        'limit',
        'price',
    ];
    public function quoters()
    {
        return $this->morphMany(Quoter::class, 'locationLimit');
    }
}
