<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PolicyVersioning extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'location_id',
        'policy_id',
        'doc_file_name',
        'doc_spanish_file_name',
        'doc_educational_file_name',
        'version_data',
        'file_name',
        'file_name_spanish',
        'created_at',
        'updated_at',
    ];
}
