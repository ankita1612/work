<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class RiskAnalysisPreviousAttemptedQuestionAnswer extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'answer_id',
        'answer',
        'question_id',
        'location_id',
        'created_at',
        'updated_at',
    ];

    public function answerContent(): BelongsTo
    {
        return $this->belongsTo(RiskAnalysisQuestionAnswerOption::class, 'answer_id');
    }
}
