<?php

namespace App\Models;

use App\Observers\DisasterVendorManualObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DisasterVendorManual extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'location_id',
        'vendor_name',
        'vendor_phone',
        'vendor_responsibility',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public static function boot()
    {
        parent::boot();
        DisasterVendorManual::observe(DisasterVendorManualObserver::class);
    }
}
