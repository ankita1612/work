<?php

namespace App\Models;

use App\Http\Controllers\App\TrainingController;
use App\Observers\StudentObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Student extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'old_hipaa_id',
        'user_id',
        'first_name',
        'last_name',
        'email',
        'phone_number',
        'class_id',
        'imaging_device_access',
        'full_network_access',
        'full_software_access',
        'primary_work_location_id',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function studentPrimaryWorkLocation(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'primary_work_location_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function studentClass(): BelongsTo
    {
        return $this->belongsTo(StudentClass::class, 'class_id');
    }

    public function trainingInvites(): MorphMany
    {
        return $this->morphMany(TrainingInvite::class, 'emp_user_acntuser_student')->orderBy('id');
    }

    public function trainingInvite()
    {
        return $this->morphOne(TrainingInvite::class, 'emp_user_acntuser_student')->orderBy('id', 'DESC');
    }

    public function unassignedTraining(): MorphMany
    {
        return $this->morphMany(UnassignedTraining::class, 'emp_user_acntuser_student');
    }

    public static function boot()
    {
        parent::boot();
        static::deleted(function ($student) {
            foreach ($student->trainingInvites as $s) {
                $s->delete();
            }
            foreach ($student->unassignedTraining as $s) {
                $s->delete();
            }
            (new TrainingController)->moveTrainingToArchive($student->primary_work_location_id);
        });
        Student::observe(StudentObserver::class);
    }
}
