<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StateBreachDetail extends Model
{
    use HasFactory;

    protected $fillable = [
        'state_id',
        'breach_time',
        'request_time',
        'state_records_time_frame',
        'state_breach_time',
        'notice_form',
        'substitute_threshold',
        'breach_content',
        'state_notice',
        'state_notice_timing',
        'state_notice_info',
        'BA_notice_timing',
    ];

    public function state(): BelongsTo
    {
        return $this->belongsTo(State::class);
    }
}
