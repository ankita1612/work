<?php

namespace App\Models;
	 
use App\Observers\RiskAnalysisContributorObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class RiskAnalysisContributor extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'first_name',
        'last_name',
        'company_name',
        'email',        
        'created_at',
        'updated_at',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function riskAnalysisContributorLocation(): HasMany
    {
        return $this->hasMany(RiskAnalysisContributorLocation::class, 'risk_analysis_contributor_id');
    }
    public function riskAnalysisContributorQuestion()
    {
        return $this->morphMany(RiskAnalysisContributorQuestion::class, 'contributor_user_acntuser')->orderBy('id','desc');
    }
    public function riskAnalysisContributorQuestionSingle()
    {
        return $this->morphOne(RiskAnalysisContributorQuestion::class, 'contributor_user_acntuser')->orderBy('id','desc')->limit(1);
    }
    public static function boot()
    {
        parent::boot();
        static::deleted(function ($ba) {            
            foreach ($ba->riskAnalysisContributorLocation as $b) {
                $b->delete();
            }
            foreach ($ba->riskAnalysisContributorQuestion as $b) {                
                if($b->status == "Assigned"){
                    $b->delete();
                }
            }
        });
        RiskAnalysisContributor::observe(RiskAnalysisContributorObserver::class);
    }
}
