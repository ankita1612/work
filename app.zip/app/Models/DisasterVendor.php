<?php

namespace App\Models;

use App\Observers\DisasterVendorObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DisasterVendor extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'location_id',
        'alarm_system_company',
        'alarm_system_company_phone',
        'data_backup_vendor',
        'data_backup_vendor_phone',
        'data_backup_vendor_location',
        'landlord_property_manager',
        'landlord_property_manager_phone',
        'practice_management_software',
        'practice_management_software_phone',
        'ehr_software',
        'ehr_software_phone',
        'it_vendor',
        'it_vendor_phone',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public static function boot()
    {
        parent::boot();
        DisasterVendor::observe(DisasterVendorObserver::class);
    }
}
