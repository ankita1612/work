<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class RiskAnalysisRemindOption extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'question_id',
        'answer_option_id',
        'education',
        'ongoing_question_id',
        'remind_month',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [];

    public function question(): BelongsTo
    {
        return $this->belongsTo(RiskAnalysisQuestion::class, 'question_id');
    }

    public function answer(): BelongsTo
    {
        return $this->belongsTo(RiskAnalysisQuestionAnswerOption::class, 'answer_option_id');
    }

    public function ongoingCode(): BelongsTo
    {
        return $this->belongsTo(OngoingQuestion::class, 'ongoing_question_id')->select(['id', 'question_code']);
    }
}
