<?php

namespace App\Models;

use App\Observers\BreachLogIncidentReporterObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class BreachLogIncidentReporter extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'breach_log_id',
        'incident_reporter_id',
        'incident_date',
        'created_at',
        'updated_at',
    ];

    //Relation With location table
    public function incidentReporterType(): BelongsTo
    {
        return $this->belongsTo(BreachLogIncidentReporterType::class, 'incident_reporter_id');
    }

    public static function boot()
    {
        parent::boot();
        BreachLogIncidentReporter::observe(BreachLogIncidentReporterObserver::class);
    }
}
