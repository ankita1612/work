<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Policy extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'old_hipaa_id',
        'code',
        'title',
        'doc_file_name',
        'doc_educational_file_name',
        'type',
        'doc_description',
        'doc_eye_description',
        'doc_warning_description',
        'doc_spanish_file_name',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [];

    public function policyVersioning(): HasMany
    {
        return $this->hasMany(PolicyVersioning::class, 'policy_id')->orderBy('id', 'DESC');
    }

    public function coveredEntityPolicyAccess(): HasMany
    {
        return $this->hasMany(CoveredEntityPolicyAccess::class, 'policy_id');
    }
}
