<?php

namespace App\Models;

use App\Observers\BusinessAssociatesAgreementObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class BusinessAssociatesAgreement extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'business_associates_id',
        'location_id',
        'reference_token',
        'address',
        'city',
        'country_id',
        'state_id',
        'state_name',
        'zip_code',
        'fax_no',
        'signature',
        'file_name',
        'agreement_type',
        'agreement_link',
        'officer_name',
        'officer_title',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function BusinessAssociates(): BelongsTo
    {
        return $this->belongsTo(BusinessAssociates::class, 'business_associates_id');
    }

    public function state(): BelongsTo
    {
        return $this->belongsTo(State::class, 'state_id');
    }

    public function country(): BelongsTo
    {
        return $this->belongsTo(Country::class, 'country_id');
    }

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'location_id');
    }

    public static function boot()
    {
        parent::boot();
        BusinessAssociatesAgreement::observe(BusinessAssociatesAgreementObserver::class);
    }
}
