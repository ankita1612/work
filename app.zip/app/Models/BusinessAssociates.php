<?php

namespace App\Models;

use App\Observers\BusinessAssociatesObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class BusinessAssociates extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'predefine_business_associates_id',
        'name',
        'email',
        'phone_number',
        'expired_date',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function businessAssociatesAgreement(): HasOne
    {
        return $this->hasOne(BusinessAssociatesAgreement::class, 'business_associates_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function predefineBusinessAssociative(): BelongsTo
    {
        return $this->belongsTo(PredefineBusinessAssociates::class, 'predefine_business_associates_id');
    }

    public function businessAssociatesLocation(): HasMany
    {
        return $this->hasMany(BusinessAssociatesLocation::class, 'business_associate_id');
    }

    public static function boot()
    {
        parent::boot();
        static::deleted(function ($ba) {
            $ba->businessAssociatesAgreement()->delete();
            foreach ($ba->businessAssociatesLocation as $b) {
                $b->delete();
            }
        });
        BusinessAssociates::observe(BusinessAssociatesObserver::class);
    }
}
