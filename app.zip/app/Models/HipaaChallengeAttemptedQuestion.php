<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class HipaaChallengeAttemptedQuestion extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'question_id',
        'visitor_id',
        'answer_id',
        'answer_type',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function question(): BelongsTo
    {
        return $this->belongsTo(HipaaChallengeQuestion::class, 'question_id');
    }

    public function visitor(): BelongsTo
    {
        return $this->belongsTo(HipaaChallengeVisitor::class, 'visitor_id');
    }

    public function answer(): MorphTo
    {
        return $this->morphTo();
    }
}
