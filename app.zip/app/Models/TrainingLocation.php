<?php

namespace App\Models;

use App\Observers\TrainingLocationObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class TrainingLocation extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'location_id',
        'training_id',
        'trigger_type',
        'schedule_date',
        'old_schedule_date',
        'schedule_by_id',
        'schedule_by_type',
        'is_disable',
        'is_triggered',
        'is_archived',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function training(): BelongsTo
    {
        return $this->belongsTo(Training::class, 'training_id', 'id');
    }

    public function unassignedTrainings(): HasMany
    {
        return $this->hasMany(UnassignedTraining::class, 'training_id', 'training_id');
    }

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'location_id');
    }

    public function schedule_by(): MorphTo
    {
        return $this->morphTo()->withTrashed();
    }

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    public static function boot()
    {
        parent::boot();
        TrainingLocation::observe(TrainingLocationObserver::class);
    }
}
