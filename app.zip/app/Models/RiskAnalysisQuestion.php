<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Symfony\Component\Console\Question\Question;

class RiskAnalysisQuestion extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'question_category_id',
        'question_law_section_id',
        'question_code',
        'question',
        'question_answer_layout',
        'display_order',
        'parent_question_id',
        'parent_answer_id',
        'is_active',
        'level',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [];

    /**
     * Get data for question is active
     */
    public function scopeIsActive($query)
    {
        return $query->where('is_active', '=', 1);
    }

    /**
     * Get data for all parent question
     */
    public function scopeIsParent($query)
    {
        return $query->where('parent_question_id', '=', null);
    }

    public function questionCategory(): BelongsTo
    {
        return $this->belongsTo(RiskAnalysisQuestionCategory::class, 'question_category_id');
    }

    public function riskAnalysisQuestionAnswerOptionNested(): HasMany
    {
        return $this->hasMany(RiskAnalysisQuestionAnswerOption::class, 'question_id')->orderBy('display_order')->with(['subQuestionNested', 'remindOption']);
    }

    public function riskAnalysisQuestionAnswerOptions(): HasMany
    {
        return $this->hasMany(RiskAnalysisQuestionAnswerOption::class, 'question_id')->orderBy('display_order');
    }

    public function parentQuestion(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_question_id');
    }

    public function childQuestion(): HasMany
    {
        return $this->hasMany(self::class, 'parent_question_id');
    }

    public function childQuestionNested(): HasMany
    {
        return $this->hasMany(self::class, 'parent_question_id')->with('childQuestionNested');
    }

    public function parentAnswer(): BelongsTo
    {
        return $this->belongsTo(RiskAnalysisQuestionAnswerOption::class, 'parent_answer_id');
    }

    public function remindOption(): HasOne
    {
        return $this->hasOne(RiskAnalysisRemindOption::class, 'question_id');
    }

    public function remindOptionDetail(): HasOne
    {
        return $this->hasOne(RiskAnalysisRemindOption::class, 'question_id');
    }

    public function riskAnalysisAttemptedQuestion(): HasMany
    {
        return $this->hasMany(RiskAnalysisAttemptedQuestion::class, 'question_id')->with(['attemptedQuestionAnswer']);
    }
    public function riskAnalysisContributorQuestion(): HasMany
    {
        return $this->hasMany(RiskAnalysisContributorQuestion::class, 'question_id')->orderBy('id','desc')->with(['contributorAttemptedQuestionAnswer']);
    }    
    public function ongoingRiskAnalysisQuestion(): HasMany
    {
        return $this->hasMany(RiskAnalysisQuestion::class, 'question_id');
    }

    public function questionLawSection(): BelongsTo
    {
        return $this->belongsTo(RiskAnalysisQuestionLawSection::class, 'question_law_section_id');
    }

    public function riskAnalysisPreviousAttemptedQuestionAnswer(): HasMany
    {
        return $this->hasMany(RiskAnalysisPreviousAttemptedQuestionAnswer::class, 'question_id');
    }

    /**
     * Cause a delete of a risk analysis question to cascade to children so they are also deleted.
     */
    public static function boot()
    {
        parent::boot();
        static::deleted(function ($ra_question) {
            $ra_question->remindOption()->delete();
            foreach ($ra_question->riskAnalysisQuestionAnswerOptions as $ans_opt) {
                $ans_opt->delete();
            }
            foreach ($ra_question->riskAnalysisAttemptedQuestion as $attempted) {
                $attempted->delete();
            }
            foreach ($ra_question->ongoingRiskAnalysisQuestion as $ongoing) {
                $ongoing->delete();
            }
            foreach ($ra_question->riskAnalysisContributorQuestion as $attempted) {
                $attempted->delete();
            }            
        });
    }
}
