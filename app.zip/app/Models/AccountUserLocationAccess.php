<?php

namespace App\Models;

use App\Observers\AccountUserLocationAccessObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class AccountUserLocationAccess extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'account_user_id',
        'location_id',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'location_id', 'id');
    }

    public function accountUser(): BelongsTo
    {
        return $this->belongsTo(AccountUser::class, 'account_user_id', 'id');
    }

    /**
     * Register any events for your application.
     */
    public static function boot(): void
    {
        parent::boot();
        AccountUserLocationAccess::observe(AccountUserLocationAccessObserver::class);
    }
}
