<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class State extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'state_code',
        'state_name',
    ];

    public function scopeGetIdByName($query, $value)
    {
        return $query->where('state_name', $value)->first()->id;
    }

    public function answer()
    {
        return $this->morphOne(HipaaChallengeAttemptedQuestion::class, 'answer');
    }

    public function calendlyLink(): HasOne
    {
        return $this->hasOne(StateCalendlyLink::class);
    }

    public function breachDetail(): HasOne
    {
        return $this->hasOne(StateBreachDetail::class);
    }
}
