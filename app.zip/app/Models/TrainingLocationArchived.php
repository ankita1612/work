<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TrainingLocationArchived extends Model
{
    protected $table = 'training_locations_archived';

    protected $fillable = [
        'location_id',
        'training_id',
        'schedule_date',
        'schedule_by_id',
        'schedule_by_type',
    ];

    public function training(): BelongsTo
    {
        return $this->belongsTo(Training::class);
    }

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class);
    }
}
