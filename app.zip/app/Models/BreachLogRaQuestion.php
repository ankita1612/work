<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class BreachLogRaQuestion extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'question_code',
        'question',
        'question_answer_layout',
        'question_answer_layout_data',
        'parent_question_id',
        'parent_answer_id',
        'parent_answer_data',
        'sequence_no',
        'level',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function breachLogRaQuestionAnswers(): HasMany
    {
        return $this->hasMany(BreachLogRaQuestionAnswer::class, 'question_id');
    }
}
