<?php

namespace App\Models;

use App\Observers\BreachLogObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class BreachLog extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'location_id',
        'incident_reporter_name',
        'discovered_by',
        'discovered_start_date',
        'discovered_end_date',
        'individuals_affected',
        'type_of_incident',
        'breach_start_date',
        'breach_end_date',
        'created_at',
        'updated_at',
    ];

    //Relation with Location table
    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'location_id');
    }

    // Relation with PHI Type table
    public function phiType(): HasMany
    {
        return $this->hasMany(BreachLogPhi::class, 'breach_log_id', 'id')->orderBy('phi_type_id');
    }

    // Relation with Incident Reporter table
    public function incidentReport(): HasMany
    {
        return $this->hasMany(BreachLogIncidentReporter::class, 'breach_log_id', 'id')->orderBy('incident_reporter_id');
    }

    // Relation with BreachLog RA Attempts questions table
    public function raAttemptQuestions(): HasMany
    {
        return $this->hasMany(BreachLogRaAttempt::class, 'breach_log_id', 'id');
    }

    public static function boot()
    {
        parent::boot();
        static::deleted(function ($breachlog) {
            $breachlog->phiType()->get()->each(function ($pt) {
                $pt->delete();
            });
            $breachlog->incidentReport()->get()->each(function ($ir) {
                $ir->delete();
            });
            $breachlog->raAttemptQuestions()->get()->each(function ($ra) {
                $ra->delete();
            });
        });
        BreachLog::observe(BreachLogObserver::class);
    }
}
