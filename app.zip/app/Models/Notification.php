<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Notification extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'old_hipaa_id',
        'code',
        'title',
        'description',
        'redirect_url',
        'module_applicable',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    public function locationNotification(): HasMany
    {
        return $this->hasMany(LocationNotification::class, 'notification_id');
    }

    public function userNotification(): HasMany
    {
        return $this->hasMany(UserNotification::class, 'notification_id');
    }
}
