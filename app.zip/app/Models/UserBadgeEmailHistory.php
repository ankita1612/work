<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserBadgeEmailHistory extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'user_badge_email_history';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'user_id',
        'email_type',
        'is_mail_send',
        'is_mail_open',
        'is_mail_attachment_download',        
        'is_popup_triggered',
        'is_popup_attachment_download',
        'mail_open_date',
        'mail_attachment_download_date',
        'popup_triggered_date',
        'popup_attachment_download_date',
        'popup_open_count',
        'deleted_at',
        'updated_at',
        'created_at'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
