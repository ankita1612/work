<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Quoter extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'location_limit',
        'location_limit_type',
        'employee_limit',
        'promo_code',
        'quote_name',
        'quote_company_name',
        'quote_company_email',
        'is_abyde_sale_rep',
        'quote_sales_rep',
        'quote_partner',
        'quote_valid_date',
    ];

    public function abyde_products(): BelongsToMany
    {
        return $this->belongsToMany(AbydeProduct::class, 'quoter_abyde_products');
    }

    public function quoter_abyde_product(): HasMany
    {
        return $this->hasMany(QuoterAbydeProduct::class, 'quoter_id')->with('abyde_products:id,description,name,code,product_category');
    }

    // public function promocodes()
    // {
    //     return $this->belongsTo(Promocode::class,"promo_code");
    // }
    public function abyde_quoter_partners(): BelongsTo
    {
        return $this->belongsTo(AbydeQuoterPartner::class, 'quote_partner');
    }
    public function location_limit_prices()
    {        
        return $this->morphTo(__FUNCTION__, 'location_limit_type', 'location_limit');
    }    
    public function employee_limit_prices(): BelongsTo
    {
        return $this->belongsTo(EmployeeLimitPrice::class, 'employee_limit');
    }

    public function sale_reps(): BelongsTo
    {
        return $this->belongsTo(SalesRep::class, 'quote_sales_rep');
    }
}
