<?php

namespace App\Models;

use App\Observers\EmployeeSecondaryWorkLocationObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmployeeSecondaryWorkLocation extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'employee_id',
        'location_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'location_id')->select(['id', 'location_nickname']);
    }

    public static function boot()
    {
        parent::boot();
        EmployeeSecondaryWorkLocation::observe(EmployeeSecondaryWorkLocationObserver::class);
    }
}
