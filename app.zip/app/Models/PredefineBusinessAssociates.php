<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class PredefineBusinessAssociates extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'old_hipaa_id',
        'name',
        'email',
        'phone_number',
        'expired_date',
        'agreement_type',
        'agreement_link',
        'doc_file',
        'predefinedBAInformation',
        'is_visible_to_demo',
        'send_agreement_email',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function businessAssociates(): HasMany
    {
        return $this->hasMany(BusinessAssociates::class, 'predefine_business_associates_id');
    }
}
