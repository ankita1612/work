<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class QuoterAbydeProduct extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'abyde_product_id',
        'quoter_id',
    ];

    public function abyde_products(): BelongsTo
    {
        return $this->belongsTo(AbydeProduct::class, 'abyde_product_id');
    }
}
