<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class HipaaChallengeQuestionAnswerOption extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'old_hipaa_id',
        'question_id',
        'answer_code',
        'answer',
        'point',
        'area_of_concern_code',
        'area_of_concern',
        'display_order',
        'is_active',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function question(): BelongsTo
    {
        return $this->belongsTo(HipaaChallengeQuestion::class, 'question_id');
    }

    public function subQuestionNested(): HasMany
    {
        return $this->hasMany(HipaaChallengeQuestion::class, 'parent_answer_id')->with(['hipaaChallengeQuestionAnswerOptionNested']);
    }

    public function subQuestions(): HasMany
    {
        return $this->hasMany(HipaaChallengeQuestion::class, 'parent_answer_id');
    }

    public function answer()
    {
        return $this->morphOne(HipaaChallengeAttemptedQuestion::class, 'answer');
    }
}
