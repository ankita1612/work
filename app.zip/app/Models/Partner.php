<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Partner extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'contact_person',
        'email',
        'logo',
        'link',
        'slug',
        'display_order',
        'is_active',
        'is_reseller',
        'phone_no',
        'show_monthly',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function hipaaChallengePartnerAccess(): HasOne
    {
        return $this->hasOne(HipaaChallengePartnerAccess::class, 'partner_id');
    }

    public function hipaaGapAssessmentPartnerAccess(): HasOne
    {
        return $this->hasOne(HipaaGapAssessmentPartnerAccess::class, 'partner_id');
    }

    /**
     * Get data for partners is active
     */
    public function scopeIsActive($query)
    {
        return $query->where('is_active', '=', 1);
    }
}
