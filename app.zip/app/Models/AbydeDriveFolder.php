<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class AbydeDriveFolder extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'old_hipaa_id',
        'folder_name',
        'user_id',
        'user_type',
        'location_id',
        'parent_folder_id',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    public function user(): MorphTo
    {
        return $this->morphTo();
    }

    public function files(): HasMany
    {
        return $this->hasMany(AbydeDriveFile::class, 'folder_id');
    }

    public function subFolder(): HasMany
    {
        return $this->hasMany(self::class, 'parent_folder_id');
    }

    public function subFolders(): HasMany
    {
        return $this->hasMany(self::class, 'parent_folder_id')->with([
            'subFolders', 'files',
        ]);
    }

    public function parentFolders(): HasOne
    {
        return $this->hasOne(self::class, 'id', 'parent_folder_id');
    }

    public function subFoldersWithTrash(): HasMany
    {
        return $this->hasMany(self::class, 'parent_folder_id')->onlyTrashed();
    }

    public function filesOnlyTrash(): HasMany
    {
        return $this->hasMany(AbydeDriveFile::class, 'folder_id')->onlyTrashed();
    }

    public function subFoldersOnlyTrash(): HasMany
    {
        return $this->hasMany(self::class, 'parent_folder_id')->onlyTrashed()->with([
            'subFoldersOnlyTrash', 'filesOnlyTrash',
        ]);
    }

    public function folderShare(): HasMany
    {
        return $this->hasMany(AbydeDriveFolderShare::class, 'abyde_drive_folder_id', 'id');
    }

    public function folderTree(): HasMany
    {
        if (request()->has('folder_id')) {
            return $this->hasMany(self::class, 'parent_folder_id')->where('id', '!=', request()->folder_id)->with('folderTree');
        } else {
            return $this->hasMany(self::class, 'parent_folder_id')->with('folderTree');
        }
    }

    public static function boot()
    {
        parent::boot();
        static::deleted(function ($folder) {
            $folder->files()->delete();
            $folder->folderShare()->delete();
            foreach ($folder->subFolder as $f) {
                $f->folderShare()->delete();
                $f->delete();
            }
        });
        static::restoring(function ($folder) {
            $folder->files()->withTrashed()->restore();
        });
    }
}
