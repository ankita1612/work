<?php

namespace App\Models;

use App\Observers\TrainingInviteObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class TrainingInvite extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'emp_user_acntuser_student_id',
        'emp_user_acntuser_student_type',
        'training_id',
        'ref_token',
        'invite_datetime',
        'completed_datetime',
        'completed_attempt_id',
        'reason',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function training(): BelongsTo
    {
        return $this->belongsTo(Training::class, 'training_id', 'id');
    }

    public function trainingAttempt(): HasMany
    {
        return $this->hasMany(TrainingAttempt::class, 'invite_id');
    }

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    public function emp_user_acntuser_student(): MorphTo
    {
        return $this->morphTo();
    }

    public static function boot()
    {
        parent::boot();
        static::deleted(function ($ti) {
            foreach ($ti->trainingAttempt as $t) {
                $t->delete();
            }
        });
        TrainingInvite::observe(TrainingInviteObserver::class);
    }
}
