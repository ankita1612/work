<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HipaaChallengeGradingScale extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'grade',
        'chart_value',
        'min_percent_range',
        'max_percent_range',
        'lowest_score',
        'highest_score',
        'what_it_means',
        'section_header',
    ];
}
