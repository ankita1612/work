<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Training extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'old_hipaa_id',
        'training_code',
        'title',
        'title_for_list',
        'title_for_tab',
        'parent_training_id',
        'description',
        'video_file',
        'video_poster_file',
        'video_caption_file',
        'training_type',
        'who_can_train',
        'trigger_month',
        'parent_training_id',
        'display_order',
        'is_active',
        'notification_code',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function trainingQuestion(): HasMany
    {
        return $this->hasMany(TrainingQuestion::class, 'training_id');
    }

    public function trainingLocation(): HasMany
    {
        return $this->hasMany(TrainingLocation::class, 'training_id');
    }

    public function trainingInvites(): HasMany
    {
        return $this->hasMany(TrainingInvite::class, 'training_id');
    }

    public function parentTraining(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_training_id');
    }

    public function childTraining(): HasMany
    {
        return $this->hasMany(self::class, 'parent_training_id')->where('is_active', '=', 1)->orderBy('display_order');
    }

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    /**
     * Get data where is_active is 1
     */
    public function scopeIsActive($query)
    {
        return $query->where('is_active', '=', 1);
    }
}
