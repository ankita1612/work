<?php

namespace App\Models;
use App\Observers\RiskAnalysisContributorQuestionObserver;	 
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\MorphTo;
class RiskAnalysisContributorQuestion extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'question_id',
        'location_id',
        'contributor_user_acntuser_id',
        'contributor_user_acntuser_type',
        'review_by_user_acntuser_id',
        'review_by_user_acntuser_type',
        'notes',        
        'status',
        'is_review_read',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];


    public function contributorAttemptedQuestionAnswer(): HasMany
    {
        return $this->hasMany(RiskAnalysisContributorAttemptedQuestionAnswer::class, 'risk_analysis_contributor_question_id')->orderBy('answer_id');
    }

    public function question(): BelongsTo
    {
        return $this->belongsTo(RiskAnalysisQuestion::class, 'question_id');
    }

    public function attemptedQuestion()
    {
        return $this->hasMany(RiskAnalysisAttemptedQuestion::class, 'question_id', 'question_id');
    }

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'location_id');
    }
    public function contributor_user_acntuser(): MorphTo
    {
        return $this->morphTo()->withTrashed();
    }
    public function review_by_user_acntuser(): MorphTo
    {
        return $this->morphTo();
    }
    public static function boot()
    {
        parent::boot();                     
        static::deleted(function ($ra_answers) {                 
            $ra_answers->contributorAttemptedQuestionAnswer()->get()->each(function ($esw) {
                $esw->delete();
            });
        });

        RiskAnalysisContributorQuestion::observe(RiskAnalysisContributorQuestionObserver::class);
    }
}
