<?php

namespace App\Models;

use App\Http\Controllers\App\TrainingController;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

class AccountUser extends Authenticatable
{
    use HasApiTokens, HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'first_name',
        'last_name',
        'email',
        'password',
        'reset_password_token',
        'dashboard_view',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];

    public function accountLocationAccess(): HasMany
    {
        return $this->hasMany(AccountUserLocationAccess::class, 'account_user_id', 'id');
    }

    public function hipaaComplianceOfficer(): MorphMany
    {
        return $this->morphMany(HipaaComplianceOfficer::class, 'hco');
    }

    public function auLoginDetails(): MorphMany
    {
        return $this->morphMany(UserLogin::class, 'user');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function whatsnewSeenStatus()
    {
        return $this->morphOne(WhatsnewSeenStatus::class, 'user');
    }

    public function abydeDriveFolderOwner()
    {
        return $this->morphOne(AbydeDriveFolder::class, 'user');
    }

    public function abydeDriveFileOwner()
    {
        return $this->morphOne(AbydeDriveFile::class, 'user');
    }

    public function trainingInvite()
    {
        return $this->morphOne(TrainingInvite::class, 'emp_user_acntuser_student')->orderBy('id', 'DESC');
    }

    public function trainingInvites(): MorphMany
    {
        return $this->morphMany(TrainingInvite::class, 'emp_user_acntuser_student')->orderBy('id');
    }

    public function scheduledTraining()
    {
        return $this->morphOne(TrainingLocation::class, 'schedule_by');
    }

    public function unassignedTraining(): MorphMany
    {
        return $this->morphMany(UnassignedTraining::class, 'emp_user_acntuser_student');
    }
    
    public function riskAnalysisContributorQuestion()
    {
        return $this->morphMany(RiskAnalysisContributorQuestion::class, 'contributor_user_acntuser')->orderBy('id');
    }
    public function riskAnalysisContributorQuestionSingle()
    {
        return $this->morphOne(RiskAnalysisContributorQuestion::class, 'contributor_user_acntuser')->orderBy('id',"desc")->limit(1);
    }
    public function riskAnalysisReviewBy()
    {
        return $this->morphMany(RiskAnalysisContributorQuestion::class, 'review_by_user_acntuser')->orderBy('id');
    }
    public static function boot()
    {
        parent::boot();
        static::deleted(function ($row) {
            $row->accountLocationAccess()->get()->each(function ($ala) {
                $ala->delete();
            });
            $row->unassignedTraining()->delete();
            // $row->hipaaComplianceOfficer()->delete();
            $row->whatsnewSeenStatus()->delete();
            $row->abydeDriveFolderOwner()->delete();
            $row->abydeDriveFileOwner()->delete();
            // $row->trainingInvite()->delete();
            $row->trainingInvites()->delete();
            foreach ($row->hipaaComplianceOfficer as $r) {
                (new TrainingController)->moveTrainingToArchive($r->location_id);
                $r->delete();
            }
            foreach ($row->riskAnalysisContributorQuestion as $b) {
                if($b->status == "Assigned"){
                    $b->delete();
                }
            }
            foreach ($row->riskAnalysisReviewBy as $b) {
                $b->delete();
            }            
        });
    }
}
