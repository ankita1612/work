<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class RiskAnalysisQuestionAnswerOption extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'question_id',
        'answer_code',
        'answer',
        'score',
        'likelihood',
        'impact',
        'display_order',
        'is_active',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [];

    public function question(): BelongsTo
    {
        return $this->belongsTo(RiskAnalysisQuestion::class, 'question_id');
    }

    public function subQuestionNested(): HasMany
    {
        return $this->hasMany(RiskAnalysisQuestion::class, 'parent_answer_id')->with(['riskAnalysisQuestionAnswerOptionNested', 'remindOption']);
    }

    public function subQuestions(): HasMany
    {
        return $this->hasMany(RiskAnalysisQuestion::class, 'parent_answer_id');
    }

    public function remindOptionDetail(): HasOne
    {
        return $this->hasOne(RiskAnalysisRemindOption::class, 'answer_option_id');
    }

    public function remindOption(): HasOne
    {
        return $this->hasOne(RiskAnalysisRemindOption::class, 'answer_option_id');
    }

    /**
     * Cause a delete of a risk analysis question answer option to cascade to children so they are also deleted.
     */
    public static function boot()
    {
        parent::boot();
        static::deleted(function ($ra_question_answer_option) {
            $ra_question_answer_option->remindOption()->delete();
            foreach ($ra_question_answer_option->subQuestions as $ans_opt) {
                $ans_opt->delete();
            }
        });
    }
}
