<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class HipaaGapAssessmentQuestion extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'question_code',
        'question',
        'question_answer_layout',
        'display_order',
        'parent_question_id',
        'parent_answer_id',
        'total_possible_points',
        'level',
        'is_active',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    /**
     * Get data for question is active
     */
    public function scopeIsActive($query)
    {
        return $query->where('is_active', '=', 1);
    }

    public function hipaaGapAssessmentQuestionAnswerOptionNested(): HasMany
    {
        return $this->hasMany(HipaaGapAssessmentQuestionAnswerOption::class, 'question_id')->orderBy('display_order')->with(['subQuestionNested']);
    }

    public function hipaaGapAssessmentQuestionAnswerOptions(): HasMany
    {
        return $this->hasMany(HipaaGapAssessmentQuestionAnswerOption::class, 'question_id')->orderBy('display_order');
    }

    public function parentQuestion(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_question_id');
    }

    public function childQuestion(): HasMany
    {
        return $this->hasMany(self::class, 'parent_question_id');
    }

    public function childQuestionNested(): HasMany
    {
        return $this->hasMany(self::class, 'parent_question_id')->with('childQuestionNested');
    }

    public function parentAnswer(): BelongsTo
    {
        return $this->belongsTo(HipaaGapAssessmentQuestionAnswerOption::class, 'parent_answer_id');
    }

    public function hipaaGapAssessmentAttemptedQuestion(): HasMany
    {
        return $this->hasMany(HipaaGapAssessmentAttemptedQuestion::class, 'question_id')->with(['answer']);
    }
}
