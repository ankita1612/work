<?php

namespace App\Models;

use App\Observers\TrainingAttemptObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class TrainingAttempt extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'invite_id',
        'attempted_from',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function trainingQuizAttempt(): HasMany
    {
        return $this->hasMany(TrainingQuizAttempt::class, 'training_attempt_id');
    }

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    public static function boot()
    {
        parent::boot();
        static::deleted(function ($ta) {
            foreach ($ta->trainingQuizAttempt as $t) {
                $t->delete();
            }
        });
        TrainingAttempt::observe(TrainingAttemptObserver::class);
    }
}
