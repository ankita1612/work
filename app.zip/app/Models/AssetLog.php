<?php

namespace App\Models;

use App\Observers\AssetLogObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class AssetLog extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'location_id',
        'device_type_id',
        'operating_system_id',
        'status',
        'name',
        'purchased_date',
        'asset_encryption_id',
        'ephi_access_id',
        'operating_location_id',
        'assigned_employee_id',
        'disposal_status_id',
        'disposal_date',
        'created_at',
        'updated_at',
    ];

    // Relation with asset log Device Type table
    public function deviceType(): BelongsTo
    {
        return $this->belongsTo(AssetLogDeviceType::class, 'device_type_id', 'id');
    }

    // Relation with asset log operating System table
    public function operatingSystem(): BelongsTo
    {
        return $this->belongsTo(AssetLogOperatingSystem::class, 'operating_system_id', 'id');
    }

    // Relation with asset log Asset Encryption table
    public function assetEncryption(): BelongsTo
    {
        return $this->belongsTo(AssetLogEncryption::class, 'asset_encryption_id', 'id');
    }

    // Relation with asset log ephi Access table
    public function ephiAccess(): BelongsTo
    {
        return $this->belongsTo(AssetLogEphiAccess::class, 'ephi_access_id', 'id');
    }

    // Relation with asset log operating location table
    public function operatingLocation(): BelongsTo
    {
        return $this->belongsTo(AssetLogOperatingLocation::class, 'operating_location_id', 'id');
    }

    // Relation with employee table
    public function assignedEmployee(): BelongsTo
    {
        return $this->belongsTo(Employee::class, 'assigned_employee_id', 'id');
    }

    //Relation with Location table
    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'location_id', 'id');
    }

    //Relation with Disposal status table
    public function disposalStatus(): BelongsTo
    {
        return $this->belongsTo(AssetLogDisposalStatus::class, 'disposal_status_id', 'id');
    }

    public static function boot()
    {
        parent::boot();
        AssetLog::observe(AssetLogObserver::class);
    }
}
