<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ScorecardDownloadHistory extends Model
{
    use HasFactory;

    protected $table = 'scorecard_download_history';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'location_id',
        'file_name',
        'history_data_json_file',
        'low_risk_count',
        'medium_risk_count',
        'high_risk_count',
        'created_at',
        'updated_at',
    ];
}
