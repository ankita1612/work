<?php

namespace App\Models;

use App\Observers\BreachLogRaAttemptObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class BreachLogRaAttempt extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable = [
        'breach_log_id',
        'question_id',
        'answer_id',
        'custom_answer',
        'created_at',
        'updated_at',
    ];

    public function question(): BelongsTo
    {
        return $this->belongsTo(BreachLogRaQuestion::class, 'question_id');
    }

    public function answer(): BelongsTo
    {
        return $this->belongsTo(BreachLogRaQuestionAnswer::class, 'answer_id');
    }

    public static function boot()
    {
        parent::boot();
        BreachLogRaAttempt::observe(BreachLogRaAttemptObserver::class);
    }
}
