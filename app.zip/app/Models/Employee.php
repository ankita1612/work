<?php

namespace App\Models;

use App\Http\Controllers\App\TrainingController;
use App\Observers\EmployeeObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Employee extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'old_hipaa_id',
        'user_id',
        'first_name',
        'last_name',
        'email',
        'phone_number',
        'primary_work_location_id',
        'status',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public function employeeSecondaryWorkLocation(): HasMany
    {
        return $this->hasMany(EmployeeSecondaryWorkLocation::class, 'employee_id');
    }

    public function employeeAgreement(): HasOne
    {
        return $this->hasOne(EmployeeAgreement::class, 'employee_id');
    }

    public function employeePrimaryWorkLocation(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'primary_work_location_id');
    }

    public function employeeAccessRights(): HasMany
    {
        return $this->hasMany(EmployeeAccessRight::class, 'employee_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function employeePortalLogin(): HasOne
    {
        return $this->hasOne(EmployeePortalLogin::class, 'employee_id');
    }

    public function trainingInvite()
    {
        return $this->morphOne(TrainingInvite::class, 'emp_user_acntuser_student')->orderBy('id', 'DESC');
    }

    public function unassignedTraining(): MorphMany
    {
        return $this->morphMany(UnassignedTraining::class, 'emp_user_acntuser_student');
    }

    public function trainingInvites(): MorphMany
    {
        return $this->morphMany(TrainingInvite::class, 'emp_user_acntuser_student')->orderBy('id');
    }

    public function disasterCommunicationAuthority(): HasMany
    {
        return $this->hasMany(DisasterCommunicationAuthority::class, 'employee_id');
    }

    public function disasterCommunicationEmployee(): HasMany
    {
        return $this->hasMany(DisasterCommunicationEmployee::class, 'employee_id');
    }

    public function disasterCommunicationMedia(): HasMany
    {
        return $this->hasMany(DisasterCommunicationMedia::class, 'employee_id');
    }

    public function disasterCommunicationPatient(): HasMany
    {
        return $this->hasMany(DisasterCommunicationPatient::class, 'employee_id');
    }

    public function disasterCommunicationPartnerVendor(): HasMany
    {
        return $this->hasMany(DisasterCommunicationPartnerVendor::class, 'employee_id');
    }

    public function disasterRecoveryLead(): HasMany
    {
        return $this->hasMany(DisasterRecoveryLead::class, 'employee_id');
    }

    public function employeeAccessRight(): HasOne
    {
        return $this->hasOne(EmployeeAccessRight::class, 'employee_id');
    }

    public function employeeDeleteAccessUpdateTracks(): HasMany
    {
        return $this->hasMany(EmployeeDeleteAccessUpdateTrack::class, 'employee_id');
    }

    public function scopeIsActive($query)
    {
        return $query->where('status', '=', 'active');
    }

    public static function boot()
    {
        parent::boot();
        static::deleted(function ($employee) {
            $employee->employeeSecondaryWorkLocation()->get()->each(function ($esw) {
                $esw->delete();
            });
            $employee->employeeAgreement()->delete();
            $employee->employeePortalLogin()->delete();
            foreach ($employee->trainingInvites as $e) {
                $e->delete();
            }
            foreach ($employee->unassignedTraining as $e) {
                $e->delete();
            }
            $employee->disasterCommunicationAuthority()->get()->each(function ($ec) {
                $ec->delete();
            });
            $employee->disasterCommunicationEmployee()->get()->each(function ($emr) {
                $emr->delete();
            });
            $employee->disasterCommunicationMedia()->get()->each(function ($elso) {
                $elso->delete();
            });
            $employee->disasterCommunicationPatient()->get()->each(function ($em) {
                $em->delete();
            });
            $employee->disasterCommunicationPartnerVendor()->get()->each(function ($esc) {
                $esc->delete();
            });
            $employee->disasterRecoveryLead()->get()->each(function ($emr) {
                $emr->delete();
            });
            $employee->employeeAccessRight()->delete();
            (new TrainingController)->moveTrainingToArchive($employee->primary_work_location_id);
        });
        Employee::observe(EmployeeObserver::class);
    }
}
