<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AbydeDriveArchiveFolderLocation extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'archive_folder_id',
        'location_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    public function abydeDriveArchiveFile(): HasMany
    {
        return $this->hasMany(AbydeDriveArchiveFile::class, 'archive_folder_id');
    }

    public function abydeDriveArchiveFolder(): BelongsTo
    {
        return $this->belongsTo(AbydeDriveArchiveFolder::class, 'archive_folder_id');
    }

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'location_id');
    }

    public static function boot()
    {
        parent::boot();
        static::deleted(function ($folderLocation) {
            $folderLocation->abydeDriveArchiveFile()->delete();
        });
    }
}
