<?php

namespace App\Models;

use App\Observers\LocalFirstResponderObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class LocalFirstResponder extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'disaster_local_first_responders';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'location_id',
        'local_police_department_name',
        'local_police_department_phone',
        'local_fire_department_name',
        'local_fire_department_phone',
        'created_at',
        'updated_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at',
    ];

    public static function boot()
    {
        parent::boot();
        LocalFirstResponder::observe(LocalFirstResponderObserver::class);
    }
}
