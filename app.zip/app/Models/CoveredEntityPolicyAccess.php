<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CoveredEntityPolicyAccess extends Model
{
    use HasFactory;

    protected $table = 'covered_entity_type_policy_access';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'ce_type_id',
        'policy_id',
    ];

    public function coveredEntity(): BelongsTo
    {
        return $this->belongsTo(CoveredEntityType::class, 'ce_type_id');
    }

    public function policy(): BelongsTo
    {
        return $this->belongsTo(Policy::class, 'ce_type_id');
    }
}
