<?php

namespace App\Traits;

use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Models\Customer;
use ChargeBee\ChargeBee\Models\PaymentSource;
use ChargeBee\ChargeBee\Models\Subscription;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

trait ChargebeePlan
{

    public function getChargebeePlanId($payment_plan,$addon_type,$product_type = 'normal', $version = 'v1')
    {
        if($product_type == 'sra_only'){
            if($addon_type == 'new'){
                switch ($payment_plan) {
                    case "monthly":
                        $plan_item_id = "SRA-ONLY-USD-Monthly";
                        break;
                    case "quarterly":
                        $plan_item_id = "SRA-ONLY-USD-Every-3-months";
                        break;
                    case "biannually":
                        $plan_item_id = "SRA-ONLY-USD-Every-6-months";
                        break;
                    case "yearly":
                        $plan_item_id = "SRA-ONLY-USD-Yearly";
                        break;
                }
            }else{
                switch ($payment_plan) {
                    case "monthly":
                        $plan_item_id = "SRA-ONLY-RENEWAL-USD-Monthly";
                        break;
                    case "quarterly":
                        $plan_item_id = "SRA-ONLY-RENEWAL-USD-Every-3-months";
                        break;
                    case "biannually":
                        $plan_item_id = "SRA-ONLY-RENEWAL-USD-Every-6-months";
                        break;
                    case "yearly":
                        $plan_item_id = "SRA-ONLY-RENEWAL-USD-Yearly";
                        break;
                }
            }
            return array('plan_item_id' => $plan_item_id);
        }else{
            if($addon_type == 'new'){
                switch ($payment_plan) {
                    case "monthly":
                        $plan_item_id = "HIPAA-CE-USD-Monthly";
                        $location_item_id = "HIPAA-CE-Locations-USD-Monthly";
                        $employee_item_id = "HIPAA-CE-Employees-USD-Monthly";
                        $transaction_fee_item_id = "Transaction-Fee_-USD-Monthly";
                        break;
                    case "quarterly":
                        $plan_item_id = "HIPAA-CE-USD-Every-3-months";
                        $location_item_id = "HIPAA-CE-Locations-USD-Every-3-months";
                        $employee_item_id = "HIPAA-CE-Employees-USD-Every-3-months";
                        $transaction_fee_item_id = "Transaction-Fee_-USD-Every-3-months";
                        break;
                    case "biannually":
                        $plan_item_id = "HIPAA-CE-USD-Every-6-months";
                        $location_item_id = "HIPAA-CE-Locations-USD-Every-6-months";
                        $employee_item_id = "HIPAA-CE-Employees-USD-Every-6-months";
                        $transaction_fee_item_id = "Transaction-Fee_-USD-Every-6-months";
                        break;
                    case "yearly":
                        $plan_item_id = "HIPAA-CE-USD-Yearly";
                        $location_item_id = "HIPAA-CE-Locations-USD-Yearly";
                        $employee_item_id = "HIPAA-CE-Employees-USD-Yearly";
                        $transaction_fee_item_id = "Transaction-Fee_-USD-Yearly";   
                        break;
                }
            }else{
                if($version == 'v1'){
                    switch ($payment_plan) {
                        case "monthly":
                            $plan_item_id = "HIPAA-CE-USD-Monthly";
                            $location_item_id = "HIPAA-CE-Renewal-Locations-USD-Monthly";
                            $employee_item_id = "HIPAA-CE-Renewal-Employees-USD-Monthly";
                            $transaction_fee_item_id = "Transaction-Fee_-USD-Monthly";
                            break;
                        case "quarterly":
                            $plan_item_id = "HIPAA-CE-USD-Every-3-months";
                            $location_item_id = "HIPAA-CE-Renewal-Locations-USD-Every-3-months";
                            $employee_item_id = "HIPAA-CE-Renewal-Employees-USD-Every-3-months";
                            $transaction_fee_item_id = "Transaction-Fee_-USD-Every-3-months";
                            break;
                        case "biannually":
                            $plan_item_id = "HIPAA-CE-USD-Every-6-months";
                            $location_item_id = "HIPAA-CE-Renewal-Locations-USD-Every-6-months";
                            $employee_item_id = "HIPAA-CE-Renewal-Employees-USD-Every-6-months";
                            $transaction_fee_item_id = "Transaction-Fee_-USD-Every-6-months";
                            break;
                        case "yearly":
                            $plan_item_id = "HIPAA-CE-USD-Yearly";
                            $location_item_id = "HIPAA-CE-Renewal-Locations-USD-Yearly";
                            $employee_item_id = "HIPAA-CE-Renewal-Employees-USD-Yearly";
                            $transaction_fee_item_id = "Transaction-Fee_-USD-Yearly";   
                            break;
                    }
                }
                if($version == 'v2'){
                    switch ($payment_plan) {
                        case "monthly":
                            $plan_item_id = "HIPAA-CE-USD-Monthly";
                            $location_item_id = "HIPAA-CE-Renewal-Locations-USD-Monthly";
                            $employee_item_id = "HIPAA-CE-Renewal-Employees-v2-USD-Monthly";
                            $transaction_fee_item_id = "Transaction-Fee_-USD-Monthly";
                            break;
                        case "quarterly":
                            $plan_item_id = "HIPAA-CE-USD-Every-3-months";
                            $location_item_id = "HIPAA-CE-Renewal-Locations-USD-Every-3-months";
                            $employee_item_id = "HIPAA-CE-Renewal-Employees-v2-USD-Every-3-months";
                            $transaction_fee_item_id = "Transaction-Fee_-USD-Every-3-months";
                            break;
                        case "biannually":
                            $plan_item_id = "HIPAA-CE-USD-Every-6-months";
                            $location_item_id = "HIPAA-CE-Renewal-Locations-USD-Every-6-months";
                            $employee_item_id = "HIPAA-CE-Renewal-Employees-v2-USD-Every-6-months";
                            $transaction_fee_item_id = "Transaction-Fee_-USD-Every-6-months";
                            break;
                        case "yearly":
                            $plan_item_id = "HIPAA-CE-USD-Yearly";
                            $location_item_id = "HIPAA-CE-Renewal-Locations-USD-Yearly";
                            $employee_item_id = "HIPAA-CE-Renewal-Employees-v2-USD-Yearly";
                            $transaction_fee_item_id = "Transaction-Fee_-USD-Yearly";   
                            break;
                    }
                }
            }
            return array('plan_item_id' => $plan_item_id, 'location_item_id' => $location_item_id, 'employee_item_id'=> $employee_item_id, 'transaction_fee_item_id'=>$transaction_fee_item_id);
        }
    }

    public function getSubscriptionDetails($subscription_id,$get_payment_source = false)
    {
        try {
            Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
            $subscription_response = Subscription::retrieve($subscription_id);
            $subscription = $subscription_response->subscription()->getValues();
            if ($get_payment_source == true){
                $payment_source_id = (isset($subscription['payment_source_id']) && !empty($subscription['payment_source_id']))?$subscription['payment_source_id']:null;
                if ($payment_source_id == null) {
                    $customer_response = Customer::retrieve($subscription['customer_id']);
                    $customer = $customer_response->customer();
                    $payment_source_id = (isset($customer->primaryPaymentSourceId) && !empty($customer->primaryPaymentSourceId))?$customer->primaryPaymentSourceId:null;
                }           
                $paymentSourceResponse = PaymentSource::retrieve($payment_source_id);
                $subscription['payment_source'] = $paymentSourceResponse->paymentSource()->getValues();
            }
            $plan_type = 'yearly';
            if ($subscription['billing_period_unit'] != "year") {
                if ($subscription['billing_period'] == 6) {
                    $plan_type = 'biannually';
                } else if ($subscription['billing_period'] == 3) {
                    $plan_type = 'quarterly';
                } else {
                    $plan_type = 'monthly';
                }
            }
            $subscription['plan_type'] = $plan_type;

            //User Plan Details
            $loc = 0;
            $emp = 0;
            foreach($subscription['subscription_items']  as $item){
                if($item['item_type'] == 'addon' && str_contains($item['item_price_id'], 'Locations')){
                    $loc = $item['quantity'];
                }else if($item['item_type'] == 'plan' && str_contains($item['item_price_id'], 'SRA-ONLY')){
                    $loc = $item['quantity'];
                }
                if($item['item_type'] == 'addon' && str_contains($item['item_price_id'], 'Employees')){
                    $emp = $item['quantity'];
                }
            }
            $subscription['location_limit'] = (int)$loc;
            $subscription['employee_limit'] = (int)$emp;
            return $subscription;
        } catch (\Exception $e) {
            Log::error('ChargebeePlan/getSubscriptionDetails() => '.$e->getMessage());
        }
        return null;
    }
}