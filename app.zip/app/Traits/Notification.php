<?php

namespace App\Traits;

use App\Jobs\SendLocationDataToSalesForce;
use App\Models\Location;
use App\Models\LocationNotification;
use App\Models\Notification as ModelsNotification;
use Exception;
use Illuminate\Support\Facades\Log;

trait Notification
{
    /**
     * Get Notification by code
     *
     *
     * @throws \Exception
     */
    public function getNotificationByCode(string $code)
    {
        try {

            $notification = ModelsNotification::where('code', $code)->first();

            return $notification;
        } catch (Exception $e) {
            Log::error('Notification/getNotificationByCode() => '.$e->getMessage());
            Log::error('Notification/getNotificationByCode() => '.json_encode([$code]));
            throw $e;
        }
    }

    /**
     * Create notification
     *
     *
     * @throws \Exception
     */
    public function createNotification(array $data)
    {
        try {
            $SF_location = Location::where('id', $data['location_id'])->whereNotNull('salesforce_unique_id')->first();
            if ($SF_location) {
                SendLocationDataToSalesForce::dispatch($SF_location->id);
            }

            return LocationNotification::create($data);
        } catch (Exception $e) {
            Log::error('Notification/createNotification() => '.$e->getMessage());
            Log::error('Notification/createNotification() => '.json_encode([$data]));
            throw $e;
        }
    }

    /**
     * Check notification already added
     *
     * @param  array  $data
     *
     * @throws \Exception
     */
    public function checkNotificationAlreadyAdded($notification_code, $location_id)
    {
        try {
            return LocationNotification::where('location_id', $location_id)
                ->with(['notification' => function ($que) use ($notification_code) {
                    $que->where('code', $notification_code);
                }])
                ->whereHas('notification', function ($q) use ($notification_code) {
                    $q->where('code', $notification_code);
                })->count();
        } catch (Exception $e) {
            Log::error('Notification/checkNotificationAlreadyAdded() => '.$e->getMessage());
            Log::error('Notification/checkNotificationAlreadyAdded() => '.json_encode([$notification_code, $location_id]));
            throw $e;
        }
    }

    /**
     * Check notification already added
     *
     * @param  array  $data
     *
     * @throws \Exception
     */
    public function getPreviousNotificationAdded($notification_code, $location_id)
    {
        try {
            $notification_date = LocationNotification::where('location_id', $location_id)
                ->with(['notification' => function ($que) use ($notification_code) {
                    $que->where('code', $notification_code);
                }])
                ->whereHas('notification', function ($q) use ($notification_code) {
                    $q->where('code', $notification_code);
                })->orderBy('created_at', 'desc')->first();

            return $notification_date;
        } catch (Exception $e) {
            Log::error('Notification/getPreviousNotificationAdded() => '.$e->getMessage());
            Log::error('Notification/getPreviousNotificationAdded() => '.json_encode([$notification_code, $location_id]));
            throw $e;
        }
    }

    /**
     * delete notification
     *
     * @param  array  $data
     *
     * @throws \Exception
     */
    public function deleteNotification($notification_code, $location_id)
    {
        try {
            return LocationNotification::where('location_id', $location_id)
                ->with(['notification' => function ($que) use ($notification_code) {
                    $que->where('code', $notification_code);
                }])
                ->whereHas('notification', function ($q) use ($notification_code) {
                    $q->where('code', $notification_code);
                })->delete();
        } catch (Exception $e) {
            Log::error('Notification/deleteNotification() => '.$e->getMessage());
            Log::error('Notification/deleteNotification() => '.json_encode([$notification_code, $location_id]));
            throw $e;
        }
    }
}
