<?php

namespace App\Traits;

use Aws\CloudFront\UrlSigner;
use Exception;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Image;

trait FileUpload
{
    /**
     * Process image upload
     *
     *
     * @throws \Exception
     */
    public function uploadFile($image_file, $image_path, $thumb_required = 0, $thumb_path = '', $thumb_width = 300, $thumb_height = 300)
    {
        try {
            if ($image_file) {
                $file_name = uniqid().'-'.$image_file->getClientOriginalName();
                $path = $image_file->storeAs(
                    $image_path,
                    $file_name, //$fileName
                    ['disk' => 's3', 'ContentType' => 'application/octet-stream'] //$options
                );

                if ($path) {
                    if ($thumb_required) {
                        $this->createThumb($image_file, $file_name, $thumb_path, $thumb_width, $thumb_height);
                    }

                    return $file_name;
                }
            }

            return '';
        } catch (Exception $e) {
            Log::error('FileUpload/uploadFile() => '.$e->getMessage());
            Log::error('FileUpload/uploadFile() => '.json_encode([$image_file, $image_path, $thumb_required, $thumb_path, $thumb_width, $thumb_height]));
            throw $e;
        }
    }

    /**
     * Create thumbnail
     */
    public function createThumb($image_file, $file_name, $thumb_path, $thumb_width = 300, $thumb_height = 300)
    {
        try {
            $s3 = Storage::disk('s3');
            $img_thumb = Image::make($image_file)->resize($thumb_width, $thumb_height, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $thumb_file_path = $thumb_path.'/'.$file_name;
            $s3->put(
                $thumb_file_path,
                $img_thumb->__toString()
            );
        } catch (Exception $e) {
            Log::error('FileUpload/createThumb() => '.$e->getMessage());
            Log::error('FileUpload/createThumb() => '.json_encode([$image_file, $file_name, $thumb_path, $thumb_width, $thumb_height]));
            throw $e;
        }
    }

    /**
     * Upload file without rename file
     *
     *
     * @throws \Exception
     */
    public function uploadFileWithOriginalName($image_file, $image_path)
    {
        try {
            if ($image_file) {
                $s3 = Storage::disk('s3');
                $file_name = $image_file->getClientOriginalName();
                $path = $image_file->storeAs(
                    $image_path,
                    $file_name, //$fileName
                    ['disk' => 's3', 'ContentType' => 'application/octet-stream'] //$options
                );

                if ($path) {
                    return $file_name;
                }
            }

            return '';
        } catch (Exception $e) {
            Log::error('FileUpload/uploadFileWithOriginalName() => '.$e->getMessage());
            Log::error('FileUpload/uploadFileWithOriginalName() => '.json_encode([$image_file, $image_path]));
            throw $e;
        }
    }

    public function deleteFile($file_path, $thumb_path = '')
    {
        try {
            if (Storage::disk('s3')->exists($file_path)) {
                Storage::disk('s3')->delete($file_path);
            }
            if ($thumb_path) {
                if (Storage::disk('s3')->exists($thumb_path)) {
                    Storage::disk('s3')->delete($thumb_path);
                }
            }
        } catch (Exception $e) {
            Log::error('FileUpload/deleteFile() => '.$e->getMessage());
            Log::error('FileUpload/deleteFile() => '.json_encode([$file_path, $thumb_path]));
            throw $e;
        }
    }

    public function copyFile($from, $to)
    {
        try {
            $s3 = Storage::disk('s3');
            if ($s3->copy($from, $to)) {
                return true;
            }

            return false;
        } catch (Exception $e) {
            Log::error('FileUpload/copyFile() => '.$e->getMessage());
            Log::error('FileUpload/copyFile() => '.json_encode([$from, $to]));
            throw $e;
        }
    }

    public function getReadableFilesize($bytes)
    {
        try {
            if ($bytes >= 1073741824) {
                $bytes = number_format($bytes / 1073741824, 2).' GB';
            } elseif ($bytes >= 1048576) {
                $bytes = number_format($bytes / 1048576, 2).' MB';
            } elseif ($bytes >= 1024) {
                $bytes = number_format($bytes / 1024, 2).' KB';
            } elseif ($bytes > 1) {
                $bytes = $bytes.' bytes';
            } elseif ($bytes == 1) {
                $bytes = $bytes.' byte';
            } else {
                $bytes = '0 bytes';
            }

            return $bytes;
        } catch (Exception $e) {
            Log::error('FileUpload/getReadableFilesize() => '.$e->getMessage());
            Log::error('FileUpload/getReadableFilesize() => '.json_encode([$bytes]));
            throw $e;
        }
    }

    public function getSignedURL($path, $time = null)
    {
        try {
            $cloudFrontKeyPairId = Config::get('app.cloud_front_key_pair_id');
            $cloudFrontPrivateKeyPath = storage_path('hipaa-ce-uploads-cloudfront.pem');
            $full_path = Storage::disk('s3')->url($path);

            // Set expiration time for the signed URL (in seconds)
            if ($time == null) {
                $expires_time = time() + Config::get('app.expire_time');
            } else {
                $expires_time = time() + $time;
            }

            $url_signer = new UrlSigner($cloudFrontKeyPairId, $cloudFrontPrivateKeyPath);
            $url = $url_signer->getSignedUrl($full_path, $expires_time);

            return $url;
        } catch (Exception $e) {
            Log::error('FileUpload/getSignedURL() => '.$e->getMessage());
            Log::error('FileUpload/getSignedURL() => '.json_encode([$path]));
            throw $e;
        }
    }
}
