<?php

namespace App\Traits;

use App\Models\HipaaComplianceOfficer;
use App\Models\User;
use Exception;
use Illuminate\Support\Facades\Log;

trait GetLoginUserData
{
    /**
     * Process for get login user data
     *
     * @param  $html
     *
     * @throws \Exception
     */
    public static function getLoginUserData()
    {
        try {
            $user_data = [];
            if (! empty(auth()->guard('user')->user())) {
                $user_data = auth()->guard('user')->user();
                $user_data['user_type'] = 'PCO';
                $user_data['user_type_display'] = 'Primary Compliance Officer';
                $user_data['PCO_email'] = $user_data['email'];
                $user_data['PCO_name'] = $user_data['first_name'].' '.$user_data['last_name'];
                if ($user_data['partner_reseller_id'] != null) {
                    $user_data['reseller'] = $user_data->reseller;
                }
                $user_data['is_admin_panel_login'] = (request()->session()->has('is_admin_panel_login')) ? 'true' : 'false';
            }
            if (! empty(auth()->guard('account_user')->user())) {
                $user_data = auth()->guard('account_user')->user();
                $is_hco = HipaaComplianceOfficer::where('hco_id', $user_data['id'])->where('hco_type', \App\Models\AccountUser::class)->count();
                if ($is_hco > 0) {
                    $user_data['user_type'] = 'HCO';
                    $user_data['user_type_display'] = 'HIPAA Compliance Officer';
                } else {
                    $user_data['user_type'] = 'USER';
                    $user_data['user_type_display'] = 'User';
                }
                $PCO_data = User::where('id', $user_data['user_id'])->first();
                $user_data['stripe_customer_id'] = $PCO_data['stripe_customer_id'];
                $user_data['is_demo_account'] = $PCO_data['is_demo_account'];
                $user_data['is_educational_account'] = $PCO_data['is_educational_account'];
                $user_data['old_hipaa_id'] = $PCO_data['old_hipaa_id'];
                $user_data['PCO_email'] = $PCO_data['email'];
                $user_data['PCO_name'] = $PCO_data['first_name'].' '.$PCO_data['last_name'];
                $user_data['PCO_company'] = $PCO_data['company_name'];
                $user_data['is_sra_user'] = $PCO_data['is_sra_user'];
                if ($PCO_data['partner_reseller_id'] != null) {
                    $user_data['reseller'] = $PCO_data->reseller;
                    $user_data['partner_reseller_id'] = $PCO_data->partner_reseller_id;
                }
                $user_data['is_admin_panel_login'] = (request()->session()->has('is_admin_panel_login')) ? 'true' : 'false';
            }

            return $user_data;
        } catch (Exception $e) {
            Log::error('GetLoginUserData/getLoginUserData() => '.$e->getMessage());
            throw $e;
        }
    }
}
