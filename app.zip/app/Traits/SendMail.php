<?php

namespace App\Traits;

use App\Mail\GeneralEmail;
use App\Models\EmailLog;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Config;
use Mail;
use Illuminate\Support\Facades\Log;
use App\Traits\GetMainUserData;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

trait SendMail
{
    use GetMainUserData;
    /**
     * Process email sending
     *
     *
     * @throws \Exception
     */
    public function sendEmail($email_code, $html, $to, $from, $subject, $attachment = null, $notify_to = null, $has_signature = true, $partner_logo = '', $user_id = null, $show_download_badge_link = null, $delay_time = null)
    {
        if (Config::get('app.mail_send') == 1) {
            // Remove product type for SRA Only User.
            if(Auth::check()) {
                $user_data = $this->getMainAccountDetails();
                if(!empty($user_data) && $user_data->is_sra_user == 1) {
                    $subject = str_replace("HIPAA CE | ", "", $subject);
                }
            } else {
                if($user_id != null) {
                    $user_data = User::where('id', $user_id)->first();
                    if($user_data->is_sra_user == 1) {
                        $subject = str_replace("HIPAA CE | ", "", $subject);
                    }
                }
            }
            $data = [
                'to' => $to,
                'from' => $from,
                'subject' => $subject,
                'attachment' => $attachment,
                'notify_to' => $notify_to,
                'general_email_view_file' => 'emails.generalEmailView',
            ];

            $temp_data = [
                'HTML' => $html,
                'PROJECT_TITLE' => Config::get('app.name'),
                'SOFTWARE_URL' => Config::get('app.wordpress_url'),
                'YEAR' => date('Y'),
                'HAS_SIGNATURE' => $has_signature,
                'PARTNER_LOGO' => $partner_logo,
                'SHOW_DOWNLOAD_BADGE_LINK' => $show_download_badge_link
            ];

            try {
                if ($delay_time) {
                    Mail::to($data['to'])
                        ->send((new GeneralEmail($temp_data, $data))->delay(Carbon::createFromFormat('Y-m-d H:i:s', $delay_time)));
                } else {
                    Mail::send($data['general_email_view_file'], $temp_data, function ($msg) use ($data) {

                        if ($data['from']) {
                            $msg->from($data['from'], Config::get('app.brand_name'));
                        }

                        if ($data['notify_to']) {
                            $msg->cc($data['notify_to']);
                        }

                        if ($data['attachment']) {
                            if (is_array($data['attachment'])) {
                                foreach ($data['attachment'] as $attachment) {
                                    $msg->attach($attachment);
                                }
                            } else {
                                $msg->attach($data['attachment']);
                            }
                        }

                        $msg->to($data['to'])->subject($data['subject']);
                    });
                }
                EmailLog::create([
                    'to_email' => (is_array($data['to'])) ? json_encode($data['to']) : $data['to'],
                    'from_email' => ($data['from']) ? $data['from'] : '',
                    'cc_email' => ($data['notify_to']) ? implode(', ', $data['notify_to']) : '',
                    'subject' => $data['subject'],
                    'body' => view($data['general_email_view_file'], $temp_data)->render(),
                    'attachment' => ($data['attachment']) ? json_encode($data['attachment']) : '',
                    'user_id' => $user_id ?? null,
                    'email_code' => $email_code,
                ]);
            } catch (Exception $e) {
                Log::error('SendMail/sendEmail() => ' . $e->getMessage());
                Log::error('SendMail/sendEmail() => ' . json_encode([$html, $to, $from, $subject, $attachment, $notify_to]));
                throw $e;
            }
        }
    }
}
