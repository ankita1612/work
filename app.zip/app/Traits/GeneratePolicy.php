<?php

namespace App\Traits;

use App\Models\AccessLog;
use App\Models\BusinessAssociates;
use App\Models\DisasterCommunicationAuthority;
use App\Models\DisasterCommunicationEmployee;
use App\Models\DisasterCommunicationMedia;
use App\Models\DisasterCommunicationPartnerVendor;
use App\Models\DisasterCommunicationPatient;
use App\Models\DisasterRecoveryLead;
use App\Models\DisasterVendor;
use App\Models\DisasterVendorManual;
use App\Models\DisasterVulnerability;
use App\Models\Employee;
use App\Models\HipaaComplianceOfficer;
use App\Models\LocalFirstResponder;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\Policy;
use App\Models\PolicyVersioning;
use App\Models\RiskAnalysisQuestion;
use App\Models\Student;
use App\Models\User;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Log;

trait GeneratePolicy
{
    /**
     * Process policy versioning
     *
     * @param  $html
     *
     * @throws \Exception
     */
    public function addPolicyVersionData($policy_code, $location_id, $is_educational = false)
    {
        try {
            $location = Location::with('state')->withCount('companyModuleCompleted', 'sraModuleCompleted', 'hipaaComplianceOfficer', 'employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation', 'disasterRecoveryPlanModuleCompleted')->findOrFail($location_id);
            if ($location->company_module_completed_count != 0 && $location->sra_module_completed_count != 0 && $location->hipaa_compliance_officer_count != 0 && $location->disaster_recovery_plan_module_completed_count != 0 && ($location->employee_primary_work_location_count != 0 || $location->employee_secondary_work_location_count != 0)) {
                $policy = Policy::where('code', $policy_code)->first();
                if ($policy) {
                    $policy_data = PolicyVersioning::where('policy_id', $policy['id'])
                        ->where('location_id', $location_id)
                        ->whereDate('created_at', Carbon::today())->first();

                    if ($policy_data == null) {
                        $is_disabled = false;
                        if ($policy['code'] == 'BACP') {
                            $ba_count = BusinessAssociates::whereHas('businessAssociatesLocation', function ($query) use ($location_id) {
                                $query->where('location_id', $location_id);
                            })->count();
                            if ($ba_count == 0) {
                                $is_disabled = true;
                            }
                        } elseif ($policy['code'] == 'EDDP') {
                            $Q12_data = RiskAnalysisQuestion::where('question_code', 'Q12')
                                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location_id) {
                                    $que->where(['location_id' => $location_id]);
                                })
                                ->with(
                                    ['riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                                        return $que->where('location_id', $location_id)
                                            ->with('attemptedQuestionAnswer.answerContent');
                                    }]
                                )->first();
                            if ($Q12_data) {
                                if ($Q12_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A1') {
                                    $is_disabled = true;
                                }
                            }
                        } elseif ($policy['code'] == 'SAP') {
                            $Q1_data = RiskAnalysisQuestion::where('question_code', 'Q1')
                                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location_id) {
                                    $que->where(['location_id' => $location_id]);
                                })
                                ->with(
                                    ['riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                                        return $que->where('location_id', $location_id)
                                            ->with('attemptedQuestionAnswer.answerContent');
                                    }]
                                )->first();
                            if ($Q1_data) {
                                if ($Q1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A1') {
                                    $is_disabled = true;
                                }
                            }
                        } elseif ($policy['code'] == 'AL') {
                            $access_log_count = AccessLog::where('location_id', $location_id)->count();
                            if ($access_log_count <= 0) {
                                $is_disabled = true;
                            }
                        } elseif ($policy['code'] == 'MMPP') {
                            $Q64_data = RiskAnalysisQuestion::where('question_code', 'Q64')
                                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location_id) {
                                    $que->where(['location_id' => $location_id]);
                                })
                                ->with(
                                    ['riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                                        return $que->where('location_id', $location_id)
                                            ->with('attemptedQuestionAnswer.answerContent');
                                    }]
                                )->first();
                            if ($Q64_data) {
                                if ($Q64_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                                    $Q64S1_data = RiskAnalysisQuestion::where('question_code', 'Q64S1')
                                        ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location_id) {
                                            $que->where(['location_id' => $location_id]);
                                        })
                                        ->with(
                                            ['riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                                                return $que->where('location_id', $location_id)
                                                    ->with('attemptedQuestionAnswer.answerContent');
                                            }]
                                        )->first();
                                    if ($Q64S1_data) {
                                        if ($Q64S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A1' && $Q64S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A2') {
                                            $is_disabled = true;
                                        }
                                    } else {
                                        $is_disabled = true;
                                    }
                                } elseif ($Q64_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A2') {
                                    $is_disabled = true;
                                }
                            }
                        } elseif ($policy['code'] == 'CSPF') {
                            $Q51_data = RiskAnalysisQuestion::where('question_code', 'Q51')
                                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location_id) {
                                    $que->where(['location_id' => $location_id]);
                                })
                                ->with(
                                    ['riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                                        return $que->where('location_id', $location_id)
                                            ->with('attemptedQuestionAnswer.answerContent');
                                    }]
                                )->first();
                            if ($Q51_data) {
                                if ($Q51_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A1') {
                                    $is_disabled = true;
                                }
                            }
                        }

                        if (! $is_disabled) {
                            if ($policy->type == 'form') {
                                $data = $this->_dynamicGenerationForm($policy, $location, true);
                            }
                            if ($policy->type == 'procedure') {
                                $data = $this->_dynamicGenerationProcedure($policy, $location, true);
                            }
                            if ($policy->type == 'policy') {
                                $user_data = User::where('id', $location->user_id)->first();
                                $is_educational = $user_data->is_educational_account ? true : false;
                                $data = $this->_dynamicGenerationPolicy($policy, $location, true, $is_educational);
                            }
                            $version_data = json_encode($data);

                            $policy_version = PolicyVersioning::create([
                                'location_id' => $location_id,
                                'policy_id' => $policy['id'],
                                'doc_file_name' => $policy['doc_file_name'],
                                'doc_spanish_file_name' => $policy['doc_spanish_file_name'],
                                'doc_educational_file_name' => $policy['doc_educational_file_name'],
                                'version_data' => $version_data,
                            ]);
                            $is_avail = LocationModuleLastUpdate::where(['location_id' => $location_id, 'module_name' => 'policy'])->first();
                            if ($is_avail) {
                                LocationModuleLastUpdate::where(['location_id' => $location_id, 'module_name' => 'policy'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                            } else {
                                LocationModuleLastUpdate::create(['location_id' => $location_id, 'module_name' => 'policy']);
                            }

                            return $policy_version;
                        }
                    }
                }
            }

            return;
        } catch (Exception $e) {
            Log::error('PolicyVersioning/addPolicyVersionData() => '.$e->getMessage());
            Log::error('PolicyVersioning/addPolicyVersionData() => '.json_encode([$policy_code, $location_id]));
            throw $e;
        }
    }

    private function _dynamicGenerationForm($policy, $location, $is_policy_version = false, $template_processor = null)
    {
        $data = [];
        if ($is_policy_version) {
            $data['CLIENT_NAME_CAPITAL'] = htmlspecialchars(strtoupper($location->company_name));
            $data['CLIENT_NAME'] = htmlspecialchars($location->company_name);
            $data['CLIENT_ADDRESS'] = htmlspecialchars($location->address);
            $data['CLIENT_CITY'] = htmlspecialchars($location->city);
            $data['CLIENT_STATE'] = htmlspecialchars($location->state->state_name);
            $data['CLIENT_ZIP'] = $location->zip_code;
            $data['CLIENT_PHONE_NUMBER'] = $location->phone_no;
            $data['COMPANY_LOGO'] = htmlspecialchars($location->logo);
        } else {
            $template_processor->setValue('CLIENT_NAME_CAPITAL', htmlspecialchars(strtoupper($location->company_name)));
            $template_processor->setValue('CLIENT_NAME', htmlspecialchars($location->company_name));
            $template_processor->setValue('CLIENT_ADDRESS', htmlspecialchars($location->address));
            $template_processor->setValue('CLIENT_CITY', htmlspecialchars($location->city));
            $template_processor->setValue('CLIENT_STATE', htmlspecialchars($location->state->state_name));
            $template_processor->setValue('CLIENT_ZIP', $location->zip_code);
            $template_processor->setValue('CLIENT_PHONE_NUMBER', $location->phone_no);
            $logo_data = $this->_addCompanyLogoOnCoverPage($location);
            $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
            $this->_removeTempCompanyLogo($location, $logo_data['temp_file_path']);
        }

        switch ($policy->code) {
            case 'PHDRF':
                $this->form_PHDRF($data, $location, $is_policy_version, $template_processor);
                break;
            case 'CFFEDOP':
                $this->form_CFFEDOP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'AFFPR':
                $this->form_AFFPR($data, $location, $is_policy_version, $template_processor);
                break;
        }

        if ($is_policy_version) {
            return $data;
        }
    }

    private function _dynamicGenerationProcedure($policy, $location, $is_policy_version = false, $template_processor = null)
    {
        $data = [];
        if ($is_policy_version) {
            $data['CLIENT_NAME'] = htmlspecialchars($location->company_name);
            $data['CLIENT_ADDRESS'] = htmlspecialchars($location->address);
            $data['CLIENT_CITY'] = htmlspecialchars($location->city);
            $data['CLIENT_STATE'] = htmlspecialchars($location->state->state_name);
            $data['CLIENT_ZIP'] = $location->zip_code;
            $data['CLIENT_PHONE_NUMBER'] = $location->phone_no;
            $data['COMPANY_LOGO'] = htmlspecialchars($location->logo);
        } else {
            $template_processor->setValue('CLIENT_NAME', htmlspecialchars($location->company_name));
            $template_processor->setValue('CLIENT_ADDRESS', htmlspecialchars($location->address));
            $template_processor->setValue('CLIENT_CITY', htmlspecialchars($location->city));
            $template_processor->setValue('CLIENT_STATE', htmlspecialchars($location->state->state_name));
            $template_processor->setValue('CLIENT_ZIP', $location->zip_code);
            $template_processor->setValue('CLIENT_PHONE_NUMBER', $location->phone_no);
            $logo_data = $this->_addCompanyLogoOnCoverPage($location);
            $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
            $this->_removeTempCompanyLogo($location, $logo_data['temp_file_path']);
        }

        switch ($policy->code) {
            case 'AL':
                $this->procedure_AL($data, $location, $is_policy_version, $template_processor);
                break;
            case 'DRP':
                $this->procedure_DRP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'MMPP':
                $this->procedure_MMPP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'SPP':
                $this->procedure_SPP($data, $location, $is_policy_version, $template_processor);
                break;
        }
        if ($is_policy_version) {
            return $data;
        }
    }

    private function _dynamicGenerationPolicy($policy, $location, $is_policy_version = false, $is_educational = false, $template_processor = null)
    {
        $data = [];
        if ($is_policy_version) {
            $data['CLIENT_NAME'] = htmlspecialchars($location->company_name);
            $data['CLIENT_ADDRESS'] = htmlspecialchars($location->address);
            $data['CLIENT_CITY'] = htmlspecialchars($location->city);
            $data['CLIENT_STATE'] = htmlspecialchars($location->state->state_name);
            $data['CLIENT_ZIP'] = $location->zip_code;
            $data['CLIENT_PHONE_NUMBER'] = $location->phone_no;
            $data['COMPANY_LOGO'] = htmlspecialchars($location->logo);
        } else {
            $template_processor->setValue('CLIENT_NAME', htmlspecialchars($location->company_name));
            $template_processor->setValue('CLIENT_ADDRESS', htmlspecialchars($location->address));
            $template_processor->setValue('CLIENT_CITY', htmlspecialchars($location->city));
            $template_processor->setValue('CLIENT_STATE', htmlspecialchars($location->state->state_name));
            $template_processor->setValue('CLIENT_ZIP', $location->zip_code);
            $template_processor->setValue('CLIENT_PHONE_NUMBER', $location->phone_no);
            $logo_data = $this->_addCompanyLogoOnCoverPage($location);
            $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
            $this->_removeTempCompanyLogo($location, $logo_data['temp_file_path']);
        }
        switch ($policy->code) {
            case 'AAP':
                $this->policy_AAP($data, $location, $is_policy_version, $is_educational, $template_processor);
                break;
            case 'BNP':
                $this->policy_BNP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'BACP':
                $this->policy_BACP($data, $policy, $location, $is_policy_version, $template_processor);
                break;
            case 'EDDP':
                $this->policy_EDDP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'EFP':
                $this->policy_EFP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'ETP':
                $this->policy_ETP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'HCUAP':
                $this->policy_HCUAP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'HNEP':
                $this->policy_HNEP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'NPP':
                $this->policy_NPP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'PMP':
                $this->policy_PMP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'PCFP':
                $this->policy_PCFP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'PHDRP':
                $this->policy_PHDRP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'SAP':
                $this->policy_SAP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'SATP':
                $this->policy_SATP($data, $location, $is_policy_version, $template_processor);
                break;
            case 'SRA':
                $this->policy_SRA($data, $location, $is_policy_version, $template_processor);
                break;
            case 'VCP':
                $this->policy_VCP($data, $location, $is_policy_version, $template_processor);
                break;
        }
        if ($is_policy_version) {
            return $data;
        }
    }

    /**
     * disasterLikelihoodText description
     */
    private function disasterLikelihoodText($value = '')
    {
        if ($value == 1) {
            return 'Low';
        } elseif ($value == 2) {
            return 'Medium';
        } elseif ($value == 3) {
            return 'High';
        } else {
            return '';
        }
    }

    /**
     * vulnerabilityText description
     */
    private function vulnerabilityText($value = '')
    {
        if ($value >= 1 && $value <= 3) {
            return 'Low';
        } elseif ($value >= 4 && $value <= 6) {
            return 'Medium';
        } elseif ($value >= 7 && $value <= 8) {
            return 'High';
        } elseif ($value == 9) {
            return 'Very High';
        } else {
            return '';
        }
    }

    private function form_PHDRF(&$data, $location, $is_policy_version, $template_processor)
    {
        $state = $location->state;
        $breach_detail = $state->breachDetail;
        $request_time = htmlspecialchars($breach_detail['request_time']);
        if ($is_policy_version) {
            $data['REQUEST_TIME'] = htmlspecialchars($request_time);
        } else {
            $template_processor->setValue('REQUEST_TIME', htmlspecialchars($request_time));
        }
    }

    private function form_AFFPR(&$data, $location, $is_policy_version, $template_processor)
    {
        $medical_practice = $location->location_nickname;
        if ($is_policy_version) {
            $data['MEDICAL_PRACTICE'] = htmlspecialchars($medical_practice);
        } else {
            $template_processor->setValue('MEDICAL_PRACTICE', htmlspecialchars($medical_practice));
        }
    }

    private function form_CFFEDOP(&$data, $location, $is_policy_version, $template_processor)
    {
        $medical_practice = $location->location_nickname;
        if ($is_policy_version) {
            $data['MEDICAL_PRACTICE'] = htmlspecialchars($medical_practice);
        } else {
            $template_processor->setValue('MEDICAL_PRACTICE', htmlspecialchars($medical_practice));
        }
    }

    private function procedure_AL(&$data, $location, $is_policy_version, $template_processor)
    {
        $access_logs = AccessLog::where('location_id', $location->id)->get();
        if ($is_policy_version) {
            $data['access_logs'] = $access_logs;
        } else {
            $total = count($access_logs);
            $template_processor->cloneRow('ALOG_NAME', $total);
            for ($i = 0; $i < $total; $i++) {
                $template_processor->setValue('ALOG_NAME#'.($i + 1), htmlspecialchars($access_logs[$i]->name));
                $template_processor->setValue('ALOG_CNAME#'.($i + 1), htmlspecialchars($access_logs[$i]->company_name));
                $template_processor->setValue('ALOG_LOG_TYPE#'.($i + 1), htmlspecialchars(ucfirst($access_logs[$i]->log_type)));
                $template_processor->setValue('ALOG_DATE#'.($i + 1), htmlspecialchars(date('m/d/Y', strtotime($access_logs[$i]->date_log_in))));
                $template_processor->setValue('ALOG_TIME_IN#'.($i + 1), htmlspecialchars(date('h:i A', strtotime($access_logs[$i]->time_log_in))));
                $template_processor->setValue('ALOG_TIME_OUT#'.($i + 1), htmlspecialchars(date('h:i A', strtotime($access_logs[$i]->time_log_out))));
            }
        }
    }

    private function procedure_DRP(&$data, $location, $is_policy_version, $template_processor)
    {
        $hco_data = HipaaComplianceOfficer::where('location_id', $location->id)->with('hco')->first();
        $disaster_vendor = DisasterVendor::where('location_id', $location->id)->first();
        $disaster_local_responder = LocalFirstResponder::where('location_id', $location->id)->first();
        $disaster_vulnerability = DisasterVulnerability::where('location_id', $location->id)->first();
        $vendor_manuals = DisasterVendorManual::where('location_id', $location->id)->get();
        $recovery_lead = DisasterRecoveryLead::where('location_id', $location->id)->with('employee')->get();

        $DISASTER_RECOVERY_LEADS_LIST = '';
        if (count($recovery_lead) > 0) {
            $DISASTER_RECOVERY_LEADS_ARR = [];
            foreach ($recovery_lead as $key => $value) {
                $DISASTER_RECOVERY_LEADS_ARR[] = htmlspecialchars($value->employee->first_name.' '.$value->employee->last_name.' ('.$value->employee->phone_number.')');
            }
            $DISASTER_RECOVERY_LEADS_LIST = implode(', ', $DISASTER_RECOVERY_LEADS_ARR);
        } else {
            $DISASTER_RECOVERY_LEADS_LIST = htmlspecialchars('N/A');
        }

        $COMMUNICATION_TO_ALL_EMPLOYESS_LIST = '';
        $communication_employees = DisasterCommunicationEmployee::where('location_id', $location->id)->with('employee')->get();
        if (count($communication_employees) > 0) {
            $COMMUNICATION_TO_ALL_EMPLOYESS_ARR = [];
            foreach ($communication_employees as $key => $value) {
                $COMMUNICATION_TO_ALL_EMPLOYESS_ARR[] = htmlspecialchars($value->employee->first_name.' '.$value->employee->last_name.' ('.$value->employee->phone_number.')');
            }
            $COMMUNICATION_TO_ALL_EMPLOYESS_LIST = implode(', ', $COMMUNICATION_TO_ALL_EMPLOYESS_ARR);
        } else {
            $COMMUNICATION_TO_ALL_EMPLOYESS_LIST = htmlspecialchars('N/A');
        }

        $COMMUNICATION_TO_AUTHORITIES_LIST = '';
        $communication_authorities = DisasterCommunicationAuthority::where('location_id', $location->id)->with('employee')->get();
        if (count($communication_authorities) > 0) {
            $COMMUNICATION_TO_AUTHORITIES_ARR = [];
            foreach ($communication_authorities as $key => $value) {
                $COMMUNICATION_TO_AUTHORITIES_ARR[] = htmlspecialchars($value->employee->first_name.' '.$value->employee->last_name.' ('.$value->employee->phone_number.')');
            }
            $COMMUNICATION_TO_AUTHORITIES_LIST = implode(', ', $COMMUNICATION_TO_AUTHORITIES_ARR);
        } else {
            $COMMUNICATION_TO_AUTHORITIES_LIST = htmlspecialchars('N/A');
        }

        $COMMUNICATION_TO_ALL_PARTNERS_VENDORS_LIST = '';
        $communication_partners = DisasterCommunicationPartnerVendor::where('location_id', $location->id)->with('employee')->get();
        if (count($communication_partners) > 0) {
            $COMMUNICATION_TO_ALL_PARTNERS_VENDORS_ARR = [];
            foreach ($communication_partners as $key => $value) {
                $COMMUNICATION_TO_ALL_PARTNERS_VENDORS_ARR[] = htmlspecialchars($value->employee->first_name.' '.$value->employee->last_name.' ('.$value->employee->phone_number.')');
            }
            $COMMUNICATION_TO_ALL_PARTNERS_VENDORS_LIST = implode(', ', $COMMUNICATION_TO_ALL_PARTNERS_VENDORS_ARR);
        } else {
            $COMMUNICATION_TO_ALL_PARTNERS_VENDORS_LIST = htmlspecialchars('N/A');
        }

        $COMMUNICATION_TO_MEDIA_LIST = '';
        $communication_medias = DisasterCommunicationMedia::where('location_id', $location->id)->with('employee')->get();
        if (count($communication_medias) > 0) {
            $COMMUNICATION_TO_MEDIA_ARR = [];
            foreach ($communication_medias as $key => $value) {
                $COMMUNICATION_TO_MEDIA_ARR[] = htmlspecialchars($value->employee->first_name.' '.$value->employee->last_name.' ('.$value->employee->phone_number.')');
            }
            $COMMUNICATION_TO_MEDIA_LIST = implode(', ', $COMMUNICATION_TO_MEDIA_ARR);
            $PARAGRAPH_COMMUNICATION_TO_MEDIA_LIST = $COMMUNICATION_TO_MEDIA_LIST;
        } else {
            $COMMUNICATION_TO_MEDIA_LIST = htmlspecialchars('N/A');
            $PARAGRAPH_COMMUNICATION_TO_MEDIA_LIST = 'no employees';
        }

        $COMMUNICATION_TO_ALL_PATIENTS_LIST = '';
        $communication_patients = DisasterCommunicationPatient::where('location_id', $location->id)->with('employee')->get();
        if (count($communication_patients) > 0) {
            $COMMUNICATION_TO_ALL_PATIENTS_ARR = [];
            foreach ($communication_patients as $key => $value) {
                $COMMUNICATION_TO_ALL_PATIENTS_ARR[] = htmlspecialchars($value->employee->first_name.' '.$value->employee->last_name.' ('.$value->employee->phone_number.')');
            }
            $COMMUNICATION_TO_ALL_PATIENTS_LIST = implode(', ', $COMMUNICATION_TO_ALL_PATIENTS_ARR);
        } else {
            $COMMUNICATION_TO_ALL_PATIENTS_LIST = htmlspecialchars('N/A');
        }

        $Q31S2_ANS = 'N/A';
        $Q31S2_statement = '';
        $Q31S2_data = RiskAnalysisQuestion::where('question_code', 'Q31S2')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                return $que->where('location_id', $location->id)
                    ->with('attemptedQuestionAnswer.answerContent');
            }])->first();
        if ($Q31S2_data) {
            if ($Q31S2_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A17') {
                $Q31S2_ANS = htmlspecialchars('Multiple times per day');
                $Q31S2_statement = htmlspecialchars($location->company_name.' follows best practices by backing up data multiple times per day to protect as much information as possible.');
            }
            if ($Q31S2_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A18') {
                $Q31S2_ANS = htmlspecialchars('Once per day');
                $Q31S2_statement = htmlspecialchars($location->company_name.' currently backs up data only once per day, and understands that this presents an elevated risk of data loss.');
            }
            if ($Q31S2_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A19') {
                $Q31S2_ANS = htmlspecialchars('Not backed up daily');
                $Q31S2_statement = htmlspecialchars($location->company_name.' currently does not back up data daily, and understands that this presents an elevated risk of data loss.');
            }
            if ($Q31S2_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $Q31S2_ANS = htmlspecialchars('Unknown');
                $Q31S2_statement = htmlspecialchars($location->company_name.' is unsure of the frequency of data back ups, and will evaluate back up processes to reduce risk of data loss.');
            }
        }

        $Q31S1_ANS = '';
        $Q31S1_data = RiskAnalysisQuestion::where('question_code', 'Q31S1')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                return $que->where('location_id', $location->id)
                    ->with('attemptedQuestionAnswer.answerContent');
            }])->first();
        if ($Q31S1_data) {

            if ($Q31S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A15') {
                $Q31S1_ANS = htmlspecialchars('Currently, '.$location->company_name.' completes manual backups of data.');
            }
            if ($Q31S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A16') {
                $Q31S1_ANS = htmlspecialchars('Currently, '.$location->company_name.' completes automatic backups of data.');
            }
            if ($Q31S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $Q31S1_ANS = htmlspecialchars('Currently, '.$location->company_name.' is unsure how data is backed up.');
            }
        }
        $Q20_STATEMENT = '';
        $Q20_data = RiskAnalysisQuestion::where('question_code', 'Q20')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                return $que->where('location_id', $location->id)
                    ->with('attemptedQuestionAnswer.answerContent');
            }])->first();
        if ($Q20_data) {
            if ($Q20_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A4') {
                $Q20_STATEMENT = htmlspecialchars($location->company_name.'’s last fire marshal inspection was within the last year.');
            }
            if ($Q20_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A5') {
                $Q20_STATEMENT = htmlspecialchars($location->company_name.'’s last fire marshal inspection was more than one year ago.');
            }
            if ($Q20_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3' || $Q20_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A6') {
                $Q20_STATEMENT = htmlspecialchars('');
            }
        }

        $LABORATORY_SAFETY_PREPAREDNESS_TITLE = '';
        if ($disaster_vulnerability->have_lab == 'yes') {
            $LABORATORY_SAFETY_PREPAREDNESS_TITLE = '</w:t><w:br/><w:t>'.htmlspecialchars('LABORATORY SAFETY & PREPAREDNESS').'</w:t><w:br/><w:t>';
            $LABORATORY_SAFETY_PREPAREDNESS_ARR = [
                ['LABORATORY_SAFETY_PREPAREDNESS_ITEM' => 'Maintain a clean work environment'],
                ['LABORATORY_SAFETY_PREPAREDNESS_ITEM' => 'Post lab safety work rules, train all personnel'],
                ['LABORATORY_SAFETY_PREPAREDNESS_ITEM' => 'Keep copies of Material Safety Data Sheets'],
                ['LABORATORY_SAFETY_PREPAREDNESS_ITEM' => 'Investigate emergency power options'],
                ['LABORATORY_SAFETY_PREPAREDNESS_ITEM' => 'Install seismic restraints on chemical storage shelves'],
                ['LABORATORY_SAFETY_PREPAREDNESS_ITEM' => 'Latch all cabinet doors'],
                ['LABORATORY_SAFETY_PREPAREDNESS_ITEM' => 'Anchor equipment and furniture'],
                ['LABORATORY_SAFETY_PREPAREDNESS_ITEM' => 'Avoid high storage of heavy items'],
                ['LABORATORY_SAFETY_PREPAREDNESS_ITEM' => 'Do not store hazardous materials on mobile carts'],
                ['LABORATORY_SAFETY_PREPAREDNESS_ITEM' => 'Dispose of chemical waste properly'],
            ];
            if ($is_policy_version) {
                $data['LABORATORY_SAFETY_PREPAREDNESS_BLOCK'] = $LABORATORY_SAFETY_PREPAREDNESS_ARR;
            } else {
                $template_processor->cloneBlock('LABORATORY_SAFETY_PREPAREDNESS_BLOCK', count($LABORATORY_SAFETY_PREPAREDNESS_ARR), true, false, $LABORATORY_SAFETY_PREPAREDNESS_ARR);
            }
        } else {
            if ($is_policy_version) {
                $data['LABORATORY_SAFETY_PREPAREDNESS_BLOCK'] = [];
            } else {
                $template_processor->cloneBlock('LABORATORY_SAFETY_PREPAREDNESS_BLOCK', 0, true, true);
            }
        }

        $EARTHQUAKE_PREPAREDNESS_TITLE = '';
        if ($disaster_vulnerability->earthquake == '2' || $disaster_vulnerability->earthquake == '3') {

            $EARTHQUAKE_PREPAREDNESS_TITLE = '</w:t><w:br/><w:t>'.htmlspecialchars('EARTHQUAKE PREPAREDNESS').'</w:t><w:br/><w:t>';
            $EARTHQUAKE_PREPAREDNESS_ARR = [
                ['EARTHQUAKE_PREPAREDNESS_ITEM' => 'Know how and where to take cover during a quake'],
                ['EARTHQUAKE_PREPAREDNESS_ITEM' => 'Anchor bookcases, cabinets, and files over 42 inches'],
                ['EARTHQUAKE_PREPAREDNESS_ITEM' => 'Do not stack furniture'],
                ['EARTHQUAKE_PREPAREDNESS_ITEM' => 'Move tall furniture away from exits'],
                ['EARTHQUAKE_PREPAREDNESS_ITEM' => 'Do not use tall furniture as room dividers'],
                ['EARTHQUAKE_PREPAREDNESS_ITEM' => 'Secure computers, equipment, and display cases'],
                ['EARTHQUAKE_PREPAREDNESS_ITEM' => 'Store heavy items at floor level'],
            ];
            if ($is_policy_version) {
                $data['EARTHQUAKE_PREPAREDNESS_BLOCK'] = $EARTHQUAKE_PREPAREDNESS_ARR;
            } else {
                $template_processor->cloneBlock('EARTHQUAKE_PREPAREDNESS_BLOCK', count($EARTHQUAKE_PREPAREDNESS_ARR), true, false, $EARTHQUAKE_PREPAREDNESS_ARR);
            }
        } else {
            if ($is_policy_version) {
                $data['EARTHQUAKE_PREPAREDNESS_BLOCK'] = [];
            } else {
                $template_processor->cloneBlock('EARTHQUAKE_PREPAREDNESS_BLOCK', 0, true, true);
            }
        }

        $employee = Employee::where('primary_work_location_id', $location->id)
            ->orWhereHas('employeeSecondaryWorkLocation', function ($q) use ($location) {
                $q->where('location_id', $location->id);
            })->get();

        if ($is_policy_version) {
            $data['vendor_manuals'] = $vendor_manuals;
            $data['employee'] = $employee;
            $data['HIPAA_COMPLIANCE_OFFICER'] = htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name);
            $data['PRACTICE_MANAGEMENT_SOFTWARE'] = ($disaster_vendor->practice_management_software != null) ? htmlspecialchars($disaster_vendor->practice_management_software) : 'N/A';
            $data['BACKUP_COMPANY'] = ($disaster_vendor->data_backup_vendor != null) ? htmlspecialchars($disaster_vendor->data_backup_vendor) : 'N/A';
            $data['BACKUP_LOCATION'] = ($disaster_vendor->data_backup_vendor_location != null) ? htmlspecialchars($disaster_vendor->data_backup_vendor_location) : 'N/A';
            $data['DATA_BACKUP_VENDOR'] = ($disaster_vendor->data_backup_vendor != null) ? htmlspecialchars($disaster_vendor->data_backup_vendor) : 'Data Backup Vendor';
            $data['DATA_BACKUP_VENDOR_PHONE_NUMBER'] = ($disaster_vendor->data_backup_vendor_phone != null) ? htmlspecialchars($disaster_vendor->data_backup_vendor_phone) : 'N/A';
            $data['PROPERTY_MANAGER'] = ($disaster_vendor->landlord_property_manager != null) ? htmlspecialchars($disaster_vendor->landlord_property_manager) : 'Landlord/Property Manager';
            $data['PROPERTY_MANAGER_PHONE_NUMBER'] = ($disaster_vendor->landlord_property_manager_phone != null) ? htmlspecialchars($disaster_vendor->landlord_property_manager_phone) : 'N/A';

            $data['LOCAL_POLICE_DEPARTMENT'] = htmlspecialchars(($disaster_local_responder->local_police_department_name != null) ? $disaster_local_responder->local_police_department_name : 'Local Police Department');
            $data['LOCAL_POLICE_DEPARTMENT_PHONE_NUMBER'] = htmlspecialchars(($disaster_local_responder->local_police_department_phone != null) ? $disaster_local_responder->local_police_department_phone : 'N/A');
            $data['LOCAL_FIRE_DEPARTMENT'] = htmlspecialchars(($disaster_local_responder->local_fire_department_name != null) ? $disaster_local_responder->local_fire_department_name : 'Local Fire Department');
            $data['LOCAL_FIRE_DEPARTMENT_PHONE_NUMBER'] = htmlspecialchars(($disaster_local_responder->local_fire_department_phone != null) ? $disaster_local_responder->local_fire_department_phone : 'N/A');

            $data['DISASTER_RECOVERY_LEADS_LIST'] = $DISASTER_RECOVERY_LEADS_LIST;
            $data['COMMUNICATION_TO_ALL_EMPLOYESS_LIST'] = $COMMUNICATION_TO_ALL_EMPLOYESS_LIST;
            $data['COMMUNICATION_TO_AUTHORITIES_LIST'] = $COMMUNICATION_TO_AUTHORITIES_LIST;
            $data['COMMUNICATION_TO_ALL_PARTNERS_VENDORS_LIST'] = $COMMUNICATION_TO_ALL_PARTNERS_VENDORS_LIST;
            $data['COMMUNICATION_TO_MEDIA_LIST'] = $COMMUNICATION_TO_MEDIA_LIST;
            $data['PARAGRAPH_COMMUNICATION_TO_MEDIA_LIST'] = $PARAGRAPH_COMMUNICATION_TO_MEDIA_LIST;
            $data['COMMUNICATION_TO_ALL_PATIENTS_LIST'] = $COMMUNICATION_TO_ALL_PATIENTS_LIST;

            $data['EARTHQUAKE_PREPAREDNESS_TITLE'] = $EARTHQUAKE_PREPAREDNESS_TITLE;
            $data['LABORATORY_SAFETY_PREPAREDNESS_TITLE'] = $LABORATORY_SAFETY_PREPAREDNESS_TITLE;

            $data['HURRICANE'] = htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->hurricane));
            $data['HURRICANE_VUL'] = htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->hurricane) ? $disaster_vulnerability->hurricane * 3 : ''));
            $data['FLOOD'] = htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->flood));
            $data['FLOOD_VUL'] = htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->flood) ? $disaster_vulnerability->flood * 2 : ''));
            $data['TORNADO'] = htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->tornado));
            $data['TORNADO_VUL'] = htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->tornado) ? $disaster_vulnerability->tornado * 3 : ''));
            $data['EARTHQUAKE'] = htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->earthquake));
            $data['EARTHQUAKE_VUL'] = htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->earthquake) ? $disaster_vulnerability->earthquake * 3 : ''));
            $data['MALICIOUS_SOFTWARE'] = htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->malicious_software_virus));
            $data['MALICIOUS_SOFTWARE_VUL'] = htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->malicious_software_virus) ? $disaster_vulnerability->malicious_software_virus * 3 : ''));
            $data['UTILITY_INTERRUPTION'] = htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->utility_interruption_failure));
            $data['UTILITY_INTERRUPTION_VUL'] = htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->utility_interruption_failure) ? $disaster_vulnerability->utility_interruption_failure * 1 : ''));
            $data['THEFT'] = htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->theft));
            $data['THEFT_VUL'] = htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->theft) ? $disaster_vulnerability->theft * 2 : ''));
            $data['FIRE'] = htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->fire));
            $data['FIRE_VUL'] = htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->fire) ? $disaster_vulnerability->fire * 3 : ''));
            $data['ROGUE_EMPLOYEE'] = htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->rogue_staff_vendor));
            $data['ROGUE_EMPLOYEE_VUL'] = htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->rogue_staff_vendor) ? $disaster_vulnerability->rogue_staff_vendor * 1 : ''));
            $data['PUBLIC_HEALTH'] = htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->public_health_emergency));
            $data['PUBLIC_HEALTH_VUL'] = htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->public_health_emergency) ? $disaster_vulnerability->public_health_emergency * 3 : ''));

            $data['Q31S2_ANS'] = $Q31S2_ANS;
            $data['Q31S2_STATEMENT'] = $Q31S2_statement;
            $data['Q31S1_ANS'] = $Q31S1_ANS;
            $data['Q20_STATEMENT'] = $Q20_STATEMENT;
            $data['DISASTER_TEST_TIMING'] = '';
        } else {

            $total = count($vendor_manuals);
            if ($total > 0) {
                $template_processor->cloneRow('VENDOR_NAME', $total);
                for ($i = 0; $i < $total; $i++) {
                    $template_processor->setValue('VENDOR_NAME#'.($i + 1), htmlspecialchars($vendor_manuals[$i]->vendor_name));
                    $template_processor->setValue('VENDOR_PHONE_NUMBER#'.($i + 1), htmlspecialchars($vendor_manuals[$i]->vendor_phone));
                }
            } else {
                $template_processor->setValue('VENDOR_NAME', htmlspecialchars('Other Vendors'));
                $template_processor->setValue('VENDOR_PHONE_NUMBER', htmlspecialchars('N/A'));
            }

            $total = count($employee);
            if ($total > 0) {
                $template_processor->cloneRow('EMPLOYEE_NAME', $total);
                for ($i = 0; $i < $total; $i++) {
                    $template_processor->setValue('EMPLOYEE_NAME#'.($i + 1), htmlspecialchars($employee[$i]['first_name'].' '.$employee[$i]['last_name']));
                    $template_processor->setValue('EMPLOYEE_PHONE_NUMBER#'.($i + 1), htmlspecialchars($employee[$i]->phone_number));
                    $template_processor->setValue('EMPLOYEE_BUSINESS_EMAIL#'.($i + 1), htmlspecialchars($employee[$i]->email));
                }
            } else {
                $template_processor->setValue('EMPLOYEE_NAME', '');
                $template_processor->setValue('EMPLOYEE_PHONE_NUMBER', '');
                $template_processor->setValue('EMPLOYEE_BUSINESS_EMAIL', '');
            }

            $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name));
            $template_processor->setValue('PRACTICE_MANAGEMENT_SOFTWARE', ($disaster_vendor->practice_management_software != null) ? htmlspecialchars($disaster_vendor->practice_management_software) : 'N/A');
            $template_processor->setValue('BACKUP_COMPANY', ($disaster_vendor->data_backup_vendor != null) ? htmlspecialchars($disaster_vendor->data_backup_vendor) : 'N/A');
            $template_processor->setValue('BACKUP_LOCATION', ($disaster_vendor->data_backup_vendor_location != null) ? htmlspecialchars($disaster_vendor->data_backup_vendor_location) : 'N/A');
            $template_processor->setValue('DATA_BACKUP_VENDOR', ($disaster_vendor->data_backup_vendor != null) ? htmlspecialchars($disaster_vendor->data_backup_vendor) : 'Data Backup Vendor');
            $template_processor->setValue('DATA_BACKUP_VENDOR_PHONE_NUMBER', ($disaster_vendor->data_backup_vendor_phone != null) ? htmlspecialchars($disaster_vendor->data_backup_vendor_phone) : 'N/A');
            $template_processor->setValue('PROPERTY_MANAGER', ($disaster_vendor->landlord_property_manager != null) ? htmlspecialchars($disaster_vendor->landlord_property_manager) : 'Landlord/Property Manager');
            $template_processor->setValue('PROPERTY_MANAGER_PHONE_NUMBER', ($disaster_vendor->landlord_property_manager_phone != null) ? htmlspecialchars($disaster_vendor->landlord_property_manager_phone) : 'N/A');

            $template_processor->setValue('LOCAL_POLICE_DEPARTMENT', htmlspecialchars(($disaster_local_responder->local_police_department_name != null) ? $disaster_local_responder->local_police_department_name : 'Local Police Department'));
            $template_processor->setValue('LOCAL_POLICE DEPARTMENT_PHONE_NUMBER', htmlspecialchars(($disaster_local_responder->local_police_department_phone != null) ? $disaster_local_responder->local_police_department_phone : 'N/A'));
            $template_processor->setValue('LOCAL_FIRE_DEPARTMENT', htmlspecialchars(($disaster_local_responder->local_fire_department_name != null) ? $disaster_local_responder->local_fire_department_name : 'Local Fire Department'));
            $template_processor->setValue('LOCAL_FIRE_DEPARTMENT_PHONE_NUMBER', htmlspecialchars(($disaster_local_responder->local_fire_department_phone != null) ? $disaster_local_responder->local_fire_department_phone : 'N/A'));

            $template_processor->setValue('DISASTER_RECOVERY_LEADS_LIST', $DISASTER_RECOVERY_LEADS_LIST);
            $template_processor->setValue('COMMUNICATION_TO_ALL_EMPLOYESS_LIST', $COMMUNICATION_TO_ALL_EMPLOYESS_LIST);
            $template_processor->setValue('COMMUNICATION_TO_AUTHORITIES_LIST', $COMMUNICATION_TO_AUTHORITIES_LIST);
            $template_processor->setValue('COMMUNICATION_TO_ALL_PARTNERS_VENDORS_LIST', $COMMUNICATION_TO_ALL_PARTNERS_VENDORS_LIST);
            $template_processor->setValue('COMMUNICATION_TO_MEDIA_LIST', $COMMUNICATION_TO_MEDIA_LIST);
            $template_processor->setValue('PARAGRAPH_COMMUNICATION_TO_MEDIA_LIST', $PARAGRAPH_COMMUNICATION_TO_MEDIA_LIST);
            $template_processor->setValue('COMMUNICATION_TO_ALL_PATIENTS_LIST', $COMMUNICATION_TO_ALL_PATIENTS_LIST);

            $template_processor->setValue('EARTHQUAKE_PREPAREDNESS_TITLE', $EARTHQUAKE_PREPAREDNESS_TITLE);
            $template_processor->setValue('LABORATORY_SAFETY_PREPAREDNESS_TITLE', $LABORATORY_SAFETY_PREPAREDNESS_TITLE);

            $template_processor->setValue('HURRICANE', htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->hurricane)));
            $template_processor->setValue('HURRICANE_VUL', htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->hurricane) ? $disaster_vulnerability->hurricane * 3 : '')));
            $template_processor->setValue('FLOOD', htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->flood)));
            $template_processor->setValue('FLOOD_VUL', htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->flood) ? $disaster_vulnerability->flood * 2 : '')));
            $template_processor->setValue('TORNADO', htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->tornado)));
            $template_processor->setValue('TORNADO_VUL', htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->tornado) ? $disaster_vulnerability->tornado * 3 : '')));
            $template_processor->setValue('EARTHQUAKE', htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->earthquake)));
            $template_processor->setValue('EARTHQUAKE_VUL', htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->earthquake) ? $disaster_vulnerability->earthquake * 3 : '')));
            $template_processor->setValue('MALICIOUS_SOFTWARE', htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->malicious_software_virus)));
            $template_processor->setValue('MALICIOUS_SOFTWARE_VUL', htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->malicious_software_virus) ? $disaster_vulnerability->malicious_software_virus * 3 : '')));
            $template_processor->setValue('UTILITY_INTERRUPTION', htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->utility_interruption_failure)));
            $template_processor->setValue('UTILITY_INTERRUPTION_VUL', htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->utility_interruption_failure) ? $disaster_vulnerability->utility_interruption_failure * 1 : '')));
            $template_processor->setValue('THEFT', htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->theft)));
            $template_processor->setValue('THEFT_VUL', htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->theft) ? $disaster_vulnerability->theft * 2 : '')));
            $template_processor->setValue('FIRE', htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->fire)));
            $template_processor->setValue('FIRE_VUL', htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->fire) ? $disaster_vulnerability->fire * 3 : '')));
            $template_processor->setValue('ROGUE_EMPLOYEE', htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->rogue_staff_vendor)));
            $template_processor->setValue('ROGUE_EMPLOYEE_VUL', htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->rogue_staff_vendor) ? $disaster_vulnerability->rogue_staff_vendor * 1 : '')));
            $template_processor->setValue('PUBLIC_HEALTH', htmlspecialchars($this->disasterLikelihoodText($disaster_vulnerability->public_health_emergency)));
            $template_processor->setValue('PUBLIC_HEALTH_VUL', htmlspecialchars($this->vulnerabilityText(is_numeric($disaster_vulnerability->public_health_emergency) ? $disaster_vulnerability->public_health_emergency * 3 : '')));

            $template_processor->setValue('Q31S2_ANS', $Q31S2_ANS);
            $template_processor->setValue('Q31S2_STATEMENT', $Q31S2_statement);
            $template_processor->setValue('Q31S1_ANS', $Q31S1_ANS);
            $template_processor->setValue('Q20_STATEMENT', $Q20_STATEMENT);
            $template_processor->setValue('DISASTER_TEST_TIMING', '');
        }
    }

    private function procedure_MMPP(&$data, $location, $is_policy_version, $template_processor)
    {
        $Q64_data = RiskAnalysisQuestion::where('question_code', 'Q64')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                return $que->where('location_id', $location->id)
                    ->with('attemptedQuestionAnswer.answerContent');
            }])->first();
        $Q64S1_data = RiskAnalysisQuestion::where('question_code', 'Q64S1')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                return $que->where('location_id', $location->id)
                    ->with('attemptedQuestionAnswer.answerContent');
            }])->first();
        $ALL_OTHER_MEDIA_PARAGRAPH = '';
        if ($Q64_data) {
            if ($Q64_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                if ($Q64S1_data) {
                    if ($Q64S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                        $ALL_OTHER_MEDIA_PARAGRAPH = htmlspecialchars('Understanding the inherent risk, '.$location->company_name.' uses the image, likeness, and/or testimony of patients or visitors on websites, social media, and/or marketing material. For the purpose of this policy, likeness refers to the image - whether in photograph, drawing, caricature, or other visual representation - name, or voice of a visitor or patient. Before ever using an image, likeness, and/or testimony '.$location->company_name.' takes additional precaution to ensure all patients and visitors sign a Media Consent Form.');
                    } elseif ($Q64S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                        $ALL_OTHER_MEDIA_PARAGRAPH = htmlspecialchars('Currently, '.$location->company_name.' does not have patients or visitors sign a Media Consent Form before using their image, likeness, and/or testimony. For the purpose of this policy, likeness refers to the image - whether in photograph, drawing, caricature, or other visual representation - name, or voice of a visitor or patient. '.$location->company_name.' understands this procedure carries a very high risk of an unauthorized data breach. '.$location->company_name.' is committed to securing all protected health information and will re-examine this procedure in the near future.');
                    }
                }
            } elseif ($Q64_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $ALL_OTHER_MEDIA_PARAGRAPH = htmlspecialchars($location->company_name.' does not use the image, likeness, and/or testimony of patients or visitors on websites, social media, or marketing material. For the purpose of this policy, likeness refers to the image - whether in photograph, drawing, caricature, or other visual representation - name, or voice of a visitor or patient.');
            }
        }
        if ($is_policy_version) {
            $data['ALL_OTHER_MEDIA_PARAGRAPH'] = $ALL_OTHER_MEDIA_PARAGRAPH;
        } else {
            $template_processor->setValue('ALL_OTHER_MEDIA_PARAGRAPH', $ALL_OTHER_MEDIA_PARAGRAPH);
        }
    }

    private function procedure_SPP(&$data, $location, $is_policy_version, $template_processor)
    {
        $hco_data = HipaaComplianceOfficer::where('location_id', $location->id)->with('hco')->first();
        if ($is_policy_version) {
            $data['HIPAA_COMPLIANCE_OFFICER'] = htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name);
        } else {
            $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name));
        }
    }

    private function policy_AAP(&$data, $location, $is_policy_version, $is_educational, $template_processor)
    {
        // Employee data
        $employee_list = Employee::where('primary_work_location_id', $location->id)
            ->with(['employeeAccessRight' => function ($query) use ($location) {
                return $query->where('location_id', $location->id);
            }])
            ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($location) {
                return $query->where('location_id', $location->id);
            })->get();

        // Q42
        $Q42_data = RiskAnalysisQuestion::where('question_code', 'Q42')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();

        $Q42_ANS = 'is unsure if employee access to their PM/EHR system currently corresponds to their job responsibilities, and acknowledges that this presents a very high risk level to ePHI';
        if ($Q42_data) {
            if ($Q42_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $Q42_ANS = 'ensures that employee access to their PM/EHR system corresponds to their job responsibilities';
            } elseif ($Q42_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $Q42_ANS = 'does not currently ensure that employee access to their PM/EHR system corresponds to their job responsibilities, and acknowledges that this presents a medium risk level to ePHI';
            } elseif ($Q42_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $Q42_ANS = 'is unsure if employee access to their PM/EHR system currently corresponds to their job responsibilities, and acknowledges that this presents a very high risk level to ePHI';
            }
        }

        // Q43
        $Q43_data = RiskAnalysisQuestion::where('question_code', 'Q43')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();

        $Q43_ANS = 'is unsure if employee access to their IT network currently corresponds to their job responsibilities, and acknowledges that this presents a very high risk level to ePHI';

        if ($Q43_data) {
            if ($Q43_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $Q43_ANS = 'ensures that employee access to their IT network corresponds to their job responsibilities';
            } elseif ($Q43_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $Q43_ANS = 'does not currently ensure that employee access to their IT network corresponds to their job responsibilities, and acknowledges that this presents a medium risk level to ePHI';
            } elseif ($Q43_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $Q43_ANS = 'is unsure if employee access to their IT network currently corresponds to their job responsibilities, and acknowledges that this presents a very high risk level to ePHI';
            }
        }

        if ($is_policy_version) {
            $data['employee_list'] = $employee_list;
            $data['Q42_ANS'] = $Q42_ANS;
            $data['Q43_ANS'] = $Q43_ANS;
        } else {
            $total = count($employee_list);
            if ($total > 0) {
                $template_processor->cloneRow('EMPLOYEE_NAME', $total);
                for ($i = 0; $i < $total; $i++) {
                    $template_processor->setValue('EMPLOYEE_NAME#'.($i + 1), htmlspecialchars($employee_list[$i]['first_name'].' '.$employee_list[$i]['last_name']));
                    if ($employee_list[$i]['employeeAccessRight'] && $employee_list[$i]['employeeAccessRight'] != null) {
                        $template_processor->setValue('FULL_FACILITY_ACCESS#'.($i + 1), htmlspecialchars($employee_list[$i]['employeeAccessRight']['full_facility_access']));
                        $template_processor->setValue('KEY_TO_FACILITY#'.($i + 1), htmlspecialchars($employee_list[$i]['employeeAccessRight']['facility_access_key']));
                        $template_processor->setValue('FULL_SOFTWARE_ACCESS#'.($i + 1), htmlspecialchars($employee_list[$i]['employeeAccessRight']['full_software_access']));
                        $template_processor->setValue('SOFTWARE_ADMIN_PRIVILEGES#'.($i + 1), htmlspecialchars($employee_list[$i]['employeeAccessRight']['software_admin_privilages']));
                        $template_processor->setValue('FULL_NETWORK_ACCESS#'.($i + 1), htmlspecialchars($employee_list[$i]['employeeAccessRight']['full_network_access']));
                        $template_processor->setValue('NETWORK_ADMIN_PRIVILEGES#'.($i + 1), htmlspecialchars($employee_list[$i]['employeeAccessRight']['network_admin_privilages']));
                    } else {
                        $template_processor->setValue('FULL_FACILITY_ACCESS#'.($i + 1), 'No');
                        $template_processor->setValue('KEY_TO_FACILITY#'.($i + 1), 'No');
                        $template_processor->setValue('FULL_SOFTWARE_ACCESS#'.($i + 1), 'No');
                        $template_processor->setValue('SOFTWARE_ADMIN_PRIVILEGES#'.($i + 1), 'No');
                        $template_processor->setValue('FULL_NETWORK_ACCESS#'.($i + 1), 'No');
                        $template_processor->setValue('NETWORK_ADMIN_PRIVILEGES#'.($i + 1), 'No');
                    }
                }
            } else {
                $template_processor->setValue('EMPLOYEE_NAME', '');
                $template_processor->setValue('FULL_FACILITY_ACCESS', '');
                $template_processor->setValue('KEY_TO_FACILITY', '');
                $template_processor->setValue('FULL_SOFTWARE_ACCESS', '');
                $template_processor->setValue('SOFTWARE_ADMIN_PRIVILEGES', '');
                $template_processor->setValue('FULL_NETWORK_ACCESS', '');
                $template_processor->setValue('NETWORK_ADMIN_PRIVILEGES', '');
            }

            $template_processor->setValue('Q42_ANS', $Q42_ANS);
            $template_processor->setValue('Q43_ANS', $Q43_ANS);
        }
        if ($is_educational == true) {
            $students = Student::with('studentClass')->where('primary_work_location_id', $location->id)->get();
            if ($is_policy_version) {
                $data['students'] = $students;
            } else {
                $student_total = count($students);
                if ($student_total > 0) {
                    $template_processor->cloneRow('STUDENT_NAME', $student_total);
                    for ($i = 0; $i < $student_total; $i++) {
                        $template_processor->setValue('STUDENT_NAME#'.($i + 1), htmlspecialchars($students[$i]['first_name'].' '.$students[$i]['last_name']));
                        $template_processor->setValue('CLASS_NAME#'.($i + 1), htmlspecialchars($students[$i]['studentClass']['class_name']));
                        $template_processor->setValue('IMAGING_DEVICE_ACCESS#'.($i + 1), htmlspecialchars($students[$i]['imaging_device_access']));
                        $template_processor->setValue('STUDENT_FULL_NETWORK_ACCESS#'.($i + 1), htmlspecialchars($students[$i]['full_network_access']));
                        $template_processor->setValue('STUDENT_FULL_SOFTWARE_ACCESS#'.($i + 1), htmlspecialchars($students[$i]['full_software_access']));
                    }
                } else {
                    $template_processor->setValue('STUDENT_NAME', '');
                    $template_processor->setValue('CLASS_NAME', '');
                    $template_processor->setValue('IMAGING_DEVICE_ACCESS', '');
                    $template_processor->setValue('STUDENT_FULL_NETWORK_ACCESS', '');
                    $template_processor->setValue('STUDENT_FULL_SOFTWARE_ACCESS', '');
                }
            }
        }
    }

    private function policy_BNP(&$data, $location, $is_policy_version, $template_processor)
    {
        $state = $location->state;
        $breach_detail = $state->breachDetail;

        if ($is_policy_version) {
            $data['BREACH_TIME'] = htmlspecialchars($breach_detail['state_breach_time']);
            $data['NOTICE_FORM'] = htmlspecialchars($breach_detail['notice_form']);
            $data['SUBSTITUTE_THRESHOLD'] = htmlspecialchars($breach_detail['substitute_threshold']);
            $data['BREACH_CONTENT'] = htmlspecialchars($breach_detail['breach_content']);
            $data['BA_NOTICE_TIMING'] = htmlspecialchars($breach_detail['BA_notice_timing']);

            if ($breach_detail['state_notice'] != '' && $breach_detail['state_notice_timing'] != '') {
                $data['ADDITIONAL_STATE_NOTICE_TITLE'] = 'Additional ${STATE} Notice(s)</w:t><w:br/><w:t>';
                $data['ADDITIONAL_STATE_NOTICE'] = 'Because ${CLIENT_NAME} is located in ${STATE}, ${CLIENT_NAME} must also notify ${STATE_NOTICE}. Notification must be provided ${STATE_NOTICE_TIMING}. ${STATE_NOTICE_INFO}</w:t><w:br/><w:t></w:t><w:br/><w:t>';

                $data['STATE_NOTICE'] = $breach_detail['state_notice'];
                $data['STATE_NOTICE_TIMING'] = $breach_detail['state_notice_timing'];
                $data['STATE_NOTICE_INFO'] = $breach_detail['state_notice_info'];
            } else {
                $data['ADDITIONAL_STATE_NOTICE_TITLE'] = '';
                $data['ADDITIONAL_STATE_NOTICE'] = '';
            }
            $data['STATE'] = htmlspecialchars($state['state_name']);
            $data['CLIENT_NAME'] = htmlspecialchars($location->company_name);
        } else {
            $template_processor->setValue('BREACH_TIME', htmlspecialchars($breach_detail['state_breach_time']));
            $template_processor->setValue('NOTICE_FORM', htmlspecialchars($breach_detail['notice_form']));
            $template_processor->setValue('SUBSTITUTE_THRESHOLD', htmlspecialchars($breach_detail['substitute_threshold']));
            $template_processor->setValue('BREACH_CONTENT', htmlspecialchars($breach_detail['breach_content']));
            $template_processor->setValue('BA_NOTICE_TIMING', htmlspecialchars($breach_detail['BA_notice_timing']));

            if ($breach_detail['state_notice'] != '' && $breach_detail['state_notice_timing'] != '') {
                $template_processor->setValue('ADDITIONAL_STATE_NOTICE_TITLE', 'Additional ${STATE} Notice(s)</w:t><w:br/><w:t>');
                $template_processor->setValue('ADDITIONAL_STATE_NOTICE', 'Because ${CLIENT_NAME} is located in ${STATE}, ${CLIENT_NAME} must also notify ${STATE_NOTICE}. Notification must be provided ${STATE_NOTICE_TIMING}. ${STATE_NOTICE_INFO}</w:t><w:br/><w:t></w:t><w:br/><w:t>');

                $template_processor->setValue('STATE_NOTICE', $breach_detail['state_notice']);
                $template_processor->setValue('STATE_NOTICE_TIMING', $breach_detail['state_notice_timing']);
                $template_processor->setValue('STATE_NOTICE_INFO', $breach_detail['state_notice_info']);
            } else {
                $template_processor->setValue('ADDITIONAL_STATE_NOTICE_TITLE', '');
                $template_processor->setValue('ADDITIONAL_STATE_NOTICE', '');
            }
            $template_processor->setValue('STATE', htmlspecialchars($state['state_name']));
            $template_processor->setValue('CLIENT_NAME', htmlspecialchars($location->company_name));
        }
    }

    private function policy_BACP(&$data, $policy, $location, $is_policy_version, $template_processor)
    {
        $business_associates = BusinessAssociates::whereHas('businessAssociatesLocation', function ($query) use ($location) {
            $query->where('location_id', $location->id);
        })
            ->with(['businessAssociatesAgreement', 'predefineBusinessAssociative'])->get();
        if ($is_policy_version) {
            $data['business_associates'] = $business_associates;
        } else {
            if (count($business_associates) > 0) {
                $template_processor->cloneRow('BUSINESS_ASSCOIATE', count($business_associates));
                foreach ($business_associates as $i => $ba) {
                    $template_processor->setValue('BUSINESS_ASSCOIATE#'.($i + 1), htmlspecialchars($ba->name));
                    $is_current = 'Incomplete';
                    if ($ba->predefine_business_associates_id == null) {
                        if ($ba->businessAssociatesAgreement && $ba->businessAssociatesAgreement->signature === null && $ba->businessAssociatesAgreement->agreement_link === null && $ba->businessAssociatesAgreement->file_name === null) {
                            $is_current = 'Pending';
                        } elseif ($ba->businessAssociatesAgreement && ($ba->businessAssociatesAgreement->signature !== null || $ba->businessAssociatesAgreement->agreement_link !== null || $ba->businessAssociatesAgreement->file_name !== null)) {
                            $is_current = 'Complete';
                        }
                    } else {
                        if ($ba->predefineBusinessAssociative->agreement_type == 'predefined_dynamic_doc' && $ba->businessAssociatesAgreement->file_name == null) {
                            $is_current = 'Pending';
                        } else {
                            $is_current = 'Complete';
                        }
                    }
                    if ($ba->expired_date === null) {
                        $exp_date = ' No Expiration ';
                    } else {
                        $exp_date = new Carbon($ba->expired_date);
                        $exp_date = $exp_date->format('m/d/Y');
                    }
                    $template_processor->setValue('IS_CURRENT#'.($i + 1), $is_current);
                    $template_processor->setValue('RENEWAL_DATE#'.($i + 1), $exp_date);
                    $template_processor->setValue('BA_EMAIL#'.($i + 1), htmlspecialchars($ba->email));
                    $template_processor->setValue('BA_PHONE#'.($i + 1), htmlspecialchars($ba->phone_number));
                }
            } else {
                $template_processor->setValue('BUSINESS_ASSCOIATE', '');
                $template_processor->setValue('BA_EMAIL', '');
                $template_processor->setValue('BA_PHONE', '');
                $template_processor->setValue('IS_CURRENT', '');
                $template_processor->setValue('RENEWAL_DATE', '');
            }
        }
    }

    private function policy_EDDP(&$data, $location, $is_policy_version, $template_processor)
    {
        //logic for dynamic variable
    }

    private function policy_EFP(&$data, $location, $is_policy_version, $template_processor)
    {
        $company_name = htmlspecialchars($location->company_name);
        // Q47
        $PARAGRAPH_1 = '';
        $Q47_data = RiskAnalysisQuestion::where('question_code', 'Q47')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();

        if ($Q47_data) {
            if ($Q47_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $PARAGRAPH_1 = "$company_name mandates all employees be assigned a company email address upon hiring. Email addresses are intended to be used for business purposes only.";
            } elseif ($Q47_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2' || $Q47_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $PARAGRAPH_1 = "Even though $company_name does not mandate all employees be assigned a company email address, employees are informed upon hiring of appropriate and inappropriate uses of email.";
            }
        }

        // Q46 & Q46S1
        $PARAGRAPH_2 = '';
        $Q46_data = RiskAnalysisQuestion::where('question_code', 'Q46')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $Q46S1_data = RiskAnalysisQuestion::where('question_code', 'Q46S1')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        if ($Q46_data) {
            if ($Q46_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                if ($Q46S1_data) {
                    if ($Q46S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                        $encrypt_external = 'uses encrypted or secure email';
                        $PARAGRAPH_2 = "When transmission of Electronic Protected Health Information (ePHI) to patients or other doctors is time-sensitive and delivery by regular mail will not meet the reasonable needs of the sender or recipient, $company_name securely emails ePHI. $company_name $encrypt_external to send ePHI to other doctors offices or patients.";
                    } elseif ($Q46S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                        $encrypt_external = 'does not currently use encrypted or secure email';
                        $PARAGRAPH_2 = "When transmission of Electronic Protected Health Information (ePHI) to patients or other doctors is time-sensitive and delivery by regular mail will not meet the reasonable needs of the sender or recipient, $company_name emails ePHI. $company_name $encrypt_external to send ePHI to other doctors offices or patients.";
                    } elseif ($Q46S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                        $encrypt_external = 'is unsure whether encryption is used';
                        $PARAGRAPH_2 = "When transmission of Electronic Protected Health Information (ePHI) to patients or other doctors is time-sensitive and delivery by regular mail will not meet the reasonable needs of the sender or recipient, $company_name emails ePHI. $company_name $encrypt_external to email ePHI to other doctors offices or patients, and will evaluate this policy as soon as possible.";
                    }
                }
            } elseif ($Q46_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $PARAGRAPH_2 = "$company_name does NOT, under any circumstances, send Electronic Protected Health Information to patients or other doctors via email.";
            } elseif ($Q46_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $PARAGRAPH_2 = "$company_name is unsure if email is used to send electronic protected health information (ePHI) to other doctors offices or patients, and will review their policies as soon as possible.";
            }
        }

        // Q51, Q51S1, Q51S2, Q51S3

        $Q51_data = RiskAnalysisQuestion::where('question_code', 'Q51')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $Q51S1_data = RiskAnalysisQuestion::where('question_code', 'Q51S1')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $Q51S2_data = RiskAnalysisQuestion::where('question_code', 'Q51S2')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $Q51S3_data = RiskAnalysisQuestion::where('question_code', 'Q51S3')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();

        $COVER_SHEET = '';
        $NUMBER_CONFIRMED = '';
        $RECEIPT_CONFIRMED = '';

        if ($Q51_data) {
            if ($Q51_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                if ($Q51S1_data != '') {
                    if ($Q51S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                        $COVER_SHEET = 'Use of standard company cover sheet containing minimum information necessary and the following disclosure: This facsimile is intended only for the use of the named addressee and may contain information that is confidential or privileged. If you are not the intended recipient, or you are not the employee responsible for delivering the facsimile for the intended recipient, you are hereby notified that any dissemination, distribution or copying of this facsimile is strictly prohibited. If you have received this facsimile in error, please notify the sender immediately.';
                    } else {
                        $COVER_SHEET = "$company_name does not require the use of a cover sheet and has identified this procedure as high risk.";
                    }
                } else {
                    $COVER_SHEET = "$company_name does not require the use of a cover sheet and has identified this procedure as high risk.";
                }
                if ($Q51S2_data != '') {
                    if ($Q51S2_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                        $NUMBER_CONFIRMED = 'Recipient fax number should be confirmed before sending fax.';
                    } else {
                        $NUMBER_CONFIRMED = "$company_name does not require the recipient's fax number to be verified before sending a fax and has identified this procedure as a high risk.";
                    }
                } else {
                    $NUMBER_CONFIRMED = "$company_name does not require the recipient's fax number to be verified before sending a fax and has identified this procedure as a high risk.";
                }
                if ($Q51S3_data != '') {
                    if ($Q51S3_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                        $RECEIPT_CONFIRMED = 'Recipient receipt of fax is confirmed.';
                    } else {
                        $RECEIPT_CONFIRMED = "$company_name does not require confirmation the recipient received the fax and has identified this as a medium risk.";
                    }
                } else {
                    $RECEIPT_CONFIRMED = "$company_name does not require confirmation the recipient received the fax and has identified this as a medium risk.";
                }
            } else {
                $COVER_SHEET = "$company_name does not require the use of a cover sheet and has identified this procedure as high risk.";
                $NUMBER_CONFIRMED = "$company_name does not require the recipient's fax number to be verified before sending a fax and has identified this procedure as a high risk.";
                $RECEIPT_CONFIRMED = "$company_name does not require confirmation the recipient received the fax and has identified this as a medium risk.";
            }
        } else {
            $COVER_SHEET = "$company_name does not require the use of a cover sheet and has identified this procedure as high risk.";
            $NUMBER_CONFIRMED = "$company_name does not require the recipient's fax number to be verified before sending a fax and has identified this procedure as a high risk.";
            $RECEIPT_CONFIRMED = "$company_name does not require confirmation the recipient received the fax and has identified this as a medium risk.";
        }

        // Q62S1
        $Q62S1_data = RiskAnalysisQuestion::where('question_code', 'Q62S1')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();

        $SECURE_AREA = '';
        if ($Q62S1_data) {
            if ($Q62S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $SECURE_AREA = "The fax machine could possibly be accessed by patients or visitors. $company_name has identified this as a high risk.";
            } elseif ($Q62S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $SECURE_AREA = 'Ensure fax machine is located in a secure area.';
            } else {
                $SECURE_AREA = "The fax machine could possibly be accessed by patients or visitors. $company_name has identified this as a high risk.";
            }
        } else {
            $SECURE_AREA = "The fax machine could possibly be accessed by patients or visitors. $company_name has identified this as a high risk.";
        }

        // Q45
        $Q45_data = RiskAnalysisQuestion::where('question_code', 'Q45')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();

        $Q45S1_data = RiskAnalysisQuestion::where('question_code', 'Q45S1')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $EMAILING_INTERNAL = '';
        if ($Q45_data) {
            if ($Q45_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $encrypt_internal = 'is unsure whether encryption is used';
                if ($Q45S1_data) {
                    if ($Q45S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                        $encrypt_internal = 'uses encrypted or secure email';
                    } elseif ($Q45S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                        $encrypt_internal = 'does not currently use encrypted or secure email';
                    }
                }
                $EMAILING_INTERNAL = "$company_name uses email to send electronic protected health information (ePHI) among staff members. $company_name $encrypt_internal to send ePHI internally among staff members.";
            } elseif ($Q45_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $EMAILING_INTERNAL = "$company_name does not currently use email to send electronic protected health information (ePHI) among staff members.";
            } else {
                $EMAILING_INTERNAL = "$company_name is unsure if email is used to send electronic protected health information (ePHI) among staff members, and will review their policies as soon as possible.";
            }
        }

        if ($is_policy_version) {
            $data['PARAGRAPH_1'] = $PARAGRAPH_1;
            $data['PARAGRAPH_2'] = $PARAGRAPH_2;
            $data['COVER_SHEET'] = $COVER_SHEET;
            $data['NUMBER_CONFIRMED'] = $NUMBER_CONFIRMED;
            $data['RECEIPT_CONFIRMED'] = $RECEIPT_CONFIRMED;
            $data['SECURE_AREA'] = $SECURE_AREA;
            $data['EMAILING_INTERNAL'] = $EMAILING_INTERNAL;
        } else {
            $template_processor->setValue('PARAGRAPH_1', $PARAGRAPH_1);
            $template_processor->setValue('PARAGRAPH_2', $PARAGRAPH_2);
            $template_processor->setValue('COVER_SHEET', $COVER_SHEET);
            $template_processor->setValue('NUMBER_CONFIRMED', $NUMBER_CONFIRMED);
            $template_processor->setValue('RECEIPT_CONFIRMED', $RECEIPT_CONFIRMED);
            $template_processor->setValue('SECURE_AREA', $SECURE_AREA);
            $template_processor->setValue('EMAILING_INTERNAL', $EMAILING_INTERNAL);
        }
    }

    private function policy_ETP(&$data, $location, $is_policy_version, $template_processor)
    {
        $hco_data = HipaaComplianceOfficer::where('location_id', $location->id)->with('hco')->first();

        if ($is_policy_version) {
            $data['HIPAA_COMPLIANCE_OFFICER'] = htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name);
            $data['TERMINATION_TIMEFRAME'] = '';
        } else {
            $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name));
            $template_processor->setValue('TERMINATION_TIMEFRAME', '');
        }
    }

    private function policy_HCUAP(&$data, $location, $is_policy_version, $template_processor)
    {
        $state = $location->state;
        $breach_detail = $state->breachDetail;

        if ($breach_detail['state_records_time_frame'] != '') {
            $STATE_RECORDS_TIMEFRAME = htmlspecialchars($breach_detail['state_records_time_frame']);
        } else {
            $STATE_RECORDS_TIMEFRAME = '';
        }

        if ($is_policy_version) {
            $data['STATE_RECORDS_TIMEFRAME'] = $STATE_RECORDS_TIMEFRAME;
            $data['STATE'] = htmlspecialchars($state['state_name']);
            $data['CLIENT_NAME'] = htmlspecialchars($location->company_name);
        } else {
            $template_processor->setValue('STATE_RECORDS_TIMEFRAME', $STATE_RECORDS_TIMEFRAME);
            $template_processor->setValue('STATE', htmlspecialchars($state['state_name']));
            $template_processor->setValue('CLIENT_NAME', htmlspecialchars($location->company_name));
        }
    }

    private function policy_HNEP(&$data, $location, $is_policy_version, $template_processor)
    {
        $hco_data = HipaaComplianceOfficer::where('location_id', $location->id)->with('hco')->first();
        if ($is_policy_version) {
            $data['HIPAA_COMPLIANCE_OFFICER'] = htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name);
        } else {
            $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name));
        }
    }

    private function policy_NPP(&$data, $location, $is_policy_version, $template_processor)
    {
        if ($is_policy_version) {
            $data['SIGNUP_DATE'] = htmlspecialchars('');
        } else {
            $template_processor->setValue('SIGNUP_DATE', htmlspecialchars(''));
        }
    }

    private function policy_PMP(&$data, $location, $is_policy_version, $template_processor)
    {
        $company_name = htmlspecialchars($location->company_name);

        $hco_data = HipaaComplianceOfficer::where('location_id', $location->id)->with('hco')->first();

        $Q34_data = RiskAnalysisQuestion::where('question_code', 'Q34')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $RA_Q34_DEPENDANT = "Passwords are updated but the timeframe in which they are changed is unknown. $company_name will update this information as soon as possible.";
        if ($Q34_data) {
            if ($Q34_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A7') {
                $RA_Q34_DEPENDANT = 'Passwords are to be updated and changed every 6 months';
            } elseif ($Q34_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A8') {
                $RA_Q34_DEPENDANT = 'Passwords are to be updated and changed every 4 months';
            } elseif ($Q34_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A6') {
                $RA_Q34_DEPENDANT = 'Passwords are not currently changed on any specified timeframe';
            }
        }

        $Q21_data = RiskAnalysisQuestion::where('question_code', 'Q21')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $RA_Q21_DEPENDANT = '';
        if ($Q21_data) {
            if ($Q21_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $RA_Q21_DEPENDANT = "$company_name ensures all employees access computers with a unique user ID";
            } elseif ($Q21_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $RA_Q21_DEPENDANT = "Currently, $company_name's employees do not all access computers with a unique user ID. $company_name understands this creates an elevated risk to the exposure of protected health information and will re-evaluate this policy in the near future";
            } else {
                $RA_Q21_DEPENDANT = "$company_name currently uses login information to access computers, but is still determining if they are unique for all employees. By not being aware of login procedures and safeguards, $company_name understands this creates an elevated risk to the exposure of protected health information and will work diligently to determine current login procedures";
            }
        }

        $NY_STATE_PARAGRAPH = '';
        if ($location->state->state_code == 'NY') {
            $NY_STATE_PARAGRAPH = '</w:t><w:br/><w:t>The New York Shield Act determines personal information that must be safeguarded to include usernames or email addresses in combination with a password or security question and answer that would allow access to an online account. The Shield Act requires at least one employee, the HIPAA Compliance Officer, '.htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name).', to coordinate the security program to protect all personal information by implementing the necessary administrative, physical and technical safeguards.</w:t><w:br/><w:t>';
        }

        $Q33_data = RiskAnalysisQuestion::where('question_code', 'Q33')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $COMPLEX_ANSWER = '';
        if ($Q33_data) {
            if ($Q33_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $COMPLEX_ANSWER = 'must';
            } elseif ($Q33_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $COMPLEX_ANSWER = 'do not currently, but should,';
            } elseif ($Q33_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $COMPLEX_ANSWER = 'may not currently, but should,';
            }
        }

        $Q26_data = RiskAnalysisQuestion::where('question_code', 'Q26')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $RA_Q26_DEPENDANT = "$company_name is unsure if computer automatically log off after a period of inactivity, and understands this creates an elevated risk to the exposure of protected health information and will re-evaluate this policy in the near future";
        if ($Q26_data) {
            if ($Q26_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $Q26S1_data = RiskAnalysisQuestion::where('question_code', 'Q26S1')
                    ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                        $que->where(['location_id' => $location->id]);
                    })
                    ->with(
                        ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                            return $que->where('location_id', $location->id)
                                ->with('attemptedQuestionAnswer.answerContent');
                        }]
                    )->first();
                if ($Q26S1_data) {
                    if ($Q26S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A13') {
                        $RA_Q26_DEPENDANT = 'Computers log users off after a period five minutes or less of inactivity';
                    } elseif ($Q26S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A14') {
                        $RA_Q26_DEPENDANT = "Computers log users off after a period of five minutes or more of inactivity. $company_name understands this creates an elevated risk to the exposure of protected health information and will re-evaluate this policy in the near future";
                    } elseif ($Q26S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                        $RA_Q26_DEPENDANT = "Computers log users off after a period of inactivity. Currently, $company_name is not aware of the time frame before users are logged off. $company_name understands this creates an elevated risk to the exposure of protected health information and will re-evaluate this policy in the near future";
                    }
                }
            } elseif ($Q26_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $RA_Q26_DEPENDANT = "Computers do not currently automatically log off after a period of inactivity, and $company_name understands this represents an elevated risk to the exposure of protected health information";
            }
        }

        if ($is_policy_version) {
            $data['RA_Q34_DEPENDANT'] = $RA_Q34_DEPENDANT;
            $data['RA_Q21_DEPENDANT'] = $RA_Q21_DEPENDANT;
            $data['NY_STATE_PARAGRAPH'] = $NY_STATE_PARAGRAPH;
            $data['COMPLEX_ANSWER'] = $COMPLEX_ANSWER;
            $data['RA_Q26_DEPENDANT'] = $RA_Q26_DEPENDANT;
            $data['HIPAA_COMPLIANCE_OFFICER'] = htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name);
        } else {
            $template_processor->setValue('RA_Q34_DEPENDANT', $RA_Q34_DEPENDANT);
            $template_processor->setValue('RA_Q21_DEPENDANT', $RA_Q21_DEPENDANT);
            $template_processor->setValue('NY_STATE_PARAGRAPH', $NY_STATE_PARAGRAPH);
            $template_processor->setValue('COMPLEX_ANSWER', $COMPLEX_ANSWER);
            $template_processor->setValue('RA_Q26_DEPENDANT', $RA_Q26_DEPENDANT);
            $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name));
        }
    }

    private function policy_PCFP(&$data, $location, $is_policy_version, $template_processor)
    {
        $hco_data = HipaaComplianceOfficer::where('location_id', $location->id)->with('hco')->first();
        if ($is_policy_version) {
            $data['HIPAA_COMPLIANCE_OFFICER'] = htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name);
        } else {
            $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name));
        }
    }

    private function policy_PHDRP(&$data, $location, $is_policy_version, $template_processor)
    {
        $client_name = htmlspecialchars($location->company_name);

        $state = $location->state;
        $breach_detail = $state->breachDetail;

        $REQUEST_TIME = htmlspecialchars($breach_detail['request_time']);
        $DYNAMIC_STATE_TEXT = 'In providing access to the patient, '.$client_name.' must provide access to the PHI requested, in whole, or in part, no later than '.$REQUEST_TIME.' from receiving the individual’s request. If '.$client_name.' is unable to provide access within '.$REQUEST_TIME.' -- for example, where the information is archived offsite and not readily accessible -- '.$client_name.' may extend the time by no more than an additional 30 days. To extend the time, '.$client_name.' must, within the initial '.$REQUEST_TIME.', inform the individual in writing of the reasons for the delay and the date by which '.$client_name.' will provide them access. Only one extension is permitted per access request.';

        $Q71_data = RiskAnalysisQuestion::where('question_code', 'Q71')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $RA_Q71_SENTENCE = '';
        if ($Q71_data) {
            $Q71_method = '';
            if ($Q71_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $Q71_method = "by written request using the practice's own form";
            } elseif ($Q71_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $Q71_method = 'using the Patient Health Data Request Form located within Abyde';
            } elseif ($Q71_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $Q71_method = 'either by written or verbal request';
            } elseif ($Q71_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A4') {
                $Q71_method = '';
            }
            if ($Q71_method != '') {
                $RA_Q71_SENTENCE = "</w:t><w:br/><w:t></w:t><w:br/><w:t>$client_name requires patients to request access $Q71_method, and $client_name must inform individuals of this requirement. For written requests, patients may submit their request to $client_name in person, by mail, or by email. $client_name may also offer the option of using other electronic means like a secure web portal to make requests.";
            }
        }
        if ($is_policy_version) {
            $data['DYNAMIC_STATE_TEXT'] = $DYNAMIC_STATE_TEXT;
            $data['REQUEST_TIME'] = $REQUEST_TIME;
            $data['RA_Q71_SENTENCE'] = $RA_Q71_SENTENCE;
        } else {
            $template_processor->setValue('DYNAMIC_STATE_TEXT', $DYNAMIC_STATE_TEXT);
            $template_processor->setValue('REQUEST_TIME', $REQUEST_TIME);
            $template_processor->setValue('RA_Q71_SENTENCE', $RA_Q71_SENTENCE);
        }
    }

    private function policy_SAP(&$data, $location, $is_policy_version, $template_processor)
    {
        $client_name = htmlspecialchars($location->company_name);
        $hco_data = HipaaComplianceOfficer::where('location_id', $location->id)->with('hco')->first();

        $disaster_vendor = DisasterVendor::where('location_id', $location->id)->first();
        $ALARM_SYSTEM_COMPANY_SENTENCE = 'does not use an alarm system vendor';
        if ($disaster_vendor->alarm_system_company != '' && $disaster_vendor->alarm_system_company != null) {
            $ALARM_SYSTEM_COMPANY_SENTENCE = 'uses '.htmlspecialchars($disaster_vendor->alarm_system_company).' as their alarm system vendor';
        }

        // Q1S3
        $Q1S3_data = RiskAnalysisQuestion::where('question_code', 'Q1S3')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $RA_Q1S3_SENTENCE = '';
        if ($Q1S3_data) {
            if ($Q1S3_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A9' || $Q1S3_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A10' || $Q1S3_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A11') {
                $RA_Q1S3_SENTENCE = '</w:t><w:br/><w:t></w:t><w:br/><w:t>
Alarm codes must be changed:</w:t><w:br/><w:t>
</w:t><w:tab/><w:t>● '.htmlspecialchars($Q1S3_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer']).'</w:t><w:br/><w:t>
</w:t><w:tab/><w:t>● '.htmlspecialchars('Physical relocation of the practice').'</w:t><w:br/><w:t>
</w:t><w:tab/><w:t>● '.htmlspecialchars('Major staff turnover').'</w:t><w:br/><w:t>';
            } elseif ($Q1S3_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $RA_Q1S3_SENTENCE = "</w:t><w:br/><w:t></w:t><w:br/><w:t>
Currently, it is unclear how often $client_name changes alarm codes. $client_name understands this creates an elevated risk when attempting to secure protected health information and will re-evaluate this process in the near future.</w:t><w:br/><w:t>";
            } elseif ($Q1S3_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A6') {
                $RA_Q1S3_SENTENCE = "</w:t><w:br/><w:t></w:t><w:br/><w:t>
$client_name does not currently change alarm codes on a regular basis. $client_name understands this creates an elevated risk when attempting to secure protected health information and will re-evaluate this process in the near future.</w:t><w:br/><w:t>";
            } else {
                $RA_Q1S3_SENTENCE = '</w:t><w:br/><w:t>';
            }
        } else {
            $RA_Q1S3_SENTENCE = '</w:t><w:br/><w:t>';
        }

        // Employee data
        $employee_list = Employee::where('primary_work_location_id', $location->id)
            ->with(['employeeAccessRight' => function ($query) use ($location) {
                return $query->where('location_id', $location->id);
            }])
            ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($location) {
                return $query->where('location_id', $location->id);
            })->get();

        if ($is_policy_version) {

            $data['employee_list'] = $employee_list;
            $data['HIPAA_COMPLIANCE_OFFICER'] = htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name);
            $data['ALARM_SYSTEM_COMPANY_SENTENCE'] = $ALARM_SYSTEM_COMPANY_SENTENCE;
            $data['RA_Q1S3_SENTENCE'] = $RA_Q1S3_SENTENCE;
        } else {
            if (count($employee_list) > 0) {
                $template_processor->cloneRow('EMPLOYEE_NAME', count($employee_list));
                foreach ($employee_list as $i => $emp) {
                    $template_processor->setValue('EMPLOYEE_NAME#'.($i + 1), htmlspecialchars($emp['first_name'].' '.$emp['last_name']));
                    if ($emp['employeeAccessRight']) {
                        if ($emp['employeeAccessRight']['security_code'] != null && $emp['employeeAccessRight']['security_code'] != '') {
                            $template_processor->setValue('ALARM_CODE#'.($i + 1), htmlspecialchars($emp['employeeAccessRight']['security_code']));
                        } else {
                            $template_processor->setValue('ALARM_CODE#'.($i + 1), 'N/A');
                        }
                    } else {
                        $template_processor->setValue('ALARM_CODE#'.($i + 1), 'N/A');
                    }
                }
            } else {
                $template_processor->setValue('EMPLOYEE_NAME', '');
                $template_processor->setValue('ALARM_CODE', '');
            }

            $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name));
            $template_processor->setValue('ALARM_SYSTEM_COMPANY_SENTENCE', $ALARM_SYSTEM_COMPANY_SENTENCE);
            $template_processor->setValue('RA_Q1S3_SENTENCE', $RA_Q1S3_SENTENCE);
        }
    }

    private function policy_SATP(&$data, $location, $is_policy_version, $template_processor)
    {
        $client_name = htmlspecialchars($location->company_name);
        $hco_data = HipaaComplianceOfficer::where('location_id', $location->id)->with('hco')->first();

        if ($location->state->state_code == 'TX') {
            $DYNAMIC_STATE_TEXT = "Because $client_name is located within Texas, all employees who are required to handle PHI or sensitive personal information (SPI), or are likely to encounter PHI, are required to undergo formal privacy training within 60 days of commencing employment. Any State licenses may also be revoked in cases where an entity or individual has demonstrated continued noncompliance. ";
        } else {
            $DYNAMIC_STATE_TEXT = "Because $client_name recognizes the importance of understanding data security and privacy, $client_name works to complete this training for all new hires at minimum within 90 days of commencing employment. ";
        }

        if ($is_policy_version) {
            $data['HIPAA_COMPLIANCE_OFFICER'] = htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name);
            $data['DYNAMIC_STATE_TEXT'] = htmlspecialchars($DYNAMIC_STATE_TEXT);
        } else {
            $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name));
            $template_processor->setValue('DYNAMIC_STATE_TEXT', htmlspecialchars($DYNAMIC_STATE_TEXT));
        }
    }

    private function policy_SRA(&$data, $location, $is_policy_version, $template_processor)
    {
        $hco_data = HipaaComplianceOfficer::where('location_id', $location->id)->with('hco')->first();
        if ($is_policy_version) {
            $data['HIPAA_COMPLIANCE_OFFICER'] = htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name);
        } else {
            $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($hco_data->hco->first_name.' '.$hco_data->hco->last_name));
        }
    }

    private function policy_VCP(&$data, $location, $is_policy_version, $template_processor)
    {
        $client_name = htmlspecialchars($location->company_name);
        $Q8_data = RiskAnalysisQuestion::where('question_code', 'Q8')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $VISITOR_CONTROL_PARAGRAPH = '';
        if ($Q8_data) {
            if ($Q8_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $VISITOR_CONTROL_PARAGRAPH = 'All Visitors are to be provided a visitor badge and escorted to and from their destination within the facility by a company employee. Other than patient access door(s) during business hours, all doors to the facility shall remain locked at all times. The patient access door and waiting room door shall remain locked outside of business hours. All staff shall exercise diligence about the property and report any incidents, unauthorized access, theft, or tampering immediately.';
            } elseif ($Q8_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $VISITOR_CONTROL_PARAGRAPH = 'All Visitors are to be escorted to and from their destination within the facility by a company employee. Other than patient access door(s) during business hours, all doors to the facility shall remain locked at all times. The patient access door and waiting room door shall remain locked outside of business hours. All staff shall exercise diligence about the property and report any incidents, unauthorized access, theft, or tampering immediately.';
            } elseif ($Q8_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $VISITOR_CONTROL_PARAGRAPH = 'All Visitors are to be escorted to and from their destination within the facility by a company employee. Other than patient access door(s) during business hours, all doors to the facility shall remain locked at all times. The patient access door and waiting room door shall remain locked outside of business hours. All staff shall exercise diligence about the property and report any incidents, unauthorized access, theft, or tampering immediately.';
            }
        }
        // Q65
        $Q65_data = RiskAnalysisQuestion::where('question_code', 'Q65')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $VISITOR_CONTROL_PARAGRAPH_2 = '';
        if ($Q65_data) {
            if ($Q65_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $VISITOR_CONTROL_PARAGRAPH_2 = "In the case visitors of $client_name gain access to clinical areas where they may encounter confidential Protected Health Information (PHI) such as, but not limited to; charts and other paper and electronic records, demographic information, conversations, names of patients, financial information, diagnoses, etc. $client_name ensures each visitor signs a Visitor Confidentiality Agreement.";
            } elseif ($Q65_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $VISITOR_CONTROL_PARAGRAPH_2 = "Currently, in the case visitors of $client_name gain access to clinical areas where they may encounter confidential Protected Health Information (PHI) such as, but not limited to; charts and other paper and electronic records, demographic information, conversations, names of patients, financial information, diagnoses, etc. $client_name does not have each visitor sign a Visitor Confidentiality Agreement. $client_name understands this procedure creates a high risk for compromising sensitive patient data and is focused on addressing this risk in the near future.";
            } elseif ($Q65_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $VISITOR_CONTROL_PARAGRAPH_2 = "Currently, in the case visitors of $client_name gain access to clinical areas where they may encounter confidential Protected Health Information (PHI) such as, but not limited to; charts and other paper and electronic records, demographic information, conversations, names of patients, financial information, diagnoses, etc. $client_name is unsure if each visitor signs a Visitor Confidentiality Agreement. $client_name understands this procedure creates a high risk for compromising sensitive patient data and is focused on addressing this risk in the near future.";
            }
        }
        // Q7
        $Q7_data = RiskAnalysisQuestion::where('question_code', 'Q7')
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                $que->where(['location_id' => $location->id]);
            })
            ->with(
                ['riskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                    return $que->where('location_id', $location->id)
                        ->with('attemptedQuestionAnswer.answerContent');
                }]
            )->first();
        $VISITOR_SIGNIN_PARAGRAPH = '';
        if ($Q7_data) {
            if ($Q7_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                $VISITOR_SIGNIN_PARAGRAPH = "$client_name will validate and document visitor access to any facility used to house protected health information or electronic protected health information based systems. Visitors include vendors, repair personnel, staff family members, delivery men, and other non-workforce members. All visitors will sign in on a visitor log provided by $client_name. The log will identify each visitor’s name, date, visitor company or role, and time in and out of the facility.";
            } elseif ($Q7_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2') {
                $VISITOR_SIGNIN_PARAGRAPH = "$client_name understands that visitor access should be validated and documented for any facility used to house electronic protected health information based systems. Visitors include vendors, repair personnel, staff family members, delivery men, and other non-workforce members. Currently, all visitors do not sign in on a visitor log. $client_name understands this presents a high risk to protected health information and will reevaluate this policy in the near future.";
            } elseif ($Q7_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3') {
                $VISITOR_SIGNIN_PARAGRAPH = "$client_name understands that visitor access should be validated and documented for any facility used to house electronic protected health information based systems. Visitors include vendors, repair personnel, staff family members, delivery men, and other non-workforce members. Currently, $client_name is unsure if all visitors sign in on a visitor log. $client_name understands this presents a high risk to protected health information and will reevaluate this policy in the near future.";
            }
        }
        if ($is_policy_version) {
            $data['VISITOR_SIGNIN_PARAGRAPH'] = htmlspecialchars($VISITOR_SIGNIN_PARAGRAPH);
            $data['VISITOR_CONTROL_PARAGRAPH'] = htmlspecialchars($VISITOR_CONTROL_PARAGRAPH);
            $data['VISITOR_CONTROL_PARAGRAPH_2'] = htmlspecialchars($VISITOR_CONTROL_PARAGRAPH_2);
        } else {
            $template_processor->setValue('VISITOR_SIGNIN_PARAGRAPH', htmlspecialchars($VISITOR_SIGNIN_PARAGRAPH));
            $template_processor->setValue('VISITOR_CONTROL_PARAGRAPH', htmlspecialchars($VISITOR_CONTROL_PARAGRAPH));
            $template_processor->setValue('VISITOR_CONTROL_PARAGRAPH_2', htmlspecialchars($VISITOR_CONTROL_PARAGRAPH_2));
        }
    }

    private function _dynamicGenerationPolicyVersioning($policy, $version_data, $location, $template_processor)
    {
        $template_processor->setValue('CLIENT_NAME', $version_data->CLIENT_NAME);
        $template_processor->setValue('CLIENT_ADDRESS', $version_data->CLIENT_ADDRESS);
        $template_processor->setValue('CLIENT_CITY', $version_data->CLIENT_CITY);
        $template_processor->setValue('CLIENT_STATE', $version_data->CLIENT_STATE);
        $template_processor->setValue('CLIENT_ZIP', $version_data->CLIENT_ZIP);
        $template_processor->setValue('CLIENT_PHONE_NUMBER', $version_data->CLIENT_PHONE_NUMBER);
        $location->logo = $version_data->COMPANY_LOGO;
        $logo_data = $this->_addCompanyLogoOnCoverPage($location);
        $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
        $this->_removeTempCompanyLogo($location, $logo_data['temp_file_path']);

        switch ($policy->code) {
            case 'AAP':
                $this->policy_version_AAP($version_data, $location, $template_processor);
                break;
            case 'BNP':
                $this->policy_version_BNP($version_data, $location, $template_processor);
                break;
            case 'BACP':
                $this->policy_version_BACP($version_data, $policy, $location, $template_processor);
                break;
            case 'EDDP':
                $this->policy_version_EDDP($version_data, $location, $template_processor);
                break;
            case 'EFP':
                $this->policy_version_EFP($version_data, $location, $template_processor);
                $this->policy_version_EFP($version_data, $location, $template_processor);
                break;
            case 'ETP':
                $this->policy_version_ETP($version_data, $location, $template_processor);
                break;
            case 'HCUAP':
                $this->policy_version_HCUAP($version_data, $location, $template_processor);
                break;
            case 'HNEP':
                $this->policy_version_HNEP($version_data, $location, $template_processor);
                break;
            case 'NPP':
                $this->policy_version_NPP($version_data, $location, $template_processor);
                break;
            case 'PMP':
                $this->policy_version_PMP($version_data, $location, $template_processor);
                break;
            case 'PCFP':
                $this->policy_version_PCFP($version_data, $location, $template_processor);
                break;
            case 'PHDRP':
                $this->policy_version_PHDRP($version_data, $location, $template_processor);
                break;
            case 'SAP':
                $this->policy_version_SAP($version_data, $location, $template_processor);
                break;
            case 'SATP':
                $this->policy_version_SATP($version_data, $location, $template_processor);
                break;
            case 'SRA':
                $this->policy_version_SRA($version_data, $location, $template_processor);
                break;
            case 'VCP':
                $this->policy_version_VCP($version_data, $location, $template_processor);
                break;
        }
    }

    private function _dynamicGenerationProcedureVersioning($policy, $version_data, $location, $template_processor)
    {
        $template_processor->setValue('CLIENT_NAME', $version_data->CLIENT_NAME);
        $template_processor->setValue('CLIENT_ADDRESS', $version_data->CLIENT_ADDRESS);
        $template_processor->setValue('CLIENT_CITY', $version_data->CLIENT_CITY);
        $template_processor->setValue('CLIENT_STATE', $version_data->CLIENT_STATE);
        $template_processor->setValue('CLIENT_ZIP', $version_data->CLIENT_ZIP);
        $template_processor->setValue('CLIENT_PHONE_NUMBER', $version_data->CLIENT_PHONE_NUMBER);
        $location->logo = $version_data->COMPANY_LOGO;
        $logo_data = $this->_addCompanyLogoOnCoverPage($location);
        $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);

        switch ($policy->code) {
            case 'AL':
                $this->procedure_version_AL($version_data, $location, $template_processor);
                break;
            case 'DRP':
                $this->procedure_version_DRP($version_data, $location, $template_processor);
                break;
            case 'MMPP':
                $this->procedure_version_MMPP($version_data, $location, $template_processor);
                break;
            case 'SPP':
                $this->procedure_version_SPP($version_data, $location, $template_processor);
                break;
        }
    }

    private function _dynamicGenerationFormVersioning($policy, $version_data, $location, $template_processor)
    {
        $template_processor->setValue('CLIENT_NAME_CAPITAL', $version_data->CLIENT_NAME_CAPITAL);
        $template_processor->setValue('CLIENT_NAME', $version_data->CLIENT_NAME);
        $template_processor->setValue('CLIENT_ADDRESS', $version_data->CLIENT_ADDRESS);
        $template_processor->setValue('CLIENT_CITY', $version_data->CLIENT_CITY);
        $template_processor->setValue('CLIENT_STATE', $version_data->CLIENT_STATE);
        $template_processor->setValue('CLIENT_ZIP', $version_data->CLIENT_ZIP);
        $template_processor->setValue('CLIENT_PHONE_NUMBER', $version_data->CLIENT_PHONE_NUMBER);
        $location->logo = $version_data->COMPANY_LOGO;
        $logo_data = $this->_addCompanyLogoOnCoverPage($location);
        $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);

        switch ($policy->code) {
            case 'PHDRF':
                $this->form_version_PHDRF($version_data, $location, $template_processor);
                break;
            case 'CFFEDOP':
                $this->form_version_CFFEDOP($version_data, $location, $template_processor);
                break;
            case 'AFFPR':
                $this->form_version_AFFPR($version_data, $location, $template_processor);
                break;
        }
    }

    private function form_version_PHDRF($version_data, $location, $template_processor)
    {
        $template_processor->setValue('REQUEST_TIME', $version_data->REQUEST_TIME);
    }

    private function form_version_CFFEDOP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('MEDICAL_PRACTICE', $version_data->MEDICAL_PRACTICE);
    }

    private function form_version_AFFPR($version_data, $location, $template_processor)
    {
        $template_processor->setValue('MEDICAL_PRACTICE', $version_data->MEDICAL_PRACTICE);
    }

    private function procedure_version_AL($version_data, $location, $template_processor)
    {
        $access_logs = $version_data->access_logs;
        $total = count($access_logs);
        $template_processor->cloneRow('ALOG_NAME', $total);
        for ($i = 0; $i < $total; $i++) {
            $template_processor->setValue('ALOG_NAME#'.($i + 1), htmlspecialchars($access_logs[$i]->name));
            $template_processor->setValue('ALOG_CNAME#'.($i + 1), htmlspecialchars($access_logs[$i]->company_name));
            $template_processor->setValue('ALOG_LOG_TYPE#'.($i + 1), htmlspecialchars(ucfirst($access_logs[$i]->log_type)));
            $template_processor->setValue('ALOG_DATE#'.($i + 1), htmlspecialchars(date('m/d/Y', strtotime($access_logs[$i]->date_log_in))));
            $template_processor->setValue('ALOG_TIME_IN#'.($i + 1), htmlspecialchars(date('h:i A', strtotime($access_logs[$i]->time_log_in))));
            $template_processor->setValue('ALOG_TIME_OUT#'.($i + 1), htmlspecialchars(date('h:i A', strtotime($access_logs[$i]->time_log_out))));
        }
    }

    private function procedure_version_DRP($version_data, $location, $template_processor)
    {

        if (count($version_data->LABORATORY_SAFETY_PREPAREDNESS_BLOCK) > 0) {
            $template_processor->cloneBlock('LABORATORY_SAFETY_PREPAREDNESS_BLOCK', count($version_data->LABORATORY_SAFETY_PREPAREDNESS_BLOCK), true, false, $version_data->LABORATORY_SAFETY_PREPAREDNESS_BLOCK);
        } else {
            $template_processor->cloneBlock('LABORATORY_SAFETY_PREPAREDNESS_BLOCK', 0, true, true);
        }

        if (count($version_data->EARTHQUAKE_PREPAREDNESS_BLOCK) > 0) {
            $template_processor->cloneBlock('EARTHQUAKE_PREPAREDNESS_BLOCK', count($version_data->EARTHQUAKE_PREPAREDNESS_BLOCK), true, false, $version_data->EARTHQUAKE_PREPAREDNESS_BLOCK);
        } else {
            $template_processor->cloneBlock('EARTHQUAKE_PREPAREDNESS_BLOCK', 0, true, true);
        }

        $vendor_manuals = $version_data->vendor_manuals;
        $total = count($vendor_manuals);
        if ($total > 0) {
            $template_processor->cloneRow('VENDOR_NAME', $total);
            for ($i = 0; $i < $total; $i++) {
                $template_processor->setValue('VENDOR_NAME#'.($i + 1), htmlspecialchars($vendor_manuals[$i]->vendor_name));
                $template_processor->setValue('VENDOR_PHONE_NUMBER#'.($i + 1), htmlspecialchars($vendor_manuals[$i]->vendor_phone));
            }
        } else {
            $template_processor->setValue('VENDOR_NAME', htmlspecialchars('Other Vendors'));
            $template_processor->setValue('VENDOR_PHONE_NUMBER', htmlspecialchars('N/A'));
        }

        $employee = $version_data->employee;
        $total = count($employee);
        if ($total > 0) {
            $template_processor->cloneRow('EMPLOYEE_NAME', $total);
            for ($i = 0; $i < $total; $i++) {
                $template_processor->setValue('EMPLOYEE_NAME#'.($i + 1), htmlspecialchars($employee[$i]->first_name.' '.$employee[$i]->last_name));
                $template_processor->setValue('EMPLOYEE_PHONE_NUMBER#'.($i + 1), htmlspecialchars($employee[$i]->phone_number));
                $template_processor->setValue('EMPLOYEE_BUSINESS_EMAIL#'.($i + 1), htmlspecialchars($employee[$i]->email));
            }
        } else {
            $template_processor->setValue('EMPLOYEE_NAME', '');
            $template_processor->setValue('EMPLOYEE_PHONE_NUMBER', '');
            $template_processor->setValue('EMPLOYEE_BUSINESS_EMAIL', '');
        }

        $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', $version_data->HIPAA_COMPLIANCE_OFFICER);
        $template_processor->setValue('PRACTICE_MANAGEMENT_SOFTWARE', $version_data->PRACTICE_MANAGEMENT_SOFTWARE);
        $template_processor->setValue('BACKUP_COMPANY', $version_data->BACKUP_COMPANY);
        $template_processor->setValue('BACKUP_LOCATION', $version_data->BACKUP_LOCATION);
        $template_processor->setValue('DATA_BACKUP_VENDOR', $version_data->DATA_BACKUP_VENDOR);
        $template_processor->setValue('DATA_BACKUP_VENDOR_PHONE_NUMBER', $version_data->DATA_BACKUP_VENDOR_PHONE_NUMBER);
        $template_processor->setValue('PROPERTY_MANAGER', $version_data->PROPERTY_MANAGER);
        $template_processor->setValue('PROPERTY_MANAGER_PHONE_NUMBER', $version_data->PROPERTY_MANAGER_PHONE_NUMBER);

        $template_processor->setValue('LOCAL_POLICE_DEPARTMENT', $version_data->LOCAL_POLICE_DEPARTMENT);
        $template_processor->setValue('LOCAL_POLICE DEPARTMENT_PHONE_NUMBER', $version_data->LOCAL_POLICE_DEPARTMENT_PHONE_NUMBER);
        $template_processor->setValue('LOCAL_FIRE_DEPARTMENT', $version_data->LOCAL_FIRE_DEPARTMENT);
        $template_processor->setValue('LOCAL_FIRE_DEPARTMENT_PHONE_NUMBER', $version_data->LOCAL_FIRE_DEPARTMENT_PHONE_NUMBER);

        $template_processor->setValue('DISASTER_RECOVERY_LEADS_LIST', $version_data->DISASTER_RECOVERY_LEADS_LIST);
        $template_processor->setValue('COMMUNICATION_TO_ALL_EMPLOYESS_LIST', $version_data->COMMUNICATION_TO_ALL_EMPLOYESS_LIST);
        $template_processor->setValue('COMMUNICATION_TO_AUTHORITIES_LIST', $version_data->COMMUNICATION_TO_AUTHORITIES_LIST);
        $template_processor->setValue('COMMUNICATION_TO_ALL_PARTNERS_VENDORS_LIST', $version_data->COMMUNICATION_TO_ALL_PARTNERS_VENDORS_LIST);
        $template_processor->setValue('COMMUNICATION_TO_MEDIA_LIST', $version_data->COMMUNICATION_TO_MEDIA_LIST);
        $template_processor->setValue('PARAGRAPH_COMMUNICATION_TO_MEDIA_LIST', $version_data->PARAGRAPH_COMMUNICATION_TO_MEDIA_LIST);
        $template_processor->setValue('COMMUNICATION_TO_ALL_PATIENTS_LIST', $version_data->COMMUNICATION_TO_ALL_PATIENTS_LIST);
        $template_processor->setValue('EARTHQUAKE_PREPAREDNESS_TITLE', $version_data->EARTHQUAKE_PREPAREDNESS_TITLE);
        $template_processor->setValue('LABORATORY_SAFETY_PREPAREDNESS_TITLE', $version_data->LABORATORY_SAFETY_PREPAREDNESS_TITLE);
        $template_processor->setValue('HURRICANE', $version_data->HURRICANE);
        $template_processor->setValue('HURRICANE_VUL', $version_data->HURRICANE_VUL);
        $template_processor->setValue('FLOOD', $version_data->FLOOD);
        $template_processor->setValue('FLOOD_VUL', $version_data->FLOOD_VUL);
        $template_processor->setValue('TORNADO', $version_data->TORNADO);
        $template_processor->setValue('TORNADO_VUL', $version_data->TORNADO_VUL);
        $template_processor->setValue('EARTHQUAKE', $version_data->EARTHQUAKE);
        $template_processor->setValue('EARTHQUAKE_VUL', $version_data->EARTHQUAKE_VUL);
        $template_processor->setValue('MALICIOUS_SOFTWARE', $version_data->MALICIOUS_SOFTWARE);
        $template_processor->setValue('MALICIOUS_SOFTWARE_VUL', $version_data->MALICIOUS_SOFTWARE_VUL);
        $template_processor->setValue('UTILITY_INTERRUPTION', $version_data->UTILITY_INTERRUPTION);
        $template_processor->setValue('UTILITY_INTERRUPTION_VUL', $version_data->UTILITY_INTERRUPTION_VUL);
        $template_processor->setValue('THEFT', $version_data->THEFT);
        $template_processor->setValue('THEFT_VUL', $version_data->THEFT_VUL);
        $template_processor->setValue('FIRE', $version_data->FIRE);
        $template_processor->setValue('FIRE_VUL', $version_data->FIRE_VUL);
        $template_processor->setValue('ROGUE_EMPLOYEE', $version_data->ROGUE_EMPLOYEE);
        $template_processor->setValue('ROGUE_EMPLOYEE_VUL', $version_data->ROGUE_EMPLOYEE_VUL);
        $template_processor->setValue('PUBLIC_HEALTH', $version_data->PUBLIC_HEALTH);
        $template_processor->setValue('PUBLIC_HEALTH_VUL', $version_data->PUBLIC_HEALTH_VUL);

        $template_processor->setValue('Q31S2_ANS', $version_data->Q31S2_ANS);
        $template_processor->setValue('Q31S2_STATEMENT', $version_data->Q31S2_STATEMENT);
        $template_processor->setValue('Q31S1_ANS', $version_data->Q31S1_ANS);

        $template_processor->setValue('Q20_STATEMENT', $version_data->Q20_STATEMENT);
        $template_processor->setValue('DISASTER_TEST_TIMING', $version_data->DISASTER_TEST_TIMING);
    }

    private function procedure_version_MMPP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('ALL_OTHER_MEDIA_PARAGRAPH', $version_data->ALL_OTHER_MEDIA_PARAGRAPH);
    }

    private function procedure_version_SPP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', $version_data->HIPAA_COMPLIANCE_OFFICER);
    }

    private function policy_version_AAP($version_data, $location, $template_processor)
    {

        $employee_list = (array) $version_data->employee_list;
        $total = count($employee_list);
        if ($total > 0) {
            $template_processor->cloneRow('EMPLOYEE_NAME', $total);
            for ($i = 0; $i < $total; $i++) {
                $template_processor->setValue('EMPLOYEE_NAME#'.($i + 1), htmlspecialchars($employee_list[$i]->first_name.' '.$employee_list[$i]->last_name));
                if ($employee_list[$i]->employee_access_right && $employee_list[$i]->employee_access_right != null) {
                    $template_processor->setValue('FULL_FACILITY_ACCESS#'.($i + 1), htmlspecialchars($employee_list[$i]->employee_access_right->full_facility_access));
                    $template_processor->setValue('KEY_TO_FACILITY#'.($i + 1), htmlspecialchars($employee_list[$i]->employee_access_right->facility_access_key));
                    $template_processor->setValue('FULL_SOFTWARE_ACCESS#'.($i + 1), htmlspecialchars($employee_list[$i]->employee_access_right->full_software_access));
                    $template_processor->setValue('SOFTWARE_ADMIN_PRIVILEGES#'.($i + 1), htmlspecialchars($employee_list[$i]->employee_access_right->software_admin_privilages));
                    $template_processor->setValue('FULL_NETWORK_ACCESS#'.($i + 1), htmlspecialchars($employee_list[$i]->employee_access_right->full_network_access));
                    $template_processor->setValue('NETWORK_ADMIN_PRIVILEGES#'.($i + 1), htmlspecialchars($employee_list[$i]->employee_access_right->network_admin_privilages));
                } else {
                    $template_processor->setValue('FULL_FACILITY_ACCESS#'.($i + 1), 'No');
                    $template_processor->setValue('KEY_TO_FACILITY#'.($i + 1), 'No');
                    $template_processor->setValue('FULL_SOFTWARE_ACCESS#'.($i + 1), 'No');
                    $template_processor->setValue('SOFTWARE_ADMIN_PRIVILEGES#'.($i + 1), 'No');
                    $template_processor->setValue('FULL_NETWORK_ACCESS#'.($i + 1), 'No');
                    $template_processor->setValue('NETWORK_ADMIN_PRIVILEGES#'.($i + 1), 'No');
                }
            }
        } else {
            $template_processor->setValue('EMPLOYEE_NAME', '');
            $template_processor->setValue('FULL_FACILITY_ACCESS', '');
            $template_processor->setValue('KEY_TO_FACILITY', '');
            $template_processor->setValue('FULL_SOFTWARE_ACCESS', '');
            $template_processor->setValue('SOFTWARE_ADMIN_PRIVILEGES', '');
            $template_processor->setValue('FULL_NETWORK_ACCESS', '');
            $template_processor->setValue('NETWORK_ADMIN_PRIVILEGES', '');
        }

        $template_processor->setValue('Q42_ANS', $version_data->Q42_ANS);
        $template_processor->setValue('Q43_ANS', $version_data->Q43_ANS);

        if (isset($version_data->students)) {
            $students = (array) $version_data->students;
            $student_total = count($students);
            if ($student_total > 0) {
                $template_processor->cloneRow('STUDENT_NAME', $student_total);
                for ($i = 0; $i < $student_total; $i++) {
                    $template_processor->setValue('STUDENT_NAME#'.($i + 1), htmlspecialchars($students[$i]->first_name.' '.$students[$i]->last_name));
                    $template_processor->setValue('CLASS_NAME#'.($i + 1), htmlspecialchars($students[$i]->student_class->class_name));
                    $template_processor->setValue('IMAGING_DEVICE_ACCESS#'.($i + 1), htmlspecialchars($students[$i]->imaging_device_access));
                    $template_processor->setValue('STUDENT_FULL_NETWORK_ACCESS#'.($i + 1), htmlspecialchars($students[$i]->full_network_access));
                    $template_processor->setValue('STUDENT_FULL_SOFTWARE_ACCESS#'.($i + 1), htmlspecialchars($students[$i]->full_software_access));
                }
            } else {
                $template_processor->setValue('STUDENT_NAME', '');
                $template_processor->setValue('CLASS_NAME', '');
                $template_processor->setValue('IMAGING_DEVICE_ACCESS', '');
                $template_processor->setValue('STUDENT_FULL_NETWORK_ACCESS', '');
                $template_processor->setValue('STUDENT_FULL_SOFTWARE_ACCESS', '');
            }
        }
    }

    private function policy_version_BNP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('BREACH_TIME', $version_data->BREACH_TIME);
        $template_processor->setValue('NOTICE_FORM', $version_data->NOTICE_FORM);
        $template_processor->setValue('SUBSTITUTE_THRESHOLD', $version_data->SUBSTITUTE_THRESHOLD);
        $template_processor->setValue('BREACH_CONTENT', $version_data->BREACH_CONTENT);
        $template_processor->setValue('BA_NOTICE_TIMING', $version_data->BA_NOTICE_TIMING);

        $template_processor->setValue('ADDITIONAL_STATE_NOTICE_TITLE', $version_data->ADDITIONAL_STATE_NOTICE_TITLE);
        $template_processor->setValue('ADDITIONAL_STATE_NOTICE', $version_data->ADDITIONAL_STATE_NOTICE);

        if (isset($version_data->STATE_NOTICE)) {
            $template_processor->setValue('STATE_NOTICE', $version_data->STATE_NOTICE);
        }
        if (isset($version_data->STATE_NOTICE_TIMING)) {
            $template_processor->setValue('STATE_NOTICE_TIMING', $version_data->STATE_NOTICE_TIMING);
        }
        if (isset($version_data->STATE_NOTICE_INFO)) {
            $template_processor->setValue('STATE_NOTICE_INFO', $version_data->STATE_NOTICE_INFO);
        }
        $template_processor->setValue('STATE', $version_data->STATE);
        $template_processor->setValue('CLIENT_NAME', $version_data->CLIENT_NAME);
    }

    private function policy_version_BACP($version_data, $policy, $location, $template_processor)
    {
        $business_associates = $version_data->business_associates;
        if (count($business_associates) > 0) {
            $template_processor->cloneRow('BUSINESS_ASSCOIATE', count($business_associates));
            foreach ($business_associates as $i => $ba) {
                $template_processor->setValue('BUSINESS_ASSCOIATE#'.($i + 1), htmlspecialchars($ba->name));
                $is_current = 'Incomplete';
                if ($ba->predefine_business_associates_id == null) {
                    if ($ba->business_associates_agreement && $ba->business_associates_agreement->signature === null && $ba->business_associates_agreement->agreement_link === null && $ba->business_associates_agreement->file_name === null) {
                        $is_current = 'Pending';
                    } elseif ($ba->business_associates_agreement && ($ba->business_associates_agreement->signature !== null || $ba->business_associates_agreement->agreement_link !== null || $ba->business_associates_agreement->file_name !== null)) {
                        $is_current = 'Complete';
                    }
                } else {
                    if ($ba->predefine_business_associative->agreement_type == 'predefined_dynamic_doc' && $ba->business_associates_agreement->file_name == null) {
                        $is_current = 'Pending';
                    } else {
                        $is_current = 'Complete';
                    }
                }
                if ($ba->expired_date === null) {
                    $exp_date = ' No Expiration ';
                } else {
                    $exp_date = new Carbon($ba->expired_date);
                    $exp_date = $exp_date->format('m/d/Y');
                }
                $template_processor->setValue('IS_CURRENT#'.($i + 1), $is_current);
                $template_processor->setValue('RENEWAL_DATE#'.($i + 1), $exp_date);
                $template_processor->setValue('BA_EMAIL#'.($i + 1), htmlspecialchars($ba->email));
                $template_processor->setValue('BA_PHONE#'.($i + 1), htmlspecialchars($ba->phone_number));
            }
        } else {
            $template_processor->setValue('BUSINESS_ASSCOIATE', '');
            $template_processor->setValue('BA_EMAIL', '');
            $template_processor->setValue('BA_PHONE', '');
            $template_processor->setValue('IS_CURRENT', '');
            $template_processor->setValue('RENEWAL_DATE', '');
        }
    }

    private function policy_version_EDDP($version_data, $location, $template_processor)
    {
        //logic for dynamic variable
    }

    private function policy_version_EFP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('PARAGRAPH_1', $version_data->PARAGRAPH_1);
        $template_processor->setValue('PARAGRAPH_2', $version_data->PARAGRAPH_2);
        $template_processor->setValue('COVER_SHEET', $version_data->COVER_SHEET);
        $template_processor->setValue('NUMBER_CONFIRMED', $version_data->NUMBER_CONFIRMED);
        $template_processor->setValue('RECEIPT_CONFIRMED', $version_data->RECEIPT_CONFIRMED);
        $template_processor->setValue('SECURE_AREA', $version_data->SECURE_AREA);
        $template_processor->setValue('EMAILING_INTERNAL', $version_data->EMAILING_INTERNAL);
    }

    private function policy_version_ETP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', $version_data->HIPAA_COMPLIANCE_OFFICER);
        $template_processor->setValue('TERMINATION_TIMEFRAME', $version_data->TERMINATION_TIMEFRAME);
    }

    private function policy_version_HCUAP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('STATE_RECORDS_TIMEFRAME', $version_data->STATE_RECORDS_TIMEFRAME);
        $template_processor->setValue('STATE', $version_data->STATE);
        $template_processor->setValue('CLIENT_NAME', $version_data->CLIENT_NAME);
    }

    private function policy_version_HNEP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', $version_data->HIPAA_COMPLIANCE_OFFICER);
    }

    private function policy_version_NPP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('SIGNUP_DATE', $version_data->SIGNUP_DATE);
    }

    private function policy_version_PMP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('RA_Q34_DEPENDANT', $version_data->RA_Q34_DEPENDANT);
        $template_processor->setValue('RA_Q21_DEPENDANT', $version_data->RA_Q21_DEPENDANT);
        $template_processor->setValue('NY_STATE_PARAGRAPH', $version_data->NY_STATE_PARAGRAPH);
        $template_processor->setValue('RA_Q26_DEPENDANT', $version_data->RA_Q26_DEPENDANT);
        $template_processor->setValue('COMPLEX_ANSWER', $version_data->COMPLEX_ANSWER);
        $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', $version_data->HIPAA_COMPLIANCE_OFFICER);
    }

    private function policy_version_PCFP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', $version_data->HIPAA_COMPLIANCE_OFFICER);
    }

    private function policy_version_PHDRP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('DYNAMIC_STATE_TEXT', $version_data->DYNAMIC_STATE_TEXT);
        $template_processor->setValue('REQUEST_TIME', $version_data->REQUEST_TIME);
        $template_processor->setValue('RA_Q71_SENTENCE', $version_data->RA_Q71_SENTENCE);
    }

    private function policy_version_SAP($version_data, $location, $template_processor)
    {
        $employee_list = $version_data->employee_list;
        if (count($employee_list) > 0) {
            $template_processor->cloneRow('EMPLOYEE_NAME', count($employee_list));
            foreach ($employee_list as $i => $emp) {
                $template_processor->setValue('EMPLOYEE_NAME#'.($i + 1), htmlspecialchars($emp->first_name.' '.$emp->last_name));
                if ($emp->employee_access_right) {
                    if ($emp->employee_access_right->security_code != null && $emp->employee_access_right->security_code != '') {
                        $template_processor->setValue('ALARM_CODE#'.($i + 1), htmlspecialchars($emp->employee_access_right->security_code));
                    } else {
                        $template_processor->setValue('ALARM_CODE#'.($i + 1), 'N/A');
                    }
                } else {
                    $template_processor->setValue('ALARM_CODE#'.($i + 1), 'N/A');
                }
            }
        } else {
            $template_processor->setValue('EMPLOYEE_NAME', '');
            $template_processor->setValue('ALARM_CODE', '');
        }
        $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', $version_data->HIPAA_COMPLIANCE_OFFICER);
        $template_processor->setValue('ALARM_SYSTEM_COMPANY_SENTENCE', $version_data->ALARM_SYSTEM_COMPANY_SENTENCE);
        $template_processor->setValue('RA_Q1S3_SENTENCE', $version_data->RA_Q1S3_SENTENCE);
    }

    private function policy_version_SATP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', $version_data->HIPAA_COMPLIANCE_OFFICER);
        $template_processor->setValue('DYNAMIC_STATE_TEXT', $version_data->DYNAMIC_STATE_TEXT);
    }

    private function policy_version_SRA($version_data, $location, $template_processor)
    {
        $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', $version_data->HIPAA_COMPLIANCE_OFFICER);
    }

    private function policy_version_VCP($version_data, $location, $template_processor)
    {
        $template_processor->setValue('VISITOR_SIGNIN_PARAGRAPH', $version_data->VISITOR_SIGNIN_PARAGRAPH);
        $template_processor->setValue('VISITOR_CONTROL_PARAGRAPH', $version_data->VISITOR_CONTROL_PARAGRAPH);
        $template_processor->setValue('VISITOR_CONTROL_PARAGRAPH_2', $version_data->VISITOR_CONTROL_PARAGRAPH_2);
    }
}
