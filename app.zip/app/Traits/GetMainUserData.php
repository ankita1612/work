<?php

namespace App\Traits;

use App\Models\User;
use Exception;
use Illuminate\Support\Facades\Log;

trait GetMainUserData
{
    /**
     * Process for get main user data
     *
     * @param  $html
     *
     * @throws \Exception
     */
    public function getMainAccountDetails()
    {
        try {
            if (! empty(auth()->guard('user')->user())) {
                $user_data = User::where('id', auth()->guard('user')->user()->id)->with(['reseller:id,logo,name,email'])->first();
            }
            if (! empty(auth()->guard('account_user')->user())) {
                $account_user_data = auth()->guard('account_user')->user();
                $user_data = User::where('id', $account_user_data['user_id'])->with(['reseller:id,logo,name,email'])->first();
            }

            return $user_data ?? null;
        } catch (Exception $e) {
            Log::error('GetMainUserData/getMainAccountDetails() => '.$e->getMessage());
            throw $e;
        }
    }
}
