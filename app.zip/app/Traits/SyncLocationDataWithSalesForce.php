<?php

namespace App\Traits;

use App\Http\Controllers\App\OngoingComplianceController;
use App\Http\Controllers\App\SecurityRiskAnalysisController;
use App\Models\BusinessAssociatesAgreement;
use App\Models\Location;
use App\Models\TrainingInvite;
use Carbon\Carbon;
use ChargeBee\ChargeBee\Models\Estimate;
use Exception;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

trait SyncLocationDataWithSalesForce
{
    use PricingHelper,ChargebeePlan;

    /**
     * sync with salesforce
     *
     *
     * @throws \Exception
     */
    public function SyncLocationDataWithSalesForce($location_id)
    {
        try {
            $data = [];
            if ($location_id != '') {
                $location = Location::where('id', $location_id)
                    ->whereNotNull('salesforce_unique_id')
                    ->with(['user' => function ($q) {
                        $q->withcount('businessAssociates');
                    }, 'businessAssociatesLocation','hipaaComplianceOfficer.hco'])
                    ->withCount(['openNotificationsWithoutLogin', 'trainingLocation', 'employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation','disasterRecoveryPlanModuleCompleted', 'contributorLocation', 'breachLog'])
                    ->withCount(['trainingLocation as open_training_count' => function ($query) {
                            $query->where('is_triggered', 1);
                        }
                    ])
                    ->withCount(['ongoingRiskAnalysisQuestion' => function ($query) {
                            $query->where('is_answered', 0);
                        }
                    ])
                    ->first();
                if ($location) {
                    $business_associates_agreement_count = BusinessAssociatesAgreement::whereIn('business_associates_id',$location->businessAssociatesLocation->pluck('business_associate_id')->toArray())
                        ->where( function($query){
                            $query->whereNotNull('signature')
                                ->orWhereNotNull('file_name')
                                ->orWhereNotNull('agreement_link');
                        })->count();
                    $is_main_location = ($location->user->locations[0]['id'] == $location_id) ? 1 : 0;
                    $subscription = $this->getSubscriptionDetails($location->user->chargebee_subscription_id);
                    $next_payment_price = 0;
                    $next_charge_price = 0;
                    $next_discount_price = 0;
                    $final_promocode_percentage = 0;
                    if($subscription['status'] == 'active' || $subscription['status'] == 'non_renewing'){
                        $renewal_estimate = Estimate::renewalEstimate(
                            $location->user->chargebee_subscription_id,
                            array(
                                'ignoreScheduledCancellation' => true,
                                'ignoreScheduledChanges' => true,
                            )
                        );
                        $renewal_estimate_response = $renewal_estimate->estimate();
                        if(isset($renewal_estimate_response->invoiceEstimate) && !empty($renewal_estimate_response->invoiceEstimate)){
                            $next_payment_price = $renewal_estimate_response->invoiceEstimate->total / 100;
                            $next_charge_price = $next_payment_price;
                            if($location->user->is_sra_user == 0){
                                $version = 'v2';
                                foreach ($subscription['item_tiers'] as $item_tiers) {
                                    if(str_contains($item_tiers['item_price_id'], 'Employees') && !empty($item_tiers['ending_unit']) && $item_tiers['ending_unit']== 5){
                                        $version = 'v1';
                                        break;
                                    }
                                }     
                                $chargebee_plan_ids = $this->getChargebeePlanId(strtolower(str_replace("-", "", $subscription['plan_type'])), $location->user->chargebe_addon_type, 'normal', $version);    
                                $transaction_fee = 0;
                                $transaction_fee_item_id = $chargebee_plan_ids['transaction_fee_item_id'];
                                foreach ($renewal_estimate_response->invoiceEstimate->lineItems as $key => $value) {
                                    if ($value->entityId == $transaction_fee_item_id) {
                                        $transaction_fee = $value->amount / 100;
                                    }
                                }
                                $next_payment_price = round($next_payment_price - $transaction_fee, 2);
                            }
                            
                            if (isset($renewal_estimate_response->invoiceEstimate->taxes) && !empty($renewal_estimate_response->invoiceEstimate->taxes)) {
                                foreach ($renewal_estimate_response->invoiceEstimate->taxes as $key => $value) {
                                    $next_sales_tax[] = array(
                                        'amount' => $value->amount / 100
                                    );
                                }
                            }
                            if (!empty($next_sales_tax)) {
                                $next_payment_price = round($next_payment_price - array_sum(array_column($next_sales_tax, 'amount')), 2);
                            }
                        
                            if (isset($renewal_estimate_response->invoiceEstimate->discounts[0]) && !empty($renewal_estimate_response->invoiceEstimate->discounts[0])) {
                                $next_discount_price = $renewal_estimate_response->invoiceEstimate->discounts[0]->amount / 100;
                                $final_promocode_percentage = $renewal_estimate_response->invoiceEstimate->discounts[0]->discountPercentage;
                            }
                            if ($next_discount_price > 0) {
                                $next_payment_price = round($next_payment_price + $next_discount_price, 2);
                            }
                        }
                    }
                    if($location->user['is_sra_user'] == 0){
                        $employee_limit = 0;
                        foreach($subscription['item_tiers']  as $item_tier){
                            if(str_contains($item_tier['item_price_id'], 'Employees') && !empty($item_tier['ending_unit']) && $item_tier['ending_unit'] == $subscription['employee_limit']){
                                $starting_unit = (int)$item_tier['starting_unit'];
                                if($starting_unit != 1){
                                    $starting_unit = $starting_unit + 1;
                                }
                                $employee_limit = $starting_unit.'-'.$item_tier['ending_unit'];
                            }
                        }
                    }
                    $last_calendar_year = Carbon::today()->subYear()->format("Y");
                    if($location['hipaaComplianceOfficer'] != null){
                        $hco_training__completed_invites_count = TrainingInvite::whereYear('completed_datetime', $last_calendar_year)
                            ->where('completed_attempt_id', '!=', null)
                            ->where('emp_user_acntuser_student_id', $location['hipaaComplianceOfficer']['hco_id'])
                            ->where('emp_user_acntuser_student_type',$location['hipaaComplianceOfficer']['hco_type'])->count();
                        $hco_training_last_completed_date = TrainingInvite::where('completed_attempt_id', '!=', null)
                            ->where('emp_user_acntuser_student_id', $location['hipaaComplianceOfficer']['hco_id'])
                            ->where('emp_user_acntuser_student_type', $location['hipaaComplianceOfficer']['hco_type'])
                            ->orderBy('completed_datetime', 'desc')
                            ->first();
                    }else{
                        $hco_training__completed_invites_count = 0;
                        $hco_training_last_completed_date = null;
                    }
                    
                    $sra = new SecurityRiskAnalysisController;
                    $ongoing_compliance = new OngoingComplianceController;
                    if($location->user->account_status=='FrozenByAdmin'){
                        $location->user->account_status = 'Frozen';
                    }
                    $data = [
                        'STATUS' => 'SUCCESS',
                        'MESSAGE' => 'User Found',
                        'DATA' => [
                            'salesforce_unique_id' => $location->salesforce_unique_id,
                            'First Name' => ($is_main_location == 1) ? $location->user->first_name : '',
                            'Last Name' => ($is_main_location == 1) ? $location->user->last_name : '',
                            'Primary Contact Name' => ($is_main_location == 1) ? ($location->user->first_name.' '.$location->user->last_name) : '',
                            'Location Nickname' =>  $location->location_nickname,
                            'Email' => ($is_main_location == 1) ? $location->user->email : '',
                            'Practice Name' => ($location->company_name != null) ? $location->company_name : '',
                            'Status' => ($is_main_location == 1) ? ($location->user['is_active'] == 1 ? 'ACTIVE' : 'INACTIVE') : '',
                            'Product Type' => ($location->user['is_sra_user'] == 1 ? 'SRA Only' : 'HIPAA CE'),
                            'Payment Freeze' => ($is_main_location == 1) ? (\Str::upper($location->user->account_status)) : '',
                            'Payment Type' => ($is_main_location == 1) ? ($subscription['plan_type'] == 'monthly' ? 'M' : ($subscription['plan_type'] == 'quarterly' ? 'Q' : ($subscription['plan_type'] == 'biannually' ? 'S' : 'Y'))) : '',
                            'Amount' => ($is_main_location == 1) ? $next_payment_price : '',
                            'Charge Amount' => ($is_main_location == 1) ? $next_charge_price : '',
                            'Locations' => ($is_main_location == 1) ? ((int)($subscription['location_limit'])) : '',
                            'SRA Complete' => ($location['sraModuleCompleted'] && $location['sraModuleCompleted']['is_completed'] == 1) ? strval(100) : strval($sra->getPercentageCount($location['id'])['percentage']),
                            'OG Complete' => strval($ongoing_compliance->getPercentageCount($location['id'])['percentage']),
                            'Notifications' => strval($location->open_notifications_without_login_count),
                            'Last Login' => ($location->user['lastLoginDetails']) ? Carbon::parse($location->user['lastLoginDetails']['created_at'])->format('Y-m-d') : '',
                            'Promo' => ($is_main_location == 1) ? (empty($subscription['coupon']) ? '' : $subscription['coupon']) : '',
                            'Employees' => ($is_main_location == 1 && $location->user['is_sra_user'] == 0) ? ($employee_limit) : '0',
                            'Training' => strval($location->training_location_count),
                            'BAAs' => strval($location->user->business_associates_count),
                            'HCO' => ($location['hipaaComplianceOfficer'] != null) ? $location['hipaaComplianceOfficer']['hco']['first_name'].' '.$location['hipaaComplianceOfficer']['hco']['last_name'] : '',
                            'HCO Email' => ($location['hipaaComplianceOfficer'] != null) ? $location['hipaaComplianceOfficer']['hco']['email'] : '',
                            'Sign Up Date' => ($is_main_location == 1) ? (Carbon::parse($location->user['created_at'])->format('Y-m-d')) : '',                            
                            'Phone' => ($location->phone_no != null) ? $location->phone_no : '',
                            'Main or Sub Location' => ($is_main_location == 1) ? 'Main Location' : 'Sub Location',
                            'Added Employees' => strval($location['employee_primary_work_location_count'] + $location['employee_secondary_work_location_count']),
                            'Disaster Recovery Plan Complete' => ($location['disaster_recovery_plan_module_completed_count'] && $location['disaster_recovery_plan_module_completed_count'] > 0) ? 'Yes' : 'No',
                            'HCO training Complete' => ($location['training_location_count'] > 0 && $hco_training__completed_invites_count && $hco_training__completed_invites_count > 0) ? 'Yes' : 'No',
                            'HCO Training Last Complete Date' => ($location['training_location_count'] > 0 && $hco_training_last_completed_date && $hco_training_last_completed_date != null) ? Carbon::parse($hco_training_last_completed_date['completed_datetime'])->format('Y-m-d')  : '',
                            'Open Training' => $location->open_training_count,
                            'Signed and Completed BAA' => $business_associates_agreement_count,
                            'Ongoing Questions' => $location->ongoing_risk_analysis_question_count,
                            'SRA Contributors' => strval($location->contributor_location_count),
                            'Breach Log' => strval($location->breach_log_count),
                            'Discount Percentage' => $final_promocode_percentage
                        ],
                    ];
                    // IF PRODUCTION CALL SF API TO SYNC DATA
                    if (Config::get('app.env') == 'production') {
                        $result_SF_sync = Http::withHeaders([
                            'Content-Type' => 'application/json',
                            'Cookie' => 'BrowserId=nCw0m7jZEe2IoOcYmxFzsA; CookieConsentPolicy=0:1; LSKey-c$CookieConsentPolicy=0:1',
                        ])->timeout(0)->post(Config::get('app.salesforce_url'), $data);
                        if ($result_SF_sync->successful() == true) {
                        } else {
                            Log::error('Sales Force Synching failed for location ID: '.$location_id);
                        }
                    }
                }
            }

            return $data;
        } catch (Exception $e) {
            Log::error('SyncLocationDataWithSalesForce/SyncLocationDataWithSalesForce() => '.json_encode([$location_id]));
            throw $e;
        }
    }   
}
