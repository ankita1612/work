<?php

namespace App\Traits;

use App\Models\Promocode;
use App\Models\User;
use App\Models\SraOnlyLocationLimitPrice;
use Avalara;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Exception;

trait PricingHelper
{
    use FileUpload;

    public function calculateTotalPrice($employee_pricing, $location_pricing)
    {
        try {
            $monthly_price = (int) $employee_pricing->price + (((int) $location_pricing->limit - 1) * (int) $location_pricing->price);
            $quarterly_price = $monthly_price * 3;
            $biannually_price = $monthly_price * 6;
            $yearly_price = ($monthly_price * 12) * 0.9; //includes 10% yearly discount

            return ['monthly_price' => $monthly_price, 'yearly_price' => $yearly_price, 'quarterly_price' => $quarterly_price, 'biannually_price' => $biannually_price];
        } catch (Exception $e) {
            Log::error('PricingHelper/calculateTotalPrice() => ' . $e->getMessage());
            Log::error('PricingHelper/calculateTotalPrice() => ' . json_encode([$employee_pricing, $location_pricing]));
            throw $e;
        }
    }

    public function checkPromoCode($promo_code, $is_flash = true)
    {
        try {
            $current_date = gmdate('Y-m-d');
            $promocode_data = Promocode::isActive()->where('promo_code', $promo_code)->first();
            if ($promocode_data) {
                if ($promocode_data->flash_sale_end_date && $promocode_data->flash_sale_end_date < $current_date && $is_flash == true) {
                    return '';
                } else {
                    return $promocode_data;
                }
            } else {
                return '';
            }
        } catch (Exception $e) {
            Log::error('PricingHelper/checkPromoCode() => ' . $e->getMessage());
            Log::error('PricingHelper/checkPromoCode() => ' . json_encode([$promo_code, $is_flash]));
            throw $e;
        }
    }

    public function commitAvalaraSalesTransaction($avalara_sales_tax_transaction_code)
    {
        try {
            $avalara_client = new Avalara\AvaTaxClient(Config::get('app.avalara_app_name'), Config::get('app.avalara_app_version'), Config::get('app.avalara_app_server'), Config::get('app.avalara_app_server_env'));
            $avalara_client->withSecurity(Config::get('app.avalara_app_api_username'), Config::get('app.avalara_app_api_pass'));
            $ping_status = $avalara_client->ping();
            if (isset($ping_status->authenticated) && $ping_status->authenticated == true) {
                try {
                    $commit_response = $avalara_client->commitTransaction(Config::get('app.avalara_app_company_code'), $avalara_sales_tax_transaction_code, Avalara\DocumentType::C_SALESINVOICE, null, ['commit' => true]);
                    if (isset($commit_response->id) && $commit_response->id != '') {
                        return $commit_response;
                    } else {
                        throw new \Exception(json_encode($commit_response));
                    }
                } catch (\Exception $e) {
                    Log::error('PricingHelperTrait : commitAvalaraSalesTransaction()'.'Avatax - commit - operation failed'.$e->getMessage());
                    Log::error('PricingHelper/commitAvalaraSalesTransaction() => ' . json_encode([$avalara_sales_tax_transaction_code]));
                    return '';
                }
            } else {
                Log::error('PricingHelperTrait : commitAvalaraSalesTransaction()'.'Avatax - commit - authentication failed');
                Log::error('PricingHelper/commitAvalaraSalesTransaction() => ' . json_encode([$avalara_sales_tax_transaction_code]));
                return '';
            }
        } catch (Exception $e) {
            Log::error('PricingHelper/commitAvalaraSalesTransaction() => ' . $e->getMessage());
            Log::error('PricingHelper/commitAvalaraSalesTransaction() => ' . json_encode([$avalara_sales_tax_transaction_code]));
            throw $e;
        }
    }

    public function getAvalaraSalesTax($state_code, $zip_code, $charge_price_before_sales_tax_amount, $email)
    {
        try {
            $avalara_client = new Avalara\AvaTaxClient(Config::get('app.avalara_app_name'), Config::get('app.avalara_app_version'), Config::get('app.avalara_app_server'), Config::get('app.avalara_app_server_env'));
            $avalara_client->withSecurity(Config::get('app.avalara_app_api_username'), Config::get('app.avalara_app_api_pass'));
            $ping_status = $avalara_client->ping();
            $avalara_sales_tax_percentage = 0;
            $avalara_sales_tax_amount = 0;
            $avalara_sales_tax_transaction_code = '';
            if (isset($ping_status->authenticated) && $ping_status->authenticated == true) {
                try {
                    $avalara_transaction_builder = new Avalara\TransactionBuilder($avalara_client, Config::get('app.avalara_app_company_code'), Avalara\DocumentType::C_SALESINVOICE, $email);
                    $avalara_response = $avalara_transaction_builder->withAddress(Config::get('app.avalara_app_address_type'), null, null, null, null, $state_code, $zip_code, Config::get('app.avalara_app_address_country'))
                        ->withLine($charge_price_before_sales_tax_amount, 1, Config::get('app.name'), null)
                        ->create();
                    if (isset($avalara_response->summary) && ! empty((array) $avalara_response->summary)) {
                        foreach ($avalara_response->summary as $key => $value) {
                            $avalara_sales_tax_percentage = $avalara_sales_tax_percentage + (float) $value->rate;
                            $avalara_sales_tax_amount = $avalara_sales_tax_amount + (float) $value->tax;
                        }
                        $avalara_sales_tax_transaction_code = $avalara_response->code;

                        return ['avalara_sales_tax_percentage' => round(($avalara_sales_tax_percentage * 100), 2), 'avalara_sales_tax_amount' => $avalara_sales_tax_amount, 'avalara_sales_tax_transaction_code' => $avalara_sales_tax_transaction_code];
                    } else {
                        throw new \Exception(json_encode($avalara_response));
                    }
                } catch (\Exception $e) {
                    Log::error('PricingHelperTrait : getAvalaraSalesTax()'.'Avatax - calculation - exception: '.$e->getMessage().' User :'.$email);
                    Log::error('PricingHelper/getAvalaraSalesTax() => ' . json_encode([$state_code, $zip_code, $charge_price_before_sales_tax_amount, $email]));
                    return ['avalara_sales_tax_percentage' => ($avalara_sales_tax_percentage * 100), 'avalara_sales_tax_amount' => $avalara_sales_tax_amount, 'avalara_sales_tax_transaction_code' => $avalara_sales_tax_transaction_code];
                }
            } else {
                Log::error('PricingHelperTrait : getAvalaraSalesTax()'.'Avatax - calculation - authentication failed User :'.$email);
                Log::error('PricingHelper/getAvalaraSalesTax() => ' . json_encode([$state_code, $zip_code, $charge_price_before_sales_tax_amount, $email]));
                return ['avalara_sales_tax_percentage' => ($avalara_sales_tax_percentage * 100), 'avalara_sales_tax_amount' => $avalara_sales_tax_amount, 'avalara_sales_tax_transaction_code' => $avalara_sales_tax_transaction_code];
            }
        } catch (Exception $e) {
            Log::error('PricingHelper/getAvalaraSalesTax() => ' . $e->getMessage());
            Log::error('PricingHelper/getAvalaraSalesTax() => ' . json_encode([$state_code, $zip_code, $charge_price_before_sales_tax_amount, $email]));
            throw $e;
        }
    }

    public function formatPrice($price)
    {
        try {
            return ($price == '0') ? '0.00' : number_format((float) $price, 2);
        } catch (Exception $e) {
            Log::error('PricingHelper/formatPrice() => ' . $e->getMessage());
            Log::error('PricingHelper/formatPrice() => ' . json_encode([$price]));
            throw $e;
        }
    }

    public function unFormatPrice($price)
    {
        try {
            return ($price == '0') ? '0' : filter_var($price, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        } catch (Exception $e) {
            Log::error('PricingHelper/unFormatPrice() => ' . $e->getMessage());
            Log::error('PricingHelper/unFormatPrice() => ' . json_encode([$price]));
            throw $e;
        }
    }

   public function getAutoRenewalDateForInvoice($signup_datetime, $payment_datetime)
    {
        try {
            $signup_datetime = Carbon::parse($signup_datetime);
            $payment_datetime = Carbon::parse($payment_datetime);
            $after_year_added = $signup_datetime->addYear();
            if ($payment_datetime->toDateString() >= $after_year_added->toDateString()) {
                $after_year_added = $this->getAutoRenewalDateForInvoice($after_year_added, $payment_datetime);
            }

            return $after_year_added;
        } catch (Exception $e) {
            Log::error('PricingHelper/getAutoRenewalDateForInvoice() => ' . $e->getMessage());
            Log::error('PricingHelper/getAutoRenewalDateForInvoice() => ' . json_encode([$signup_datetime, $payment_datetime]));
            throw $e;
        }
    }
    public function calculateTotalPriceForSRA($locations)
    {
        try {
            $sraonly_location_pricing = SraOnlyLocationLimitPrice::select('price')
                ->selectRaw('count(id) as size')
                ->groupBy('price')
                ->OrderBy('price', 'desc')
                ->get();
            
            if ($locations->limit <= 0) {
              return 0;
            }

            $total_price = 0;
            $remaining_loc = $locations->limit;

            foreach ($sraonly_location_pricing as $tier) {
                if ($remaining_loc > 0) {
                    $location_tier = min($remaining_loc, $tier['size']);
                    $total_price += $location_tier * $tier['price'];
                    $remaining_loc -= $location_tier;
                } else {
                    break;
                }
            }

            $monthly_price = $total_price; 
            $quarterly_price = $monthly_price * 3;
            $biannually_price = $monthly_price * 6;
            $yearly_price = $monthly_price * 12;
            return ['monthly_price' => $monthly_price, 'yearly_price' => $yearly_price, 'quarterly_price' => $quarterly_price, 'biannually_price' => $biannually_price];
        } catch (Exception $e) {
            Log::error('PricingHelper/calculateTotalPriceForSRA() => ' . $e->getMessage());
            Log::error('PricingHelper/calculateTotalPriceForSRA() => ' . json_encode([$locations]));
            throw $e;
        }
    }
}
