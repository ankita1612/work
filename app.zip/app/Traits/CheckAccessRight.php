<?php

namespace App\Traits;

use App\Models\AccountUserLocationAccess;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\User;
use Illuminate\Support\Facades\Log;

trait CheckAccessRight
{
    /**
     * Process for check access right
     *
     * @param  $html
     *
     * @throws \Exception
     */
    public function checkAccessRight($module_name, $location_id = 0)
    {
        try {
            $hco_not_access_module = ['upgrade', 'billing'];
            $user_not_access_module = ['upgrade', 'account_user', 'billing'];
            $sra_only_not_access_module = ['employee', 'student', 'training', 'disaster_recovery_plan', 'hipaa_log', 'businessAssociates', 'procedures_policies_forms', 'abyde_drive'];
            $user_data = [];
            if (! empty(auth()->guard('user')->user())) {
                $user_data = auth()->guard('user')->user();
                // For checking access SRA User module.
                if(in_array($module_name, $sra_only_not_access_module) && $user_data['is_sra_user'] == 1) {
                    return false;
                }
                if ($module_name == 'student' && $user_data['is_educational_account'] == 0) {
                    return false;
                    exit;
                }
                if ($location_id > 0) {
                    $location_count = Location::where('user_id', $user_data['id'])
                        ->where('id', $location_id)
                        ->select(['id'])
                        ->count();
                    if ($location_count > 0) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
            }
            if (! empty(auth()->guard('account_user')->user())) {
                $user_data = auth()->guard('account_user')->user();
                $main_user_data = User::where('id', $user_data['user_id'])->first();
                // For checking access SRA User module.
                if(in_array($module_name, $sra_only_not_access_module) && $main_user_data['is_sra_user'] == 1) {
                    return false;
                }
                if ($module_name == 'student' && $main_user_data['is_educational_account'] == 0) {
                    return false;
                    exit;
                }
                $is_hco = HipaaComplianceOfficer::where('hco_id', $user_data['id'])->where('hco_type', \App\Models\AccountUser::class)->count();
                if ($is_hco > 0) {
                    if (in_array($module_name, $hco_not_access_module)) {
                        return false;
                    } else {
                        if ($location_id > 0) {
                            $location_count = AccountUserLocationAccess::where('account_user_id', $user_data['id'])
                                ->where('location_id', $location_id)
                                ->select(['id'])
                                ->count();
                            if ($location_count > 0) {
                                return true;
                            } else {
                                return false;
                            }
                        } else {
                            return true;
                        }
                    }
                } else {
                    if (in_array($module_name, $user_not_access_module)) {
                        return false;
                    } else {
                        if ($location_id > 0) {
                            $location_count = AccountUserLocationAccess::where('account_user_id', $user_data['id'])
                                ->where('location_id', $location_id)
                                ->select(['id'])
                                ->count();
                            if ($location_count > 0) {
                                return true;
                            } else {
                                return false;
                            }
                        } else {
                            return true;
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('CheckAccessRight/CheckAccessRight() => '.$e->getMessage());
            Log::error('CheckAccessRight/CheckAccessRight() => '.json_encode([$module_name, $location_id]));
            throw $e;
        }
    }
}
