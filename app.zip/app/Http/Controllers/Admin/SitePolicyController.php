<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SitePolicy;
use App\Traits\ApiResponser;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class SitePolicyController extends Controller
{
    use ApiResponser, SendMail;

    /**
     * View page
     */
    public function showSitePolicy()
    {
        return view('admin.pages.sitepolicy.view');
    }

    /**
     * Add page
     */
    public function showSitePolicyAdd()
    {
        return view('admin.pages.sitepolicy.add');
    }

    /**
     * Edit page
     */
    public function showSitePolicyEdit($site_policy_id)
    {
        return view('admin.pages.sitepolicy.edit', compact('site_policy_id'));
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Site policy Add
     *
     * @return \Illuminate\Http\Response
     */
    public function addSitePolicy(Request $request)
    {
        $validator_rules = [
            'title' => 'required',
            'description' => 'required',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $input_fields = $request->all();
            $display_order = SitePolicy::max('display_order');
            $input_fields['display_order'] = $display_order ? $display_order + 1 : 1;
            $site_policies = SitePolicy::create($input_fields);

            return $this->success(Config::get('constants.ADMIN_PANEL.SITE_POLICIES.SITE_POLICIES_ADD'), 200, $site_policies);
        } catch (\Exception $e) {
            Log::error('SitePolicyController/addSitePolicy() => '.$e->getMessage());
            Log::error('SitePolicyController/addSitePolicy()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     *  Site policy List
     *
     * @return \Illuminate\Http\Response
     */
    public function getSitePolicyList(Request $request)
    {
        try {
            $site_policies_list = SitePolicy::query();
            if ($request->has('search') && $request['search'] != '') {
                $site_policies_list = $site_policies_list->where('title', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhere('display_order', 'LIKE', '%'.$request->input('search').'%');
            }
            if ($request->input('sort_column')) {
                $site_policies_list = $site_policies_list->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
            }
            $site_policies_list = $site_policies_list->paginate($request->input('selected_show_entry'))->onEachSide(1);

            return $this->success(Config::get('constants.SUCCESS'), 200, $site_policies_list);

        } catch (\Exception $e) {
            Log::error('SitePolicyController/getSitePolicyList() => '.$e->getMessage());
            Log::error('SitePolicyController/getSitePolicyList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Site Policy Detail
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getSitePolicyEditDetail($site_policy_id = '')
    {
        if (! $site_policy_id) {
            return $this->error(Config::get('constants.MISSING_ARG'), 200);
        }
        try {
            $site_policies = SitePolicy::findOrFail($site_policy_id);
            if ($site_policies) {
                return $this->success(Config::get('constants.ADMIN_PANEL.SITE_POLICIES.SITE_POLICIES_EDIT'), 200, $site_policies);
            } else {
                return $this->error(Config::get('constants.ADMIN_PANEL.SITE_POLICIES.SITE_POLICIES_NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('SitePolicyController/getSitePolicyEditDetail() => '.$e->getMessage());
            Log::error('SitePolicyController/getSitePolicyEditDetail()[data] => '.json_encode([$site_policy_id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.SITE_POLICIES.NOT_FOUND'), 200);
        }
    }

    /**
     * Site Policy Update
     *
     * @return \Illuminate\Http\Response
     */
    public function updateSitePolicy(Request $request)
    {

        $validator_rules = [
            'title' => 'required',
            'site_policy_id' => 'required',
            'description' => 'required',
            // 'display_order' => 'required|unique:App\Models\SitePolicy,display_order,'.$site_policy_id.',site_policy_id,deleted_at,NULL'
        ];
        $site_policy_id = $request->site_policy_id;
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $site_policies = SitePolicy::findOrFail($site_policy_id);
            $input_fields = $request->all();
            $site_policies->update($input_fields);

            return $this->success(Config::get('constants.ADMIN_PANEL.SITE_POLICIES.SITE_POLICIES_UPDATE'), 200, $site_policies);
        } catch (\Exception $e) {
            Log::error('SitePolicyController/updateSitePolicy() => '.$e->getMessage());
            Log::error('SitePolicyController/updateSitePolicy()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Site Policy Delete
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deleteSitePolicy($id)
    {
        try {
            $site_policies = SitePolicy::findOrFail($id);
            $site_policies->delete();

            return $this->success(Config::get('constants.ADMIN_PANEL.SITE_POLICIES.SITE_POLICIES_DELETE_SUCCESS'), 200, $site_policies);
        } catch (\Exception $e) {
            Log::error('SitePolicyController/deleteSitePolicy() => '.$e->getMessage());
            Log::error('SitePolicyController/deleteSitePolicy()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.SITE_POLICIES.SITE_POLICIES_DELETE_FAIL'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */

}
