<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\App\OngoingComplianceController;
use App\Http\Controllers\App\SecurityRiskAnalysisController;
use App\Http\Controllers\Controller;
use App\Models\Location;
use App\Models\LocationNotification;
use App\Models\ModuleCompletedStatus;
use App\Models\RiskAnalysisQuestion;
use App\Traits\ApiResponser;
use App\Traits\FileUpload;
use App\Traits\SyncLocationDataWithSalesForce;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class LocationController extends Controller
{
    use ApiResponser, FileUpload, SyncLocationDataWithSalesForce;

    /**
     * View page
     */
    public function showLocation($user_id)
    {
        return view('admin.pages.location.view', ['user_id' => $user_id]);
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get location list
     *
     * @return \Illuminate\Http\Response
     */
    public function getLocationList($user_id, Request $request)
    {
        try {
            $location_list = Location::with('user')->where('user_id', $user_id);

            if ($request->has('search') && $request['search'] != '') {
                $location_list = $location_list->where(function ($query) use ($request) {
                    $query->where('company_name', 'LIKE', '%'.$request->input('search').'%')
                        ->orWhere('location_nickname', 'LIKE', '%'.$request->input('search').'%');
                });
            }
            if ($request->input('sort_column')) {
                $location_list = $location_list->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
            }

            $location_list = $location_list->paginate($request->input('selected_show_entry'))->onEachSide(1);

            return $this->success(Config::get('constants.SUCCESS'), 200, $location_list);
        } catch (\Exception $e) {
            Log::error('LocationController/getLocationList() => '.$e->getMessage());
            Log::error('LocationController/getLocationList()[data] => '.json_encode($request->all()));
            Log::error('LocationController/getLocationList()[user_id] => '.json_encode([$user_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get location list
     *
     * @return \Illuminate\Http\Response
     */
    public function getLocationDetail($location_id)
    {
        try {
            $location_details = Location::with(['hipaaComplianceOfficer.hco', 'sraModuleCompleted'])
                ->withCount('openNotificationsWithoutLogin')
                ->withCount('businessAssociatesUser')
                ->find($location_id);
            if ($location_details) {
                $sra = new SecurityRiskAnalysisController;
                $ongoing_compliance = new OngoingComplianceController;
                $location_details['sra_percentage_count'] = ($location_details->sraModuleCompleted && $location_details->sraModuleCompleted->is_completed == 1) ? (object) ['percentage' => 100] : $sra->getPercentageCount($location_details->id);
                $location_details['ongoing_compliance_percentage_count'] = $ongoing_compliance->getPercentageCount($location_details->id);

                return $this->success(Config::get('constants.SUCCESS'), 200, $location_details);
            } else {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        } catch (\Exception $e) {
            Log::error('LocationController/getLocationDetail() => '.$e->getMessage());
            Log::error('LocationController/getLocationList()[data] => '.json_encode([$location_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Download pdf for scorecard
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadScorecard(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $location = Location::with(['user', 'state'])->find($request['location_id']);
            if (! is_null($location->logo)) {
                $location->logo = $this->getSignedURL('/company_logo/'.$location['user']['id'].'/'.$request['location_id'].'/original/'.$location->logo);
            }
            $ra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $request['location_id'],
                    'module' => 'risk_analysis',
                ]
            )->first();
            $file_name = preg_replace('/[^A-Za-z0-9\-\_]/', '', str_replace(' ', '_', trim($location['location_nickname']))).'-Security-Risk-Analysis-'.date('YmdHis').'.pdf';

            $data = RiskAnalysisQuestion::isActive()
                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                    $que->where(['location_id' => $location['id']]);
                })->with(
                    [
                        'RiskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                            return $que->where('location_id', $location['id'])
                                ->with('attemptedQuestionAnswer.answerContent', 'attemptedQuestionAnswer.answerContent.remindOptionDetail');
                        },
                        'riskAnalysisQuestionAnswerOptions',
                        'questionCategory',
                        'questionLawSection',
                        'riskAnalysisPreviousAttemptedQuestionAnswer' => function ($que) use ($location) {
                            return $que->where('location_id', $location['id'])
                                ->with('answerContent');
                        },
                    ]
                );
            $data = $data->orderBy('display_order', 'ASC')->get()->toArray();

            $question_list = [];

            foreach ($data as $key => $list) {
                $risk_level = '';
                $risk_levele_image = '';
                if ($list['question_answer_layout'] == 'radio') {
                    $answer = $list['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content'];
                    $score = $answer['score'];
                    switch ($score) {
                        case 1:
                            $risk_level = 'Very Low';
                            $risk_levele_image = 'very-low.png';
                            break;
                        case 2:
                        case 3:
                            $risk_level = 'Low';
                            $risk_levele_image = 'low.png';
                            break;
                        case 4:
                        case 5:
                        case 6:
                            $risk_level = 'Medium';
                            $risk_levele_image = 'medium.png';
                            break;
                        case 7:
                        case 8:
                            $risk_level = 'High';
                            $risk_levele_image = 'high.png';
                            break;
                        case 9:
                        case 10:
                            $risk_level = 'Very High';
                            $risk_levele_image = 'very-high.png';
                            break;
                    }
                    $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['risk_level'] = $risk_level;
                    $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['risk_level_image'] = $risk_levele_image;

                    $likelihood = $answer['likelihood'];
                    $likelihood_text = '';
                    switch ($likelihood) {
                        case 1:
                            $likelihood_text = 'Low';
                            break;
                        case 2:
                            $likelihood_text = 'Medium';
                            break;
                        case 3:
                            $likelihood_text = 'High';
                            break;
                    }
                    $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['likelihood_text'] = $likelihood_text;

                    $impact = $answer['impact'];
                    $impact_text = '';
                    switch ($impact) {
                        case 1:
                            $impact_text = 'Low';
                            break;
                        case 2:
                            $impact_text = 'Medium';
                            break;
                        case 3:
                            $impact_text = 'High';
                            break;
                    }
                    $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['impact_text'] = $impact_text;
                }
                if (isset($data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content'])) {
                    $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['remind_option_detail'] = isset($data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['remind_option_detail']) ? $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['remind_option_detail'] : null;
                }
                if (($list['question_code'] == 'Q75S3' || $list['question_code'] == 'Q75S4' || $list['question_code'] == 'Q75S5')) {
                    $ra = new SecurityRiskAnalysisController;
                    $str_to_replace = $ra->getDynamicString($request['location_id'], 'Q75');
                    $data[$key]['question'] = str_replace('{%IT_PROVIDER_QUESTION%}', $str_to_replace, $list['question']);
                }
                $final_data = $data[$key];
                if ($request->has('risk_level') && ! empty($request['risk_level'])) {
                    if (in_array($risk_level, $request['risk_level'])) {
                        $question_list[] = $final_data;
                    }
                    if (in_array('High', $request['risk_level'])) {
                        if ($risk_level === 'Very High') {
                            $question_list[] = $final_data;
                        }
                    }
                    if (in_array('Low', $request['risk_level'])) {
                        if ($risk_level === 'Very Low') {
                            $question_list[] = $final_data;
                        }
                    }
                } else {
                    $question_list[] = $final_data;
                }
            }
            $pdf_data = [
                'title' => $file_name,
                'location' => $location,
                'question_list' => $question_list,
                'sra_complete_details' => $ra_completed,
                'timezone' => $location->user->timezone,
            ];

            $pdf_data['completed_on'] = Carbon::now();
            $pdf = PDF::loadView('reports/scorecard', $pdf_data);
            $s3_certificate = '/SRAScorecard/'.$location->user->id.'/'.$pdf_data['title'];
            Storage::disk('s3')->put($s3_certificate, $pdf->output(), ['ContentType' => 'application/pdf']);
            $download_url = $this->getSignedURL($s3_certificate);

            return $this->success(Config::get('constants.SUCCESS'), 200, $download_url);
        } catch (\Exception $e) {
            Log::error('LocationController/downloadScorecard() => '.$e->getMessage());
            Log::error('LocationController/downloadScorecard()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get Notification
     *
     * @return \Illuminate\Http\Response
     */
    public function getNotification($location_id)
    {
        try {
            $notification_list = LocationNotification::where('location_id', $location_id)
                ->where('is_completed', 0)
                ->with(['notification'])
                ->orderBy('id', 'DESC')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $notification_list);
        } catch (\Exception $e) {
            Log::error('LocationController/getNotification() => '.$e->getMessage());
            Log::error('LocationController/getNotification()[data] => '.json_encode([$location_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * edit sales force id
     *
     * @return \Illuminate\Http\Response
     */
    public function editSalesForceId(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'salesforce_unique_id' => 'required|unique:App\Models\Location,salesforce_unique_id,'.$request->location_id.',id,deleted_at,NULL',
            ];
            $custom_message = [];
            $custom_message = [
                'salesforce_unique_id.unique' => 'Unique ID already assigned to another user!',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules, $custom_message);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $location = Location::where('id', $request['location_id'])->first();
            $location->update($input_fields);
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200, $location);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('LocationController/editSalesForceId() => '.$e->getMessage());
            Log::error('LocationController/editSalesForceId()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * sync with sales force
     *
     * @return \Illuminate\Http\Response
     */
    public function syncWithSalesForce($location_id)
    {
        try {
            if ($location_id == '') {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
            $location_id = base64_decode($location_id, true);
            $sync_sales_force_data = $this->SyncLocationDataWithSalesForce($location_id);

            return $this->success(Config::get('constants.ADMIN_PANEL.USER.USER_LOCATION_SALES_FORCE'), 200, $sync_sales_force_data);
        } catch (\Exception $e) {
            Log::error('LocationController/syncWithSalesForce() => '.$e->getMessage());
            Log::error('LocationController/syncWithSalesForce()[data] => '.json_encode([$location_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    /************************** */
    /*API methods - end
    /*************************** */
}
