<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\OngoingQuestion;
use App\Models\RiskAnalysisQuestion;
use App\Models\RiskAnalysisQuestionAnswerOption;
use App\Models\RiskAnalysisQuestionCategory;
use App\Models\RiskAnalysisQuestionLawSection;
use App\Models\RiskAnalysisRemindOption;
use App\Traits\ApiResponser;
use App\Traits\Notification;
use App\Traits\SendMail;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class SecurityRiskAnalysisController extends Controller
{
    use ApiResponser, Notification, SendMail;

    /**
     * View page
     */
    public function showSecurityRiskAnalysis()
    {
        return view('admin.pages.securityRiskAnalysis.view');
    }

    /**
     * Add page
     */
    public function showSecurityRiskAnalysisAdd()
    {
        return view('admin.pages.securityRiskAnalysis.add');
    }

    /**
     * Edit page
     */
    public function showSraQuestionEdit($sra_question_id)
    {
        return view('admin.pages.securityRiskAnalysis.edit', compact('sra_question_id'));
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Add SecurityRiskAnalysis
     *
     * @return \Illuminate\Http\Response
     */
    public function addSecurityRiskAnalysis(Request $request)
    {
        $validator_rules = [
            'question' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        DB::beginTransaction();
        try {
            $input_fields = $request->all();
            $data = $this->addQuestions($input_fields['question']);
            DB::commit();

            return $this->success(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.SRA_ADD'), 200, $data);
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/addSecurityRiskAnalysis() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/addSecurityRiskAnalysis()[data] => '.json_encode($request->all()));
            DB::rollback();
            if ($e->getCode() == 422) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, [$e->getMessage()]);
            }

            return $this->error(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.NOT_ADDED'), 200);
        }
    }

    /*
     * Recursion method to add questions, sub questions with answers
    */
    public function addQuestions($question, $level = 1, $parent_question_id = null, $parent_answer_id = null)
    {
        try {
            if (! empty($question)) {
                foreach ($question as $que) {
                    $validator_rules = [
                        'question_category_id' => 'required',
                        'question_law_section_id' => 'required',
                        'question_code' => 'required|unique:App\Models\RiskAnalysisQuestion,question_code,NULL,id ,deleted_at,NULL',
                        'question' => 'required',
                        'question_answer_layout' => 'required',
                        'display_order' => 'required|unique:App\Models\RiskAnalysisQuestion,display_order,NULL,id ,deleted_at,NULL',
                    ];
                    $validator_rules_messages = [
                        'question_code.unique' => 'The :attribute '.$que['question_code'].' has already been taken',
                        'display_order.unique' => 'The :attribute for question '.$que['question_code'].' has already been taken',
                    ];
                    if (isset($que['answers']) && ! empty($que['answers'])) {
                        $validator_rules['answers.*.answer_code'] = 'required';
                        $validator_rules['answers.*.answer'] = 'required';
                    }
                    $validator_check = Validator::make($que, $validator_rules, $validator_rules_messages);
                    if ($validator_check->fails()) {
                        //dd($validator_check->errors()->all());
                        $error_msg = $validator_check->errors()->all();
                        $message = implode(',', $error_msg);
                        throw new Exception($message, 422);
                    }
                    $input_fields = [
                        'question_category_id' => $que['question_category_id'],
                        'question_law_section_id' => $que['question_law_section_id'],
                        'question_code' => $que['question_code'],
                        'question' => $que['question'],
                        'question_answer_layout' => (isset($que['question_answer_layout']) && $que['question_answer_layout'] != '') ? $que['question_answer_layout'] : 'radio',
                        'display_order' => (isset($que['display_order']) && $que['display_order'] != '') ? $que['display_order'] : 0,
                        'parent_question_id' => isset($parent_question_id) ? $parent_question_id : null,
                        'parent_answer_id' => isset($parent_answer_id) ? $parent_answer_id : null,
                        'level' => $level,
                        'is_active' => 1,
                    ];

                    $added_question = RiskAnalysisQuestion::create($input_fields);
                    if (($que['question_answer_layout'] == 'text' || $que['question_answer_layout'] == 'checkbox') && (isset($que['education']) || isset($que['remind_months']) || isset($que['ongoing_question_id']))) {
                        $remindOptions = [
                            'education' => (isset($que['education']) && $que['education'] != '') ? $que['education'] : '',
                            'remind_month' => (isset($que['remind_months']) && $que['remind_months'] != '') ? $que['remind_months'] : null,
                            'ongoing_question_id' => (isset($que['ongoing_question_id']) && $que['ongoing_question_id'] != '') ? $que['ongoing_question_id'] : null,
                            'question_id' => $added_question['id'],
                        ];
                        RiskAnalysisRemindOption::create($remindOptions);
                    }
                    if (isset($que['answers']) && ! empty($que['answers'])) {
                        foreach ($que['answers'] as $key => $answer) {
                            $ans_arr = [
                                'answer_code' => $answer['answer_code'],
                                'answer' => $answer['answer'],
                                'score' => isset($answer['score']) ? $answer['score'] : 0,
                                'likelihood' => isset($answer['likelihood']) ? $answer['likelihood'] : 0,
                                'impact' => isset($answer['impact']) ? $answer['impact'] : 0,
                                'display_order' => isset($answer['display_order']) ? $answer['display_order'] : 0,
                                'is_active' => 1,
                            ];
                            $added_question['answers'] = $added_question->riskAnalysisQuestionAnswerOptions()->create($ans_arr);
                            if ($que['question_answer_layout'] == 'radio' && (isset($answer['education']) || isset($answer['remind_months']) || isset($answer['ongoing_question_id']))) {
                                $remindOptions = [
                                    'education' => (isset($answer['education']) && $answer['education'] != '') ? $answer['education'] : '',
                                    'remind_month' => (isset($answer['remind_months']) && $answer['remind_months'] != '') ? $answer['remind_months'] : null,
                                    'ongoing_question_id' => (isset($answer['ongoing_question_id']) && $answer['ongoing_question_id'] != '') ? $answer['ongoing_question_id'] : null,
                                    'answer_option_id' => $added_question['answers']['id'],
                                    'question_id' => $added_question['id'],
                                ];
                                RiskAnalysisRemindOption::create($remindOptions);
                            }
                            if (isset($answer['sub_questions'])) {
                                $this->addQuestions($answer['sub_questions'], ($level + 1), $added_question['id'], $added_question['answers']['id']);
                            }
                        }
                    }
                }

                return $added_question;
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    /**
     * SecurityRiskAnalysis List
     *
     * @return \Illuminate\Http\Response
     */
    public function getSecurityRiskAnalysisList(Request $request)
    {
        try {
            $security_risk_analysis_list = RiskAnalysisQuestion::join('risk_analysis_question_categories', 'risk_analysis_questions.question_category_id', '=', 'risk_analysis_question_categories.id')->leftJoin('risk_analysis_question_law_sections', 'risk_analysis_questions.question_law_section_id', '=', 'risk_analysis_question_law_sections.id')->select('risk_analysis_questions.*', 'risk_analysis_question_categories.category_title', 'risk_analysis_question_law_sections.title as law_section_title');

            if ($request->input('sub_question') != '') {
                $security_risk_analysis_list = $security_risk_analysis_list->where('risk_analysis_questions.parent_question_id', $request->input('sub_question'));
            } else {
                $security_risk_analysis_list = $security_risk_analysis_list->where('risk_analysis_questions.parent_question_id', null);
            }

            if ($request->has('search') && $request['search'] != '') {
                $security_risk_analysis_list = $security_risk_analysis_list->where(function ($query) use ($request) {
                    $query->where('category_title', 'LIKE', '%'.$request->input('search').'%')
                        ->orWhere('question_code', 'LIKE', '%'.$request->input('search').'%')
                        ->orWhere('question', 'LIKE', '%'.$request->input('search').'%');
                });
            }
            $security_risk_analysis_list->with(['parentQuestion', 'parentAnswer']);
            $security_risk_analysis_list->withCount(['childQuestion']);
            if ($request->input('sort_column') == 'question_category_id') {
                $security_risk_analysis_list = $security_risk_analysis_list->orderBy('category_title', $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
            } else {
                $security_risk_analysis_list = $security_risk_analysis_list->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
            }
            $security_risk_analysis_list = $security_risk_analysis_list->paginate($request->input('selected_show_entry'))->onEachSide(1);

            return $this->success(Config::get('constants.SUCCESS'), 200, $security_risk_analysis_list);
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/getSecurityRiskAnalysisList() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/getSecurityRiskAnalysisList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Get Security Risk analysis question detail
     *
     * @return \Illuminate\Http\Response
     */
    public function viewSraQuestionAnswerDetail(Request $request, $id = '')
    {
        if (! $id) {
            return $this->error(Config::get('constants.MISSING_ARG'), 200);
        }
        try {
            $sra_question_ans_detail = RiskAnalysisQuestion::with(['riskAnalysisQuestionAnswerOptions.remindOption.ongoingCode', 'remindOption.ongoingCode'])->find($id);
            if ($sra_question_ans_detail) {
                return $this->success(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.SRA_VIEW_QUESTION_ANS_DETAIL'), 200, $sra_question_ans_detail);
            } else {
                return $this->error(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/viewSraQuestionAnswerDetail() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/viewSraQuestionAnswerDetail()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.NOT_FOUND'), 200);
        }
    }

    /**
     * Get Security Risk analysis category
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function getSraCategoryList()
    {
        try {
            $get_category_list = RiskAnalysisQuestionCategory::all();

            return $this->success(Config::get('constants.SUCCESS'), 200, $get_category_list);
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/getSraCategoryList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * List all months
     *
     * @return \Illuminate\Http\Response
     */
    public function getSraMonthsList(Request $request)
    {
        try {
            $list = [];
            for ($i = 1; $i <= 12; $i++) {
                if ($i == 1) {
                    array_push($list, ['month_id' => $i, 'month_name' => $i.' Month']);
                } else {
                    array_push($list, ['month_id' => $i, 'month_name' => $i.' Months']);
                }
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/getSraMonthsList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * List all ongoing questions
     *
     * @return \Illuminate\Http\Response
     */
    public function getOngoingQuestionList(Request $request)
    {
        try {
            $list = OngoingQuestion::all();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/getOngoingQuestionList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * SRA Question Edit Detail
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getSraQuestionEditDetail($sra_question_id = '')
    {
        if (! $sra_question_id) {
            return $this->error(Config::get('constants.MISSING_ARG'), 200);
        }
        try {
            $sra_question_detail = RiskAnalysisQuestion::with([
                'riskAnalysisQuestionAnswerOptionNested',
                'remindOption',
            ])->where('id', $sra_question_id)->first();
            if ($sra_question_detail) {
                $result_object = new \stdClass;
                $this->transformQuestionData($sra_question_detail, $result_object);

                return $this->success(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.SRA_QUESTION_EDIT'), 200, $result_object);
            } else {
                return $this->error(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.SRA_QUESTION_NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/getSraQuestionEditDetail() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/getSraQuestionEditDetail()[data] => '.json_encode([$sra_question_id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.NOT_FOUND'), 200);
        }
    }

    private function transformQuestionData($sra_question_detail, &$result_object, $from = '')
    {
        $object_var = new \stdClass;
        $question_unique_id = 'que_'.$sra_question_detail->id.'_'.uniqid();
        $object_var->question_id = $sra_question_detail->id;
        $object_var->question_unique_id = $question_unique_id;
        $object_var->question_code = $sra_question_detail->question_code;
        $object_var->question = $sra_question_detail->question;
        $object_var->question_category_id = $sra_question_detail->question_category_id;
        $object_var->question_law_section_id = $sra_question_detail->question_law_section_id;
        $object_var->question_answer_layout = $sra_question_detail->question_answer_layout;
        $object_var->display_order = $sra_question_detail->display_order;
        $object_var->parent_question_id = ($sra_question_detail->parent_question_id) ? $sra_question_detail->parent_question_id : '';
        $object_var->parent_answer_id = ($sra_question_detail->parent_answer_id) ? $sra_question_detail->parent_answer_id : '';
        if (isset($sra_question_detail->remindOption) && isset($sra_question_detail->remindOption->question_id) && ! isset($sra_question_detail->remindOption->answer_option_id) && $sra_question_detail->question_answer_layout != 'radio') {
            $object_var->is_remind = true;
            $object_var->remind_months = $sra_question_detail->remindOption->remind_month;
            $object_var->ongoing_question_id = $sra_question_detail->remindOption->ongoing_question_id;
        } else {
            $object_var->is_remind = false;
            $object_var->remind_months = '';
            $object_var->ongoing_question_id = '';
        }
        if (count($sra_question_detail->riskAnalysisQuestionAnswerOptionNested) > 0) {
            foreach ($sra_question_detail->riskAnalysisQuestionAnswerOptionNested as $key => $value) {
                $temp_array = [];
                $answer_unique_id = 'ans_'.$value->id.'_'.uniqid();
                $temp_array['answer_id'] = $value['id'];
                $temp_array['answer_unique_id'] = $answer_unique_id;
                $temp_array['question_unique_id'] = $question_unique_id;
                $temp_array['answer_code'] = $value['answer_code'];
                $temp_array['answer'] = $value['answer'];
                if (isset($value['remindOption']) && isset($value['remindOption']->question_id) && isset($value['remindOption']->answer_option_id) && $sra_question_detail->question_answer_layout == 'radio') {
                    $temp_array['is_remind'] = ($value['remindOption']->remind_month && $value['remindOption']->ongoing_question_id) ? true : false;
                    $temp_array['remind_months'] = ($value['remindOption']->remind_month) ? $value['remindOption']->remind_month : '';
                    $temp_array['ongoing_question_id'] = ($value['remindOption']->ongoing_question_id) ? $value['remindOption']->ongoing_question_id : '';
                    $temp_array['education'] = ($value['remindOption']->education) ? $value['remindOption']->education : '';
                } else {
                    $temp_array['is_remind'] = false;
                    $temp_array['remind_months'] = '';
                    $temp_array['ongoing_question_id'] = '';
                    $temp_array['education'] = '';
                }
                if ($sra_question_detail->question_answer_layout == 'radio') {
                    $temp_array['score'] = $value['score'];
                    $temp_array['likelihood'] = $value['likelihood'];
                    $temp_array['impact'] = $value['impact'];
                } else {
                    $temp_array['score'] = '';
                    $temp_array['likelihood'] = '';
                    $temp_array['impact'] = '';
                }
                if (isset($value['subQuestionNested']) && count($value['subQuestionNested']) > 0) {
                    foreach ($value['subQuestionNested'] as $s_key => $s_value) {
                        $temp_array['sub_questions'][$s_key] = $this->transformQuestionData($s_value, $result_object, 'sub');
                    }
                } else {
                    $temp_array['sub_questions'] = [];
                }
                $object_var->answers[$key] = $temp_array;
            }
        } else {
            $object_var->answers = [];
        }
        if ($from == 'sub') {
            return $object_var;
        } else {
            $result_object = $object_var;
        }
    }

    /**
     * Edit security risk analysis question
     *
     * @return \Illuminate\Http\Response
     */
    public function updateSraQuestion(Request $request)
    {
        // dd($request->all());
        $validator_rules = [
            'question' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        DB::beginTransaction();
        try {
            $input_fields = $request->all();
            $data = $this->editQuestions($input_fields['question']);
            if (isset($data['success']) && $data['success'] == false) {
                DB::rollback();

                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $data['errors']);
            }
            DB::commit();

            return $this->success(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.SRA_EDITED'), 200);
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/updateSraQuestion() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/updateSraQuestion()[data] => '.json_encode($request->all()));
            DB::rollback();
            if ($e->getCode() == 422) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, [$e->getMessage()]);
            }

            return $this->error(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.NOT_EDITED'), 200);
        }
    }

    /*
     * Recursion method to edit questions, sub questions with answers
    */
    public function editQuestions($question, $level = 1, $parent_question_id = null, $parent_answer_id = null)
    {

        try {
            if (! empty($question)) {
                foreach ($question as $que) {
                    $validator_rules = [
                        'question_category_id' => 'required',
                        'question_law_section_id' => 'required',
                        'question_code' => 'required|unique:App\Models\RiskAnalysisQuestion,question_code,'.(isset($que['question_id']) ? $que['question_id'] : null).',id ,deleted_at,NULL',
                        'question' => 'required',
                        'question_answer_layout' => 'required',
                        'display_order' => 'required|unique:App\Models\RiskAnalysisQuestion,display_order,'.(isset($que['question_id']) ? $que['question_id'] : null).',question_id ,deleted_at,NULL',
                    ];
                    $validator_rules_messages = [
                        'question_code.unique' => 'The :attribute '.$que['question_code'].' has already been taken',
                    ];
                    if (isset($que['answers']) && ! empty($que['answers'])) {
                        $validator_rules['answers.*.answer_code'] = 'required';
                        $validator_rules['answers.*.answer'] = 'required';
                    }
                    $validator_check = Validator::make($que, $validator_rules, $validator_rules_messages);
                    if ($validator_check->fails()) {
                        $error_msg = $validator_check->errors()->all();
                        $message = implode(',', $error_msg);
                        throw new Exception($message, 422);
                    }

                    if (isset($que['question_id'])) {
                        $question = RiskAnalysisQuestion::findOrFail($que['question_id']);
                        $que['level'] = $level;
                        $edited_question = $question->update($que);
                        $all_answer = RiskAnalysisQuestionAnswerOption::where('question_id', $que['question_id'])->get();
                        foreach ($all_answer as $ans) {
                            if ($que['question_answer_layout'] == 'text') {
                                $ans->delete();
                            }
                        }
                        if ($que['question_answer_layout'] == 'text' || $que['question_answer_layout'] == 'checkbox') {

                            RiskAnalysisRemindOption::where('question_id', $que['question_id'])->delete();

                            // if (isset($que['remind_option_id'])) {
                            //     $remind_options = RiskAnalysisRemindOption::findOrFail($que['remind_option_id']);
                            //     $remindOptions = [
                            //         'education' => (isset($que['education']) && $que['education'] != '') ? $que['education'] : "",
                            //         'remind_month' => (isset($que['remind_month']) && $que['remind_month'] != '') ? $que['remind_month'] : NULL,
                            //         'ongoing_question_id' => (isset($que['ongoing_question_id']) && $que['ongoing_question_id'] != '') ? $que['ongoing_question_id'] : NULL,
                            //         'question_id' => $que['question_id']
                            //     ];
                            //     $remind_options->update($remindOptions);
                            // } else {
                            if (isset($que['education']) || isset($que['remind_months']) || isset($que['ongoing_question_id'])) {
                                $remindOptions = [
                                    'education' => (isset($que['education']) && $que['education'] != '') ? $que['education'] : '',
                                    'remind_month' => (isset($que['remind_months']) && $que['remind_months'] != '') ? $que['remind_months'] : null,
                                    'ongoing_question_id' => (isset($que['ongoing_question_id']) && $que['ongoing_question_id'] != '') ? $que['ongoing_question_id'] : null,
                                    'question_id' => $que['question_id'],
                                ];
                                RiskAnalysisRemindOption::create($remindOptions);
                            }
                            // }
                        } else {
                            RiskAnalysisRemindOption::where('question_id', $que['question_id'])->delete();
                        }
                    } else {
                        $input_fields = [
                            'question_category_id' => $que['question_category_id'],
                            'question_code' => $que['question_code'],
                            'question' => $que['question'],
                            'question_answer_layout' => (isset($que['question_answer_layout']) && $que['question_answer_layout'] != '') ? $que['question_answer_layout'] : 'radio',
                            'display_order' => (isset($que['display_order']) && $que['display_order'] != '') ? $que['display_order'] : 0,
                            'parent_question_id' => isset($parent_question_id) ? $parent_question_id : null,
                            'parent_answer_id' => isset($parent_answer_id) ? $parent_answer_id : null,
                            'level' => $level,
                            'is_active' => 1,
                            'question_law_section_id' => $que['question_law_section_id'],
                        ];
                        $question = RiskAnalysisQuestion::create($input_fields);
                        if (($que['question_answer_layout'] == 'text' || $que['question_answer_layout'] == 'checkbox') && (isset($que['education']) || isset($que['remind_months']) || isset($que['ongoing_question_id']))) {
                            $remindOptions = [
                                'education' => (isset($que['education']) && $que['education'] != '') ? $que['education'] : '',
                                'remind_month' => (isset($que['remind_months']) && $que['remind_months'] != '') ? $que['remind_months'] : null,
                                'ongoing_question_id' => (isset($que['ongoing_question_id']) && $que['ongoing_question_id'] != '') ? $que['ongoing_question_id'] : null,
                                'question_id' => $question['id'],
                            ];
                            RiskAnalysisRemindOption::create($remindOptions);
                        }
                    }

                    if ((isset($que['answers']) && ! empty($que['answers'])) && ($que['question_answer_layout'] == 'radio' || $que['question_answer_layout'] == 'checkbox')) {
                        foreach ($que['answers'] as $key => $ans) {
                            if (isset($ans['answer_id'])) {
                                $answer = RiskAnalysisQuestionAnswerOption::findOrFail($ans['answer_id']);
                                $edited_answer = $answer->update($ans);

                                $remind_options = RiskAnalysisRemindOption::where('question_id', $que['question_id'])->where('answer_option_id', $ans['answer_id'])->first();
                                if ($que['question_answer_layout'] == 'radio') {
                                    if ($remind_options) {
                                        if (isset($ans['education']) || isset($ans['remind_month']) || isset($ans['ongoing_question_id'])) {
                                            $remindOptions = [
                                                'education' => (isset($ans['education']) && $ans['education'] != '') ? $ans['education'] : '',
                                                'remind_month' => (isset($ans['remind_months']) && $ans['remind_months'] != '') ? $ans['remind_months'] : null,
                                                'ongoing_question_id' => (isset($ans['ongoing_question_id']) && $ans['ongoing_question_id'] != '') ? $ans['ongoing_question_id'] : null,
                                                'answer_option_id' => $ans['answer_id'],
                                                'question_id' => $que['question_id'],
                                            ];
                                            $remind_options->update($remindOptions);
                                        } else {
                                            $remind_options->delete();
                                        }
                                    } else {
                                        if (isset($ans['education']) || isset($ans['remind_month']) || isset($ans['ongoing_question_id'])) {
                                            $remindOptions = [
                                                'education' => (isset($ans['education']) && $ans['education'] != '') ? $ans['education'] : '',
                                                'remind_month' => (isset($ans['remind_months']) && $ans['remind_months'] != '') ? $ans['remind_months'] : null,
                                                'ongoing_question_id' => (isset($ans['ongoing_question_id']) && $ans['ongoing_question_id'] != '') ? $ans['ongoing_question_id'] : null,
                                                'answer_option_id' => $ans['answer_id'],
                                                'question_id' => $que['question_id'],
                                            ];
                                            RiskAnalysisRemindOption::create($remindOptions);
                                        }
                                    }
                                }
                            } else {
                                $ans_arr = [
                                    'answer_code' => $ans['answer_code'],
                                    'answer' => $ans['answer'],
                                    'score' => isset($ans['score']) ? $ans['score'] : 0,
                                    'likelihood' => isset($ans['likelihood']) ? $ans['likelihood'] : 0,
                                    'impact' => isset($ans['impact']) ? $ans['impact'] : 0,
                                    'display_order' => isset($answer['display_order']) ? $answer['display_order'] : 0,
                                ];
                                $answer = $question->riskAnalysisQuestionAnswerOptions()->create($ans_arr);
                                if ($que['question_answer_layout'] == 'radio' && (isset($ans['education']) || isset($ans['remind_month']) || isset($ans['ongoing_question_id']))) {
                                    $remindOptions = [
                                        'education' => (isset($ans['education']) && $ans['education'] != '') ? $ans['education'] : '',
                                        'remind_month' => (isset($ans['remind_months']) && $ans['remind_months'] != '') ? $ans['remind_months'] : null,
                                        'ongoing_question_id' => (isset($ans['ongoing_question_id']) && $ans['ongoing_question_id'] != '') ? $ans['ongoing_question_id'] : null,
                                        'answer_option_id' => $answer['id'],
                                        'question_id' => $question['id'],
                                    ];
                                    RiskAnalysisRemindOption::create($remindOptions);
                                }
                            }
                            if (isset($ans['sub_questions'])) {
                                $this->editQuestions($ans['sub_questions'], ($level + 1), $question['id'], $answer['id']);
                            }
                        }
                    }
                }

                return $question;
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    /**
     * SRA Question Answer Delete
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteSraQuestionAnswer(Request $request, $id = '')
    {
        if (! $id) {
            return $this->error(Config::get('constants.MISSING_ARG'), 200);
        }
        try {
            if ($request->has('type') && request('type') == 'answer') {
                $data = RiskAnalysisQuestionAnswerOption::where('id', $id)->first();
            } else {
                $data = RiskAnalysisQuestion::where('id', $id)->first();
            }
            if ($data) {
                $data->delete();
                if ($request->has('type') && request('type') == 'answer') {
                    return $this->success(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.SRA_ANSWER_DELETED'), 200, $data);
                } else {
                    return $this->success(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.SRA_QUESTION_DELETED'), 200);
                }
            } else {
                return $this->error(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/deleteSraQuestionAnswer() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/deleteSraQuestionAnswer()[data] => '.json_encode($request->all()));
            Log::error('SecurityRiskAnalysisController/deleteSraQuestionAnswer()[id] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.NOT_FOUND'), 200);
        }
    }

    /**
     * SRA Question Status Change
     */
    public function sraQuestionStatusChnage($id, $status = null)
    {
        if (! $id) {
            return $this->error(Config::get('constants.MISSING_ARG'), 200);
        }
        try {
            $question = RiskAnalysisQuestion::with('childQuestion')->find($id);
            if ($status == null) {
                $status = ($question->is_active == 1 ? 0 : 1);
            }
            if ($question->update([
                'is_active' => $status,
            ])) {
                if ($question->childQuestion()->exists() == 'true') {
                    foreach ($question->childQuestion as $subQuestion) {
                        $this->sraQuestionStatusChnage($subQuestion->id, $status);
                    }
                }

                return $this->success(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.SRA_QUESTION_STATUS_CHANGED'), 200, $question);
            } else {
                return $this->error(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.SRA_QUESTION_STATUS_CHANGED_FAILED'), 200);
            }
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/sraQuestionStatusChnage() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/sraQuestionStatusChnage()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.SECURITY_RISK_ANALYSIS.SRA_QUESTION_STATUS_CHANGED_FAILED'), 200);
        }
    }

    /**
     * Get law section list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getSraLawSectionList()
    {
        try {
            $get_law_section_list = RiskAnalysisQuestionLawSection::all();

            return $this->success(Config::get('constants.SUCCESS'), 200, $get_law_section_list);
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/getSraLawSectionList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
