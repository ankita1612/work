<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Promocode;
use App\Traits\ApiResponser;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class PromocodeController extends Controller
{
    use ApiResponser, SendMail;

    /**
     * View page
     */
    public function showPromocode()
    {
        return view('admin.pages.promocode.view');
    }

    /**
     * Add page
     */
    public function showPromocodeAdd()
    {
        return view('admin.pages.promocode.add');
    }

    /**
     * Edit page
     */
    public function showPromocodeEdit($promocode_id)
    {
        return view('admin.pages.promocode.edit', compact('promocode_id'));
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Promocode Add
     *
     * @return \Illuminate\Http\Response
     */
    public function addPromocode(Request $request)
    {
        $validator_rules = [
            'promo_code' => 'required',
            'discount_percentage' => 'required',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $input_fields = $request->all();
            $input_fields['is_active'] = 1;
            $promocode = Promocode::create($input_fields);

            return $this->success(Config::get('constants.ADMIN_PANEL.PROMOCODE.PROMOCODE_ADD'), 200, $promocode);
        } catch (\Exception $e) {
            Log::error('PromocodeController/addPromocode() => '.$e->getMessage());
            Log::error('PromocodeController/addPromocode()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     *  Promocode List
     *
     * @return \Illuminate\Http\Response
     */
    public function getPromocodeList(Request $request)
    {
        try {
            $promocodes_list = Promocode::query();
            if ($request->has('search') && $request['search'] != '') {
                $promocodes_list = $promocodes_list->where('promo_code', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhere('discount_percentage', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhere('user_type', 'LIKE', '%'.ucfirst($request->input('search')).'%');
            }
            if ($request->input('sort_column')) {
                $promocodes_list = $promocodes_list->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
            }
            $promocodes_list = $promocodes_list->paginate($request->input('selected_show_entry'))->onEachSide(1);

            return $this->success(Config::get('constants.SUCCESS'), 200, $promocodes_list);

        } catch (\Exception $e) {
            Log::error('PromocodeController/getPromocodeList() => '.$e->getMessage());
            Log::error('PromocodeController/getPromocodeList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Promocode Edit Detail
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getPromocodeEditDetail($promocode_id = '')
    {
        if (! $promocode_id) {
            return $this->error(Config::get('constants.MISSING_ARG'), 200);
        }
        try {
            $promocode = Promocode::findOrFail($promocode_id);
            if ($promocode) {
                return $this->success(Config::get('constants.ADMIN_PANEL.PROMOCODE.PROMOCODE_EDIT'), 200, $promocode);
            } else {
                return $this->error(Config::get('constants.ADMIN_PANEL.PROMOCODE.PROMOCODE_NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('PromocodeController/getPromocodeEditDetail() => '.$e->getMessage());
            Log::error('PromocodeController/getPromocodeEditDetail()[data] => '.json_encode([$promocode_id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.PROMOCODE.NOT_FOUND'), 200);
        }
    }

    /**
     * Promocode Update
     *
     * @return \Illuminate\Http\Response
     */
    public function updatePromocode(Request $request)
    {
        $promocode_id = $request->promocode_id;
        $validator_rules = [
            'promo_code' => 'required',
            'discount_percentage' => 'required',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $promocode = Promocode::findOrFail($promocode_id);
            $input_fields['promo_code'] = $request['promo_code'];
            $input_fields['is_active'] = ($request['is_active'] == true) ? 1 : 0;
            $input_fields['user_type'] = $request['user_type'];
            $promocode->update($input_fields);

            return $this->success(Config::get('constants.ADMIN_PANEL.PROMOCODE.PROMOCODE_UPDATE'), 200, $promocode);
        } catch (\Exception $e) {
            Log::error('PromocodeController/updatePromocode() => '.$e->getMessage());
            Log::error('PromocodeController/updatePromocode()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Promocode Delete
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deletePromocode($id)
    {
        try {
            $promocode = Promocode::findOrFail($id);
            $promocode->delete();

            return $this->success(Config::get('constants.ADMIN_PANEL.PROMOCODE.PROMOCODE_DELETE_SUCCESS'), 200, $promocode);
        } catch (\Exception $e) {
            Log::error('PromocodeController/deletePromocode() => '.$e->getMessage());
            Log::error('PromocodeController/deletePromocode()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.PROMOCODE.PROMOCODE_DELETE_FAIL'), 200);
        }
    }

    /**
     * Check unique promo code
     *
     * @return \Illuminate\Http\Response
     */
    public function checkUniquePromoCode(Request $request, $promo_code = '', $promocode_id = '')
    {
        try {
            if ($promo_code == '') {
                dd('Invalid parmas');
            }
            $promocode = Promocode::where('promo_code', $request['promo_code']);
            if ($promocode_id != '') {
                $promocode->where('id', '!=', $request['promocode_id']);
            }
            $promocode = $promocode->count();
            if ($promocode > 0) {
                return 'available';
            } else {
                return 'not_available';
            }
        } catch (\Exception $e) {
            Log::error('PromocodeController/checkUniquePromoCode() => '.$e->getMessage());
            Log::error('PromocodeController/checkUniquePromoCode()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */

}
