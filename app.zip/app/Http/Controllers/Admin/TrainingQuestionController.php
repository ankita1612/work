<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Training;
use App\Models\TrainingQuestion;
use App\Models\TrainingQuestionAnswer;
use App\Traits\ApiResponser;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class TrainingQuestionController extends Controller
{
    use ApiResponser, SendMail;

    /**
     * View page
     */
    public function showTrainingQuestion()
    {
        return view('admin.pages.trainingquestion.view');
    }

    /**
     * Add page
     */
    public function showTrainingQuestionAdd()
    {
        return view('admin.pages.trainingquestion.add');
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Training Question Add
     *
     * @return \Illuminate\Http\Response
     */
    public function addTrainingQuestion(Request $request)
    {
        $validator_rules = [
            'selected_training' => 'required',
            'question' => 'required',
            'options' => 'required|array',
            'is_training_question_answer_correct' => 'required',
            'display_order' => 'required',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $input_fields = $request->all();
            $input_fields['training_id'] = $input_fields['selected_training'];
            $input_fields['is_active'] = 1;
            $training_question = TrainingQuestion::create($input_fields);
            $question_option['training_question_id'] = $training_question['id'];
            $training_question_answer_data = [];
            foreach ($input_fields['options'] as $key => $option) {
                $question_option['answer'] = $option['question_option'];
                $question_option['is_correct_answer'] = $input_fields['is_training_question_answer_correct'] == $key ? 'yes' : 'no';
                $question_option['created_at'] = Carbon::now();
                $question_option['updated_at'] = Carbon::now();
                $training_question_answer_data[] = $question_option;
            }
            TrainingQuestionAnswer::insert($training_question_answer_data);

            return $this->success(Config::get('constants.ADMIN_PANEL.TRAINING_QUESTION.TRAINING_QUESTION_ADD'), 200);
        } catch (\Exception $e) {
            Log::error('TrainingQuestionController/addTrainingQuestion() => '.$e->getMessage());
            Log::error('TrainingQuestionController/addTrainingQuestion()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     *  Training Question List
     *
     * @return \Illuminate\Http\Response
     */
    public function getTrainingQuestionList(Request $request)
    {
        try {
            $training_question_list = TrainingQuestion::query();
            $training_question_list = $training_question_list->with(['training', 'trainingQuestionAnswer', 'trainingQuestionAnswerCorrect']);

            if ($request->has('search') && $request['search'] != '') {
                if ($request->input('selected_training') != null) {
                    $training_question_list = $training_question_list
                        ->where('training_id', $request->input('selected_training'))
                        ->where(function ($result) use ($request) {
                            $result->where('question', 'LIKE', '%'.$request->input('search').'%');
                            $result->orWhere('training_questions.display_order', 'LIKE', '%'.$request->input('search').'%');
                            $result->orwhereHas('training', function (Builder $query) use ($request) {
                                $query->where('title', 'like', '%'.$request->input('search').'%');
                            });
                            $result->orwhereHas('trainingQuestionAnswerCorrect', function (Builder $query) use ($request) {
                                $query->where('answer', 'like', '%'.$request->input('search').'%');
                            });
                        });
                } else {
                    $training_question_list = $training_question_list->where('question', 'LIKE', '%'.$request->input('search').'%')
                        ->orWhere('training_questions.display_order', 'LIKE', '%'.$request->input('search').'%')
                        ->orwhereHas('training', function (Builder $query) use ($request) {
                            $query->where('title', 'like', '%'.$request->input('search').'%');
                        })
                        ->orwhereHas('trainingQuestionAnswerCorrect', function (Builder $query) use ($request) {
                            $query->where('answer', 'like', '%'.$request->input('search').'%');
                        });
                }
            }
            if ($request->input('selected_training') != null) {
                $training_question_list = $training_question_list->where('training_id', $request->input('selected_training'));
            }

            if ($request->input('sort_column') == 'answer') {
                $training_question_list = $training_question_list->join('training_question_answers', 'training_questions.id', '=', 'training_question_answers.training_question_id')
                    ->where('training_question_answers.is_correct_answer', '=', 'yes')
                    ->select('training_question_answers.*', 'training_questions.*')
                    ->orderBy('training_question_answers.answer', $request->input('sort_order'))
                    ->orderBy('training_question_answers.id', $request->input('sort_order'));
            } 
            else if ($request->input('sort_column') == 'title') {
                $training_question_list = $training_question_list->join('trainings', 'training_questions.training_id', '=', 'trainings.id')                   
                    ->select('trainings.*', 'training_questions.*')
                    ->orderBy('trainings.title', $request->input('sort_order'))
                    ->orderBy('trainings.id', $request->input('sort_order'));
            } 
            else {
                $training_question_list = $training_question_list->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
            }

            $training_question_list = $training_question_list->paginate($request->input('selected_show_entry'));

            return $this->success(Config::get('constants.SUCCESS'), 200, $training_question_list);
        } catch (\Exception $e) {
            Log::error('TrainingQuestionController/getTrainingQuestionList() => '.$e->getMessage());
            Log::error('TrainingQuestionController/getTrainingQuestionList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Training Question Delete
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deleteTrainingQuestion($id)
    {
        try {
            $training_question = TrainingQuestion::findOrFail($id);
            $training_question->delete();

            return $this->success(Config::get('constants.ADMIN_PANEL.TRAINING_QUESTION.TRAINING_QUESTION_DELETE_SUCCESS'), 200, $training_question);
        } catch (\Exception $e) {
            Log::error('TrainingQuestionController/deleteTrainingQuestion() => '.$e->getMessage());
            Log::error('TrainingQuestionController/deleteTrainingQuestion()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.TRAINING_QUESTION.TRAINING_QUESTION_DELETE_FAIL'), 200);
        }
    }

    /**
     * Change training question status
     *
     * @return \Illuminate\Http\Response
     */
    public function trainingQuestionStatusChnage(Request $request, $id = '')
    {
        if (! $id) {
            return $this->error(Config::get('constants.MISSING_ARG'), 200);
        }
        try {
            $training_question = TrainingQuestion::find($id);
            if ($training_question->update([
                'is_active' => ($training_question->is_active == 1 ? 0 : 1),
            ])) {
                return $this->success(Config::get('constants.ADMIN_PANEL.TRAINING_QUESTION.TRAINING_QUESTION_STATUS_CHANGED'), 200, $training_question);
            } else {
                return $this->error(Config::get('constants.ADMIN_PANEL.TRAINING_QUESTION.TRAINING_QUESTION_STATUS_CHANGED_FAILED'), 200);
            }
        } catch (\Exception $e) {
            Log::error('TrainingQuestionController/trainingQuestionStatusChnage() => '.$e->getMessage());
            Log::error('TrainingQuestionController/trainingQuestionStatusChnage()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.TRAINING_QUESTION.TRAINING_QUESTION_STATUS_CHANGED_FAILED'), 200);
        }
    }

    /**
     * Check unique display order
     *
     * @return \Illuminate\Http\Response
     */
    public function checkUniqueDisplayOrder(Request $request, $display_order = '', $training_question_id = '')
    {
        try {
            if ($display_order == '') {
                dd('Invalid parmas');
            }
            $training_question_do = TrainingQuestion::where('training_id', $training_question_id);
            if ($training_question_id != '') {
                $training_question_do->where('display_order', '=', $display_order);
            }
            $og_question = $training_question_do->count();
            if ($og_question > 0) {
                return 'available';
            } else {
                return 'not_available';
            }
        } catch (\Exception $e) {
            Log::error('TrainingQuestionController/checkUniqueDisplayOrder() => '.$e->getMessage());
            Log::error('TrainingQuestionController/checkUniqueDisplayOrder()[data] => '.json_encode([$display_order, $training_question_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Get Training Video Title List
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function getTrainingVideoTitleList()
    {
        try {
            $get_training_vidoe_title_list = Training::select('id', 'title')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $get_training_vidoe_title_list);
        } catch (\Exception $e) {
            Log::error('TrainingQuestionController/getTrainingVideoTitleList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Training Question Answer Detail
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function showTrainingQuestionDetail($id)
    {
        try {
            $training_question_answer = TrainingQuestionAnswer::where('training_question_id', $id)->get();

            return $this->success(Config::get('constants.ADMIN_PANEL.TRAINING_QUESTION.TRAINING_QUESTION_DETAIL_SHOW'), 200, $training_question_answer);
        } catch (\Exception $e) {
            Log::error('TrainingQuestionController/showTrainingQuestionDetail() => '.$e->getMessage());
            Log::error('TrainingQuestionController/showTrainingQuestionDetail()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.TRAINING_QUESTION.NOT_FOUND'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
