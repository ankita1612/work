<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Traits\ApiResponser;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    use ApiResponser, SendMail;

    /**
     * Login page
     *
     * @return \Illuminate\Http\Response
     */
    public function showLogin()
    {
        if (Auth::guard('admin')->check()) {
            return redirect()->route('admin_dashboard');
        }

        return view('admin.pages.login');
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     *Admin login
     *
     * @return \Illuminate\Http\Response
     */
    public function doLogin(Request $request)
    {
        $validator_rules = [
            'email' => 'required|email',
            'password' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $admin = Admin::where('email', $request->email)->first();
            if ($admin) {
                if (! $admin->is_active) {
                    return $this->error(Config::get('constants.ADMIN_PANEL.ADMIN.INACTIVE'), 200);
                } elseif (Auth::guard('admin')->attempt($request->all())) {
                    return $this->success(Config::get('constants.ADMIN_PANEL.ADMIN.ADMIN_LOGIN_SUCCESS'), 200, $admin);
                }
            }

            return $this->error(Config::get('constants.ADMIN_PANEL.ADMIN.ADMIN_LOGIN_FAIL'), 200);
        } catch (\Exception $e) {
            Log::error('AuthController/doLogin() => '.$e->getMessage());
            Log::error('AuthController/doLogin()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
