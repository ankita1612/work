<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\OngoingQuestion;
use App\Models\RiskAnalysisRemindOption;
use App\Traits\ApiResponser;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class OngoingQuestionController extends Controller
{
    use ApiResponser, SendMail;

    /**
     * View page
     */
    public function showOnGoingQuestion()
    {
        return view('admin.pages.ongoingquestion.view');
    }

    /**
     * Add page
     */
    public function showOnGoingQuestionAdd()
    {
        return view('admin.pages.ongoingquestion.add');
    }

    /**
     * Edit page
     */
    public function showOnGoingQuestionEdit($ongoingquestion_id)
    {
        return view('admin.pages.ongoingquestion.edit', compact('ongoingquestion_id'));
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * OnGoing Question Add
     *
     * @return \Illuminate\Http\Response
     */
    public function addOnGoingQuestion(Request $request)
    {
        $validator_rules = [
            'question_code' => 'required',
            'question' => 'required',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $input_fields = $request->all();
            $input_fields['is_active'] = 1;
            $ongoingquestion = OngoingQuestion::create($input_fields);

            return $this->success(Config::get('constants.ADMIN_PANEL.ONGOING_QUESTION.ONGOING_QUESTION_ADD'), 200, $ongoingquestion);
        } catch (\Exception $e) {
            Log::error('OngoingQuestionController/addOnGoingQuestion() => '.$e->getMessage());
            Log::error('OngoingQuestionController/addOnGoingQuestion()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     *  OnGoing Question List
     *
     * @return \Illuminate\Http\Response
     */
    public function getOnGoingQuestionList(Request $request)
    {
        try {
            $ongoingquestion_list = OngoingQuestion::query();
            if ($request->has('search') && $request['search'] != '') {
                $ongoingquestion_list = $ongoingquestion_list->where('question_code', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhere('question', 'LIKE', '%'.$request->input('search').'%');
            }
            if ($request->input('sort_column')) {
                $ongoingquestion_list = $ongoingquestion_list->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
            }
            $ongoingquestion_list = $ongoingquestion_list->paginate($request->input('selected_show_entry'))->onEachSide(1);

            return $this->success(Config::get('constants.SUCCESS'), 200, $ongoingquestion_list);
        } catch (\Exception $e) {
            Log::error('OngoingQuestionController/getOnGoingQuestionList() => '.$e->getMessage());
            Log::error('OngoingQuestionController/getOnGoingQuestionList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * OnGoing Question Detail
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getOnGoingQuestionEditDetail($ongoingquestion_id = '')
    {
        if (! $ongoingquestion_id) {
            return $this->error(Config::get('constants.MISSING_ARG'), 200);
        }
        try {
            $ongoingquestion = OngoingQuestion::findOrFail($ongoingquestion_id);
            if ($ongoingquestion) {
                return $this->success(Config::get('constants.ADMIN_PANEL.ONGOING_QUESTION.ONGOING_QUESTION_EDIT'), 200, $ongoingquestion);
            } else {
                return $this->error(Config::get('constants.ADMIN_PANEL.ONGOING_QUESTION.ONGOING_QUESTION_NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('OngoingQuestionController/getOnGoingQuestionEditDetail() => '.$e->getMessage());
            Log::error('OngoingQuestionController/getOnGoingQuestionEditDetail()[data] => '.json_encode([$ongoingquestion_id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.ONGOING_QUESTION.NOT_FOUND'), 200);
        }
    }

    /**
     * OnGoing Question Update
     *
     * @return \Illuminate\Http\Response
     */
    public function updateOnGoingQuestion(Request $request)
    {
        $ongoingquestion_id = $request->ongoingquestion_id;
        $validator_rules = [
            'question_code' => 'required',
            'question' => 'required',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $ongoingquestion = OngoingQuestion::findOrFail($ongoingquestion_id);
            $input_fields = $request->all();
            $input_fields['is_active'] = ($input_fields['is_active'] == true) ? 1 : 0;
            $ongoingquestion->update($input_fields);

            return $this->success(Config::get('constants.ADMIN_PANEL.ONGOING_QUESTION.ONGOING_QUESTION_UPDATE'), 200, $ongoingquestion);
        } catch (\Exception $e) {
            Log::error('OngoingQuestionController/updateOnGoingQuestion() => '.$e->getMessage());
            Log::error('OngoingQuestionController/updateOnGoingQuestion()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * OnGoing Question Delete
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deleteOnGoingQuestion($id)
    {
        try {
            $ongoingquestion = OngoingQuestion::findOrFail($id);
            if (RiskAnalysisRemindOption::where('ongoing_question_id', $id)->first()) {
                return $this->error(Config::get('constants.ADMIN_PANEL.ONGOING_QUESTION.ONGOING_QUESTION_NOT_DELETE'), 200, $ongoingquestion);
            } else {
                $ongoingquestion->delete();

                return $this->success(Config::get('constants.ADMIN_PANEL.ONGOING_QUESTION.ONGOING_QUESTION_DELETE_SUCCESS'), 200, $ongoingquestion);
            }
        } catch (\Exception $e) {
            Log::error('OngoingQuestionController/deleteOnGoingQuestion() => '.$e->getMessage());
            Log::error('OngoingQuestionController/deleteOnGoingQuestion()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.ONGOING_QUESTION.ONGOING_QUESTION_DELETE_FAIL'), 200);
        }
    }

    /**
     * Check unique code
     *
     * @return \Illuminate\Http\Response
     */
    public function checkUniqueCode(Request $request, $question_code = '', $question_id = '')
    {
        try {
            if ($question_code == '') {
                dd('Invalid parmas');
            }
            $og_question = OngoingQuestion::where('question_code', $request['question_code']);
            if ($question_id != '') {
                $og_question->where('id', '!=', $request['question_id']);
            }
            $og_question = $og_question->count();
            if ($og_question > 0) {
                return 'available';
            } else {
                return 'not_available';
            }
        } catch (\Exception $e) {
            Log::error('OngoingQuestionController/checkUniqueCode() => '.$e->getMessage());
            Log::error('OngoingQuestionController/checkUniqueCode()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * ViewCorrelation Detail
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function viewCorrelationDetail($id)
    {
        try {
            $ongoingquestion = RiskAnalysisRemindOption::with(['question', 'answer'])->where('ongoing_question_id', $id)->get();

            return $this->success(Config::get('constants.ADMIN_PANEL.ONGOING_QUESTION.ONGOING_QUESTION_VIEW_CORRELATION'), 200, $ongoingquestion);
        } catch (\Exception $e) {
            Log::error('OngoingQuestionController/viewCorrelationDetail() => '.$e->getMessage());
            Log::error('OngoingQuestionController/viewCorrelationDetail()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.ONGOING_QUESTION.NOT_FOUND'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
