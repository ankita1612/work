<?php

namespace App\Http\Controllers\Admin;

use App\Exports\ExportLocation;
use App\Exports\ExportTrainingReportForOldUser;
use App\Exports\ExportUser;
use App\Http\Controllers\Controller;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AccountUser;
use App\Models\BusinessAssociates;
use App\Models\EmailTemplate;
use App\Models\Employee;
use App\Models\Location;
use App\Models\Partner;
use App\Models\Promocode;
use App\Models\Student;
use App\Models\User;
use App\Models\UserPartner;
use App\Models\UserScheduleStatusChangeEvent;
use App\Models\UserTag;
use App\Traits\ApiResponser;
use App\Traits\ChargebeePlan;
use App\Traits\PricingHelper;
use App\Traits\SendMail;
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Models\Estimate;
use ChargeBee\ChargeBee\Models\Subscription;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;
use Maatwebsite\Excel\Excel as ExcelC;
use Maatwebsite\Excel\Facades\Excel;
use Stripe;

class UserController extends Controller
{
    use ApiResponser, PricingHelper, SendMail, ChargebeePlan;

    /**
     * View page
     */
    public function showUser()
    {
        return view('admin.pages.user.view');
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get user list for view
     *
     * @return \Illuminate\Http\Response
     */
    public function getUserList(Request $request)
    {
        try {
            $user_data = Auth::user();
            $user_list = User::select('users.*', DB::raw('IFNULL(partners.name,"Abyde") as reseller_name'))
                ->leftJoin('partners', 'users.partner_reseller_id', '=', 'partners.id');

            if ($user_data['partner_reseller_id'] != null) {
                $user_list->where('users.partner_reseller_id', $user_data['partner_reseller_id'])
                    ->with('reseller:id,name');
            }

            if ($request->has('search') && $request['search'] != '') {
                $user_list = $user_list->where(function ($query) use ($request) {
                    $query->whereRaw('concat(first_name, " ", last_name) like "%' . $request->input('search') . '%" ')
                        ->orWhereRaw('concat(last_name, " ", first_name) like "%' . $request->input('search') . '%" ')
                        ->orWhere('users.email', 'LIKE', '%' . $request->input('search') . '%')
                        ->orWhere('partners.name', 'LIKE', '%' . $request->input('search') . '%')
                        ->orWhere('company_name', 'LIKE', '%' . $request->input('search') . '%');
                });
            }
            if ($request->input('sort_column')) {
                $user_list = $user_list->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
            }

            if ($request['filter_by'] != '' && $request['filter_by'] == 'active') {
                $user_list = $user_list->where('users.is_active', 1);
            } elseif ($request['filter_by'] != '' && $request['filter_by'] == 'inactive') {
                $user_list = $user_list->where('users.is_active', 0);
            } elseif ($request['filter_by'] != '' && $request['filter_by'] == 'frozen') {
                $user_list = $user_list->where('account_status', 'Frozen');
            }
            $user_list = $user_list->paginate($request->input('selected_show_entry'))->onEachSide(1);

            return $this->success(Config::get('constants.SUCCESS'), 200, $user_list);
        } catch (\Exception $e) {
            Log::error('UserController/getUserList() => ' . $e->getMessage());
            Log::error('UserController/getUserList()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get user details
     *
     * @return \Illuminate\Http\Response
     */
    public function getUserDetails($id)
    {
        try {

            $user_details = User::with(['state', 'lastLoginDetails', 'userTags', 'userScheduleStatusChangeEvent'])
                ->with([
                    'userPartners:user_id,partner_id',
                    'userPartners.partner:id,name'
                ])
                ->withCount(['locations', 'accountUsers', 'employees', 'businessAssociates', 'students'])
                ->find($id);
            $subscription = $this->getSubscriptionDetails($user_details->chargebee_subscription_id);
            $plan_type = $subscription['plan_type'];
            $location_limit = $subscription['location_limit'];
            $employee_limit = $subscription['employee_limit'];  
             if($user_details->is_sra_user == 1){
                $chargebee_plan_ids = $this->getChargebeePlanId(strtolower(str_replace("-", "", $plan_type)), $user_details->chargebe_addon_type, 'sra_only');
             }else{
                $version = 'v2';
                foreach ($subscription['item_tiers'] as $item_tiers) {
                    if(str_contains($item_tiers['item_price_id'], 'Employees') && !empty($item_tiers['ending_unit']) && $item_tiers['ending_unit']== 5){
                        $version = 'v1';
                        break;
                    }
                }     
                $chargebee_plan_ids = $this->getChargebeePlanId(strtolower(str_replace("-", "", $plan_type)), $user_details->chargebe_addon_type, 'normal', $version);    
             }         

            $next_payment_price = 0;
            $next_charge_price = 0;
            $next_sales_tax_percentage = 0;
            $next_sales_tax = [];
            $transaction_fee = 0;
            $next_discount_price = 0;
            $final_promocode_percentage = 0;
            $final_promocode = '';
            $renewal_estimation_amount_recieved = 'no';
            $user_details['subscription_status'] = $subscription['status'];
            if($subscription['status'] == 'active' || $subscription['status'] == 'non_renewing'){
                $renewal_estimate = Estimate::renewalEstimate(
                    $user_details->chargebee_subscription_id,
                    array(
                        'ignoreScheduledCancellation' => true,
                        'ignoreScheduledChanges' => true,
                    )
                );
                $renewal_estimate_response = $renewal_estimate->estimate();
                if(isset($renewal_estimate_response->invoiceEstimate) && !empty($renewal_estimate_response->invoiceEstimate)){
                    $next_payment_price = $renewal_estimate_response->invoiceEstimate->total / 100;
                    $next_charge_price = $next_payment_price;
                    if($user_details->is_sra_user == 0){
                        $transaction_fee_item_id = $chargebee_plan_ids['transaction_fee_item_id'];
                        foreach ($renewal_estimate_response->invoiceEstimate->lineItems as $key => $value) {
                            if ($value->entityId == $transaction_fee_item_id) {
                                $transaction_fee = $value->amount / 100;
                            }
                        }
                        $next_payment_price = round($next_payment_price - $transaction_fee, 2);
                    }
                    
                    if (isset($renewal_estimate_response->invoiceEstimate->taxes) && !empty($renewal_estimate_response->invoiceEstimate->taxes)) {
                        foreach ($renewal_estimate_response->invoiceEstimate->taxes as $key => $value) {
                            $next_sales_tax[] = array(
                                'amount' => $value->amount / 100
                            );
                        }
                        foreach ($renewal_estimate_response->invoiceEstimate->lineItems as $key => $value) {
                            $next_sales_tax_percentage  = (isset($value->taxRate)) ? $value->taxRate : 0;
                        }
                    }
                    if (!empty($next_sales_tax)) {
                        $next_payment_price = round($next_payment_price - array_sum(array_column($next_sales_tax, 'amount')), 2);
                    }
                
                    if (isset($renewal_estimate_response->invoiceEstimate->discounts[0]) && !empty($renewal_estimate_response->invoiceEstimate->discounts[0])) {
                        $next_discount_price = $renewal_estimate_response->invoiceEstimate->discounts[0]->amount / 100;
                        $final_promocode = $renewal_estimate_response->invoiceEstimate->discounts[0]->entityId;
                        $final_promocode_percentage = $renewal_estimate_response->invoiceEstimate->discounts[0]->discountPercentage;
                    }
                    if ($next_discount_price > 0) {
                        $next_payment_price = round($next_payment_price + $next_discount_price, 2);
                    }
                    $renewal_estimation_amount_recieved = 'yes';
                }
            }

            $data = [
                'user_details' => $user_details,
                'plan_type' => $plan_type,
                'amount' => $this->formatPrice($next_payment_price),
                'sale_tax_per' => $this->formatPrice($next_sales_tax_percentage),
                'sale_tax_amount' => $this->formatPrice(array_sum(array_column($next_sales_tax, 'amount'))),
                'charge_amount' => $this->formatPrice($next_charge_price),
                'next_transaction_fee' => $this->formatPrice($transaction_fee),
                'location_limit' => $location_limit,
                'employee_limit' => $employee_limit,
                'renewal_estimation_amount_recieved' => $renewal_estimation_amount_recieved,
            ];

            if ($final_promocode != '') {
                $data['user_promocode'] = [
                    'discount_percentage' => $final_promocode_percentage,
                    'promo_code' => $final_promocode
                ];
            }
            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('UserController/getUserDetails() => ' . $e->getMessage());
            Log::error('UserController/getUserDetails()[data] => ' . json_encode([$id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * modify user account details
     *
     * @return Illuminate\Http\Response
     */
    public function modifyUserAccountDetail(Request $request)
    {
        $validator_rules = [
            'user_id' => 'required',
            'call_from' => 'nullable|in:account_verified_status,active_status,payment_freeze_status,filter_by',
            'status' => 'nullable',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            DB::beginTransaction();
            $user = User::findOrFail($request['user_id']);
            if ($request['call_from'] == 'account_verified_status' && $request['status'] == 1) {
                $user = $user->update(['is_account_verified' => 0]);
            }
            if ($request['call_from'] == 'account_verified_status' && $request['status'] == 0) {
                $user = $user->update(['is_account_verified' => 1, 'is_active' => 1, 'account_verification_code' => '']);
            }

            if ($request['call_from'] == 'active_status') {
                UserScheduleStatusChangeEvent::where('user_id', $request['user_id'])->delete();
                if ($request['status'] == 2) {
                    $input_fields['user_id'] = $request['user_id'];
                    $input_fields['scheduled_date'] = $request['scheduled_date'];
                    UserScheduleStatusChangeEvent::create($input_fields);
                } elseif ($request['call_from'] == 'active_status' && $request['status'] == 1) {
                    $user = $user->update(['is_active' => 0]);
                    if ($user) {
                        $updated_user = User::findOrFail($request['user_id']);
                        if (isset($updated_user->locations[0]['id'])) {
                            $main_location = Location::where('id', $updated_user->locations[0]['id'])->whereNotNull('salesforce_unique_id')->first();
                            if ($main_location) {
                                SendLocationDataToSalesForce::dispatch($main_location->id);
                            }
                        }
                    }
                } elseif ($request['call_from'] == 'active_status' && $request['status'] == 0) {
                    $user = $user->update(['is_active' => 1]);
                    if ($user) {
                        $updated_user = User::findOrFail($request['user_id']);
                        if (isset($updated_user->locations[0]['id'])) {
                            $main_location = Location::where('id', $updated_user->locations[0]['id'])->whereNotNull('salesforce_unique_id')->first();
                            if ($main_location) {
                                SendLocationDataToSalesForce::dispatch($main_location->id);
                            }
                        }
                    }
                }
            }

            if ($request['call_from'] == 'payment_freeze_status' && $request['status'] == 'Unfrozen') {
                $user = $user->update(['account_status' => 'Frozen']);
                if ($user) {
                    $updated_user = User::findOrFail($request['user_id']);
                    if (isset($updated_user->locations[0]['id'])) {
                        $main_location = Location::where('id', $updated_user->locations[0]['id'])->whereNotNull('salesforce_unique_id')->first();
                        if ($main_location) {
                            SendLocationDataToSalesForce::dispatch($main_location->id);
                        }
                    }
                }
            }
            if ($request['call_from'] == 'payment_freeze_status' && ($request['status'] == 'Frozen')) {
                $user = $user->update(['account_status' => 'Unfrozen']);
                if ($user) {
                    $updated_user = User::findOrFail($request['user_id']);
                    if (isset($updated_user->locations[0]['id'])) {
                        $main_location = Location::where('id', $updated_user->locations[0]['id'])->whereNotNull('salesforce_unique_id')->first();
                        if ($main_location) {
                            SendLocationDataToSalesForce::dispatch($main_location->id);
                        }
                    }
                }
            }

            DB::commit();

            return $this->success(Config::get('constants.ADMIN_PANEL.USER.USER_UPDATE'), 200);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('UserController/modifyUserAccountDetail() => ' . $e->getMessage());
            Log::error('UserController/modifyUserAccountDetail()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get list of users for manual trx
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function userList()
    {
        try {
            $user = User::select(['id', 'first_name', 'last_name', 'email'])->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $user);
        } catch (\Exception $e) {
            Log::error('UserController/userList() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 500);
        }
    }

    /**
     * get employee
     *
     * @return \Illuminate\Http\Response
     */
    public function getEmployee($user_id)
    {
        try {
            $employee = Employee::with(['employeeSecondaryWorkLocation.location', 'employeePrimaryWorkLocation'])->where('user_id', $user_id)
                ->orderBy('id', 'DESC')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $employee);
        } catch (\Exception $e) {
            Log::error('UserController/getEmployee() => ' . $e->getMessage());
            Log::error('UserController/getEmployee()[data] => ' . json_encode([$user_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get students
     *
     * @return \Illuminate\Http\Response
     */
    public function getStudent($user_id)
    {
        try {
            $student = Student::with('studentPrimaryWorkLocation')->where('user_id', $user_id)
                ->orderBy('id', 'DESC')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $student);
        } catch (\Exception $e) {
            Log::error('UserController/getStudent() => ' . $e->getMessage());
            Log::error('UserController/getStudent()[data] => ' . json_encode([$user_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get business associate
     *
     * @return \Illuminate\Http\Response
     */
    public function getBusinessAssociate($user_id)
    {
        try {
            $business_associate = BusinessAssociates::where('user_id', $user_id)
                ->orderBy('id', 'DESC')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $business_associate);
        } catch (\Exception $e) {
            Log::error('UserController/getBusinessAssociate() => ' . $e->getMessage());
            Log::error('UserController/getBusinessAssociate()[data] => ' . json_encode([$user_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get account user
     *
     * @return \Illuminate\Http\Response
     */
    public function getAccountUser($user_id)
    {
        try {
            $account_user = AccountUser::with(['accountLocationAccess.location', 'hipaaComplianceOfficer.location'])->where('user_id', $user_id)
                ->orderBy('id', 'DESC')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $account_user);
        } catch (\Exception $e) {
            Log::error('UserController/getAccountUser() => ' . $e->getMessage());
            Log::error('UserController/getAccountUser()[data] => ' . json_encode([$user_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * login to user account by admin
     *
     * @return \Illuminate\Http\Response
     */
    public function doUserLoginByAdmin(Request $request)
    {
        $validator_rules = [
            'user_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $user = User::where('id', $request['user_id'])->first();
            if ($user) {
                if (request()->session()->has('is_admin_panel_login') || Auth::guard('user')->check() || Auth::guard('account_user')->check()) {
                    return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, ['is_user_logged_in' => 1]);
                }
                Auth::guard('user')->logout();
                Auth::guard('account_user')->logout();
                if (! $user->is_active) {
                    return $this->error(Config::get('constants.USER.INACTIVE'), 200, ['is_user_found' => 1]);
                    exit;
                } elseif (! $user->is_account_verified) {
                    return $this->error(Config::get('constants.USER.ACCOUNT_NOT_VERIFIED'), 200, ['is_user_found' => 1]);
                    exit;
                } elseif (Auth::guard('user')->loginUsingId($user->id)) {
                    $request->session()->put('is_admin_panel_login', true);

                    return $this->success(Config::get('constants.USER.USER_LOGIN_SUCCESS'), 200, ['is_user_found' => 1, 'redirect_url' => Config::get('app.url')]);
                    exit;
                }
            }
        } catch (\Exception $e) {
            Log::error('UserController/doUserLoginByAdmin() => ' . $e->getMessage());
            Log::error('UserController/doUserLoginByAdmin()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function exportUsers(Request $request)
    {
        try {
            $validator_rules = [
                'year' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $export = new ExportUser($request['year']);

            return $this->success(
                Config::get('constants.SUCCESS'),
                200,
                [
                    'name' => 'User List for Year ' . $request->year . '.xlsx',
                    'file' => 'data:application/vnd.ms-excel;base64,' . base64_encode(Excel::raw($export, ExcelC::XLSX)),
                ]
            );
        } catch (\Exception $e) {
            Log::error('UserController/exportUsers() => ' . $e->getMessage());
            Log::error('UserController/exportUsers()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * add user tags
     *
     * @return \Illuminate\Http\Response
     */
    public function addUserTags(Request $request)
    {
        try {
            $validator_rules = [
                'add_tags' => 'sometimes|array',
                'remove_tags' => 'sometimes|array',
                'user_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            DB::beginTransaction();
            $input_fields = $request->all();
            $user = User::find($input_fields['user_id']);
            if ($request->has('remove_tags') && ! empty($input_fields['remove_tags'])) {
                UserTag::whereIn('id', $input_fields['remove_tags'])->get()->each(function ($usertag) {
                    $usertag->delete();
                });
            }
            if ($request->has('add_tags') && ! empty($input_fields['add_tags'])) {
                $user->userTags()->createMany($input_fields['add_tags']);
            }
            DB::commit();

            return $this->success(Config::get('constants.ADMIN_PANEL.USER.TAGS_ADDED'), 200);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('UserController/addUserTags() => ' . $e->getMessage());
            Log::error('UserController/addUserTags()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * list user partners
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getUserPartnersList()
    {
        try {
            $list = Partner::select('id', 'name')->isActive()->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('UserController/getUserPartnersList() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * add user partners
     *
     * @return \Illuminate\Http\Response
     */
    public function addUserPartners(Request $request)
    {
        try {
            $validator_rules = [
                'user_id' => 'required',
                'partner_id' => 'array|sometimes',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $user = User::findOrFail($input_fields['user_id']);

            if ($request->has('partner_id_list_old')) {
                UserPartner::whereIn('partner_id', $request['partner_id_list_old'])->delete();
            }

            if ($request->has('partner_id_list_new')) {
                $user->userPartners()->createMany($input_fields['partner_id_list_new']);
            }

            DB::commit();

            return $this->success(Config::get('constants.ADMIN_PANEL.USER.PARTNERS_ADDED'), 200);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('UserController/addUserPartners() => ' . $e->getMessage());
            Log::error('UserController/addUserPartners()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
