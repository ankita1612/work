<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\Partner;
use App\Models\Role;
use App\Traits\ApiResponser;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class AdminController extends Controller
{
    use ApiResponser, SendMail;

    /**
     * View page
     */
    public function showAdmin()
    {
        return view('admin.pages.admin.view');
    }

    /**
     * Add page
     */
    public function showAdminAdd()
    {
        return view('admin.pages.admin.add');
    }

    /**
     * Edit page
     */
    public function showAdminEdit($admin_id)
    {
        return view('admin.pages.admin.edit', compact('admin_id'));
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Role list
     *
     * @return \Illuminate\Http\Response
     */
    public function getRoleList()
    {
        $list = Role::get();

        return $this->success(Config::get('constants.SUCCESS'), 200, $list);
    }

    /**
     * Admin Add
     *
     * @return \Illuminate\Http\Response
     */
    public function addAdmin(Request $request)
    {
        $validator_rules = [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email|unique:App\Models\Admin,email,NULL,id,deleted_at,NULL',
            'password' => 'required',
            'selected_role' => 'required',
            'partner_reseller_id' => 'required_if:role_id,4',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $input_fields = $request->all();
            $input_fields['is_active'] = 1;
            $input_fields['role_id'] = $input_fields['selected_role'];
            $input_fields['password'] = bcrypt($input_fields['password']);
            $input_fields['partner_reseller_id'] = $request->partner_reseller_id;
            $admin = Admin::create($input_fields);

            return $this->success(Config::get('constants.ADMIN_PANEL.ADMIN.ADMIN_ADD'), 200, $admin);
        } catch (\Exception $e) {
            Log::error('AdminController/addAdmin() => '.$e->getMessage());
            Log::error('AdminController/addAdmin()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Admin List
     *
     * @return \Illuminate\Http\Response
     */
    public function getAdminList(Request $request)
    {
        try {
            $admin_list = Admin::join('roles', 'admins.role_id', '=', 'roles.id')->select('admins.*', 'roles.role');
            if ($request->has('search') && $request['search'] != '') {
                $admin_list = $admin_list->whereRaw('concat(first_name, " ", last_name) like "%'.$request->input('search').'%" ')
                    ->orWhereRaw('concat(last_name, " ", first_name) like "%'.$request->input('search').'%" ')
                    ->orWhere('email', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhere('roles.role', 'LIKE', '%'.$request->input('search').'%');
            }
            if ($request->input('sort_column') == 'role_id') {
                $admin_list = $admin_list->orderBy('roles.role', $request->input('sort_order'))->orderBy('roles.id', $request->input('sort_order'));
            } else {
                $admin_list = $admin_list->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
            }

            $admin_list = $admin_list->paginate($request->input('selected_show_entry'))->onEachSide(1);

            return $this->success(Config::get('constants.SUCCESS'), 200, $admin_list);
        } catch (\Exception $e) {
            Log::error('AdminController/getAdminList() => '.$e->getMessage());
            Log::error('AdminController/getAdminList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Admin Detail
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getAdminEditDetail($admin_id = '')
    {
        if (! $admin_id) {
            return $this->error(Config::get('constants.MISSING_ARG'), 200);
        }
        try {
            $admin = Admin::with('partner')->findOrFail($admin_id);
            if ($admin) {
                return $this->success(Config::get('constants.ADMIN_PANEL.ADMIN.ADMIN_EDIT'), 200, $admin);
            } else {
                return $this->error(Config::get('constants.ADMIN_PANEL.ADMIN.NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AdminController/getAdminEditDetail() => '.$e->getMessage());
            Log::error('AdminController/getAdminEditDetail()[data] => '.json_encode([$admin_id]));

            return $this->error(Config::get('constants.ADMIN.NOT_FOUND'), 200);
        }
    }

    /**
     * Admin Update
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAdmin(Request $request)
    {
        $admin_id = $request->admin_id;
        $validator_rules = [
            'admin_id' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email|unique:App\Models\Admin,email,'.$admin_id.',id,deleted_at,NULL',
            'partner_reseller_id' => 'required_if:role_id,4',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $admin = Admin::findOrFail($admin_id);
            $input_fields = $request->all();
            $input_fields['is_active'] = ($input_fields['is_active'] == true) ? 1 : 0;
            if (isset($input_fields['password']) && ! empty($input_fields['password'])) {
                $input_fields['password'] = bcrypt($input_fields['password']);
            } else {
                unset($input_fields['password']);
            }
            $admin->update($input_fields);

            return $this->success(Config::get('constants.ADMIN_PANEL.ADMIN.ADMIN_UPDATE'), 200, $admin);
        } catch (\Exception $e) {
            Log::error('AdminController/updateAdmin() => '.$e->getMessage());
            Log::error('AdminController/updateAdmin()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Admin Delete
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deleteAdmin($id)
    {
        try {
            $admin = Admin::findOrFail($id);
            $admin->delete();

            return $this->success(Config::get('constants.ADMIN_PANEL.ADMIN.ADMIN_DELETE_SUCCESS'), 200, $admin);
        } catch (\Exception $e) {
            Log::error('AdminController/deleteAdmin() => '.$e->getMessage());
            Log::error('AdminController/deleteAdmin()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.ADMIN.ADMIN_DELETE_FAIL'), 200);
        }
    }

    /**
     * Check unique email address in admin
     *
     * @return \Illuminate\Http\Response
     */
    public function checkUniqueEmail(Request $request, $email = '', $admin_id = '')
    {
        try {
            if ($email == '') {
                dd('Invalid parmas');
            }
            $admin = Admin::where('email', $request['email']);
            if ($admin_id != '') {
                $admin->where('id', '!=', $request['admin_id']);
            }
            $admin = $admin->count();
            if ($admin > 0) {
                return 'available';
            } else {
                return 'not_available';
            }
        } catch (\Exception $e) {
            Log::error('AdminController/checkUniqueEmail() => '.$e->getMessage());
            Log::error('AdminController/checkUniqueEmail()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Partner Reseller list
     *
     * @return \Illuminate\Http\Response
     */
    public function getPartnerResellerList()
    {
        $list = Partner::get();

        return $this->success(Config::get('constants.SUCCESS'), 200, $list);
    }
    /************************** */
    /*API methods - end
    /*************************** */
}
