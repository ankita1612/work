<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\HipaaGapAssessmentVisitor;
use App\Models\Partner;
use App\Models\State;
use App\Traits\{ApiResponser};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;

class HIPAAGapAssessmentController extends Controller
{
    use ApiResponser;

    /**
     * View page
     */
    public function showVisitor()
    {
        return view('admin.pages.hipaaGapAssessment.visitor');
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     *  Visitor List
     *
     * @return \Illuminate\Http\Response
     */
    public function getVisitorList(Request $request)
    {
        try {
            $visitor_list = HipaaGapAssessmentVisitor::query();
            if ($request->has('search') && $request['search'] != '') {
                $visitor_list = $visitor_list->where('company_name', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhere('contact_name', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhere('email', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhereHas('partner', function ($q) use ($request) {
                        $q->where('name', 'LIKE', '%'.$request->input('search').'%');
                    })
                    ->orWhereHas('state', function ($q) use ($request) {
                        $q->where('state_name', 'LIKE', '%'.$request->input('search').'%');
                    });
            }
            if ($request->input('sort_column')) {
                if ($request['sort_column'] == 'partner_name') {
                    $visitor_list = $visitor_list->with(['partner'])->orderBy(Partner::select('name')
                        ->whereColumn('partners.id', 'hipaa_gap_assessment_visitors.partner_id'),
                        $request->input('sort_order')
                    )->orderBy('id',$request->input('sort_order'));
                } elseif ($request['sort_column'] == 'state_name') {
                    $visitor_list = $visitor_list->with(['state'])->orderBy(State::select('state_name')
                        ->whereColumn('states.id', 'hipaa_gap_assessment_visitors.state_id'),
                        $request->input('sort_order')
                    )->orderBy('id',$request->input('sort_order'));
                } else {
                    $visitor_list = $visitor_list->with(['partner', 'state'])->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id',$request->input('sort_order'));
                }
            }
            $visitor_list = $visitor_list->paginate($request->input('selected_show_entry'))->onEachSide(1);

            return $this->success(Config::get('constants.SUCCESS'), 200, $visitor_list);

        } catch (\Exception $e) {
            Log::error('HIPAAGapAssessmentController/getVisitorList() => '.$e->getMessage());
            Log::error('HIPAAGapAssessmentController/getVisitorList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */

}
