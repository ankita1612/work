<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\State;
use App\Models\User;
use App\Models\Whatsnew;
use App\Models\WhatsnewSeenStatus;
use App\Models\WhatsnewState;
use App\Traits\ApiResponser;
use App\Traits\FileUpload;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class WhatsnewController extends Controller
{
    use ApiResponser, FileUpload, SendMail;

    /**
     * View page
     */
    public function showWhatsnew()
    {
        return view('admin.pages.whatsnew.view');
    }

    /**
     * Add page
     */
    public function showWhatsnewAdd()
    {
        return view('admin.pages.whatsnew.add');
    }

    /**
     * Edit page
     */
    public function showWhatsnewEdit($whatsnew_id)
    {
        return view('admin.pages.whatsnew.edit', compact('whatsnew_id'));
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Whatsnew Add
     *
     * @return \Illuminate\Http\Response
     */
    public function addWhatsnew(Request $request)
    {
        $validator_rules = [
            'title' => 'required',
            'short_description' => 'required',
            'description' => 'required',
            'file' => 'required|mimes:mp4,jpg,png,jpeg',
            'post_date' => 'required',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $input_fields = $request->all();
            $file = $request->file('file');
            $mediaName = '';
            if ($request->hasFile('file')) {
                $mediaName = date('YmdHis').'.'.$file->getClientOriginalExtension();
            }
            $input_fields['media'] = $mediaName;
            if (strstr($input_fields['media_type'], 'image/')) {
                $input_fields['media_type'] = 'image';
            } else {
                $input_fields['media_type'] = 'video';
            }
            $input_fields['is_active'] = 1;
            $input_fields['post_date'] = $request->post_date;
            $whatsnew = Whatsnew::create($input_fields);
            if ($request->has('states')) {
                $whatsnew_states = [];
                foreach (json_decode($input_fields['states']) as $key => $value) {
                    $whatsnew_states[$key] = ['state_id' => $value->id];
                }
                $whatsnew->whatsnewState()->createMany($whatsnew_states);
            }
            $file->storeAs(
                '/whatsnew/'.$whatsnew['id'],
                $mediaName,
                ['disk' => 's3', 'ContentType' => 'application/octet-stream',\fopen($file, 'r+')] 
            );
            if ($request->has('states')) {
                $users_id = User::whereIn('state_id', $whatsnew_states)->pluck('id');
                WhatsnewSeenStatus::whereIn('user_id', $users_id)->get()->each(function ($wnss) {
                    $wnss->delete();
                });
            } else {
                WhatsnewSeenStatus::truncate();
            }

            return $this->success(Config::get('constants.ADMIN_PANEL.WHATSNEW.WHATSNEW_ADD'), 200, $whatsnew);
        } catch (\Exception $e) {
            Log::error('WhatsnewController/addWhatsnew() => '.$e->getMessage());
            Log::error('WhatsnewController/addWhatsnew()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     *  Whatsnew List
     *
     * @return \Illuminate\Http\Response
     */
    public function getWhatsnewList(Request $request)
    {
        try {
            $whatsnew_list = Whatsnew::query();
            $whatsnew_list = $whatsnew_list->with(['whatsnewState.states']);
            if ($request->has('search') && $request['search'] != '') {
                $whatsnew_list = $whatsnew_list->where('title', 'LIKE', '%'.$request->input('search').'%');
            }
            if ($request->input('sort_column')) {
                $whatsnew_list = $whatsnew_list->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
            }
            $whatsnew_list = $whatsnew_list->paginate($request->input('selected_show_entry'));

            return $this->success(Config::get('constants.SUCCESS'), 200, $whatsnew_list);
        } catch (\Exception $e) {
            Log::error('WhatsnewController/getWhatsnewList() => '.$e->getMessage());
            Log::error('WhatsnewController/getWhatsnewList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Whatsnew Detail
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getWhatsnewEditDetail($whatsnew_id = '')
    {
        if (! $whatsnew_id) {
            return $this->error(Config::get('constants.MISSING_ARG'), 200);
        }
        try {
            $whatsnew = Whatsnew::with('whatsnewState.states')->findOrFail($whatsnew_id);

            if ($whatsnew) {
                $whatsnew['media_path'] = $this->getSignedURL('whatsnew/'.$whatsnew['id'].'/'.$whatsnew['media']);

                return $this->success(Config::get('constants.ADMIN_PANEL.WHATSNEW.WHATSNEW_EDIT'), 200, $whatsnew);
            } else {
                return $this->error(Config::get('constants.ADMIN_PANEL.WHATSNEW.WHATSNEW_NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('WhatsnewController/getWhatsnewEditDetail() => '.$e->getMessage());
            Log::error('WhatsnewController/getWhatsnewEditDetail()[data] => '.json_encode([$whatsnew_id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.WHATSNEW.NOT_FOUND'), 200);
        }
    }

    /**
     * Whatsnew Update
     *
     * @return \Illuminate\Http\Response
     */
    public function updateWhatsnew(Request $request)
    {
        $validator_rules = [
            'title' => 'required',
            'short_description' => 'required',
            'description' => 'required',
            'post_date' => 'required',
            'whatsnew_id' => 'required',
        ];
        $whatsnew_id = $request->whatsnew_id;
        if ($request->file('file') != null) {
            $validator_rules = [
                'file' => 'mimes:mp4,jpg,png,jpeg',
            ];
        }

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $whatsnew = Whatsnew::findOrFail($whatsnew_id);
            $input_fields = $request->all();
            $file = $request->file('file');
            if ($request->file('file') != null) {
                if ($request->hasFile('file')) {
                    $media_file_delete = '/whatsnew/'.$whatsnew['id'].'/'.$whatsnew['media'];
                    if (Storage::disk('s3')->exists($media_file_delete)) {
                        Storage::disk('s3')->delete($media_file_delete);
                    }
                    $mediaName = date('YmdHis').'.'.$file->getClientOriginalExtension();
                    $file->storeAs(
                        '/whatsnew/'.$whatsnew_id,
                        $mediaName,
                        ['disk' => 's3', 'ContentType' => 'application/octet-stream',\fopen($file, 'r+')] 
                    );
                    $input_fields['media'] = $mediaName;
                }
            } else {
                $input_fields['media'] = $whatsnew['media'];
            }
            if ($input_fields['media_type'] == null) {
                $input_fields['media_type'] = $whatsnew['media_type'];
            } else {
                if (strstr($input_fields['media_type'], 'image/')) {
                    $input_fields['media_type'] = 'image';
                } else {
                    $input_fields['media_type'] = 'video';
                }
            }
            $input_fields['is_active'] = ($input_fields['is_active'] == 'true') ? 1 : 0;
            if ($whatsnew->update($input_fields)) {
                if ($request->has('state_remove')) {
                    $remove_states = [];
                    $remove_states = json_decode($request['state_remove'], true);
                    WhatsnewState::whereIn('state_id', $remove_states)
                        ->where('whatsnew_id', $whatsnew_id)->get()->each(function ($wn) {
                            $wn->delete();
                        });
                }
                if ($request->has('state_new')) {
                    $new_states = [];
                    $new_states = json_decode($request['state_new'], true);
                    $whatsnew->whatsnewState()->createMany($new_states);

                    $users_id = User::whereIn('state_id', $new_states)->pluck('id');
                    WhatsnewSeenStatus::whereIn('user_id', $users_id)->get()->each(function ($wnss) {
                        $wnss->delete();
                    });
                }
            }

            // $whatsnew->update($input_fields);
            return $this->success(Config::get('constants.ADMIN_PANEL.WHATSNEW.WHATSNEW_UPDATE'), 200, $whatsnew);
        } catch (\Exception $e) {
            Log::error('WhatsnewController/updateWhatsnew() => '.$e->getMessage());
            Log::error('WhatsnewController/updateWhatsnew()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Whatsnew Delete
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deleteWhatsnew($id)
    {
        try {
            $whatsnew = Whatsnew::findOrFail($id);
            $file = '/whatsnew/'.$whatsnew['id'].'/'.$whatsnew['media'];
            if (Storage::disk('s3')->exists($file)) {
                Storage::disk('s3')->delete($file);
            }
            $whatsnew->delete();

            return $this->success(Config::get('constants.ADMIN_PANEL.WHATSNEW.WHATSNEW_DELETE_SUCCESS'), 200, $whatsnew);
        } catch (\Exception $e) {
            Log::error('WhatsnewController/deleteWhatsnew() => '.$e->getMessage());
            Log::error('WhatsnewController/deleteWhatsnew()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.WHATSNEW.WHATSNEW_DELETE_FAIL'), 200);
        }
    }

    /**
     * Whatsnew Detail
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function showWhatsnewDetail($id)
    {
        try {
            $whatsnew = Whatsnew::findOrFail($id);
            $whatsnew['media_path'] = $this->getSignedURL('whatsnew/'.$whatsnew['id'].'/'.$whatsnew['media']);

            return $this->success(Config::get('constants.ADMIN_PANEL.WHATSNEW.WHATSNEW_DETAIL_SHOW'), 200, $whatsnew);
        } catch (\Exception $e) {
            Log::error('WhatsnewController/showWhatsnewDetail() => '.$e->getMessage());
            Log::error('WhatsnewController/showWhatsnewDetail()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.WHATSNEW.NOT_FOUND'), 200);
        }
    }

    /**
     * State List
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function stateList()
    {
        try {
            $state_list = State::select(['id', 'state_code', 'state_name'])->orderBy('state_name')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $state_list);
        } catch (\Exception $e) {
            Log::error('WhatsnewController/stateList() => '.$e->getMessage());

            return $this->error(Config::get('constants.ADMIN_PANEL.WHATSNEW.NOT_FOUND'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
