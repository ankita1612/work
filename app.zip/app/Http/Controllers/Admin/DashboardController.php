<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\OngoingQuestion;
use App\Models\Promocode;
use App\Models\RiskAnalysisQuestion;
use App\Models\Training;
use App\Models\User;
use App\Models\Whatsnew;
use App\Models\UserBadgeEmailHistory;
use App\Traits\ApiResponser;
use App\Traits\SendMail;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExportAllUserBadgeEmailHistory;

class DashboardController extends Controller
{
    use ApiResponser, SendMail;

    /**
     * Dashboard page
     */
    public function showDashboard()
    {
        return view('admin.pages.dashboard');
    }

    /**
     * Logout
     */
    public function showLogout()
    {
        Auth::logout();

        return redirect()->route('admin_login');
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get dashboard details
     *
     * @return \Illuminate\Http\Response
     */
    public function getDahboardDetails()
    {
        try {
            $user_data = auth()->user();
            if ($user_data->partner_reseller_id != null) {
                $user_count = User::where('partner_reseller_id', $user_data->partner_reseller_id)->count();
            } else {
                $user_count = User::count();
            }
            $list['total_admin'] = Admin::count();
            $list['total_user'] = $user_count;
            $list['total_whatsnew'] = Whatsnew::count();
            $list['total_sra'] = RiskAnalysisQuestion::count();
            $list['total_og'] = OngoingQuestion::count();
            $list['total_training'] = Training::count();
            $list['total_promocode'] = Promocode::count();  
            $list['total_badge_data'] = UserBadgeEmailHistory::count();  

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('DashboardController/getDahboardDetails() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get module access
     *
     * @return \Illuminate\Http\Response
     */
    public function getModuleAccess()
    {
        try {
            $list = Admin::with('role.accessibleModules')->where('id', auth()->user()->id)->first();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('DashboardController/getModuleAccess() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    
    public function downloadUserBadgeEmailReport() {        
        return Excel::download(new ExportAllUserBadgeEmailHistory, 'User_badge_report.xlsx');
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
