<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Training;
use App\Models\Notification;
use App\Traits\ApiResponser;
use App\Traits\FileUpload;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class TrainingController extends Controller
{
    use ApiResponser, FileUpload, SendMail;

    /**
     * View page
     */
    public function showTraining()
    {
        return view('admin.pages.training.view');
    }

    /**
     * Add page
     */
    public function showTrainingAdd()
    {
        return view('admin.pages.training.add');
    }

    /**
     * Edit page
     */
    public function showTrainingEdit($training_id)
    {
        return view('admin.pages.training.edit', compact('training_id'));
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Training Add
     *
     * @return \Illuminate\Http\Response
     */
    public function addTraining(Request $request)
    {
        $input_fields = $request->all();
        $validator_rules = [
            'training_code' => 'required|unique:trainings,training_code',
            'title' => 'required',
            'title_for_list' => 'required_if:parent_training_id,null',
            'description' => 'required',
            'training_type' => 'required',
            'who_can_train' => 'required',
            'video_file' => 'required',
            'video_poster_file' => 'required',
            'video_caption_file' => 'required',
            'display_order' => 'required',
        ];
        $validator_check = Validator::make($input_fields, $validator_rules);

        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $video_file = $request->file('video_file');
            $video_poster_file = $request->file('video_poster_file');
            $video_caption_file = $request->file('video_caption_file');

            $video_file_name = '';
            $video_poster_file_name = '';
            $video_caption_file_name = '';
            $checklist_file_name = '';
            if ($request->hasFile('video_file')) {
                $video_file_name = date('YmdHis').'.'.$video_file->getClientOriginalExtension();
            }
            if ($request->hasFile('video_poster_file')) {
                $video_poster_file_name = date('YmdHis').'.'.$video_poster_file->getClientOriginalExtension();
            }
            if ($request->hasFile('video_caption_file')) {
                $video_caption_file_name = $video_caption_file->getClientOriginalName();
            }
            $input_fields['video_file'] = $video_file_name;
            $input_fields['video_poster_file'] = $video_poster_file_name;
            $input_fields['video_caption_file'] = $video_caption_file_name;
            $input_fields['is_active'] = 1;
            $training = Training::create($input_fields);
            $video_file->storeAs(
                '/trainings/'.$training['id'],
                $video_file_name,
                ['disk' => 's3', 'ContentType' => 'application/octet-stream',\fopen($video_file, 'r+')] 
            );
            $video_poster_file->storeAs(
                '/trainings/'.$training['id'],
                $video_poster_file_name,
                ['disk' => 's3', 'ContentType' => 'application/octet-stream',\fopen($video_poster_file, 'r+')] 
            );
            $video_caption_file->storeAs(
                '/trainings/'.$training['id'],
                $video_caption_file_name,
                ['disk' => 's3', 'ContentType' => 'application/octet-stream',\fopen($video_caption_file, 'r+')] 
            );
            return $this->success(Config::get('constants.ADMIN_PANEL.TRAINING.TRAINING_ADD'), 200, $training);
        } catch (\Exception $e) {
            Log::error('TrainingController/addTraining() => '.$e->getMessage());
            Log::error('TrainingController/addTraining()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     *  Training List
     *
     * @return \Illuminate\Http\Response
     */
    public function getTrainingList(Request $request)
    {
        try {
            $training_list = Training::query();
            if ($request->has('search') && $request['search'] != '') {
                $training_list = $training_list->where('training_code', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhere('title', 'LIKE', '%'.$request->input('search').'%');
            }
            if ($request->input('sort_column')) {
                $training_list = $training_list->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
            }
            $training_list = $training_list->paginate($request->input('selected_show_entry'));

            return $this->success(Config::get('constants.SUCCESS'), 200, $training_list);
        } catch (\Exception $e) {
            Log::error('TrainingController/getTrainingList() => '.$e->getMessage());
            Log::error('TrainingController/getTrainingList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Training Detail
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getTrainingEditDetail($training_id = '')
    {
        if (! $training_id) {
            return $this->error(Config::get('constants.MISSING_ARG'), 200);
        }
        try {
            $training = Training::with('parentTraining:id,title,who_can_train')->findOrFail($training_id);

            if ($training) {
                $training['get_s3_video_file'] = $this->getSignedURL('trainings/'.$training['id'].'/'.$training['video_file']);
                $training['get_s3_video_poster_file'] = $this->getSignedURL('trainings/'.$training['id'].'/'.$training['video_poster_file']);

                return $this->success(Config::get('constants.ADMIN_PANEL.TRAINING.TRAINING_EDIT'), 200, $training);
            } else {
                return $this->error(Config::get('constants.ADMIN_PANEL.TRAINING.NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('TrainingController/getTrainingEditDetail() => '.$e->getMessage());
            Log::error('TrainingController/getTrainingEditDetail()[data] => '.json_encode([$training_id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.TRAINING.NOT_FOUND'), 200);
        }
    }

    /**
     * Training Update
     *
     * @return \Illuminate\Http\Response
     */
    public function updateTraining(Request $request)
    {
        $input_fields = $request->all();
        $validator_rules = [
            'training_code' => 'required',
            'title' => 'required',
            'title_for_list' => 'required_if:parent_training_id,null',
            'description' => 'required',
            'training_type' => 'required',
            'who_can_train' => 'required',
            'training_id' => 'required',
            'display_order' => 'required',
        ];
        $training_id = $request->training_id;
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }

        try {
            $training = Training::findOrFail($training_id);
            $video_file = $request->file('video_file');
            $video_poster_file = $request->file('video_poster_file');
            $video_caption_file = $request->file('video_caption_file');
            if ($video_file != null) {
                if ($request->hasFile('video_file')) {
                    $video_file_delete = '/trainings/'.$training['id'].'/'.$training['video_file'];
                    if (Storage::disk('s3')->exists($video_file_delete)) {
                        Storage::disk('s3')->delete($video_file_delete);
                    }
                    $video_file_new_name = date('YmdHis').'.'.$video_file->getClientOriginalExtension();
                    $video_file->storeAs(
                        '/trainings/'.$training_id,
                        $video_file_new_name,
                        ['disk' => 's3', 'ContentType' => 'application/octet-stream',\fopen($video_file, 'r+')] 
                    );
                    $input_fields['video_file'] = $video_file_new_name;
                }
            } else {
                $input_fields['video_file'] = $training['video_file'];
            }

            if ($video_poster_file != null) {
                if ($request->hasFile('video_poster_file')) {
                    $video_poster_file_delete = '/trainings/'.$training['id'].'/'.$training['video_poster_file'];
                    if (Storage::disk('s3')->exists($video_poster_file_delete)) {
                        Storage::disk('s3')->delete($video_poster_file_delete);
                    }
                    $video_poster_file_new_name = date('YmdHis').'.'.$video_poster_file->getClientOriginalExtension();
                    $video_poster_file->storeAs(
                        '/trainings/'.$training_id,
                        $video_poster_file_new_name,
                        ['disk' => 's3', 'ContentType' => 'application/octet-stream',\fopen($video_poster_file, 'r+')] 
                    );
                    $input_fields['video_poster_file'] = $video_poster_file_new_name;
                }
            } else {
                $input_fields['video_poster_file'] = $training['video_poster_file'];
            }

            if ($video_caption_file != null) {
                if ($request->hasFile('video_caption_file')) {
                    $video_caption_file_delete = '/trainings/'.$training['id'].'/'.$training['video_caption_file'];
                    if (Storage::disk('s3')->exists($video_caption_file_delete)) {
                        Storage::disk('s3')->delete($video_caption_file_delete);
                    }
                    $video_caption_file_new_name = $video_caption_file->getClientOriginalName();
                    $video_caption_file->storeAs(
                        '/trainings/'.$training_id,
                        $video_caption_file_new_name,
                        ['disk' => 's3', 'ContentType' => 'application/octet-stream',\fopen($video_caption_file, 'r+')] 
                    );
                    $input_fields['video_caption_file'] = $video_caption_file_new_name;
                }
            } else {
                $input_fields['video_caption_file'] = $training['video_caption_file'];
            }

            $input_fields['is_active'] = ($input_fields['is_active'] == 'true') ? 1 : 0;
            $input_fields['title_for_list'] = ($input_fields['title_for_list'] == null || $input_fields['title_for_list'] == 'null') ? '' : $input_fields['title_for_list'];
            $training->update($input_fields);

            return $this->success(Config::get('constants.ADMIN_PANEL.TRAINING.TRAINING_UPDATE'), 200, $training);
        } catch (\Exception $e) {
            Log::error('TrainingController/updateTraining() => '.$e->getMessage());
            Log::error('TrainingController/updateTraining()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Training Delete
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deleteTraining($id)
    {
        try {
            $training = Training::findOrFail($id);
            $file = '/trainings/'.$training['id'];
            Storage::disk('s3')->deleteDirectory($file);
            $training->delete();

            return $this->success(Config::get('constants.ADMIN_PANEL.TRAINING.TRAINING_DELETE_SUCCESS'), 200, $training);
        } catch (\Exception $e) {
            Log::error('TrainingController/deleteTraining() => '.$e->getMessage());
            Log::error('TrainingController/deleteTraining()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.ADMIN_PANEL.TRAINING.TRAINING_DELETE_FAIL'), 200);
        }
    }

    /**
     * Check unique training code
     *
     * @return \Illuminate\Http\Response
     */
    public function checkUniqueTrainingCode(Request $request, $training_code = '', $training_id = '')
    {
        try {
            if ($training_code == '') {
                dd('Invalid parmas');
            }
            $training = Training::where('training_code', $request['training_code']);
            if ($training_id != '') {
                $training->where('id', '!=', $request['training_id']);
            }
            $training = $training->count();
            if ($training > 0) {
                return 'available';
            } else {
                return 'not_available';
            }
        } catch (\Exception $e) {
            Log::error('TrainingController/checkUniqueTrainingCode() => '.$e->getMessage());
            Log::error('TrainingController/checkUniqueTrainingCode()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Check unique display order
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function checkUniqueDisplayOrder($display_order = '', $training_id = '')
    {
        try {
            if ($display_order == '') {
                dd('Invalid parmas');
            }
            $training_do = Training::where('display_order', $display_order);
            if ($training_id != '') {
                $training_do->where('id', '!=', $training_id);
            }
            $og_question = $training_do->count();
            if ($og_question > 0) {
                return 'available';
            } else {
                return 'not_available';
            }
        } catch (\Exception $e) {
            Log::error('TrainingController/checkUniqueDisplayOrder() => '.$e->getMessage());
            Log::error('TrainingController/checkUniqueDisplayOrder()[data] => '.json_encode([$display_order, $training_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     *  parent Training List
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getParentTrainingList($training_id = '')
    {
        try {            
            $training_list = Training::select("id","title","who_can_train")->whereIn("who_can_train",array("hco", "employee"))->whereNull('parent_training_id');
            if($training_id != ''){
                    $training_list = $training_list->where('id','!=',$training_id);
                }
            $training_list = $training_list->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $training_list);
        } catch (\Exception $e) {
            Log::error('TrainingController/getParentTrainingList() => '.$e->getMessage());
            Log::error('TrainingController/getParentTrainingList()[data] => '.json_encode([$training_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
     /**
     *  notification code
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getNotificationList()
    {
        try {
            $notification_list = Notification::select("code")
                ->where('module_applicable', 'HIPAA Training')
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $notification_list);
        } catch (\Exception $e) {
            Log::error('TrainingController/getNotificationList() => '.$e->getMessage());
            Log::error('TrainingController/getNotificationList()[data] => ' . json_encode([$notification_list]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
