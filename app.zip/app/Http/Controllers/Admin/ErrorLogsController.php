<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ErrorLogsController extends Controller
{
    /**
     * Error log page
     *
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $file_id = '')
    {
        try {
            if ($file_id != '') {
                echo '<pre>';
                if ($file_id == '') {
                    echo 'Log file not found';
                    exit;
                }
                $filepath = storage_path().'/logs/'.$file_id.'.log';
                if (file_exists($filepath)) {
                    $data = file_get_contents($filepath);
                    echo $data;
                } else {
                    echo 'Log file not found';
                }
                echo '</pre>';
            } else {
                $path = storage_path().'/logs/';
                $ignored = ['.', '..', '.svn', '.htaccess', '.gitignore'];
                $files = array_diff(scandir($path), ['.', '..']);
                $files = [];
                foreach (scandir($path) as $file) {
                    if (in_array($file, $ignored)) {
                        continue;
                    }
                    $files[$file] = filemtime($path.'/'.$file);
                }
                arsort($files);
                $files = array_keys($files);
                if (! empty($files)) {
                    foreach ($files as $file_key => $file) {
                        $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $file);
                        echo "<a href='".url()->current().'/'.$withoutExt."'>".$withoutExt.'</a><br>';
                    }
                } else {
                    echo 'Log files not found';
                }
            }
        } catch (\Exception $e) {
            Log::error('ErrorLogsController/show() => '.$e->getMessage());
        }
    }
}
