<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\HipaaChallengeVisitor;
use App\Models\Partner;
use App\Traits\{ApiResponser};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;

class HIPAAChallengeController extends Controller
{
    use ApiResponser;

    /**
     * View page
     */
    public function showVisitor()
    {
        return view('admin.pages.hipaaChallenge.visitor');
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     *  Visitor List
     *
     * @return \Illuminate\Http\Response
     */
    public function getVisitorList(Request $request)
    {
        try {
            $visitor_list = HipaaChallengeVisitor::query();
            if ($request->has('search') && $request['search'] != '') {
                $visitor_list = $visitor_list->where('company_name', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhere('contact_name', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhere('email', 'LIKE', '%'.$request->input('search').'%')
                    ->orWhereHas('partner', function ($q) use ($request) {
                        $q->where('name', 'LIKE', '%'.$request->input('search').'%');
                    });
            }
            if ($request->input('sort_column')) {
                if ($request['sort_column'] == 'partner_name') {
                    $visitor_list = $visitor_list->with(['partner'])->orderBy(Partner::select('name')
                        ->whereColumn('partners.id', 'hipaa_challenge_visitors.partner_id'),
                        $request->input('sort_order')
                    )->orderBy('id',$request->input('sort_order'));
                } else {
                    $visitor_list = $visitor_list->with(['partner'])->orderBy($request->input('sort_column'), $request->input('sort_order'))->orderBy('id', $request->input('sort_order'));
                }
            }
            $visitor_list = $visitor_list->paginate($request->input('selected_show_entry'))->onEachSide(1);

            return $this->success(Config::get('constants.SUCCESS'), 200, $visitor_list);

        } catch (\Exception $e) {
            Log::error('HIPAAChallengeController/getVisitorList() => '.$e->getMessage());
            Log::error('HIPAAChallengeController/getVisitorList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */

}
