<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\EmailTemplate;
use App\Models\ChargebeeWebhookExcecution;
use App\Models\Location;
use App\Models\Promocode;
use App\Models\TrainingLocation;
use App\Models\User;
use App\Traits\{SendMail, PricingHelper, ChargebeePlan};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Models\Estimate;
use ChargeBee\ChargeBee\Models\Event;
use ChargeBee\ChargeBee\Models\PaymentSource;
use ChargeBee\ChargeBee\Models\Subscription;
use ChargeBee\ChargeBee\Models\Invoice;
use ChargeBee\ChargeBee\Models\Customer;
use Stripe;

class ChargebeeWebhookController extends Controller
{
    use SendMail,PricingHelper, ChargebeePlan;

    /**
     * handle chargebee webhook calls
     *
     * @return \Illuminate\Http\Response
     */
    public function handleWebhookCall(Request $request)
    {
        try {
            Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
            if (isset($_POST)) {
                // check whether valid request from chargebee - (RANDOM KEY or BASIC AUTH)
                if($_REQUEST['webhook_key'] != Config::get('app.chargebee_webhook_key') ) {
                    header("HTTP/1.0 403 Error");
                    return false;
                }
                $raw_input = file_get_contents('php://input');
                $event_data = Event::deserialize($raw_input);
                if ($event_data) {
                    DB::beginTransaction();
                    $is_alrady_processed = ChargebeeWebhookExcecution::where('event_id', $event_data->id)->first();
                    if ($is_alrady_processed) {
                        throw new \Exception('This chargebee webhookevent already processed');
                    }
                    $allowed_CB_events = ['payment_succeeded','payment_failed', 'subscription_cancelled', 'subscription_reactivated', 'payment_source_expiring' ,'subscription_changed', 'payment_initiated', 'transaction_updated', 'contract_term_renewed', 'contract_term_created'];
                    if (in_array($event_data->eventType, $allowed_CB_events)) {
                        if($event_data->source != 'api' || $event_data->eventType == 'payment_succeeded' || $event_data->eventType == 'payment_initiated'){
                            $chargebee_webhook_excecution = ChargebeeWebhookExcecution::create([
                                'event_id' => $event_data->id,
                                'start' => now(),
                            ]);
                        }
                        switch ($event_data->eventType) {
                            case 'payment_initiated':
                                $this->_handlePaymentInitiatedEvent($event_data);
                                break;
                            case 'payment_succeeded':
                                $this->_handlePaymentSucceededEvent($event_data);
                                break;
                            case 'payment_failed':
                                if($event_data->source != 'api'){
                                    $this->_handlePaymentFailedEvent($event_data);
                                }
                                break;
                            case 'transaction_updated':
                                if($event_data->source != 'api' && $event_data->content['transaction']['payment_method'] == 'direct_debit' && $event_data->content['transaction']['status'] == 'failure' && count($event_data->content['transaction']['linked_invoices']) > 1){
                                    $this->_makeAccountFrozen($event_data->content['transaction']['customer_id'], $event_data->content['transaction']['subscription_id']);
                                }
                                break;
                            case 'subscription_cancelled':
                                if($event_data->source != 'api'){
                                    $this->_handleSubscriptionCancelledEvent($event_data);
                                }
                                break;
                            case 'subscription_reactivated':
                                if($event_data->source != 'api'){
                                    $this->_handleSubscriptionReactivatedEvent($event_data);
                                }
                                break;
                            case 'payment_source_expiring':
                                if($event_data->source != 'api' && $event_data->content['payment_source']['type'] == "card"){
                                    $this->_handleCardExpiryReminderEvent($event_data);
                                }
                                break;
                            case 'subscription_changed':
                                if($event_data->source != 'api'){
                                    $this->_handleSubscriptionChangedEvent($event_data);
                                }
                                break;
                            case 'contract_term_renewed':
                                if($event_data->source != 'api'){
                                    $this->_handleContractTermRenewedEvent($event_data);
                                }
                                break;
                            case 'contract_term_created':
                                    $this->_handleContractTermCreatedEvent($event_data);
                                break;
                            default:
                                // no logic should go here
                        }
                        if($event_data->source != 'api' || $event_data->eventType == 'payment_succeeded' || $event_data->eventType == 'payment_initiated'){
                            $chargebee_webhook_excecution->update([
                                'end' => now(),
                            ]);
                        }
                    }
                    DB::commit();
                }
                header("HTTP/1.0 200 Success");
                return true;
            }
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('ChargebeeWebhookController/handleWebhookCall() => ' . $e->getMessage());
            header("HTTP/1.0 500 Error");
            return false;
        }
    }

    private function _handlePaymentInitiatedEvent($event_data)
    {
        try {
            $user = User::where('chargebee_customer_id', $event_data->content['customer']['id'])->where('chargebee_subscription_id', $event_data->content['subscription']['id'])->with(['reseller'])->first();
            if ($user && $event_data->content['subscription']['status'] == 'active') {
                $this->_makeAccountUnFrozen($event_data);
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_handlePaymentInitiatedEvent() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_handlePaymentInitiatedEvent()[data] => '.json_encode($event_data));
        }
    }
    private function _handlePaymentSucceededEvent($event_data)
    {
        try {
            $user = User::where('chargebee_customer_id', $event_data->content['customer']['id'])->where('chargebee_subscription_id', $event_data->content['subscription']['id'])->with(['reseller'])->first();
            if ($user && $event_data->content['subscription']['status'] == 'active') {
                $this->_makeAccountUnFrozen($event_data);
                Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
                if($event_data->source != 'api'){
                    $subscription_response = Subscription::retrieve($user->chargebee_subscription_id);
                    $subscription = $subscription_response->subscription();
                    $plan_type = 'Yearly';
                    if($subscription->billingPeriodUnit != "year"){
                        if($subscription->billingPeriod == 6){
                            $plan_type = 'Bi-Annually';
                        }else if($subscription->billingPeriod == 3){
                            $plan_type = 'Quarterly';
                        }else{
                            $plan_type = 'Monthly';
                        }
                    }
                    $transaction_fee = 0;
                    $final_payment_price =(($event_data->content['invoice']['status'] == 'payment_due')?$event_data->content['invoice']['amount_due']:$event_data->content['invoice']['amount_paid']) / 100;
                    $charge_price = $final_payment_price;
                    if($user->is_sra_user == 0){
                        $chargebee_plan_ids = $this->getChargebeePlanId(strtolower(str_replace("-","",$plan_type)),$user->chargebe_addon_type);
                        $transaction_fee_item_id = $chargebee_plan_ids['transaction_fee_item_id'];
                        foreach ($event_data->content['invoice']['line_items'] as $key => $value) {
                            if($value['entity_id'] == $transaction_fee_item_id){
                                $transaction_fee = $value['amount'] / 100;
                            }
                        }
                    }
                    $final_payment_price = round($final_payment_price - $transaction_fee, 2);
                    $sales_tax = [];
                    $sales_tax_percentage = 0;
                    if(isset($event_data->content['invoice']['taxes']) && !empty($event_data->content['invoice']['taxes'])){
                        foreach ($event_data->content['invoice']['taxes'] as $key => $value) {
                            $sales_tax[] = array(
                                'amount' => $value['amount'] / 100
                            );
                        }
                        foreach ($event_data->content['invoice']['line_items'] as $key => $value) {
                            $sales_tax_percentage  = (isset($value['tax_rate']))?$value['tax_rate']:0;
                        }
                    }
                    if(!empty($sales_tax)){
                        $final_payment_price = round($final_payment_price - array_sum(array_column($sales_tax, 'amount')), 2);
                    }
                    $final_discount_price = 0;
                    $final_promocode = '';
                    if(isset($event_data->content['invoice']['discounts'][0]) && !empty($event_data->content['invoice']['discounts'][0])){
                        $final_discount_price = $event_data->content['invoice']['discounts'][0]['amount'] / 100;
                        $final_promocode = $event_data->content['invoice']['discounts'][0]['entity_id'];
                    }
                    if($final_discount_price > 0){
                        $final_payment_price = round($final_payment_price + $final_discount_price, 2);
                    }
                    $date = Carbon::now()->setTimezone($user->timezone);
                    if($user->is_active == 1){
                        $emailTemplate = EmailTemplate::where('code', 'HCE-AE16')->first();
                        $email_vars = [
                            '{%CHRGEBEE_INVOICE_ID%}' => $event_data->content['invoice']['id'],
                            '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user->first_name,
                            '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user->last_name,
                            '{%PHONE_NUMBER%}' => $user->phone_number,
                            '{%COMPANY_NAME%}' => $user->company_name,
                            '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user->email,
                            '{%PROMO_CODE%}' => $final_promocode,
                            '{%PRICE%}' => $this->formatPrice($final_payment_price),
                            '{%PROMO_DISCOUNT%}' => $this->formatPrice($final_discount_price),
                            '{%DISCOUNT_PRICE%}' => $this->formatPrice(round(($final_payment_price - $final_discount_price), 2)),
                            '{%SALES_TAX_PERCENTAGE%}' =>$this->formatPrice((!empty($sales_tax))?$sales_tax_percentage:0),
                            '{%SALES_TAX_AMOUNT%}' => $this->formatPrice((!empty($sales_tax))?array_sum(array_column($sales_tax, 'amount')):0),
                            '{%TRANSACTION_FEE_AMOUNT%}' => $this->formatPrice($transaction_fee),
                            '{%PAYMENT_PRICE%}' => $this->formatPrice($charge_price),
                            '{%PAYMENT_TERM%}' => ucfirst($plan_type),
                            '{%PAYMENT_DATE%}' => Carbon::parse($date)->format('Y-m-d'),
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                            /** Send mail to reseller*/
                        if (! empty($user->partner_reseller_id)){
                            $subject = str_ireplace(['{%RESELLER%}'], [$user->reseller->name],$emailTemplate->reseller_subject);
                        }
                    
                        /** End Send mail to reseller*/
                        $this->sendEmail($emailTemplate->code, $html, Config::get('app.finance_group_email'), Config::get('app.from_admin_email'), $subject ?? $emailTemplate->subject,null,null,true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                    }
                    //send invoice in attachment to reseller                
                    $emailTemplate_HCE_AE24 = EmailTemplate::where('code', 'HCE-AE24')->first();
                    if ($user->partner_reseller_id != null && $user->is_active == 1)
                    {
                        $attachment_invoice = null;
                        $chargebee_invoice_download = Invoice::pdf($event_data->content['invoice']['id'], ['dispositionType' => 'attachment']);
                        $chargebee_invoice_pdf = $chargebee_invoice_download->download();
                        $attachment_invoice = storage_path('app/public').'/generatedpolicydocuments/'.'Abyde_Receipt_'.strtotime($user->created_at).'.pdf';
                        file_put_contents($attachment_invoice, file_get_contents($chargebee_invoice_pdf->downloadUrl));
                        $email_vars = [                                
                            '{%PAYMENT_TERM%}' => ucfirst($plan_type),
                            '{%CUSTOMER_NAME%}' => $user->first_name.' '.$user->last_name,
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                            '{%ADMIN_PORTAL%}' => Config::get('app.url') . "/pkO0OA17otP61RwETtNn",
                        ];   
                        $admin_subject = str_ireplace('{%RESELLER%}', $user->reseller->name, $emailTemplate_HCE_AE24->reseller_subject);
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate_HCE_AE24->body);                            
                        $this->sendEmail($emailTemplate_HCE_AE24->code, $html, $user->reseller->email, Config::get('app.from_admin_email'), $admin_subject, $attachment_invoice, null, true, $user->reseller->logo, $user->id);                        
                    }
                    Log::info('Plan renewal success for user id: '.$user->id);
                }

                if($event_data->source != 'api'){
                    if(isset($event_data->content['transaction']['payment_source_id']) && $event_data->content['transaction']['payment_source_id'] != null){
                        $subscriptionDetails = $this->getSubscriptionDetails($event_data->content['subscription']['id'],true);
                        $user_payment_source = $subscriptionDetails['payment_source'] ?? null;
                        $user_payment_source_same = (!empty($user_payment_source) && isset($user_payment_source['id']) && $user_payment_source['id'] == $event_data->content['transaction']['payment_source_id']) ? $user_payment_source : null;
                        if($user_payment_source_same == null){
                            $paymentSourceResponse = PaymentSource::retrieve($event_data->content['transaction']['payment_source_id']);
                            $paymentSource = $paymentSourceResponse->paymentSource()->getValues();
                            Subscription::overrideBillingProfile($user->chargebee_subscription_id,array(
                                "paymentSourceId" =>$event_data->content['transaction']['payment_source_id'],
                            ));
                            if($user->is_active == 1){
                                $emailTemplate = EmailTemplate::where('code', 'HCE-UE21')->first();
                                $email_vars = [
                                    '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user->first_name,
                                    '{%COMPANY_NAME%}' => $user->company_name,
                                    '{%PAYMENT_METHOD%}' => ($paymentSource['type'] == 'card') ? 'Card' : 'Bank',
                                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                    '{%SUPPORT_PHONE%}' => Config::get('app.support_phone_number'),
                                    '{%SUPPORT_PHONE_NUMBER_DISPLAY%}' => Config::get('app.support_phone_number_display'),
                                ];
                                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user->company_name], $emailTemplate->subject);
                                $this->sendEmail($emailTemplate->code, $html, $user->email, Config::get('app.from_user_email'), $html_subject,null,null,true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                                $emailTemplate = EmailTemplate::where('code', 'HCE-AE3')->first();
                                $email_vars = [
                                    '{%USER_FIRST_NAME%}' => $user->first_name,
                                    '{%USER_LAST_NAME%}' => $user->last_name,
                                    '{%COMPANY_NAME%}' => $user->company_name,
                                    '{%EMAIL%}' => $user->email,
                                    '{%PAYMENT_METHOD%}' => ($paymentSource['type'] == 'card') ? 'Card' : 'Bank',
                                    '{%LAST_4_DIGITS%}' => ($paymentSource['type'] == 'card')?$paymentSource['card']['last4']:$paymentSource['bank_account']['last4']
                                ];
                                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                /** Send mail to reseller*/
                                if (!empty($user->partner_reseller_id)){
                                    $subject = str_ireplace(['{%RESELLER%}'], [$user->reseller->name],$emailTemplate->reseller_subject);
                                    $this->sendEmail($emailTemplate->code, $html,  $user->reseller->email, Config::get('app.from_admin_email'), $subject,null,null,true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                                }
                                /** End Send mail to reseller*/
                                $this->sendEmail($emailTemplate->code, $html, Config::get('app.finance_group_email'), Config::get('app.from_admin_email'), $subject ?? $emailTemplate->subject,null,null,true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                            }
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_handlePaymentSucceededEvent() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_handlePaymentSucceededEvent()[data] => '.json_encode($event_data));
        }
    }

    private function _makeAccountUnFrozen($event_data){
        try {
            $user = User::where('chargebee_customer_id', $event_data->content['customer']['id'])->where('chargebee_subscription_id', $event_data->content['subscription']['id'])->with(['reseller'])->first();
            if ($user && $event_data->content['subscription']['status'] == 'active') {
                Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
                $is_unpaid_invoice_avail = Invoice::all([
                    "customerId[is]" => $event_data->content['customer']['id'],
                    "subscriptionId[is]" => $event_data->content['subscription']['id'],
                    "status[is]" => "not_paid"
                ]);
                $is_unpaid_inprogress_invoice_avail = Invoice::all([
                    "customerId[is]" => $event_data->content['customer']['id'],
                    "subscriptionId[is]" => $event_data->content['subscription']['id'],
                    "status[is]" => "payment_due",
                    "dunningStatus[is]" => "in_progress"
                ]);
                $total_pending_invoice = count($is_unpaid_invoice_avail) + count($is_unpaid_inprogress_invoice_avail);
                if ($user->account_status == 'Frozen' &&
                    (
                        ($event_data->eventType == 'payment_succeeded' && $total_pending_invoice == 0) ||
                        ($event_data->eventType == 'payment_initiated' && count($event_data->content['transaction']['linked_invoices']) == $total_pending_invoice)
                    )
                    ) {
                    User::where('id',$user->id)->update([
                        'account_status' => 'Unfrozen'
                    ]);
                    if($user->is_active == 1){
                        $emailTemplate = EmailTemplate::where('code', 'HCE-UE24')->first();
                        $email_vars = [
                            '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user->first_name,
                            '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        $this->sendEmail($emailTemplate->code, $html, $user->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                        $emailTemplate = EmailTemplate::where('code', 'HCE-AE11')->first();
                        $email_vars = [
                            '{%PRIMARY_COMPLIANCE_OFFICER_NAME%}' => $user->first_name . ' ' . $user->last_name,
                            '{%COMPANY_NAME%}' => $user->company_name,
                            '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user->email,
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        /** Send mail to reseller*/
                        if (!empty($user->partner_reseller_id)) {
                            $subject = str_ireplace(['{%RESELLER%}'], [$user->reseller->name], $emailTemplate->reseller_subject);
                        }
                        /** End Send mail to reseller*/
                        $this->sendEmail($emailTemplate->code, $html, Config::get('app.finance_group_email'), Config::get('app.from_admin_email'), $subject ?? $emailTemplate->subject, null, null,true, ($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_makeAccountUnFrozen() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_makeAccountUnFrozen()[data] => '.json_encode($event_data));
        }
    }

    private function _handlePaymentFailedEvent($event_data)
    {
        try {
            $user = User::where('chargebee_customer_id', $event_data->content['customer']['id'])->where('chargebee_subscription_id', $event_data->content['subscription']['id'])->with(['reseller'])->first();
            if ($user && $event_data->content['subscription']['status'] == 'active') {
                $this->_makeAccountFrozen($event_data->content['customer']['id'], $event_data->content['subscription']['id']);
                
                Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
                $subscription_response = Subscription::retrieve($user->chargebee_subscription_id);
                $subscription = $subscription_response->subscription();
                $plan_type = 'Yearly';
                if($subscription->billingPeriodUnit != "year"){
                    if($subscription->billingPeriod == 6){
                        $plan_type = 'Bi-Annually';
                    }else if($subscription->billingPeriod == 3){
                        $plan_type = 'Quarterly';
                    }else{
                        $plan_type = 'Monthly';
                    }
                }
                $transaction_fee = 0;
                $final_payment_price = (($event_data->content['invoice']['status'] == 'payment_due')?$event_data->content['invoice']['amount_due']:$event_data->content['invoice']['amount_paid']) / 100;
                $charge_price = $final_payment_price;
                if($user->is_sra_user == 0){
                    $chargebee_plan_ids = $this->getChargebeePlanId(strtolower(str_replace("-","",$plan_type)),$user->chargebe_addon_type);
                    $transaction_fee_item_id = $chargebee_plan_ids['transaction_fee_item_id'];
                    foreach ($event_data->content['invoice']['line_items'] as $key => $value) {
                        if($value['entity_id'] == $transaction_fee_item_id){
                                $transaction_fee = $value['amount'] / 100;
                        }
                    }
                }
                $final_payment_price = round($final_payment_price - $transaction_fee, 2);
                $sales_tax = [];
                $sales_tax_percentage = 0;
                if(isset($event_data->content['invoice']['taxes']) && !empty($event_data->content['invoice']['taxes'])){
                    foreach ($event_data->content['invoice']['taxes'] as $key => $value) {
                        $sales_tax[] = array(
                            'amount' => $value['amount'] / 100
                        );
                    }
                    foreach ($event_data->content['invoice']['line_items'] as $key => $value) {
                        $sales_tax_percentage  = (isset($value['tax_rate']))?$value['tax_rate']:0;
                    }
                }
                if(!empty($sales_tax)){
                    $final_payment_price = round($final_payment_price - array_sum(array_column($sales_tax, 'amount')), 2);
                }
                $final_discount_price = 0;
                $final_promocode = '';
                if(isset($event_data->content['invoice']['discounts'][0]) && !empty($event_data->content['invoice']['discounts'][0])){
                    $final_discount_price = $event_data->content['invoice']['discounts'][0]['amount'] / 100;
                    $final_promocode = $event_data->content['invoice']['discounts'][0]['entity_id'];
                }
                if($final_discount_price > 0){
                    $final_payment_price = round($final_payment_price + $final_discount_price, 2);
                }
                $date = Carbon::now()->setTimezone($user->timezone);
                if($user->is_active == 1){
                    $emailTemplate = EmailTemplate::where('code', 'HCE-AE9')->first();
                    $email_vars = [
                        '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user->first_name,
                        '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user->last_name,
                        '{%COMPANY_NAME%}' => $user->company_name,
                        '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user->email,
                        '{%PROMO_CODE%}' => $final_promocode,
                        '{%PRICE%}' => $this->formatPrice($final_payment_price),
                        '{%PROMO_DISCOUNT%}' => $this->formatPrice($final_discount_price),
                        '{%DISCOUNT_PRICE%}' => $this->formatPrice(round(($final_payment_price - $final_discount_price), 2)),
                        '{%SALES_TAX_PERCENTAGE%}' => $this->formatPrice((!empty($sales_tax))?$sales_tax_percentage:0),
                        '{%SALES_TAX_AMOUNT%}' => $this->formatPrice((!empty($sales_tax))?array_sum(array_column($sales_tax, 'amount')):0),
                        '{%TRANSACTION_FEE_AMOUNT%}' => $this->formatPrice($transaction_fee),
                        '{%PAYMENT_PRICE%}' => $this->formatPrice($charge_price),
                        '{%PAYMENT_TERM%}' => $plan_type,
                        '{%PAYMENT_DATE%}' => Carbon::parse($date)->format('Y-m-d'),
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    /** Send mail to reseller*/
                    if (! empty($user->partner_reseller_id)){
                        $subject = str_ireplace(['{%RESELLER%}'], [$user->reseller->name],$emailTemplate->reseller_subject);
                    }
                    /** End Send mail to reseller*/
                    $this->sendEmail($emailTemplate->code, $html, [Config::get('app.finance_group_email'), Config::get('app.cs_group_email')], Config::get('app.from_admin_email'), $subject ?? $emailTemplate->subject,null,null,true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                    //send invoice in attachment to reseller                
                    $emailTemplate_HCE_AE24 = EmailTemplate::where('code', 'HCE-AE24')->first();
                    if ($user->partner_reseller_id != null && $user->is_active == 1)
                    {
                        $attachment_invoice = null;
                        $chargebee_invoice_download = Invoice::pdf($event_data->content['invoice']['id'], ['dispositionType' => 'attachment']);
                        $chargebee_invoice_pdf = $chargebee_invoice_download->download();
                        $attachment_invoice = storage_path('app/public').'/generatedpolicydocuments/'.'Abyde_Receipt_'.strtotime($user->created_at).'.pdf';
                        file_put_contents($attachment_invoice, file_get_contents($chargebee_invoice_pdf->downloadUrl));
                        $email_vars = [                                
                            '{%PAYMENT_TERM%}' => ucfirst($plan_type),
                            '{%CUSTOMER_NAME%}' => $user->first_name.' '.$user->last_name,
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                            '{%ADMIN_PORTAL%}' => Config::get('app.url') . "/pkO0OA17otP61RwETtNn",
                        ];   
                        $admin_subject = str_ireplace('{%RESELLER%}', $user->reseller->name, $emailTemplate_HCE_AE24->reseller_subject);
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate_HCE_AE24->body);                            
                        $this->sendEmail($emailTemplate_HCE_AE24->code, $html, $user->reseller->email, Config::get('app.from_admin_email'), $admin_subject, $attachment_invoice, null, true, $user->reseller->logo, $user->id);                        
                    }
                }
                Log::info('Plan renewal failed for user id '.$user->id);
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_handlePaymentFailedEvent() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_handlePaymentFailedEvent()[data] => '.json_encode($event_data));
        }
    }

    private function _makeAccountFrozen($customer_id, $subscription_id){
        try {
            $user = User::where('chargebee_customer_id', $customer_id)->where('chargebee_subscription_id', $subscription_id)->with(['reseller'])->first();
            if ($user && ($user->is_active == 1 || ($user->is_active == 0 && $user->is_account_verified == 0))) {
                if ($user->account_status == 'Unfrozen') {
                    $user->update([
                        'account_status' => 'Frozen',
                    ]);
                    if($user->is_active == 1 || ($user->is_active == 0 && $user->is_account_verified == 0)){
                        // send email to user
                        $emailTemplate = EmailTemplate::where('code', 'HCE-UE25')->first();
                        $email_vars = [
                            '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user->first_name,
                            '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        $this->sendEmail($emailTemplate->code, $html, $user->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null,true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                        // send email to admin OAE10 and HCE-AE10
                        $emailTemplate = EmailTemplate::where('code', 'HCE-AE10')->first();
                        $email_vars = [
                            '{%PRIMARY_COMPLIANCE_OFFICER_NAME%}' => $user->first_name . ' ' . $user->last_name,
                            '{%COMPANY_NAME%}' => $user->company_name,
                            '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user->email,
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        /** Send mail to reseller*/
                        if (!empty($user->partner_reseller_id)) {
                            $subject = str_ireplace(['{%RESELLER%}'], [$user->reseller->name], $emailTemplate->reseller_subject);
                        }
                        /** End Send mail to reseller*/
                        $this->sendEmail($emailTemplate->code, $html, Config::get('app.finance_group_email'), Config::get('app.from_admin_email'), $subject ?? $emailTemplate->subject, null, null,true, ($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_makeAccountFrozen() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_makeAccountFrozen()[data] => '.json_encode([$customer_id, $subscription_id]));
        }
    }

    private function _handleSubscriptionCancelledEvent($event_data)
    {
        try {
            $user = User::where('chargebee_customer_id', $event_data->content['customer']['id'])->where('chargebee_subscription_id', $event_data->content['subscription']['id'])->with(['reseller'])->first();
            if ($user) {
                $user->update([
                    'is_active' => 0,
                ]);
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_handleSubscriptionCancelledEvent() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_handleSubscriptionCancelledEvent()[data] => '.json_encode($event_data));
        }
    }

    private function _handleSubscriptionReactivatedEvent($event_data)
    {
        try {
            $user = User::where('chargebee_customer_id', $event_data->content['customer']['id'])->where('chargebee_subscription_id', $event_data->content['subscription']['id'])->with(['reseller'])->first();
            if ($user) {
                $user->update([
                    'is_active' => 1,
                ]);
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_handleSubscriptionReactivatedEvent() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_handleSubscriptionReactivatedEvent()[data] => '.json_encode($event_data));
        }
    }

    private function _handleCardExpiryReminderEvent($event_data){
        try {
            $user = User::where('chargebee_customer_id', $event_data->content['payment_source']['customer_id'])->with(['reseller'])->first();
            if($user && $user->is_active == 1){
                Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
                $subscription_response = Subscription::retrieve($user->chargebee_subscription_id);
                $subscription = $subscription_response->subscription();
                if($subscription->paymentSourceId == $event_data->content['payment_source']['id']){
                    $plan_type = 'Yearly';
                    if($subscription->billingPeriodUnit != "year"){
                        if($subscription->billingPeriod == 6){
                            $plan_type = 'Bi-Annually';
                        }else if($subscription->billingPeriod == 3){
                            $plan_type = 'Quarterly';
                        }else{
                            $plan_type = 'Monthly';
                        }
                    }
                    if($user->is_active == 1){
                        $emailTemplate = EmailTemplate::where('code', 'HCE-UE28')->first();
                        $email_vars = [
                            '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user->first_name,
                            '{%PAYMENT_TERM%}' => $plan_type,
                            '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user->company_name], $emailTemplate->subject);
                        $this->sendEmail($emailTemplate->code, $html, $user->email, Config::get('app.from_user_email'), $html_subject,null,null,true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_handleCardExpiryReminderEvent() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_handleCardExpiryReminderEvent()[data] => '.json_encode($event_data));
        }
    }

    private function _handleSubscriptionChangedEvent($event_data){
        try {
            $user = User::with('reseller')->where('chargebee_customer_id', $event_data->content['customer']['id'])->where('chargebee_subscription_id', $event_data->content['subscription']['id'])->with(['reseller'])->first();
            if($user && $event_data->content['subscription']['status'] == 'active'){
                if(Carbon::parse($user->contract_renewal_date)->format('Y-m-d') != Carbon::parse($event_data->content['subscription']['contract_term']['contract_end'])->format('Y-m-d')){
                    $user_contract_date_array = [
                        'contract_renewal_date' => Carbon::parse($event_data->content['subscription']['contract_term']['contract_end'])->format('Y-m-d'),
                    ];
                    if(Carbon::parse($user->chargebe_first_contract_end_date)->format('Y-m-d') > Carbon::now()->format('Y-m-d')){
                        $user_contract_date_array ['chargebe_first_contract_end_date'] = Carbon::parse($event_data->content['subscription']['contract_term']['contract_end'])->subDay()->format('Y-m-d');
                    }
                    if(Carbon::parse($user->chargebee_first_renewal_date)->format('Y-m-d') > Carbon::now()->format('Y-m-d')){
                        $user_contract_date_array ['chargebee_first_renewal_date'] = Carbon::parse($event_data->content['subscription']['next_billing_at'])->format('Y-m-d');                        
                    }
                    $user->update($user_contract_date_array);
                }
                $this->_sendChangePromocodeEmail($user);
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_handleSubscriptionChangedEvent() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_handleSubscriptionChangedEvent()[data] => '.json_encode($event_data));
        }
    }

    private function _sendChangePromocodeEmail($user){
        try {
            Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
            $invoice_estimate_response = Estimate::renewalEstimate(
                $user->chargebee_subscription_id,
                array(
                    'ignoreScheduledCancellation' => true,
                    'ignoreScheduledChanges' => true,
                )
            );
            $invoice_estimate = $invoice_estimate_response->estimate();
            if($invoice_estimate->subscriptionEstimate->status == 'active' || $invoice_estimate->subscriptionEstimate->status == 'non_renewing'){
                $subscription_response = Subscription::retrieve($user->chargebee_subscription_id);
                $subscription = $subscription_response->subscription();
                $plan_type = 'Yearly';
                if($subscription->billingPeriodUnit != "year"){
                    if($subscription->billingPeriod == 6){
                        $plan_type = 'Bi-Annually';
                    }else if($subscription->billingPeriod == 3){
                        $plan_type = 'Quarterly';
                    }else{
                        $plan_type = 'Monthly';
                    }
                }
                $transaction_fee = 0;
                $payment_price = $invoice_estimate->invoiceEstimate->total / 100;
                $charge_price = $payment_price;
                if($user->is_sra_user == 0){
                    $chargebee_plan_ids = $this->getChargebeePlanId(strtolower(str_replace("-","",$plan_type)),$user->chargebe_addon_type);
                    $transaction_fee_item_id = $chargebee_plan_ids['transaction_fee_item_id'];
                    foreach ($invoice_estimate->invoiceEstimate->lineItems as $key => $value) {
                        if($value->entityId == $transaction_fee_item_id){
                            $transaction_fee = $value->amount / 100;
                        }
                    }
                }
                $payment_price = round($payment_price - $transaction_fee, 2);
                $sales_tax = [];
                $sales_tax_percentage = 0;
                if(isset($invoice_estimate->invoiceEstimate->taxes) && !empty($invoice_estimate->invoiceEstimate->taxes)){
                    foreach ($invoice_estimate->invoiceEstimate->taxes as $key => $value) {
                        $sales_tax[] = array(
                            'amount' => $value->amount / 100
                        );
                    }
                    foreach ($invoice_estimate->invoiceEstimate->lineItems as $key => $value) {
                        $sales_tax_percentage  = (isset($value->taxRate))?$value->taxRate:0;
                    }
                }
                if(!empty($sales_tax)){
                    $payment_price = round($payment_price - array_sum(array_column($sales_tax, 'amount')), 2);
                }
                $discount_price = 0;
                $promocode = '';
                if(isset($invoice_estimate->invoiceEstimate->discounts[0]) && !empty($invoice_estimate->invoiceEstimate->discounts[0])){
                    $discount_price = $invoice_estimate->invoiceEstimate->discounts[0]->amount / 100;
                    $promocode = $invoice_estimate->invoiceEstimate->discounts[0]->entityId;
                }
                if($discount_price > 0){
                    $payment_price = round($payment_price + $discount_price, 2);
                }
                $location_limit = 0;
                $employee_limit = 0;
                foreach($subscription->subscriptionItems as $subscriptionItems){
                    if($subscriptionItems->itemType == 'addon' && str_contains($subscriptionItems->itemPriceId, 'Locations')){
                        $location_limit = $subscriptionItems->quantity;
                    } else if($subscriptionItems->itemType == 'plan' && str_contains($subscriptionItems->itemPriceId, 'SRA-ONLY')){
                        $location_limit = $subscriptionItems->quantity;
                    }
                    if($subscriptionItems->itemType == 'addon' && str_contains($subscriptionItems->itemPriceId, 'Employees')){
                        $employee_limit = $subscriptionItems->quantity;
                    }
                }
                        
                if($user->is_active == 1){
                    $emailTemplate = EmailTemplate::where('code', 'HCE-AE6')->first();
                    $email_vars = [
                        '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user->first_name,
                        '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user->last_name,
                        '{%COMPANY_NAME%}' => $user->company_name,
                        '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user->email,
                        '{%NUMBERS_OF_LOCATIONS%}' => $location_limit,
                        '{%EMPLOYEE_RANGE%}' => $employee_limit,
                        '{%PRICE%}' => $this->formatPrice($payment_price),
                        '{%PROMO_CODE%}' => $promocode,
                        '{%PROMO_DISCOUNT%}' => $this->formatPrice($discount_price),
                        '{%DISCOUNT_PRICE%}' => $this->formatPrice(round(($payment_price - $discount_price), 2)),
                        '{%SALES_TAX_PERCENTAGE%}' => $this->formatPrice((!empty($sales_tax))?$sales_tax_percentage:0),
                        '{%SALES_TAX_AMOUNT%}' =>$this->formatPrice((!empty($sales_tax))?array_sum(array_column($sales_tax, 'amount')):0),
                        '{%TRANSACTION_FEE_AMOUNT%}' => $this->formatPrice($transaction_fee),
                        '{%PAYMENT_PRICE%}' => $this->formatPrice($charge_price),
                        '{%PAYMENT_TERM%}' => $plan_type,
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    /** Send mail to reseller*/
                    if (! empty($user->partner_reseller_id)){
                        $subject = str_ireplace(['{%RESELLER%}'], [$user->reseller->name],$emailTemplate->reseller_subject);
                    }
                    /** End Send mail to reseller*/
                    $this->sendEmail($emailTemplate->code, $html, Config::get('app.finance_group_email'), Config::get('app.from_admin_email'), $subject ?? $emailTemplate->subject,null,null,true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                }
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_sendChangePromocodeEmail() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_sendChangePromocodeEmail()[data] => '.json_encode($user));
        }
    }

    private function _handleContractTermRenewedEvent($event_data){
        try {
            $user = User::with(['reseller'])->where('chargebee_subscription_id', $event_data->content['contract_term']['subscription_id'])->first();
            if($user && $user->is_active == 1){
                $location_ids = Location::where('user_id', $user->id)->pluck('id');
                TrainingLocation::where('is_triggered', 0)->where('is_disable', 1)->whereIn('location_id', $location_ids)->update([
                    'is_disable' => 0,
                ]);
                Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
                $subscription_response = Subscription::retrieve($user->chargebee_subscription_id);
                $subscription = $subscription_response->subscription();
                $plan_type = 'Yearly';
                if($subscription->billingPeriodUnit != "year"){
                    if($subscription->billingPeriod == 6){
                        $plan_type = 'Bi-Annually';
                    }else if($subscription->billingPeriod == 3){
                        $plan_type = 'Quarterly';
                    }else{
                        $plan_type = 'Monthly';
                    }
                }
                $location_limit = 0;
                $employee_limit = 0;
                foreach($subscription->subscriptionItems as $subscriptionItems){
                    if($subscriptionItems->itemType == 'addon' && str_contains($subscriptionItems->itemPriceId, 'Locations')){
                        $location_limit = $subscriptionItems->quantity;
                    } else if($subscriptionItems->itemType == 'plan' && str_contains($subscriptionItems->itemPriceId, 'SRA-ONLY')){
                        $location_limit = $subscriptionItems->quantity;
                    }
                    if($subscriptionItems->itemType == 'addon' && str_contains($subscriptionItems->itemPriceId, 'Employees')){
                        $employee_limit = $subscriptionItems->quantity;
                    }
                }
                        
                if($user->chargebe_addon_type == 'new'){
                    if($user->is_sra_user == 1){
                        $chargebee_plan_ids = $this->getChargebeePlanId(strtolower(str_replace("-","",$plan_type)),'renewal','sra_only');
                        $is_location_plan_renewal = 0;
                        foreach($subscription->subscriptionItems as $subscriptionItems){
                            if($chargebee_plan_ids['plan_item_id'] == $subscriptionItems->itemPriceId){
                                $is_location_plan_renewal = 1;
                            }
                        }
                        if($is_location_plan_renewal == 1 ){
                            $user->update([
                                'chargebe_addon_type' => 'renewal'
                            ]);
                        }
                    }else{
                        $version = 'v2';
                        foreach ($subscription->itemTiers as $item_tiers) {
                            if(str_contains($item_tiers->itemPriceId, 'Employees') && !empty($item_tiers->endingUnit) && $item_tiers->endingUnit == 5){
                                $version = 'v1';
                                break;
                            }
                        }
                        $chargebee_plan_ids = $this->getChargebeePlanId(strtolower(str_replace("-","",$plan_type)),'renewal', 'normal', $version);
                        $is_location_plan_renewal = 0;
                        $is_employee_plan_renewal = 0;
                        foreach($subscription->subscriptionItems as $subscriptionItems){
                            if($chargebee_plan_ids['location_item_id'] == $subscriptionItems->itemPriceId){
                                $is_location_plan_renewal = 1;
                            }
                            if($chargebee_plan_ids['employee_item_id'] == $subscriptionItems->itemPriceId){
                                $is_employee_plan_renewal = 1;
                            }
                        }
                        if($is_location_plan_renewal == 1 && $is_employee_plan_renewal == 1){
                            $user->update([
                                'chargebe_addon_type' => 'renewal'
                            ]);
                        }
                    }
                }
                $user->update([
                    'contract_renewal_date' => Carbon::parse($event_data->content['contract_term']['contract_end'])->format('Y-m-d')
                ]);
                if($subscription->status == 'active' || $subscription->status == 'non_renewing'){
                    $invoice_estimate_response = Estimate::renewalEstimate(
                        $user->chargebee_subscription_id,
                        array(
                            'ignoreScheduledCancellation' => true,
                            'ignoreScheduledChanges' => true,
                        )
                    );
                    $invoice_estimate = $invoice_estimate_response->estimate();
                    $transaction_fee = 0;
                    $payment_price = $invoice_estimate->invoiceEstimate->total / 100;
                    $charge_price = $payment_price;
                    if($user->is_sra_user == 0){
                        $chargebee_plan_ids = $this->getChargebeePlanId(strtolower(str_replace("-","",$plan_type)),$user->chargebe_addon_type);
                        $transaction_fee_item_id = $chargebee_plan_ids['transaction_fee_item_id'];
                        foreach ($invoice_estimate->invoiceEstimate->lineItems as $key => $value) {
                            if($value->entityId == $transaction_fee_item_id){
                                $transaction_fee = $value->amount / 100;
                            }
                        }
                    }
                    $payment_price = round($payment_price - $transaction_fee, 2);
                    $sales_tax = [];
                    $sales_tax_percentage = 0;
                    if(isset($invoice_estimate->invoiceEstimate->taxes) && !empty($invoice_estimate->invoiceEstimate->taxes)){
                        foreach ($invoice_estimate->invoiceEstimate->taxes as $key => $value) {
                            $sales_tax[] = array(
                                'amount' => $value->amount / 100
                            );
                        }
                        foreach ($invoice_estimate->invoiceEstimate->lineItems as $key => $value) {
                            $sales_tax_percentage  = (isset($value->taxRate))?$value->taxRate:0;
                        }
                    }
                    if(!empty($sales_tax)){
                        $payment_price = round($payment_price - array_sum(array_column($sales_tax, 'amount')), 2);
                    }
                    $discount_price = 0;
                    $discount_percentage = 0;
                    $promocode = '';
                    if(isset($invoice_estimate->invoiceEstimate->discounts[0]) && !empty($invoice_estimate->invoiceEstimate->discounts[0])){
                        $discount_price = $invoice_estimate->invoiceEstimate->discounts[0]->amount / 100;
                        $promocode = $invoice_estimate->invoiceEstimate->discounts[0]->entityId;
                        $discount_percentage = $invoice_estimate->invoiceEstimate->discounts[0]->discountPercentage;
                    }
                    if($discount_price > 0){
                        $payment_price = round($payment_price + $discount_price, 2);
                    }
                    if($user->is_active == 1){
                        $emailTemplate_HCE_AE22 = EmailTemplate::where('code', 'HCE-AE22')->first();
                        $email_HCE_AE22_vars = array(
                            '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user->first_name,
                            '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user->last_name,
                            '{%COMPANY_NAME%}' => $user->company_name,
                            '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user->email,
                            '{%NUMBERS_OF_LOCATIONS%}' => $location_limit,
                            '{%EMPLOYEE_RANGE%}' => $employee_limit,
                            '{%PROMO_CODE%}' => $promocode,
                            '{%PROMO_CODE_PERCENTAGE%}' => $discount_percentage,
                            '{%PRICE%}' => $this->formatPrice($payment_price),
                            '{%PROMO_DISCOUNT%}' => $this->formatPrice($discount_price),
                            '{%DISCOUNT_PRICE%}' => $this->formatPrice(round(($payment_price - $discount_price), 2)),
                            '{%TRANSACTION_FEE_AMOUNT%}' => $this->formatPrice($transaction_fee),
                            '{%SALES_TAX_PERCENTAGE%}' => $this->formatPrice((!empty($sales_tax))?$sales_tax_percentage:0),
                            '{%SALES_TAX_AMOUNT%}' => $this->formatPrice((!empty($sales_tax))?array_sum(array_column($sales_tax, 'amount')):0),
                            '{%PAYMENT_PRICE%}' => $this->formatPrice($charge_price),
                            '{%PAYMENT_TERM%}' => $plan_type,
                            '{%PAYMENT_DATE%}' =>  Carbon::today()->format('Y-m-d'),
                            '{%SUBSCRIPTION_YEAR%}' => ( (Carbon::parse($event_data->content['contract_term']['contract_end'])->subDay())->diffInYears($user->created_at)) + 1,
                        );
                        $html = str_ireplace(array_keys($email_HCE_AE22_vars), array_values($email_HCE_AE22_vars), $emailTemplate_HCE_AE22->body);

                        if ($user->partner_reseller_id != null) {
                            $admin_subject = str_ireplace('{%RESELLER%}', $user->reseller->name, $emailTemplate_HCE_AE22->reseller_subject);
                        } else {
                            $admin_subject = $emailTemplate_HCE_AE22->subject;
                        }

                        $this->sendEmail($emailTemplate_HCE_AE22->code, $html, [Config::get('app.finance_group_email'), Config::get('app.cs_group_email'), Config::get('app.salesadmin_group_email')], Config::get('app.from_admin_email'), $admin_subject, null, null,true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);

                        //send mail to partner start
                        if ($user->partner_reseller_id != null && $user->reseller->email != '') {
                            $this->sendEmail($emailTemplate_HCE_AE22->code, $html, $user->reseller->email, Config::get('app.from_admin_email'), $admin_subject, null, null, true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_handleContractTermRenewedEvent() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_handleContractTermRenewedEvent()[data] => '.json_encode($event_data));
        }
    }

    private function _handleContractTermCreatedEvent($event_data){
        try {
            $user = User::where('chargebee_subscription_id', $event_data->content['contract_term']['subscription_id'])->first();
            if($user){
                Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
                $subscription_response = Subscription::retrieve($user->chargebee_subscription_id);
                $subscription = $subscription_response->subscription();
                if($subscription->status == 'active'){
                    $user->update([
                        'contract_renewal_date' => Carbon::parse($event_data->content['contract_term']['contract_end'])->format('Y-m-d')
                    ]);
                }
            }
        } catch (\Exception $e) {
            Log::error('ChargebeeWebhookController/_handleContractTermCreatedEvent() => ' . $e->getMessage());
            Log::error('ChargebeeWebhookController/_handleContractTermCreatedEvent()[data] => '.json_encode($event_data));
        }
    }
}