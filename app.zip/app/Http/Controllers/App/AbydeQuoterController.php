<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Jobs\QuoterMailWithAttachment;
use App\Models\AbydeProduct;
use App\Models\AbydeQuoterPartner;
use App\Models\EmployeeLimitPrice;
use App\Models\LocationLimitPrice;
use App\Models\Promocode;
use App\Models\Quoter;
use App\Models\SalesRep;
use App\Models\SraOnlyLocationLimitPrice;
use App\Traits\ApiResponser;
use App\Traits\PricingHelper;
use App\Traits\SendMail;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class AbydeQuoterController extends Controller
{
    use ApiResponser, PricingHelper, SendMail;

    /**
     * Check sales rep password
     *
     * @return \Illuminate\Http\Response
     */
    public function quoterValidatePassword(Request $request)
    {
        $validator_rules = [
            'password' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            if (Hash::check($request['password'], Config::get('app.quoter_password'))) {
                $partner_list = AbydeQuoterPartner::select('id', 'name')->orderBy('display_order', 'ASC')->orderBy('name', 'ASC')->get();
                $sales_rep_list = SalesRep::select('id', DB::raw("CONCAT(`first_name`, ' ', `last_name`) as name"))->get();

                return $this->success(Config::get('constants.QUOTER.PASSWORD_VALID'), 200, [
                    'partner_list' => $partner_list,
                    'sales_rep_list' => $sales_rep_list]);
            } else {
                return $this->error(Config::get('constants.QUOTER.PASSWORD_NOT_VALID'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AbydeQuoterController/quoterValidatePassword() => '.$e->getMessage());
            Log::error('AbydeQuoterController/quoterValidatePassword()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * save quoter data
     *
     * @return \Illuminate\Http\Response
     */
    public function quoterSave(Request $request)
    {
        try {
            $input_fields = $request->all();

            $validator_rules = [
                'location_limit' => 'required',
                'employee_limit' => [
                    Rule::requiredIf(function () use ($request) {
                        $list = $request->input('selected_product_list', []);
                        return collect(['hipaace', 'hipaaba', 'oshahc'])->intersect($list)->isNotEmpty();
                    }),                    
                ],
                'selected_product_list' => 'array|required',
                'quote_name' => 'required',
                'quote_company_name' => 'required',
                'quote_company_email' => 'required|email',
                'is_abyde_sale_rep' => 'required|in:yes,no',
                'quote_password' => 'required_if:is_abyde_sale_rep,yes',
                'quote_sales_rep' => 'required_if:is_abyde_sale_rep,yes',
                'quote_partner' => 'required_if:is_abyde_sale_rep,yes',
                'quote_valid_date' => 'required_if:is_abyde_sale_rep,yes|nullable|date_format:m/d/Y',
                'show_locked_prices' => 'required|in:monthly,quarterly,all',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            //validating password
            if ($input_fields['is_abyde_sale_rep'] == 'yes') {
                if (! Hash::check($input_fields['quote_password'], Config::get('app.quoter_password'))) {
                    return $this->error(Config::get('constants.QUOTER.PASSWORD_NOT_VALID'), 200);
                }
            }
            //checking promocode
            $input_fields['selected_product_list'] = array_map('strtolower', $input_fields['selected_product_list']);
            if (! empty($input_fields['promo_code'])) {
                if (in_array('hipaace', $input_fields['selected_product_list']) || in_array('hipaacesraonly', $input_fields['selected_product_list'])) {
                    $promocode_data = $this->checkPromoCode($input_fields['promo_code'], false);
                    if (empty($promocode_data)) {
                        return $this->error(Config::get('constants.QUOTER.POMOCODE_NOT_VALID'), 200);
                    }
                }
                
                if ((in_array('oshahc', $input_fields['selected_product_list']) && ! in_array('hipaace', $input_fields['selected_product_list'])) || in_array('hipaaba', $input_fields['selected_product_list']) && ! in_array('hipaace', $input_fields['selected_product_list']) && ! in_array('oshahc', $input_fields['selected_product_list'])) {
                    if ((in_array('oshahc', $input_fields['selected_product_list']) && ! in_array('hipaace', $input_fields['selected_product_list']))) {
                        $result_json = $this->fetchPromocodeDiscount('oshahc', $input_fields['promo_code']);
                    }
                    if (in_array('hipaaba', $input_fields['selected_product_list']) && ! in_array('hipaace', $input_fields['selected_product_list']) && ! in_array('oshahc', $input_fields['selected_product_list'])) {
                        $result_json = $this->fetchPromocodeDiscount('hipaaba', $input_fields['promo_code']);
                    }
                    if ($result_json['status'] == 'Error') {
                        return $this->error(Config::get('constants.QUOTER.POMOCODE_NOT_VALID'), 200);
                    }
                }
            }

            if ($input_fields['is_abyde_sale_rep'] == 'no') {
                $input_fields['quote_sales_rep'] = null;
                $input_fields['quote_partner'] = null;
                $input_fields['quote_valid_date'] = date('Y-m-d');
            } else {
                $input_fields['quote_valid_date'] = date('Y-m-d', strtotime($input_fields['quote_valid_date']));
            }

            if(!in_array('hipaacesraonly', $input_fields['selected_product_list'])){                
                $location_pricing = LocationLimitPrice::select('id')->where('limit', $input_fields['location_limit'])->first();
                $input_fields['location_limit'] = $location_pricing->id;            

                $employee_pricing = EmployeeLimitPrice::select('id')->where('limit', $input_fields['employee_limit'])->first();
                $input_fields['employee_limit'] = $employee_pricing->id;
                $input_fields['location_limit_type']='App\\Models\\LocationLimitPrice';
            }
            else{
                $location_pricing = SraOnlyLocationLimitPrice::select('id')->where('limit', $input_fields['location_limit'])->first();
                $input_fields['location_limit'] = $location_pricing->id;                            
                $input_fields['employee_limit'] = null;
                $input_fields['location_limit_type']='App\\Models\\SraOnlyLocationLimitPrice';
            }

            $selected_product_list = AbydeProduct::whereIn('code', $input_fields['selected_product_list'])->orderBy('id', 'asc')->pluck('id');
            $input_fields['selected_product_list'] = $selected_product_list;           
            
            DB::beginTransaction();
            $quoter = Quoter::create($input_fields);
            $last_id = $quoter->id;

            //save products
            if (! empty($input_fields['selected_product_list'])) {
                $product_arr = [];
                for ($i = 0; $i < count($input_fields['selected_product_list']); $i++) {
                    $product_arr[$i]['abyde_product_id'] = $input_fields['selected_product_list'][$i];
                }
                $quoter->quoter_abyde_product()->createMany($product_arr);
            }

            DB::commit();
            QuoterMailWithAttachment::dispatch($last_id, $input_fields['show_locked_prices']);

            $quoter_data = Quoter::where('id', $last_id)
                ->with([
                    'location_limit_prices:id,limit,price',
                    'employee_limit_prices:id,limit,price',
                    'abyde_quoter_partners:id,name,logo',
                    'sale_reps:id,first_name,last_name,image,phone_number,email',
                    'quoter_abyde_product:abyde_product_id,quoter_id',
                ])->first();

            return $this->success(Config::get('constants.QUOTER.QUOTER_ADDED'), 200, [$quoter_data]);
        } catch (\Exception $e) {
            Log::error($e->getLine());
            Log::error('AbydeQuoterController/quoterSave() => '.$e->getMessage());
            Log::error('AbydeQuoterController/quoterSave()[data] => '.json_encode($request->all()));
            Log::error('AbydeQuoterController/quoterSave() => '.$e->getLine());
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function fetchPromocodeDiscount($code, $promo_code)
    {
        if ($code == 'oshahc') {
            $url = Config::get('app.osha_hc_url').'/check-promocode';
            $error_msg = Config::get('constants.QUOTER.OSHA_HC_URL_CALL_ERROR');
        } elseif ($code == 'hipaaba') {
            $url = Config::get('app.hipaa_ba_url').'/check-promocode';
            $error_msg = Config::get('constants.QUOTER.HIPAA_BA_URL_CALL_ERROR');
        }
        $headers[] = 'Content-Type: application/json';
        $params = ['promo_code' => $promo_code];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 80);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        if (! $result = curl_exec($ch)) {
            return $this->error($error_msg, 200);
        }
        curl_close($ch);
        $quoter_data = [];
        $result_json = json_decode($result, 1);
        if ($result_json['status'] == 'Error') {
            $quoter_data['status'] = 'Error';
        } else {
            $quoter_data['status'] = 'success';
            $quoter_data['promocodes']['discount_percentage'] = $result_json['data']['discount_percentage'];
            $quoter_data['promocodes']['promo_code'] = $result_json['data']['promo_code'];
        }

        return $quoter_data;
    }   
}
