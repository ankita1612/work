<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\BusinessAssociates;
use App\Models\BusinessAssociatesAgreement;
use App\Models\Countries;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Traits\ApiResponser;
use App\Traits\FileUpload;
use App\Traits\GeneratePolicy;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class BusinessAssociatesPortalController extends Controller
{
    use ApiResponser, FileUpload, GeneratePolicy, SendMail;

    /**
     * Business Associates page
     *
     * @return \Illuminate\Http\Response
     */
    public function showAgreement($business_associates_id = '', $ref_token = '')
    {
        if ($business_associates_id == '' || $ref_token == '') {
            return redirect()->route('login');
        } else {
            if (base64_decode($business_associates_id, true)) {
                $business_associates = BusinessAssociates::with(['user.reseller'])->where('id', base64_decode($business_associates_id))->first();
                $business_associates_agreement = BusinessAssociatesAgreement::with('location.state')->where('reference_token', $ref_token)->where('business_associates_id', base64_decode($business_associates_id))->first();

                return view('app.pages.businessassociatesagreement', ['business_associates_id' => $business_associates_id, 'ref_token' => $ref_token, 'business_associates_user_data' => $business_associates, 'business_associates_agreement_data' => $business_associates_agreement]);
            } else {
                return redirect()->route('login');
            }
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get agreement data
     *
     * @return \Illuminate\Http\Response
     */
    public function getAgreementData(Request $request)
    {
        try {
            $validator_rules = [
                'business_associates_id' => 'required',
                'ref_token' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $countries = Countries::select(['id', 'country_code', 'country_name'])->get();
            $business_associates = BusinessAssociates::with('user.reseller')->where('id', base64_decode($request['business_associates_id']))->first();
            $business_associates_agreement = BusinessAssociatesAgreement::with(['location.state', 'location.hipaaComplianceOfficer.hco'])
                ->where('reference_token', $request['ref_token'])
                ->where('business_associates_id', base64_decode($request['business_associates_id']))->first();
            if ($business_associates && $business_associates_agreement) {
                if ($business_associates_agreement->signature && $business_associates_agreement->file_name) {
                    $expire_time = Config::get('app.expire_time');
                    $response = [
                        'business_associates' => $business_associates,
                        'business_associates_agreement' => $business_associates_agreement,
                        'agreement_pdf_url' => $this->getSignedURL('/generatedpolicydocuments/businessassociateagreement/'.$business_associates_agreement->file_name),
                        'agreement_pdf_url_downloadebale' => Storage::disk('s3')->temporaryUrl(
                            'generatedpolicydocuments/businessassociateagreement/'.$business_associates_agreement->file_name,
                            now()->addSeconds($expire_time),
                            [
                                'ResponseContentType' => 'application/octet-stream',
                                'ResponseContentDisposition' => 'attachment',
                            ]
                        ),
                    ];
                } else {
                    $public_path = public_path();
                    $storage_path = storage_path('app/public');
                    $generated_agreement_directory_path = $storage_path.'/generatedpolicydocuments/';
                    $business_associates_agreement_filename = 'BusinessAssociateAgreement.docx';
                    $gnerated_business_associates_agreement_filename = $business_associates->id.'_'.$business_associates_agreement_filename;
                    if (isset($request->signature) && $request->signature != '') {
                        $gnerated_business_associates_agreement_filename = $business_associates->id.'_signed_'.$business_associates_agreement_filename;
                    } else {
                        $gnerated_business_associates_agreement_filename = $business_associates->id.'_'.$business_associates_agreement_filename;
                    }
                    $gnerated_business_associates_agreement_pdf_name = str_replace('docx', 'pdf', $gnerated_business_associates_agreement_filename);

                    $business_associates_agreement_file_path = $public_path.'/policydocuments/'.$business_associates_agreement_filename;
                    $gnerated_business_associates_agreement_file_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_business_associates_agreement_filename;
                    $gnerated_business_associates_agreement_pdf_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_business_associates_agreement_pdf_name;

                    $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($business_associates_agreement_file_path);

                    $generalController = new GeneralController;
                    $logo_data = $generalController->_addCompanyLogoOnCoverPage($business_associates_agreement->location);
                    $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
                    $generalController->_removeTempCompanyLogo($business_associates_agreement->location, $logo_data['temp_file_path']);
                    $template_processor->setValue('CLIENT_NAME', htmlspecialchars($business_associates_agreement->location->company_name));
                    $template_processor->setValue('LOCATION_NAME', htmlspecialchars($business_associates_agreement->location->location_nickname));
                    $template_processor->setValue('CLIENT_ADDRESS', htmlspecialchars($business_associates_agreement->location->address));
                    $template_processor->setValue('CLIENT_CITY', htmlspecialchars($business_associates_agreement->location->city));
                    $template_processor->setValue('CLIENT_STATE', htmlspecialchars($business_associates_agreement->location->state->state_name));
                    $template_processor->setValue('CLIENT_ZIP', htmlspecialchars($business_associates_agreement->location->zip_code));
                    $template_processor->setValue('CLIENT_PHONE_NUMBER', htmlspecialchars($business_associates_agreement->location->phone_no));
                    $template_processor->setValue('CLIENT_FAX_NUMBER', $business_associates_agreement->location->fax_no != null ? htmlspecialchars($business_associates_agreement->location->fax_no) : 'N/A');

                    $template_processor->setValue('EXPORT_DATE', date('F j, Y', strtotime($business_associates_agreement->updated_at)));
                    $template_processor->setValue('BA_NAME', htmlspecialchars($business_associates->name));
                    $template_processor->setValue('BA_PHONE_NUMBER', $business_associates->phone_number != null ? htmlspecialchars($business_associates->phone_number) : 'N/A');

                    $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($business_associates_agreement->officer_name));
                    $template_processor->setValue('HIPAA_COMPLIANCE_TITLE', htmlspecialchars($business_associates_agreement->officer_title));
                    $template_processor->setValue('PRACTICE_NAME', htmlspecialchars($business_associates_agreement->location->company_name));
                    $template_processor->setValue('SIGNATURE_SEND_DATE', date('m/d/Y', strtotime($business_associates_agreement->created_at)));
                    $template_processor->setValue('USER_SIGN', htmlspecialchars($business_associates_agreement->officer_name));

                    if (isset($request->signature) && $request->signature != '') {

                        $template_processor->setValue('BA_OFFICER_NAME', htmlspecialchars($request->signature));
                        $template_processor->setValue('BA_OFFICER_TITLE', htmlspecialchars($request->signature_title));
                        $template_processor->setValue('BA_ADDRESS', htmlspecialchars($request->address));
                        if ($request->city == '') {
                            $template_processor->setValue('BA_CITY', htmlspecialchars($request->city));
                        } else {
                            $template_processor->setValue('BA_CITY', htmlspecialchars($request->city).',');
                        }
                        $template_processor->setValue('BA_FAX_NUMBER', $request->fax_no != null ? htmlspecialchars($request->fax_no) : 'N/A');
                        if (is_array($request->state)) {
                            if ($request->state['state_name'] == '' || $request->country['country_code'] == 'US') {
                                $template_processor->setValue('BA_STATE', $request->state['state_name']);
                            } else {
                                $template_processor->setValue('BA_STATE', $request->state['state_name'].',');
                            }
                        } else {
                            if ($request->state == '' || $request->country['country_code'] == 'US') {
                                $template_processor->setValue('BA_STATE', $request->state);
                            } else {
                                $template_processor->setValue('BA_STATE', $request->state.',');
                            }
                        }
                        if ($request->country['country_code'] == 'US') {
                            $template_processor->setValue('BA_ZIP', htmlspecialchars($request->zip_code));
                        } else {
                            $template_processor->setValue('BA_ZIP', htmlspecialchars($request->country['country_name'].' '.$request->zip_code));
                        }

                        $template_processor->setValue('BA_SIGNATURE_DATE', date('m/d/Y'));
                        $template_processor->setValue('BA_SIGN', htmlspecialchars($request->signature));
                    } else {
                        $template_processor->setValue('BA_OFFICER_NAME', '');
                        $template_processor->setValue('BA_OFFICER_TITLE', '');
                        $template_processor->setValue('BA_ADDRESS', '');
                        $template_processor->setValue('BA_CITY', '');
                        $template_processor->setValue('BA_STATE', '');
                        $template_processor->setValue('BA_ZIP', '');
                        $template_processor->setValue('BA_FAX_NUMBER', '');

                        $template_processor->setValue('BA_SIGNATURE_DATE', '');
                        $template_processor->setValue('BA_SIGN', '');
                    }
                    $template_processor->saveAs($gnerated_business_associates_agreement_file_path);
                    if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                        // change libreoffice path as per installation path from your machine
                        exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  '.$generated_agreement_directory_path.' '.$gnerated_business_associates_agreement_file_path);
                    } else {
                        exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir '.$generated_agreement_directory_path.' '.$gnerated_business_associates_agreement_file_path);
                    }
                    if (file_exists($gnerated_business_associates_agreement_pdf_path)) {
                        $file_contents = \File::get($gnerated_business_associates_agreement_pdf_path);
                        Storage::disk('s3')->put('/generatedpolicydocuments/businessassociateagreement/'.$gnerated_business_associates_agreement_pdf_name, $file_contents);
                        if (isset($request->signature) && $request->signature != '') {
                            $business_associates_agreement_old = BusinessAssociatesAgreement::where('reference_token', $request->ref_token)->where('business_associates_id', base64_decode($request->business_associates_id))->first();
                            $locations = Location::where('user_id', $business_associates['user_id'])->get();
                            foreach ($locations as $location) {
                                $this->addPolicyVersionData('BACP', $location->id);
                            }
                            $business_associates_agreement_old->update([
                                'address' => $request->address,
                                'city' => $request->city,
                                'country_id' => $request->country['id'],
                                'state_id' => is_array($request->state) ? $request->state['id'] : null,
                                'state_name' => ! is_array($request->state) ? $request->state : null,
                                'zip_code' => $request->zip_code,
                                'fax_no' => $request->fax_no,
                                'signature' => $request->signature,
                                'agreement_type' => 'system',
                                'file_name' => $gnerated_business_associates_agreement_pdf_name,
                            ]);
                            $business_associates_agreement = BusinessAssociatesAgreement::with(['location.hipaaComplianceOfficer.hco', 'location.user.reseller'])->where('reference_token', $request->ref_token)->where('business_associates_id', base64_decode($request->business_associates_id))->first();

                            // send HCE-UE20
                            (new BusinessAssociatesController)->sendHCEUE20EmailToBA($business_associates, $business_associates_agreement, null, null);
                            // send HCE-UE18
                            $one_year_seconds = 31556926; // accurate seconds for one year
                            $baa_agreement_file = $this->getSignedURL('/generatedpolicydocuments/businessassociateagreement/'.$gnerated_business_associates_agreement_pdf_name, $one_year_seconds);
                            $emailTemplate = EmailTemplate::where('code', 'HCE-UE18')->first();
                            $email_vars = [
                                '{%SIGN_UP_FIRST_NAME%}' => $business_associates_agreement['location']['hipaaComplianceOfficer']['hco']['first_name'],
                                '{%CLICK_HERE_TO_REVIEW%}' => $baa_agreement_file,
                                '{%BA_NAME%}' => $business_associates->name,
                                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                            ];
                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                            $html_subject = str_ireplace(['{%BA_NAME%}'], [$business_associates->name], $emailTemplate->subject);
                            $this->sendEmail($emailTemplate->code, $html, $business_associates_agreement['location']['hipaaComplianceOfficer']['hco']['email'], Config::get('app.from_user_email'), $html_subject, null, null, true, (! empty($business_associates_agreement['location']['user']['partner_reseller_id']) ? $business_associates_agreement['location']['user']['reseller']['logo'] : null), $business_associates_agreement['location']['user']['id']);
                        }
                    }
                    $expire_time = Config::get('app.expire_time');
                    $response = [
                        'business_associates' => $business_associates,
                        'business_associates_agreement' => $business_associates_agreement,
                        'countries' => $countries,
                        'agreement_pdf_url' => $this->getSignedURL('/generatedpolicydocuments/businessassociateagreement/'.$gnerated_business_associates_agreement_pdf_name),
                        'agreement_pdf_url_downloadebale' => Storage::disk('s3')->temporaryUrl(
                            'generatedpolicydocuments/businessassociateagreement/'.$gnerated_business_associates_agreement_pdf_name,
                            now()->addSeconds($expire_time),
                            [
                                'ResponseContentType' => 'application/octet-stream',
                                'ResponseContentDisposition' => 'attachment',
                            ]
                        ),
                    ];
                }

                return $this->success(Config::get('constants.SUCCESS'), 200, $response);
            }
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesPortalController/getAgreementData() => '.$e->getMessage());
            Log::error('BusinessAssociatesPortalController/getAgreementData()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
