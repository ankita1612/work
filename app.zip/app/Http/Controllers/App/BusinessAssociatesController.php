<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Imports\BusinessAssociatesImport;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AbydeDriveArchiveFile;
use App\Models\AbydeDriveArchiveFolder;
use App\Models\AbydeDriveArchiveFolderLocation;
use App\Models\AccountUser;
use App\Models\BusinessAssociates;
use App\Models\BusinessAssociatesAgreement;
use App\Models\BusinessAssociatesLocation;
use App\Models\EmailTemplate;
use App\Models\Employee;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\Policy;
use App\Models\PredefineBusinessAssociates;
use App\Models\User;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\FileUpload;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\HeadingRowImport;

class BusinessAssociatesController extends Controller
{
    use ApiResponser, CheckAccessRight, FileUpload, GeneratePolicy, GetMainUserData, SendMail;

    /**
     * BusinessAssociates page
     *
     * @return \Illuminate\Http\Response
     */
    public function showBusinessAssociates()
    {
        if ($this->checkAccessRight('businessAssociates')) {
            $user_data = $this->getMainAccountDetails();
            $general_controller = new GeneralController;
            $accessible_location_list = $general_controller->getAssingedLocationList();
            $location_count = Location::whereIn('id', $accessible_location_list)
                ->whereHas('hipaaComplianceOfficer')
                ->whereHas('companyModuleCompleted')
                ->whereHas('sraModuleCompleted')
                ->whereHas('disasterRecoveryPlanModuleCompleted')
                ->where(function ($query) {
                    $query->whereHas('employeePrimaryWorkLocation')->orWhereHas('employeeSecondaryWorkLocation');
                })
                ->count();
            if ($location_count > 0) {
                return view('app.pages.businessAssociates');
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Add Business Associates
     *
     * @return \Illuminate\Http\Response
     */
    public function addBusinessAssociates(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'name' => 'required',
                'email' => 'required|email',
                'location_list' => 'required|array',
            ];
            if ($request['is_no_expiration_applicable'] == false) {
                $validator_rules['expired_date'] = 'required|date';
            }
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $total_business_associates_added = BusinessAssociates::where('user_id', $user_data->id)->count();
            if ($total_business_associates_added === 0) {
                $first_business_associates_added = true;
            } else {
                $first_business_associates_added = false;
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $input_fields['user_id'] = $user_data['id'];
            $input_fields['expired_date'] = ($request['is_no_expiration_applicable'] == false) ? $request['expired_date'] : null;
            $locationIds = collect($request['location_list'])->pluck('location_id');
            $locations = Location::whereIn('id', $locationIds)
                ->whereHas('hipaaComplianceOfficer')
                ->whereHas('companyModuleCompleted')
                ->whereHas('sraModuleCompleted')
                ->whereHas('disasterRecoveryPlanModuleCompleted')
                ->where(function ($query) {
                    $query->whereHas('employeePrimaryWorkLocation')->orWhereHas('employeeSecondaryWorkLocation');
                })->get();
            foreach ($locations as $location) {
                $this->addPolicyVersionData('BACP', $location->id);
                if ($location->salesforce_unique_id != null) {
                    SendLocationDataToSalesForce::dispatch($location->id);
                }
            }
            $business_associates = BusinessAssociates::create($input_fields);
            $business_associates['business_associates_location_list'] = $business_associates->businessAssociatesLocation()->createMany($input_fields['location_list']);
            if ($request->predefine_business_associates_id != null) {
                $locations = Location::with(['state', 'hipaaComplianceOfficer.hco'])
                    ->where('user_id', $user_data['id'])
                    ->whereHas('hipaaComplianceOfficer')
                    ->whereHas('companyModuleCompleted')
                    ->whereHas('sraModuleCompleted')
                    ->whereHas('disasterRecoveryPlanModuleCompleted')
                    ->where(function ($query) {
                        $query->whereHas('employeePrimaryWorkLocation')->orWhereHas('employeeSecondaryWorkLocation');
                    })
                    ->get();
                $predefine_ba = PredefineBusinessAssociates::where('id', $request['predefine_business_associates_id'])->first();
                if (count($locations) == 1 && $predefine_ba->agreement_type == 'predefined_dynamic_doc') {
                    $public_path = public_path();
                    $storage_path = storage_path('app/public');
                    $location = $locations[0];
                    $predefine_ba_doc_filename = $public_path . '/policydocuments/' . $predefine_ba->doc_file;
                    $generated_agreement_directory_path = $storage_path . '/generatedpolicydocuments/';
                    $gnerated_business_associates_agreement_filename = $business_associates->id . '_' . $predefine_ba->doc_file;
                    $gnerated_business_associates_agreement_pdf_name = str_replace('docx', 'pdf', $gnerated_business_associates_agreement_filename);
                    $gnerated_business_associates_agreement_file_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_business_associates_agreement_filename;
                    $gnerated_business_associates_agreement_pdf_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_business_associates_agreement_pdf_name;
                    $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($predefine_ba_doc_filename);
                    // WVA agreement for predefine business associate
                    if ($predefine_ba->id == 4) {
                        $predefine_doc_jsondata = json_decode($predefine_ba['predefinedBAInformation']);
                        $generalController = new GeneralController;
                        $logo_data = $generalController->_addCompanyLogoOnCoverPage($location);
                        $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
                        $generalController->_removeTempCompanyLogo($location, $logo_data['temp_file_path']);
                        $template_processor->setValue('CLIENT_NAME', htmlspecialchars($location->company_name));
                        $template_processor->setValue('CLIENT_ADDRESS', htmlspecialchars($location->address));
                        $template_processor->setValue('CLIENT_CITY', htmlspecialchars($location->city));
                        $template_processor->setValue('CLIENT_STATE', htmlspecialchars($location->state->state_name));
                        $template_processor->setValue('CLIENT_ZIP', htmlspecialchars($location->zip_code));
                        $template_processor->setValue('CLIENT_PHONE_NUMBER', htmlspecialchars($location->phone_no));
                        $template_processor->setValue('CLIENT_FAX_NUMBER', htmlspecialchars($location->fax_no));

                        $template_processor->setValue('EXPORT_DATE', date('F j, Y', strtotime($business_associates->created_at)));
                        $template_processor->setValue('BA_NAME', htmlspecialchars($predefine_ba->name));
                        $template_processor->setValue('BA_ADDRESS', htmlspecialchars($predefine_doc_jsondata->tAddress));
                        $template_processor->setValue('BA_CITY', htmlspecialchars($predefine_doc_jsondata->vCity) . ',');
                        $template_processor->setValue('BA_STATE', htmlspecialchars($predefine_doc_jsondata->vState));
                        $template_processor->setValue('BA_ZIP', htmlspecialchars($predefine_doc_jsondata->vZipcode));
                        $template_processor->setValue('BA_PHONE_NUMBER', htmlspecialchars($predefine_doc_jsondata->vPhoneNumber));
                        $template_processor->setValue('BA_FAX_NUMBER', htmlspecialchars($predefine_doc_jsondata->vFaxNo));
                        $template_processor->setValue('BA_OFFICER_NAME', htmlspecialchars($predefine_doc_jsondata->vOfficerName));

                        $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($location['hipaaComplianceOfficer']['hco']['first_name'] . ' ' . $location['hipaaComplianceOfficer']['hco']['last_name']));
                        $template_processor->setValue('HIPAA_COMPLIANCE_TITLE', 'HIPAA COMPLIANCE OFFICER');
                        $template_processor->setValue('SIGNATURE_SEND_DATE', date('m/d/Y', strtotime($business_associates->created_at)));

                        $template_processor->setValue('BA_SIGNATURE_DATE', date('m/d/Y', strtotime($business_associates->created_at)));
                        $template_processor->setValue('USER_SIGN', htmlspecialchars($location['hipaaComplianceOfficer']['hco']['first_name'] . ' ' . $location['hipaaComplianceOfficer']['hco']['last_name']));
                        $template_processor->setValue('BA_SIGN', htmlspecialchars($predefine_doc_jsondata->vOfficerName));
                    }
                    // open dental agreement for predefine business associate
                    if ($predefine_ba->id == 5) {
                        $template_processor->setValue('CLIENT_NAME', htmlspecialchars($location->company_name));
                        $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($location['hipaaComplianceOfficer']['hco']['first_name'] . ' ' . $location['hipaaComplianceOfficer']['hco']['last_name']));
                        $template_processor->setValue('HIPAA_COMPLIANCE_TITLE', 'HIPAA COMPLIANCE OFFICER');
                        $template_processor->setValue('SIGNATURE_SEND_DATE', date('m/d/Y'));
                        $template_processor->setValue('USER_SIGN', htmlspecialchars($location['hipaaComplianceOfficer']['hco']['first_name'] . ' ' . $location['hipaaComplianceOfficer']['hco']['last_name']));
                    }
                    $template_processor->saveAs($gnerated_business_associates_agreement_file_path);
                    if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                        // change libreoffice path as per installation path from your machine
                        exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  ' . $generated_agreement_directory_path . ' ' . $gnerated_business_associates_agreement_file_path);
                    } else {
                        exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir ' . $generated_agreement_directory_path . ' ' . $gnerated_business_associates_agreement_file_path);
                    }
                    if (file_exists($gnerated_business_associates_agreement_pdf_path)) {
                        $file_contents = \File::get($gnerated_business_associates_agreement_pdf_path);
                        Storage::disk('s3')->put('/generatedpolicydocuments/businessassociateagreement/' . $gnerated_business_associates_agreement_pdf_name, $file_contents);
                    }
                }
                $filename = null;
                if ($predefine_ba->agreement_type == 'doc') {
                    $filename = $predefine_ba->doc_file;
                }
                if (count($locations) == 1 && $predefine_ba->agreement_type == 'predefined_dynamic_doc') {
                    $filename = $gnerated_business_associates_agreement_pdf_name;
                }
                BusinessAssociatesAgreement::create([
                    'business_associates_id' => $business_associates->id,
                    'agreement_type' => $predefine_ba->agreement_type,
                    'agreement_link' => ($predefine_ba->agreement_type == 'url') ? $predefine_ba->agreement_link : null,
                    'file_name' => $filename,
                ]);
                if ($predefine_ba->id != 4 && $predefine_ba->id != 5) {
                    $business_associates_agreement = BusinessAssociatesAgreement::with(['location.hipaaComplianceOfficer.hco'])->where('business_associates_id', $business_associates->id)->first();
                    $this->sendHCEUE20EmailToBA($business_associates, $business_associates_agreement, 'predefine_doc_url', null);
                }
            }
            $request['first_business_associates_added'] = $first_business_associates_added;
            $request['total_business_associates_added'] = $total_business_associates_added;
            $request['user_locations_number'] = count($locations);
            DB::commit();

            return $this->success(Config::get('constants.BUSINESSASSOCIATES.BUSINESSASSOCIATES_ADDED'), 200, $request->all());
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/addBusinessAssociates() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/addBusinessAssociates()[data] => ' . json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Check unique email address in business associates
     *
     * @return \Illuminate\Http\Response
     */
    public function checkUniqueEmail(Request $request, $email = '', $business_associates_id = '')
    {
        try {
            if ($email == '') {
                dd('Invalid parmas');
            }
            $user_data = $this->getMainAccountDetails();
            $business_associates = BusinessAssociates::where('email', $request['email'])
                ->where('user_id', $user_data['id']);
            if ($business_associates_id != '') {
                $business_associates = $business_associates->where('id', '!=', $business_associates_id);
            }
            $business_associates = $business_associates->count();
            if ($business_associates > 0) {
                return 'available';
            } else {
                return 'not_available';
            }
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/checkUniqueEmail() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/checkUniqueEmail()[data] => ' . json_encode([$email, $business_associates_id]));
            Log::error('BusinessAssociatesController/checkUniqueEmail()[request] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get predefine business associatives
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getPredefineBusinessAssociates()
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $predefine_ba = PredefineBusinessAssociates::whereDoesntHave('businessAssociates', function ($que) use ($user_data) {
                return $que->where('user_id', $user_data['id']);
            });
            if ($user_data['is_demo_account'] !== 1) {
                $predefine_ba = $predefine_ba->where('is_visible_to_demo', 0);
            }
            $predefine_ba = $predefine_ba->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $predefine_ba);
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/getPredefineBusinessAssociates() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get Business AssociatesList list
     *
     * @return \Illuminate\Http\Response
     */
    public function allBusinessAssociatesList(Request $request)
    {
        try {
            $validator_rules = [
                'sort_by' => 'sometimes|nullable|in:name,email,phone_number,expired_date',
                'sort_by_dir' => 'sometimes|nullable|in:ASC,DESC',
                'filter_by_location' => 'sometimes|nullable|array',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $limit = $request->has('per_page') ? request('per_page') : Config::get('constants.PER_PAGE');
            $user_data = $this->getMainAccountDetails();
            $generalController = new GeneralController;
            $location_access_list = $generalController->getAssingedLocationList();
            $business_associates = BusinessAssociates::where('user_id', $user_data['id'])
                ->with(['businessAssociatesLocation', 'businessAssociatesLocation.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }, 'businessAssociatesAgreement', 'predefineBusinessAssociative']);
            $business_associates = $business_associates->where(function ($subquery) use ($location_access_list) {
                $subquery->whereHas('businessAssociatesLocation', function ($que) use ($location_access_list) {
                    $que->whereIn('location_id', $location_access_list);
                });
            });
            $input_fields = $request->all();
            if (isset($input_fields['search_query']) && $input_fields['search_query'] != '') {
                $business_associates = $business_associates->where(function ($que) use ($input_fields) {
                    return $que->where('name', 'LIKE', '%' . $input_fields['search_query'] . '%')
                        ->orWhere('email', 'LIKE', '%' . $input_fields['search_query'] . '%')
                        ->orWhere('phone_number', 'LIKE', '%' . $input_fields['search_query'] . '%');
                });
            }
            if (isset($input_fields['filter_by_location']) && ! empty($input_fields['filter_by_location'])) {
                $business_associates = $business_associates->whereHas('businessAssociatesLocation', function ($que) use ($input_fields) {
                    return $que->whereIn('location_id', $input_fields['filter_by_location']);
                });
            }
            if (isset($input_fields['sort_by']) && ! empty($input_fields['sort_by']) && isset($input_fields['sort_by_dir']) && ! empty($input_fields['sort_by_dir'])) {
                $business_associates = $business_associates->orderBy($input_fields['sort_by'], $input_fields['sort_by_dir'])->orderBy('id', $input_fields['sort_by_dir']);
            } else {
                $business_associates = $business_associates->orderBy('id', 'DESC');
            }
            $business_associates = $business_associates->paginate($limit);

            $business_associates->getCollection()->transform(function ($ba, $key) {
                if ($ba->businessAssociatesAgreement && $ba->businessAssociatesAgreement->file_name) {
                    $expire_time = Config::get('app.expire_time');
                    $businessAssociatesAgreement = $ba->businessAssociatesAgreement;
                    if ($ba->predefine_business_associates_id != null && $ba->businessAssociatesAgreement->agreement_type == 'doc') {
                        $businessAssociatesAgreement->file_name = Storage::disk('s3')->temporaryUrl(
                            'predefinebusinessassociateagreementtypedoc/' . $ba->predefine_business_associates_id . '/' . $businessAssociatesAgreement->file_name,
                            now()->addSeconds($expire_time),
                            [
                                'ResponseContentType' => 'application/octet-stream',
                                'ResponseContentDisposition' => 'attachment',
                            ]
                        );
                    } else {
                        $businessAssociatesAgreement->file_name = Storage::disk('s3')->temporaryUrl(
                            'generatedpolicydocuments/businessassociateagreement/' . $businessAssociatesAgreement->file_name,
                            now()->addSeconds($expire_time),
                            [
                                'ResponseContentType' => 'application/octet-stream',
                                'ResponseContentDisposition' => 'attachment',
                            ]
                        );
                    }
                    $ba->businessAssociatesAgreement = $businessAssociatesAgreement;
                }

                return $ba;
            });

            $location_list_count = Location::whereHas('hipaaComplianceOfficer')
                ->whereHas('companyModuleCompleted')
                ->whereHas('sraModuleCompleted')
                ->whereHas('disasterRecoveryPlanModuleCompleted')
                ->where(function ($query) {
                    $query->whereHas('employeePrimaryWorkLocation')->orWhereHas('employeeSecondaryWorkLocation');
                })
                ->where('user_id', $user_data['id'])
                ->whereIn('id', $location_access_list)
                ->count();

            $data = [
                'sample_import_doc' => ($location_list_count == 1) ? url('/sample_docs/businessassociate_template_std.xlsx') : url('/sample_docs/businessassociate_template_ent.xlsx'),
                'business_associates_list' => $business_associates,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/allBusinessAssociatesList() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/allBusinessAssociatesList()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Edit Business Associates
     *
     * @return \Illuminate\Http\Response
     */
    public function editBusinessAssociates(Request $request)
    {
        try {
            $validator_rules = [
                'business_associative_id' => 'required',
                'name' => 'required',
                'email' => 'required|email',
                'location_work_new' => 'sometimes|array',
                'location_work_removed' => 'sometimes|array',
            ];
            if ($request['is_no_expiration_applicable'] == false) {
                $validator_rules['expired_date'] = 'required|date';
            }

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            DB::beginTransaction();
            $input_fields = $request->all();
            $business_associative = BusinessAssociates::with('businessAssociatesLocation')->findOrFail($input_fields['business_associative_id']);
            $input_fields['expired_date'] = ($request['is_no_expiration_applicable'] == false) ? $request['expired_date'] : null;
            $policy_location = [];
            if ($request->has('location_work_new')) {
                foreach ($request['location_work_new'] as $new_loc) {
                    array_push($policy_location, $new_loc);
                }
            }
            if ($request->has('location_work_removed')) {
                foreach ($request['location_work_removed'] as $new_loc) {
                    array_push($policy_location, $new_loc);
                }
            }
            if ($business_associative['email'] != $input_fields['email'] || $business_associative['name'] != $input_fields['name'] || $business_associative['expired_date'] != $input_fields['expired_date'] || $business_associative['phone_number'] != $input_fields['phone_number']) {
                foreach ($policy_location as $location) {
                    $this->addPolicyVersionData('BACP', $location['location_id']);
                }
            }
            if (! empty($policy_location)) {
                $ba_old_location = $business_associative->businessAssociatesLocation()->whereNotIn('location_id', $policy_location)->get()->toArray();
                foreach ($ba_old_location as $old_loc) {
                    $policy_location[] = ['location_id' => $old_loc['location_id']];
                }
                foreach ($policy_location as $location) {
                    $this->addPolicyVersionData('BACP', $location['location_id']);
                }
            }
            if ($business_associative->update($input_fields)) {
                if ($request->has('location_work_removed')) {
                    BusinessAssociatesLocation::whereIn('location_id', $input_fields['location_work_removed'])
                        ->where('business_associate_id', $input_fields['business_associative_id'])->get()->each(function ($bal) {
                            $bal->delete();
                        });
                }
                if ($request->has('location_work_new')) {
                    $business_associative->businessAssociatesLocation()->createMany($input_fields['location_work_new']);
                }
            }
            $business_associative = BusinessAssociates::where('id', $input_fields['business_associative_id'])
                ->with(['businessAssociatesLocation', 'businessAssociatesLocation.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }, 'predefineBusinessAssociative', 'businessAssociatesAgreement'])->first();
            if ($business_associative->businessAssociatesAgreement && $business_associative->businessAssociatesAgreement->file_name) {
                $expire_time = Config::get('app.expire_time');
                $business_associative_Agreement = $business_associative->businessAssociatesAgreement;
                $business_associative_Agreement->file_name = Storage::disk('s3')->temporaryUrl(
                    'generatedpolicydocuments/businessassociateagreement/' . $business_associative_Agreement->file_name,
                    now()->addSeconds($expire_time),
                    [
                        'ResponseContentType' => 'application/octet-stream',
                        'ResponseContentDisposition' => 'attachment',
                    ]
                );
                $business_associative->businessAssociatesAgreement = $business_associative_Agreement;
            }
            DB::commit();

            return $this->success(Config::get('constants.BUSINESSASSOCIATES.BUSINESSASSOCIATES_EDITED'), 200, $business_associative);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('BusinessAssociatesController/editBusinessAssociates() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/editBusinessAssociates()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * delete Business Associates
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteBusinessAssociates(Request $request)
    {
        try {
            $validator_rules = [
                'business_associative_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $business_associative = BusinessAssociates::with(['businessAssociatesAgreement', 'predefineBusinessAssociative', 'businessAssociatesLocation.location'])->findOrFail($request['business_associative_id']);
            if ($business_associative->businessAssociatesAgreement != null && ($business_associative->businessAssociatesAgreement->file_name != null || $business_associative->businessAssociatesAgreement->file_name != '')) {
                if ($business_associative->businessAssociatesAgreement->agreement_type != 'url') {
                    if ($business_associative->predefine_business_associates_id && $business_associative->predefineBusinessAssociative->agreement_type == 'doc') {
                        $old_file = 'predefinebusinessassociateagreementtypedoc/' . $business_associative->predefine_business_associates_id . '/' . $business_associative->businessAssociatesAgreement->file_name;
                        $file_size = $this->getReadableFilesize(Storage::disk('s3')->size('/predefinebusinessassociateagreementtypedoc/' . $business_associative->predefine_business_associates_id . '/' . $business_associative->businessAssociatesAgreement->file_name));
                    } else {
                        $old_file = '/generatedpolicydocuments/businessassociateagreement/' . $business_associative->businessAssociatesAgreement->file_name;
                        $file_size = $this->getReadableFilesize(Storage::disk('s3')->size('/generatedpolicydocuments/businessassociateagreement/' . $business_associative->businessAssociatesAgreement->file_name));
                    }
                    $business_associative->name = str_replace(' ', '_', trim($business_associative->name));
                    $business_associative->name = preg_replace('/[^A-Za-z0-9\-\_]/', '', $business_associative->name);
                    $file_extenstion = substr(strrchr($business_associative->businessAssociatesAgreement->file_name, '.'), 1);
                    $new_file_name_without_ext = $business_associative->id . '_' . $business_associative->name . '_' . 'agreement';
                    $new_file_name = $new_file_name_without_ext . '.' . $file_extenstion;
                    $new_file = '/abyde_drive_archive/business_associates/' . $business_associative->user_id . '/' . $new_file_name;
                    $title = $new_file_name_without_ext;
                    if (Storage::disk('s3')->copy($old_file, $new_file)) {
                        $abyde_drive_folder = AbydeDriveArchiveFolder::where('folder_name', 'Business Associates')->first();
                        $ba_name_folder = AbydeDriveArchiveFolder::updateOrCreate([
                            'folder_name' => $business_associative->name . '_' . $business_associative->id,
                            'parent_folder_id' => $abyde_drive_folder->id,
                        ]);
                        $agreement_folder = AbydeDriveArchiveFolder::updateOrCreate([
                            'folder_name' => 'Agreement',
                            'parent_folder_id' => $ba_name_folder->id,
                        ]);
                        $file_data = [];
                        foreach ($business_associative->businessAssociatesLocation as $location) {
                            $emp_name_folder_location = AbydeDriveArchiveFolderLocation::create([
                                'archive_folder_id' => $ba_name_folder->id,
                                'location_id' => $location->location_id,
                            ]);

                            $agreement_folder_location = AbydeDriveArchiveFolderLocation::create([
                                'archive_folder_id' => $agreement_folder->id,
                                'location_id' => $location->location_id,
                            ]);

                            $file_data[] = [
                                'file_name' => $new_file_name,
                                'title' => $title,
                                'archive_folder_id' => $agreement_folder_location->id,
                                'file_size' => $file_size,
                                'created_at' => Carbon::now(),
                                'updated_at' => Carbon::now(),
                            ];
                        }
                        AbydeDriveArchiveFile::insert($file_data);
                    }
                }
            }
            foreach ($business_associative->businessAssociatesLocation as $location) {
                $this->addPolicyVersionData('BACP', $location->location_id);
                if ($location->salesforce_unique_id != null) {
                    SendLocationDataToSalesForce::dispatch($location->location->id);
                }
            }
            $business_associative->delete();

            return $this->success(Config::get('constants.BUSINESSASSOCIATES.BUSINESSASSOCIATES_DELETED'), 200);
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/deleteBusinessAssociates() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/deleteBusinessAssociates()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Import business Associates from file
     *
     * @return \Illuminate\Http\Response
     */
    public function importBusinessAssociates(Request $request)
    {
        $user_data = $this->getMainAccountDetails();
        $generalController = new GeneralController;
        $location_access_list = $generalController->getAssingedLocationList();
        $location_list_count = Location::whereHas('hipaaComplianceOfficer')
            ->whereHas('companyModuleCompleted')
            ->whereHas('sraModuleCompleted')
            ->whereHas('disasterRecoveryPlanModuleCompleted')
            ->where(function ($query) {
                $query->whereHas('employeePrimaryWorkLocation')->orWhereHas('employeeSecondaryWorkLocation');
            })
            ->where('user_id', $user_data['id'])
            ->whereIn('id', $location_access_list)
            ->count();
        $validator_rules = [
            'import_file' => 'required|mimes:xls,xlsx',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules, []);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.BUSINESSASSOCIATES.INVALID_IMPORT_FILE'), 200, $validator_check->errors()->all());
        }
        // check exce sheet format
        $headings = (new HeadingRowImport)->toArray($request['import_file']);
        if ($location_list_count == 1) {
            $heading_array = ['vendor_name', 'email', 'expiration_date', 'phone_number'];
        } else {
            $heading_array = ['vendor_name', 'email', 'expiration_date', 'phone_number', 'assigned_locations'];
        }
        $headings[0][0] = array_filter($headings[0][0], function ($v) {
            return trim($v) == true;
        });
        $missing_heading = array_diff($heading_array, $headings[0][0]);
        if ($missing_heading) {
            return $this->error(Config::get('constants.BUSINESSASSOCIATES.IMPORT_FILE_INVALID_TEMPLETE'), 200);
        }
        try {
            if ($request->has('import_file')) {
                // import Business Associates
                $import = new BusinessAssociatesImport;
                $import->import($request['import_file']);
                if ($import->failures()->isNotEmpty()) {
                    $error = [];
                    $i = 0;
                    foreach ($import->failures() as $failure) {
                        foreach ($failure->errors() as $value) {
                            $error[$i] = $value . 'Row No :' . $failure->row();
                            $i++;
                        }
                    }

                    Log::error('BusinessAssociatesController/importBusinessAssociates(ImportValidation) => ' . json_encode($error));

                    if ($import->row_count == 0) {
                        return $this->error(Config::get('constants.BUSINESSASSOCIATES.IMPORT_ERROR'), 200, $error);
                    } else {
                        return $this->success(Config::get('constants.BUSINESSASSOCIATES.PARTIALLY_IMPORT_ERROR'), 200, $error);
                    }
                }
                if ($import->row_count == 0) {
                    return $this->error(Config::get('constants.BUSINESSASSOCIATES.IMPORT_ERROR'), 200, $import->invalid_locations);
                }
                if ($import->row_count == $import->total_row_count) {
                    return $this->success(Config::get('constants.BUSINESSASSOCIATES.IMPORTED'), 200);
                } else {
                    return $this->success(Config::get('constants.BUSINESSASSOCIATES.PARTIALLY_IMPORT_ERROR'), 200, $import->invalid_locations);
                }
            }
        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            Log::error('BusinessAssociatesController/importBusinessAssociates() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/importBusinessAssociates()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.BUSINESSASSOCIATES.IMPORT_ERROR'), 200);
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/importBusinessAssociates() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/importBusinessAssociates()[data] => ' . json_encode($request->all()));
            if ($e->getMessage() == 'more_than_limit_records') {
                return $this->error(Config::get('constants.IMPORT_LIMIT'), 200);
            } else {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        }
    }

    /**
     * Send agreement email
     *
     * @return \Illuminate\Http\Response
     */
    public function sendAgreementEmail(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'business_associative_id' => 'required',
                'officer_name' => 'required',
                'officer_title' => 'required',
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $business_associative = BusinessAssociates::with('businessAssociatesLocation.location')->findOrFail($request['business_associative_id']);
            $business_associative_agreement = BusinessAssociatesAgreement::where('business_associates_id', $business_associative->id)->first();
            if ($business_associative_agreement == null) {
                foreach ($business_associative->businessAssociatesLocation as $location) {
                    $this->addPolicyVersionData('BACP', $location->location_id);
                }
            }
            $ref_token = \Str::random(10);
            $input_fields = $request->all();
            $input_fields['reference_token'] = $ref_token;
            if ($business_associative_agreement == null) {
                BusinessAssociatesAgreement::create([
                    'business_associates_id' => $business_associative->id,
                    'reference_token' => $input_fields['reference_token'],
                    'agreement_type' => 'system',
                    'officer_name' => $input_fields['officer_name'],
                    'officer_title' => $input_fields['officer_title'],
                    'location_id' => $input_fields['location_id'],
                ]);
            } else {
                $business_associative_agreement->update($input_fields);
            }

            $hco = HipaaComplianceOfficer::where('location_id', $request['location_id'])->with(['hco', 'location'])->first();
            $emailTemplate = EmailTemplate::where('code', 'HCE-UE16')->first();
            $email_vars = [
                '{%BA_NAME%}' => $business_associative->name,
                '{%COMPANY_NAME%}' => $user_data->company_name,
                '{%VIEW_AGREEMENT%}' => Config::get('app.url') . '/businessassociatesportal/agreement/' . base64_encode($business_associative->id) . '/' . $ref_token,
                '{%HCO_OFFICER%}' => $hco->hco->first_name . ' ' . $hco->hco->last_name,
                '{%HCO_OFFICER_EMAIL%}' => $hco->hco->email,
                '{%PRACTICE_PHONE_NUMBER%}' => $hco->location->phone_no,
                '{%PRACTICE_NAME%}' => $hco->location->company_name,
                '{%FEDERAL_REGULATION_45_CFR%}' => url('https://www.hhs.gov/sites/default/files/ocr/privacy/hipaa/understanding/coveredentities/businessassociates.pdf'),
            ];
            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
            $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
            $this->sendEmail($emailTemplate->code, $html, $business_associative->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));

            return $this->success(Config::get('constants.BUSINESSASSOCIATES.BUSINESSASSOCIATES_SEND_AGREEMENT'), 200);
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/sendAgreementEmail() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/sendAgreementEmail()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get employees list by location id
     *
     * @return \Illuminate\Http\Response
     */
    public function getEmployeesHco(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $employees = Employee::where('primary_work_location_id', $request['location_id'])
                ->orWhereHas('employeeSecondaryWorkLocation', function ($q) use ($request) {
                    $q->where('location_id', $request->location_id);
                })
                ->isActive()->get()->toArray();
            foreach ($employees as $key => $employee) {
                $employees[$key]['is_hco'] = 0;
                $hco_count = AccountUser::where('email', $employee['email'])->has('hipaaComplianceOfficer')->count();
                if ($hco_count == 0) {
                    $hco_count = User::where('email', $employee['email'])->has('hipaaComplianceOfficer')->count();
                }
                if ($hco_count > 0) {
                    $employees[$key]['is_hco'] = 1;
                }
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $employees);
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/getEmployeesByUserId() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/getEmployeesByUserId()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * generate agreement by url or doc file
     *
     * @return \Illuminate\Http\Response
     */
    public function agreementByUrlDocOfBussinessAssociative(Request $request)
    {
        try {
            $validator_rules = [
                'business_associative_id' => 'required',
                'agreement_type' => 'required|in:url,doc',
                'agreement_link' => 'nullable',
                'file' => 'nullable',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $business_associative = BusinessAssociates::with('user.reseller', 'businessAssociatesLocation')->findOrFail($request['business_associative_id']);
            $business_associative_agreement = BusinessAssociatesAgreement::where('business_associates_id', $business_associative->id)->first();
            foreach ($business_associative->businessAssociatesLocation as $location) {
                $this->addPolicyVersionData('BACP', $location->location_id);
            }
            $input_fields = $request->all();
            if ($request['agreement_type'] == 'url') {
                if ($business_associative_agreement == null) {
                    BusinessAssociatesAgreement::create([
                        'business_associates_id' => $business_associative->id,
                        'agreement_type' => $input_fields['agreement_type'],
                        'agreement_link' => $input_fields['agreement_link'],
                    ]);
                } else {
                    $business_associative_agreement->update([
                        'location_id' => null,
                        'reference_token' => null,
                        'agreement_type' => $input_fields['agreement_type'],
                        'agreement_link' => $input_fields['agreement_link'],
                    ]);
                }
            } else {
                if ($request->has('file')) {
                    $filePath = '/generatedpolicydocuments/businessassociateagreement/';
                    $doc = $request->file('file');
                    $file_name = $business_associative->id . '_' . $doc->getClientOriginalName();
                    $path = $doc->storeAs(
                        $filePath,
                        $file_name, //$fileName
                        ['disk' => 's3'] //$options
                    );
                    $business_associates_agreement = $this->getSignedURL('/generatedpolicydocuments/businessassociateagreement/' . $business_associative->id . '/' . $file_name);
                    if ($business_associative_agreement == null) {
                        BusinessAssociatesAgreement::create([
                            'business_associates_id' => $business_associative->id,
                            'agreement_type' => $input_fields['agreement_type'],
                            'file_name' => $file_name,
                        ]);
                    } else {
                        $business_associative_agreement->update([
                            'location_id' => null,
                            'reference_token' => null,
                            'agreement_type' => $input_fields['agreement_type'],
                            'file_name' => $file_name,
                        ]);
                    }
                }
            }
            $this->sendHCEUE20EmailToBA($business_associative, $business_associative_agreement, 'predefine_doc_url', null);

            return $this->success(Config::get('constants.BUSINESSASSOCIATES.BUSINESSASSOCIATES_SEND_AGREEMENT_UPLOAD'), 200);
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/agreementByUrlDocOfBussinessAssociative() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/agreementByUrlDocOfBussinessAssociative()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * complete agreement for predefined ba
     *
     * @return \Illuminate\Http\Response
     */
    public function completeAgreementForPredefinedBa(Request $request)
    {
        try {
            $validator_rules = [
                'business_associates_id' => 'required',
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $business_associates = BusinessAssociates::with('predefineBusinessAssociative', 'businessAssociatesLocation')->findOrFail($request['business_associates_id']);
            $predefine_ba = $business_associates->predefineBusinessAssociative;
            $location = Location::with(['state', 'hipaaComplianceOfficer.hco'])->findOrFail($request['location_id']);
            $public_path = public_path();
            $storage_path = storage_path('app/public');
            $predefine_ba_doc_filename = $public_path . '/policydocuments/' . $predefine_ba->doc_file;
            $generated_agreement_directory_path = $storage_path . '/generatedpolicydocuments/';
            $gnerated_business_associates_agreement_filename = $business_associates->id . '_' . $predefine_ba->doc_file;
            $gnerated_business_associates_agreement_pdf_name = str_replace('docx', 'pdf', $gnerated_business_associates_agreement_filename);
            $gnerated_business_associates_agreement_file_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_business_associates_agreement_filename;
            $gnerated_business_associates_agreement_pdf_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_business_associates_agreement_pdf_name;
            $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($predefine_ba_doc_filename);
            // WVA agreement for predefine business associate
            if ($predefine_ba->id == 4) {
                $predefine_doc_jsondata = json_decode($predefine_ba['predefinedBAInformation']);
                $generalController = new GeneralController;
                $logo_data = $generalController->_addCompanyLogoOnCoverPage($location);
                $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
                $generalController->_removeTempCompanyLogo($location, $logo_data['temp_file_path']);
                $template_processor->setValue('CLIENT_NAME', htmlspecialchars($location->company_name));
                $template_processor->setValue('CLIENT_ADDRESS', htmlspecialchars($location->address));
                $template_processor->setValue('CLIENT_CITY', htmlspecialchars($location->city));
                $template_processor->setValue('CLIENT_STATE', htmlspecialchars($location->state->state_name));
                $template_processor->setValue('CLIENT_ZIP', htmlspecialchars($location->zip_code));
                $template_processor->setValue('CLIENT_PHONE_NUMBER', htmlspecialchars($location->phone_no));
                $template_processor->setValue('CLIENT_FAX_NUMBER', htmlspecialchars($location->fax_no));

                $template_processor->setValue('EXPORT_DATE', date('F j, Y', strtotime($business_associates->created_at)));
                $template_processor->setValue('BA_NAME', htmlspecialchars($predefine_ba->name));
                $template_processor->setValue('BA_ADDRESS', htmlspecialchars($predefine_doc_jsondata->tAddress));
                $template_processor->setValue('BA_CITY', htmlspecialchars($predefine_doc_jsondata->vCity) . ',');
                $template_processor->setValue('BA_STATE', htmlspecialchars($predefine_doc_jsondata->vState));
                $template_processor->setValue('BA_ZIP', htmlspecialchars($predefine_doc_jsondata->vZipcode));
                $template_processor->setValue('BA_PHONE_NUMBER', htmlspecialchars($predefine_doc_jsondata->vPhoneNumber));
                $template_processor->setValue('BA_FAX_NUMBER', htmlspecialchars($predefine_doc_jsondata->vFaxNo));
                $template_processor->setValue('BA_OFFICER_NAME', htmlspecialchars($predefine_doc_jsondata->vOfficerName));

                $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($location['hipaaComplianceOfficer']['hco']['first_name'] . ' ' . $location['hipaaComplianceOfficer']['hco']['last_name']));
                $template_processor->setValue('HIPAA_COMPLIANCE_TITLE', 'HIPAA COMPLIANCE OFFICER');
                $template_processor->setValue('SIGNATURE_SEND_DATE', date('m/d/Y', strtotime($business_associates->created_at)));

                $template_processor->setValue('BA_SIGNATURE_DATE', date('m/d/Y', strtotime($business_associates->created_at)));
                $template_processor->setValue('USER_SIGN', htmlspecialchars($location['hipaaComplianceOfficer']['hco']['first_name'] . ' ' . $location['hipaaComplianceOfficer']['hco']['last_name']));
                $template_processor->setValue('BA_SIGN', htmlspecialchars($predefine_doc_jsondata->vOfficerName));
            }
            // open dental agreement for predefine business associate
            if ($predefine_ba->id == 5) {
                $template_processor->setValue('CLIENT_NAME', htmlspecialchars($location->company_name));
                $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', htmlspecialchars($location['hipaaComplianceOfficer']['hco']['first_name'] . ' ' . $location['hipaaComplianceOfficer']['hco']['last_name']));
                $template_processor->setValue('HIPAA_COMPLIANCE_TITLE', 'HIPAA COMPLIANCE OFFICER');
                $template_processor->setValue('SIGNATURE_SEND_DATE', date('m/d/Y'));
                $template_processor->setValue('USER_SIGN', htmlspecialchars($location['hipaaComplianceOfficer']['hco']['first_name'] . ' ' . $location['hipaaComplianceOfficer']['hco']['last_name']));
            }
            foreach ($business_associates->businessAssociatesLocation as $location) {
                $this->addPolicyVersionData('BACP', $location->location_id);
            }
            $template_processor->saveAs($gnerated_business_associates_agreement_file_path);
            if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                // change libreoffice path as per installation path from your machine
                exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  ' . $generated_agreement_directory_path . ' ' . $gnerated_business_associates_agreement_file_path);
            } else {
                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir ' . $generated_agreement_directory_path . ' ' . $gnerated_business_associates_agreement_file_path);
            }
            if (file_exists($gnerated_business_associates_agreement_pdf_path)) {
                $file_contents = \File::get($gnerated_business_associates_agreement_pdf_path);
                Storage::disk('s3')->put('/generatedpolicydocuments/businessassociateagreement/' . $gnerated_business_associates_agreement_pdf_name, $file_contents);
            }
            $business_associative_agreement = BusinessAssociatesAgreement::where('business_associates_id', $business_associates->id)->first();
            $business_associative_agreement->file_name = $gnerated_business_associates_agreement_pdf_name;
            $business_associative_agreement->location_id = $request['location_id'];
            $business_associative_agreement->save();
            if ($predefine_ba->id == 4 && $predefine_ba->send_agreement_email == 1) {
                $this->sendHCEUE20EmailToBA($business_associates, $business_associative_agreement, 'WVA_predefine_ba', $gnerated_business_associates_agreement_pdf_path);
            }
            if ($predefine_ba->id == 5 && $predefine_ba->send_agreement_email == 1) {
                $this->sendHCEUE20EmailToBA($business_associates, $business_associative_agreement, null, $gnerated_business_associates_agreement_pdf_path);
            }

            return $this->success(Config::get('constants.BUSINESSASSOCIATES.BUSINESSASSOCIATES_SEND_AGREEMENT_COMPLETED'), 200);
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/completeAgreementForPredefinedBa() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/completeAgreementForPredefinedBa()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get last updated Business Associates for dashboard
     */
    public function getLastUpdatedBusinessAssociates($location_id)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $location_id, 'module_name' => 'business_associates'])->first();
            if ($is_avail) {
                return $is_avail->updated_at;
            } else {
                $user_id = Location::find($location_id)->user_id;
                $latest_ba = BusinessAssociates::where('user_id', $user_id)
                    ->wherehas('businessAssociatesLocation', function ($query) use ($location_id) {
                        $query->where('location_id', $location_id);
                    })
                    ->orderBy('updated_at', 'DESC')->first();
                $check_agrrement_date = BusinessAssociatesAgreement::with('BusinessAssociates')
                    ->whereHas('BusinessAssociates', function ($q) use ($user_id) {
                        $q->where('user_id', $user_id);
                    })->orderBy('updated_at', 'DESC')->first();
                if ($latest_ba) {
                    if ($check_agrrement_date) {
                        if ($latest_ba->updated_at > $check_agrrement_date->updated_at) {
                            return $latest_ba->updated_at;
                        } else {
                            return $check_agrrement_date->updated_at;
                        }
                    } else {
                        return $latest_ba->updated_at;
                    }
                } else {
                    return '';
                }
            }
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/getLastUpdatedBusinessAssociates() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/getLastUpdatedBusinessAssociates()[data] => ' . json_encode(['location_id' => $location_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * send HCE-UE20 email to BA with NPP attachment
     */
    public function sendHCEUE20EmailToBA($business_associative, $business_associates_agreement, $call_from = null, $document = null)
    {
        if ($call_from == 'predefine_doc_url') {
            $user_data = $this->getMainAccountDetails();
            //$user_first_location = $user_data->locations[0];
            $user_first_location = $business_associative->businessAssociatesLocation[0]->location;
        }
        $location_id = ($call_from == 'predefine_doc_url' ? $user_first_location->id : $business_associates_agreement->location_id);
        $attachments = [];
        if ($document != null) {
            array_push($attachments, $document);
        }
        $npp_policy = Policy::where('code', 'NPP')->first();
        $public_path = public_path();
        $storage_path = storage_path('app/public');
        $policy_filename = $npp_policy->doc_file_name;
        $policy_file_path = $public_path . '/policydocuments/' . $policy_filename;
        $generated_policy_directory_path = $storage_path . '/generatedpolicydocuments/';
        $gnerated_policy_doc_name = $location_id . '_' . $policy_filename;
        $gnerated_policy_pdf_name = str_replace('docx', 'pdf', $gnerated_policy_doc_name);
        $gnerated_policy_file_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_policy_doc_name;
        $gnerated_policy_pdf_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_policy_pdf_name;
        $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($policy_file_path);
        $template_processor->setValue('EFFECTIVE_DATE', htmlspecialchars('Accessed on ' . gmdate('m/d/Y')));
        $template_processor->setValue('SIGNUP_DATE', htmlspecialchars(''));
        $template_processor->setValue('CLIENT_NAME', htmlspecialchars(($call_from == 'predefine_doc_url' ? $user_first_location['company_name'] : $business_associates_agreement->location->company_name)));
        $template_processor->setValue('CLIENT_PHONE_NUMBER', htmlspecialchars(($call_from == 'predefine_doc_url' ? $user_first_location['phone_no'] : $business_associates_agreement->location->phone_no)));
        $template_processor->saveAs($gnerated_policy_file_path);
        if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
            // change libreoffice path as per installation path from your machine
            exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  ' . $generated_policy_directory_path . ' ' . $gnerated_policy_file_path);
        } else {
            exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir ' . $generated_policy_directory_path . ' ' . $gnerated_policy_file_path);
        }
        array_push($attachments, $gnerated_policy_pdf_path);
        $emailTemplate = EmailTemplate::where('code', 'HCE-UE20')->first();
        $email_vars = [
            '{%BA_NAME%}' => $business_associative->name,
            '{%COMPANY_NAME%}' => ($call_from == 'predefine_doc_url' ? $user_first_location['company_name'] : $business_associates_agreement->location->company_name),
            '{%HCO_FIRST_NAME%}' => ($call_from == 'predefine_doc_url' ? $user_data['first_name'] : $business_associates_agreement['location']['hipaaComplianceOfficer']['hco']['first_name']),
            '{%HCO_LAST_NAME%}' => ($call_from == 'predefine_doc_url' ? $user_data['last_name'] : $business_associates_agreement['location']['hipaaComplianceOfficer']['hco']['last_name']),
            '{%HCO_OFFICER_EMAIL%}' => ($call_from == 'predefine_doc_url' ? $user_data['email'] : $business_associates_agreement['location']['hipaaComplianceOfficer']['hco']['email']),
        ];
        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
        $html_subject = str_ireplace(['{%COMPANY_NAME%}', '{%BA_NAME%}'], [($call_from == 'predefine_doc_url' ? $user_first_location['company_name'] : $business_associates_agreement->location->company_name), $business_associative->name], $emailTemplate->subject);
        if ($call_from == 'WVA_predefine_ba') {
            foreach ($attachments as $attachment) {
                $this->sendEmail($emailTemplate->code, $html, $business_associative->email, Config::get('app.from_user_email'), $html_subject, $attachment, null, true, ($business_associative->user->partner_reseller_id != null ? $business_associative->user->reseller->logo : null));
            }
        } else {
            $this->sendEmail($emailTemplate->code, $html, $business_associative->email, Config::get('app.from_user_email'), $html_subject, $attachments, null, true, ($business_associative->user->partner_reseller_id != null ? $business_associative->user->reseller->logo : null));
        }
    }

    public function downloadAgreementWithoutSignature(Request $request)
    {
        try {
            $validator_rules = [
                'business_associate_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $business_associate = BusinessAssociates::with('businessAssociatesAgreement')->where('id', $request->business_associate_id)->first();

            if ($business_associate->businessAssociatesAgreement) {
                $location = Location::where('id', $business_associate->businessAssociatesAgreement->location_id)->with(['state', 'hipaaComplianceOfficer.hco'])->first();
            } else {
                $location = Location::where('user_id', $business_associate->user_id)
                    ->whereHas('hipaaComplianceOfficer')
                    ->with(['state', 'hipaaComplianceOfficer.hco'])->first();
            }

            $public_path = public_path();
            $storage_path = storage_path('app/public');
            $filename = 'BusinessAssociateAgreement.docx';
            $file_path = $public_path . '/policydocuments/' . $filename;
            $generated_agreement_directory_path = $storage_path . '/generatedpolicydocuments/';
            $gnerated_doc_name = $business_associate->id . '_' . $filename;
            $gnerated_pdf_name = str_replace('docx', 'pdf', $gnerated_doc_name);

            $gnerated_file_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_doc_name;
            $gnerated_pdf_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_pdf_name;
            $gnerated_pdf_url = asset('storage/generatedpolicydocuments/' . $gnerated_pdf_name);
            $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($file_path);

            $generalController = new GeneralController;
            $logo_data = $generalController->_addCompanyLogoOnCoverPage($location);
            $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
            $generalController->_removeTempCompanyLogo($location, $logo_data['temp_file_path']);
            $template_processor->setValue('CLIENT_NAME', htmlspecialchars($location->company_name));
            $template_processor->setValue('LOCATION_NAME', htmlspecialchars($location->location_nickname));
            $template_processor->setValue('CLIENT_ADDRESS', htmlspecialchars($location->address));
            $template_processor->setValue('CLIENT_CITY', htmlspecialchars($location->city));
            $template_processor->setValue('CLIENT_STATE', htmlspecialchars($location->state->state_name));
            $template_processor->setValue('CLIENT_ZIP', htmlspecialchars($location->zip_code));
            $template_processor->setValue('CLIENT_PHONE_NUMBER', htmlspecialchars($location->phone_no));
            $template_processor->setValue('CLIENT_FAX_NUMBER', $location->fax_no != null ? htmlspecialchars($location->fax_no) : 'N/A');

            $template_processor->setValue('EXPORT_DATE', $business_associate->businessAssociatesAgreement ? date('F j, Y', strtotime($business_associate->businessAssociatesAgreement->updated_at)) : date('F j, Y'));
            $template_processor->setValue('BA_NAME', htmlspecialchars($business_associate->name));
            $template_processor->setValue('BA_PHONE_NUMBER', $business_associate->phone_number != null ? htmlspecialchars($business_associate->phone_number) : 'N/A');

            $template_processor->setValue('HIPAA_COMPLIANCE_OFFICER', $business_associate->businessAssociatesAgreement ? (htmlspecialchars($business_associate->businessAssociatesAgreement->officer_name)) : '');
            $template_processor->setValue('HIPAA_COMPLIANCE_TITLE', $business_associate->businessAssociatesAgreement ? htmlspecialchars($business_associate->businessAssociatesAgreement->officer_title) : '');
            $template_processor->setValue('PRACTICE_NAME', $business_associate->businessAssociatesAgreement ? htmlspecialchars($location->company_name) : '');
            $template_processor->setValue('SIGNATURE_SEND_DATE', $business_associate->businessAssociatesAgreement ? date('m/d/Y', strtotime($business_associate->businessAssociatesAgreement->created_at)) : '');
            $template_processor->setValue('USER_SIGN', $business_associate->businessAssociatesAgreement ? (htmlspecialchars($business_associate->businessAssociatesAgreement->officer_name)) : '');

            $template_processor->setValue('BA_OFFICER_NAME', '');
            $template_processor->setValue('BA_OFFICER_TITLE', '');
            $template_processor->setValue('BA_ADDRESS', '');
            $template_processor->setValue('BA_CITY', '');
            $template_processor->setValue('BA_STATE', '');
            $template_processor->setValue('BA_ZIP', '');
            $template_processor->setValue('BA_FAX_NUMBER', '');

            $template_processor->setValue('BA_SIGNATURE_DATE', '');
            $template_processor->setValue('BA_SIGN', '');

            $template_processor->saveAs($gnerated_file_path);
            if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                // change libreoffice path as per installation path from your machine
                exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  ' . $generated_agreement_directory_path . ' ' . $gnerated_file_path);
            } else {
                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir ' . $generated_agreement_directory_path . ' ' . $gnerated_file_path);
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, ['file_name' => $business_associate->id . '_BusinessAssociateAgreement.pdf', 'download_url' => $gnerated_pdf_url]);
        } catch (\Exception $e) {
            Log::error('downloadAgreementWithoutSignature/downloadAgreementWithoutSignature() => ' . $e->getMessage());
            Log::error('downloadAgreementWithoutSignature/downloadAgreementWithoutSignature()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function sendReminderEmail(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'business_associative_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $ref_token = \Str::random(10);
            $business_associative = BusinessAssociates::findOrFail($request['business_associative_id']);
            $business_associative_agreement = BusinessAssociatesAgreement::where('business_associates_id', $business_associative->id)->first();
            $hco = HipaaComplianceOfficer::where('location_id', $business_associative_agreement['location_id'])->with(['hco', 'location'])->first();
            if ($business_associative_agreement !== null) {
                if (BusinessAssociatesAgreement::where('business_associates_id', $business_associative->id)->update([
                    'reference_token' => $ref_token,
                ])) {
                    $emailTemplate = EmailTemplate::where('code', 'HCE-UE17')->first();
                    $email_vars = [
                        '{%BA_NAME%}' => $business_associative->name,
                        '{%COMPANY_NAME%}' => $user_data->company_name,
                        '{%VIEW_AGREEMENT%}' => Config::get('app.url') . '/businessassociatesportal/agreement/' . base64_encode($business_associative->id) . '/' . $ref_token,
                        '{%HCO_OFFICER%}' => $hco->hco->first_name . ' ' . $hco->hco->last_name,
                        '{%PRACTICE_PHONE_NUMBER%}' => $hco->location->phone_no,
                        '{%HCO_OFFICER_EMAIL%}' => $hco->hco->email,
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
                    $this->sendEmail($emailTemplate->code, $html, $business_associative->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                }
            }

            return $this->success(Config::get('constants.BUSINESSASSOCIATES.BUSINESSASSOCIATES_SEND_AGREEMENT_REMIND'), 200);
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/sendReminderEmail() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/sendReminderEmail()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * BA assigned location list
     */
    public function getBusinessAssociatesAssignedLocationList(Request $request)
    {
        $validator_rules = [
            'ba_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $user_data = $this->getMainAccountDetails();
            $locations = Location::where('user_id', $user_data['id'])
                ->whereHas('businessAssociatesLocation', function ($q) use ($request) {
                    $q->where('business_associate_id', $request->ba_id);
                })
                ->select(['id', 'location_nickname'])
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $locations);
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/getBAList() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/getBusinessAssociatesAssignedLocationList()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    /**
     * check location is unasssigned
     */
    public function checkLocationUnassigned(Request $request)
    {
        $validator_rules = [
            'ba_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $ba_locations = BusinessAssociatesAgreement::where("business_associates_id", $request->ba_id)->pluck("location_id");
            if (!empty($ba_locations)) {
                $location_data = BusinessAssociatesLocation::where('business_associate_id', $request->ba_id)
                    ->whereIn('location_id', $ba_locations)
                    ->count();
                if ($location_data > 0) {
                    return $this->success(Config::get('constants.SUCCESS'), 200);
                }
            }
            return $this->error(Config::get('constants.BUSINESSASSOCIATES.BUSINESSASSOCIATES_LOCATION_DELETED'), 200);
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesController/checkLocationUnassigned() => ' . $e->getMessage());
            Log::error('BusinessAssociatesController/checkLocationUnassigned()[data] => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    /************************** */
    /*API methods - end
    /*************************** */
}
