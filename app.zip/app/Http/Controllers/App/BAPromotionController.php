<?php

namespace App\Http\Controllers\App;

use App\Exports\ExportBAPromotionList;
use App\Http\Controllers\Controller;
use App\Models\BaPromotionResponse;
use App\Traits\ApiResponser;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;
use Maatwebsite\Excel\Excel as ExcelC;
use Maatwebsite\Excel\Facades\Excel;

class BAPromotionController extends Controller
{
    use ApiResponser, SendMail;

    public function showPromoLogPage()
    {
        return view('admin.pages.logs.bapromotion');
    }

    /**
     * list ba promotion response details
     *
     * @return \Illuminate\Http\Response
     */
    public function getBAPromotionList(Request $request)
    {
        try {
            $ba_promo_list = BaPromotionResponse::withAggregate('user', 'first_name')
                ->withAggregate('user', 'last_name')
                ->withAggregate('user', 'company_name')
                ->withAggregate('user', 'email');
            if ($request->has('search') && $request['search'] != '') {
                $ba_promo_list = $ba_promo_list->whereHas('user', function ($q) use ($request) {
                    $q->where('first_name', 'LIKE', '%'.$request->input('search').'%')
                        ->orWhere('last_name', 'LIKE', '%'.$request->input('search').'%')
                        ->orWhere('email', 'LIKE', '%'.$request->input('search').'%')
                        ->orWhere('company_name', 'LIKE', '%'.$request->input('search').'%');
                });
            }
            if ($request->input('filter_by')) {
                $ba_promo_list = $ba_promo_list->where('is_interested', (
                    $request->input('filter_by') == 'yes' ? 1 : ($request->input('filter_by') == 'ask later' ? 2 : 0)
                ));
            }
            if ($request->input('sort_column')) {
                $ba_promo_list = $ba_promo_list->orderBy($request->input('sort_column'), $request->input('sort_order'));
            }
            $ba_promo_list = $ba_promo_list->paginate($request->input('selected_show_entry'))->onEachSide(1);

            return $this->success(Config::get('constants.SUCCESS'), 200, $ba_promo_list);

        } catch (\Exception $e) {
            Log::error('BAPromotionController/getBAPromotionList() => '.$e->getMessage());
            Log::error('BAPromotionController/getBAPromotionList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function exportBAPromotionList()
    {
        try {
            $export = new ExportBAPromotionList;

            return $this->success(Config::get('constants.SUCCESS'), 200,
                [
                    'name' => 'BA Promotion Response List.xlsx',
                    'file' => 'data:application/vnd.ms-excel;base64,'.base64_encode(Excel::raw($export, ExcelC::XLSX)),
                ]
            );
        } catch (\Exception $e) {
            Log::error('BAPromotionController/exportBAPromotionList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
}
