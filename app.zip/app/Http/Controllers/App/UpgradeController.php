<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\EmailTemplate;
use App\Models\EmployeeLimitPrice;
use App\Models\Location;
use App\Models\LocationLimitPrice;
use App\Models\Partner;
use App\Models\Promocode;
use App\Models\User;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\GetLoginUserData;
use App\Traits\GetMainUserData;
use App\Traits\PricingHelper;
use App\Traits\SendMail;
use App\Traits\ChargebeePlan;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Exceptions\PaymentException;
use ChargeBee\ChargeBee\Models\Estimate;
use ChargeBee\ChargeBee\Models\Subscription;
use ChargeBee\ChargeBee\Models\Customer;
use ChargeBee\ChargeBee\Models\Invoice;
use Stripe;

class UpgradeController extends Controller
{
    use ApiResponser, ApiResponser, CheckAccessRight, GetLoginUserData, GetMainUserData, PricingHelper, SendMail, ChargebeePlan;

    /**
     * Upgrade page
     *
     * @return \Illuminate\Http\Response
     */
    public function showUpgrade(Request $request)
    {
        $user_data = $this->getLoginUserData();
        if ($this->checkAccessRight('upgrade') && $user_data->is_sra_user == 0 && ($user_data->partner_reseller_id == null || ($user_data->partner_reseller_id != null && $user_data->is_admin_panel_login == 'true'))) {
            return view('app.pages.upgrade');
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get user current plan information
     *
     * @return \Illuminate\Http\Response
     */
    public function getLocationEmployeeInformation(Request $request)
    {
        $user_data = $this->getMainAccountDetails();
        $location_max_limit = LocationLimitPrice::max('limit');
        $employee_max_limit = EmployeeLimitPrice::max('min_limit');
        Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
        $subscription_response = Subscription::retrieve($user_data->chargebee_subscription_id);
        $subscription = $subscription_response->subscription();
        $employee_range = [];
        foreach ($subscription->itemTiers as $key => $value) {
            if(str_contains($value->itemPriceId, 'Employees')){
                $employee_range[$key]['id'] = $key;
                $employee_range[$key]['min_limit'] = (int)$value->startingUnitInDecimal + 1;
                if(isset($value->endingUnitInDecimal)){
                    $employee_range[$key]['max_limit'] = (int)$value->endingUnitInDecimal;
                    $employee_range[$key]['limit'] = ((int)$value->startingUnitInDecimal + 1).'-'.(int)$value->endingUnitInDecimal;
                }else{
                    $employee_range[$key]['max_limit'] = 3500;
                    $employee_range[$key]['limit'] = ((int)$value->startingUnitInDecimal + 1).'-3500';
                }
            }
        }
        if ($subscription->billingPeriodUnit == "month") {
            $plan_type = "monthly";
            if ($subscription->billingPeriod == 3) {
                $plan_type = "quarterly";
            }
            if ($subscription->billingPeriod == 6) {
                $plan_type = "biannually";
            }
        } else {
            $plan_type = "yearly";
        }
        $location_limit = 0;
        $current_employee_limit = 0;
        $employee_range[3501] = array(
            'id' => 3501,
            'min_limit' => 3501,
            'max_limit' => 20000,
            'limit' => "3501+",
        );
        foreach($subscription->subscriptionItems as $subscriptionItems){
            if($subscriptionItems->itemType == 'addon' && str_contains($subscriptionItems->itemPriceId, 'Locations')){
                $location_limit = $subscriptionItems->quantity;
            }
            if($subscriptionItems->itemType == 'addon' && str_contains($subscriptionItems->itemPriceId, 'Employees')){
                $current_employee_limit = collect($employee_range)->where('max_limit',$subscriptionItems->quantity)->first();
            }
        }
                        
        $is_software_upgrade_enabled = 0;
        if (Carbon::today()->gte(Carbon::parse($user_data->chargebee_first_renewal_date))) {
            $is_software_upgrade_enabled = 1;
        }
        $data = [
            'user_current_location_limit' => $location_limit,
            'user_current_employee_limit' => $current_employee_limit,
            'employee_limit' => $employee_range,
            'employee_max_limit' => $employee_max_limit,
            'location_max_limit' => $location_max_limit,
            'chargebee_subscription' => ['plan_type' => $plan_type],
            'is_software_upgrade_enabled' => $is_software_upgrade_enabled,
            'has_scheduled_changes' => $subscription->hasScheduledChanges,
            'subscription_status' => $subscription->status,
        ];

        return $this->success('', 200, $data);
    }

    /**
     * get chargebee price upgrade estimation for show information in upgrade page
     *
     * @return \Illuminate\Http\Response
     */
    public function getChargebeePriceUpgradeEstimation(Request $request)
    {

        try {
            $validator_rules = [
                'location_limit' => 'required',
                'employee_limit' => 'required',
                'employee_max_limit' => 'required',
                'employee_max_limit_old' => 'required',
                'plan_type' => 'required',
                'is_chargebee_first_renewal_passed' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $user_data = $this->getMainAccountDetails();
            $subscription = $this->getSubscriptionDetails($user_data->chargebee_subscription_id);
            Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
            $version = 'v2';
            foreach ($subscription['item_tiers'] as $item_tiers) {
                if(str_contains($item_tiers['item_price_id'], 'Employees') && !empty($item_tiers['ending_unit']) && $item_tiers['ending_unit'] == 5){
                    $version = 'v1';
                    break;
                }
            }
            $chargebee_plan_ids = $this->getChargebeePlanId($request->plan_type, $user_data->chargebe_addon_type, 'normal', $version);
            $first_estimation_array = array(
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => 1
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['location_item_id'],
                        "quantity" => $request->location_limit
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['employee_item_id'],
                        "quantity" => $request->employee_max_limit
                    )
                ),
            );
            if (!empty($subscription['coupon'])) {
                $first_estimation_array["couponIds"] = array($subscription['coupon']);
            }
            $first_estimate_response = Estimate::createSubItemEstimate($first_estimation_array);
            $first_estimate = $first_estimate_response->estimate();
            $transaction_fee_percentage = Config::get('app.transaction_fee_percentage');
            $transaction_fee = (int)(($first_estimate->invoiceEstimate->total * $transaction_fee_percentage) / 100);
            $estimation_array = array(
                "invoiceImmediately" => true,
                "subscription" => array(
                    "id" => $user_data->chargebee_subscription_id
                ),
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => 1
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['location_item_id'],
                        "quantity" => $request->location_limit
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['employee_item_id'],
                        "quantity" => $request->employee_max_limit
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['transaction_fee_item_id'],
                        "unitPriceInDecimal" => ($transaction_fee / 100)
                    ),
                ),
            );
            $estimate_response = Estimate::updateSubscriptionForItems($estimation_array);
            $estimate = $estimate_response->estimate();
            $taxes = '';
            $discount = '';
            $invoice_estimate = $estimate->invoiceEstimate;

            if (isset($invoice_estimate->taxes) && !empty($invoice_estimate->taxes)) {
                $taxes = [];
                foreach ($invoice_estimate->taxes as $key => $value) {
                    $taxes[] = array(
                        'percentage' => $value->description,
                        'amount' => $value->amount
                    );
                }
            }
            if (isset($invoice_estimate->discounts[0]) && !empty($invoice_estimate->discounts[0])) {
                $discount = array(
                    'id' => $invoice_estimate->discounts[0]->entityId,
                    'promocode' => $invoice_estimate->discounts[0]->description,
                    'discount_percentage' => (isset($invoice_estimate->discounts[0]->discountPercentage)) ? $invoice_estimate->discounts[0]->discountPercentage : '',
                    'discount_type' => $invoice_estimate->discounts[0]->discountType,
                    'discount_amount' => $invoice_estimate->discounts[0]->amount
                );
            }
            $prorate_transaction_fee = 0;
            $tax_rate = 0;
            foreach ($invoice_estimate->lineItems as $line_items) {
                $tax_rate = (isset($line_items->taxRate)) ? $line_items->taxRate : 0;
                if ($line_items->entityId == $chargebee_plan_ids['transaction_fee_item_id']) {
                    $prorate_transaction_fee = $line_items->amount;
                }
            }

            $next_billing_at = Carbon::createFromTimestamp($estimate->subscriptionEstimate->nextBillingAt);
            $after_tax_price = 0;
            $manual_discount = 0;
            if ($request->is_chargebee_first_renewal_passed == 0 && $request->employee_max_limit_old != $request->employee_max_limit) {
                $local_upgrade_calculator = $this->upgradeCalculator($request->location_limit, $request->employee_max_limit, $request->plan_type, $next_billing_at->format('Y-m-d'));
                $before_tax_local_calculate_price = $local_upgrade_calculator['before_tax_local_calculate_price'];
                $after_tax_price = round($before_tax_local_calculate_price * (1 + ($tax_rate / 100)), 2);
                $after_credit_add_price = $after_tax_price + ($invoice_estimate->creditsApplied / 100);
                $required_new_subtotal = $after_credit_add_price / (1 + ($tax_rate / 100));
                $manual_discount = round(($invoice_estimate->subTotal / 100) - $required_new_subtotal, 2);
            }
            $final_response = array(
                'subscription_status' => $estimate->subscriptionEstimate->status,
                'next_billing_at' => $next_billing_at->format('Y-m-d'),
                'total' => $invoice_estimate->amountDue,
                'taxes' => $taxes,
                'discounts' => $discount,
                'transaction_fee' => $transaction_fee,
                'prorate_transaction_fee' => $prorate_transaction_fee,
                'local_calculate_price' => $after_tax_price,
                'manual_discount' => $manual_discount,
            );
            return $this->success(Config::get('constants.SUCCESS'), 200, $final_response);
        } catch (\Exception $e) {
            Log::error('UpgradeController/getChargebeePriceUpgradeEstimation() => ' . $e->getMessage());
            Log::error('UpgradeController/getChargebeePriceUpgradeEstimation()[data] => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * upgrade action
     *
     * @return \Illuminate\Http\Response
     */
    public function doUpgrade(Request $request)
    {
        $validator_rules = [
            'location_limit' => 'required',
            'location_limit_old' => 'required',
            'employee_limit' => 'required',
            'employee_limit_old' => 'required',
            'employee_max_limit' => 'required',
            'transaction_fee' => 'required',
            'plan_type' => 'required',
            'manual_discount' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            DB::beginTransaction();
            $user_data = $this->getMainAccountDetails();
            Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
            $subscription_response = Subscription::retrieve($user_data->chargebee_subscription_id);
            $subscription = $subscription_response->subscription();
            $version = 'v2';
            foreach ($subscription->itemTiers as $item_tiers) {
                if(str_contains($item_tiers->itemPriceId, 'Employees') && !empty($item_tiers->endingUnit) && $item_tiers->endingUnit == 5){
                    $version = 'v1';
                    break;
                }
            }
            $chargebee_plan_ids = $this->getChargebeePlanId($request->plan_type, $user_data->chargebe_addon_type, 'normal', $version);
            // previous invoice
            $previous_invoice_estimate_response = Estimate::renewalEstimate(
                $user_data->chargebee_subscription_id,
                array(
                    'ignoreScheduledCancellation' => true,
                    'ignoreScheduledChanges' => true,
                )
            );
            $previous_invoice_estimate = $previous_invoice_estimate_response->estimate();
            $prev_payment_price = $previous_invoice_estimate->invoiceEstimate->total / 100;
            $prev_charge_price = $prev_payment_price;
            $prev_transaction_fee = 0;
            foreach ($previous_invoice_estimate->invoiceEstimate->lineItems as $key => $value) {
                if ($value->entityId == $chargebee_plan_ids['transaction_fee_item_id']) {
                    $prev_transaction_fee = $value->amount / 100;
                }
            }
            $prev_payment_price = round($prev_payment_price - $prev_transaction_fee, 2);
            $prev_sales_tax = [];
            $prev_sales_tax_percentage = 0;
            if (isset($previous_invoice_estimate->invoiceEstimate->taxes) && !empty($previous_invoice_estimate->invoiceEstimate->taxes)) {
                foreach ($previous_invoice_estimate->invoiceEstimate->taxes as $key => $value) {
                    $prev_sales_tax[] = array(
                        'amount' => $value->amount / 100
                    );
                }
                foreach ($previous_invoice_estimate->invoiceEstimate->lineItems as $key => $value) {
                    $prev_sales_tax_percentage  = (isset($value->taxRate)) ? $value->taxRate : 0;
                }
            }
            if (!empty($prev_sales_tax)) {
                $prev_payment_price = round($prev_payment_price - array_sum(array_column($prev_sales_tax, 'amount')), 2);
            }
            $prev_discount_price = 0;
            $final_promocode = '';
            if (isset($previous_invoice_estimate->invoiceEstimate->discounts[0]) && !empty($previous_invoice_estimate->invoiceEstimate->discounts[0])) {
                $prev_discount_price = $previous_invoice_estimate->invoiceEstimate->discounts[0]->amount / 100;
                $final_promocode = $previous_invoice_estimate->invoiceEstimate->discounts[0]->entityId;
            }
            if ($prev_discount_price > 0) {
                $prev_payment_price = round($prev_payment_price + $prev_discount_price, 2);
            }
            $location_pricing = LocationLimitPrice::where('limit', $request->location_limit)->first();
            $employee_pricing = EmployeeLimitPrice::where('limit', $request->employee_limit)->first();
            $subscription_array = array(
                "invoiceImmediately" => true,
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => 1
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['location_item_id'],
                        "quantity" => $request->location_limit
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['employee_item_id'],
                        "quantity" => $request->employee_max_limit
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['transaction_fee_item_id'],
                        "unitPriceInDecimal" => $request->transaction_fee
                    ),
                )
            );
            if ($request->manual_discount > 0) {
                $subscription_array['discounts'] = array(
                    array(
                        "apply_on" => 'invoice_amount',
                        "durationType" => 'one_time',
                        "amount" => ($request->manual_discount * 100),
                        "operationType" => 'add'
                    )
                );
            }
            $chargebee_subscription_response = Subscription::updateForItems($user_data->chargebee_subscription_id, $subscription_array);
            $chargebee_subscription_updated = $chargebee_subscription_response->subscription();
            $chargebee_invoice_created = $chargebee_subscription_response->invoice();

            // next invoice
            $next_invoice_estimate_response = Estimate::renewalEstimate(
                $user_data->chargebee_subscription_id,
                array(
                    'ignoreScheduledCancellation' => true,
                    'ignoreScheduledChanges' => true,
                )
            );
            $next_invoice_estimate = $next_invoice_estimate_response->estimate();
            $next_payment_price = $next_invoice_estimate->invoiceEstimate->total / 100;
            $next_charge_price = $next_payment_price;
            $next_payment_price = round($next_payment_price - $request->transaction_fee, 2);
            $next_sales_tax = [];
            if (isset($next_invoice_estimate->invoiceEstimate->taxes) && !empty($next_invoice_estimate->invoiceEstimate->taxes)) {
                foreach ($next_invoice_estimate->invoiceEstimate->taxes as $key => $value) {
                    $next_sales_tax[] = array(
                        'amount' => $value->amount / 100
                    );
                }
            }
            if (!empty($next_sales_tax)) {
                $next_payment_price = round($next_payment_price - array_sum(array_column($next_sales_tax, 'amount')), 2);
            }
            $next_discount_price = 0;
            $final_promocode = '';
            if (isset($next_invoice_estimate->invoiceEstimate->discounts[0]) && !empty($next_invoice_estimate->invoiceEstimate->discounts[0])) {
                $next_discount_price = $next_invoice_estimate->invoiceEstimate->discounts[0]->amount / 100;
                $final_promocode = $next_invoice_estimate->invoiceEstimate->discounts[0]->entityId;
            }
            if ($next_discount_price > 0) {
                $next_payment_price = round($next_payment_price + $next_discount_price, 2);
            }
            // flag for change location or employee limit
            $is_location_limit_change = false;
            if ($request->location_limit != $request->location_limit_old) {
                $is_location_limit_change = true;
            }
            $is_employee_limit_change = false;
            if ($request->employee_limit != $request->employee_limit_old) {
                $is_employee_limit_change = true;
            }
            

            $emailTemplate = EmailTemplate::where('code', 'HCE-UE23')->first();
            $email_dynamic_paragrah = '';
            if ($is_location_limit_change == true) {
                $email_dynamic_paragrah .= '<p style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 14px;line-height: 1.6;margin-bottom: 10px;font-weight: normal;">New locations have been added to ' . $user_data->company_name . '\'s account! Please log in and name each location. Then assign any additional HIPAA Compliance Officers or users to help you manage the compliance program for these locations.</p>';
            }
            if ($is_employee_limit_change == true) {
                $email_dynamic_paragrah .= '<p style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 14px;line-height: 1.6;margin-bottom: 10px;font-weight: normal;">The employee range for ' . $user_data->company_name . ' has been increased to ' . $request->employee_limit . '. Please add the information for these new employees in the <i>Employee</i> section.</p>';
            }
            $email_vars = [
                '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_data->first_name,
                '{%DYNAMIC_PARAGRAPH%}' => $email_dynamic_paragrah,
                '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
            ];
            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
            $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
            $this->sendEmail($emailTemplate->code, $html, $user_data->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
            if ($chargebee_invoice_created) {
                $charge_price = (($chargebee_invoice_created->status == 'payment_due') ? $chargebee_invoice_created->amountDue : $chargebee_invoice_created->amountPaid) / 100;

                $emailTemplate = EmailTemplate::where('code', 'HCE-AE5')->first();
                $email_vars = [
                    '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_data->first_name,
                    '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user_data->last_name,
                    '{%COMPANY_NAME%}' => $user_data->company_name,
                    '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_data->email,
                    '{%PROMO_CODE%}' =>  $final_promocode,
                    '{%PREVIOUS_NUMBER_OF_LOCATIONS%}' => $request->location_limit_old,
                    '{%PREVIOUS_EMPLOYEE_RANGE%}' => $request->employee_limit_old,
                    '{%PREVIOUS_PRICE%}' => $this->formatPrice($prev_payment_price),
                    '{%PREVIOUS_PROMO_DISCOUNT%}' => $this->formatPrice($prev_discount_price),
                    '{%PREVIOUS_DISCOUNT_PRICE%}' => $this->formatPrice(round($prev_payment_price - $prev_discount_price, 2)),
                    '{%PREVIOUS_TRANSACTION_FEE_AMOUNT%}' => $this->formatPrice($prev_transaction_fee),
                    '{%PREVIOUS_SALES_TAX%}' => $this->formatPrice(array_sum(array_column($prev_sales_tax, 'amount'))),
                    '{%PREVIOUS_CHARGE_PRICE%}' => $this->formatPrice($prev_charge_price),
                    '{%NEW_NUMBER_OF_LOCATIONS%}' => $request->location_limit,
                    '{%NEW_EMPLOYEE_RANGE%}' => $request->employee_limit,
                    '{%NEW_PRICE%}' => $this->formatPrice($next_payment_price),
                    '{%NEW_PROMO_DISCOUNT%}' => $this->formatPrice($next_discount_price),
                    '{%NEW_DISCOUNT_PRICE%}' => $this->formatPrice(round($next_payment_price - $next_discount_price, 2)),
                    '{%NEW_TRANSACTION_FEE_AMOUNT%}' => $this->formatPrice($request->transaction_fee),
                    '{%NEW_SALES_TAX%}' => $this->formatPrice(array_sum(array_column($next_sales_tax, 'amount'))),
                    '{%NEW_CHARGE_PRICE%}' => $this->formatPrice($next_charge_price),
                    '{%PAYMENT_TERM%}' => ($request->plan_type == 'biannually') ? 'Bi-Annually' : ucfirst($request->plan_type),
                    '{%PRORATED_CHARGE_PRICE%}' => $this->formatPrice($charge_price),
                    '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                ];
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                if ($user_data->partner_reseller_id != null) {
                    $admin_subject = str_ireplace('{%RESELLER%}', $user_data->reseller->name, $emailTemplate->reseller_subject);
                } else {
                    $admin_subject = $emailTemplate->subject;
                }
                $delayTime = Carbon::now()->addHours(24)->format('Y-m-d H:i:s');
                $this->sendEmail($emailTemplate->code, $html, [Config::get('app.finance_group_email'), Config::get('app.cs_group_email'), Config::get('app.salesadmin_group_email')], Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null), null, null, $delayTime);

                //send mail to partner start
                if ($user_data->partner_reseller_id != '' && $user_data->reseller->email != '') {
                    $attachment_invoice = null;
                    $chargebee_invoice_download = Invoice::pdf($chargebee_invoice_created->id, ['dispositionType' => 'attachment']);
                    $chargebee_invoice_pdf = $chargebee_invoice_download->download();
                    $attachment_invoice = storage_path('app/public') . '/generatedpolicydocuments/' . 'Abyde_Receipt_' . strtotime($user_data->created_at) . '.pdf';
                    file_put_contents($attachment_invoice, file_get_contents($chargebee_invoice_pdf->downloadUrl));
                    $this->sendEmail($emailTemplate->code, $html, $user_data->reseller->email, Config::get('app.from_admin_email'), $admin_subject, $attachment_invoice, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null), null, null, $delayTime);
                }
                //send mail to partner end
            }
            DB::commit();
            if ($is_employee_limit_change == true || $is_location_limit_change == true) {
                $sales_force_locations = Location::where('user_id', $user_data->id)->whereNotNull('salesforce_unique_id')->get();
                foreach($sales_force_locations as $location){
                    SendLocationDataToSalesForce::dispatch($location->id);
                }
            }

            return $this->success(Config::get('constants.USER.UPGRADE_SUCCESS'), 200);
        } catch (Stripe\Exception\CardException $e) {
            DB::rollback();
            Log::error('UpgradeController/doUpgrade() => ' . $e->getError()->message);
            Log::error('UpgradeController/doUpgrade()[data] => ' . json_encode($request->all()));
            return $this->error($e->getError()->message, 200);
        } catch (PaymentException $e) {
            DB::rollback();
            Log::error('UpgradeController/doUpgrade() => ' . $e->getMessage());
            Log::error('UpgradeController/doUpgrade()[data] => ' . json_encode($request->all()));
            preg_match('/Error message:\s*\(.*?\)\s*(.*)/', $e->getMessage(), $matches);
            $error = isset($matches[1]) ? trim($matches[1]) : $e->getMessage();
            return $this->error($error, 200);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('UpgradeController/doUpgrade() => ' . $e->getMessage());
            Log::error('UpgradeController/doUpgrade()[data] => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.USER.UPGRADE_FAILED'), 200);
        }
    }

    /**
     * upgrade calculator
     *
     * @return \Illuminate\Http\Response
     */
    public function upgradeCalculator($location_limit, $employee_limit, $plan_type, $next_billing_at)
    {
        $user_data = auth()->user();
        $user_information = User::where('id', $user_data['id'])->with('state', 'reseller')->first();
        if ($user_information) {
            try {
                // find out final price base on current plan and old plan without promocode
                // price base on new plan selected
                $subscription = $this->getSubscriptionDetails($user_information->chargebee_subscription_id);
                $current_employee_limit = $subscription['employee_limit'];
                $current_location_limit = $subscription['location_limit'];
                $location_pricing_new = LocationLimitPrice::where('limit', $location_limit)->first();
                $employee_pricing_new = EmployeeLimitPrice::withTrashed()->where('max_limit', $employee_limit)->first();
                $calculatedPricingNew = $this->calculateTotalPrice($employee_pricing_new, $location_pricing_new);
                $final_payment_price_new = ($plan_type == 'monthly' ? $calculatedPricingNew['monthly_price'] : ($plan_type == 'quarterly' ? $calculatedPricingNew['quarterly_price'] : ($plan_type == 'biannually' ? $calculatedPricingNew['biannually_price'] : $calculatedPricingNew['yearly_price'])));
                // price base on old plan selected
                $location_pricing_current = LocationLimitPrice::where('limit', $current_location_limit)->first();
                $employee_pricing_current = EmployeeLimitPrice::withTrashed()->where('max_limit', $current_employee_limit)->first();
                $calculatedPricingOld = $this->calculateTotalPrice($employee_pricing_current, $location_pricing_current);
                $final_payment_price_old = ($plan_type == 'monthly' ? $calculatedPricingOld['monthly_price'] : ($plan_type == 'quarterly' ? $calculatedPricingOld['quarterly_price'] : ($plan_type == 'biannually' ? $calculatedPricingOld['biannually_price'] : $calculatedPricingOld['yearly_price'])));
                // find out remaining days
                $user_current_plan_end_date = Carbon::parse($next_billing_at . " 00:00:00");
                $today_date = Carbon::today();
                $user_current_plan_remaining_days = ($user_current_plan_end_date->diffInDays($today_date));
                // check promocode apply
                $discount_percentage = 0;
                $final_discount = 0;
                $promo_code = '';
                $final_discount_price_new = 0;
                $final_discount_price_for_next_payment = 0;
                $final_discount_price_old = 0;
                if (! empty($subscription['coupon'])) {
                    $promocode_data = $this->checkPromoCode($subscription['coupon'], false);
                    if (! empty($promocode_data)) {
                        $discount_percentage = $promocode_data->discount_percentage;
                        $final_discount_price_for_next_payment = round(($final_payment_price_new * $discount_percentage) / 100, 2);
                        $promo_code = $promocode_data->promo_code;
                    }
                }
                if ($plan_type == 'monthly') {
                    // per day price as per new plan select
                    $per_day_price_new = round($final_payment_price_new * 12 / 365, 2);
                    // per day price as per old plan
                    $per_day_price_old = round($final_payment_price_old * 12 / 365, 2);
                    // per day discount as per new plan
                    if ($discount_percentage > 0) {
                        $final_discount_price_new = round(($final_payment_price_new * $discount_percentage) / 100, 2);
                        $final_discount_price_new_per_day = round(($final_discount_price_new * 12) / 365, 2);
                    }
                    // per day discount as per old plan
                    if ($discount_percentage > 0) {
                        $final_discount_price_old = round(($final_payment_price_old * $discount_percentage) / 100, 2);
                        $final_discount_price_old_per_day = round(($final_discount_price_old * 12) / 365, 2);
                    }
                } elseif ($plan_type == 'quarterly') {
                    // per day price as per new plan select
                    $per_day_price_new = round($final_payment_price_new * 4 / 365, 2);
                    // per day price as per old plan
                    $per_day_price_old = round($final_payment_price_old * 4 / 365, 2);
                    // per day discount as per new plan
                    if ($discount_percentage > 0) {
                        $final_discount_price_new = round(($final_payment_price_new * $discount_percentage) / 100, 2);
                        $final_discount_price_new_per_day = round(($final_discount_price_new * 4) / 365, 2);
                    }
                    // per day discount as per old plan
                    if ($discount_percentage > 0) {
                        $final_discount_price_old = round(($final_payment_price_old * $discount_percentage) / 100, 2);
                        $final_discount_price_old_per_day = round(($final_discount_price_old * 4) / 365, 2);
                    }
                } elseif ($plan_type == 'biannually') {
                    // per day price as per new plan select
                    $per_day_price_new = round($final_payment_price_new * 2 / 365, 2);
                    // per day price as per old plan
                    $per_day_price_old = round($final_payment_price_old * 2 / 365, 2);
                    // per day discount as per new plan
                    if ($discount_percentage > 0) {
                        $final_discount_price_new = round(($final_payment_price_new * $discount_percentage) / 100, 2);
                        $final_discount_price_new_per_day = round(($final_discount_price_new * 2) / 365, 2);
                    }
                    // per day discount as per old plan
                    if ($discount_percentage > 0) {
                        $final_discount_price_old = round(($final_payment_price_old * $discount_percentage) / 100, 2);
                        $final_discount_price_old_per_day = round(($final_discount_price_old * 2) / 365, 2);
                    }
                } else {
                    // per day price as per new plan select
                    $per_day_price_new = round($final_payment_price_new / 365, 2);
                    // per day price as per old plan
                    $per_day_price_old = round($final_payment_price_old / 365, 2);
                    // per day discount as per new plan
                    if ($discount_percentage > 0) {
                        $final_discount_price_new = round(($final_payment_price_new * $discount_percentage) / 100, 2);
                        $final_discount_price_new_per_day = round($final_discount_price_new / 365, 2);
                    }
                    // per day discount as per old plan
                    if ($discount_percentage > 0) {
                        $final_discount_price_old = round(($final_payment_price_old * $discount_percentage) / 100, 2);
                        $final_discount_price_old_per_day = round($final_discount_price_old / 365, 2);
                    }
                }
                // total final price as per remaining days new plan
                $total_price_as_per_new_plan = round($user_current_plan_remaining_days * $per_day_price_new, 2);
                // total final price as per remaining days old plan
                $total_price_as_per_old_plan = round($user_current_plan_remaining_days * $per_day_price_old, 2);
                // final payment price
                $final_payment_price = round($total_price_as_per_new_plan - $total_price_as_per_old_plan, 2);
                // final discount
                $final_discount_new = 0;
                $final_discount_old = 0;
                if ($discount_percentage > 0) {
                    $final_discount_new = round($user_current_plan_remaining_days * $final_discount_price_new_per_day, 2);
                }
                if ($discount_percentage > 0) {
                    $final_discount_old = round($user_current_plan_remaining_days * $final_discount_price_old_per_day, 2);
                }
                $final_discount = round($final_discount_new - ($final_discount_old), 2);
                $charge_price_before_sales_tax_amount = round(($final_payment_price - ($final_discount)), 2);
                $data = [
                    'before_tax_local_calculate_price' => $charge_price_before_sales_tax_amount
                ];
                return $data;
            } catch (\Exception $e) {
                Log::error('UpgradeController/upgradeCalculator() => ' . $e->getMessage());
                return '';
            }
        } else {
            return '';
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
