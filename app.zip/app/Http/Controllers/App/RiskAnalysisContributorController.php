<?php

namespace App\Http\Controllers\App;
use App\Http\Controllers\Controller;
use App\Imports\RiskAnalysisContributorImport;
use App\Models\RiskAnalysisContributor;
use App\Models\RiskAnalysisContributorLocation;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\RiskAnalysisContributorQuestion;
use App\Models\User;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use App\Traits\FileUpload;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\HeadingRowImport;

class RiskAnalysisContributorController extends Controller
{
    use ApiResponser, CheckAccessRight, FileUpload, GeneratePolicy, GetMainUserData, SendMail;
   
    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Add Risk Analysis Contributor
     *
     * @return \Illuminate\Http\Response
     */
    public function addRiskAnalysisContributor(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'first_name' => 'required',
                'last_name' => 'required',
                'company_name' => 'required',
                'email' => 'required|email',
                'location_list' => 'required|array',
            ];
           
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }           
            DB::beginTransaction();
            $input_fields = $request->all();
            $input_fields['user_id'] = $user_data['id'];
            $input_fields['first_name'] = $input_fields['first_name'];
            $input_fields['last_name'] = $input_fields['last_name'];
            $input_fields['company_name'] = $input_fields['company_name'];
            $input_fields['email'] = $input_fields['email'];            
            
            $sra_contributor = RiskAnalysisContributor::create($input_fields);
            $sra_contributor['sra_contributor_location_list'] = $sra_contributor->riskAnalysisContributorLocation()->createMany($input_fields['location_list']);     
            
            $sra_contributor = $sra_contributor->load(['riskAnalysisContributorLocation', 'riskAnalysisContributorLocation.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }]);
           
            //send mail
            $location_str="";
            if(!empty($sra_contributor['riskAnalysisContributorLocation']))                
            {               
                $location_arr = array_map(function($person) {
                    return $person['location']['location_nickname'];
                }, $sra_contributor['riskAnalysisContributorLocation']->toArray());

                $location_str = implode(", ", $location_arr);
            }
            $emailTemplate = EmailTemplate::where('code', 'HCE-UE64')->first();
            $email_vars = [
                '{%CONTRIBUTOR_FIRST_NAME%}' => $sra_contributor->first_name,
                '{%COMPANY_NAME%}' => $user_data->company_name,                
                '{%PCO_OFFICER%}' => $user_data->first_name . ' '. $user_data->last_name,
                '{%PCO_OFFICER_EMAIL%}' => $user_data->email,
                '{%HIPAABA_LINK%}' => Config::get('app.hipaa_business_associates_url'),
                '{%PARTNER_LINK%}' => Config::get('app.partner_url')
            ];
            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
            $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
            $this->sendEmail($emailTemplate->code, $html, $sra_contributor->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
            //end send mail
            DB::commit();

            return $this->success(Config::get('constants.SRA_CONTRIBUTOR.SRA_CONTRIBUTOR_ADDED'), 200, $sra_contributor);
        } catch (\Exception $e) {
            Log::error('RiskAnalysisContributorController/addRiskAnalysisContributor() => '.$e->getMessage());
            Log::error('Line() => '.$e->getLine());
            Log::error('Data() => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Check unique email address in Risk Analysis Contributor
     *
     * @return \Illuminate\Http\Response
     */
    public function checkUniqueEmail(Request $request, $email = '', $risk_analysis_contributor_id = '')
    {
        try {
            if ($email == '') {
                dd('Invalid parmas');
            }
            $user_data = $this->getMainAccountDetails();
            $sra_contributor = RiskAnalysisContributor::where('email', $request['email'])
                ->where('user_id', $user_data['id']);
            if ($risk_analysis_contributor_id != '') {
                $sra_contributor = $sra_contributor->where('id', '!=', $risk_analysis_contributor_id);
            }
            $sra_contributor = $sra_contributor->count();
            if ($sra_contributor > 0) {
                return 'available';
            } else {
                return 'not_available';
            }
        } catch (\Exception $e) {
            Log::error('RiskAnalysisContributorController/checkUniqueEmail() => '.$e->getMessage());
            Log::error('RiskAnalysisContributorController/checkUniqueEmail()[data] => '.json_encode([$email, $risk_analysis_contributor_id]));
            Log::error('RiskAnalysisContributorController/checkUniqueEmail()[request] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get Risk Analysis Contributor list
     *
     * @return \Illuminate\Http\Response
     */
    public function allRiskAnalysisContributorList(Request $request)
    {      
        try {
            $validator_rules = [
                'sort_by' => 'sometimes|nullable|in:first_name,last_name,email,company_name',
                'sort_by_dir' => 'sometimes|nullable|in:ASC,DESC',
                'filter_by_location' => 'sometimes|nullable|array',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $limit = $request->has('per_page') ? request('per_page') : Config::get('constants.PER_PAGE');
            $user_data = $this->getMainAccountDetails();
            $generalController = new GeneralController;
            $location_access_list = $generalController->getAssingedLocationList();
            $sra_contributors = RiskAnalysisContributor::where('user_id', $user_data['id'])
                ->with(['riskAnalysisContributorLocation', 'riskAnalysisContributorLocation.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }]);
            $sra_contributors = $sra_contributors->where(function ($subquery) use ($location_access_list) {
                $subquery->whereHas('riskAnalysisContributorLocation', function ($que) use ($location_access_list) {
                    $que->whereIn('location_id', $location_access_list);
                });
            });
            $input_fields = $request->all();
            if (isset($input_fields['search_query']) && $input_fields['search_query'] != '') {
                $sra_contributors = $sra_contributors->where(function ($que) use ($input_fields) {
                    return $que->whereRaw('concat(first_name, " ", last_name) like "%'.$input_fields['search_query'].'%" ')
                       ->orWhereRaw('concat(last_name, " ", first_name) like "%'.$input_fields['search_query'].'%" ')
                       ->orWhere('email', 'LIKE', '%'.$input_fields['search_query'].'%')
                       ->orWhere('company_name', 'LIKE', '%'.$input_fields['search_query'].'%');
               });
            }
            if (isset($input_fields['filter_by_location']) && ! empty($input_fields['filter_by_location'])) {
                $sra_contributors = $sra_contributors->whereHas('riskAnalysisContributorLocation', function ($que) use ($input_fields) {
                    return $que->whereIn('location_id', $input_fields['filter_by_location']);
                });
            }
            if (isset($input_fields['sort_by']) && ! empty($input_fields['sort_by']) && isset($input_fields['sort_by_dir']) && ! empty($input_fields['sort_by_dir'])) {
                $sra_contributors = $sra_contributors->orderBy($input_fields['sort_by'], $input_fields['sort_by_dir'])->orderBy('id', $input_fields['sort_by_dir']);
            } else {
                $sra_contributors = $sra_contributors->orderBy('id', 'DESC');
            }
            $sra_contributors = $sra_contributors->paginate($limit);

             //fetch total questions whose status is 'pending','reviewed' location wise
            $sra_contributors->map(function ($item)  {
                foreach($item->riskAnalysisContributorLocation as $key=>$sra_user)
                {
                    $item->riskAnalysisContributorLocation[$key]->contrinutor_questions_count  = RiskAnalysisContributorQuestion::where(['contributor_user_acntuser_type' => \App\Models\RiskAnalysisContributor::class,'contributor_user_acntuser_id'=> $sra_user->risk_analysis_contributor_id,'location_id' => $sra_user->location_id])
                        ->whereIn('status' ,['Pending','Reviewed'])               
                        ->count(); 
                }
                return $item;
            });          
            //end
            
            $location_list_count = Location::where('user_id', $user_data['id'])
                ->select(['id', 'location_nickname'])
                ->count();
            $data = [                
                'sra_contributors_list' => $sra_contributors,
                'sample_import_file_link' => ($location_list_count == 1) ? url('/sample_docs/sra_contributor_template_std.xlsx') : url('/sample_docs/sra_contributor_template_ent.xlsx'),
            ];
            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('RiskAnalysisContributorController/allRiskAnalysisContributorList() => '.$e->getMessage());
            Log::error('RiskAnalysisContributorController/allRiskAnalysisContributorList()[data] => '.json_encode($request->all()));
            Log::error('Line->> => '.$e->getLine());
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Edit Risk Analysis Contributor
     *
     * @return \Illuminate\Http\Response
     */
    public function editRiskAnalysisContributor(Request $request)
    {
        try {
            $validator_rules = [
                'risk_analysis_contributor_id' => 'required',
                'first_name' => 'required',
                'last_name' => 'required',
                'company_name' => 'required',
                'location_work_new' => 'sometimes|array',
                'location_work_removed' => 'sometimes|array',
            ];
           
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            DB::beginTransaction();
            $input_fields = $request->all();
            $sra_contributor = RiskAnalysisContributor::with('riskAnalysisContributorLocation')->findOrFail($input_fields['risk_analysis_contributor_id']);            
           
            if ($sra_contributor->update($input_fields)) {
                if ($request->has('location_work_removed')) {
                    RiskAnalysisContributorLocation::whereIn('location_id', $input_fields['location_work_removed'])
                        ->where('risk_analysis_contributor_id', $input_fields['risk_analysis_contributor_id'])->get()->each(function ($bal) {
                            $bal->delete();
                        });

                    RiskAnalysisContributorQuestion::whereIn('location_id', $input_fields['location_work_removed'])
                        ->where('contributor_user_acntuser_type', RiskAnalysisContributor::class)
                        ->where('contributor_user_acntuser_id', $input_fields['risk_analysis_contributor_id'])->get()->each(function ($bal) {
                            $bal->delete();
                        });
                }
                if ($request->has('location_work_new')) {
                    $sra_contributor->riskAnalysisContributorLocation()->createMany($input_fields['location_work_new']);
                }
            }
            $sra_contributor = RiskAnalysisContributor::where('id', $input_fields['risk_analysis_contributor_id'])
                ->with(['riskAnalysisContributorLocation', 'riskAnalysisContributorLocation.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }])->first();
            
             //fetch total questions whose status is 'pending','review' location wise
            if(!empty($sra_contributor->riskAnalysisContributorLocation))
            {
                foreach($sra_contributor->riskAnalysisContributorLocation as $key=>$sra_user)
                {
                    $sra_contributor->riskAnalysisContributorLocation[$key]->contrinutor_questions_count  = RiskAnalysisContributorQuestion::where(['contributor_user_acntuser_type' => \App\Models\RiskAnalysisContributor::class,'contributor_user_acntuser_id'=> $sra_user->risk_analysis_contributor_id,'location_id' => $sra_user->location_id])
                        ->whereIn('status' ,['Pending','Reviewed'])               
                        ->count();   
                }
            }
            //end    
            DB::commit();

            return $this->success(Config::get('constants.SRA_CONTRIBUTOR.SRA_CONTRIBUTOR_EDITED'), 200, $sra_contributor);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('RiskAnalysisContributorController/editRiskAnalysisContributor() => '.$e->getMessage());
            Log::error('RiskAnalysisContributorController/editRiskAnalysisContributor()[data] => '.json_encode($request->all()));
            Log::error('Line => '.$e->getLine());
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * delete Risk Analysis Contributor
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteRiskAnalysisContributor(Request $request)
    {        
        try {
            $validator_rules = [
                'risk_analysis_contributor_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $risk_analysis_contributor_id = $request['risk_analysis_contributor_id'];
            $question_count = RiskAnalysisContributorQuestion::where(['contributor_user_acntuser_type'=> RiskAnalysisContributor::class,'contributor_user_acntuser_id'=> $risk_analysis_contributor_id])
                ->whereIn('status' ,['Pending','Reviewed'])               
                ->count();   
                
            if ($question_count > 0) {
                return $this->error(Config::get('constants.SRA_CONTRIBUTOR.CANNOT_DELETE_SRA_CONTRIBUTOR'), 200);
            }   
     
            $sra_contributor = RiskAnalysisContributor::with(['riskAnalysisContributorLocation','riskAnalysisContributorQuestion'])->findOrFail($risk_analysis_contributor_id);                  
            $sra_contributor->delete();
            return $this->success(Config::get('constants.SRA_CONTRIBUTOR.SRA_CONTRIBUTOR_DELETED'), 200);
        } catch (\Exception $e) {
            Log::error('RiskAnalysisContributorController/deleteRiskAnalysisContributor() => '.$e->getMessage());
            Log::error('RiskAnalysisContributorController/deleteRiskAnalysisContributor() => '.$e->getLine());
            Log::error('RiskAnalysisContributorController/deleteRiskAnalysisContributor()[data] => '.json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Import Risk Analysis Contributor from file
     *
     * @return \Illuminate\Http\Response
     */
    public function importRiskAnalysisContributor(Request $request)
    {
        $user_data = $this->getMainAccountDetails();
        $generalController = new GeneralController;
        $location_access_list = $generalController->getAssingedLocationList();
        $location_list_count = Location::where('user_id', $user_data['id'])
            ->select(['id', 'location_nickname'])
            ->count();
        $validator_rules = [
            'import_file' => 'required|mimes:xls,xlsx',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules, []);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.SRA_CONTRIBUTOR.INVALID_IMPORT_FILE'), 200, $validator_check->errors()->all());
        }
        // check exce sheet format
        $headings = (new HeadingRowImport)->toArray($request['import_file']);
        if ($location_list_count == 1) {
            $heading_array = ['first_name', 'last_name', 'company_name', 'email'];
        } else {
            $heading_array = ['first_name', 'last_name', 'company_name', 'email', 'location_access'];
        }
        $headings[0][0] = array_filter($headings[0][0], function ($v) {
            return trim($v) == true;
        });
        $missing_heading = array_diff($heading_array, $headings[0][0]);
        if ($missing_heading) {
            return $this->error(Config::get('constants.SRA_CONTRIBUTOR.IMPORT_FILE_INVALID_TEMPLETE'), 200);
        }
        try {
            if ($request->has('import_file')) {
                // import Risk Analysis Contributor
                $import = new RiskAnalysisContributorImport;
                $import->import($request['import_file']);
                if ($import->failures()->isNotEmpty()) {
                    $error = [];
                    $i = 0;
                    foreach ($import->failures() as $failure) {
                        foreach ($failure->errors() as $value) {
                            $error[$i] = $value.'Row No :'.$failure->row();
                            $i++;
                        }
                    }

                    Log::error('RiskAnalysisContributorController/importRiskAnalysisContributor(ImportValidation) => '.json_encode($error));

                    if ($import->row_count == 0) {
                        return $this->error(Config::get('constants.SRA_CONTRIBUTOR.IMPORT_ERROR'), 200, $error);
                    } else {
                        return $this->success(Config::get('constants.SRA_CONTRIBUTOR.PARTIALLY_IMPORT_ERROR'), 200, $error);
                    }
                }
                if ($import->row_count == 0) {
                    return $this->error(Config::get('constants.SRA_CONTRIBUTOR.IMPORT_ERROR'), 200, $import->invalid_locations);
                }
                if ($import->row_count == $import->total_row_count) {
                    return $this->success(Config::get('constants.SRA_CONTRIBUTOR.IMPORTED'), 200);
                } else {
                    return $this->success(Config::get('constants.SRA_CONTRIBUTOR.PARTIALLY_IMPORT_ERROR'), 200, $import->invalid_locations);
                }
            }
        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            Log::error('RiskAnalysisContributorController/importRiskAnalysisContributor() => '.$e->getMessage());

            return $this->error(Config::get('constants.SRA_CONTRIBUTOR.IMPORT_ERROR'), 200);
        } catch (\Exception $e) {
            Log::error('RiskAnalysisContributorController/importRiskAnalysisContributor() => '.$e->getMessage());
            Log::error('Line => '.$e->getLine());
            if ($e->getMessage() == 'more_than_limit_records') {
                return $this->error(Config::get('constants.IMPORT_LIMIT'), 200);
            } else {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        }
    }
    /************************** */
    /*API methods - end
    /*************************** */
}