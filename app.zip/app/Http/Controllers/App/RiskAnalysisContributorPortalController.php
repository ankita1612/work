<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\BusinessAssociates;
use App\Models\BusinessAssociatesAgreement;
use App\Models\Countries;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Models\RiskAnalysisContributorAttemptedQuestionAnswer;
use App\Models\RiskAnalysisContributorQuestion;
use App\Traits\ApiResponser;
use App\Traits\FileUpload;
use App\Traits\GeneratePolicy;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class RiskAnalysisContributorPortalController extends Controller
{
    use ApiResponser, FileUpload, SendMail;

    /**
     * Contributor's portal page
     *
     * @return \Illuminate\Http\Response
     */
    public function showPortal($location_id = '', $contributor_user_acntuser_id = '',$contributor_user_acntuser_type = '')
    {
        if ($location_id == '' || $contributor_user_acntuser_id == '' || $contributor_user_acntuser_type == '') {
            return redirect()->route('login');
        } else {
            $location_id = base64_decode($location_id,true);
            $contributor_user_acntuser_id = base64_decode($contributor_user_acntuser_id,true);
            $contributor_user_acntuser_type = base64_decode($contributor_user_acntuser_type,true);
            if(empty($location_id) || !is_numeric($location_id) || empty($contributor_user_acntuser_id) || !is_numeric($contributor_user_acntuser_id) || empty($contributor_user_acntuser_type)) {
                return redirect()->route('login');
            }
            
            $check_contributor = RiskAnalysisContributorQuestion::where([
                'location_id' => $location_id,
                'contributor_user_acntuser_id' => $contributor_user_acntuser_id,
                'contributor_user_acntuser_type' => $contributor_user_acntuser_type,
            ]);
            $contributor_data = $check_contributor->first();
            $questions_count = $check_contributor->where('status', 'Pending')->count();
            $location_data = Location::with('user.reseller','state')->where('id',$location_id)->first();
            return view('app.pages.sra_contributorportal',compact('location_data','contributor_user_acntuser_id','contributor_user_acntuser_type','questions_count', 'contributor_data'));
           
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * SRA contributor complete record
     *
     * @return \Illuminate\Http\Response
     */
    public function addSRAContributorCompleteRecord(Request $request)
    {
        try {
            $validator_rules = [
                'question_answer' => 'required|array',
                'location_id'   => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }  
            $check_exist_answer = RiskAnalysisContributorQuestion::where(['id' => $request['question_answer'][0]['risk_analysis_contributor_question_id'], 'status' => 'Reviewed'])->first();
            if($check_exist_answer) {
                return $this->error(Config::get('constants.SRA_CONTRIBUTOR.ANSWER_ALREADY_SUBMITTED'), 200, []);
            }        
            foreach($request['question_answer'] as $answer){
                RiskAnalysisContributorAttemptedQuestionAnswer::create($answer);
                $question_data = [
                    'status' => 'Reviewed',
                    'notes' => $answer['notes'] ?? null,
                ];
                $contributor_data = RiskAnalysisContributorQuestion::where('id',$answer['risk_analysis_contributor_question_id'])->first();
                if ($contributor_data) {
                    $contributor_data->status = 'Reviewed';
                    $contributor_data->notes =  $answer['notes'] ?? null;
                    $contributor_data->save();
                }
            }
            
            //Send email to HCO
            $location = Location::where('id',$request->location_id)->with('user.reseller')->with('hipaaComplianceOfficer.hco')->first();
            $user = $location->user;
            $hco = $location->hipaaComplianceOfficer;
            $emailTemplate = EmailTemplate::where('code', 'HCE-UE67')->first();
            $email_vars = [
                '{%FIRST_NAME%}' => $hco->hco->first_name,
                '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
            ];
            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
            $this->sendEmail($emailTemplate->code, $html, $hco->hco->email, Config::get('app.from_user_email'), $emailTemplate->subject,null,null,true,($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);

            return $this->success(Config::get('constants.SRA_CONTRIBUTOR.ANSWER_COMPLETED'), 200);
        } catch (\Exception $e) {
            Log::error('RiskAnalysisContributorPortalController/addSRAContributorCompleteRecord() => '.$e->getMessage());
            Log::error('RiskAnalysisContributorPortalController/addSRAContributorCompleteRecord()[data] => '.json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

     /**
     * load risk analysis question
     *
     * @return \Illuminate\Http\Response
     */
    public function loadRiskAnalysisQuestion(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'contributor_id' => 'required',
                'contributor_type' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $check_exist_answer = RiskAnalysisContributorQuestion::where([
                'location_id' => $request->location_id,
                'contributor_user_acntuser_id' => $request->contributor_id,
                'contributor_user_acntuser_type' => $request->contributor_type,
                'status' => 'Pending'
            ]);
            if($check_exist_answer->count() == 0) {
                return $this->error(Config::get('constants.SRA_CONTRIBUTOR.ANSWER_ALREADY_SUBMITTED'), 200, []);
            }

            $question_detail = $check_exist_answer
            ->with([
                'question.riskAnalysisQuestionAnswerOptions',
                'question.questionCategory',
                'question.questionLawSection',
                'attemptedQuestion' => function ($query)use ($request) {
                    $query->where('location_id', $request->location_id)->latest();
                },
            ])
            ->orderBy('question_id','asc')
            ->get();
            
            $data = [
                'question_detail' => $question_detail
            ];
            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('RiskAnalysisContributorPortalController/loadRiskAnalysisQuestion() => '.$e->getMessage());
            Log::error('RiskAnalysisContributorPortalController/loadRiskAnalysisQuestion()[data] => '.json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    /************************** */
    /*API methods - end
    /*************************** */
}
