<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Imports\StudentImport;
use App\Jobs\MoveStudentCertificateToAbydeDrive;
use App\Models\AbydeDriveArchiveFile;
use App\Models\AbydeDriveArchiveFolder;
use App\Models\AbydeDriveArchiveFolderLocation;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\Student;
use App\Models\StudentClass;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\FileUpload;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\HeadingRowImport;

class StudentController extends Controller
{
    use ApiResponser, CheckAccessRight, FileUpload, GeneratePolicy, GetMainUserData;

    /**
     * Student page
     *
     * @return \Illuminate\Http\Response
     */
    public function showStudent()
    {
        if ($this->checkAccessRight('student')) {
            $general_controller = new GeneralController;
            $accessible_location_list = $general_controller->getStudentAccessLocationList();
            $is_atleast_one_loc_hco = HipaaComplianceOfficer::whereIn('location_id', $accessible_location_list)->count();
            if ($is_atleast_one_loc_hco > 0) {
                return view('app.pages.student');
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Add student
     *
     * @return \Illuminate\Http\Response
     */
    public function addStudent(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required|email|unique:App\Models\Student,email,NULL,id,deleted_at,NULL',
                'phone_number' => 'required',
                'class_id' => 'required',
                'primary_work_location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $this->addPolicyVersionData('AAP', $input_fields['primary_work_location_id']);
            $input_fields['user_id'] = $user_data['id'];
            $student_created = Student::create($input_fields);
            $training_controller = new TrainingController;
            //Add in unassigned Training
            $training_controller->addToUnassignedTraining($student_created['primary_work_location_id'], $student_created['id'], \App\Models\Student::class);
            DB::commit();

            return $this->success(Config::get('constants.STUDENT.STUDENT_ADDED'), 200, $student_created);
        } catch (\Exception $e) {
            Log::error('StudentController/addStudent() => '.$e->getMessage());
            Log::error('StudentController/addStudent()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Check unique email address in student
     *
     * @return \Illuminate\Http\Response
     */
    public function checkUniqueEmail(Request $request, $email = '', $student_id = '')
    {
        try {
            if ($email == '') {
                dd('Invalid parmas');
            }
            $student = Student::where('email', $request['email']);
            if ($student_id != '') {
                $student = $student->where('id', '!=', $student_id);
            }
            $student = $student->count();
            if ($student > 0) {
                return 'available';
            } else {
                return 'not_available';
            }
        } catch (\Exception $e) {
            Log::error('StudentController/checkUniqueEmail() => '.$e->getMessage());
            Log::error('StudentController/checkUniqueEmail()[data] => '.json_encode([$email, $student_id]));
            Log::error('StudentController/checkUniqueEmail()[request] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get student list
     *
     * @return \Illuminate\Http\Response
     */
    public function allStudentList(Request $request)
    {
        try {
            $validator_rules = [
                'sort_by' => 'sometimes|nullable|in:first_name,last_name,email,phone_number',
                'sort_by_dir' => 'sometimes|nullable|in:ASC,DESC',
                'filter_by_location' => 'sometimes|nullable|array',
                'filter_by_class' => 'sometimes|nullable|array',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $limit = $request->has('per_page') ? request('per_page') : Config::get('constants.PER_PAGE');
            $user_data = $this->getMainAccountDetails();
            $student = Student::where('user_id', $user_data['id'])
                ->with(['studentPrimaryWorkLocation' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }, 'studentClass'])->whereHas('studentPrimaryWorkLocation.hipaaComplianceOfficer');
            $input_fields = $request->all();
            if (isset($input_fields['search_query']) && $input_fields['search_query'] != '') {
                $student = $student->where(function ($que) use ($input_fields) {
                    return $que->whereRaw('concat(first_name, " ", last_name) like "%'.$input_fields['search_query'].'%" ')
                        ->orWhereRaw('concat(last_name, " ", first_name) like "%'.$input_fields['search_query'].'%" ')
                        ->orWhere('email', 'LIKE', '%'.$input_fields['search_query'].'%')
                        ->orWhere('phone_number', 'LIKE', '%'.$input_fields['search_query'].'%');
                });
            }
            if (isset($input_fields['filter_by_location']) && ! empty($input_fields['filter_by_location'])) {
                $student = $student->where(function ($subquery) use ($input_fields) {
                    $subquery->whereHas('studentPrimaryWorkLocation', function ($que) use ($input_fields) {
                        $que->whereIn('id', $input_fields['filter_by_location']);
                    });
                });
            }
            if (isset($input_fields['filter_by_class']) && ! empty($input_fields['filter_by_class'])) {
                $student = $student->where(function ($subquery) use ($input_fields) {
                    $subquery->whereHas('studentClass', function ($que) use ($input_fields) {
                        $que->whereIn('id', $input_fields['filter_by_class']);
                    });
                });
            }
            if (isset($input_fields['sort_by']) && ! empty($input_fields['sort_by']) && isset($input_fields['sort_by_dir']) && ! empty($input_fields['sort_by_dir'])) {
                $student = $student->orderBy($input_fields['sort_by'], $input_fields['sort_by_dir'])->orderBy('id', $input_fields['sort_by_dir']);
            } else {
                $student = $student->orderBy('id', 'DESC');
            }
            $student = $student->paginate($limit);

            $location_list_count = Location::where('user_id', $user_data['id'])
                ->select(['id', 'location_nickname'])
                ->whereHas('hipaaComplianceOfficer')
                ->count();
            $data = [
                'student_list' => $student,
                'sample_import_file_link' => ($location_list_count == 1) ? url('/sample_docs/student_template_std.xlsx') : url('/sample_docs/student_template_ent.xlsx'),
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('StudentController/allStudentList() => '.$e->getMessage());
            Log::error('StudentController/allStudentList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * delete student
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteStudent(Request $request)
    {
        try {
            $validator_rules = [
                'student_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $student = Student::where('id', $request->student_id)->with('studentPrimaryWorkLocation')->first();
            $this->addPolicyVersionData('AAP', $student->primary_work_location_id);
            $public_path = public_path();
            $storage_path = storage_path('app/public');
            $filename = 'StudentConfidentialityAgreement.docx';
            $file_path = $public_path.'/policydocuments/'.$filename;
            $generated_agreement_directory_path = $storage_path.'/generatedpolicydocuments/';
            $gnerated_doc_name = $student->id.'_'.$filename;
            $gnerated_pdf_name = str_replace('docx', 'pdf', $gnerated_doc_name);

            $gnerated_file_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_doc_name;
            $gnerated_pdf_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_pdf_name;
            $gnerated_pdf_url = asset('storage/generatedpolicydocuments/' . $gnerated_pdf_name);
            $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($file_path);
            $template_processor->setValue('STUDENT_NAME', htmlspecialchars($student->first_name.' '.$student->last_name));
            $template_processor->setValue('CLIENT_NAME', htmlspecialchars($student->studentPrimaryWorkLocation->company_name));
            $template_processor->saveAs($gnerated_file_path);
            if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                // change libreoffice path as per installation path from your machine
                exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  '.$generated_agreement_directory_path.' '.$gnerated_file_path);
            } else {
                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir '.$generated_agreement_directory_path.' '.$gnerated_file_path);
            }

            $student_first_name = str_replace(' ', '_', trim($student->first_name));
            $student_first_name = preg_replace('/[^A-Za-z0-9\-\_]/', '', $student_first_name);
            $student_last_name = str_replace(' ', '_', trim($student->last_name));
            $student_last_name = preg_replace('/[^A-Za-z0-9\-\_]/', '', $student_last_name);

            $generate_pdf_file_name_s3 = $student->id.'_'.$student_first_name.'_'.$student_last_name.'_'.'agreement.pdf';

            $contents = \File::get($storage_path.'/generatedpolicydocuments/'. $gnerated_pdf_name);
            $new_file = '/abyde_drive_archive/students/'.$student->user_id.'/'.$generate_pdf_file_name_s3;
            Storage::disk('s3')->put($new_file, $contents, [
                'ContentType' => 'application/pdf',
            ]);

            $file_size = $this->getReadableFilesize(Storage::disk('s3')->size($new_file));
            $title = basename($generate_pdf_file_name_s3, '.pdf');

            $abyde_drive_folder = AbydeDriveArchiveFolder::where('folder_name', 'Students')->first();
            $student_name_folder = AbydeDriveArchiveFolder::updateOrCreate([
                'folder_name' => $student_first_name.'_'.$student_last_name.'_'.$student->id,
                'parent_folder_id' => $abyde_drive_folder->id,
            ]);
            $agreement_folder = AbydeDriveArchiveFolder::updateOrCreate([
                'folder_name' => 'Agreement',
                'parent_folder_id' => $student_name_folder->id,
            ]);

            $student_name_folder_location = AbydeDriveArchiveFolderLocation::create([
                'archive_folder_id' => $student_name_folder->id,
                'location_id' => $student->primary_work_location_id,
            ]);

            $agreement_folder_location = AbydeDriveArchiveFolderLocation::create([
                'archive_folder_id' => $agreement_folder->id,
                'location_id' => $student->primary_work_location_id,
            ]);

            $file_data = [
                'file_name' => $generate_pdf_file_name_s3,
                'title' => $title,
                'archive_folder_id' => $agreement_folder_location->id,
                'file_size' => $file_size,
            ];
            AbydeDriveArchiveFile::create($file_data);

            $student_move_certi = Student::with('trainingInvites.training')
                ->findOrFail($request['student_id'])->toArray();
            MoveStudentCertificateToAbydeDrive::dispatch($student_move_certi);

            $student->delete();
            DB::commit();

            return $this->success(Config::get('constants.STUDENT.STUDENT_DELETED'), 200);
        } catch (\Exception $e) {
            Log::error('StudentController/deleteStudent() => '.$e->getMessage());
            Log::error('StudentController/deleteStudent()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Edit student
     *
     * @return \Illuminate\Http\Response
     */
    public function editStudent(Request $request)
    {
        try {
            $validator_rules = [
                'student_id' => 'required',
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required|email|unique:App\Models\Student,email,'.$request->student_id.',id,deleted_at,NULL',
                'phone_number' => 'required',
                'primary_work_location_id' => 'required',
                'class_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();

            $input_fields = $request->all();
            $student = Student::findOrFail($input_fields['student_id']);
            if ($student->primary_work_location_id != $input_fields['primary_work_location_id']) {
                $this->addPolicyVersionData('AAP', $input_fields['primary_work_location_id']);
                $this->addPolicyVersionData('AAP', $student->primary_work_location_id);
            }
            if ($student->first_name !== $input_fields['first_name'] || $student->last_name !== $input_fields['last_name'] || $student->class_id !== $input_fields['class_id'] || $input_fields['imaging_device_access'] !== $student->imaging_device_access || $input_fields['full_network_access'] != $student->full_network_access || $input_fields['full_software_access'] !== $student->full_software_access) {
                $this->addPolicyVersionData('AAP', $student->primary_work_location_id);
            }
            $old_student_id = $student->primary_work_location_id;
            $student->update($input_fields);
            if ($old_student_id != $request['primary_work_location_id']) {
                $training_controller = new TrainingController;
                $training_controller->moveTrainingToArchive($old_student_id);
                //Add in unassigned Training
                $training_controller->addToUnassignedTraining($request['primary_work_location_id'], $student['id'], \App\Models\Student::class);
            }
            $student = Student::where('id', $input_fields['student_id'])
                ->with(['studentPrimaryWorkLocation' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }, 'studentClass'])->first();
            DB::commit();

            return $this->success(Config::get('constants.STUDENT.STUDENT_EDITED'), 200, $student);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('StudentController/editStudent() => '.$e->getMessage());
            Log::error('StudentController/editStudent()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get all student class list
     *
     * @return \Illuminate\Http\Response
     */
    public function getStudentClassList(Request $request)
    {
        try {
            $list = StudentClass::All();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('StudentController/getStudentClassList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get last updated student for dashboard
     */
    public function getLastUpdatedStudent($location_id)
    {
        $is_avail = LocationModuleLastUpdate::where(['location_id' => $location_id, 'module_name' => 'student'])->first();

        return ($is_avail) ? $is_avail->updated_at : '';
    }

    /**
     * Import student from file
     *
     * @return \Illuminate\Http\Response
     */
    public function importStudent(Request $request)
    {
        $user_data = $this->getMainAccountDetails();
        $location_list_count = Location::where('user_id', $user_data['id'])
            ->select(['id', 'location_nickname'])
            ->whereHas('hipaaComplianceOfficer')
            ->count();
        $validator_rules = [
            'import_file' => 'required|mimes:xlsx,xls',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules, []);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.STUDENT.INVALID_IMPORT_FILE'), 200, $validator_check->errors()->all());
        }

        $headings = (new HeadingRowImport)->toArray($request['import_file']);
        if ($location_list_count == 1) {
            $heading_array = ['first_name', 'last_name', 'email', 'phone_number', 'class_name', 'imaging_device_access', 'full_network_access', 'full_software_access'];
        } else {
            $heading_array = ['first_name', 'last_name', 'email', 'phone_number', 'class_name', 'imaging_device_access', 'full_network_access', 'full_software_access', 'primary_education_location'];
        }
        $headings[0][0] = array_filter($headings[0][0], function ($v) {
            return trim($v);
        });
        $missing_heading = array_diff($heading_array, $headings[0][0]);
        if ($missing_heading) {
            return $this->error(Config::get('constants.STUDENT.IMPORT_FILE_INVALID_TEMPLETE'), 200);
        }

        try {
            if ($request->has('import_file')) {
                $import = new StudentImport;
                $import->import($request['import_file']);
                if ($import->failures()->isNotEmpty()) {
                    $error = [];
                    $i = 0;
                    foreach ($import->failures() as $failure) {
                        foreach ($failure->errors() as $value) {
                            $error[$i] = $value.'Row No :'.$failure->row();
                            $i++;
                        }
                    }
                    Log::error('StudentController/importStudent(ImportValidation) => '.json_encode($error));
                    if ($import->row_count == 0) {
                        return $this->error(Config::get('constants.STUDENT.IMPORT_ERROR'), 200, $error);
                    } else {
                        return $this->success(Config::get('constants.STUDENT.PARTIALLY_IMPORT_ERROR'), 200, $error);
                    }
                }
                if ($import->row_count == 0) {
                    return $this->error(Config::get('constants.STUDENT.IMPORT_ERROR'), 200);
                }
                if ($import->row_count == $import->total_row_count) {
                    return $this->success(Config::get('constants.STUDENT.IMPORTED'), 200);
                } else {
                    return $this->success(Config::get('constants.STUDENT.PARTIALLY_IMPORT_ERROR'), 200);
                }
            }
        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            Log::error('StudentController/importStudent(Import) => '.$e->getMessage());

            return $this->error(Config::get('constants.STUDENT.IMPORT_ERROR'), 200);
        } catch (\Exception $e) {
            if ($e->getMessage() == 'more_than_limit_records') {
                Log::error('StudentController/importStudent(limit) => Limit reached');

                return $this->error(Config::get('constants.IMPORT_LIMIT'), 200);
            } elseif ($e->getCode() == 100) {
                $invalid_primary_education_location = explode(',', $e->getMessage());

                return $this->error(Config::get('constants.STUDENT.IMPORT_ERROR'), 200, $invalid_primary_education_location);
            } else {
                Log::error('StudentController/importStudent(error) => '.$e->getMessage());

                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        }
    }

    /**
     * download student agreement
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadAgreement(Request $request)
    {
        try {
            $validator_rules = [
                'student_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $student = Student::where('id', $request->student_id)->with('studentPrimaryWorkLocation')->first();

            $public_path = public_path();
            $storage_path = storage_path('app/public');
            $filename = 'StudentConfidentialityAgreement.docx';
            $file_path = $public_path.'/policydocuments/'.$filename;
            $generated_agreement_directory_path = $storage_path.'/generatedpolicydocuments/';
            $gnerated_doc_name = $student->id.'_'.$filename;
            $gnerated_pdf_name = str_replace('docx', 'pdf', $gnerated_doc_name);

            $gnerated_file_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_doc_name;
            $gnerated_pdf_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_pdf_name;
            $gnerated_pdf_url = asset('storage/generatedpolicydocuments/' . $gnerated_pdf_name);
            $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($file_path);
            $template_processor->setValue('STUDENT_NAME', htmlspecialchars($student->first_name.' '.$student->last_name));
            $template_processor->setValue('CLIENT_NAME', htmlspecialchars($student->studentPrimaryWorkLocation->company_name));
            $template_processor->saveAs($gnerated_file_path);
            if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                // change libreoffice path as per installation path from your machine
                exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  '.$generated_agreement_directory_path.' '.$gnerated_file_path);
            } else {
                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir '.$generated_agreement_directory_path.' '.$gnerated_file_path);
            }

            // header("Content-type:application/pdf");
            // header("Content-Disposition:attachment;filename=".str_replace("docx","pdf",$filename));
            // readfile($gnerated_pdf_path);
            return $this->success(Config::get('constants.SUCCESS'), 200, ['file_name' => $student->id.'_StudentConfidentialityAgreement.pdf', 'download_url' => $gnerated_pdf_url]);
        } catch (\Exception $e) {
            Log::error('StudentController/downloadAgreement() => '.$e->getMessage());
            Log::error('StudentController/downloadAgreement()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
