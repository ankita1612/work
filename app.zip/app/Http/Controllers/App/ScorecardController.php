<?php

namespace App\Http\Controllers\App;

use App\Events\DownloadLogEvent;
use App\Http\Controllers\Controller;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\ModuleCompletedStatus;
use App\Models\OngoingRiskAnalysisQuestion;
use App\Models\RiskAnalysisAttemptedQuestion;
use App\Models\RiskAnalysisAttemptedQuestionAnswer;
use App\Models\RiskAnalysisPreviousAttemptedQuestionAnswer;
use App\Models\RiskAnalysisQuestion;
use App\Models\RiskAnalysisQuestionAnswerOption;
use App\Models\RiskAnalysisQuestionCategory;
use App\Models\ScorecardDownloadHistory;
use App\Models\RiskAnalysisContributor;
use App\Models\RiskAnalysisContributorQuestion;
use App\Models\AccountUser;
use App\Models\User;
use App\Models\EmailTemplate;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\FileUpload;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use App\Traits\GetLoginUserData;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use App\Traits\SendMail;
use Exception;

class ScorecardController extends Controller
{
    use ApiResponser, CheckAccessRight, FileUpload, GeneratePolicy, GetMainUserData, SendMail, GetLoginUserData;

    /**
     * scorecard  page
     *
     * @return \Illuminate\Http\Response
     */
    public function showScorecard(Request $request, $location_id = '')
    {
        if ($location_id != '') {
            $location_id = base64_decode($location_id, true);
            if ($location_id) {
                if ($this->checkAccessRight('scorecard', $location_id)) {
                    $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                    $company_info_completed = ModuleCompletedStatus::where(['location_id' => $location_id, 'module' => 'company_info', 'is_completed' => 1])->first();
                    $check_is_ra_completed = ModuleCompletedStatus::where(
                        [
                            'location_id' => $location_id,
                            'module' => 'risk_analysis',
                            'is_completed' => 1,
                        ]
                    )->first();
                    if (! $check_is_ra_completed || ! $hco || ! $company_info_completed) {
                        return redirect('/dashboard');
                    }

                    return view('app.pages.scorecard', ['location_id' => $location_id]);
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get Attemplted questions list
     *
     * @return \Illuminate\Http\Response
     */
    public function attemptedQuestionList(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];

            $contributor_status = $request['contributor_status'];
            $show_questions_who_has_contributors = $request['show_questions_who_has_contributors'];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $location_id = $request['location_id'];
            $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
            $company_info_completed = ModuleCompletedStatus::where(['location_id' => $location_id, 'module' => 'company_info', 'is_completed' => 1])->first();
            $check_is_ra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $location_id,
                    'module' => 'risk_analysis',
                    'is_completed' => 1,
                ]
            )->first();
            if (! $check_is_ra_completed || ! $hco || ! $company_info_completed) {
                return $this->error('Complete SRA first', 200);
            }

            $data = RiskAnalysisQuestion::isActive()
                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location_id) {
                    $que->where(['location_id' => $location_id]);
                })
                ->with(
                    [
                        'riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                            return $que->where('location_id', $location_id)
                                ->with('attemptedQuestionAnswer.answerContent', 'attemptedQuestionAnswer.answerContent.remindOptionDetail');
                        },
                        'riskAnalysisQuestionAnswerOptions',
                        'questionCategory',
                        'questionLawSection',
                    ]
                );

            $data = $data->with(['riskAnalysisContributorQuestion' => function ($query) use ($location_id, $contributor_status) {
                if (!empty($contributor_status)) {
                    $query = $query->whereIn('status', $contributor_status);
                }
                return $query->where('location_id', $location_id)
                    ->with('contributorAttemptedQuestionAnswer.contributorAnswerContent', 'contributor_user_acntuser');
            }]);


            if (!empty($contributor_status) || !empty($show_questions_who_has_contributors)) {
                $data = $data->whereHas('riskAnalysisContributorQuestion', function ($query) use ($location_id, $contributor_status) {
                    if (!empty($contributor_status)) {
                        $query = $query->whereIn('status', $contributor_status);
                    }

                    return $query->where('location_id', $location_id);
                });
            }
            if ($request->has('category_id') && ($request['category_id'] != '' || $request['category_id'] != null)) {
                $data = $data->whereIn('question_category_id', $request['category_id']);
            }
            if ($request->has('search') && ($request['search'] != '' || $request['search'] != null)) {
                $data = $data->where('question', 'LIKE', '%' . $request['search'] . '%');
            }
            $data = $data->orderBy('display_order', 'ASC')->get();

            $question_list = [];

            foreach ($data as $key => $list) {
                try {
                    $risk_level = '';
                    if ($list['question_answer_layout'] == 'radio') {
                        $answer = $list['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent'];
                        $score = $answer['score'];
                        switch ($score) {
                            case 1:
                                $risk_level = 'Very Low';
                                break;
                            case 2:
                            case 3:
                                $risk_level = 'Low';
                                break;
                            case 4:
                            case 5:
                            case 6:
                                $risk_level = 'Medium';
                                break;
                            case 7:
                            case 8:
                                $risk_level = 'High';
                                break;
                            case 9:
                            case 10:
                                $risk_level = 'Very High';
                                break;
                        }
                        $data[$key]['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['risk_level'] = $risk_level;

                        $likelihood = $answer['likelihood'];
                        $likelihood_text = '';
                        switch ($likelihood) {
                            case 1:
                                $likelihood_text = 'Low';
                                break;
                            case 2:
                                $likelihood_text = 'Medium';
                                break;
                            case 3:
                                $likelihood_text = 'High';
                                break;
                        }
                        $data[$key]['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['likelihood_text'] = $likelihood_text;

                        $impact = $answer['impact'];
                        $impact_text = '';
                        switch ($impact) {
                            case 1:
                                $impact_text = 'Low';
                                break;
                            case 2:
                                $impact_text = 'Medium';
                                break;
                            case 3:
                                $impact_text = 'High';
                                break;
                        }
                        $data[$key]['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['impact_text'] = $impact_text;
                    }
                    if ($request->has('risk_level') && ! empty($request['risk_level'])) {
                        if (in_array($risk_level, $request['risk_level'])) {
                            $question_list[] = $data[$key];
                        }
                        if (in_array('High', $request['risk_level'])) {
                            if ($risk_level === 'Very High') {
                                $question_list[] = $data[$key];
                            }
                        }
                        if (in_array('Low', $request['risk_level'])) {
                            if ($risk_level === 'Very Low') {
                                $question_list[] = $data[$key];
                            }
                        }
                    } else {
                        $question_list[] = $data[$key];
                    }

                    if (($list->question_code == 'Q75S3' || $list->question_code == 'Q75S4' || $list->question_code == 'Q75S5')) {
                        $ra = new SecurityRiskAnalysisController;
                        $str_to_replace = $ra->getDynamicString($location_id, 'Q75');
                        $list['question'] = str_replace('{%IT_PROVIDER_QUESTION%}', $str_to_replace, $list['question']);
                    }
                } catch (\Exception $e) {
                    Log::error('ScorecardController/attemptedQuestionList()[data_error] => ' . $e->getMessage());
                    Log::error('ScorecardController/attemptedQuestionList()[data_data] => ' . json_encode($list));
                }
            }

            $scorecard_location_id = $request->location_id . '_scorecard_module_access';
            if (! session($scorecard_location_id, false)) {
                session([$scorecard_location_id => true]);
                $first_time_scorecard_added = true;
            } else {
                $first_time_scorecard_added = false;
            }

            $get_send_question_count = RiskAnalysisContributorQuestion::where(['status' => 'Assigned', 'location_id' => $location_id])->groupBy('question_id')->get()->count();

            $response_data = [
                'risk_levels' => [
                    'Low',
                    'Medium',
                    'High',
                ],
                'attempted_questions' => $question_list,
                'first_time_scorecard_added' => $first_time_scorecard_added,
                'location_company_name' => Location::where('id', $location_id)->pluck("company_name")->first(),
                'total_contributors' => RiskAnalysisContributorQuestion::where('location_id', $location_id)->count(),
                'send_question_count' => $get_send_question_count,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $response_data);
        } catch (\Exception $e) {
            Log::error('ScorecardController/attemptedQuestionList() => ' . $e->getMessage());
            Log::error(' => ' . $e->getLine());
            Log::error('ScorecardController/attemptedQuestionList()[data] => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * add/edit note for attempted questions
     *
     * @return \Illuminate\Http\Response
     */
    public function editNote(Request $request)
    {
        try {
            $validator_rules = [
                'attempted_question_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $r = RiskAnalysisAttemptedQuestion::find($request['attempted_question_id'])
                ->update(['note' => $request['note']]);

            return $this->success(Config::get('constants.SUCCESS'), 200);
        } catch (\Exception $e) {
            Log::error('ScorecardController/editNote() => ' . $e->getMessage());
            Log::error('ScorecardController/editNote()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * edit answer for attempted questions
     *
     * @return \Illuminate\Http\Response
     */
    public function editAnswer(Request $request)
    {
        try {
            $validator_rules = [
                'attempted_question_id' => 'required',
                'answer_id' => 'required_without:answer|array',
                'answer' => 'required_without:answer_id',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $answer_fields = $request->all();
            DB::beginTransaction();

            $attempted_question = RiskAnalysisAttemptedQuestion::with('attemptedQuestionAnswer.answerContent')->findorFail($request['attempted_question_id']);
            if ($attempted_question) {
                if (isset($request['answer_id']) && $request['answer_id'] != null) {
                    $this->addPolicyVersion($attempted_question['question_id'], $attempted_question['location_id'], $request['answer_id']);
                }
                $question_data = RiskAnalysisQuestion::where('id')->first();
                $attempted_question_answer = RiskAnalysisAttemptedQuestionAnswer::where('attempted_question_id', $attempted_question['id'])->get();
                if (count($attempted_question_answer) > 0) {
                    RiskAnalysisPreviousAttemptedQuestionAnswer::where([
                        'question_id' => $attempted_question['question_id'],
                        'location_id' => $attempted_question['location_id'],
                    ])->delete();
                    $attempted_question_answer->each(function ($ans) use ($attempted_question) {
                        $perv_answer = [
                            'question_id' => $attempted_question['question_id'],
                            'location_id' => $attempted_question['location_id'],
                        ];
                        if ($ans['answer'] != '' || $ans['answer'] != null) {
                            $perv_answer['answer'] = $ans['answer'];
                        } else {
                            $perv_answer['answer_id'] = $ans['answer_id'];
                        }
                        RiskAnalysisPreviousAttemptedQuestionAnswer::create($perv_answer);
                        $ans->delete();
                        $this->removeAnswerRecursive($attempted_question['question_id'], $ans['answer_id'], $attempted_question['location_id']);
                    });
                }
                $this->removeOngoingRecursive($attempted_question['question_id'], $attempted_question['location_id']);
                $selected_answer = [];
                if (isset($request['answer']) && $request['answer'] != '') {
                    $selected_answer[0]['answer'] = $request['answer'];
                }
                if (isset($request['answer_id']) && is_array($request['answer_id'])) {
                    foreach ($request['answer_id'] as $key => $ans) {
                        $selected_answer[$key]['answer_id'] = $ans;
                    }
                }
                $attempted_question->attemptedQuestionAnswer()->createMany($selected_answer);

                $question_detail = RiskAnalysisQuestion::where('id', $attempted_question['question_id'])->with('remindOption')->first();
                if ($question_detail['question_answer_layout'] == 'radio') {
                    $answer_detail = RiskAnalysisQuestionAnswerOption::where('id', $request['answer_id'][0])
                        ->with('remindOption')->first();
                    if (! empty($answer_detail['remindOption']) && ($answer_detail['remindOption']['ongoing_question_id'] != null && $answer_detail['remindOption']['remind_month'] != null)) {
                        $current_date = gmdate('Y-m-d');
                        $next_remind_date = gmdate('Y-m-d', strtotime('+' . $answer_detail['remindOption']['remind_month'] . ' month', strtotime($current_date)));
                        $attempted_question->update(['next_remind_date' => $next_remind_date]);
                    } elseif ($attempted_question['next_remind_date'] != null) {
                        $attempted_question->update(['next_remind_date' => null]);
                    }
                } else {
                    if (! empty($question_detail['remindOption']) && ($question_detail['remindOption']['ongoing_question_id'] != null && $question_detail['remindOption']['remind_month'] != null)) {
                        $current_date = gmdate('Y-m-d');
                        $next_remind_date = gmdate('Y-m-d', strtotime('+' . $question_detail['remindOption']['remind_month'] . ' month', strtotime($current_date)));
                        $attempted_question->update(['next_remind_date' => $next_remind_date]);
                    } elseif ($attempted_question['next_remind_date'] != null) {
                        $attempted_question->update(['next_remind_date' => null]);
                    }
                }
                // add sub question in onging
                if (isset($request['answer_id'])) {
                    // get sub question
                    $sub_questions = RiskAnalysisQuestion::where('parent_question_id', $attempted_question['question_id'])
                        ->whereIn('parent_answer_id', $request['answer_id'])->get();
                    $temp_data = [];
                    foreach ($sub_questions as $sub_question) {
                        $temp_data[] = [
                            'question_id' => $sub_question->id,
                            'location_id' => $attempted_question->location_id,
                            'question_type' => 'normal',
                            'added_date' => Carbon::now()->format('Y-m-d H:i:s'),
                            'created_at' => Carbon::now(),
                            'updated_at' => Carbon::now(),
                        ];
                    }
                    // add sub question in onging
                    OngoingRiskAnalysisQuestion::insert($temp_data);
                }

                // Update contributor answer status if answer exist.
                if (!$request->has('save_type')) {
                    $update_answer_status = RiskAnalysisContributorQuestion::where(['location_id' => $attempted_question['location_id'], 'question_id' => $attempted_question['question_id'], 'status' => 'Approved'])->first();
                    if ($update_answer_status) {
                        $update_answer_status->update(['status' => 'Rejected']);
                    }
                }
            }
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200, $answer_fields);
        } catch (\Exception $e) {
            if (!empty($request['save_type']) && $request['save_type'] == "contributor-answer-approved")
                throw new Exception("Something went wrong!");
            DB::rollBack();
            Log::error('ScorecardController/editAnswer() => ' . $e->getMessage());
            Log::error('ScorecardController/editAnswer()[data] => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * List all categories
     *
     * @return \Illuminate\Http\Response
     */
    public function categoryList(Request $request)
    {
        try {
            $list = RiskAnalysisQuestionCategory::isActive()->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('ScorecardController/categoryList() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Download pdf for scorecard
     *
     * @return \Illuminate\Http\Response
     */
    public function download(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $contributor_status = $request['contributor_status'];
            $show_questions_who_has_contributors = $request['show_questions_who_has_contributors'];

            $location = Location::with(['user', 'state'])->find($request['location_id']);
            if (! is_null($location->logo)) {
                $location->logo = $this->getSignedURL('/company_logo/' . $location['user']['id'] . '/' . $request['location_id'] . '/original/' . $location->logo);
            }
            $ra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $request['location_id'],
                    'module' => 'risk_analysis',
                ]
            )->first();
            $file_name = preg_replace('/[^A-Za-z0-9\-\_]/', '', str_replace(' ', '_', trim($location['location_nickname']))) . '-Security-Risk-Analysis-' . date('YmdHis') . '.pdf';

            $data = RiskAnalysisQuestion::isActive()
                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location) {
                    $que->where(['location_id' => $location['id']]);
                })->with(
                    ['RiskAnalysisAttemptedQuestion' => function ($que) use ($location) {
                        return $que->where('location_id', $location['id'])
                            ->with(['attemptedQuestionAnswer.answerContent', 'attemptedQuestionAnswer.answerContent.remindOptionDetail']);
                    }, 'riskAnalysisQuestionAnswerOptions', 'questionCategory', 'questionLawSection', 'riskAnalysisPreviousAttemptedQuestionAnswer' => function ($que) use ($location) {
                        return $que->where('location_id', $location['id'])
                            ->with('answerContent');
                    }]
                );
            $data = $data->with(['riskAnalysisContributorQuestion' => function ($query) use ($location, $contributor_status) {
                if (!empty($contributor_status)) {
                    $query = $query->whereIn('status', $contributor_status);
                }
                return $query->where('location_id', $location['id'])
                    ->with('contributorAttemptedQuestionAnswer.contributorAnswerContent', 'contributor_user_acntuser');
            }]);

            if (!empty($contributor_status) || !empty($show_questions_who_has_contributors)) {
                $data = $data->whereHas('riskAnalysisContributorQuestion', function ($query) use ($location, $contributor_status) {
                    if (!empty($contributor_status)) {
                        $query = $query->whereIn('status', $contributor_status);
                    }

                    return $query->where('location_id', $location['id']);
                });
            }
            if ($request->has('category_id') && ($request['category_id'] != '' || $request['category_id'] != null)) {
                $data = $data->whereIn('question_category_id', $request['category_id']);
            }
            if ($request->has('search') && ($request['search'] != '' || $request['search'] != null)) {
                $data = $data->where('question', 'LIKE', '%' . $request['search'] . '%');
            }
            $data = $data->orderBy('display_order', 'ASC')->get()->toArray();

            $question_list = [];

            foreach ($data as $key => $list) {
                try {
                    $risk_level = '';
                    $risk_levele_image = '';
                    if ($list['question_answer_layout'] == 'radio') {
                        $answer = $list['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content'];
                        $score = $answer['score'];
                        switch ($score) {
                            case 1:
                                $risk_level = 'Very Low';
                                $risk_levele_image = 'very-low.png';
                                break;
                            case 2:
                            case 3:
                                $risk_level = 'Low';
                                $risk_levele_image = 'low.png';
                                break;
                            case 4:
                            case 5:
                            case 6:
                                $risk_level = 'Medium';
                                $risk_levele_image = 'medium.png';
                                break;
                            case 7:
                            case 8:
                                $risk_level = 'High';
                                $risk_levele_image = 'high.png';
                                break;
                            case 9:
                            case 10:
                                $risk_level = 'Very High';
                                $risk_levele_image = 'very-high.png';
                                break;
                        }
                        $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['risk_level'] = $risk_level;
                        $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['risk_level_image'] = $risk_levele_image;

                        $likelihood = $answer['likelihood'];
                        $likelihood_text = '';
                        switch ($likelihood) {
                            case 1:
                                $likelihood_text = 'Low';
                                break;
                            case 2:
                                $likelihood_text = 'Medium';
                                break;
                            case 3:
                                $likelihood_text = 'High';
                                break;
                        }
                        $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['likelihood_text'] = $likelihood_text;

                        $impact = $answer['impact'];
                        $impact_text = '';
                        switch ($impact) {
                            case 1:
                                $impact_text = 'Low';
                                break;
                            case 2:
                                $impact_text = 'Medium';
                                break;
                            case 3:
                                $impact_text = 'High';
                                break;
                        }
                        $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['impact_text'] = $impact_text;
                    }
                    if (isset($data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content'])) {
                        $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['remind_option_detail'] = isset($data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['remind_option_detail']) ? $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['remind_option_detail'] : null;
                    }
                    if (($list['question_code'] == 'Q75S3' || $list['question_code'] == 'Q75S4' || $list['question_code'] == 'Q75S5')) {
                        $ra = new SecurityRiskAnalysisController;
                        $str_to_replace = $ra->getDynamicString($request['location_id'], 'Q75');
                        $data[$key]['question'] = str_replace('{%IT_PROVIDER_QUESTION%}', $str_to_replace, $list['question']);
                    }
                    $final_data = $data[$key];
                    if ($request->has('risk_level') && ! empty($request['risk_level'])) {
                        if (in_array($risk_level, $request['risk_level'])) {
                            $question_list[] = $final_data;
                        }
                        if (in_array('High', $request['risk_level'])) {
                            if ($risk_level === 'Very High') {
                                $question_list[] = $final_data;
                            }
                        }
                        if (in_array('Low', $request['risk_level'])) {
                            if ($risk_level === 'Very Low') {
                                $question_list[] = $final_data;
                            }
                        }
                    } else {
                        $question_list[] = $final_data;
                    }
                } catch (\Exception $e) {
                    Log::error('ScorecardController/download()[data_error] => ' . $e->getMessage());
                    Log::error('ScorecardController/download()[data_data] => ' . json_encode($list));
                }
            }
            $pdf_data = [
                'title' => $file_name,
                'location' => $location,
                'question_list' => $question_list,
                'sra_complete_details' => $ra_completed,
                'timezone' => $request['timezone'],
            ];
            $completed_on = Carbon::now();

            $download_url = $this->generateScorecardPdf($pdf_data, $completed_on);
            event(new DownloadLogEvent($location->user_id ?? '', 'Security-Risk-Analysis-Scorecard.pdf', $location['id']));

            return $this->success(Config::get('constants.SUCCESS'), 200, $download_url);
        } catch (\Exception $e) {
            Log::error('ScorecardController/download() => ' . $e->getMessage());
            Log::error('ScorecardController/download()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get Scorecard history
     *
     * @return \Illuminate\Http\Response
     */

    public function history(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $data = ScorecardDownloadHistory::where('location_id', $request['location_id']);
            $has_old_history = ScorecardDownloadHistory::where('location_id', $request['location_id'])->whereNull('history_data_json_file')->count();
            if ($request->has('risk_level') && ($request['risk_level'] != '' || $request['risk_level'] != null)) {
                if ($request['risk_level'] == 'Highest-Lowest') {
                    $data = $data->orderBy('high_risk_count', 'desc');
                }
                if ($request['risk_level'] == 'Lowest-Highest') {
                    $data = $data->orderBy('high_risk_count', 'asc');
                }
            } else {
                $data = $data->orderBy('created_at', 'desc');
            }
            $data = $data->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, ['data' => $data, 'has_old_history' => $has_old_history]);
        } catch (\Exception $e) {
            Log::error('ScorecardController/history() => ' . $e->getMessage());
            Log::error('ScorecardController/history()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Download Scorecard History by id
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadScorecarHistorydByID(Request $request)
    {
        try {
            $validator_rules = [
                'scorecard_download_history_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $user_data = $this->getMainAccountDetails();

            $data = ScorecardDownloadHistory::findOrFail($request['scorecard_download_history_id']);
            if (! $data['file_name']) {
                $file_path = 'scorecard_history_json/' . $data['history_data_json_file'];
                $s3_file = Storage::disk('s3')->get($file_path);
                $s3_file_data = json_decode($s3_file, 1);
                if (! is_null($s3_file_data['location']['logo'])) {
                    $s3_file_data['location']['logo'] = $this->getSignedURL('/company_logo/' . $s3_file_data['location']['user']['id'] . '/' . $s3_file_data['location']['id'] . '/original/' . $s3_file_data['location']['logo']);
                }

                $s3_file_data['timezone'] = $request->timezone;
                $download_url = $this->generateScorecardPdf($s3_file_data, $data['created_at']);
                $data->update(['file_name' => $s3_file_data['title'], 'history_data_json_file' => null]);
                $this->deleteFile($file_path);
            } else {
                $download_url = $this->getSignedURL('/SRAScorecard/' . $user_data->id . '/' . $data['file_name']);
            }
            event(new DownloadLogEvent($user_data->id, 'Security-Risk-Analysis-Scorecard-History.pdf', $data['location_id']));

            return $this->success(Config::get('constants.SUCCESS'), 200, $download_url);
        } catch (\Exception $e) {
            Log::error('ScorecardController/downloadScorecarHistorydByID() => ' . $e->getMessage());
            Log::error('ScorecardController/downloadScorecarHistorydByID()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Generate Scorecard pdf
     *
     * @param  \Illuminate\Http\Request  $request
     */
    private function generateScorecardPdf($pdf_data, $completed_on)
    {
        try {
            $user_data = $this->getMainAccountDetails();

            $pdf_data['completed_on'] = $completed_on;
            $pdf = PDF::loadView('reports/scorecard', $pdf_data);
            $s3_certificate = '/SRAScorecard/' . $user_data->id . '/' . $pdf_data['title'];
            Storage::disk('s3')->put($s3_certificate, $pdf->output(), ['ContentType' => 'application/pdf']);
            $download_url = $this->getSignedURL($s3_certificate);

            return $download_url;
        } catch (\Exception $e) {
            Log::error('ScorecardController/generateScorecardPdf() => ' . $e->getMessage());
            Log::error('ScorecardController/generateScorecardPdf()[data] => ' . json_encode([$pdf_data]));
        }
    }

    /**
     * Remove Answer Recursive
     *
     * @param  \Illuminate\Http\Request  $request
     */
    public function removeAnswerRecursive($question_id, $answer_id, $location_id)
    {
        try {
            $questions = RiskAnalysisQuestion::where([
                'parent_question_id' => $question_id,
                'parent_answer_id' => $answer_id,
            ])->get();
            if (count($questions) > 0) {
                foreach ($questions as $que) {
                    try {
                        $attempted_question = RiskAnalysisAttemptedQuestion::where(['question_id' => $que['id'], 'location_id' => $location_id])->first();
                        RiskAnalysisAttemptedQuestion::where(['question_id' => $que['id'], 'location_id' => $location_id])->delete();
                        RiskAnalysisPreviousAttemptedQuestionAnswer::where(['question_id' => $que['id'], 'location_id' => $location_id])->delete();
                        if ($attempted_question) {
                            $question_id = $attempted_question['question_id'];
                            $location_id = $attempted_question['location_id'];
                            $attempted_question_answer = RiskAnalysisAttemptedQuestionAnswer::where('attempted_question_id', $attempted_question['id'])->get();
                            if ($attempted_question_answer) {
                                $attempted_question_answer->each(function ($ans) use ($question_id, $location_id) {
                                    $ans_id = $ans['answer_id'];
                                    $ans->delete();
                                    //remove contributor questions
                                    $contri_question_data = RiskAnalysisContributorQuestion::where(["location_id" =>  $location_id, "question_id" => $question_id])->get();
                                    $contri_question_data->each(function ($item) {
                                        $item->delete();
                                    });
                                    //end remove code
                                    $this->removeAnswerRecursive($question_id, $ans_id, $location_id);
                                });
                            }
                        }
                    } catch (\Exception $e) {
                        Log::error('ScorecardController/removeAnswerRecursive()[questions_list] => ' . $e->getMessage());
                        Log::error('ScorecardController/removeAnswerRecursive()[questions_data] => ' . json_encode($que));
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('ScorecardController/removeAnswerRecursive() => ' . $e->getMessage());
            Log::error('ScorecardController/removeAnswerRecursive()[data] => ' . json_encode([$question_id, $answer_id, $location_id]));
        }
    }

    /**
     * Remove Ongoning Recursive
     *
     * @param  \Illuminate\Http\Request  $request
     */
    private function removeOngoingRecursive($question_id, $location_id)
    {
        try {
            $ongoing_question = OngoingRiskAnalysisQuestion::where([
                'question_id' => $question_id,
                'location_id' => $location_id,
                'is_answered' => 0,
            ]);
            if ($ongoing_question) {
                $ongoing_question->delete();
            }
            $question_list = RiskAnalysisQuestion::where('parent_question_id', $question_id)->get();
            foreach ($question_list as $que) {
                $this->removeOngoingRecursive($que['id'], $location_id);
            }
        } catch (\Exception $e) {
            Log::error('ScorecardController/removeOngoingRecursive() => ' . $e->getMessage());
            Log::error('ScorecardController/removeOngoingRecursive()[data] => ' . json_encode([$question_id, $location_id]));
        }
    }

    /**
     * add policy version for answer change
     */
    public function addPolicyVersion($question_id, $location_id, $answer_id)
    {
        try {
            $question_data = RiskAnalysisQuestion::where('id', $question_id)->first();
            $attempted_question = RiskAnalysisAttemptedQuestion::with('attemptedQuestionAnswer.answerContent')->where('question_id', $question_id)
                ->where('location_id', $location_id)->first();
            $answer_detail = RiskAnalysisQuestionAnswerOption::findOrFail($answer_id[0]);

            if ($question_data['question_code'] == 'Q20' || $question_data['question_code'] == 'Q31S2' || $question_data['question_code'] == 'Q31S1') {
                if ($question_data['question_code'] == 'Q20') {
                    if ($attempted_question) {
                        if (! (($attempted_question['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3' && $answer_detail['answer_code'] == 'A6') || ($attempted_question['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A6' && $answer_detail['answer_code'] == 'A3'))) {
                            $this->addPolicyVersionData('DRP', $location_id);
                        }
                    }
                } else {
                    $this->addPolicyVersionData('DRP', $location_id);
                }
            } elseif ($question_data['question_code'] == 'Q64' || $question_data['question_code'] == 'Q64S1') {
                if ($question_data['question_code'] == 'Q64') {
                    if ($attempted_question) {
                        if ($attempted_question['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                            $attempted_question_Q64S1 = RiskAnalysisAttemptedQuestion::with('attemptedQuestionAnswer.answerContent')->where('location_id', $location_id)->whereHas('question', function ($query) {
                                $query->where('question_code', 'Q64S1');
                            })->first();
                            if ($attempted_question_Q64S1 && $answer_detail['answer_code'] == 'A2') {
                                $this->addPolicyVersionData('MMPP', $location_id);
                            }
                        }
                    }
                } elseif ($question_data['question_code'] == 'Q64S1') {
                    if ($attempted_question) {
                        if ($attempted_question['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1' && $answer_detail['answer_code'] == 'A2' || $attempted_question['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2' && $answer_detail['answer_code'] == 'A1') {
                            $this->addPolicyVersionData('MMPP', $location_id);
                        }
                    }
                }
            } elseif ($question_data['question_code'] == 'Q42' || $question_data['question_code'] == 'Q43') {

                $this->addPolicyVersionData('AAP', $location_id);
            } elseif ($question_data['question_code'] == 'Q47' || $question_data['question_code'] == 'Q46' || $question_data['question_code'] == 'Q46S1' || $question_data['question_code'] == 'Q51S1' || $question_data['question_code'] == 'Q51S2' || $question_data['question_code'] == 'Q51S3' || $question_data['question_code'] == 'Q62S1' || $question_data['question_code'] == 'Q45' || $question_data['question_code'] == 'Q45S1') {

                if ($question_data['question_code'] == 'Q47' || $question_data['question_code'] == 'Q51S1' || $question_data['question_code'] == 'Q51S2' || $question_data['question_code'] == 'Q51S3') {
                    if ($attempted_question) {
                        if ($attempted_question['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1' || $answer_detail['answer_code'] == 'A1') {
                            $this->addPolicyVersionData('EFP', $location_id);
                        }
                    } else {
                        if ($answer_detail['answer_code'] == 'A1') {
                            $this->addPolicyVersionData('EFP', $location_id);
                        }
                    }
                } elseif ($question_data['question_code'] == 'Q62S1') {
                    if ($attempted_question) {
                        if ($attempted_question['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A2' || $answer_detail['answer_code'] == 'A2') {
                            $this->addPolicyVersionData('EFP', $location_id);
                        }
                    } else {
                        if ($answer_detail['answer_code'] == 'A2') {
                            $this->addPolicyVersionData('EFP', $location_id);
                        }
                    }
                } elseif ($question_data['question_code'] == 'Q45S1') {
                    if ($attempted_question) {
                        if ($attempted_question['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A3' || $answer_detail['answer_code'] != 'A3') {
                            $this->addPolicyVersionData('EFP', $location_id);
                        }
                    } else {
                        if ($answer_detail['answer_code'] != 'A3') {
                            $this->addPolicyVersionData('EFP', $location_id);
                        }
                    }
                } else {
                    $this->addPolicyVersionData('EFP', $location_id);
                }
            } elseif ($question_data['question_code'] == 'Q34' || $question_data['question_code'] == 'Q21' || $question_data['question_code'] == 'Q33' || $question_data['question_code'] == 'Q26' || $question_data['question_code'] == 'Q26S1') {

                if ($question_data['question_code'] == 'Q26') {
                    if ($attempted_question) {
                        if (! ($attempted_question['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A3' && $answer_detail['answer_code'] == 'A1')) {
                            $this->addPolicyVersionData('PMP', $location_id);
                        }
                    }
                } else {
                    $this->addPolicyVersionData('PMP', $location_id);
                }
            } elseif ($question_data['question_code'] == 'Q71') {

                $this->addPolicyVersionData('PHDRP', $location_id);
            } elseif ($question_data['question_code'] == 'Q1S3') {

                $this->addPolicyVersionData('SAP', $location_id);
            } elseif ($question_data['question_code'] == 'Q7' || $question_data['question_code'] == 'Q8' || $question_data['question_code'] == 'Q65') {
                if ($question_data['question_code'] == 'Q8') {
                    if ($attempted_question) {
                        if ($attempted_question['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1' || $answer_detail['answer_code'] == 'A1') {
                            $this->addPolicyVersionData('VCP', $location_id);
                        }
                    } else {
                        if ($answer_detail['answer_code'] == 'A1') {
                            $this->addPolicyVersionData('VCP', $location_id);
                        }
                    }
                } else {
                    $this->addPolicyVersionData('VCP', $location_id);
                }
            }
        } catch (\Exception $e) {
            Log::error('scorecardController/addPolicyVersion() => ' . $e->getMessage());
            Log::error('scorecardController/addPolicyVersion()[data] => ' . json_encode([$question_id, $location_id, $answer_id]));
        }
    }
    /**
     * It will return question and contributor detail
     *
     * @return \Illuminate\Http\Response
     */
    public function getContributorQuestiondetail(Request $request)
    {
        try {
            $validator_rules = [
                'risk_analysis_contributor_question_id' => 'required',
                'question_id' => 'required',
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $location_id = $request['location_id'];
            $question_id = $request['question_id'];
            $risk_analysis_contributor_question_id = $request['risk_analysis_contributor_question_id'];
            $question_data = RiskAnalysisQuestion::where('id', $question_id)
                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location_id) {
                    $que->where(['location_id' => $location_id]);
                })
                ->with(
                    [
                        'riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                            return $que->where('location_id', $location_id)
                                ->with('attemptedQuestionAnswer.answerContent', 'attemptedQuestionAnswer.answerContent');
                        },
                        'riskAnalysisContributorQuestion' => function ($que) use ($risk_analysis_contributor_question_id) {
                            return $que->where('id', $risk_analysis_contributor_question_id)->with('contributorAttemptedQuestionAnswer.contributorAnswerContent');
                        },
                        'riskAnalysisContributorQuestion.contributor_user_acntuser'
                    ]
                )->first();
            $get_send_question_cout = RiskAnalysisContributorQuestion::where(['status' => 'Assigned', 'location_id' => $location_id])->groupBy('question_id')->get()->count();
            $question_data->send_question_cout = $get_send_question_cout;
            // Update read review flag.
            if ($request->status == 'Reviewed') {
                $update_flag = RiskAnalysisContributorQuestion::where(['id' => $risk_analysis_contributor_question_id, 'is_review_read' => 0, 'status' => 'Reviewed'])->first();
                if ($update_flag) {
                    $update_flag->update(['is_review_read' => 1]);
                }
            }
            return $this->success(Config::get('constants.SUCCESS'), 200, $question_data);
        } catch (\Exception $e) {
            Log::error('ScorecardController/getContributorQuestiondetail() => ' . $e->getMessage());
            Log::error('Line() => ' . $e->getLine());
            Log::error('ScorecardController/getContributorQuestiondetail()[data] => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    /**
     * It will send request to contributor for question so it's status will be pending
     *
     * @return \Illuminate\Http\Response
     */
    public function sendRequestToContributor(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'risk_analysis_contributor_question_id' => 'required',
                'send_all' => 'required|in:0,1',
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();

            $contributors_arr = [];
            $location_id = $request['location_id'];
            if ($request['send_all'] == 1) {
                $contributors_list = RiskAnalysisContributorQuestion::select('location_id', 'contributor_user_acntuser_id', 'contributor_user_acntuser_type')
                    ->where(['location_id' => $location_id, 'status' => 'Assigned'])
                    ->with(['contributor_user_acntuser', 'location:id,location_nickname'])
                    ->distinct()
                    ->get();
                $contributor_data = RiskAnalysisContributorQuestion::where(['location_id' => $location_id, 'status' => 'Assigned'])->each(function ($item) {
                    $item->status = 'Pending';
                    $item->invite_sent_date = Carbon::now();
                    $item->save(); // Triggers the observer
                });
                $contributors_arr = (count($contributors_list) > 0 ? $contributors_list->toArray() : []);
            } else {
                $contributors_list = RiskAnalysisContributorQuestion::with('contributor_user_acntuser', 'location:id,location_nickname')->find($request['risk_analysis_contributor_question_id']);

                if (!empty($contributors_list)) {
                    if ($contributors_list->status != 'Assigned') {
                        return $this->error(Config::get('constants.SRA_CONTRIBUTOR.INVITATION_IS_ALREADY_SENT'), 200);
                    }
                    $contributors_arr[] = $contributors_list->toArray();
                    $contributor_data = RiskAnalysisContributorQuestion::where(['id' => $request['risk_analysis_contributor_question_id']])->first();

                    if ($contributor_data) {
                        $contributor_data->status = 'Pending';
                        $contributor_data->invite_sent_date = Carbon::now();
                        $contributor_data->save(); // This will trigger the observer
                    }
                }
            }
            $emailTemplate = EmailTemplate::where('code', 'HCE-UE65')->first();
            foreach ($contributors_arr as $key => $contributor) {
                //send mail               
                $email_vars = [
                    '{%CONTRIBUTOR_FIRST_NAME%}' => $contributor['contributor_user_acntuser']['first_name'],
                    '{%COMPANY_NAME%}' => $user_data->company_name,
                    '{%LOGIN_TO_ABYDE_CONTRIBUTOR_PORTAL%}' => Config::get('app.sra_contributor_portal_url') . "/" . base64_encode($location_id) . "/" . base64_encode($contributor['contributor_user_acntuser_id']) . "/" . base64_encode($contributor['contributor_user_acntuser_type']),
                    '{%PCO_OFFICER%}' => $user_data->first_name . ' ' . $user_data->last_name,
                    '{%PCO_OFFICER_EMAIL%}' => $user_data->email,
                    '{%HIPAABA_LINK%}' => Config::get('app.hipaa_business_associates_url'),
                    '{%PARTNER_LINK%}' => Config::get('app.partner_url')
                ];
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                $html_subject = $emailTemplate->subject;
                $this->sendEmail($emailTemplate->code, $html,  $contributor['contributor_user_acntuser']['email'], Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                //end send mail
            }
            DB::commit();
            return $this->success(Config::get('constants.SRA_CONTRIBUTOR.INVITATION_IS_SENT_SUCCESSFULLY'), 200);
        } catch (\Exception $e) {
            Log::error('ScorecardController/sendRequestToContributor() => ' . $e->getMessage());
            Log::error('Line() => ' . $e->getLine());
            Log::error('ScorecardController/sendRequestToContributor()[data] => ' . json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * It will send reminder contributor for questions whose status is pending 
     *
     * @return \Illuminate\Http\Response
     */
    public function sendReminderToContributor(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'risk_analysis_contributor_question_id' => 'required',
                'send_all' => 'required|in:0,1',
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();

            $contributors_arr = [];
            $location_id = $request['location_id'];
            if ($request['send_all'] == 1) {
                $contributors_list = RiskAnalysisContributorQuestion::select('location_id', 'contributor_user_acntuser_id', 'contributor_user_acntuser_type')
                    ->where(['location_id' => $location_id, 'status' => 'Pending'])
                    ->with(['contributor_user_acntuser', 'location:id,location_nickname'])
                    ->distinct()
                    ->get();
                $contributor_data = RiskAnalysisContributorQuestion::where(['location_id' => $location_id, 'status' => 'Pending'])->get()->each(function ($item) {
                    $item->invite_sent_date = Carbon::now();
                    $item->save(); // Triggers the observer
                });
                $contributors_arr = (count($contributors_list) > 0 ? $contributors_list->toArray() : []);
            } else {
                $contributors_list = RiskAnalysisContributorQuestion::with('contributor_user_acntuser', 'location:id,location_nickname')->find($request['risk_analysis_contributor_question_id']);

                if (!empty($contributors_list)) {
                    if ($contributors_list->status != 'Pending') {
                        return $this->error(Config::get('constants.SRA_CONTRIBUTOR.INVITATION_REMINDER_ALLOW_FOR_ONLY_PENDING_STATUS'), 200);
                    }
                    $contributors_arr[] = $contributors_list->toArray();
                    $contributor_data = RiskAnalysisContributorQuestion::where(['id' => $request['risk_analysis_contributor_question_id']])->first();
                    if ($contributor_data) {
                        $contributor_data->invite_sent_date = Carbon::now();
                        $contributor_data->save(); // This will trigger the observer
                    }
                }
            }
            $emailTemplate = EmailTemplate::where('code', 'HCE-UE66')->first();
            foreach ($contributors_arr as $key => $contributor) {
                //send mail               
                $email_vars = [
                    '{%CONTRIBUTOR_FIRST_NAME%}' => $contributor['contributor_user_acntuser']['first_name'],
                    '{%COMPANY_NAME%}' => $user_data->company_name,
                    '{%LOGIN_TO_ABYDE_CONTRIBUTOR_PORTAL%}' => Config::get('app.sra_contributor_portal_url') . "/" . base64_encode($location_id) . "/" . base64_encode($contributor['contributor_user_acntuser_id']) . "/" . base64_encode($contributor['contributor_user_acntuser_type']),
                    '{%PCO_OFFICER%}' => $user_data->first_name . ' ' . $user_data->last_name,
                    '{%PCO_OFFICER_EMAIL%}' => $user_data->email,
                    '{%HIPAABA_LINK%}' => Config::get('app.hipaa_business_associates_url'),
                    '{%PARTNER_LINK%}' => Config::get('app.partner_url')
                ];
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                $html_subject = $emailTemplate->subject;
                $this->sendEmail($emailTemplate->code, $html,  $contributor['contributor_user_acntuser']['email'], Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                //end send mail
            }
            DB::commit();
            return $this->success(Config::get('constants.SRA_CONTRIBUTOR.INVITATION_REMINDER_IS_SENT_SUCCESSFULLY'), 200);
        } catch (\Exception $e) {
            Log::error('ScorecardController/sendreminderToContributor() => ' . $e->getMessage());
            Log::error('Line() => ' . $e->getLine());
            Log::error('arguements => ' . json_encode($request->all()));
            DB::rollback();
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * fetch internal[from user, account user]  and external [SRA contributors] contributors
     *
     * @return \Illuminate\Http\Response
     */
    public function fetchAllContributors(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'question_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $external = RiskAnalysisContributor::select('id', 'first_name', 'last_name', 'email', DB::raw("'sra_contributor' AS morph_type"))
                ->with('riskAnalysisContributorQuestionSingle', function ($que) use ($request) {
                    $que->where(["location_id" => $request['location_id'], "question_id" => $request['question_id'], "contributor_user_acntuser_type" => \App\Models\RiskAnalysisContributor::class])
                        ->whereIn("status", ['Assigned', 'Pending', 'Reviewed']);
                })
                ->whereHas('riskAnalysisContributorLocation', function ($q) use ($request) {
                    $q->where('location_id', $request['location_id']);
                })
                ->whereDoesntHave('riskAnalysisContributorQuestionSingle', function ($que) use ($request) {
                    $que->where(["location_id" => $request['location_id'], "question_id" => $request['question_id'], "contributor_user_acntuser_type" => \App\Models\RiskAnalysisContributor::class])
                        ->whereIn("status", ['Assigned', 'Pending', 'Reviewed']);
                })
                ->orderBy('id', 'desc')->get();

            $user_data = $this->getMainAccountDetails();
            $logged_in_user = $this->getLoginUserData();

            $internal_user = collect();
            if ($logged_in_user['user_type'] !== 'PCO') {
                $internal_user = User::select(['id', 'first_name', 'last_name', 'email', DB::raw('"PCO" As morph_type')])
                    ->where('id', $user_data['id'])
                    ->with('riskAnalysisContributorQuestionSingle', function ($que) use ($request) {
                        $que->where(["location_id" => $request['location_id'], "question_id" => $request['question_id'], "contributor_user_acntuser_type" => \App\Models\User::class])
                            ->whereIn("status", ['Assigned', 'Pending', 'Reviewed']);
                    })
                    ->whereDoesntHave('riskAnalysisContributorQuestionSingle', function ($que) use ($request) {
                        $que->where(["location_id" => $request['location_id'], "question_id" => $request['question_id'], "contributor_user_acntuser_type" => \App\Models\User::class])
                            ->whereIn("status", ['Assigned', 'Pending', 'Reviewed']);
                    })
                    ->get();
            }
            $internal_acc_user = AccountUser::select('id', 'first_name', 'last_name', 'email', DB::raw("'account_user' AS morph_type"))
                ->with('riskAnalysisContributorQuestionSingle', function ($que) use ($request) {
                    $que->where(["location_id" => $request['location_id'], "question_id" => $request['question_id'], "contributor_user_acntuser_type" => \App\Models\AccountUser::class])
                        ->whereIn("status", ['Assigned', 'Pending', 'Reviewed']);
                })
                ->whereHas('accountLocationAccess', function ($q) use ($request) {
                    $q->where('location_id', $request['location_id']);
                })
                ->whereDoesntHave('riskAnalysisContributorQuestionSingle', function ($que) use ($request) {
                    $que->where(["location_id" => $request['location_id'], "question_id" => $request['question_id'], "contributor_user_acntuser_type" => \App\Models\AccountUser::class])
                        ->whereIn("status", ['Assigned', 'Pending', 'Reviewed']);
                });
            if ($logged_in_user['user_type'] != 'PCO') {
                $internal_acc_user = $internal_acc_user->where('id', '!=', $logged_in_user['id']);
            }

            $internal_acc_user = $internal_acc_user->orderBy('id', 'desc')->get();
            $data = [
                'internal' => $internal_user->merge($internal_acc_user)->toArray(),
                'external' => $external->toArray(),
            ];
            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('ScorecardController/fetchAllContributors() => ' . $e->getMessage());
            Log::error('Line() => ' . $e->getLine());
            Log::error('arguements => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    /**
     * fetch internal[from user, account user]  and external [SRA contributors] contributors
     *
     * @return \Illuminate\Http\Response
     */
    public function saveContributors(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'question_id' => 'required',
                'contributors_list' => 'required |array',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $logged_in_user = $this->getLoginUserData();

            $contributors_list = $request['contributors_list'];
            $location_id = $request['location_id'];
            $question_id = $request['question_id'];
            foreach ($contributors_list as $new_contri) {
                $contrbutor_type = ($new_contri['contributor_type'] == "PCO" ? \App\Models\User::class : ($new_contri['contributor_type'] == "account_user" ? \App\Models\AccountUser::class : \App\Models\RiskAnalysisContributor::class));
                $data = [
                    'location_id' => $location_id,
                    'question_id' => $question_id,
                    'contributor_user_acntuser_id' => $new_contri['contributor_id'],
                    'contributor_user_acntuser_type' => $contrbutor_type,
                    'status' => 'Assigned',
                    'created_at' => Carbon::now(),
                    'updated_at' => Carbon::now(),
                ];
                RiskAnalysisContributorQuestion::create($data);
            }

            return $this->success(Config::get('constants.SRA_CONTRIBUTOR.CONTRIBUTOR_ASSIGNED'), 200);
        } catch (\Exception $e) {
            Log::error('ScorecardController/saveContributors() => ' . $e->getMessage());
            Log::error('Line() => ' . $e->getLine());
            Log::error('arguements => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    /**
     * It will return question and contributor detail
     *
     * @return \Illuminate\Http\Response
     */
    public function getContributorQuestionAnswerdetail(Request $request)
    {
        try {
            $validator_rules = [
                'risk_analysis_contributor_question_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $risk_analysis_contributor_question_id = $request['risk_analysis_contributor_question_id'];

            $question_data = RiskAnalysisContributorQuestion::with([
                'contributor_user_acntuser',
                'contributorAttemptedQuestionAnswer.contributorAnswerContent'

            ])
                ->where("id", $risk_analysis_contributor_question_id)->first();
            if ($question_data['status'] == "") {
                return $this->error(Config::get('constants.SRA_CONTRIBUTOR.ONLY_ALLOW_REVIEW_SATUS'), 200);
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $question_data);
        } catch (\Exception $e) {
            Log::error('ScorecardController/getContributorQuestionAnswerdetail() => ' . $e->getMessage());
            Log::error('Line() => ' . $e->getLine());
            Log::error('arguements => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /* It will return Save contributor answer
     *
     * @return \Illuminate\Http\Response
    */
    public function approveRejectContributorAnswer(Request $request)
    {
        try {
            $validator_rules = [
                'attempted_question_id' => 'required',
                'answer_id' => 'required_without:answer|array',
                'answer' => 'required_without:answer_id',
                'contri_answer_status' => 'required|in:Approved,Rejected',
                'risk_analysis_contributor_question_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $msg = ($request['contri_answer_status'] == "Approved" ? Config::get('constants.SRA_CONTRIBUTOR.APPROVED_SUCCESSFULLY') : Config::get('constants.SRA_CONTRIBUTOR.REJECTED_SUCCESSFULLY'));

            DB::beginTransaction();
            $attempted_question = RiskAnalysisAttemptedQuestion::with('attemptedQuestionAnswer.answerContent')->findorFail($request['attempted_question_id']);

            if (!empty($attempted_question)) {
                $sra_question = RiskAnalysisContributorQuestion::where('id', $request['risk_analysis_contributor_question_id'])->whereIn("status", ["Reviewed", "Rejected", "Approved"])->first();

                if (!empty($sra_question)) {
                    if ($request['contri_answer_status'] == "Approved") {
                        //set accepted answer as  rejected
                        $previously_approved = RiskAnalysisContributorQuestion::where(['location_id' => $attempted_question->location_id, "status" => "Approved", "question_id" =>  $attempted_question->question_id])->get()->each(function ($item) {
                            $item->status = "Rejected";
                            $item->save();
                        });
                        //end code
                    }

                    $user_type = $this->getLoginUserData();
                    $sra_question->update(['status' => $request['contri_answer_status'], 'review_by_user_acntuser_id' => $user_type['id'], 'review_by_user_acntuser_type' => ($user_type['user_type'] == 'PCO' ? \App\Models\User::class : \App\Models\AccountUser::class)]);

                    if ($request['contri_answer_status'] == "Approved") {
                        $attempted_question->update(['note' => $sra_question->notes]);
                        $request['save_type'] = "contributor-answer-approved";
                        $this->editAnswer($request);
                    }
                }
            }
            DB::commit();
            return $this->success($msg, 200);
        } catch (\Exception $e) {
            Log::error('ScorecardController/approveRejectContributorAnswer() => ' . $e->getMessage());
            Log::error('Line() => ' . $e->getLine());
            Log::error('arguements => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    /* It will delete contributor
     *
     * @return \Illuminate\Http\Response
    */
    public function deleteAssignedContributor(Request $request)
    {
        try {
            $validator_rules = [
                'risk_analysis_contributor_question_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            DB::beginTransaction();
            $sra_data = RiskAnalysisContributorQuestion::with("contributorAttemptedQuestionAnswer")->findorFail($request['risk_analysis_contributor_question_id']);

            if (!empty($sra_data)) {
                if ($sra_data->status == "Assigned" || $sra_data->status == "Rejected" || $sra_data->status == "Approved" || $sra_data->status == "Pending") {
                    $sra_data->delete();
                } else {
                    return $this->error(Config::get('constants.SRA_CONTRIBUTOR.CANOTRIBUTOR_CANNOT_DELETE'), 200);
                }
            }
            DB::commit();
            return $this->success(Config::get('constants.SRA_CONTRIBUTOR.CONTRIBUTOR_FOR_QUESTION_DELETED'), 200);
        } catch (\Exception $e) {
            Log::error('ScorecardController/deleteAssignedContributor() => ' . $e->getMessage());
            Log::error('Line() => ' . $e->getLine());
            Log::error('arguements => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    /************************** */
    /*API methods - end
    /*************************** */
}
