<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\AbydeDriveArchiveFile;
use App\Models\AbydeDriveArchiveFolder;
use App\Models\AbydeDriveFile;
use App\Models\AbydeDriveFileShare;
use App\Models\AbydeDriveFolder;
use App\Models\AbydeDriveFolderShare;
use App\Models\AccountUser;
use App\Models\Location;
use App\Models\User;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\FileUpload;
use App\Traits\GetMainUserData;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class AbydeDriveController extends Controller
{
    use ApiResponser, CheckAccessRight, FileUpload, GetMainUserData;

    /**
     * Site Policy  page
     *
     * @return \Illuminate\Http\Response
     */
    public function showAbydeDrive(Request $request)
    {
        if ($this->checkAccessRight('abyde_drive')) {
            return view('app.pages.abydedrive');
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Get list of files and folders
     *
     * @return \Illuminate\Http\Response
     */
    public function listDocuments(Request $request)
    {

        $validator_rules = [
            'location_id' => 'required',
            'parent_folder_id' => 'nullable',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }

        $input_fields = $request->all();

        try {
            $parent_folder_id = (isset($input_fields['parent_folder_id']) && $input_fields['parent_folder_id'] != '') ? $input_fields['parent_folder_id'] : null;

            $folders = AbydeDriveFolder::where('parent_folder_id', $parent_folder_id)
                ->where('location_id', $input_fields['location_id'])
                ->with('user')
                ->withCount('folderShare')
                ->orderBy('created_at', 'desc')
                ->get()
                ->map(function ($folder) use ($input_fields) {
                    $folder->is_shared = $this->checkParentFolderShared($folder->id, $input_fields['location_id']);
                    return $folder;
                });

            $files = AbydeDriveFile::where(['folder_id' => $parent_folder_id])
                ->where('location_id', $input_fields['location_id'])
                ->with('user')
                ->withCount('fileShare')
                ->orderBy('created_at', 'desc')->orderBy('id', 'desc')
                ->get()
                ->map(function ($file) use ($input_fields, $parent_folder_id) {
                    $file->is_shared = $this->checkParentFileShared($parent_folder_id, $file->id, $input_fields['location_id']);
                    return $file;
                });

            $archive_folders = AbydeDriveArchiveFolder::whereNull('parent_folder_id');
            $user_data = $this->getMainAccountDetails();
            if ($user_data->is_educational_account == 0) {
                $archive_folders = $archive_folders->where('folder_name', '!=', 'Students');
            }
            $archive_folders = $archive_folders->get();

            $data = [
                'folders' => $folders,
                'files' => $files,
                'archive_folders' => $archive_folders,
            ];
            if (! $parent_folder_id) {
                $recent_files = AbydeDriveFile::where('location_id', $input_fields['location_id'])
                    ->withCount('fileShare')
                    ->limit(5)->orderBy('created_at', 'desc')
                    ->orderBy('id', 'desc')
                    ->get()
                    ->map(function ($recent_file) use ($parent_folder_id, $input_fields) {
                        $recent_file->is_shared = $this->checkParentFileShared($parent_folder_id, $recent_file->id, $input_fields['location_id'], 1);
                        return $recent_file;
                    });
                $data['recent_files'] = $recent_files;
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/listDocuments() => ' . $e->getMessage());
            Log::error('AbydeDriveController/listDocuments()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Create new folder
     *
     * @return \Illuminate\Http\Response
     */
    public function createFolder(Request $request)
    {
        $user_data = auth()->user();
        $validator_rules = [
            'parent_folder_id' => 'nullable',
            'location_id' => 'required',
            'folder_name' => ['required', Rule::unique(\App\Models\AbydeDriveFolder::class)->where(function ($q) use ($request) {
                $parent_folder_id = $request->has('parent_folder_id') && $request->parent_folder_id ? $request->parent_folder_id : null;
                $location_id = $request->location_id;

                return $q->where(['parent_folder_id' => $parent_folder_id])
                    ->where('location_id', $location_id)
                    ->where('deleted_at', null);
            })],
        ];
        $validator_rules_messages = [
            'folder_name.unique' => Config::get('constants.ABYDE_DRIVE.DUPLICATE_FOLDER'),
        ];
        $validator_check = Validator::make($request->all(), $validator_rules, $validator_rules_messages);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $input_fields = $request->all();
            $check_current_login = auth()->getDefaultDriver();
            $folder_data = null;
            if ($check_current_login == 'user') {
                $folder_data = User::find($user_data->id)->abydeDriveFolderOwner()->create($input_fields);
            } elseif ($check_current_login == 'account_user') {
                $folder_data = AccountUser::find($user_data->id)->abydeDriveFolderOwner()->create($input_fields);
            }
            if ($folder_data) {
                return $this->success(Config::get('constants.ABYDE_DRIVE.FOLDER_CREATED'), 200, $folder_data);
            } else {
                return $this->error(Config::get('constants.ABYDE_DRIVE.FOLDER_NOT_CREATED'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/createFolder() => ' . $e->getMessage());
            Log::error('AbydeDriveController/createFolder()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Rename folder
     *
     * @return \Illuminate\Http\Response
     */
    public function renameFolder(Request $request)
    {
        $validator_rules = [
            'location_id' => 'required',
            'folder_id' => 'required',
            'parent_folder_id' => 'nullable',
            'folder_name' => ['required', Rule::unique(\App\Models\AbydeDriveFolder::class)->where(function ($q) use ($request) {
                $parent_folder_id = $request->has('parent_folder_id') && $request->parent_folder_id ? $request->parent_folder_id : null;
                $location_id = $request->location_id;

                return $q->where('id', '!=', $request['folder_id'])
                    ->where(['parent_folder_id' => $parent_folder_id])
                    ->where('location_id', $location_id)
                    ->where('deleted_at', null);
            })],
        ];
        $validator_rules_messages = [
            'folder_name.unique' => Config::get('constants.ABYDE_DRIVE.DUPLICATE_FOLDER'),
        ];
        $validator_check = Validator::make($request->all(), $validator_rules, $validator_rules_messages);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $folder = AbydeDriveFolder::findOrFail($request->folder_id);
            if ($folder->update([
                'folder_name' => $request->folder_name,
            ])) {
                return $this->success(Config::get('constants.ABYDE_DRIVE.FOLDER_RENAMED'), 200);
            } else {
                return $this->error(Config::get('constants.ABYDE_DRIVE.FOLDER_NOT_RENAMED'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/renameFolder() => ' . $e->getMessage());
            Log::error('AbydeDriveController/renameFolder()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * delete folder
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteFolder(Request $request)
    {
        $validator_rules = [
            'folder_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            if (AbydeDriveFolder::where('id', $request->folder_id)
                ->get()->each(function ($folder) {
                    $folder->delete();
                })
            ) {
                return $this->success(Config::get('constants.ABYDE_DRIVE.FOLDER_DELETED'), 200);
            } else {
                return $this->error(Config::get('constants.ABYDE_DRIVE.FOLDER_NOT_DELETED'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/deleteFolder() => ' . $e->getMessage());
            Log::error('AbydeDriveController/deleteFolder()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * view folder detail
     *
     * @return \Illuminate\Http\Response
     */
    public function viewFolderDetail(Request $request)
    {
        $validator_rules = [
            'folder_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $folder = AbydeDriveFolder::with('user')->find($request['folder_id']);
            if (! $folder) {
                $folder = AbydeDriveFolder::withTrashed()->with('user')->findOrFail($request->folder_id);
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $folder);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/viewFolderDetail() => ' . $e->getMessage());
            Log::error('AbydeDriveController/viewFolderDetail()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Download folder
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadFolder(Request $request)
    {
        $validator_rules = [
            'folder_id' => 'required',
            'location_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $public_path = public_path();
            if (! is_dir($public_path . '/storage/temp_zip_abyde_drive/' . $request['location_id'])) {
                Storage::disk('public')->makeDirectory('/temp_zip_abyde_drive/' . $request['location_id']);
            }

            $call_type = 'original';
            $folder = AbydeDriveFolder::where('id', $request['folder_id'])
                ->with(['subFolders', 'files'])->get();
            if (count($folder) == 0) {
                $folder = AbydeDriveFolder::withTrashed()->where('id', $request['folder_id'])
                    ->with(['subFoldersOnlyTrash', 'filesOnlyTrash'])->get();
                $call_type = 'trash';
            }
            if (count($folder) > 0) {
                $zip_file_path = '/temp_zip_abyde_drive/' . $request['location_id'] . '/' . $folder[0]->folder_name . '.zip';

                $zip = new \ZipArchive;

                if ($zip->open($public_path . '/storage' . $zip_file_path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE)) {
                    if (isset($folder)) {
                        $this->addFoldersToZip($zip, $folder, $call_type);
                    }

                    $zip->close();

                    return $this->success(Config::get('constants.ABYDE_DRIVE.FOLDER_DOWNLOADED'), 200, ['download_url' => asset('storage' . $zip_file_path)]);
                } else {
                    return $this->error(Config::get('constants.ABYDE_DRIVE.FOLDER_NOT_DOWNLOADED'), 200);
                }
            }
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/downloadFolder() => ' . $e->getMessage());
            Log::error('AbydeDriveController/downloadFolder()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function addFoldersToZip($zip, $folders, $call_type, $dir = '', $level = 1)
    {
        try {
            if (! empty($folders)) {
                foreach ($folders as $folder) {
                    $old_dir = $dir;
                    if ($level == 1) {
                        $dir = $folder['folder_name'];
                    } else {
                        $dir = $folder['parent_folder_id'] ? $dir . '/' . $folder['folder_name'] : $folder['folder_name'];
                    }
                    if (count($folder[($call_type == 'trash') ? 'filesOnlyTrash' : 'files'])) {
                        foreach ($folder[($call_type == 'trash') ? 'filesOnlyTrash' : 'files'] as $file) {
                            $download_file = Storage::disk('s3')->get('/abyde_drive/' . $file['location_id'] . '/' . $file['file_name']);
                            if ($download_file != null) {
                                $zip->addFromString($dir . '/' . $file['file_name'], $download_file);
                            }
                        }
                    } else {
                        $zip->addEmptyDir($dir);
                    }
                    if (! empty($folder[($call_type == 'trash') ? 'subFoldersOnlyTrash' : 'subFolders'])) {
                        $this->addFoldersToZip($zip, $folder[($call_type == 'trash') ? 'subFoldersOnlyTrash' : 'subFolders'], $call_type, $dir, ++$level);
                    }
                    $dir = $old_dir;
                }
            }
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/addFoldersToZip() => ' . $e->getMessage());
            Log::error('AbydeDriveController/addFoldersToZip()[data] => ' . json_encode([$zip, $folders, $call_type, $dir, $level]));
        }
    }

    /**
     * Move folder
     *
     * @return \Illuminate\Http\Response
     */
    public function moveFolder(Request $request)
    {
        $validator_rules = [
            'location_id' => 'required',
            'destination_folder_id' => 'nullable',
            'folder_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            DB::beginTransaction();
            $destination_folder_id = $request->destination_folder_id ? $request->destination_folder_id : null;
            $folder = AbydeDriveFolder::find($request->folder_id);
            if (! $folder) {
                $folder = AbydeDriveFolder::withTrashed()->find($request->folder_id);
            }
            if ($folder->parent_folder_id == $destination_folder_id) {
                if ($folder->deleted_at == null) {
                    return $this->error(Config::get('constants.ABYDE_DRIVE.ALREADY_EXIST'), 200);
                }
            }
            $check_duplicate = AbydeDriveFolder::where([
                'location_id' => $request->location_id,
                'parent_folder_id' => $destination_folder_id,
            ])
                ->whereRaw('LOWER(folder_name) = LOWER("' . $folder['folder_name'] . '")')
                ->first();
            if ($check_duplicate) {
                return $this->error(Config::get('constants.ABYDE_DRIVE.ALREADY_EXIST'), 200);
            }
            $parentFolderId = $folder->parent_folder_id;
            if ($folder->update(['parent_folder_id' => $destination_folder_id])) {
                if ($folder['deleted_at'] != null) {
                    $this->restoreFolderRecursive($request->folder_id);
                } else {
                    $this->restoreFolderRecursive($request->folder_id);
                    if ($destination_folder_id != null) {
                        $getNearestSharedParentFolderIds = $this->getMultipleLocSharedFolderListData($destination_folder_id);
                        $getNearestSharedParentFolderList = AbydeDriveFolderShare::where([
                            'from_loc_id' => $request->location_id
                        ])->whereIn('abyde_drive_folder_id', $getNearestSharedParentFolderIds)->get();
                        $checkFolderTree = AbydeDriveFolder::where('id', $request->folder_id)
                            ->where(['location_id' => $request->location_id])
                            ->with('subFolders', 'files')
                            ->first();

                        $subFolderIds = $this->getSubfolderIds($checkFolderTree);
                        $filesIds = $this->getSubfolderFilesIds($checkFolderTree);

                        if (!empty($getNearestSharedParentFolderList)) {
                            $subFolderIds[] = $request->folder_id;
                            foreach ($getNearestSharedParentFolderList as $getNearestSharedParentFolder) {
                                $checkAlreadySharedSubFoldersId = AbydeDriveFolderShare::where([
                                    'from_loc_id' => $request->location_id,
                                    'to_loc_id' => $getNearestSharedParentFolder->to_loc_id
                                ])
                                    ->whereIn('abyde_drive_folder_id', $subFolderIds)
                                    ->pluck('id');

                                $checkAlreadySharedSubFoldersFilesId = AbydeDriveFileShare::where([
                                    'from_loc_id' => $request->location_id,
                                    'to_loc_id' => $getNearestSharedParentFolder->to_loc_id
                                ])
                                    ->whereIn('abyde_drive_file_id', $filesIds)
                                    ->pluck('id');

                                // // Delete already shared sub folders and files    
                                AbydeDriveFolderShare::whereIn('id', $checkAlreadySharedSubFoldersId)->delete();
                                AbydeDriveFileShare::whereIn('id', $checkAlreadySharedSubFoldersFilesId)->delete();
                            }
                        }
                    } else {
                        $user_data = auth()->user();
                        $check_current_login = auth()->getDefaultDriver();
                        if ($check_current_login == 'user') {
                            $user_id = $user_data->id;
                            $user_type = 'App\Models\User';
                        } elseif ($check_current_login == 'account_user') {
                            $user_id = $user_data->id;
                            $user_type = 'App\Models\AccountUser';
                        }
                        $getNearestSharedParentFolderList = $this->getNearestSharedParentFolderList($parentFolderId);
                        $shared_folder_data = [];
                        if ($getNearestSharedParentFolderList != null) {
                            foreach ($getNearestSharedParentFolderList as $getNearestSharedParentFolder) {
                                $shared_folder_data[] = [
                                    'abyde_drive_folder_id' => $request->folder_id,
                                    'from_loc_id' => $request->location_id,
                                    'to_loc_id' => $getNearestSharedParentFolder->to_loc_id,
                                    'user_id' => $user_id,
                                    'user_type' => $user_type,
                                    'created_at' => Carbon::now(),
                                    'updated_at' => Carbon::now()
                                ];
                            }
                            $insert_shared_folder_data = AbydeDriveFolderShare::insert($shared_folder_data);
                        }
                    }
                }
                DB::commit();
                return $this->success(Config::get('constants.ABYDE_DRIVE.FOLDER_MOVED'), 200);
            }
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('AbydeDriveController/moveFolder() => ' . $e->getMessage());
            Log::error('AbydeDriveController/moveFolder()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.ABYDE_DRIVE.FOLDER_FILE_NOT_MOVED'), 200);
        }
    }

    public function restoreFolderRecursive($id)
    {
        try {
            $folder = AbydeDriveFolder::with('subFoldersWithTrash')->withTrashed()->find($id);
            if ($folder) {
                $folder->restore();
                if ($folder->subFoldersWithTrash()->exists() == 'true') {
                    foreach ($folder->subFoldersWithTrash as $subfolders) {
                        $this->restoreFolderRecursive($subfolders->id);
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/restoreFolderRecursive() => ' . $e->getMessage());
            Log::error('AbydeDriveController/restoreFolderRecursive()[data] => ' . json_encode([$id]));
        }
    }

    /**
     * get folder tree
     *
     * @return \Illuminate\Http\Response
     */
    public function folderTree(Request $request)
    {
        $validator_rules = [
            'location_id' => 'required',
            'type' => 'required',
            'folder_id' => 'required_if:type,folder',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $folders = AbydeDriveFolder::where(['parent_folder_id' => null, 'location_id' => $request->location_id])
                ->where('id', '!=', $request->folder_id)
                ->with(['folderTree'])
                ->get();
            $data = [
                'folder_id' => null,
                'folder_name' => 'Abyde Drive',
                'folder_tree' => $folders,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/folderTree() => ' . $e->getMessage());
            Log::error('AbydeDriveController/folderTree()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * upload files
     *
     * @return \Illuminate\Http\Response
     */
    public function uploadFile(Request $request)
    {
        $user_data = auth()->user();
        $validator_rules = [
            'location_id' => 'required',
            'file' => 'required|mimes:txt,csv,jpg,jpeg,doc,docx,pdf,png,zip,html,xls,xlsx|max:10240',
        ];
        $validator_rules_messages = [
            'file.mimes' => 'You can\'t upload this type of file.',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules, $validator_rules_messages);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            DB::beginTransaction();
            $input_fields = $request->all();
            $input_fields['user_id'] = $user_data->user_id;
            $file = $request->file('file');
            $input_fields['title'] = basename($file->getClientOriginalName(), '.' . $file->getClientOriginalExtension());
            $input_fields['title'] = substr($input_fields['title'], 0, 25);
            $file_name = $input_fields['title'] . '.' . $file->getClientOriginalExtension();
            $check_file = AbydeDriveFile::where([
                'file_name' => $file_name,
                'location_id' => $input_fields['location_id'],
            ]);
            // if ($request->has('folder_id') && ($request['folder_id'] != null || $request['folder_id'] != 0)) {
            //     $check_file = $check_file->where('folder_id', $input_fields['folder_id']);
            // } else {
            //     $check_file = $check_file->where('folder_id', NULL);
            // }
            $check_file = $check_file->first();

            if ($check_file) {
                for ($i = 1; $i <= 50; $i++) {
                    $file_name = $input_fields['title'] . '(' . $i . ').' . $file->getClientOriginalExtension();
                    $check_file = AbydeDriveFile::where([
                        'file_name' => $file_name,
                        'location_id' => $input_fields['location_id'],
                    ]);
                    // if ($request->has('folder_id') && ($request['folder_id'] != null || $request['folder_id'] != 0)) {
                    //     $check_file = $check_file->where('folder_id', $input_fields['folder_id']);
                    // } else {
                    //     $check_file = $check_file->where('folder_id', NULL);
                    // }
                    $check_file = $check_file->first();
                    if ($check_file == null) {
                        $input_fields['title'] = $input_fields['title'] . '(' . $i . ')';
                        break;
                    }
                }
            }

            $check_current_login = auth()->getDefaultDriver();
            $file_data = null;
            if ($check_current_login == 'user') {
                $file_data = User::find($user_data->id)->abydeDriveFileOwner()->create($input_fields);
            } elseif ($check_current_login == 'account_user') {
                $file_data = AccountUser::find($user_data->id)->abydeDriveFileOwner()->create($input_fields);
            }
            $file_path = '/abyde_drive/' . $request['location_id'];
            $file->storeAs(
                $file_path,
                $file_name, //$fileName
                ['disk' => 's3', 'ContentType' => 'application/octet-stream'] //$options
            );
            $file_size = $this->getReadableFilesize($file->getSize());
            $file_data->update([
                'file_name' => $file_name,
                'file_size' => $file_size,
            ]);
            DB::commit();

            return $this->success(Config::get('constants.ABYDE_DRIVE.FILE_UPLOADED'), 200);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('AbydeDriveController/uploadFile() => ' . $e->getMessage());
            Log::error('AbydeDriveController/uploadFile()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Rename file
     *
     * @return \Illuminate\Http\Response
     */
    public function renameFile(Request $request)
    {
        $validator_rules = [
            'file_id' => 'required',
            'file_name' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $file = AbydeDriveFile::findOrFail($request->file_id);
            if ($file->title == trim($request->file_name)) {
                return $this->success(Config::get('constants.ABYDE_DRIVE.FILE_RENAMED'), 200);
            }
            $file_extention = explode('.', $file->file_name);
            $file_extention = end($file_extention);

            $check_duplicate_file = AbydeDriveFile::where('file_name', $request->file_name . '.' . $file_extention)->count();
            if ($check_duplicate_file > 0) {
                return $this->error(Config::get('constants.ABYDE_DRIVE.FILE_NAME_DUPLICATE'), 200);
            }
            $old_file = '/abyde_drive/' . $file->location_id . '/' . $file->file_name;
            $new_file = '/abyde_drive/' . $file->location_id . '/' . trim($request->file_name) . '.' . $file_extention;
            if (Storage::disk('s3')->copy($old_file, $new_file)) {
                if (Storage::disk('s3')->exists($old_file)) {
                    Storage::disk('s3')->delete($old_file);
                }
                $file->update([
                    'file_name' => trim($request->file_name) . '.' . $file_extention,
                    'title' => trim($request->file_name),
                ]);

                return $this->success(Config::get('constants.ABYDE_DRIVE.FILE_RENAMED'), 200);
            } else {
                return $this->error(Config::get('constants.ABYDE_DRIVE.FILE_NOT_RENAMED'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/renameFile() => ' . $e->getMessage());
            Log::error('AbydeDriveController/renameFile()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * view file detail
     *
     * @return \Illuminate\Http\Response
     */
    public function viewFileDetail(Request $request)
    {
        $validator_rules = [
            'file_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $file = AbydeDriveFile::with('user')->find($request['file_id']);
            if (! $file) {
                $file = AbydeDriveFile::with('user')->withTrashed()->findOrFail($request['file_id']);
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $file);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/viewFileDetail() => ' . $e->getMessage());
            Log::error('AbydeDriveController/viewFileDetail()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * delete file
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteFile(Request $request)
    {
        $validator_rules = [
            'file_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            if (AbydeDriveFile::where('id', $request->file_id)
                ->get()->each(function ($file) {
                    $file->fileShare()->delete();
                    $file->delete();
                })
            ) {
                return $this->success(Config::get('constants.ABYDE_DRIVE.FILE_DELETED'), 200);
            } else {
                return $this->error(Config::get('constants.ABYDE_DRIVE.FILE_NOT_DELETED'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/deleteFile() => ' . $e->getMessage());
            Log::error('AbydeDriveController/deleteFile()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Download file
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadFile(Request $request)
    {
        $validator_rules = [
            'file_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $file = AbydeDriveFile::find($request->file_id);
            if (! $file) {
                $file = AbydeDriveFile::withTrashed()->findOrFail($request->file_id);
            }
            $download_url = $this->getSignedURL('/abyde_drive/' . $file->location_id . '/' . $file->file_name);

            return $this->success(Config::get('constants.ABYDE_DRIVE.FILE_DOWNLOADED'), 200, ['download_url' => $download_url]);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/downloadFile() => ' . $e->getMessage());
            Log::error('AbydeDriveController/downloadFile()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Move file
     *
     * @return \Illuminate\Http\Response
     */
    public function moveFile(Request $request)
    {
        $validator_rules = [
            'location_id' => 'required',
            'destination_folder_id' => 'nullable',
            'file_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $destination_folder_id = $request->destination_folder_id ? $request->destination_folder_id : null;
            $file = AbydeDriveFile::find($request->file_id);
            if (! $file) {
                $file = AbydeDriveFile::withTrashed()->find($request->file_id);
            }
            if ($file->folder_id == $destination_folder_id) {
                if ($file->deleted_at == null) {
                    return $this->error(Config::get('constants.ABYDE_DRIVE.SAME_FILE'), 200);
                }
            }
            $folderId = $file->folder_id;

            if ($file->update(['folder_id' => $destination_folder_id])) {
                if ($file['deleted_at'] != null) {
                    $file->restore();
                } else {
                    $file->restore();
                    if ($destination_folder_id != null) {
                        $getNearestSharedParentFolderIds = $this->getMultipleLocSharedFolderListData($destination_folder_id);
                        $getNearestSharedParentFolderList = AbydeDriveFolderShare::where([
                            'from_loc_id' => $request->location_id
                        ])->whereIn('abyde_drive_folder_id', $getNearestSharedParentFolderIds)->get();

                        if (!empty($getNearestSharedParentFolderList)) {
                            foreach ($getNearestSharedParentFolderList as $getNearestSharedParentFolder) {
                                AbydeDriveFileShare::where([
                                    'abyde_drive_file_id' => $request->file_id,
                                    'from_loc_id' => $request->location_id,
                                    'to_loc_id' => $getNearestSharedParentFolder->to_loc_id
                                ])->delete();
                            }
                        }
                    } else {
                        $user_data = auth()->user();
                        $check_current_login = auth()->getDefaultDriver();
                        if ($check_current_login == 'user') {
                            $user_id = $user_data->id;
                            $user_type = 'App\Models\User';
                        } elseif ($check_current_login == 'account_user') {
                            $user_id = $user_data->id;
                            $user_type = 'App\Models\AccountUser';
                        }
                        $getNearestSharedParentFolderList = $this->getNearestSharedParentFolderList($folderId);
                        $file_data = [];
                        if (!empty($getNearestSharedParentFolderList)) {
                            foreach ($getNearestSharedParentFolderList as $getNearestSharedParentFolder) {
                                $file_data[] = [
                                    'abyde_drive_file_id' => $request->file_id,
                                    'from_loc_id' => $request->location_id,
                                    'to_loc_id' => $getNearestSharedParentFolder->to_loc_id,
                                    'user_id' => $user_id,
                                    'user_type' => $user_type,
                                    'created_at' => Carbon::now(),
                                    'updated_at' => Carbon::now()
                                ];
                            }
                            $insert_file_data = AbydeDriveFileShare::insert($file_data);
                        }
                    }
                }
                return $this->success(Config::get('constants.ABYDE_DRIVE.FILE_MOVED'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/moveFile() => ' . $e->getMessage());
            Log::error('AbydeDriveController/moveFile()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Fetch multiple Location folder shared location ids list 
     *
     * @return \Illuminate\Http\Response
     */
    private function getMultipleLocSharedFolderListData($folder_id)
    {
        $sharedFolders = [];
        $checkedFolders = [];

        while ($folder_id) {
            $shared_folder = AbydeDriveFolderShare::where(['abyde_drive_folder_id' => $folder_id])->pluck('abyde_drive_folder_id')->toArray();
            if (!empty($shared_folder)) {
                $sharedFolders = array_merge($sharedFolders, $shared_folder);
            }
            $folder = AbydeDriveFolder::select('parent_folder_id')->where(['id' => $folder_id])->first();
            if (!$folder || in_array($folder_id, $checkedFolders)) {
                break;
            }
            $checkedFolders[] = $folder_id;
            $folder_id = $folder->parent_folder_id;
        }

        return array_unique($sharedFolders);
    }

    /**
     * Get list of recent files
     *
     * @return \Illuminate\Http\Response
     */
    public function getRecentFiles(Request $request)
    {
        try {

            $validator_rules = [
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $recent_files = AbydeDriveFile::where('location_id', $request->location_id)
                ->with('user')
                ->withCount('fileShare')
                ->with('fileShare', function ($query) use ($request) {
                    $query->where('from_loc_id', $request->location_id);
                })
                ->limit(10)->orderBy('created_at', 'desc')->orderBy('id', 'desc')->get()
                ->map(function ($file) use ($request) {
                    $file->is_shared = $this->checkParentFileShared(null, $file->id, $request->location_id, 1);
                    return $file;
                });

            return $this->success(Config::get('constants.SUCCESS'), 200, $recent_files);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/getRecentFiles() => ' . $e->getMessage());
            Log::error('AbydeDriveController/getRecentFiles()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Check parent file shared
     *
     * @return \Illuminate\Http\Response
     */
    private function checkParentFileShared($parentFolderId, $fileId, $locationId, $recent_file = 0)
    {
        if ($parentFolderId == null && $recent_file == 0) {
            $isShared = AbydeDriveFileShare::where('abyde_drive_file_id', $fileId)
                ->where(['from_loc_id' => $locationId])
                ->exists();

            if ($isShared) {
                return true;
            } else {
                return false;
            }
        } else {
            $isShared = AbydeDriveFileShare::where('abyde_drive_file_id', $fileId)
                ->where(['from_loc_id' => $locationId])
                ->exists();

            if ($isShared) {
                return true;
            }
            $currentFolder = AbydeDriveFile::where('id', $fileId)
                ->whereNotNull('folder_id')
                ->where(['location_id' => $locationId])
                ->first();
            if ($currentFolder && $currentFolder->folder_id) {
                return $this->checkParentFolderShared($currentFolder->folder_id, $locationId);
            }
            return false;
        }
    }

    /**
     * Get list of files and folders
     *
     * @return \Illuminate\Http\Response
     */
    public function listTrashedDocuments(Request $request)
    {

        $validator_rules = [
            'location_id' => 'required',
            'parent_folder_id' => 'nullable',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }

        $input_fields = $request->all();

        try {
            if (isset($input_fields['parent_folder_id']) && $input_fields['parent_folder_id'] != '') {
                $folders = AbydeDriveFolder::with(['user'])
                    ->onlyTrashed()
                    ->where('location_id', $input_fields['location_id'])
                    ->where('parent_folder_id', $input_fields['parent_folder_id'])
                    ->orderBy('updated_at', 'desc')->get();

                $files = AbydeDriveFile::where('location_id', $input_fields['location_id'])
                    ->with('user')
                    ->onlyTrashed()
                    ->where('folder_id', $input_fields['parent_folder_id'])
                    ->orderBy('updated_at', 'desc')->get();
            } else {
                $folders = AbydeDriveFolder::with(['user'])
                    ->onlyTrashed()
                    ->where('location_id', $input_fields['location_id'])
                    ->where(function ($query) {
                        $query->whereRelation('parentFolders', 'deleted_at', null)
                            ->orWhere('parent_folder_id', null);
                    })
                    ->orderBy('updated_at', 'desc')->get();

                $files = AbydeDriveFile::where('location_id', $input_fields['location_id'])
                    ->with('user')
                    ->onlyTrashed()
                    ->where(function ($query) {
                        $query->whereRelation('folder', 'deleted_at', null)
                            ->orWhere('folder_id', null);
                    })
                    ->orderBy('updated_at', 'desc')->get();
            }

            $data = [
                'folders' => $folders,
                'files' => $files,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/listTrashedDocuments() => ' . $e->getMessage());
            Log::error('AbydeDriveController/listTrashedDocuments()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Get list of archived folder
     *
     * @return \Illuminate\Http\Response
     */
    public function getArchiveFolders(Request $request)
    {

        try {
            $folders = AbydeDriveArchiveFolder::whereNull('parent_folder_id');
            $user_data = $this->getMainAccountDetails();
            if ($user_data->is_educational_account == 0) {
                $folders = $folders->where('folder_name', '!=', 'Students');
            }
            $folders = $folders->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $folders);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/getArchiveFolders() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Get list of documents of archived folder
     *
     * @return \Illuminate\Http\Response
     */
    public function getArchiveDocList(Request $request)
    {

        $validator_rules = [
            'location_id' => 'required',
            'archive_folder_id' => 'required',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }

        try {

            $folders = AbydeDriveArchiveFolder::where(['parent_folder_id' => $request['archive_folder_id']])
                ->whereHas('abydeDriveArchiveFolderLocation', function ($que) use ($request) {
                    $que->where('location_id', $request['location_id']);
                })
                ->orderBy('created_at', 'desc')->get();

            $files = AbydeDriveArchiveFile::orderBy('created_at', 'desc')
                ->whereHas('abydeDriveArchiveFolderLocation', function ($que) use ($request) {
                    $que->where('location_id', $request['location_id'])
                        ->where('archive_folder_id', $request['archive_folder_id']);
                })
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, ['folders' => $folders, 'files' => $files]);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/getArchiveDocList() => ' . $e->getMessage());
            Log::error('AbydeDriveController/getArchiveDocList()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * view archive file detail
     *
     * @return \Illuminate\Http\Response
     */
    public function viewArchiveFileDetail(Request $request)
    {
        $validator_rules = [
            'file_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $file = AbydeDriveArchiveFile::findOrFail($request['file_id']);

            return $this->success(Config::get('constants.SUCCESS'), 200, $file);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/viewArchiveFileDetail() => ' . $e->getMessage());
            Log::error('AbydeDriveController/viewArchiveFileDetail()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Download archive file
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadArchiveFile(Request $request)
    {
        $validator_rules = [
            'file_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $file = AbydeDriveArchiveFile::with('abydeDriveArchiveFolderLocation.abydeDriveArchiveFolder', 'abydeDriveArchiveFolderLocation.location.user')->findOrFail($request->file_id);
            $url = '/abyde_drive_archive/';
            $main_folder_id = $file->abydeDriveArchiveFolderLocation->abydeDriveArchiveFolder->findTopParentId($file->abydeDriveArchiveFolderLocation->abydeDriveArchiveFolder->id);

            if ($main_folder_id != $file->abydeDriveArchiveFolderLocation->abydeDriveArchiveFolder->id) {
                $folder_name = AbydeDriveArchiveFolder::find($main_folder_id)->folder_name;
            } else {
                $folder_name = $file->abydeDriveArchiveFolderLocation->abydeDriveArchiveFolder->folder_name;
            }
            switch ($folder_name) {
                case 'Employees':
                    $url .= 'employees/' . $file->abydeDriveArchiveFolderLocation->location->user->id . '/' . $file->file_name;
                    break;
                case 'Business Associates':
                    $url .= 'business_associates/' . $file->abydeDriveArchiveFolderLocation->location->user->id . '/' . $file->file_name;
                    break;
                case 'HIPAA Logs':
                    if (str_contains($file->title, 'Access_Log')) {
                        $url .= 'access_logs/' . $file->abydeDriveArchiveFolderLocation->location->id;
                    } elseif (str_contains($file->title, 'Active_Asset_Log')) {
                        $url .= 'asset_logs/' . $file->abydeDriveArchiveFolderLocation->location->id . '/active_asset_log';
                    } elseif (str_contains($file->title, 'Inactive_Asset_Log')) {
                        $url .= 'asset_logs/' . $file->abydeDriveArchiveFolderLocation->location->id . '/inactive_asset_log';
                    } else {
                        $url .= 'breach_logs/' . $file->abydeDriveArchiveFolderLocation->location->id;
                    }
                    $url .= '/' . $file->file_name;
                    break;
                case 'Students':
                    $url .= 'students/' . $file->abydeDriveArchiveFolderLocation->location->user->id . '/' . $file->file_name;
                    break;
            }
            $download_url = $this->getSignedURL($url);

            return $this->success(Config::get('constants.ABYDE_DRIVE.FILE_DOWNLOADED'), 200, ['download_url' => $download_url]);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/downloadArchiveFile() => ' . $e->getMessage());
            Log::error('AbydeDriveController/downloadArchiveFile()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Download folder
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadArchiveFolder(Request $request)
    {
        $validator_rules = [
            'folder_id' => 'required',
            'location_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $public_path = public_path();
            if (! is_dir($public_path . '/storage/temp_zip_abyde_drive_archive/' . $request['location_id'])) {
                Storage::disk('public')->makeDirectory('/temp_zip_abyde_drive_archive/' . $request['location_id']);
            }

            $folder = AbydeDriveArchiveFolder::where(['id' => $request['folder_id']])
                ->with(['subFolders'])
                ->orderBy('created_at', 'desc')->get();
            $zip_file_path = '/temp_zip_abyde_drive_archive/' . $request['location_id'] . '/' . $folder[0]->folder_name . '.zip';
            $zip = new \ZipArchive;
            $zip->open($public_path . '/storage' . $zip_file_path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
            $this->addArchiveFoldersToZip($zip, $folder);
            $zip->close();

            return $this->success(Config::get('constants.ABYDE_DRIVE.FOLDER_DOWNLOADED'), 200, ['download_url' => asset('storage' . $zip_file_path)]);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/downloadArchiveFolder() => ' . $e->getMessage());
            Log::error('AbydeDriveController/downloadArchiveFolder()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Add Archive Folder to zip
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addArchiveFoldersToZip($zip, $folders, $dir = '', $level = 1)
    {
        try {
            if (! empty($folders)) {
                foreach ($folders as $folder) {
                    try {
                        $old_dir = $dir;
                        if ($level == 1) {
                            $dir = $folder['folder_name'];
                        } else {
                            $dir = $folder['parent_folder_id'] ? $dir . '/' . $folder['folder_name'] : $folder['folder_name'];
                        }
                        if (isset($folder['abydeDriveArchiveFolderLocation'][0]['abydeDriveArchiveFile']) && count($folder['abydeDriveArchiveFolderLocation'][0]['abydeDriveArchiveFile']) > 0) {
                            $main_folder_id = $folder->findTopParentId($folder->id);

                            if ($main_folder_id != $folder->id) {
                                $folder_name = AbydeDriveArchiveFolder::find($main_folder_id)->folder_name;
                            } else {
                                $folder_name = $folder->folder_name;
                            }
                            foreach ($folder['abydeDriveArchiveFolderLocation'][0]['abydeDriveArchiveFile'] as $file) {
                                try {
                                    $url = '/abyde_drive_archive/';
                                    switch ($folder_name) {
                                        case 'Employees':
                                            $url .= 'employees/' . $folder['abydeDriveArchiveFolderLocation'][0]->location->user->id . '/' . $file->file_name;
                                            break;
                                        case 'Business Associates':
                                            $url .= 'business_associates/' . $folder['abydeDriveArchiveFolderLocation'][0]->location->user->id . '/' . $file->file_name;
                                            break;
                                        case 'HIPAA Logs':
                                            if (str_contains($file->title, 'Access_Log')) {
                                                $url .= 'access_logs/' . $folder['abydeDriveArchiveFolderLocation'][0]->location->id;
                                            } elseif (str_contains($file->title, 'Active_Asset_Log')) {
                                                $url .= 'asset_logs/' . $folder['abydeDriveArchiveFolderLocation'][0]->location->id . '/active_asset_log';
                                            } elseif (str_contains($file->title, 'Inactive_Asset_Log')) {
                                                $url .= 'asset_logs/' . $folder['abydeDriveArchiveFolderLocation'][0]->location->id . '/inactive_asset_log';
                                            } elseif (str_contains($file->title, 'Breach_Log')) {
                                                $url .= 'breach_logs/' . $folder['abydeDriveArchiveFolderLocation'][0]->location->id;
                                            }
                                            $url .= '/' . $file->file_name;
                                            break;
                                        case 'Students':
                                            $url .= 'students/' . $folder['abydeDriveArchiveFolderLocation'][0]->location->user->id . '/' . $file->file_name;
                                            break;
                                    }
                                    $download_file = Storage::disk('s3')->get($url);
                                    if ($download_file != null) {
                                        $zip->addFromString($dir . '/' . $file['file_name'], $download_file);
                                    }
                                } catch (\Exception $e) {
                                    Log::error('AbydeDriveController/addArchiveFoldersToZip()[abydeDriveArchiveFile_error] => ' . $e->getMessage());
                                    Log::error('AbydeDriveController/addArchiveFoldersToZip()[abydeDriveArchiveFile_data] => ' . json_encode($file));
                                }
                            }
                        } else {
                            $zip->addEmptyDir($dir);
                        }
                        if (! empty($folder['subFolders'])) {
                            $this->addArchiveFoldersToZip($zip, $folder['subFolders'], $dir, ++$level);
                        }
                        $dir = $old_dir;
                    } catch (\Exception $e) {
                        Log::error('AbydeDriveController/addArchiveFoldersToZip()[folders_error] => ' . $e->getMessage());
                        Log::error('AbydeDriveController/addArchiveFoldersToZip()[folders_data] => ' . json_encode($folder));
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/addArchiveFoldersToZip() => ' . $e->getMessage());
            Log::error('AbydeDriveController/addArchiveFoldersToZip()[data] => ' . json_encode([$zip, $folders, $dir, $level]));
        }
    }

    /**
     * Get Shared Locations
     *
     * @return \Illuminate\Http\Response
     */
    public function getSharedLocations(Request $request)
    {
        $validator_rules = [
            'from_location_id' => 'required',
            'doc_id' => 'required',
            'doc_type' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $user_id = auth()->user()->id;
            if ($request->doc_type == 'folder') {
                $folder = AbydeDriveFolder::where([
                    'id' => $request->doc_id,
                    'location_id' => $request->from_location_id
                ])->first();
                if ($folder) {
                    $folderIdLists = $this->getParentFolderIdList($folder->id);
                } else {
                    $folderIdLists = [];
                }
                $shared_parent_doc_data = AbydeDriveFolderShare::select('id', 'to_loc_id', 'abyde_drive_folder_id')
                    ->where(['from_loc_id' => $request->from_location_id])
                    ->whereIn('abyde_drive_folder_id', $folderIdLists)
                    ->get()
                    ->map(function ($shared_doc) use ($request) {
                        return $shared_doc->to_loc_id;
                    });

                $shared_current_doc_data = AbydeDriveFolderShare::select('id', 'to_loc_id', 'abyde_drive_folder_id')
                    ->where(['from_loc_id' => $request->from_location_id])
                    ->where('abyde_drive_folder_id', $request->doc_id)
                    ->get()
                    ->map(function ($shared_doc) use ($request) {
                        return $shared_doc->to_loc_id;
                    });
            } else {
                $file = AbydeDriveFile::where([
                    'id' => $request->doc_id,
                    'location_id' => $request->from_location_id,
                ])->first();
                $folderIdLists = $this->getParentFolderIdList($file->folder_id, $request->doc_type);
                $shared_current_doc_data = AbydeDriveFileShare::select('id', 'to_loc_id', 'abyde_drive_file_id')
                    ->where(['from_loc_id' => $request->from_location_id])
                    ->where('abyde_drive_file_id', $request->doc_id)
                    ->get()
                    ->map(function ($shared_doc) use ($request) {
                        return $shared_doc->to_loc_id;
                    });
                $shared_parent_doc_data = AbydeDriveFolderShare::select('id', 'to_loc_id', 'abyde_drive_folder_id')
                    ->where(['from_loc_id' => $request->from_location_id])
                    ->whereIn('abyde_drive_folder_id', $folderIdLists)
                    ->get()
                    ->map(function ($shared_doc) use ($request) {
                        return $shared_doc->to_loc_id;
                    });
            }
            if (!empty(auth()->guard('account_user')->user())) {
                $user_data = auth()->guard('account_user')->user();
                $shared_parent_locations = Location::select('id', 'location_nickname')->whereIn('id', $shared_parent_doc_data)->get();
                $shared_current_locations = Location::select('id', 'location_nickname')->whereIn('id', $shared_current_doc_data)->get();
                $locations_list = Location::select('id', 'location_nickname')->where('user_id', $user_data->user_id)->where('id', '!=', $request->from_location_id)->get();
            }
            if (!empty(auth()->guard('user')->user())) {
                $shared_parent_locations = Location::select('id', 'location_nickname')->where('user_id', $user_id)->whereIn('id', $shared_parent_doc_data)->get();
                $shared_current_locations = Location::select('id', 'location_nickname')->where('user_id', $user_id)->whereIn('id', $shared_current_doc_data)->get();
                $locations_list = Location::select('id', 'location_nickname')->where('user_id', $user_id)->where('id', '!=', $request->from_location_id)->get();
            }
            $unshared_all_locations =  array_merge($shared_parent_locations->toArray(), $shared_current_locations->toArray());
            $lication_list = [
                'shared_parent_locations' => $shared_parent_locations,
                'shared_current_locations' => $shared_current_locations,
                'unshared_all_locations' => $unshared_all_locations,
                'all_locations' => $locations_list,
            ];
            return $this->success(Config::get('constants.SUCCESS'), 200, $lication_list);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/getSharedLocations() => ' . $e->getMessage());
            Log::error('AbydeDriveController/getSharedLocations()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Fetch parent folder shared
     *
     * @return \Illuminate\Http\Response
     */
    private function getParentFolderIdList($docId, $doc_type = "")
    {
        $parentFolderIds = [];
        $folder = AbydeDriveFolder::where('id', $docId)->first();
        if ($doc_type == 'file') {
            $parentFolderIds[] = $docId;
        }
        while ($folder && $folder->parent_folder_id) {
            $parentFolderIds[] = $folder->parent_folder_id;
            $folder = AbydeDriveFolder::where('id', $folder->parent_folder_id)->first();
        }
        return array_unique($parentFolderIds);
    }

    /**
     * Check parent folder shared
     *
     * @return \Illuminate\Http\Response
     */
    public function checkParentFolderShared($folderId, $locationId)
    {
        $isShared = AbydeDriveFolderShare::where('abyde_drive_folder_id', $folderId)
            ->where(['from_loc_id' => $locationId])
            ->exists();

        if ($isShared) {
            return true;
        }

        $currentFolder = AbydeDriveFolder::where('id', $folderId)
            ->where(['location_id' => $locationId])
            ->first();

        if ($currentFolder && $currentFolder->parent_folder_id) {
            return $this->checkParentFolderShared($currentFolder->parent_folder_id, $locationId);
        }
        return false;
    }

    /**
     * fetch Share folder locations 
     *
     * @return \Illuminate\Http\Response
     */
    private function fetchSharedLocationForFolder($from_location_id, $folder_id)
    {
        $shared_locations = AbydeDriveFolderShare::where('from_loc_id', $from_location_id)
            ->where(['abyde_drive_folder_id' => $folder_id])
            ->pluck('to_loc_id');

        if ($shared_locations->isNotEmpty()) {
            return Location::select('id', 'location_nickname')
                ->whereIn('id', $shared_locations)
                ->get();
        } else {

            $parentFolder = AbydeDriveFolder::select('parent_folder_id')
                ->where(['id' => $folder_id])
                ->first();
            if ($parentFolder && $parentFolder->parent_folder_id) {
                return $this->fetchSharedLocationForFolder($from_location_id, $parentFolder->parent_folder_id);
            }
        }
        return [];
    }

    /**
     * Fetch List Of Shared me Documents
     *
     * @return \Illuminate\Http\Response
     */
    public function listSharedMeDocuments(Request $request)
    {

        $validator_rules = [
            'location_id' => 'required',
            'parent_folder_id' => 'nullable',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }

        $input_fields = $request->all();

        try {
            $parent_folder_id = (isset($input_fields['parent_folder_id']) && $input_fields['parent_folder_id'] != '') ? $input_fields['parent_folder_id'] : null;
            if ($parent_folder_id == null) {
                $folders = AbydeDriveFolder::with(['folderShare' => function ($query) use ($input_fields) {
                    $query->where('to_loc_id', $input_fields['location_id']);
                }, 'user'])
                    ->whereHas('folderShare', function ($query) use ($input_fields) {
                        $query->where('to_loc_id', $input_fields['location_id']);
                    })
                    ->orderBy('created_at', 'desc')
                    ->get();
                $files = AbydeDriveFile::with(['fileShare' => function ($query) use ($input_fields) {
                    $query->where('to_loc_id', $input_fields['location_id']);
                }, 'user'])
                    ->whereHas('fileShare', function ($query) use ($input_fields) {
                        $query->where('to_loc_id', $input_fields['location_id']);
                    })
                    ->orderBy('created_at', 'desc')
                    ->get();
            } else {
                $shared_parent = $this->getNearestSharedParentFolder($parent_folder_id);
                if (!$shared_parent) {
                    return $this->error("Access Denied: Folder is not shared.", 200);
                }

                $from_loc_id = $shared_parent->from_loc_id;

                $folders = AbydeDriveFolder::where('parent_folder_id', $parent_folder_id)
                    ->where('location_id', $from_loc_id)
                    ->with('user')
                    ->orderBy('created_at', 'desc')
                    ->get();

                $files = AbydeDriveFile::where('folder_id', $parent_folder_id)
                    ->with(['user'])
                    ->orderBy('created_at', 'desc')
                    ->get();
            }

            $data = [
                'folders' => $folders,
                'files' => $files,
            ];
            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/listSharedMeDocuments() => ' . $e->getMessage());
            Log::error('AbydeDriveController/listSharedMeDocuments()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Check parent folder shared
     *
     * @return \Illuminate\Http\Response
     */
    private function getNearestSharedParentFolder($folder_id)
    {
        while ($folder_id) {
            $shared_folder = AbydeDriveFolderShare::where(['abyde_drive_folder_id' => $folder_id])->with(['fromLocation', 'folder.user'])->first();
            if ($shared_folder) {
                return $shared_folder;
            }
            $folder = AbydeDriveFolder::select('parent_folder_id')->where(['id' => $folder_id])->first();
            $folder_id = $folder ? $folder->parent_folder_id : null;
        }
        return null;
    }

    /**
     * Check parent folder shared
     *
     * @return \Illuminate\Http\Response
     */
    private function getNearestSharedParentFolderList($folder_id)
    {
        while ($folder_id) {
            $shared_folder = AbydeDriveFolderShare::where(['abyde_drive_folder_id' => $folder_id])->get();
            if ($shared_folder->isNotEmpty()) {
                return $shared_folder;
            }
            $folder = AbydeDriveFolder::select('parent_folder_id')->where(['id' => $folder_id])->first();
            $folder_id = $folder ? $folder->parent_folder_id : null;
        }
        return null;
    }


    /**
     * Ftech shared locationlist for folder or file
     *
     * @return \Illuminate\Http\Response
     */
    public function shareDocumentToLocation(Request $request)
    {
        $validator_rules = [
            'from_loc_id' => 'required',
            'doc_id' => 'required',
            'doc_type' => 'required',
            'selected_locations' => 'nullable',
            'removed_selected_locations' => 'nullable'
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }

        try {
            $user_data = auth()->user();
            $input_fields = $request->all();
            $check_current_login = auth()->getDefaultDriver();
            if ($check_current_login == 'user') {
                $user_id = $user_data->id;
                $user_type = 'App\Models\User';
            } elseif ($check_current_login == 'account_user') {
                $user_id = $user_data->id;
                $user_type = 'App\Models\AccountUser';
            }
            if ($input_fields['doc_type'] == 'folder') {
                $checkFolderTree = AbydeDriveFolder::where('id', $input_fields['doc_id'])
                    ->where(['location_id' => $input_fields['from_loc_id']])
                    ->with('subFolders', 'files')
                    ->first();

                $subFolderIds = $this->getSubfolderIds($checkFolderTree);
                $filesIds = $this->getSubfolderFilesIds($checkFolderTree);

                $checkAlreadySharedSubFoldersId = AbydeDriveFolderShare::whereIn('abyde_drive_folder_id', $subFolderIds)
                    ->where('from_loc_id', $input_fields['from_loc_id'])
                    ->whereIn('to_loc_id', $input_fields['selected_locations'])
                    ->pluck('id');
                $checkAlreadySharedSubFoldersFilesId = AbydeDriveFileShare::whereIn('abyde_drive_file_id', $filesIds)
                    ->where('from_loc_id', $input_fields['from_loc_id'])
                    ->whereIn('to_loc_id', $input_fields['selected_locations'])
                    ->pluck('id');

                // Delete already shared sub folders and files  
                AbydeDriveFolderShare::whereIn('id', $checkAlreadySharedSubFoldersId)->delete();
                AbydeDriveFileShare::whereIn('id', $checkAlreadySharedSubFoldersFilesId)->delete();

                $folder_data = [];
                foreach ($input_fields['selected_locations'] as $location) {
                    $folder_data[] = [
                        'abyde_drive_folder_id' => $input_fields['doc_id'],
                        'from_loc_id' => $input_fields['from_loc_id'],
                        'to_loc_id' => $location['location_id'],
                        'user_id' => $user_id,
                        'user_type' => $user_type,
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now()
                    ];
                }

                if (!empty($request->removed_selected_locations)) {
                    foreach ($request->removed_selected_locations as $removed_location) {
                        AbydeDriveFolderShare::where([
                            'abyde_drive_folder_id' => $input_fields['doc_id'],
                            'from_loc_id' => $request->from_loc_id,
                            'to_loc_id' => $removed_location['location_id']
                        ])->delete();
                    }
                }
                $insert_folder_data = AbydeDriveFolderShare::insert($folder_data);
                if ($insert_folder_data) {
                    if ($request->selected_locations) {
                        return $this->success(Config::get('constants.ABYDE_DRIVE.FOLDER_SHARED'), 200, $folder_data);
                    }
                    if ($request->removed_selected_locations) {
                        return $this->success(Config::get('constants.ABYDE_DRIVE.FOLDER_UNSHARED'), 200, $folder_data);
                    }
                } else {
                    return $this->error(Config::get('constants.ABYDE_DRIVE.FOLDER_NOT_SHARED'), 200);
                }
            } else if ($input_fields['doc_type'] == 'file') {
                $file_data = [];
                foreach ($input_fields['selected_locations'] as $location) {
                    $file_data[] = [
                        'abyde_drive_file_id' => $input_fields['doc_id'],
                        'from_loc_id' => $input_fields['from_loc_id'],
                        'to_loc_id' => $location['location_id'],
                        'user_id' => $user_id,
                        'user_type' => $user_type,
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now()
                    ];
                }
                if (!empty($request->removed_selected_locations)) {
                    foreach ($request->removed_selected_locations as $removed_location) {
                        AbydeDriveFileShare::where([
                            'abyde_drive_file_id' => $input_fields['doc_id'],
                            'from_loc_id' => $request->from_loc_id,
                            'to_loc_id' => $removed_location['location_id']
                        ])->delete();
                    }
                }

                $insert_file_data = AbydeDriveFileShare::insert($file_data);
                if ($insert_file_data) {
                    if ($request->selected_locations) {
                        return $this->success(Config::get('constants.ABYDE_DRIVE.FILE_SHARED'), 200, $file_data);
                    }
                    if ($request->removed_selected_locations) {
                        return $this->success(Config::get('constants.ABYDE_DRIVE.FILE_UNSHARED'), 200, $file_data);
                    }
                } else {
                    return $this->error(Config::get('constants.ABYDE_DRIVE.FILE_NOT_SHARED'), 200);
                }
            }
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/shareDocLocation() => ' . $e->getMessage());
            Log::error('AbydeDriveController/shareDocLocation()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * view shared folder detail
     *
     * @return \Illuminate\Http\Response
     */
    public function viewSharedFolderDetail(Request $request)
    {
        $validator_rules = [
            'folder_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {

            $folder = AbydeDriveFolderShare::where(['abyde_drive_folder_id' => $request->folder_id])->with([
                'fromLocation',
                'folder.user'
            ])->first();

            if (! $folder) {
                $folder = $this->getNearestSharedParentFolder($request->folder_id);
            }

            if ($folder->user_type == 'App\Models\User') {
                $sharedBy = User::find($folder->user_id);
            } elseif ($folder->user_type == 'App\Models\AccountUser') {
                $sharedBy = AccountUser::find($folder->user_id);
            }
            $folder['shared_by'] = $sharedBy;

            return $this->success(Config::get('constants.SUCCESS'), 200, $folder);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/viewSharedFolderDetail() => ' . $e->getMessage());
            Log::error('AbydeDriveController/viewSharedFolderDetail()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * view shared file detail
     *
     * @return \Illuminate\Http\Response
     */
    public function viewSharedFileDetail(Request $request)
    {
        $validator_rules = [
            'file_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $file = AbydeDriveFileShare::where(['abyde_drive_file_id' => $request['file_id']])->with([
                'fromLocation',
                'file.user'
            ])->first();
            if (! $file) {
                $fileData = AbydeDriveFile::where(['id' => $request['file_id']])->first();
                $file = $this->getNearestSharedParentFolder($fileData->folder_id);
                $file['file'] = $fileData;
            }


            if ($file->user_type == 'App\Models\User') {
                $sharedBy = User::select('id', 'first_name', 'last_name')->find($file->user_id);
            } elseif ($file->user_type == 'App\Models\AccountUser') {
                $sharedBy = AccountUser::select('id', 'first_name', 'last_name')->find($file->user_id);
            }
            $file['shared_by'] = $sharedBy;

            return $this->success(Config::get('constants.SUCCESS'), 200, $file);
        } catch (\Exception $e) {
            Log::error('AbydeDriveController/viewSharedFileDetail() => ' . $e->getMessage());
            Log::error('AbydeDriveController/viewSharedFileDetail()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Fetch sub folder Ids
     *
     * @return \Illuminate\Http\Response
     */
    private function getSubfolderIds($folder)
    {
        $subFolderIds = [];
        if ($folder != null) {
            foreach ($folder->subFolders as $subFolder) {
                $subFolderIds[] = $subFolder->id;
                $subFolderIds = array_merge($subFolderIds, $this->getSubfolderIds($subFolder));
            }
        }
        return $subFolderIds;
    }

    /**
     * Fetch sub folder from file
     *
     * @return \Illuminate\Http\Response
     */
    public function getSubfolderFilesIds($subFolder)
    {
        $fileIds = [];
        if ($subFolder->files->isNotEmpty()) {
            foreach ($subFolder->files as $file) {
                $fileIds[] = $file->id;
            }
        }
        if ($subFolder->subFolders->isNotEmpty()) {
            foreach ($subFolder->subFolders as $folder) {
                $fileIds = array_merge($fileIds, $this->getSubfolderFilesIds($folder));
            }
        }
        return $fileIds;
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
