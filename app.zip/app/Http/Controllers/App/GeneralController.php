<?php

namespace App\Http\Controllers\App;

use App\Exports\ExportAccountLocation;
use App\Exports\ExportComplianceBadgeReport;
use App\Exports\ExportUserLocationTraining;
use App\Http\Controllers\Controller;
use App\Models\AccountUserLocationAccess;
use App\Models\BusinessAssociates;
use App\Models\ContactUsRequests;
use App\Models\DownloadLog;
use App\Models\EmailLog;
use App\Models\EmailTemplate;
use App\Models\Employee;
use App\Models\Location;
use App\Models\LocationNotification;
use App\Models\State;
use App\Models\User;
use App\Traits\ApiResponser;
use App\Traits\FileUpload;
use App\Traits\GetLoginUserData;
use App\Traits\GetMainUserData;
use App\Traits\SendMail;
use App\Traits\SyncLocationDataWithSalesForce;
use Aws\SesV2\SesV2Client;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;
use Maatwebsite\Excel\Facades\Excel;

class GeneralController extends Controller
{
    use ApiResponser, FileUpload, GetLoginUserData, GetMainUserData, SendMail, SyncLocationDataWithSalesForce;

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get all assigned locations list
     *
     * @return \Illuminate\Http\Response
     */
    public function assignedLocationList(Request $request)
    {
        try {
            $list = Location::whereIn('id', $this->getAssingedLocationList())
                ->select(['id', 'location_nickname', 'created_at'])
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('GeneralController/assignedLocationList() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get assigned location open noti count
     *
     * @return \Illuminate\Http\Response
     */
    public function getAssignedLocationOpenNoticount(Request $request)
    {
        try {
            $user_data = $this->getLoginUserData();
            if ($user_data['user_type'] == 'USER') {
                $user_data['user_type'] = 'User';
            }
            $count = LocationNotification::whereIn('location_id', $this->getAssingedLocationList())
                ->where('is_completed', 0)
                ->whereHas('notification.userNotification', function ($query) use ($user_data) {
                    $query->where('user_type', $user_data['user_type']);
                })
                ->count();

            return $this->success(Config::get('constants.SUCCESS'), 200, ['total_open_notifications' => $count]);
        } catch (\Exception $e) {
            Log::error('GeneralController/getAssignedLocationOpenNoticount() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get all locations list
     *
     * @return \Illuminate\Http\Response
     */
    public function allLocationList(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $list = Location::where('user_id', $user_data['id'])
                ->select(['id', 'location_nickname'])
                ->orderBy('location_nickname')
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('GeneralController/allLocationList() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get employee module location list
     *
     * @return \Illuminate\Http\Response
     */
    public function employeeModuleLocationList(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $location_access_list = $this->getAssingedLocationList();
            $list = Location::where('user_id', $user_data['id'])
                ->select(['id', 'location_nickname'])
                ->whereHas('hipaaComplianceOfficer')
                ->whereIn('id', $location_access_list)
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('GeneralController/employeeModuleLocationList() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get business associates module location list
     *
     * @return \Illuminate\Http\Response
     */
    public function businessAssociatesModuleLocationList(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $location_access_list = $this->getAssingedLocationList();
            $list = Location::where('user_id', $user_data['id'])
                ->select(['id', 'location_nickname'])
                ->whereHas('disasterRecoveryPlanModuleCompleted')
                ->whereHas('hipaaComplianceOfficer')
                ->whereHas('companyModuleCompleted')
                ->whereHas('sraModuleCompleted')
                ->whereIn('id', $location_access_list)
                ->where(function ($query) {
                    $query->whereHas('employeePrimaryWorkLocation')->orWhereHas('employeeSecondaryWorkLocation');
                })
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('GeneralController/businessAssociatesModuleLocationList() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get assigned location list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getAssingedLocationList()
    {
        if (! empty(auth()->guard('user')->user())) {
            $user_data = auth()->guard('user')->user();
            $location_access_list = Location::where('user_id', $user_data['id'])
                ->select(['id'])
                ->get()->toArray();
        }
        if (! empty(auth()->guard('account_user')->user())) {
            $user_data = auth()->guard('account_user')->user();
            $location_access_list = AccountUserLocationAccess::where('account_user_id', $user_data['id'])->select(['location_id'])->get()->toArray();
        }

        return $location_access_list;
    }

    /**
     * List all states
     *
     * @return \Illuminate\Http\Response
     */
    public function listStates(Request $request)
    {
        try {
            $list = State::select(['id', 'state_code', 'state_name'])->orderBy('state_name')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('GeneralController/listStates() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * get all employees list
     *
     * @return \Illuminate\Http\Response
     */
    public function getEmployeeListByLocationId(Request $request)
    {
        $validator_rules = [
            'location_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }

        try {
            $user_data = $this->getMainAccountDetails();
            $list = Employee::where('user_id', $user_data['id'])
                ->select(['id', 'first_name', 'last_name'])
                ->where('primary_work_location_id', $request['location_id'])
                ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($request) {
                    return $query->where('location_id', $request['location_id']);
                })
                ->orderBy('created_at', 'desc')
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('GeneralController/getEmployeeListByLocationId() => ' . $e->getMessage());
            Log::error('GeneralController/getEmployeeListByLocationId()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get login user data
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public static function getLoggedUserData()
    {
        return $user_data = self::getLoginUserData();
    }

    /**
     * get pco user data
     *
     * @param  \Illuminate\Http\Request  $reqest
     * @return \Illuminate\Http\Response
     */
    public function getMainUserdata()
    {
        try {
            $user_data = $this->getMainAccountDetails();

            return $this->success(Config::get('constants.SUCCESS'), 200, $user_data);
        } catch (\Exception $e) {
            Log::error('GeneralController/getMainUserdata() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Add and remove company logo to cover page
     */
    public function _addCompanyLogoOnCoverPage($location)
    {
        $public_path = public_path();
        $storage_path = storage_path('app/public');
        $temp_file_path = '';
        if ($location->logo != '') {
            $company_logo_image_s3 = Storage::disk('s3')->get('/company_logo/' . $location->user_id . '/' . $location->id . '/original/' . $location->logo);
            $temp_file_name_ext = pathinfo($location->logo, PATHINFO_EXTENSION);
            $temp_file_name = $location->id . '_' . time() . '.' . $temp_file_name_ext;
            $temp_file_path = $storage_path . '/generatedpolicydocuments/' . $temp_file_name;
            \Image::make($company_logo_image_s3)->save($temp_file_path);
        } else {
            $temp_file_path = $public_path . '/policydocuments/blank_company_logo.png';
        }
        $company_logo_data = [
            'path' => $temp_file_path,
            'width' => 350,
            'height' => 130,
            'ratio' => true,
        ];

        return ['company_logo_data' => $company_logo_data, 'temp_file_path' => $temp_file_path];
    }

    public function _removeTempCompanyLogo($location, $temp_file_path)
    {
        if ($location->logo != '') {
            if (file_exists($temp_file_path)) {
                unlink($temp_file_path);
            }
        }
    }
    /*
     * get BA list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function getBAList(Request $request)
    {
        $validator_rules = [
            'location_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }

        try {
            $user_data = $this->getMainAccountDetails();
            $business_associates = BusinessAssociates::where('user_id', $user_data['id'])
                ->whereHas('businessAssociatesLocation', function ($query) use ($request) {
                    $query->where('location_id', $request->location_id);
                })
                ->select(['id', 'name'])
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $business_associates);
        } catch (\Exception $e) {
            Log::error('GeneralController/getBAList() => ' . $e->getMessage());
            Log::error('GeneralController/getBAList()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    /*
     * wordpress contact us action
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function wordpressContactus(Request $request)
    {
        try {
            $validator_rules = [
                'vFirstName' => 'required',
                'vLastName' => 'required',
                'vCompanyName' => 'required',
                'vPhoneno' => 'required',
                'vEmail' => 'required',
                // 'vState' => 'required',
                // 'vMessage' => 'required',
                'eContactMethod' => 'required|in:Phone,Email',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $recaptcha_response = $_POST['g-recaptcha-response'];
            $recaptcha = file_get_contents(Config::get('app.google_recaptcha_url') . '?secret=' . Config::get('app.google_recaptcha_secret') . '&response=' . $recaptcha_response);
            $recaptcha = json_decode($recaptcha);
            if ($recaptcha->success == true && $recaptcha->score >= 0.5 && $recaptcha->action == 'submit') {
                $state = State::where('state_name', $request->vState)->first();
                ContactUsRequests::create([
                    'first_name' => $request->vFirstName,
                    'last_name' => $request->vLastName,
                    'company_name' => $request->vCompanyName,
                    'phone_no' => $request->vPhoneno,
                    'email' => $request->vEmail,
                    'state_id' => ($state) ? $state->id : null,
                    'message' => ($request->vMessage) ? $request->vMessage : null,
                    'contact_method' => strtolower($request->eContactMethod),
                ]);
                // send HCE-UE48
                $emailTemplate = EmailTemplate::where('code', 'HCE-UE48')->first();
                $email_vars = [
                    '{%FIRST_NAME%}' => $request->vFirstName,
                    '{%HIPAA_CHALLANGE%}' => Config::get('app.url') . '/hipaachallenge',
                    '{%OSHA_CHALLANGE%}' => Config::get('app.osha_hc_url') . '/oshachallenge',
                    '{%VIDEOS%}' => url('https://www.youtube.com/@abydehipaasolution9394/videos'),
                    '{%SUPPORT_PHONE%}' => Config::get('app.support_phone_number'),
                    '{%SUPPORT_PHONE_NUMBER_DISPLAY%}' => Config::get('app.support_phone_number_display'),
                ];
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                $this->sendEmail($emailTemplate->code, $html, $request->vEmail, Config::get('app.from_user_email'), $emailTemplate->subject);
                // send HCE-AE18
                $emailTemplate = EmailTemplate::where('code', 'HCE-AE18')->first();
                $email_vars = [
                    '{%CONTACT_US_FORM_FULL_NAME%}' => $request->vFirstName . ' ' . $request->vLastName,
                    '{%CONTACT_US_FORM_COMPANY_NAME%}' => $request->vCompanyName,
                    '{%CONTACT_US_FORM_EMAIL%}' => $request->vEmail,
                    '{%CONTACT_US_FORM_PHONE%}' => $request->vPhoneno,
                    '{%CONTACT_US_FORM_STATE%}' => ($state) ? $state->state_name : '',
                    '{%CONTACT_US_FORM_MESSAGE%}' => ($request->vMessage) ? $request->vMessage : '',
                    '{%CONTACT_US_FORM_CONTACT_METHOD%}' => $request->eContactMethod,
                ];
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                $this->sendEmail($emailTemplate->code, $html, [Config::get('app.cs_group_email'), Config::get('app.salesadmin_group_email'), Config::get('app.marketing_group_email')], Config::get('app.from_admin_email'), $emailTemplate->subject);

                return $this->success(Config::get('constants.CONTACT_US_SUCCESS'), 200);
            } else {
                return $this->error(Config::get('constants.CONTACT_US_FAILED'), 200);
            }
        } catch (\Exception $e) {
            Log::error('GeneralController/wordpressContactus() => ' . $e->getMessage());
            Log::error('GeneralController/wordpressContactus()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.CONTACT_US_FAILED'), 200);
        }
    }

    /**
     * get sign url
     *
     * @param  \Illuminate\Http\Request  $reqest
     * @return \Illuminate\Http\Response
     */
    public function getSignUrl(Request $request)
    {
        $validator_rules = [
            'file_path' => 'required',
            'file_exp_time' => 'sometimes',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }

        try {
            $sign_url = $this->getSignedURL($request->file_path, $request->file_exp_time);

            return $this->success(Config::get('constants.SUCCESS'), 200, $sign_url);
        } catch (\Exception $e) {
            Log::error('GeneralController/getSignUrl() => ' . $e->getMessage());
            Log::error('GeneralController/getSignUrl()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get student module location list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function studentModuleLocationList()
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $list = Location::where('user_id', $user_data['id'])
                ->select(['id', 'location_nickname'])
                ->whereHas('hipaaComplianceOfficer')
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('GeneralController/studentModuleLocationList() => ' . $e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get access location list for student
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getStudentAccessLocationList()
    {
        $user_data = $this->getMainAccountDetails();
        $location_access_list = Location::where('user_id', $user_data['id'])
            ->select(['id'])
            ->whereHas('hipaaComplianceOfficer')
            ->get()->toArray();

        return $location_access_list;
    }

    public function closeTab()
    {
        return view('app.pages.closetab');
    }

    public function showDeleteSuppressedDestinationPage()
    {
        return view('app.pages.delete_suppressed_email');
    }

    public function deleteSuppressedDestination(Request $request)
    {

        try {
            $client = new SesV2Client([
                'region' => Config::get('services.ses.region'), // Replace with your AWS region
                'version' => 'latest',
                'credentials' => [
                    'key' => Config::get('services.ses.key'),
                    'secret' => Config::get('services.ses.secret'),
                ],
            ]);

            $result = $client->deleteSuppressedDestination([
                'EmailAddress' => $request->email,
            ]);

            return $this->success("$request->email is successfully removed from suppression list", 200);
        } catch (\Aws\Exception\AwsException $e) {
            Log::error('Error removing email from suppression list: ' . $e->getAwsErrorMessage());
            Log::error('GeneralController/deleteSuppressedDestination()[data] => ' . json_encode($request->all()));

            return $this->error($e->getAwsErrorMessage(), 200);
        } catch (Exception $e) {
            Log::error('Error removing email from suppression list: ' . $e->getMessage());
            Log::error('GeneralController/deleteSuppressedDestination()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * sync with sales force
     *
     * @return \Illuminate\Http\Response
     */
    public function routeSyncLocationDataWithSalesForce()
    {

        $location_list = Location::whereNotNull('salesforce_unique_id')
            ->with([
                'user' => function ($query) {
                    $query->where('is_active', '1');
                }
            ])
            ->whereHas('user', function ($query) {
                $query->where('is_active', '1');
            })
            ->orderBy('id', 'asc')
            ->skip(0)
            ->take(100)
            ->get();
        foreach ($location_list as $location) {
            $this->SyncLocationDataWithSalesForce($location['id']);
            Log::info('sync data of location => ' . $location['id']);
        }
    }

    /**
     * Check Email Already Signup
     *
     * @return \Illuminate\Http\Response
     */
    public function checkStripeCustomerAlreadySignupForChargebeeMigration(Request $request)
    {
        $validator_rules = [
            'stripe_customer_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $user = User::where('stripe_customer_id', $request->stripe_customer_id)->first();
            return $this->success(Config::get('constants.SUCCESS'), 200, $user);
        } catch (\Exception $e) {
            Log::error('AuthController/checkStripeCustomerAlreadySignupForChargebeeMigration() => ' . $e->getMessage());
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
