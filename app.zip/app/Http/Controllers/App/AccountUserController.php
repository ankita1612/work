<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Imports\AccountUsersImport;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AccountUser;
use App\Models\AccountUserLocationAccess;
use App\Models\EmailTemplate;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\LocationNotification;
use App\Models\Partner;
use App\Models\User;
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Models\Customer;
use App\Models\RiskAnalysisContributorQuestion;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use App\Traits\Notification;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\HeadingRowImport;
use Stripe;

class AccountUserController extends Controller
{
    use ApiResponser, CheckAccessRight, GeneratePolicy, GetMainUserData, Notification, SendMail;

    /**
     * Account user page
     *
     * @return \Illuminate\Http\Response
     */
    public function showAccountUser()
    {
        if ($this->checkAccessRight('account_user')) {
            return view('app.pages.accountuser');
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get all users list
     *
     * @return \Illuminate\Http\Response
     */
    public function allUserList(Request $request)
    {
        try {
            $validator_rules = [
                'filter_by_access_level' => 'sometimes|nullable|in:hipaa_compliance_officer,standard',
                'filter_by_location' => 'sometimes|nullable|array',
                'sort_by' => 'sometimes|nullable|in:first_name,last_name,email',
                'sort_by_dir' => 'sometimes|nullable|in:ASC,DESC',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $limit = $request->has('per_page') ? request('per_page') : Config::get('constants.PER_PAGE');
            $user_data = $this->getMainAccountDetails();
            $user = User::where('id', $user_data['id'])
                ->with(['hipaaComplianceOfficer', 'hipaaComplianceOfficer.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }])->first();
            $account_user = AccountUser::where('user_id', $user_data['id'])
                ->with(['accountLocationAccess', 'accountLocationAccess.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }, 'hipaaComplianceOfficer', 'hipaaComplianceOfficer.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }]);
            $input_fields = $request->all();
            if (isset($input_fields['search_query']) && $input_fields['search_query'] != '') {
                $account_user = $account_user->where(function ($que) use ($input_fields) {
                    return $que->whereRaw('concat(first_name, " ", last_name) like "%'.$input_fields['search_query'].'%" ')
                        ->orWhereRaw('concat(last_name, " ", first_name) like "%'.$input_fields['search_query'].'%" ')
                        ->orWhere('email', 'LIKE', '%'.$input_fields['search_query'].'%');
                });
            }
            if (isset($input_fields['filter_by_access_level']) && $input_fields['filter_by_access_level'] != '') {
                if ($input_fields['filter_by_access_level'] == 'hipaa_compliance_officer') {
                    $account_user = $account_user->has('hipaaComplianceOfficer');
                } else {
                    $account_user = $account_user->doesnthave('hipaaComplianceOfficer');
                }
            }
            if (isset($input_fields['filter_by_location']) && ! empty($input_fields['filter_by_location'])) {
                $account_user->whereHas('accountLocationAccess', function ($que) use ($input_fields) {
                    return $que->whereIn('location_id', $input_fields['filter_by_location']);
                });
            }
            if (isset($input_fields['sort_by']) && ! empty($input_fields['sort_by']) && isset($input_fields['sort_by_dir']) && ! empty($input_fields['sort_by_dir'])) {
                $employee = $account_user->orderBy($input_fields['sort_by'], $input_fields['sort_by_dir'])->orderBy('id', $input_fields['sort_by_dir']);
            } else {
                $employee = $account_user->orderBy('id', 'DESC');
            }

            $account_user = $account_user->paginate($limit);
            $location_list_count = Location::where('user_id', $user_data['id'])
                ->select(['id', 'location_nickname'])
                ->count();

            //fetch total questions whose status is 'pending','review' location wise
            $account_user->map(function ($item)  {
                foreach($item->accountLocationAccess as $key=>$acc_user)
                {
                    $item->accountLocationAccess[$key]->contrinutor_questions_count  = RiskAnalysisContributorQuestion::where(['contributor_user_acntuser_type' => \App\Models\AccountUser::class,'contributor_user_acntuser_id'=> $acc_user->account_user_id,'location_id' => $acc_user->location_id])
                        ->whereIn('status' ,['Pending','Reviewed'])               
                        ->count();   
                }
                return $item;
            });   
            //end
            $data = [
                'primary_user' => $user,
                'account_user_list' => $account_user,
                'sample_import_doc' => ($location_list_count == 1) ? url('/sample_docs/account_user_template_std.xlsx') : url('/sample_docs/account_user_template_ent.xlsx'),
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('AccountUserController/allUserList() => '.$e->getMessage());   
            Log::error('AccountUserController/allUserList()[data] => '.json_encode($request->all()));         
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * check HCO already assigned
     *
     * @return \Illuminate\Http\Response
     */
    public function checkHCOAlreadyAssigned(Request $request, $location_id, $user_id = '', $user_type = '')
    {
        try {
            if ($location_id == '') {
                dd('Invalid parmas');
            }
            if ($user_id && $user_type) {
                $is_avail = HipaaComplianceOfficer::where('location_id', $location_id)->where(function ($query) use ($user_id, $user_type) {
                    $query->where('hco_id', '!=', $user_id)
                        ->orWhere('hco_type', '!=', ($user_type == 'user') ? \App\Models\User::class : \App\Models\AccountUser::class);
                })->count();
            } else {
                $is_avail = HipaaComplianceOfficer::where('location_id', $location_id)->count();
            }
            if ($is_avail > 0) {
                return $this->success(Config::get('constants.SUCCESS'), 200);
            } else {
                return $this->error(Config::get('constants.ERROR'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AccountUserController/checkHCOAlreadyAssigned() => '.$e->getMessage());
            Log::error('AccountUserController/checkHCOAlreadyAssigned()[data] => '.json_encode([$location_id, $user_id, $user_type]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Edit primary user
     *
     * @return \Illuminate\Http\Response
     */
    public function editPrimaryUser(Request $request)
    {
        try {
            $input_fields = $request->all();
            $validator_rules = [
                'user_id' => 'required',
                'first_name' => 'required',
                'last_name' => 'required',
                'phone_number' => 'required',
                'email' => 'required|email',
                'hco_location_new' => 'sometimes|array',
                'hco_location_removed' => 'sometimes|array',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $training_controller = new TrainingController;
            $user = User::with('hipaaComplianceOfficer', 'reseller')->findOrFail($input_fields['user_id']);
            if ($input_fields['first_name'] != $user['first_name'] || $input_fields['last_name'] != $user['last_name']) {
                foreach ($user->hipaaComplianceOfficer as $hipaaComplianceOfficer) {
                    // add policy, procedure, form versioning
                    $policy_array = ['DRP', 'SPP', 'ETP', 'HNEP', 'PMP', 'PCFP', 'SAP', 'SATP', 'SRA'];
                    foreach ($policy_array as $policy) {
                        $this->addPolicyVersionData($policy, $hipaaComplianceOfficer['location_id']);
                    }
                }
            }
            if ($request->has('hco_location_removed')) {
                foreach ($input_fields['hco_location_removed'] as $removed_location) {
                    // add policy, procedure, form versioning
                    $policy_array = ['DRP', 'SPP', 'ETP', 'HNEP', 'PMP', 'PCFP', 'SAP', 'SATP', 'SRA'];
                    foreach ($policy_array as $policy) {
                        $this->addPolicyVersionData($policy, $removed_location['location_id']);
                    }
                    $training_controller->moveTrainingToArchive($removed_location['location_id']);
                }
            }

            if ($request->has('hco_location_new')) {
                foreach ($input_fields['hco_location_new'] as $new_location) {
                    // add policy, procedure, form versioning
                    $policy_array = ['DRP', 'SPP', 'ETP', 'HNEP', 'PMP', 'PCFP', 'SAP', 'SATP', 'SRA'];
                    foreach ($policy_array as $policy) {
                        $this->addPolicyVersionData($policy, $new_location['location_id']);
                    }
                }
            }

            $old_first_name = $user->first_name;
            $old_last_name = $user->last_name;
            $old_email = $user->email;
            $old_phone_number = $user->phone_number;
            $user->update($input_fields);

            if ($request->has('is_hipaa_compliance_officer') && $request['is_hipaa_compliance_officer'] == 0) {
                $user->hipaaComplianceOfficer()->delete();
            } else {
                if ($request->has('hco_location_removed')) {
                    HipaaComplianceOfficer::whereIn('location_id', $input_fields['hco_location_removed'])->delete();
                }

                if (isset($input_fields['hco_location_new'])) {
                    $emailTemplate_admin_HCE_AE15 = EmailTemplate::where('code', 'HCE-AE15')->first();
                    foreach ($input_fields['hco_location_new'] as $data) {
                        try {
                            $old_hco_data = HipaaComplianceOfficer::where('location_id', $data['location_id'])->first();
                            if ($old_hco_data && $user && ($old_hco_data->hco_id != $user->id || $old_hco_data->hco_type != \App\Models\User::class)) {
                                $location = Location::findOrFail($data['location_id']);
                                // Send HCE-AE15
                                $email_vars_admin = [
                                    '{%HCO_NAME%}' => $user->first_name.' '.$user->last_name,
                                    '{%HCO_EMAIL%}' => $user->email,
                                    '{%COMPANY_NAME%}' => $location->company_name,
                                    '{%LOCATION_NAME%}' => $location->location_nickname,
                                    '{%PREVIOUS_HCO_NAME%}' => $old_first_name.' '.$old_last_name,
                                ];
                                $email_vars_admin['{%USER_NAME%}'] = 'Admin';
                                $html_admin = str_ireplace(array_keys($email_vars_admin), array_values($email_vars_admin), $emailTemplate_admin_HCE_AE15->body);

                                if ($user->partner_reseller_id != null) {
                                    $email_subject = [
                                        '{%RESELLER%}' => $user->reseller->name,
                                        '{%LOCATION_NAME%}' => $location->location_nickname,
                                    ];
                                    $admin_subject = str_ireplace(array_keys($email_subject), array_values($email_subject), $emailTemplate_admin_HCE_AE15->reseller_subject);
                                } else {
                                    $admin_subject = str_ireplace(['{%LOCATION_NAME%}'], [$location->location_nickname], $emailTemplate_admin_HCE_AE15->subject);
                                }
                                $this->sendEmail($emailTemplate_admin_HCE_AE15->code, $html_admin, Config::get('app.cs_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user->partner_reseller_id != null ? $user->reseller->logo : null));

                                //send mail to partner start
                                if ($user->partner_reseller_id != null && $user->reseller->email != '') {
                                    $this->sendEmail($emailTemplate_admin_HCE_AE15->code, $html_admin, $user->reseller->email, Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user->partner_reseller_id != null ? $user->reseller->logo : null));
                                }
                                //send mail to partner end
                            }
                        } catch (\Exception $e) {
                            Log::error('AccountUserController/editPrimaryUser()[hco_location_new_error] => '.$e->getMessage());
                            Log::error('AccountUserController/editPrimaryUser()[hco_location_new_data] => '.json_encode($data));
                        }
                    }
                    HipaaComplianceOfficer::whereIn('location_id', $input_fields['hco_location_new'])->delete();
                    $user['hipaa_compliance_officer'] = $user->hipaaComplianceOfficer()->createMany($input_fields['hco_location_new']);
                    $emailTemplate_HCE_UE47 = EmailTemplate::where('code', 'HCE-UE47')->first();
                    $notification_HCE_AN2 = $this->getNotificationByCode('HCE-AN2');
                    $notification_HCE_AN3 = $this->getNotificationByCode('HCE-AN3');
                    $notification_HCE_AN5 = $this->getNotificationByCode('HCE-AN5');
                    $notification_HCE_AN39 = $this->getNotificationByCode('HCE-AN39');
                    foreach ($input_fields['hco_location_new'] as $data) {
                        try {
                            // $training_controller->addTrainingToLocation($data['location_id']);
                            $user_data = $this->getMainAccountDetails();
                            $location = Location::findOrFail($data['location_id']);
                            $new_hco_data = HipaaComplianceOfficer::where('location_id', $data['location_id'])->with('hco')->first();
                            $email_send_user_list[] = ['first_name' => $user_data->first_name, 'email' => $user_data->email];
                            if ($user_data->email != $new_hco_data->hco->email) {
                                $email_send_user_list[] = ['first_name' => $new_hco_data->hco->first_name, 'email' => $new_hco_data->hco->email];
                            }
                            //Add in unassigned Training
                            $training_controller->addToUnassignedTraining($data['location_id'], $user['id'], \App\Models\User::class);
                            // Notification HCE-AN3
                            if ($this->checkNotificationAlreadyAdded($notification_HCE_AN3->code, $data['location_id']) == 0) {
                                $notification_HCE_AN3_data = [
                                    'location_id' => $data['location_id'],
                                    'notification_id' => $notification_HCE_AN3['id'],
                                ];
                                $this->createNotification($notification_HCE_AN3_data);
                            }
                            // Notification HCE-AN5
                            if ($this->checkNotificationAlreadyAdded($notification_HCE_AN5->code, $data['location_id']) == 0 && $user_data->is_sra_user == 0) {
                                $notification_HCE_AN5_data = [
                                    'location_id' => $data['location_id'],
                                    'notification_id' => $notification_HCE_AN5['id'],
                                ];
                                $this->createNotification($notification_HCE_AN5_data);
                            }
                            if ($user_data['is_educational_account'] == 1) {
                                // Notification HCE-AN39
                                if ($this->checkNotificationAlreadyAdded($notification_HCE_AN39->code, $data['location_id']) == 0) {
                                    $notification_HCE_AN39_data = [
                                        'location_id' => $data['location_id'],
                                        'notification_id' => $notification_HCE_AN39['id'],
                                    ];
                                    $this->createNotification($notification_HCE_AN39_data);
                                    foreach ($email_send_user_list as $key => $value) {
                                        // send HCE-UE47
                                        $email_vars = [
                                            '{%FIRST_NAME%}' => $value['first_name'],
                                            '{%LOG_IN_TO_ABYDE%}' => Config::get('app.url'),
                                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                        ];
                                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate_HCE_UE47->body);
                                        $html_subject = str_ireplace(['{%LOCATION_NAME%}'], [$location->location_nickname], $emailTemplate_HCE_UE47->subject);
                                        $this->sendEmail($emailTemplate_HCE_UE47->code, $html, $value['email'], Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                                    }
                                }
                            }
                            // Notification HCE-AN2
                            LocationNotification::where('notification_id', $notification_HCE_AN2->id)
                                ->where('location_id', $data['location_id'])
                                ->where('is_completed', 0)
                                ->update(['is_completed' => 1]);
                        } catch (\Exception $e) {
                        Log::error('AccountUserController/editPrimaryUser()[hco_location_new_error] => '.$e->getMessage());
                        Log::error('AccountUserController/editPrimaryUser()[hco_location_new_data] => '.json_encode($data));
                    }
                    }
                }
            }
            if ($old_email != $input_fields['email']) {
                $emailTemplate = EmailTemplate::where('code', 'HCE-AE13')->first();
                $email_vars = [
                    '{%PRIMARY_COMPLIANCE_OFFICER_NAME%}' => $user->first_name.' '.$user->last_name,
                    '{%COMPANY_NAME%}' => $user->company_name,
                    '{%PRIMARY_COMPLIANCE_OFFICER_PREVIOUS_EMAIL%}' => $old_email,
                    '{%PRIMARY_COMPLIANCE_OFFICER_NEW_EMAIL%}' => $input_fields['email'],
                ];
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);

                if ($user->partner_reseller_id != null) {
                    $admin_subject = str_ireplace('{%RESELLER%}', $user->reseller->name, $emailTemplate->reseller_subject);
                } else {
                    $admin_subject = $emailTemplate->subject;
                }
                $this->sendEmail($emailTemplate->code, $html, Config::get('app.finance_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user->partner_reseller_id != null ? $user->reseller->logo : null));

                //send mail to partner start
                if ($user->partner_reseller_id != null && $user->reseller->email != '') {
                    $this->sendEmail($emailTemplate->code, $html, $user->reseller->email, Config::get('app.from_admin_email'), $admin_subject, null, null, true, $user->reseller->logo);
                }
                //send mail to partner end
            }
            if ($old_first_name != $input_fields['first_name'] || $old_last_name != $input_fields['last_name']) {
                $emailTemplate = EmailTemplate::where('code', 'HCE-AE14')->first();
                $email_vars = [
                    '{%COMPANY_NAME%}' => $user->company_name,
                    '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user->email,
                    '{%PRIMARY_COMPLIANCE_OFFICER_PREVIOUS_NAME%}' => $old_first_name.' '.$old_last_name,
                    '{%PRIMARY_COMPLIANCE_OFFICER_NEW_NAME%}' => $user->first_name.' '.$user->last_name,
                ];
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                if ($user->partner_reseller_id != null) {
                    $admin_subject = str_ireplace('{%RESELLER%}', $user->reseller->name, $emailTemplate->reseller_subject);
                } else {
                    $admin_subject = $emailTemplate->subject;
                }
                $this->sendEmail($emailTemplate->code, $html, Config::get('app.finance_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user->partner_reseller_id != null ? $user->reseller->logo : null));

                //send mail to partner start
                if ($user->partner_reseller_id != null && $user->reseller->email != '') {
                    $this->sendEmail($emailTemplate->code, $html, $user->reseller->email, Config::get('app.from_admin_email'), $admin_subject, null, null, true, $user->reseller->logo);
                }
                //send mail to partner end
            }
            if ($old_first_name != $input_fields['first_name'] || $old_last_name != $input_fields['last_name'] || $old_email != $input_fields['email']) {
                $main_location = Location::where('id', $user->locations[0]['id'])->whereNotNull('salesforce_unique_id')->first();
                if ($main_location) {
                    SendLocationDataToSalesForce::dispatch($main_location->id);
                }
                $hco_locations = HipaaComplianceOfficer::where('hco_id',$user->id)->where('hco_type','App\Models\User')->get();
                foreach($hco_locations  as $hco_location){
                    SendLocationDataToSalesForce::dispatch($hco_location->location_id);
                }
            }
            foreach ($input_fields['hco_location_new'] as $loc) {
                $SF_location = Location::where('id', $loc['location_id'])->whereNotNull('salesforce_unique_id')->first();
                if ($SF_location) {
                    SendLocationDataToSalesForce::dispatch($SF_location->id);
                }
            }
            $user = User::where('id', $user['id'])
                ->with(['state','hipaaComplianceOfficer', 'hipaaComplianceOfficer.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }])->first();

            if ($old_email != $input_fields['email'] || $old_first_name != $input_fields['first_name'] || $old_last_name != $input_fields['last_name'] || $old_phone_number != $input_fields['phone_number']) {
                Stripe\Stripe::setApiKey(Config::get('app.stripe_secret_key'));
                Stripe\Customer::update(
                    $user->stripe_customer_id,
                    [
                        "email"=> $input_fields['email'],
                        "phone"=> $input_fields['phone_number'],
                        "description" => $input_fields['first_name'].' '.$input_fields['last_name'].' :: '.$input_fields['email'].' :: '.$user->company_name,
                    ]
                );
                Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
                Customer::update($user->chargebee_customer_id,array(
                    "firstName" => $input_fields['first_name'],
                    "lastName" => $input_fields['last_name'],
                    "email" => $input_fields['email'],
                    "phone"=> $input_fields['phone_number'],
                ));
                Customer::updateBillingInfo($user->chargebee_customer_id,array(
                    "billingAddress" => array(
                        "firstName" => $input_fields['first_name'],
                        "lastName" => $input_fields['last_name'],
                        "email" => $input_fields['email'],
                        "company" => $user->company_name,
                        "stateCode" => $user->state->state_code,
                        "state" => $user->state->state_name,
                        "zip" => $user->zip_code,
                        "country" => "US",
                        "validationStatus" => 'partially_valid'
                    )
                ));
            }
            DB::commit();

            return $this->success(Config::get('constants.USER.USER_EDITED'), 200, $user);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('AccountUserController/editPrimaryUser() => '.$e->getMessage());
            Log::error('AccountUserController/editPrimaryUser()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Check unique email address in user and account user for this location
     *
     * @return \Illuminate\Http\Response
     */
    public function checkUniqueEmail(Request $request, $email = '', $user_type = '', $user_id = '')
    {

        try {
            if ($email == '' || $user_type == '') {
                dd('Invalid parmas');
            }
            if ($user_id = '') {
                $user = User::where('email', $request['email'])->count();
                $account_user = AccountUser::where('email', $request['email'])->count();
                if ($user > 0 || $account_user > 0) {
                    return 'available';
                } else {
                    return 'not_available';
                }
            } else {
                if ($request['user_type'] == 'primary_user') {
                    $user = User::where('email', $request['email'])->where('id', '!=', $request['user_id'])->count();
                    $account_user = AccountUser::where('email', $request['email'])->count();
                    if ($user > 0 || $account_user > 0) {
                        return 'available';
                    } else {
                        return 'not_available';
                    }
                } else {
                    $user = User::where('email', $request['email'])->count();
                    $account_user = AccountUser::where('email', $request['email'])->where('id', '!=', $request['user_id'])->count();
                    if ($user > 0 || $account_user > 0) {
                        return 'available';
                    } else {
                        return 'not_available';
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('AccountUserController/checkUniqueEmail() => '.$e->getMessage());
            Log::error('AccountUserController/checkUniqueEmail()[data] => '.json_encode($request->all()));
            Log::error('AccountUserController/checkUniqueEmail()[data] => '.json_encode([$email, $user_type, $user_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Add account user
     *
     * @return \Illuminate\Http\Response
     */
    public function addAccountUser(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required|email|unique:App\Models\AccountUser,email,NULL,id,deleted_at,NULL',
                'location_access' => 'required|array',
                'hco_location' => 'sometimes|array',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $total_account_user_added = AccountUser::where('user_id', $user_data->id)->count();
            if ($total_account_user_added === 0) {
                $first_account_user_added = true;
            } else {
                $first_account_user_added = false;
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $input_fields['user_id'] = $user_data['id'];
            $account_user_created = AccountUser::create($input_fields);
            $token = \Str::random(10);
            if ($account_user_created->update([
                'reset_password_token' => $token,
            ])) {
                $account_user_created['account_location_access'] = $account_user_created->accountLocationAccess()->createMany($input_fields['location_access']);
                if (isset($input_fields['hco_location']) && ! empty($input_fields['hco_location'])) {
                    $location_list = Location::select('location_nickname')->whereIn('id', array_values($input_fields['hco_location']))->get();
                    $emailTemplate = EmailTemplate::where('code', 'HCE-UE73')->first();
                    if ($user_data->is_sra_user == 1) {
                        $emailTemplate->body = preg_replace('/<ol[^>]*{%FOR_DEFAULT_USER%}[^>]*>.*?<\/ol>/is', '', $emailTemplate->body);
                    } else {
                        $emailTemplate->body = preg_replace('/<ol[^>]*{%FOR_SRA_USER%}[^>]*>.*?<\/ol>/is', '', $emailTemplate->body);
                    }
                    $email_vars = [
                        '{%HCO_FIRST_NAME%}' => $account_user_created->first_name,
                        '{%LOGIN_TO_ABYDE%}' => Config::get('app.url').'/login/'.$token.'/'.base64_encode($account_user_created->id).'/accountuser',
                        '{%LOCATION_LIST_USER_ADDED_TO%}' => implode(', ', \Arr::pluck($location_list, 'location_nickname')),
                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        '{%QUICK_INTRO_VIDEO%}' => 'https://youtu.be/FVfpNrmvDuc',
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $this->sendEmail($emailTemplate->code, $html, $account_user_created->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                } else {
                    $location_list = Location::select('location_nickname')->whereIn('id', array_values($input_fields['location_access']))->get();
                    $emailTemplate = EmailTemplate::where('code', 'HCE-UE4')->first();
                    $email_vars = [
                        '{%USER_FIRST_NAME%}' => $account_user_created->first_name,
                        '{%LOGIN_TO_ABYDE%}' => Config::get('app.url').'/login/'.$token.'/'.base64_encode($account_user_created->id).'/accountuser',
                        '{%LOCATION_LIST_USER_ADDED_TO%}' => implode(', ', \Arr::pluck($location_list, 'location_nickname')),
                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
                    $this->sendEmail($emailTemplate->code, $html, $account_user_created->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                }
                if (isset($input_fields['hco_location']) && ! empty($input_fields['hco_location'])) {
                    $emailTemplate_admin_HCE_AE15 = EmailTemplate::where('code', 'HCE-AE15')->first();
                    foreach ($input_fields['hco_location'] as $data) {
                        try {
                            $old_hco_data = HipaaComplianceOfficer::with(['hco'])->where('location_id', $data['location_id'])->first();
                            if ($old_hco_data && $account_user_created && ($old_hco_data->hco_id != $account_user_created->id || $old_hco_data->hco_type != \App\Models\AccountUser::class)) {
                                $location = Location::findOrFail($data['location_id']);
                                //Send HCE-AE15
                                $email_vars_admin = [
                                    '{%HCO_NAME%}' => $account_user_created->first_name.' '.$account_user_created->last_name,
                                    '{%HCO_EMAIL%}' => $account_user_created->email,
                                    '{%COMPANY_NAME%}' => $location->company_name,
                                    '{%LOCATION_NAME%}' => $location->location_nickname,
                                    '{%PREVIOUS_HCO_NAME%}' => $old_hco_data->hco->first_name.' '.$old_hco_data->hco->last_name,
                                ];
                                $html_admin = str_ireplace(array_keys($email_vars_admin), array_values($email_vars_admin), $emailTemplate_admin_HCE_AE15->body);

                                if ($user_data->partner_reseller_id != null) {
                                    $email_subject = [
                                        '{%RESELLER%}' => $user_data->reseller->name,
                                        '{%LOCATION_NAME%}' => $location->location_nickname,
                                    ];
                                    $admin_subject = str_ireplace(array_keys($email_subject), array_values($email_subject), $emailTemplate_admin_HCE_AE15->reseller_subject);
                                } else {
                                    $admin_subject = str_ireplace(['{%LOCATION_NAME%}'], [$location->location_nickname], $emailTemplate_admin_HCE_AE15->subject);
                                }

                                $this->sendEmail($emailTemplate_admin_HCE_AE15->code, $html_admin, Config::get('app.cs_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));

                                //send mail to partner start
                                if ($user_data->partner_reseller_id != null && $user_data->reseller->email != '') {
                                    $this->sendEmail($emailTemplate_admin_HCE_AE15->code, $html, $user_data->reseller->email, Config::get('app.from_admin_email'), $admin_subject, null, null, true, $user_data->reseller->logo);
                                }
                                //send mail to partner end
                            }

                            // add policy, procedure, form versioning
                            $policy_array = ['DRP', 'SPP', 'ETP', 'HNEP', 'PMP', 'PCFP', 'SAP', 'SATP', 'SRA'];
                            foreach ($policy_array as $policy) {
                                $this->addPolicyVersionData($policy, $data['location_id']);
                            }
                        } catch (\Exception $e) {
                            Log::error('AccountUserController/addAccountUser()[hco_location_error] => '.$e->getMessage());
                            Log::error('AccountUserController/addAccountUser()[hco_location_data] => '.json_encode($data));
                        }
                    }
                    HipaaComplianceOfficer::whereIn('location_id', $input_fields['hco_location'])->delete();
                    $account_user_created['hipaa_compliance_officer'] = $account_user_created->hipaaComplianceOfficer()->createMany($input_fields['hco_location']);

                    $training_controller = new TrainingController;
                    $emailTemplate_HCE_UE47 = EmailTemplate::where('code', 'HCE-UE47')->first();
                    $notification_HCE_AN2 = $this->getNotificationByCode('HCE-AN2');
                    $notification_HCE_AN3 = $this->getNotificationByCode('HCE-AN3');
                    $notification_HCE_AN5 = $this->getNotificationByCode('HCE-AN5');
                    $notification_HCE_AN39 = $this->getNotificationByCode('HCE-AN39');
                    foreach ($input_fields['hco_location'] as $data) {
                        try {
                            $user_data = $this->getMainAccountDetails();
                            $location = Location::findOrFail($data['location_id']);
                            $new_hco_data = HipaaComplianceOfficer::where('location_id', $data['location_id'])->with('hco')->first();
                            $email_send_user_list[] = ['first_name' => $user_data->first_name, 'email' => $user_data->email];
                            if ($user_data->email != $new_hco_data->hco->email) {
                                $email_send_user_list[] = ['first_name' => $new_hco_data->hco->first_name, 'email' => $new_hco_data->hco->email];
                            }
                            //Add in unassigned Training
                            $training_controller->addToUnassignedTraining($data['location_id'], $account_user_created->id, \App\Models\AccountUser::class);
                            // Notification HCE-AN3
                            if ($this->checkNotificationAlreadyAdded($notification_HCE_AN3->code, $data['location_id']) == 0) {
                                $notification_HCE_AN3_data = [
                                    'location_id' => $data['location_id'],
                                    'notification_id' => $notification_HCE_AN3['id'],
                                ];
                                $this->createNotification($notification_HCE_AN3_data);
                            }

                            // Notification HCE-AN5
                            if ($this->checkNotificationAlreadyAdded($notification_HCE_AN5->code, $data['location_id']) == 0 && $user_data->is_sra_user == 0) {
                                $notification_HCE_AN5_data = [
                                    'location_id' => $data['location_id'],
                                    'notification_id' => $notification_HCE_AN5['id'],
                                ];
                                $this->createNotification($notification_HCE_AN5_data);
                            }
                            if ($user_data['is_educational_account'] == 1 && $user_data->is_sra_user == 0) {
                                //Notification HCE-AN39
                                if ($this->checkNotificationAlreadyAdded($notification_HCE_AN39->code, $data['location_id']) == 0) {
                                    $notification_HCE_AN39_data = [
                                        'location_id' => $data['location_id'],
                                        'notification_id' => $notification_HCE_AN39['id'],
                                    ];
                                    $this->createNotification($notification_HCE_AN39_data);
                                    foreach ($email_send_user_list as $key => $value) {
                                        // send HCE-UE47
                                        $email_vars = [
                                            '{%FIRST_NAME%}' => $value['first_name'],
                                            '{%LOG_IN_TO_ABYDE%}' => Config::get('app.url'),
                                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                        ];
                                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate_HCE_UE47->body);
                                        $html_subject = str_ireplace(['{%LOCATION_NAME%}'], [$location->location_nickname], $emailTemplate_HCE_UE47->subject);
                                        $this->sendEmail($emailTemplate_HCE_UE47->code, $html, $value['email'], Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                                    }
                                }
                            }

                            LocationNotification::where('notification_id', $notification_HCE_AN2->id)
                                ->where('location_id', $data['location_id'])
                                ->where('is_completed', 0)
                                ->update(['is_completed' => 1]);
                        } catch (\Exception $e) {
                            Log::error('AccountUserController/addAccountUser()[hco_location_error] => '.$e->getMessage());
                            Log::error('AccountUserController/addAccountUser()[hco_location_data] => '.json_encode($data));
                        }
                    }
                    foreach ($input_fields['hco_location'] as $data) {
                        $SF_location = Location::where('id', $data['location_id'])->whereNotNull('salesforce_unique_id')->first();
                        if ($SF_location) {
                            SendLocationDataToSalesForce::dispatch($SF_location->id);
                        }
                    }
                }
            }
            $account_user_created['first_account_user_added'] = $first_account_user_added;
            $account_user_created['total_account_user_added'] = $total_account_user_added;
            DB::commit();

            return $this->success(Config::get('constants.ACCOUNT_USER.ACCOUNT_USER_ADDED'), 200, $account_user_created);
        } catch (\Exception $e) {
            Log::error('AccountUserController/addAccountUser() => '.$e->getMessage());
            Log::error('AccountUserController/addAccountUser()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Edit account user
     *
     * @return \Illuminate\Http\Response
     */
    public function editAccountUser(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'account_user_id' => 'required',
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required|email|unique:App\Models\AccountUser,email,'.$request->account_user_id.',id,deleted_at,NULL',
                'location_access_new' => 'sometimes|array',
                'location_access_removed' => 'sometimes|array',
                'hco_location_new' => 'sometimes|array',
                'hco_location_removed' => 'sometimes|array',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $removed_location_temp_array = [];
            $is_new_location_assign = false;
            $training_controller = new TrainingController;
            if ($request->has('location_access_removed')) {
                $removed_location_temp_array = $request['location_access_removed'];
            }
            $account_user = AccountUser::findOrFail($input_fields['account_user_id']);
            $old_account_user = AccountUser::with('hipaaComplianceOfficer')->findOrFail($input_fields['account_user_id']);

            if ($input_fields['first_name'] != $old_account_user['first_name'] || $input_fields['last_name'] != $old_account_user['last_name']) {
                foreach ($old_account_user->hipaaComplianceOfficer as $hipaaComplianceOfficer) {
                    // add policy, procedure, form versioning
                    $policy_array = ['DRP', 'SPP', 'ETP', 'HNEP', 'PMP', 'PCFP', 'SAP', 'SATP', 'SRA'];
                    foreach ($policy_array as $policy) {
                        $this->addPolicyVersionData($policy, $hipaaComplianceOfficer['location_id']);
                    }
                }
            }

            if ($request->has('hco_location_removed')) {
                foreach ($input_fields['hco_location_removed'] as $removed_location) {
                    // add policy, procedure, form versioning
                    $policy_array = ['DRP', 'SPP', 'ETP', 'HNEP', 'PMP', 'PCFP', 'SAP', 'SATP', 'SRA'];
                    foreach ($policy_array as $policy) {
                        $this->addPolicyVersionData($policy, $removed_location['location_id']);
                    }
                    $training_controller->moveTrainingToArchive($removed_location['location_id']);
                }
            }

            if ($request->has('hco_location_new')) {
                foreach ($input_fields['hco_location_new'] as $new_location) {
                    // add policy, procedure, form versioning
                    $policy_array = ['DRP', 'SPP', 'ETP', 'HNEP', 'PMP', 'PCFP', 'SAP', 'SATP', 'SRA'];
                    foreach ($policy_array as $policy) {
                        $this->addPolicyVersionData($policy, $new_location['location_id']);
                    }
                }
            }

            if ($account_user->update($input_fields)) {
                if ($request->has('location_access_removed')) {
                    AccountUserLocationAccess::whereIn('location_id', $input_fields['location_access_removed'])
                        ->where('account_user_id', $input_fields['account_user_id'])->get()->each(function ($ala) {
                            $ala->delete();
                        });
                }
                if ($request->has('location_access_new')) {
                    if (! empty($input_fields['location_access_new'])) {
                        $account_user->accountLocationAccess()->createMany($input_fields['location_access_new']);
                        $is_new_location_assign = true;
                    }
                }
                //if location is removed then delete all contributor question
                RiskAnalysisContributorQuestion::whereIn('location_id',$request->location_access_removed)
                        ->where(['contributor_user_acntuser_type' => AccountUser::class, 'status' => 'Assigned'])
                        ->where('contributor_user_acntuser_id', $request->account_user_id)->get()->each(function ($bal) {
                            $bal->delete();
                        });
                //end delete
                if ($request->has('is_hipaa_compliance_officer') && $request['is_hipaa_compliance_officer'] == 0) {
                    $account_user->hipaaComplianceOfficer()->delete();
                } else {
                    if ($request->has('hco_location_removed')) {
                        HipaaComplianceOfficer::whereIn('location_id', $input_fields['hco_location_removed'])->delete();
                    }

                    if ($request->has('hco_location_new')) {
                        $emailTemplate_admin_HCE_AE15 = EmailTemplate::where('code', 'HCE-AE15')->first();
                        foreach ($input_fields['hco_location_new'] as $data) {
                            try {
                                $old_hco_data = HipaaComplianceOfficer::with(['hco'])->where('location_id', $data['location_id'])->first();
                                if ($old_hco_data && $account_user && ($old_hco_data->hco_id != $account_user->id || $old_hco_data->hco_type != \App\Models\AccountUser::class)) {
                                    $location = Location::findOrFail($data['location_id']);
                                    // Send HCE-AE15
                                    $email_vars_admin = [
                                        '{%HCO_NAME%}' => $account_user->first_name.' '.$account_user->last_name,
                                        '{%HCO_EMAIL%}' => $account_user->email,
                                        '{%COMPANY_NAME%}' => $location->company_name,
                                        '{%LOCATION_NAME%}' => $location->location_nickname,
                                        '{%PREVIOUS_HCO_NAME%}' => $old_hco_data->hco->first_name.' '.$old_hco_data->hco->last_name,
                                    ];
                                    $html_admin = str_ireplace(array_keys($email_vars_admin), array_values($email_vars_admin), $emailTemplate_admin_HCE_AE15->body);

                                    if ($user_data->partner_reseller_id != null) {
                                        $email_subject = [
                                            '{%RESELLER%}' => $user_data->reseller->name,
                                            '{%LOCATION_NAME%}' => $location->location_nickname,
                                        ];
                                        $admin_subject = str_ireplace(array_keys($email_subject), array_values($email_subject), $emailTemplate_admin_HCE_AE15->reseller_subject);
                                    } else {
                                        $admin_subject = str_ireplace(['{%LOCATION_NAME%}'], [$location->location_nickname], $emailTemplate_admin_HCE_AE15->subject);
                                    }
                                    $this->sendEmail($emailTemplate_admin_HCE_AE15->code, $html_admin, Config::get('app.cs_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));

                                    //send mail to partner start
                                    if ($user_data->partner_reseller_id != null && $user_data->reseller->email != '') {
                                        $this->sendEmail($emailTemplate_admin_HCE_AE15->code, $html_admin, $user_data->reseller->email, Config::get('app.from_admin_email'), $admin_subject, null, null, true, $user_data->reseller->logo);
                                    }
                                    //send mail to partner end

                                }
                            } catch (\Exception $e) {
                                Log::error('AccountUserController/editAccountUser()[hco_location_new_error] => '.$e->getMessage());
                                Log::error('AccountUserController/editAccountUser()[hco_location_new_data] => '.json_encode($data));
                            }
                        }
                        HipaaComplianceOfficer::whereIn('location_id', $input_fields['hco_location_new'])->delete();
                        $account_user->hipaaComplianceOfficer()->createMany($input_fields['hco_location_new']);
                        $emailTemplate_HCE_UE47 = EmailTemplate::where('code', 'HCE-UE47')->first();
                        $notification_HCE_AN2 = $this->getNotificationByCode('HCE-AN2');
                        $notification_HCE_AN3 = $this->getNotificationByCode('HCE-AN3');
                        $notification_HCE_AN5 = $this->getNotificationByCode('HCE-AN5');
                        $notification_HCE_AN39 = $this->getNotificationByCode('HCE-AN39');
                        foreach ($input_fields['hco_location_new'] as $data) {
                            try {
                                $user_data = $this->getMainAccountDetails();
                                $location = Location::findOrFail($data['location_id']);
                                $new_hco_data = HipaaComplianceOfficer::where('location_id', $data['location_id'])->with('hco')->first();
                                $email_send_user_list[] = ['first_name' => $user_data->first_name, 'email' => $user_data->email];
                                if ($user_data->email != $new_hco_data->hco->email) {
                                    $email_send_user_list[] = ['first_name' => $new_hco_data->hco->first_name, 'email' => $new_hco_data->hco->email];
                                }
                                //Add in unassigned Training
                                $training_controller->addToUnassignedTraining($data['location_id'], $input_fields['account_user_id'], \App\Models\AccountUser::class);
                                // Notification HCE-AN3
                                if ($this->checkNotificationAlreadyAdded($notification_HCE_AN3->code, $data['location_id']) == 0) {
                                    $notification_HCE_AN3_data = [
                                        'location_id' => $data['location_id'],
                                        'notification_id' => $notification_HCE_AN3['id'],
                                    ];
                                    $this->createNotification($notification_HCE_AN3_data);
                                }
                                // Notification HCE-AN5
                                if ($this->checkNotificationAlreadyAdded($notification_HCE_AN5->code, $data['location_id']) == 0 && $user_data->is_sra_user == 0) {
                                    $notification_HCE_AN5_data = [
                                        'location_id' => $data['location_id'],
                                        'notification_id' => $notification_HCE_AN5['id'],
                                    ];
                                    $this->createNotification($notification_HCE_AN5_data);
                                }
                                if ($user_data['is_educational_account'] == 1) {
                                    // Notification HCE-AN39
                                    if ($this->checkNotificationAlreadyAdded($notification_HCE_AN39->code, $data['location_id']) == 0) {
                                        $notification_HCE_AN39_data = [
                                            'location_id' => $data['location_id'],
                                            'notification_id' => $notification_HCE_AN39['id'],
                                        ];
                                        $this->createNotification($notification_HCE_AN39_data);
                                        foreach ($email_send_user_list as $key => $value) {
                                            // send HCE-UE47
                                            $email_vars = [
                                                '{%FIRST_NAME%}' => $value['first_name'],
                                                '{%LOG_IN_TO_ABYDE%}' => Config::get('app.url'),
                                                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                            ];
                                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate_HCE_UE47->body);
                                            $html_subject = str_ireplace(['{%LOCATION_NAME%}'], [$location->location_nickname], $emailTemplate_HCE_UE47->subject);
                                            $this->sendEmail($emailTemplate_HCE_UE47->code, $html, $value['email'], Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                                        }
                                    }
                                }
                                LocationNotification::where('notification_id', $notification_HCE_AN2->id)
                                    ->where('location_id', $data['location_id'])
                                    ->where('is_completed', 0)
                                    ->update(['is_completed' => 1]);
                                    SendLocationDataToSalesForce::dispatch($data['location_id']);
                            } catch (\Exception $e) {
                                Log::error('AccountUserController/editAccountUser()[hco_location_new_error] => '.$e->getMessage());
                                Log::error('AccountUserController/editAccountUser()[hco_location_new_data] => '.json_encode($data));
                            }
                        }
                    }
                }
                if ($old_account_user->email != $account_user->email && is_null($old_account_user->password)) {
                    $token = \Str::random(10);
                    if ($account_user->update([
                        'reset_password_token' => $token,
                    ])) {
                        $is_HCO = HipaaComplianceOfficer::where('hco_id', $account_user->id)->where('hco_type', \App\Models\AccountUser::class)->with('location')->get();
                        if (count($is_HCO) > 0) {
                            $emailTemplate = EmailTemplate::where('code', 'HCE-UE73')->first();
                            if ($user_data->is_sra_user == 1) {
                                $emailTemplate->body = preg_replace('/<ol[^>]*{%FOR_DEFAULT_USER%}[^>]*>.*?<\/ol>/is', '', $emailTemplate->body);
                            } else {
                                $emailTemplate->body = preg_replace('/<ol[^>]*{%FOR_SRA_USER%}[^>]*>.*?<\/ol>/is', '', $emailTemplate->body);
                            }
                            $email_vars = [
                                '{%HCO_FIRST_NAME%}' => $account_user->first_name,
                                '{%LOGIN_TO_ABYDE%}' => Config::get('app.url').'/login/'.$token.'/'.base64_encode($account_user->id).'/accountuser',
                                '{%LOCATION_LIST_USER_ADDED_TO%}' => implode(', ', \Arr::pluck($is_HCO, 'location.location_nickname')),
                                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                '{%QUICK_INTRO_VIDEO%}' => 'https://youtu.be/FVfpNrmvDuc',
                            ];
                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                            $this->sendEmail($emailTemplate->code, $html, $account_user->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                        } else {
                            $location_list = AccountUserLocationAccess::where('account_user_id', $account_user->id)->with('location')->get();
                            $emailTemplate = EmailTemplate::where('code', 'HCE-UE4')->first();
                            $email_vars = [
                                '{%USER_FIRST_NAME%}' => $account_user->first_name,
                                '{%LOGIN_TO_ABYDE%}' => Config::get('app.url').'/login/'.$token.'/'.base64_encode($account_user->id).'/accountuser',
                                '{%LOCATION_LIST_USER_ADDED_TO%}' => implode(', ', \Arr::pluck($location_list, 'location.location_nickname')),
                                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                            ];
                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                            $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
                            $this->sendEmail($emailTemplate->code, $html, $account_user->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                        }
                    }
                }

                if ($is_new_location_assign) {
                    $emailTemplate = EmailTemplate::where('code', 'HCE-UE30')->first();
                    $email_vars = [
                        '{%FIRST_NAME%}' => $account_user->first_name,
                        '{%LOGIN_TO_ABYDE%}' => Config::get('app.url').'/login',
                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $this->sendEmail($emailTemplate->code, $html, $account_user->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                }
            }

            $account_user = AccountUser::where('id', $input_fields['account_user_id'])
                ->with(['accountLocationAccess', 'accountLocationAccess.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }, 'hipaaComplianceOfficer', 'hipaaComplianceOfficer.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }])->first();

            
            //fetch total questions whose status is 'pending','review' location wise
            if(!empty($account_user->accountLocationAccess))
            {
                foreach($account_user->accountLocationAccess as $key=>$acc_user)
                {
                    $account_user->accountLocationAccess[$key]->contrinutor_questions_count  = RiskAnalysisContributorQuestion::where(['contributor_user_acntuser_type' => \App\Models\AccountUser::class,'contributor_user_acntuser_id'=> $acc_user->account_user_id,'location_id' => $acc_user->location_id])
                        ->whereIn('status' ,['Pending','Reviewed'])               
                        ->count();   
                }
            }
            //end
            
            if ($input_fields['email'] != $old_account_user['email'] || $input_fields['first_name'] != $old_account_user['first_name'] || $input_fields['last_name'] != $old_account_user['last_name']){
                foreach($account_user['hipaaComplianceOfficer'] as $hco){
                    SendLocationDataToSalesForce::dispatch($hco['location_id']);
                }
            }
            DB::commit();

            return $this->success(Config::get('constants.ACCOUNT_USER.ACCOUNT_USER_EDITED'), 200, $account_user);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('AccountUserController/editAccountUser() => '.$e->getMessage());
            Log::error('AccountUserController/editAccountUser()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * delete account user
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteAccountUser(Request $request)
    {
        try {
            $validator_rules = [
                'account_user_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $check_hco = HipaaComplianceOfficer::where('hco_id', $request['account_user_id'])
                ->where('hco_type', \App\Models\AccountUser::class)
                ->count();
            if ($check_hco) {
                return $this->error(Config::get('constants.ACCOUNT_USER.SELECTED_HCO'), 200);
            }

            //if account user selected as SRA contributor then don't allow to delete
            $risk_analysis_contributor_id = $request['account_user_id'];
            $question_count = RiskAnalysisContributorQuestion::where(['contributor_user_acntuser_type'=>\App\Models\AccountUser::class,'contributor_user_acntuser_id'=> $risk_analysis_contributor_id])
                ->whereIn('status' ,['Pending','Reviewed'])               
                ->count();   
                
            if ($question_count > 0) {
                return $this->error(Config::get('constants.SRA_CONTRIBUTOR.CANNOT_DELETE_SRA_CONTRIBUTOR_ACCOUNT_USER'), 200);
            }            
            //end 
            AccountUser::findOrFail($request['account_user_id'])->delete();

            return $this->success(Config::get('constants.ACCOUNT_USER.ACCOUNT_USER_DELETED'), 200);
        } catch (\Exception $e) {
            Log::error('AccountUserController/deleteAccountUser() => '.$e->getMessage());
            Log::error('AccountUserController/deleteAccountUser()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Import account users from file
     *
     * @return \Illuminate\Http\Response
     */
    public function importAccountUsers(Request $request)
    {
        $user_data = $this->getMainAccountDetails();
        $location_list_count = Location::where('user_id', $user_data['id'])
            ->select(['id', 'location_nickname'])
            ->count();
        $validator_rules = [
            'import_file' => 'required|mimes:xlsx,xls',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules, []);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.ACCOUNT_USER.INVALID_IMPORT_FILE'), 200, $validator_check->errors()->all());
        }

        $headings = (new HeadingRowImport)->toArray($request['import_file']);
        if ($location_list_count == 1) {
            $heading_array = ['first_name', 'last_name', 'email'];
        } else {
            $heading_array = ['first_name', 'last_name', 'email', 'location_access'];
        }

        $headings[0][0] = array_filter($headings[0][0], function ($v) {
            return trim($v);
        });
        $missing_heading = array_diff($heading_array, $headings[0][0]);
        if ($missing_heading) {
            return $this->error(Config::get('constants.ACCOUNT_USER.IMPORT_FILE_INVALID_TEMPLETE'), 200);
        }

        try {
            if ($request->has('import_file')) {
                $import_file = $request->file('import_file')->store('import');
                $import = new AccountUsersImport;
                $import->import($import_file);
                if ($import->failures()->isNotEmpty()) {
                    $error = [];
                    $i = 0;
                    foreach ($import->failures() as $failure) {
                        foreach ($failure->errors() as $value) {
                            $error[$i] = $value.'Row No :'.$failure->row();
                            $i++;
                        }
                    }
                    Log::error('AccountUserController/importAccountUsers(ImportValidation) => '.json_encode($error));
                    if (! empty($error)) {
                        if ($import->row_count == 0) {
                            return $this->error(Config::get('constants.ACCOUNT_USER.IMPORT_ERROR'), 200, $error);
                        }
                        if ($import->row_count > 0) {
                            return $this->success(Config::get('constants.ACCOUNT_USER.PARTIALLY_IMPORT_ERROR'), 200, $error);
                        }
                    }
                }
                if ($import->row_count == 0) {
                    return $this->error(Config::get('constants.ACCOUNT_USER.IMPORT_ERROR'), 200, $import->invalid_primary_location);
                }
                if ($import->row_count == $import->total_row_count) {
                    return $this->success(Config::get('constants.ACCOUNT_USER.IMPORTED'), 200);
                } else {
                    return $this->success(Config::get('constants.ACCOUNT_USER.PARTIALLY_IMPORT_ERROR'), 200, $import->invalid_primary_location);
                }
            }
        } catch (\Exception $e) {
            if ($e->getMessage() == 'more_than_limit_records') {
                Log::error('AccountUserController/importAccountUsers(limit) => Limit reached');

                return $this->error(Config::get('constants.IMPORT_LIMIT'), 200);
            } else {
                Log::error('AccountUserController/importAccountUsers(error) => '.$e->getMessage());

                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        }
    }

    /**
     * get last updated account user for dashboard
     */
    public function getLastUpdatedAccountUser($location_id)
    {
        $is_avail = LocationModuleLastUpdate::where(['location_id' => $location_id, 'module_name' => 'account_user'])->first();

        return ($is_avail) ? $is_avail->updated_at : '';
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
