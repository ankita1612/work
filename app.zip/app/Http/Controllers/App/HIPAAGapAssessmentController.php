<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\EmailTemplate;
use App\Models\HipaaGapAssessmentAttemptedQuestion;
use App\Models\HipaaGapAssessmentQuestion;
use App\Models\HipaaGapAssessmentVisitor;
use App\Models\Partner;
use App\Models\State;
use App\Traits\ApiResponser;
use App\Traits\FileUpload;
use App\Traits\SendMail;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class HIPAAGapAssessmentController extends Controller
{
    use ApiResponser, FileUpload, SendMail;

    /**
     * Hipaa Gap Assessment page
     */
    public function showHipaaChallange(Request $request, $partner = null)
    {
        return view('app.pages.hipaagapassessment');
    }

    /**
     * Hipaa Gap Assessment page
     */
    public function showSelectState(Request $request)
    {
        return view('app.pages.hipaagapassessmentscheduled');
    }

    /**
     * hipaa Gap Assessment question
     *
     * @return \Illuminate\Http\Response
     */
    public function loadHipaaGapAssessmentQuestion(Request $request)
    {
        try {
            $validator_rules = [
                'pagination_type' => 'required|in:next,first',
                'attempted_questions' => 'nullable|array',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $question_id = $request->has('question_id') ? $request['question_id'] : null;
            $answer_id = $request->has('answer_id') ? $request['answer_id'] : null;
            $pagination_type = $request->has('pagination_type') ? $request['pagination_type'] : 'next';
            $percentage_count = $this->getPercentageCount($request['attempted_questions']);
            if ($pagination_type == 'first') {
                $question_detail = HipaaGapAssessmentQuestion::with(['hipaaGapAssessmentQuestionAnswerOptions'])
                    ->isActive()->orderBy('display_order', 'asc')->first();
            } elseif ($pagination_type == 'next') {
                $question_detail = $this->getNextQuestion($question_id, $answer_id);
            }

            $data = [
                'question_detail' => $question_detail,
                'percentage_count' => $percentage_count,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('HIPAAGapAssessmentController/loadHipaaGapAssessmentQuestion() => '.$e->getMessage());
            Log::error('HIPAAGapAssessmentController/loadHipaaGapAssessmentQuestion()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Get Next Question
     */
    public function getNextQuestion($question_id, $answer_id)
    {
        $current_question = HipaaGapAssessmentQuestion::where('id', $question_id)->first();
        if ($current_question) {
            $question = HipaaGapAssessmentQuestion::with(['hipaaGapAssessmentQuestionAnswerOptions'])
                ->where('parent_question_id', $question_id)
                ->where('parent_answer_id', $answer_id)
                ->isActive()
                ->orderBy('display_order', 'asc')
                ->first();
            if (! $question) {
                $question = HipaaGapAssessmentQuestion::with(['hipaaGapAssessmentQuestionAnswerOptions'])
                    ->where('parent_question_id', $current_question['parent_question_id'])
                    ->where('display_order', '>', $current_question['display_order'])
                    ->where('level', '=', $current_question['level'])
                    ->isActive()
                    ->orderBy('display_order', 'asc')
                    ->first();
                if (! $question) {
                    $parent_question = HipaaGapAssessmentQuestion::where('id', $current_question['parent_question_id'])->first();
                    if ($parent_question != null) {
                        $question = HipaaGapAssessmentQuestion::with(['hipaaGapAssessmentQuestionAnswerOptions'])
                            ->where('parent_question_id', $parent_question['parent_question_id'])
                            ->where('display_order', '>', $parent_question['display_order'])
                            ->where('level', '=', $parent_question['level'])
                            ->isActive()
                            ->orderBy('display_order', 'asc')
                            ->first();
                    } else {
                        return null;
                    }
                }
            }

            return $question;
        }

        return null;
    }

    /**
     * List all states
     *
     * @return \Illuminate\Http\Response
     */
    public function listStates(Request $request)
    {
        try {
            $list = State::select(['id', 'state_code', 'state_name'])
                ->with('calendlyLink')
                ->orderBy('state_name')
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('GeneralController/listStates() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    public function saveAnswers(Request $request)
    {
        try {
            $validator_rules = [
                'contact_info.company_name' => 'required',
                'contact_info.contact_name' => 'required',
                'contact_info.email' => 'required',
                'contact_info.state_id' => 'required',
                'quiz_info.*.question_id' => 'required',
                'quiz_info.*.answer_id' => 'required',
                'quiz_info.*.answer_type' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $input_fields = $request->all();
            foreach ($input_fields['quiz_info'] as $key => $val) {
                if (isset($val['answer_type']) && $val['answer_type'] == 'state') {
                    $input_fields['quiz_info'][$key]['answer_type'] = \App\Models\State::class;
                } else {
                    $input_fields['quiz_info'][$key]['answer_type'] = \App\Models\HipaaGapAssessmentQuestionAnswerOption::class;
                }
            }
            DB::beginTransaction();
            $visitors = HipaaGapAssessmentVisitor::create($input_fields['contact_info']);
            foreach ($input_fields['quiz_info'] as $quizInfo) {
                $visitors->attemptedQuestion()->updateOrCreate(
                    ['question_id' => $quizInfo['question_id'], 'visitor_id' => $visitors->id],
                    $quizInfo
                );
            }
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200, $visitors);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('HIPAAGapAssessmentController/saveAnswers() => '.$e->getMessage());
            Log::error('HIPAAGapAssessmentController/saveAnswers()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Get Percentage Count
     *
     * @param  \Illuminate\Http\Request  $request
     */
    public function getPercentageCount($attempted_que)
    {
        $all_question_ids = HipaaGapAssessmentQuestion::isActive()->pluck('id')->toArray();

        $ids = array_column($attempted_que, 'question_id');
        $attempted_questions = HipaaGapAssessmentQuestion::isActive()
            ->with('childQuestionNested')
            ->where('level', 1)
            ->whereIn('id', $ids)
            ->get();
        $attempted_question_ids = $attempted_questions->pluck('id')->toArray();
        $this->getRecursiveCountOfQuestion($attempted_questions, $attempted_question_ids);
        $attempted_with_total_child = $attempted_question_ids;
        foreach ($attempted_que as $que) {
            $sub_question = HipaaGapAssessmentQuestion::where([
                'parent_question_id' => $que['question_id'],
                'parent_answer_id' => $que['answer_id'],
            ])->isActive()->get();
            foreach ($sub_question as $sq) {
                $key = array_search($sq['id'], $ids);
                if (! $key) {
                    if ($key = array_search($sq['id'], $attempted_question_ids)) {
                        unset($attempted_question_ids[$key]);
                    }
                }
            }
        }

        $total_questions = count($all_question_ids);
        $attempted_questions_count = count($attempted_question_ids);

        if ($total_questions > 0) {
            $per = ($attempted_questions_count / $total_questions) * 100;
        } else {
            $per = 0;
        }

        return [
            'total_questions' => $total_questions,
            'attempted_questions' => $attempted_questions_count,
            'percentage' => round($per),
        ];
    }

    /**
     * Get Recursive Count Of Question
     */
    private function getRecursiveCountOfQuestion($questions, &$attempted_question_ids)
    {
        foreach ($questions as $que) {
            if (! in_array($que['id'], $attempted_question_ids)) {
                $attempted_question_ids[] = $que['id'];
            }
            if (count($que->childQuestionNested) > 0) {
                $this->getRecursiveCountOfQuestion($que->childQuestionNested, $attempted_question_ids);
            }
        }
    }

    /**
     * Generate visitor scorecard
     *
     * @return \Illuminate\Http\Response
     */
    public function generateVisitorScorecard(Request $request)
    {
        try {
            $validator_rules = [
                'visitor_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $attempted_main_answers = HipaaGapAssessmentAttemptedQuestion::where('visitor_id', $request['visitor_id'])
                ->with(['answer', 'question'])
                ->whereHas('question', function ($q) {
                    $q->where('level', 1);
                })
                ->get();
            foreach ($attempted_main_answers as $answer) {
                $answer['sub_answers'] = HipaaGapAssessmentAttemptedQuestion::where('visitor_id', $request['visitor_id'])
                    ->with(['answer', 'question'])
                    ->whereHas('question', function ($q) use ($answer) {
                        $q->where('level', 2)
                            ->where('parent_question_id', $answer->question->id);
                    })
                    ->get();
            }
            $visitor = HipaaGapAssessmentVisitor::with('state')->find($request['visitor_id']);
            $data['attempted_answers'] = $attempted_main_answers;
            $data['visitor'] = $visitor;

            // hipaa gap assessment scorecard pdf
            $pdf = PDF::loadView('reports/hipaagapassessmentscorecard', compact('attempted_main_answers', 'visitor'));
            $local_pdf_url = storage_path('app/public').'/generatedpolicydocuments/'.$request['visitor_id'].'_hipaa_gap_assessment_scorecard.pdf';
            $pdf->save($local_pdf_url);
            $s3_scorecard_path = '/hipaagapassessment/'.$request['visitor_id'].'_hipaa_gap_assessment_scorecard.pdf';
            Storage::disk('s3')->put($s3_scorecard_path, file_get_contents($local_pdf_url));
            $data['download_url'] = $this->getSignedURL($s3_scorecard_path);
            $visitor->update([
                'scorecard' => $request['visitor_id'].'_hipaa_gap_assessment_scorecard.pdf',
            ]);

            $emailTemplateAdmin = EmailTemplate::where('code', 'HCE-AE21')->first();
            $email_vars_admin = [
                '{%VISITOR_COMPANY_NAME%}' => $visitor['company_name'],
                '{%VISITOR_EMAIL%}' => $visitor['email'],
                '{%VISITOR_NAME%}' => $visitor['contact_name'],
                '{%STATE_ANSWER%}' => $visitor['state']['state_name'],
            ];
            $html_admin = str_ireplace(array_keys($email_vars_admin), array_values($email_vars_admin), $emailTemplateAdmin->body);
            $this->sendEmail($emailTemplateAdmin->code, $html_admin, Config::get('app.sales_group_email'), Config::get('app.expert_email'), $emailTemplateAdmin->subject, $local_pdf_url, [Config::get('app.salesadmin_cc_email')]);

            $emailTemplateUser = EmailTemplate::where('code', 'HCE-UE54')->first();

            $email_vars_user = [
                '{%VISITOR_NAME%}' => $visitor['contact_name'],
                '{%HIPAA_GAP_ASSESSMENT%}' => Config::get('app.wordpress_url'),
                '{%SELECT_STATE_URL%}' => URL::to('/hipaa-gap-assessment/selectstate'),
            ];
            $html_user = str_ireplace(array_keys($email_vars_user), array_values($email_vars_user), $emailTemplateUser->body);
            $this->sendEmail($emailTemplateUser->code, $html_user, $visitor->email, Config::get('app.from_user_email'), $emailTemplateUser->subject, $local_pdf_url);

            return $this->success(Config::get('constants.GAP_ASSESSMENT_SUCCESS'), 200);
        } catch (\Exception $e) {
            Log::error('HIPAAGapAssessmentController/generateVisitorScorecard() => '.$e->getMessage());
            Log::error('HIPAAGapAssessmentController/generateVisitorScorecard()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * hipaa gap assessment question
     *
     * @return \Illuminate\Http\Response
     */
    public function partnerInfo(Request $request)
    {
        try {
            $validator_rules = [
                'slug' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $partner = Partner::where('slug', $request['slug'])->whereHas('hipaaGapAssessmentPartnerAccess')->first();

            return $this->success(Config::get('constants.SUCCESS'), 200, $partner);
        } catch (\Exception $e) {
            Log::error('HIPAAGapAssessmentController/partnerInfo() => '.$e->getMessage());
            Log::error('HIPAAGapAssessmentController/partnerInfo()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
}
