<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\State;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;

class WebinarController extends Controller
{
    use ApiResponser;

    /**
     * Webinar select state page
     */
    public function showSelectState(Request $request)
    {
        return view('app.pages.webinar');
    }

    /**
     * List all states
     *
     * @return \Illuminate\Http\Response
     */
    public function listStates(Request $request)
    {
        try {
            $list = State::select(['id', 'state_code', 'state_name'])
                ->with('calendlyLink')
                ->orderBy('state_name')
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('WebinarController/listStates() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }
}
