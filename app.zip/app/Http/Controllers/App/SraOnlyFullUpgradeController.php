<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\EmailTemplate;
use App\Models\EmployeeLimitPrice;
use App\Models\FullUpgradeSraUserDetail;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\LocationLimitPrice;
use App\Models\State;
use App\Models\Promocode;
use App\Models\User;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\GetLoginUserData;
use App\Traits\GetMainUserData;
use App\Traits\PricingHelper;
use App\Traits\SendMail;
use App\Traits\ChargebeePlan;
use Carbon\Carbon;
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Models\Estimate;
use ChargeBee\ChargeBee\Models\Subscription;
use ChargeBee\ChargeBee\Models\UnbilledCharge;
use ChargeBee\ChargeBee\Models\Invoice;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Traits\Notification;

class SraOnlyFullUpgradeController extends Controller
{
    use ApiResponser, ApiResponser, CheckAccessRight, GetLoginUserData, GetMainUserData, PricingHelper, SendMail, ChargebeePlan, Notification;

    /**
     * Upgrade page
     *
     * @return \Illuminate\Http\Response
     */
    public function showUpgrade(Request $request)
    {
        $user_data = $this->getLoginUserData();
        if ($this->checkAccessRight('upgrade') && $user_data->is_sra_user == 1 && ($user_data->partner_reseller_id == null || ($user_data->partner_reseller_id != null && $user_data->is_admin_panel_login == 'true'))) {
            return view('app.pages.sra_only_full_upgrade');
        } else {
            return redirect('/dashboard');
        }
    }


    /************************** */
    /*API methods - start
    /*************************** */


    /**
     * get user current plan information
     *
     * @return \Illuminate\Http\Response
     */
    public function getLocationEmployeeInformation(Request $request)
    {
        $user_data = $this->getMainAccountDetails();
        $employee_limit = EmployeeLimitPrice::all();
        $location_max_limit = LocationLimitPrice::max('limit');
        $employee_max_limit = EmployeeLimitPrice::max('min_limit');
        Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
        $subscription_response = Subscription::retrieve($user_data->chargebee_subscription_id);
        $subscription = $subscription_response->subscription();
        $location_limit = 0;
        foreach($subscription->subscriptionItems as $subscriptionItems){
            if($subscriptionItems->itemType == 'plan' && str_contains($subscriptionItems->itemPriceId, 'SRA-ONLY')){
                $location_limit = $subscriptionItems->quantity;
            }
        }
        
        $data = [
            'user_current_location_limit' => $location_limit,
            'employee_limit' => $employee_limit,
            'employee_max_limit' => $employee_max_limit,
            'location_max_limit' => $location_max_limit,
        ];

        return $this->success('', 200, $data);
    }

    /**
     * get chargebee price upgrade estimation for show information in upgrade page
     *
     * @return \Illuminate\Http\Response
     */
    public function getChargebeePriceUpgradeEstimation(Request $request)
    {

        try {
            $validator_rules = [
                'location_limit' => 'required',
                'employee_max_limit' => 'required',
                'plan_type' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $user_data = $this->getMainAccountDetails();
            Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
            $chargebee_plan_ids = $this->getChargebeePlanId($request->plan_type, $user_data->chargebe_addon_type);
            $cancel_estimation_array = array(
                "credit_option_for_current_term_charges" => "prorate",
                "refundable_credits_handling" => "no_action",
                "contract_term_cancel_option" => "terminate_immediately",
                "cancel_reason_code" => "Other",
            );
            $cancel_estimate_response = Estimate::cancelSubscriptionForItems($user_data->chargebee_subscription_id,$cancel_estimation_array);
            $cancel_estimate = $cancel_estimate_response->estimate();
            $state_data = State::where('id', $user_data->state_id)->first();
            $first_estimation_array = array(
                "billingAddress" => array(
                        "stateCode" => $state_data->state_code,
                        "state" => $state_data->state_name,
                        "zip" => $user_data->zip_code,
                        "country" => "US"
                    ),
                "customer" => array(
                        "taxability" => ($request->user_type == 'Reseller') ? 'exempt' : 'taxable'
                    ),
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => 1
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['location_item_id'],
                        "quantity" => $request->location_limit
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['employee_item_id'],
                        "quantity" => $request->employee_max_limit
                    )
                ),
            );
            if($request->filled('entered_promocode')){
                // check promocode in database
                $promocode_data = Promocode::isActive()->where(['promo_code'=> $request->entered_promocode,'user_type'=>$request->user_type])->first();
                if(empty($promocode_data)){
                    return $this->error(Config::get('constants.USER.PROMO_NOT_VALID'), 200, ['error_type' => 'coupon']);
                }
                $first_estimation_array["couponIds"] = array($request->entered_promocode);
            }
            $first_estimate_response = Estimate::createSubItemEstimate($first_estimation_array);
            $first_estimate = $first_estimate_response->estimate();
            $discount = '';
            $taxes = '';

            if (isset($first_estimate->invoiceEstimate->taxes) && !empty($first_estimate->invoiceEstimate->taxes)) {
                $taxes = [];
                foreach ($first_estimate->invoiceEstimate->taxes as $key => $value) {
                    $taxes[] = array(
                        'percentage' => $value->description,
                        'amount' => $value->amount
                    );
                }
            }
            if(isset($first_estimate->invoiceEstimate->discounts[0]) && !empty($first_estimate->invoiceEstimate->discounts[0])){
                $discount = array(
                    'id' => $first_estimate->invoiceEstimate->discounts[0]->entityId,
                    'promocode' => $first_estimate->invoiceEstimate->discounts[0]->description,
                    'discount_percentage' => (isset($first_estimate->invoiceEstimate->discounts[0]->discountPercentage))?$first_estimate->invoiceEstimate->discounts[0]->discountPercentage:'',
                    'discount_type' => $first_estimate->invoiceEstimate->discounts[0]->discountType,
                    'discount_amount' => $first_estimate->invoiceEstimate->discounts[0]->amount
                );
            }
            $cancel_credit_amount = 0;
            foreach($cancel_estimate->creditNoteEstimates as $credit_data) {
                $cancel_credit_amount += ($credit_data->total / 100);
            }
            $total_amount = $first_estimate->invoiceEstimate->total / 100;
            
            $upgrade_amount = max($total_amount - $cancel_credit_amount,0);
            $save_credit_amount = 0;
            if($upgrade_amount == 0) {
                $save_credit_amount = $cancel_credit_amount - $total_amount;
            } 

            if($request->plan_type == 'yearly') {
                $monthly_amount = $total_amount / 12;
            } else if($request->plan_type == 'biannually') {
                $monthly_amount = $total_amount / 6;
            }
             $final_response = array(
                'next_yearly_payment_amount' => $total_amount,
                'monthly_amount' => $monthly_amount,
                'upgrade_amount' => $upgrade_amount,
                'save_credit_amount' => $save_credit_amount,
                'discounts' => $discount,
                'taxes' => $taxes,
            );
            return $this->success(Config::get('constants.SUCCESS'), 200, $final_response);
        } catch (\Exception $e) {
            Log::error('SraOnlyFullUpgradeController/getChargebeePriceUpgradeEstimation() => ' . $e->getMessage());
            Log::error('SraOnlyFullUpgradeController/getChargebeePriceUpgradeEstimation()[data] => ' . json_encode($request->all()));
            if ("coupon_ids[0]" == $e->getParam()) {
                return $this->error(Config::get('constants.USER.PROMO_NOT_VALID'), 200, ['error_type' => 'coupon']);
            }else if("destination_address_error" == $e->getJsonObject()['error_code']){
                return $this->error($e->getMessage(), 200, ['error_type' => 'zipcode']);
            }
            else if("invalid_request" == $e->getApiErrorCode()){
                return $this->error($e->getMessage(), 200, ['error_type' => 'other']);
            }else{
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, ['error_type' => 'other']);
            }
        }
    }

    /**
     * upgrade action
     *
     * @return \Illuminate\Http\Response
     */
    public function doUpgrade(Request $request)
    {
        $validator_rules = [
            'location_limit' => 'required',
            'employee_limit' => 'required',
            'employee_max_limit' => 'required',
            'plan_type' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            DB::beginTransaction();
            $user_data = $this->getMainAccountDetails();
            Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
            $chargebee_plan_ids = $this->getChargebeePlanId($request->plan_type, $user_data->chargebe_addon_type);
            $chargebee_subscription_details = $this->getSubscriptionDetails($user_data->chargebee_subscription_id);
            $chargebee_payament_source_id = $chargebee_subscription_details['payment_source_id'];
            
            if($request->filled('entered_promocode')){
                // Check promocode in database
                $promocode_data = Promocode::isActive()->where(['promo_code'=> $request->entered_promocode,'user_type'=>$request->user_type])->first();
                if(empty($promocode_data)){                    
                    return $this->error(Config::get('constants.USER.PROMO_NOT_VALID'), 200, ['error_type' => 'coupon']);
                }               
            }
            // CB subscription create
            $cancel_subscription_array = array(
                   "credit_option_for_current_term_charges" => "prorate",
                    "refundable_credits_handling" => "no_action",
                    "contract_term_cancel_option" => "terminate_immediately",
                    "cancel_reason_code" => "Other",
            );
            Subscription::cancelForItems($user_data->chargebee_subscription_id,$cancel_subscription_array);
            
            $create_new_subscription_array = array(
                "invoiceImmediately" => false,
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => 1
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['location_item_id'],
                        "quantity" => $request->location_limit
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['employee_item_id'],
                        "quantity" => $request->employee_max_limit
                    )
                ),
                "contractTerm" => array(
                    "actionAtTermEnd" => "renew",
                    "cancellationCutoffPeriod" => "30"
                ),
                "paymentSourceId" => $chargebee_payament_source_id,
            );
            if($request->filled('entered_promocode')){
                $create_new_subscription_array["couponIds"] = array($request->entered_promocode);
            }
            $create_new_subscription_response = Subscription::createWithItems($user_data->chargebee_customer_id, $create_new_subscription_array);
            $subscription_response_details = $create_new_subscription_response->subscription();

            $unbilled_charge_response = UnbilledCharge::invoiceUnbilledCharges(array(
                "subscriptionId" => $subscription_response_details->id,
            ));
            $chargebee_invoice_response = $unbilled_charge_response->invoices();
            $chargebee_invoice_created = $chargebee_invoice_response[0];

            if ($chargebee_invoice_created) {
                // Create history for sra only in DB
                FullUpgradeSraUserDetail::create([
                    'user_id' => $user_data->id,
                    'sra_only_subscription_id' => $user_data->chargebee_subscription_id
                ]);
                User::where('id', $user_data->id)->update(['chargebee_subscription_id' => $subscription_response_details->id, 'is_sra_user' => 0]);

                $emailTemplate = EmailTemplate::where('code', 'HCE-UE71')->first();
                // Invoice Attachment
                $now = Carbon::now();
                $attachment_invoice = null;
                $chargebee_invoice_download = Invoice::pdf($chargebee_invoice_created->id, ['dispositionType' => 'attachment']);
                $chargebee_invoice_pdf = $chargebee_invoice_download->download();
                $attachment_invoice = storage_path('app/public').'/generatedpolicydocuments/'.'Abyde_Receipt_'.strtotime($now).'.pdf';
                file_put_contents($attachment_invoice, file_get_contents($chargebee_invoice_pdf->downloadUrl));
                $email_vars = [
                    '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_data->first_name,
                    '{%SCHEDULE_TRAINING%}' => Config::get('app.calendly_url').'/cs-team-sj1m/abyde-academy-team-hipaa?back=1&month='.date("Y")."-".date("m"),
                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                ];
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                $this->sendEmail($emailTemplate->code, $html, $user_data->email, Config::get('app.from_user_email'), $emailTemplate->subject, ($user_data->partner_reseller_id == null? $attachment_invoice : null), null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
            
                $charge_price = (($chargebee_invoice_created->status == 'payment_due')?$chargebee_invoice_created->amountDue:$chargebee_invoice_created->amountPaid) / 100;
                $final_payment_price = $chargebee_invoice_created->total / 100;
                $applied_credit = $chargebee_invoice_created->creditsApplied / 100;
                $sales_tax = [];
                $sales_tax_percentage = 0;
                if(isset($chargebee_invoice_created->taxes) && !empty($chargebee_invoice_created->taxes)){
                    foreach ($chargebee_invoice_created->taxes as $key => $value) {
                        $sales_tax[] = array(
                            'amount' => $value->amount / 100
                        );
                    }
                    foreach ($chargebee_invoice_created->lineItems as $key => $value) {
                        $sales_tax_percentage  = (isset($value->taxRate))?$value->taxRate:0;
                    }
                }
                if(!empty($sales_tax)){
                    $final_payment_price = round($final_payment_price - array_sum(array_column($sales_tax, 'amount')), 2);
                }
                $final_discount_price = 0;
                if(isset($chargebee_invoice_created->discounts[0]) && !empty($chargebee_invoice_created->discounts[0])){
                    $final_discount_price = $chargebee_invoice_created->discounts[0]->amount / 100;
                }
                if($final_discount_price > 0){
                    $final_payment_price = round($final_payment_price + $final_discount_price, 2);
                }
                
                $emailTemplate = EmailTemplate::where('code', 'HCE-AE26')->first();
                $email_vars = [
                    '{%CHRGEBEE_INVOICE_ID%}'  => $chargebee_invoice_created->id,
                    '{%CHRGEBEE_CUSTOMER_ID%}' => $user_data->chargebee_customer_id,
                    '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_data->first_name,
                    '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user_data->last_name,
                    '{%COMPANY_NAME%}' => $user_data->company_name,
                    '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_data->email,
                    '{%PHONE_NUMBER%}' => $user_data->phone_number,
                    '{%NUMBERS_OF_LOCATIONS%}' => $request->location_limit,
                    '{%EMPLOYEE_RANGE%}' => $request->employee_limit,
                    '{%PROMO_CODE%}' => ($request->entered_promocode) ? $request->entered_promocode : '',
                    '{%PRICE%}' => $this->formatPrice($final_payment_price),
                    '{%PROMO_DISCOUNT%}' => $this->formatPrice($final_discount_price),
                    '{%DISCOUNT_PRICE%}' => $this->formatPrice(round(($final_payment_price - $final_discount_price), 2)),
                    '{%SALES_TAX_PERCENTAGE%}' => (!empty($sales_tax))?$sales_tax_percentage:0,
                    '{%SALES_TAX_AMOUNT%}' => $this->formatPrice((!empty($sales_tax))?array_sum(array_column($sales_tax, 'amount')):0),
                    '{%CREDITS_APPLIED%}' => $this->formatPrice($applied_credit),
                    '{%PAYMENT_PRICE%}' => $this->formatPrice($charge_price),
                    '{%PAYMENT_TERM%}' => ($request->plan_type == 'biannually' ? 'Bi-Annually' : ucfirst($request->plan_type)),
                    '{%PAYMENT_DATE%}' => Carbon::now()->format('Y-m-d'),
                ];
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                $admin_subject = $emailTemplate->subject;
                $this->sendEmail($emailTemplate->code, $html, [Config::get('app.finance_group_email'), Config::get('app.cs_group_email'), Config::get('app.aw_group_email')], Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                if ($user_data->partner_reseller_id != null) {
                    $admin_subject = str_ireplace('{%RESELLER%}', $user_data->reseller->name, $emailTemplate->reseller_subject);
                    $this->sendEmail($emailTemplate->code, $html, $user_data->reseller->email, Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                }
                // Update Training anchor date in Location
                Location::where('user_id', $user_data->id)->update(['training_anchor_date' => Carbon::now()]);

                // Send notification for Add Employee
                $get_all_locations = Location::where('user_id', $user_data->id)->pluck('id');
                $notification_HCE_AN5 = $this->getNotificationByCode('HCE-AN5');
                foreach($get_all_locations as $data) {
                    $new_hco_data = HipaaComplianceOfficer::where('location_id', $data)->with('hco')->first();
                    if($new_hco_data) {
                        $location = Location::where('id', $data)->first();
                        $notification_HCE_AN5_data = [
                            'location_id' => $data,
                            'notification_id' => $notification_HCE_AN5['id'],
                        ];
                        $this->createNotification($notification_HCE_AN5_data);
                    }
                }
            }
            DB::commit();
            $sales_force_locations = Location::where('user_id', $user_data->id)->whereNotNull('salesforce_unique_id')->get();
            foreach($sales_force_locations as $location){
                SendLocationDataToSalesForce::dispatch($location->id);
            }
            
            return $this->success(Config::get('constants.USER.UPGRADE_SUCCESS'), 200);
        } catch (Stripe\Exception\CardException $e) {
            DB::rollback();
            Log::error('SraOnlyFullUpgradeController/doUpgrade() => ' . $e->getError()->message);
            Log::error('SraOnlyFullUpgradeController/doUpgrade()[data] => ' . json_encode($request->all()));
            return $this->error($e->getError()->message, 200);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('SraOnlyFullUpgradeController/doUpgrade() => ' . $e->getMessage());
            Log::error('SraOnlyFullUpgradeController/doUpgrade()[data] => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.USER.UPGRADE_FAILED'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
