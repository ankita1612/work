<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\HipaaComplianceOfficer;
use App\Models\LocationNotification;
use App\Models\ModuleCompletedStatus;
use App\Models\OngoingQuestion;
use App\Models\OngoingRiskAnalysisQuestion;
use App\Models\RiskAnalysisAttemptedQuestion;
use App\Models\RiskAnalysisAttemptedQuestionAnswer;
use App\Models\RiskAnalysisPreviousAttemptedQuestionAnswer;
use App\Models\RiskAnalysisQuestion;
use App\Models\RiskAnalysisQuestionAnswerOption;
use App\Models\RiskAnalysisRemindOption;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\Notification;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Validator;

class OngoingComplianceController extends Controller
{
    use ApiResponser, CheckAccessRight, Notification;

    /**
     * Ongoing compliance page
     *
     * @return \Illuminate\Http\Response
     */
    public function showOngoingCompliance(Request $request, $location_id = '')
    {
        if ($location_id != '') {
            $location_id = base64_decode($location_id, true);
            if ($location_id) {
                if ($this->checkAccessRight('ongoing_compliance', $location_id)) {
                    $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                    $company_info_completed = ModuleCompletedStatus::where(['location_id' => $location_id, 'module' => 'company_info', 'is_completed' => 1])->first();
                    $check_is_ra_completed = ModuleCompletedStatus::where(
                        [
                            'location_id' => $location_id,
                            'module' => 'risk_analysis',
                            'is_completed' => 1,
                        ]
                    )->first();
                    if (! $check_is_ra_completed || ! $hco || ! $company_info_completed) {
                        return redirect('/dashboard');
                    }

                    return view('app.pages.ongoingcompliance', ['location_id' => $location_id]);
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /***************************/
    /*API methods - start
    /***************************/

    /**
     * Get Online compliance percentage status
     *
     * @return \Illuminate\Http\Response
     */
    public function getOnlineComplianceStatus(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $hco = HipaaComplianceOfficer::where('location_id', $request['location_id'])->first();
            $company_info_completed = ModuleCompletedStatus::where(['location_id' => $request['location_id'], 'module' => 'company_info', 'is_completed' => 1])->first();
            $check_is_ra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $request['location_id'],
                    'module' => 'risk_analysis',
                    'is_completed' => 1,
                ]
            )->first();
            if (! $check_is_ra_completed || ! $hco || ! $company_info_completed) {
                return $this->error('Complete SRA first', 200);
            }

            $data = $this->getPercentageCount($request['location_id']);

            $ongoing_location_id = $request->location_id.'_ongoing_module_access';
            if (! session($ongoing_location_id, false)) {
                session([$ongoing_location_id => true]);
                $data['first_time_og_added'] = true;
            } else {
                $data['first_time_og_added'] = false;
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('OngoingComplianceController/getOnlineComplianceStatus() => '.$e->getMessage());
            Log::error('OngoingComplianceController/getOnlineComplianceStatus()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function getPercentageCount($location_id)
    {

        $is_ra_completed = ModuleCompletedStatus::where([
            'location_id' => $location_id,
            'module' => 'risk_analysis',
            'is_completed' => 1,
        ])->count();
        $ongoing_count = OngoingRiskAnalysisQuestion::where('location_id', $location_id)->count();
        $ongoing_attempted_count = OngoingRiskAnalysisQuestion::where([
            'location_id' => $location_id,
            'is_answered' => 1,
        ])->count();
        if ($is_ra_completed == 0) {
            $percentage = 100;
        } else {
            if ($ongoing_count == 0) {
                $percentage = 100;
            } else {
                $percentage = $ongoing_count ? round(($ongoing_attempted_count / $ongoing_count) * 100) : 0;
            }
        }

        return [
            'total_ongoing_question' => $ongoing_count,
            'total_ongoing_attempted_count' => $ongoing_attempted_count,
            'percentage' => $percentage,
        ];
    }

    /**
     * load online compliance question
     *
     * @return \Illuminate\Http\Response
     */
    public function loadQuestion(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $location_id = $request['location_id'];

            $question_detail = OngoingRiskAnalysisQuestion::where([
                'location_id' => $location_id,
                'is_answered' => 0,
            ])
                ->with([
                    'riskAnalysisQuestion',
                    'riskAnalysisQuestion.riskAnalysisQuestionAnswerOptions',
                    'riskAnalysisQuestion.questionCategory',
                    'riskAnalysisQuestion.questionLawSection',
                    'riskAnalysisQuestion.riskAnalysisAttemptedQuestion' => function ($query) use ($location_id) {
                        $query->where('location_id', $location_id);
                    },
                ])
                ->orderBy('added_date', 'asc')
                ->orderBy('id', 'asc')
                ->first();
            $percentage_count = $this->getPercentageCount($location_id);
            if ($question_detail && $question_detail['question_type'] == 'ongoing') {
                if ($question_detail['riskAnalysisQuestion']['question_answer_layout'] == 'radio') {
                    $answer_id = $question_detail['riskAnalysisQuestion']['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answer_id'];
                    $remind_option = RiskAnalysisRemindOption::where('answer_option_id', $answer_id)->first();
                } else {
                    $remind_option = RiskAnalysisRemindOption::where('question_id', $question_detail['riskAnalysisQuestion']['id'])->first();
                }

                if ($remind_option) {
                    if ($remind_option['ongoing_question_id']) {
                        $Ongoing_question = OngoingQuestion::find($remind_option['ongoing_question_id']);
                        $question_detail['riskAnalysisQuestion']['question'] = $Ongoing_question['question'];
                    }
                }
            }
            unset($question_detail['riskAnalysisQuestion']['riskAnalysisAttemptedQuestion']);
            if ($question_detail && ($question_detail['riskAnalysisQuestion']['question']) && ($question_detail['riskAnalysisQuestion']['question_code'] == 'Q75S3' || $question_detail['riskAnalysisQuestion']['question_code'] == 'Q75S4' || $question_detail['riskAnalysisQuestion']['question_code'] == 'Q75S5')) {
                $ra = new SecurityRiskAnalysisController;
                $str_to_replace = $ra->getDynamicString($location_id, 'Q75');
                $question_detail['riskAnalysisQuestion']['question'] = str_replace('{%IT_PROVIDER_QUESTION%}', $str_to_replace, $question_detail['riskAnalysisQuestion']['question']);
            }
            $data = [
                'question_detail' => $question_detail,
                'percentage_count' => $percentage_count,
            ];
            if (! $question_detail || is_null($question_detail)) {
                $notification_HCE_AN7 = $this->getNotificationByCode('HCE-AN7');
                LocationNotification::where('notification_id', $notification_HCE_AN7->id)
                    ->where('location_id', $location_id)
                    ->where('is_completed', 0)
                    ->update(['is_completed' => 1]);

                $notification_HCE_AN21 = $this->getNotificationByCode('HCE-AN21');
                LocationNotification::where('notification_id', $notification_HCE_AN21->id)
                    ->where('location_id', $location_id)
                    ->where('is_completed', 0)
                    ->update(['is_completed' => 1]);
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('OngoingComplianceController/loadQuestion() => '.$e->getMessage());
            Log::error('OngoingComplianceController/loadQuestion()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * save ongoing compliance answer
     *
     * @return \Illuminate\Http\Response
     */
    public function saveAnswer(Request $request)
    {
        try {
            $validator_rules = [
                'ongoing_risk_analysis_id' => 'required',
                'location_id' => 'required',
                'question_id' => 'required',
                'answer_id' => 'required_without:answer|array',
                'answer' => 'required_without:answer_id',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $answer_fields = $request->all();
            $is_given_answer_same = false;
            DB::beginTransaction();
            $scorecard = new ScorecardController;
            $attempted_question = RiskAnalysisAttemptedQuestion::where(['question_id' => $answer_fields['question_id'], 'location_id' => $answer_fields['location_id']])->first();
            if ($attempted_question) {
                if ($request->has('note')) {
                    $attempted_question->update(['note' => $request['note']]);
                }
                $attempted_question_answer = RiskAnalysisAttemptedQuestionAnswer::where('attempted_question_id', $attempted_question['id'])->get();
                if (count($attempted_question_answer) > 0) {

                    $arr_answer = array_column($attempted_question_answer->toArray(), 'answer_id');
                    if ($request->has('answer_id') && ! empty($request['answer_id'])) {
                        if ($arr_answer != $request['answer_id']) {
                            $scorecard->addPolicyVersion($answer_fields['question_id'], $answer_fields['location_id'], $request['answer_id']);
                            RiskAnalysisPreviousAttemptedQuestionAnswer::where([
                                'question_id' => $attempted_question['question_id'],
                                'location_id' => $attempted_question['location_id'],
                            ])->delete();
                            $attempted_question_answer->each(function ($ans) use ($attempted_question) {
                                $perv_answer = [
                                    'question_id' => $attempted_question['question_id'],
                                    'location_id' => $attempted_question['location_id'],
                                    'answer_id' => $ans['answer_id'],  
                                ];
                                RiskAnalysisPreviousAttemptedQuestionAnswer::create($perv_answer);
                                $ans->delete();
                                $this->removeAnswerRecursive($attempted_question['question_id'], $ans['answer_id'], $attempted_question['location_id']);
                            });
                        } else {
                            $is_given_answer_same = true;
                        }
                    }

                    if ($request->has('answer') && ! empty($request['answer'])) {
                        if ($attempted_question_answer[0]['answer'] != $request['answer']) {
                            RiskAnalysisPreviousAttemptedQuestionAnswer::where([
                                'question_id' => $attempted_question['question_id'],
                                'location_id' => $attempted_question['location_id'],
                            ])->delete();
                            $attempted_question_answer->each(function ($ans) use ($attempted_question) {
                                $perv_answer = [
                                    'question_id' => $attempted_question['question_id'],
                                    'location_id' => $attempted_question['location_id'],
                                    'answer' => $ans['answer'],  
                                ];
                                RiskAnalysisPreviousAttemptedQuestionAnswer::create($perv_answer);
                                $ans->delete();
                            });
                        } else {
                            $is_given_answer_same = true;
                        }
                    }
                }
            } else {
                if ($request->has('answer_id') && ! empty($request['answer_id'])) {
                    $scorecard->addPolicyVersion($answer_fields['question_id'], $answer_fields['location_id'], $request['answer_id']);
                }
                $attempted_question = RiskAnalysisAttemptedQuestion::create($answer_fields);
            }
            if (! $is_given_answer_same) {
                $selected_answer = [];
                if (isset($answer_fields['answer']) && $answer_fields['answer'] != '') {
                    $selected_answer[0]['answer'] = $answer_fields['answer'];
                }
                if (isset($answer_fields['answer_id']) && is_array($answer_fields['answer_id'])) {
                    foreach ($answer_fields['answer_id'] as $key => $ans) {
                        $selected_answer[$key]['answer_id'] = $ans;
                    }
                }
                $attempted_question->attemptedQuestionAnswer()->createMany($selected_answer);

                $question_detail = RiskAnalysisQuestion::where('id', $answer_fields['question_id'])->with('remindOption')->first();
                if ($question_detail['question_answer_layout'] == 'radio') {
                    $answer_detail = RiskAnalysisQuestionAnswerOption::where('id', $answer_fields['answer_id'][0])
                        ->with('remindOption')->first();
                    if (! empty($answer_detail['remindOption']) && ($answer_detail['remindOption']['ongoing_question_id'] != null && $answer_detail['remindOption']['remind_month'] != null)) {
                        $current_date = gmdate('Y-m-d');
                        $next_remind_date = gmdate('Y-m-d', strtotime('+'.$answer_detail['remindOption']['remind_month'].' month', strtotime($current_date)));
                        $attempted_question->update(['next_remind_date' => $next_remind_date]);
                    } elseif ($attempted_question['next_remind_date'] != null) {
                        $attempted_question->update(['next_remind_date' => null]);
                    }
                } else {
                    if (! empty($question_detail['remindOption']) && ($question_detail['remindOption']['ongoing_question_id'] != null && $question_detail['remindOption']['remind_month'] != null)) {
                        $current_date = gmdate('Y-m-d');
                        $next_remind_date = gmdate('Y-m-d', strtotime('+'.$question_detail['remindOption']['remind_month'].' month', strtotime($current_date)));
                        $attempted_question->update(['next_remind_date' => $next_remind_date]);
                    } elseif ($attempted_question['next_remind_date'] != null) {
                        $attempted_question->update(['next_remind_date' => null]);
                    }
                }
            }

            OngoingRiskAnalysisQuestion::where('id', $request['ongoing_risk_analysis_id'])
                ->update(['is_answered' => 1]);

            if (! $is_given_answer_same) {
                $this->removeOngoingRecursive($answer_fields['question_id'], $request['location_id']);

                // add subquestion if any on selected answer
                if (isset($answer_fields['answer_id'])) {
                    $sub_questions = RiskAnalysisQuestion::whereIn('parent_answer_id', $answer_fields['answer_id'])
                        ->where('parent_question_id', $answer_fields['question_id'])
                        ->orderBy('display_order', 'asc')
                        ->isActive()->get();
                    if ($sub_questions) {
                        $current_ongoing_question = OngoingRiskAnalysisQuestion::where('id', $request['ongoing_risk_analysis_id'])->first();
                        $temp_data = [];
                        foreach ($sub_questions as $que) {
                            $temp_data[] = [
                                'question_id' => $que->id,
                                'location_id' => $answer_fields['location_id'],
                                'question_type' => 'normal',
                                'added_date' => $current_ongoing_question['added_date'],
                                'created_at' => Carbon::now(),
                                'updated_at' => Carbon::now(),
                            ];
                        }
                        $temp_data = OngoingRiskAnalysisQuestion::insert($temp_data);
                    }
                }
            }
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200, $answer_fields);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('OngoingComplianceController/saveAnswer() => '.$e->getMessage());
            Log::error('OngoingComplianceController/saveAnswer()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * add random ongoing question for demo accounts
     *
     * @return \Illuminate\Http\Response
     */
    public function addRandomOngoingQuestionForDemoAccount(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $randomeFRAMainQuestionList = RiskAnalysisQuestion::where('parent_question_id', null)
                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($request) {
                    return $que->where(['location_id' => $request->location_id]);
                })
                ->isActive()
                ->inRandomOrder()
                ->limit(5)
                ->get();
            $temp_data = [];
            foreach ($randomeFRAMainQuestionList as $key => $value) {
                OngoingRiskAnalysisQuestion::where([
                    'question_id' => $value->id,
                    'location_id' => $request->location_id,
                ])->delete();
                $temp_data[] = [
                    'question_id' => $value->id,
                    'location_id' => $request->location_id,
                    'question_type' => 'ongoing',
                    'added_date' => now(),
                    'created_at' => Carbon::now(),
                    'updated_at' => Carbon::now(),
                ];
            }
            $temp_data = OngoingRiskAnalysisQuestion::insert($temp_data);
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('OngoingComplianceController/addRandomOngoingQuestionForDemoAccount() => '.$e->getMessage());
            Log::error('OngoingComplianceController/addRandomOngoingQuestionForDemoAccount()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function removeAnswerRecursive($question_id, $answer_id, $location_id)
    {
        $questions = RiskAnalysisQuestion::where([
            'parent_question_id' => $question_id,
            'parent_answer_id' => $answer_id,
        ])->get();
        if (count($questions) > 0) {
            foreach ($questions as $que) {
                $attempted_question = RiskAnalysisAttemptedQuestion::where(['question_id' => $que['id'], 'location_id' => $location_id])->first();
                RiskAnalysisAttemptedQuestion::where(['question_id' => $que['id'], 'location_id' => $location_id])->delete();
                if ($attempted_question) {
                    $question_id = $attempted_question['question_id'];
                    $location_id = $attempted_question['location_id'];
                    $attempted_question_answer = RiskAnalysisAttemptedQuestionAnswer::where('attempted_question_id', $attempted_question['attempted_question_id'])->get();
                    if ($attempted_question_answer) {
                        $attempted_question_answer->each(function ($ans) use ($question_id, $location_id) {
                            $ans_id = $ans['answer_id'];
                            $ans->delete();
                            $this->removeAnswerRecursive($question_id, $ans_id, $location_id);
                        });
                    }
                }
            }
        }
    }

    private function removeOngoingRecursive($question_id, $location_id)
    {
        $ongoing_question = OngoingRiskAnalysisQuestion::where([
            'question_id' => $question_id,
            'location_id' => $location_id,
            'is_answered' => 0,
        ]);
        if ($ongoing_question) {
            $ongoing_question->delete();
        }
        $question_list = RiskAnalysisQuestion::where('parent_question_id', $question_id)->get();
        foreach ($question_list as $que) {
            $this->removeOngoingRecursive($que['id'], $location_id);
        }
    }

    /**
     * get last completed ongoing for dashboard
     */
    public function getLastCompletedOngoing($location_id)
    {
        $ongoing_ra = OngoingRiskAnalysisQuestion::select('updated_at')->where('location_id', $location_id)->orderBy('updated_at', 'desc')->limit(1)->withTrashed()->first();
        if ($ongoing_ra) {
            return $ongoing_ra->updated_at;
        } else {
            return '';
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
