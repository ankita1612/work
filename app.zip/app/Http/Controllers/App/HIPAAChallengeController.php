<?php

namespace App\Http\Controllers\app;

use App\Http\Controllers\Controller;
use App\Models\EmailTemplate;
use App\Models\HipaaChallengeAttemptedQuestion;
use App\Models\HipaaChallengeGradingScale;
use App\Models\HipaaChallengeQuestion;
use App\Models\HipaaChallengeVisitor;
use App\Models\Partner;
use App\Models\State;
use App\Traits\ApiResponser;
use App\Traits\FileUpload;
use App\Traits\SendMail;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class HIPAAChallengeController extends Controller
{
    use ApiResponser, FileUpload, SendMail;

    /**
     * Hipaa Challenge page
     */
    public function showHipaaChallange(Request $request, $partner = null)
    {
        return view('app.pages.hipaachallenge');
    }

    /**
     * Hipaa Challenge page
     */
    public function showSelectState(Request $request)
    {
        return view('app.pages.selectState', ['is_state_page' => true]);
    }

    /**
     * hipaa challenge question
     *
     * @return \Illuminate\Http\Response
     */
    public function loadHipaaChallengeQuestion(Request $request)
    {
        try {
            $validator_rules = [
                'pagination_type' => 'required|in:next,first',
                'attempted_questions' => 'nullable|array',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $question_id = $request->has('question_id') ? $request['question_id'] : null;
            $answer_id = $request->has('answer_id') ? $request['answer_id'] : null;
            $pagination_type = $request->has('pagination_type') ? $request['pagination_type'] : 'next';
            $percentage_count = $this->getPercentageCount($request['attempted_questions']);
            if ($pagination_type == 'first') {
                $question_detail = HipaaChallengeQuestion::with(['hipaaChallengeQuestionAnswerOptions'])
                    ->isActive()->orderBy('display_order', 'asc')->first();
            } elseif ($pagination_type == 'next') {
                $question_detail = $this->getNextQuestion($question_id, $answer_id);
            }

            $data = [
                'question_detail' => $question_detail,
                'percentage_count' => $percentage_count,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('HipaaChallengeController/loadHipaaChallengeQuestion() => '.$e->getMessage());
            Log::error('HipaaChallengeController/loadHipaaChallengeQuestion()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Get Next Question
     */
    public function getNextQuestion($question_id, $answer_id)
    {
        $current_question = HipaachallengeQuestion::where('id', $question_id)->first();
        if ($current_question) {
            $question = HipaachallengeQuestion::with(['hipaaChallengeQuestionAnswerOptions'])
                ->where('parent_question_id', $question_id)
                ->where('parent_answer_id', $answer_id)
                ->isActive()
                ->orderBy('display_order', 'asc')
                ->first();
            if (! $question) {
                $question = HipaachallengeQuestion::with(['hipaaChallengeQuestionAnswerOptions'])
                    ->where('parent_question_id', $current_question['parent_question_id'])
                    ->where('display_order', '>', $current_question['display_order'])
                    ->where('level', '=', $current_question['level'])
                    ->isActive()
                    ->orderBy('display_order', 'asc')
                    ->first();
                if (! $question) {
                    $parent_question = HipaachallengeQuestion::where('id', $current_question['parent_question_id'])->first();
                    if ($parent_question != null) {
                        $question = HipaachallengeQuestion::with(['hipaaChallengeQuestionAnswerOptions'])
                            ->where('parent_question_id', $parent_question['parent_question_id'])
                            ->where('display_order', '>', $parent_question['display_order'])
                            ->where('level', '=', $parent_question['level'])
                            ->isActive()
                            ->orderBy('display_order', 'asc')
                            ->first();
                    } else {
                        return null;
                    }
                }
            }

            return $question;
        }

        return null;
    }

    /**
     * List all states
     *
     * @return \Illuminate\Http\Response
     */
    public function listStates(Request $request)
    {
        try {
            $list = State::select(['id', 'state_code', 'state_name'])
                ->with('calendlyLink')
                ->orderBy('state_name')
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('GeneralController/listStates() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    public function saveAnswers(Request $request)
    {
        try {
            $validator_rules = [
                'contact_info.company_name' => 'required',
                'contact_info.contact_name' => 'required',
                'contact_info.email' => 'required',
                'quiz_info.*.question_id' => 'required',
                'quiz_info.*.answer_id' => 'required',
                'quiz_info.*.answer_type' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $input_fields = $request->all();
            foreach ($input_fields['quiz_info'] as $key => $val) {
                if (isset($val['answer_type']) && $val['answer_type'] == 'state') {
                    $input_fields['quiz_info'][$key]['answer_type'] = \App\Models\State::class;
                } else {
                    $input_fields['quiz_info'][$key]['answer_type'] = \App\Models\HipaaChallengeQuestionAnswerOption::class;
                }
            }
            DB::beginTransaction();
            $visitors = HipaaChallengeVisitor::create($input_fields['contact_info']);
            $visitors->attemptedQuestion()->createMany($input_fields['quiz_info']);
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200, $visitors);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('HipaaChallengeController/saveAnswers() => '.$e->getMessage());
            Log::error('HipaaChallengeController/saveAnswers()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Get Percentage Count
     *
     * @param  \Illuminate\Http\Request  $request
     */
    public function getPercentageCount($attempted_que)
    {
        $all_question_ids = HipaaChallengeQuestion::isActive()->pluck('id')->toArray();

        $ids = array_column($attempted_que, 'question_id');
        $attempted_questions = HipaaChallengeQuestion::isActive()
            ->with('childQuestionNested')
            ->where('level', 1)
            ->whereIn('id', $ids)
            ->get();
        $attempted_question_ids = $attempted_questions->pluck('id')->toArray();
        $this->getRecursiveCountOfQuestion($attempted_questions, $attempted_question_ids);
        $attempted_with_total_child = $attempted_question_ids;
        foreach ($attempted_que as $que) {
            $sub_question = HipaaChallengeQuestion::where([
                'parent_question_id' => $que['question_id'],
                'parent_answer_id' => $que['answer_id'],
            ])->isActive()->get();
            foreach ($sub_question as $sq) {
                $key = array_search($sq['id'], $ids);
                if (! $key) {
                    if ($key = array_search($sq['id'], $attempted_question_ids)) {
                        unset($attempted_question_ids[$key]);
                    }
                }
            }
        }

        $total_questions = count($all_question_ids);
        $attempted_questions_count = count($attempted_question_ids);

        if ($total_questions > 0) {
            $per = ($attempted_questions_count / $total_questions) * 100;
        } else {
            $per = 0;
        }

        return [
            'total_questions' => $total_questions,
            'attempted_questions' => $attempted_questions_count,
            'percentage' => round($per),
        ];
    }

    /**
     * Get Recursive Count Of Question
     */
    private function getRecursiveCountOfQuestion($questions, &$attempted_question_ids)
    {
        foreach ($questions as $que) {
            if (! in_array($que['id'], $attempted_question_ids)) {
                $attempted_question_ids[] = $que['id'];
            }
            if (count($que->childQuestionNested) > 0) {
                $this->getRecursiveCountOfQuestion($que->childQuestionNested, $attempted_question_ids);
            }
        }
    }

    /**
     * Generate visitor scorecard
     *
     * @return \Illuminate\Http\Response
     */
    public function generateVisitorScorecard(Request $request)
    {
        try {
            $validator_rules = [
                'visitor_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $attempted_ans = HipaaChallengeAttemptedQuestion::where('visitor_id', $request['visitor_id'])
                ->with('answer')
                ->get();
            $data['area_of_concern_count'] = 0;
            foreach ($attempted_ans as $attempted_answer) {
                if (isset($attempted_answer['answer']) && $attempted_answer['answer'] != null && $attempted_answer['answer']['area_of_concern'] != null) {
                    $data['area_of_concern_count']++;
                    break;
                }
            }
            $visitor = HipaaChallengeVisitor::find($request['visitor_id']);
            $data['attempted_answers'] = $attempted_ans;
            $data['visitor'] = $visitor;
            $data['total_score'] = HipaaChallengeQuestion::sum('total_possible_points');
            $data['attempted_answers_score'] = $attempted_ans->sum('answer.point');
            $data['grade_scale'] = $this->calculateGrade($data['total_score'], $data['attempted_answers_score']);
            // hipaa challenge scorecard pdf
            $pdf = PDF::loadView('reports/hipaachallengescorecard', $data);
            $local_pdf_url = storage_path('app/public').'/generatedpolicydocuments/'.$request['visitor_id'].'_hipaa_challenge_scorecard.pdf';
            $pdf->save($local_pdf_url);
            $s3_scorecard_path = '/hipaachallenge/'.$request['visitor_id'].'_hipaa_challenge_scorecard.pdf';
            Storage::disk('s3')->put($s3_scorecard_path, file_get_contents($local_pdf_url));
            $data['download_url'] = $this->getSignedURL($s3_scorecard_path);
            $visitor->update([
                'scorecard' => $request['visitor_id'].'_hipaa_challenge_scorecard.pdf',
            ]);

            $state = HipaaChallengeAttemptedQuestion::where('visitor_id', $visitor->id)
                ->where('answer_type', 'LIKE', '%State%')
                ->with('answer')
                ->first();

            $emailTemplateAdmin = EmailTemplate::where('code', 'HCE-AE7')->first();
            $state_name = '';
            if ($state != null && isset($state->answer)) {
                $state_name = $state->answer->state_name;
            }
            $email_vars_admin = [
                '{%VISITOR_COMPANY_NAME%}' => $visitor['company_name'],
                '{%VISITOR_EMAIL%}' => $visitor['email'],
                '{%VISITOR_NAME%}' => $visitor['contact_name'],
                '{%STATE_ANSWER%}' => $state_name,
            ];
            $html_admin = str_ireplace(array_keys($email_vars_admin), array_values($email_vars_admin), $emailTemplateAdmin->body);
            $this->sendEmail($emailTemplateAdmin->code, $html_admin, Config::get('app.sales_group_email'), Config::get('app.expert_email'), $emailTemplateAdmin->subject, $local_pdf_url, [Config::get('app.salesadmin_cc_email')]);

            $emailTemplateUser = EmailTemplate::where('code', 'HCE-UE33')->first();

            $email_vars_user = [
                '{%VISITOR_NAME%}' => $visitor['contact_name'],
                '{%HIPAA_CHALLENGE%}' => Config::get('app.wordpress_url'),
                '{%SELECT_STATE_URL%}' => URL::to('/hipaachallenge/selectstate'),
            ];
            $html_user = str_ireplace(array_keys($email_vars_user), array_values($email_vars_user), $emailTemplateUser->body);
            $this->sendEmail($emailTemplateUser->code, $html_user, $visitor->email, Config::get('app.from_user_email'), $emailTemplateUser->subject, $local_pdf_url);

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {

            Log::error('HipaaChallengeController/generateVisitorScorecard() => '.$e->getMessage());
            Log::error('HipaaChallengeController/generateVisitorScorecard()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * calculate grade
     *
     * @param  \Illuminate\Http\Request  $request
     */
    private function calculateGrade($total_score, $attempted_answers_score)
    {
        $grade_percent = round(($attempted_answers_score / $total_score) * 100);
        $result = HipaaChallengeGradingScale::whereRaw('? between min_percent_range and max_percent_range', [$grade_percent])->first();

        $result['grade_percent'] = $grade_percent;

        return $result;
    }

    /**
     * hipaa challenge question
     *
     * @return \Illuminate\Http\Response
     */
    public function partnerInfo(Request $request)
    {
        try {
            $validator_rules = [
                'slug' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $partner = Partner::where('slug', $request['slug'])->whereHas('hipaaChallengePartnerAccess')->first();

            return $this->success(Config::get('constants.SUCCESS'), 200, $partner);
        } catch (\Exception $e) {
            Log::error('HipaaChallengeController/partnerInfo() => '.$e->getMessage());
            Log::error('HipaaChallengeController/partnerInfo()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
}
