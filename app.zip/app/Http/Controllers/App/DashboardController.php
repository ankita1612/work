<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Imports\LocationImport;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AccountUser;
use App\Models\AccountUserLocationAccess;
use App\Models\AutorenewalReviewPopupTracks;
use App\Models\BaPromotionResponse;
use App\Models\EmailTemplate;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\LocationNotification;
use App\Models\NewChangesPopupTracks;
use App\Models\SharedEmailPopupTracks;
use App\Models\User;
use App\Models\UserBadgeEmailHistory;
use App\Traits\ApiResponser;
use App\Traits\GeneratePolicy;
use App\Traits\GetLoginUserData;
use App\Traits\GetMainUserData;
use App\Traits\Notification;
use App\Traits\ChargebeePlan;
use App\Traits\SendMail;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\HeadingRowImport;
use Carbon\Carbon;

class DashboardController extends Controller
{
    use ApiResponser, GeneratePolicy, GetLoginUserData, GetMainUserData, Notification, SendMail,ChargebeePlan;

    /**
     * Dashboard page
     *
     * @return \Illuminate\Http\Response
     */
    public function showDashboard(Request $request)
    {
        if (! empty(auth()->guard('account_user')->user())) {
            $user_data = $this->getMainAccountDetails();
            $total_location = Location::where('user_id', $user_data['id'])->count();
            $is_access_location = AccountUserLocationAccess::where('account_user_id', auth()->guard('account_user')->user()->id)->count();
            $subscription = $this->getSubscriptionDetails($user_data['chargebee_subscription_id']);
            $location_limit = $subscription['location_limit'];
            if ((int) $location_limit > (int) $total_location || $user_data->account_status == 'Frozen' || ! $user_data->is_active || ! $user_data->is_account_verified || $is_access_location == 0) {
                Auth::logout();

                return redirect()->route('login');
            }
        }
        if (! empty(auth()->guard('user')->user())) {
            $user_data = $this->getMainAccountDetails();
            if (! $user_data->is_active || ! $user_data->is_account_verified) {
                Auth::logout();

                return redirect()->route('login');
            }
        }
        $successMessage = $request->query('success');
        return view('app.pages.dashboard',[
            'success_message' => $successMessage
        ]);
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Logout
     *
     * @return \Illuminate\Http\Response
     */
    public function doLogout(Request $request)
    {
        try {
            $request->session()->forget('is_admin_panel_login');
            $request->session()->forget('show_company_info_modal');
            $request->session()->save();
            Auth::logout();

            return $this->success(Config::get('constants.SUCCESS'), 200);
        } catch (\Exception $e) {
            Log::error('DashboardController/doLogout() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Location Limit Count
     *
     * @return \Illuminate\Http\Response
     */
    public function LocationLimitCount(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $total_location = Location::where('user_id', $user_data['id'])->count();
            $subscription = $this->getSubscriptionDetails($user_data['chargebee_subscription_id']);
            $location_limit = $subscription['location_limit'];
            $data = [
                'location_limit' => $location_limit,
                'location_count' => $total_location,
                'sample_import_doc' => url('/sample_docs/location_template.xlsx'),
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('DashboardController/LocationLimitCount() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Add Locations
     *
     * @return \Illuminate\Http\Response
     */
    public function addLocations(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $total_location = Location::where('user_id', $user_data['id'])->count();
            
            $subscription = $this->getSubscriptionDetails($user_data['chargebee_subscription_id']);
            $location_limit = $subscription['location_limit'];
            
                       
            $remaining_location = $location_limit - $total_location;

            if ($remaining_location <= 0) {
                return $this->error(Config::get('constants.LOCATION.LIMIT_EXCEEDED'), 200);
            }

            if (count($request['locations']) != $remaining_location) {
                return $this->error(Config::get('constants.LOCATION.COUNT_MUST_SAME'), 200);
            }

            $validator_rules = [
                'locations' => 'required|array',
                'locations.*.location_nickname' => 'required|distinct|unique:App\Models\Location,location_nickname,NULL,location_id,deleted_at,NULL,user_id,'.$user_data['id'],
            ];

            $custom_messages = [
                'locations.*.location_nickname.unique' => 'Location name :input has already been taken. Please try again.',
                'locations.*.location_nickname.distinct' => 'Location name :input has a duplicate value. Please try again.',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules, $custom_messages);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $data = [];
            $location = [];
            $notification_HCE_AN2 = $this->getNotificationByCode('HCE-AN2');
            foreach ($request['locations'] as $key => $loc) {
                try {
                    $data[$key] = Location::create([
                        'user_id' => $user_data['id'],
                        'company_name' => $user_data['company_name'],
                        'location_nickname' => $loc['location_nickname'],
                        'salesforce_unique_id' => ($total_location == 0 && $key == 0) ? $user_data['primary_location_salesforce_unique_id'] : null,
                        'training_anchor_date' => Carbon::now(),
                    ]);

                    $notification_HCE_AN2_data = [
                        'location_id' => $data[$key]['id'],
                        'notification_id' => $notification_HCE_AN2['id'],
                    ];
                    $this->createNotification($notification_HCE_AN2_data);

                    array_push($location, ['location_id' => $data[$key]['id']]);
                } catch (\Exception $e) {
                    Log::error('DashboardController/addLocations()[locations_error] => '.$e->getMessage());
                    Log::error('DashboardController/addLocations()[locations_data] => '.json_encode($loc));
                }
            }

            // Update Account User
            $all_location_access_account_user = AccountUser::where('user_id', $user_data['id'])
                ->withCount('accountLocationAccess')->get();

            $all_location_access_account_user = $all_location_access_account_user->where('account_location_access_count', $total_location)->all();
            foreach ($all_location_access_account_user as $key => $acc_user) {
                $update_acc_user_location = AccountUser::where('id', $acc_user['id'])->first();
                $update_acc_user_location = $update_acc_user_location->accountLocationAccess()->createMany($location);
            }

            return $this->success(Config::get('constants.LOCATION.LOCATION_ADDED'), 200, $data);
        } catch (\Exception $e) {
            Log::error('DashboardController/addLocations() => '.$e->getMessage());
            Log::error('DashboardController/addLocations()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Location List
     *
     * @return \Illuminate\Http\Response
     */
    public function listLocations(Request $request)
    {
        try {
            $generalController = new GeneralController;
            $location_access_list = $generalController->getAssingedLocationList();
            $location_list = Location::whereIn('id', $location_access_list)
                ->select(['id', 'location_nickname', 'ce_type_id', 'updated_at'])
                ->withCount('companyModuleCompleted')
                ->withCount('disasterRecoveryPlanModuleCompleted')
                ->with('sraModuleCompleted', 'locationModuleLastUpdate', 'ongoingRiskAnalysisQuestion')
                ->with([
                    'hipaaComplianceOfficer.hco', 'accountLocationAccess.accountUser', 'employeePrimaryWorkLocation',
                    'employeeSecondaryWorkLocation', 'localFirstResponder', 'businessAssociatesUser',
                    'studentPrimaryWorkLocation',
                ])
                ->withCount('high_risk')
                ->withCount('medium_risk')
                ->withCount('low_risk')
                ->withCount('openNotifications')
                ->withCount('trainingLocation')
                ->withCount('activeEmployeePrimaryWorkLocation')
                ->withCount('businessAssociatesLocation')
                ->withCount('contributorLocation');
            if ($request->has('q') && $request['q'] != '') {
                $location_list = $location_list->where('location_nickname', 'LIKE', '%'.$request['q'].'%');
            }

            if ($request->has('user_id') && $request['user_id'] != '') {
                if ($request->has('user_type') && $request['user_type'] == 'user') {
                    $location_list = $location_list->whereHas('hipaaComplianceOfficer', function ($q) use ($request) {
                        $q->where('hco_id', $request['user_id']);
                        $q->where('hco_type', \App\Models\User::class);
                    });
                }
                if ($request->has('user_type') && $request['user_type'] == 'account_user') {
                    $location_list = $location_list->whereHas('hipaaComplianceOfficer', function ($q) use ($request) {
                        $q->where('hco_id', $request['user_id']);
                        $q->where('hco_type', \App\Models\AccountUser::class);
                    });
                }
            }
            if ($request->has('sort_by') && ! empty($request['sort_by']) && $request->has('sort_by_dir') && ! empty($request['sort_by_dir'])) {
                if ($request['sort_by'] == 'location_name') {
                    $location_list = $location_list->orderBy('location_nickname', $request['sort_by_dir'])->orderBy('id', $request['sort_by_dir']);
                }
                if ($request['sort_by'] == 'open_notifications') {
                    // order by open noti. count
                    $location_list = $location_list->orderBy('open_notifications_count', $request['sort_by_dir'])->orderBy('id', $request['sort_by_dir']);
                }
                if ($request['sort_by'] == 'risk_levels') {
                    // order by scorecard risk levels que. count
                    $location_list = $location_list->orderBy('high_risk_count', $request['sort_by_dir'])->orderBy('id', $request['sort_by_dir']);
                }
            } else {
                $location_list = $location_list->orderBy('id', 'ASC');
            }
            $limit = $request->has('per_page') ? request('per_page') : Config::get('constants.PER_PAGE');
            $location_list = $location_list->paginate($limit);
            $account_user = new AccountUserController;
            $sra = new SecurityRiskAnalysisController;
            $employee = new EmployeeController;
            $student = new StudentController;
            $disaster = new DisasterRecoveryPlanController;
            $ongoing_compliance = new OngoingComplianceController;
            $business_associates = new BusinessAssociatesController;
            $training = new TrainingController;
            $policy = new PolicyController;
            $notification = new NotificationController;
            $hipaa_logs = new HipaaLogController;
            foreach ($location_list as $key => $val) {
                try {
                    $location_list[$key]['accountuser_last_updated'] = $val->locationModuleLastUpdate->where('module_name', 'account_user')->first()->updated_at ?? '';
                    $location_list[$key]['sra_percentage_count'] = ($val->sraModuleCompleted && $val->sraModuleCompleted->is_completed == 1) ? (object) ['percentage' => 100] : $sra->getPercentageCount($val->id);
                    $location_list[$key]['scorecard_last_updated'] = $val->locationModuleLastUpdate->where('module_name', 'scorecard')->first()->updated_at ?? '';
                    $location_list[$key]['employee_last_updated'] = $val->locationModuleLastUpdate->where('module_name', 'employee')->first()->updated_at ?? '';
                    $location_list[$key]['student_last_updated'] = $val->locationModuleLastUpdate->where('module_name', 'student')->first()->updated_at ?? '';
                    $location_list[$key]['disaster_last_updated'] = $val->locationModuleLastUpdate->where('module_name', 'disaster')->first()->updated_at ?? '';
                    $location_list[$key]['ongoing_last_completed'] = $val->ongoingRiskAnalysisQuestion->sortByDesc('updated_at')->first()->updated_at ?? '';
                    $location_list[$key]['ongoing_compliance_percentage_count'] = $ongoing_compliance->getPercentageCount($val->id);
                    $location_list[$key]['business_associates_last_updated'] = $business_associates->getLastUpdatedBusinessAssociates($val->id);
                    $location_list[$key]['training_last_updated'] = $val->locationModuleLastUpdate->where('module_name', 'training')->first()->updated_at ?? '';
                    $location_list[$key]['training_counts'] = $training->getTrainingCount($val->id);
                    $location_list[$key]['policy_last_updated'] = $policy->getLastUpdatedPolicy($val->id);
                    $location_list[$key]['hipaa_log_last_updated'] = $val->locationModuleLastUpdate->where('module_name', 'hipaa_logs')->first()->updated_at ?? '';
                    $location_list[$key]['notification'] = $notification->openNotificationlist($val->id);
                    // $low_risk_count = 0;
                    // $medium_risk_count = 0;
                    // $high_risk_count = 0;
                    // foreach ($val['attemptedQuestion'] as  $list) {
                    //     if ($list['question']['question_answer_layout'] == 'radio') {
                    //         $answer = $list['attemptedQuestionAnswer'][0]['answerContent'];
                    //         $score = $answer['score'];
                    //         switch ($score) {
                    //             case 1:
                    //             case 2:
                    //             case 3:
                    //                 $low_risk_count++;
                    //                 break;
                    //             case 4:
                    //             case 5:
                    //             case 6:
                    //                 $medium_risk_count++;
                    //                 break;
                    //             case 7:
                    //             case 8:
                    //             case 9:
                    //             case 10:
                    //                 $high_risk_count++;
                    //                 break;
                    //         }
                    //     }
                    // }
                    // $location_list[$key]['attemptedQuestion']['low_risk_count'] = $low_risk_count;
                    // $location_list[$key]['attemptedQuestion']['medium_risk_count'] = $medium_risk_count;
                    // $location_list[$key]['attemptedQuestion']['high_risk_count'] = $high_risk_count;
                } catch (\Exception $e) {
                    Log::error('DashboardController/listLocations()[location_list_error] => '.$e->getMessage());
                    Log::error('DashboardController/listLocations()[location_list_data] => '.json_encode($val));
                }
            }
            $data = [
                'location_list' => $location_list,
                'sample_import_doc' => url('/sample_docs/location_template.xlsx'),
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('DashboardController/listLocations() => '.$e->getMessage());
            Log::error('DashboardController/listLocations()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * Import location from file
     *
     * @return \Illuminate\Http\Response
     */
    public function importLocations(Request $request)
    {
        $validator_rules = [
            'import_file' => 'required|mimes:xls,xlsx',
        ];

        $validator_rules_messages = [
            'import_file.mimes' => 'Please check your file is invalid format as per sample attached.',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules, $validator_rules_messages);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        // check exce sheet format
        $headings = (new HeadingRowImport)->toArray($request['import_file']);
        if ($headings[0][0][0] != 'location_nickname') {
            return $this->error(Config::get('constants.LOCATION.IMPORT_FILE_INVALID_TEMPLETE'), 200);
        }
        try {
            if ($request->has('import_file')) {
                // import location
                $import = new LocationImport;
                $import->import($request['import_file']);
                if ($import->row_count == 0) {
                    return $this->error(Config::get('constants.LOCATION.IMPORT_ERROR'), 200);
                }
                if ($import->row_count == $import->total_row_count) {
                    return $this->success(Config::get('constants.LOCATION.IMPORTED_SUCCESS'), 200);
                } else {
                    return $this->success(Config::get('constants.LOCATION.PARTIALLY_IMPORT_ERROR'), 200);
                }
            }
        }
        // if limit exception error then return
        catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            Log::error('DashboardController/importLocations(LocationImport) => '.$e->getMessage());
            Log::error('DashboardController/importLocations()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.LOCATION.IMPORT_ERROR'), 200);
        } catch (\Exception $e) {
            if ($e->getMessage() == 'location_limit_exceeded') {
                return $this->error(Config::get('constants.LOCATION.COUNT_MUST_SAME'), 200);
            } else {
                Log::error('DashboardController/importLocations(error) => '.$e->getMessage());
                Log::error('DashboardController/importLocations()[data] => '.json_encode($request->all()));

                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        }
    }

    /**
     * List account user list
     *
     * @return \Illuminate\Http\Response
     */
    public function listAccountUsers(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            // get account users
            $account_user = AccountUser::where('user_id', $user_data['id'])
                ->select(['id', 'first_name', 'last_name'])->orderBy('id', 'desc')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $account_user);
        } catch (\Exception $e) {
            Log::error('DashboardController/listAccountUsers() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * Selected HCO user
     *
     * @return \Illuminate\Http\Response
     */
    public function getAllSelectedHCOUser(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();

            $generalController = new GeneralController;
            $location_access_list = $generalController->getAssingedLocationList();

            // get user which selected as hco
            $user = User::select(['id', 'first_name', 'last_name', DB::raw('"user" AS type')])
                ->whereHas('hipaaComplianceOfficer', function ($q) use ($location_access_list) {
                    $q->whereIn('location_id', $location_access_list);
                })
                ->find($user_data['id']);

            // get account user which selected as hco
            $account_user = AccountUser::select(['id', 'first_name', 'last_name', DB::raw('"account_user" AS type')])
                ->whereHas('hipaaComplianceOfficer', function ($q) use ($location_access_list) {
                    $q->whereIn('location_id', $location_access_list);
                })
                ->where('user_id', $user_data['id'])->get();

            $data = [
                'user' => $user,
                'account_user' => $account_user,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('DashboardController/getAllSelectedHCOUser() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get users list for hco
     *
     * @return \Illuminate\Http\Response
     */
    public function userListForHCO(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            // get user details for this location id
            $user_data = $this->getMainAccountDetails();
            $user = User::select(['id', 'first_name', 'last_name', DB::raw('"user" As hco_type'), DB::raw('CONCAT(id, "_", "user") AS unique_id')])
                ->find($user_data['id']);

            // get account user details for this location
            $account_user = AccountUser::select(['id', 'first_name', 'last_name', DB::raw('"account_user" As hco_type'), DB::raw('CONCAT(id, "_", "account_user") AS unique_id')])
                ->whereHas('accountLocationAccess', function ($q) use ($request) {
                    $q->where('location_id', $request['location_id']);
                })->orderBy('id', 'desc')->get();

            $data = [
                'user' => $user,
                'account_user' => $account_user,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('DashboardController/userListForHCO() => '.$e->getMessage());
            Log::error('DashboardController/userListForHCO()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * set hco for locations
     *
     * @return \Illuminate\Http\Response
     */
    public function setHCO(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'user_id' => 'required',
                'user_type' => 'required|in:user,account_user',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            DB::beginTransaction();
            $training_controller = new TrainingController;
            $user_data = $this->getMainAccountDetails();
            $old_hco_data = HipaaComplianceOfficer::where('location_id', $request['location_id'])->first();
            if ($old_hco_data == null) {
                $first_time_hco_added = true;
            } else {
                $first_time_hco_added = false;
            }

            // add policy, procedure, form versioning
            if (! $old_hco_data || ($old_hco_data && ($old_hco_data->hco_id != $request['user_id'] || ($request['user_type'] == 'account_user' && $old_hco_data->hco_type == \App\Models\User::class) || ($request['user_type'] == 'account_user' && $old_hco_data->hco_type == \App\Models\User::class)))) {
                $policy_array = ['DRP', 'SPP', 'ETP', 'HNEP', 'PMP', 'PCFP', 'SAP', 'SATP', 'SRA'];
                foreach ($policy_array as $policy) {
                    $this->addPolicyVersionData($policy, $request['location_id']);
                }
            }
            // if hco is user
            if ($request['user_type'] == 'user') {
                HipaaComplianceOfficer::where('location_id', $request['location_id'])->delete();
                $user = User::find($request['user_id']);
                if ($user) {
                    $user->hipaaComplianceOfficer()->create(['location_id' => $request['location_id']]);
                    //Add in unassigned Training
                    $training_controller->addToUnassignedTraining($request['location_id'], $request['user_id'], \App\Models\User::class);
                }
            }

            // if hco is account user
            if ($request['user_type'] == 'account_user') {
                HipaaComplianceOfficer::where('location_id', $request['location_id'])->delete();
                $account_user = AccountUser::find($request['user_id']);
                if ($account_user) {
                    $account_user->hipaaComplianceOfficer()->create(['location_id' => $request['location_id']]);
                    //Add in unassigned Training
                    $training_controller->addToUnassignedTraining($request['location_id'], $request['user_id'], \App\Models\AccountUser::class);
                }
            }
            $new_hco_data = hipaaComplianceOfficer::with(['hco'])->where('location_id', $request['location_id'])->with('hco')->first();

            $location = Location::findOrFail($request->location_id);
            $email_send_user_list[] = ['first_name' => $user_data->first_name, 'email' => $user_data->email];
            if ($user_data->email != $new_hco_data->hco->email) {
                $email_send_user_list[] = ['first_name' => $new_hco_data->hco->first_name, 'email' => $new_hco_data->hco->email];
            }

            $notification_HCE_AN3 = $this->getNotificationByCode('HCE-AN3');
            if ($this->checkNotificationAlreadyAdded($notification_HCE_AN3->code, $request['location_id']) == 0) {
                $notification_HCE_AN3_data = [
                    'location_id' => $request['location_id'],
                    'notification_id' => $notification_HCE_AN3['id'],
                ];
                $this->createNotification($notification_HCE_AN3_data);
            }
            $notification_HCE_AN5 = $this->getNotificationByCode('HCE-AN5');
            if ($this->checkNotificationAlreadyAdded($notification_HCE_AN5->code, $request['location_id']) == 0 && $user_data->is_sra_user == 0) {
                $notification_HCE_AN5_data = [
                    'location_id' => $request['location_id'],
                    'notification_id' => $notification_HCE_AN5['id'],
                ];
                $this->createNotification($notification_HCE_AN5_data);
            }
            if ($user_data['is_educational_account'] == 1 && $user_data->is_sra_user == 0) {
                $notification_HCE_AN39 = $this->getNotificationByCode('HCE-AN39');
                if ($this->checkNotificationAlreadyAdded($notification_HCE_AN39->code, $request['location_id']) == 0) {
                    $notification_HCE_AN39_data = [
                        'location_id' => $request['location_id'],
                        'notification_id' => $notification_HCE_AN39['id'],
                    ];
                    $this->createNotification($notification_HCE_AN39_data);
                    // send HCE-UE47
                    $emailTemplate_HCE_UE47 = EmailTemplate::where('code', 'HCE-UE47')->first();
                    foreach ($email_send_user_list as $key => $value) {
                        $email_vars = [
                            '{%FIRST_NAME%}' => $value['first_name'],
                            '{%LOG_IN_TO_ABYDE%}' => Config::get('app.url'),
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate_HCE_UE47->body);
                        $html_subject = str_ireplace(['{%LOCATION_NAME%}'], [$location->location_nickname], $emailTemplate_HCE_UE47->subject);
                        $this->sendEmail($emailTemplate_HCE_UE47->code, $html, $value['email'], Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                    }
                }
            }
            if ($old_hco_data && $new_hco_data && ($old_hco_data->hco_id != $new_hco_data->hco_id || $old_hco_data->hco_type != $new_hco_data->hco_type)) {
                $location = Location::findOrFail($request->location_id);
                $emailTemplateAdmin = EmailTemplate::where('code', 'HCE-AE15')->first();
                $email_vars_admin = [
                    '{%HCO_NAME%}' => $new_hco_data->hco->first_name.' '.$new_hco_data->hco->last_name,
                    '{%HCO_EMAIL%}' => $new_hco_data->hco->email,
                    '{%COMPANY_NAME%}' => $location->company_name,
                    '{%LOCATION_NAME%}' => $location->location_nickname,
                    '{%PREVIOUS_HCO_NAME%}' => $old_hco_data->hco->first_name.' '.$old_hco_data->hco->last_name,
                ];
                $email_vars_admin['{%USER_NAME%}'] = 'Admin';
                $html_admin = str_ireplace(array_keys($email_vars_admin), array_values($email_vars_admin), $emailTemplateAdmin->body);

                if ($user_data->partner_reseller_id != null) {
                    $email_subject = [
                        '{%RESELLER%}' => $user_data->reseller->name,
                        '{%LOCATION_NAME%}' => $location->location_nickname,
                    ];
                    $admin_subject = str_ireplace(array_keys($email_subject), array_values($email_subject), $emailTemplateAdmin->reseller_subject);
                } else {
                    $admin_subject = str_ireplace(['{%LOCATION_NAME%}'], [$location->location_nickname], $emailTemplateAdmin->subject);
                }
                $this->sendEmail($emailTemplateAdmin->code, $html_admin, Config::get('app.cs_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));

                //send mail to partner start
                if ($user_data->partner_reseller_id != null && $user_data->reseller->email != '') {
                    $this->sendEmail($emailTemplateAdmin->code, $html_admin, $user_data->reseller->email, Config::get('app.from_admin_email'), $admin_subject, null, null, true, $user_data->reseller->logo);
                }
                //send mail to partner end
            }
            $notification_HCE_AN2 = $this->getNotificationByCode('HCE-AN2');
            LocationNotification::where('notification_id', $notification_HCE_AN2->id)
                ->where('location_id', $request['location_id'])
                ->where('is_completed', 0)
                ->update(['is_completed' => 1]);
            $SF_location = Location::where('id', $request['location_id'])->whereNotNull('salesforce_unique_id')->first();
            if ($SF_location) {
                SendLocationDataToSalesForce::dispatch($SF_location->id);
            }
            $notification = new NotificationController;
            $location_notification = $notification->openNotificationlist($request['location_id']);
            $open_notifiction_count = $location_notification->count();
            $data = [
                'first_time_hco_added' => $first_time_hco_added,
                'hco' => $new_hco_data,
                'notification' => $location_notification,
                'open_notifications_count' => $open_notifiction_count,
                'training_counts' => $training_controller->getTrainingCount($location->id),
            ];
            DB::commit();

            return $this->success(Config::get('constants.LOCATION.HCO_SET_SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('DashboardController/setHCO() => '.$e->getMessage());
            Log::error('DashboardController/setHCO()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Set Account users
     *
     * @return \Illuminate\Http\Response
     */
    public function setAccountUser(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'account_user_id' => 'sometimes|array',
                'account_user_id_removed' => 'sometimes|array',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $input_fields = $request->all();
            
            //not allowing HCO to delete
            $location_HCO = HipaaComplianceOfficer::where('hco_type', \App\Models\AccountUser::class)
                    ->where('location_id', $input_fields['location_id'])
                    ->pluck('hco_id');           
            if(!empty($location_HCO) && count($location_HCO)>0 && !empty($input_fields['account_user_id_removed'])){                
                if(in_array($location_HCO[0],$input_fields['account_user_id_removed'])){
                    return $this->error(Config::get('constants.ACCOUNT_USER.CANNOT_DELETE_HCO'), 200);
                }                 
            }
            //end not allowing HCO to delete

            DB::beginTransaction();
            if ($request->has('account_user_id_removed')) {
                HipaaComplianceOfficer::where('hco_type', \App\Models\AccountUser::class)
                    ->where('location_id', $input_fields['location_id'])
                    ->whereIn('hco_id', $input_fields['account_user_id_removed'])->delete();
                AccountUserLocationAccess::whereIn('account_user_id', $input_fields['account_user_id_removed'])
                    ->where('location_id', $input_fields['location_id'])
                    ->get()->each(function ($r) {
                        $r->delete();
                    });
            }

            if ($request->has('account_user_id')) {
                $emailTemplate_HCE_UE30 = EmailTemplate::where('code', 'HCE-UE30')->first();
                foreach ($input_fields['account_user_id'] as $user_id) {
                    AccountUserLocationAccess::create([
                        'location_id' => $input_fields['location_id'],
                        'account_user_id' => $user_id,
                    ]);
                    $account_user = AccountUser::where('id', $user_id)->with('user.reseller')->first();
                    // Send HCE-UE30
                    $email_vars = [
                        '{%FIRST_NAME%}' => $account_user->first_name,
                        '{%LOGIN_TO_ABYDE%}' => Config::get('app.url').'/login',
                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate_HCE_UE30->body);
                    $this->sendEmail($emailTemplate_HCE_UE30->code, $html, $account_user->email, Config::get('app.from_user_email'), $emailTemplate_HCE_UE30->subject, null, null, true, ($account_user->user->partner_reseller_id != null ? $account_user->user->reseller->logo : null));
                }
            }
            DB::commit();
            $location = Location::where('id', $input_fields['location_id'])
                ->select(['id', 'location_nickname', 'ce_type_id', 'updated_at'])
                ->withCount('companyModuleCompleted')
                ->withCount('disasterRecoveryPlanModuleCompleted')
                ->with('sraModuleCompleted')
                ->with([
                    'hipaaComplianceOfficer.hco', 'accountLocationAccess.accountUser', 'employeePrimaryWorkLocation',
                    'employeeSecondaryWorkLocation', 'localFirstResponder', 'businessAssociatesUser',
                    'studentPrimaryWorkLocation',
                ])
                ->withCount('high_risk')
                ->withCount('medium_risk')
                ->withCount('low_risk')
                ->withCount('openNotifications')
                ->withCount('activeEmployeePrimaryWorkLocation')
                ->withCount('businessAssociatesLocation')
                ->withCount('contributorLocation')
                ->first();

            $account_user = new AccountUserController;
            $sra = new SecurityRiskAnalysisController;
            $employee = new EmployeeController;
            $student = new StudentController;
            $disaster = new DisasterRecoveryPlanController;
            $ongoing_compliance = new OngoingComplianceController;
            $business_associates = new BusinessAssociatesController;
            $training = new TrainingController;
            $policy = new PolicyController;
            $notification = new NotificationController;
            $hipaa_logs = new HipaaLogController;
            $location['accountuser_last_updated'] = $account_user->getLastUpdatedAccountUser($location->id);
            $location['sra_percentage_count'] = ($location->sraModuleCompleted && $location->sraModuleCompleted->is_completed == 1) ? (object) ['percentage' => 100] : $sra->getPercentageCount($location->id);
            $location['scorecard_last_updated'] = $sra->getLastUpdatedScorecard($location->id);
            $location['employee_last_updated'] = $employee->getLastUpdatedEmployee($location->id);
            $location['student_last_updated'] = $student->getLastUpdatedStudent($location->id);
            $location['disaster_last_updated'] = $disaster->getLastUpdatedDisaster($location->id);
            $location['ongoing_last_completed'] = $ongoing_compliance->getLastCompletedOngoing($location->id);
            $location['ongoing_compliance_percentage_count'] = $ongoing_compliance->getPercentageCount($location->id);
            $location['business_associates_last_updated'] = $business_associates->getLastUpdatedBusinessAssociates($location->id);
            $location['training_last_updated'] = $training->getLastUpdatedTraining($location->id);
            $location['policy_last_updated'] = $policy->getLastUpdatedPolicy($location->id);
            $location['hipaa_log_last_updated'] = $hipaa_logs->getLastUpdatedHipaaLogs($location->id);
            $location['notification'] = $notification->openNotificationlist($location->id);
            $location['training_counts'] = $training->getTrainingCount($location->id);

            return $this->success(Config::get('constants.ACCOUNT_USER.ACCOUNT_USER_ADDED'), 200, $location);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('DashboardController/setAccountUser() => '.$e->getMessage());
            Log::error('DashboardController/setAccountUser()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Send HIPAA emergency emails
     *
     * @return \Illuminate\Http\Response
     */
    public function helpHipaaEmergency(Request $request)
    {
        try {
            $validator_rules = [
                'selected_access_locations' => 'required|array',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $user_data = $this->getMainAccountDetails();
            $selected_location_acntuser = [];
            foreach ($request->selected_access_locations as $key => $value) {
                try {
                    $hco = HipaaComplianceOfficer::where('location_id', $value['id'])->with('hco')->first();
                    if (! empty($hco)) {
                        if ($user_data->email != $hco->hco->email) {
                            $hco_key = $hco->hco->id;
                            if (array_key_exists($hco_key, $selected_location_acntuser)) {
                                if (! in_array($value['location_nickname'], $selected_location_acntuser[$hco_key])) {
                                    $selected_location_acntuser[$hco_key][] = $value['location_nickname'];
                                }
                            } else {
                                $selected_location_acntuser[$hco_key] = [$value['location_nickname']];
                            }
                        }
                    }
                    $account_users_list = AccountUserLocationAccess::where('location_id', $value['id'])->with('accountUser')->get();
                    if (! empty($account_users_list)) {
                        foreach ($account_users_list as $key => $val) {
                            $acntuser_key = $val->accountUser->id;
                            if (array_key_exists($acntuser_key, $selected_location_acntuser)) {
                                if (! in_array($value['location_nickname'], $selected_location_acntuser[$acntuser_key])) {
                                    $selected_location_acntuser[$acntuser_key][] = $value['location_nickname'];
                                }
                            } else {
                                $selected_location_acntuser[$acntuser_key] = [$value['location_nickname']];
                            }
                        }
                    }
                } catch (\Exception $e) {
                    Log::error('DashboardController/helpHipaaEmergency()[selected_access_locations_error] => '.$e->getMessage());
                    Log::error('DashboardController/helpHipaaEmergency()[selected_access_locations_data] => '.json_encode($value));
                }
            }
            //send mail to PCO
            $emailTemplatePCO = EmailTemplate::where('code', 'HCE-UE22')->first();
            $email_vars_PCO = [
                '{%FIRST_NAME%}' => $user_data->first_name,
                '{%LOCATION_LIST%}' => implode(', ', \Arr::pluck($request->selected_access_locations, 'location_nickname')),
                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                '{%SUPPORT_PHONE%}' => Config::get('app.support_phone_number'),
                '{%SUPPORT_PHONE_NUMBER_DISPLAY%}' => Config::get('app.support_phone_number_display'),
            ];
            // echo "<br>" . $user_data->email."====". Config::get('app.from_user_email');
            $html_PCO = str_ireplace(array_keys($email_vars_PCO), array_values($email_vars_PCO), $emailTemplatePCO->body);
            $this->sendEmail($emailTemplatePCO->code, $html_PCO, $user_data->email, Config::get('app.from_user_email'), $emailTemplatePCO->subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
            // send email to Abyde
            $emailTemplateAdmin = EmailTemplate::where('code', 'HCE-AE4')->first();
            $email_vars_admin = [
                '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_data->email,
                '{%COMPANY_NAME%}' => $user_data->company_name,
                '{%LOCATION_LIST%}' => implode(', ', \Arr::pluck($request->selected_access_locations, 'location_nickname')),
            ];
            $email_vars_admin['{%USER_NAME%}'] = 'Admin';
            $html_admin = str_ireplace(array_keys($email_vars_admin), array_values($email_vars_admin), $emailTemplateAdmin->body);
            if ($user_data->partner_reseller_id != null) {
                $admin_subject = str_ireplace('{%RESELLER%}', $user_data->reseller->name, $emailTemplateAdmin->reseller_subject);
            } else {
                $admin_subject = $emailTemplateAdmin->subject;
            }
            $this->sendEmail($emailTemplateAdmin->code, $html_admin, [Config::get('app.cs_group_email'), Config::get('app.exec_group_email')], Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));

            //send mail to partner start
            if ($user_data->partner_reseller_id != '' && $user_data->reseller->email != '') {
                $this->sendEmail($emailTemplateAdmin->code, $html_admin, $user_data->reseller->email, Config::get('app.from_admin_email'), $admin_subject, null, null, true, $user_data->reseller->logo);
            }
            //end send mail to partner
            // send email to acnt user and hco
            if (! empty($selected_location_acntuser)) {
                foreach ($selected_location_acntuser as $key => $val) {
                    $location_list_for_acntuser = implode(',', $val);
                    $acntuserinfo = AccountUser::where('id', $key)->first();
                    $email_vars = [
                        '{%FIRST_NAME%}' => $acntuserinfo->first_name,
                        '{%LOCATION_LIST%}' => $location_list_for_acntuser,
                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        '{%SUPPORT_PHONE%}' => Config::get('app.support_phone_number'),
                        '{%SUPPORT_PHONE_NUMBER_DISPLAY%}' => Config::get('app.support_phone_number_display'),
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplatePCO->body);
                    $this->sendEmail($emailTemplatePCO->code, $html, $acntuserinfo->email, Config::get('app.from_admin_email'), $emailTemplatePCO->subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                }
            }

            return $this->success(Config::get('constants.USER.HIPAA_EMERGENCY_SUCCESS'), 200);
        } catch (\Exception $e) {
            Log::error('DashboardController/helpHipaaEmergency() => '.$e->getLine());
            Log::error('DashboardController/helpHipaaEmergency() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * delete locations
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteLocation(Request $request)
    {
        try {
            Location::find($request['location_id'])->delete();

            return $this->success(Config::get('constants.SUCCESS'), 200);
        } catch (\Exception $e) {
            Log::error('DashboardController/deleteLocation() => '.$e->getMessage());
            Log::error('DashboardController/deleteLocation()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * change Dashboard View
     *
     * @return \Illuminate\Http\Response
     */
    public function changeDashboardView(Request $request)
    {
        try {
            $user_type = $this->getLoginUserData();
            if ($user_type['user_type'] == 'PCO') {
                $user = User::find($user_type['id']);
            }
            if ($user_type['user_type'] == 'HCO' || $user_type['user_type'] == 'USER') {
                $user = AccountUser::find($user_type['id']);
            }
            $user->dashboard_view = $request['dashboard_view'];
            $user->save();

            return $this->success(Config::get('constants.SUCCESS'), 200);
        } catch (\Exception $e) {
            Log::error('DashboardController/changeDashboardView() => '.$e->getMessage());
            Log::error('DashboardController/changeDashboardView()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * Auto Renewal popup check
     *
     * @return \Illuminate\Http\Response
     */
    public function autoRenewalPopupCheck(Request $request)
    {
        try {
            $user_data = $this->getLoginUserData();
            if (! empty($user_data)) {
                $today_date_time_obj = new DateTime;
                $current_year = date('Y');
                $sign_up_date_time = strtotime($user_data['created_at']);
                $renewal_date_time = str_replace(date('Y', $sign_up_date_time), $current_year, $user_data['created_at']);
                $renewal_date_time_obj = new DateTime($renewal_date_time);
                if ($renewal_date_time_obj < $today_date_time_obj) {
                    $renewal_date_time_obj->modify('+1 year');
                }
                $duration_obj = $today_date_time_obj->diff($renewal_date_time_obj);
                $no_of_days = ($duration_obj->days);
                $check1 = AutorenewalReviewPopupTracks::where([
                    'user_id' => $user_data['id'],
                    'renewal_date' => $renewal_date_time_obj->format('Y-m-d'),
                ])->whereIn('close_type', ['sign_me_up']);
                $is_closed_permanent = $check1->get()->toArray();
                $check2 = AutorenewalReviewPopupTracks::where([
                    'user_id' => $user_data['id'],
                    'renewal_date' => $renewal_date_time_obj->format('Y-m-d'),
                ]);
                $total_entry = $check2->get()->toArray();
                if ($no_of_days <= 120 && $no_of_days >= 1 && empty($is_closed_permanent) && count($total_entry) < 3 && $request->session()->get('AUTORENEWALREVIEWYPOPUPSHOWN') == '0') {
                    return $this->success(Config::get('constants.SUCCESS'), 200);
                } else {
                    return $this->error(Config::get('constants.ERROR'), 200);
                }
            }
        } catch (\Exception $e) {
            Log::error('DashboardController/autoRenewalPopupCheck() => '.$e->getMessage());
            Log::error('DashboardController/autoRenewalPopupCheck()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * update auto renewal popup flag
     *
     * @return \Illuminate\Http\Response
     */
    public function updateAutoRenewalPopupFlag(Request $request)
    {
        try {
            $user_data = $this->GetLoginUserData();
            if ($user_data) {
                DB::beginTransaction();
                $today_date_time_obj = new DateTime;
                $current_year = date('Y');
                $sign_up_date_time = strtotime($user_data['created_at']);
                $renewal_date_time = str_replace(date('Y', $sign_up_date_time), $current_year, $user_data['created_at']);
                $renewal_date_time_obj = new DateTime($renewal_date_time);
                if ($renewal_date_time_obj < $today_date_time_obj) {
                    $renewal_date_time_obj->modify('+1 year');
                }
                $request->session()->put('AUTORENEWALREVIEWYPOPUPSHOWN', 1);
                $data = [
                    'user_id' => $user_data['id'],
                    'close_type' => $request->close_type,
                    'renewal_date' => $renewal_date_time_obj->format('Y-m-d'),
                ];
                $update_session_flag = AutorenewalReviewPopupTracks::create($data);
                DB::commit();
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $update_session_flag);
        } catch (\Exception $e) {
            Log::error('DashboardController/updateAutoRenewalPopupFlag() => '.$e->getMessage());
            Log::error('DashboardController/updateAutoRenewalPopupFlag()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * Check new Changes Popup Tracks
     *
     * @return \Illuminate\Http\Response
     */
    public function checkNewChangesPopupTracks(Request $request)
    {
        try {
            $user_data = $this->GetLoginUserData();
            if ($user_data['user_type'] == 'PCO') {
                $user_type = 'user';
            } else {
                $user_type = 'account_user';
            }
            $signup_date = new DateTime($user_data->created_at);
            $hipaa_rebuild_launch_date = '2023-08-12'; // HIPAA REBUILD LAUNCH DATE [WE WILL SHOW THIS POPUP TO OLD USERS]
            $check = NewChangesPopupTracks::where('user_id', $user_data['id'])->where('user_type', $user_type)->first();
            if (empty($check) && $signup_date->format('Y-m-d') < $hipaa_rebuild_launch_date) {
                return $this->success(Config::get('constants.SUCCESS'), 200);
            } else {
                return $this->error(Config::get('constants.ERROR'), 200);
            }
        } catch (\Exception $e) {
            Log::error('DashboardController/checkChangesPopupTracks() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * Check BA Promotion
     *
     * @return \Illuminate\Http\Response
     */
    public function checkBAPromotionTracks(Request $request)
    {
        try {
            $user_data = $this->GetLoginUserData();
            $check = BaPromotionResponse::where('user_id', $user_data['user_id'] ?? $user_data['id'])->first();
            if (empty($check)) {
                return $this->success(Config::get('constants.SUCCESS'), 200);
            } else {
                return $this->error(Config::get('constants.ERROR'), 200);
            }
        } catch (\Exception $e) {
            Log::error('DashboardController/checkBAPromotionTracks() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    public function updateBAPromotionResponses(Request $request)
    {
        try {
            $user_data = $this->GetLoginUserData();
            DB::beginTransaction();
            if (isset($request->is_interested)) {
                $ba_promo_response = BaPromotionResponse::create([
                    'user_id' => $user_data['user_id'] ?? $user_data['id'],
                    'answered_by_type' => $user_data['user_type'],
                    'answered_by' => $user_data['id'],
                    'is_interested' => $request->is_interested,
                ]);
                if ($request->is_interested == 1) {
                    $emailTemplate = EmailTemplate::where('code', 'HCE-AE19')->first();
                    $email_vars = [
                        '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_data['PCO_email'] ?? '',
                        '{%COMPANY_NAME%}' => $user_data['PCO_company'] ?? $user_data['company_name'],
                        '{%PRIMARY_COMPLIANCE_OFFICER_NAME%}' => $user_data['PCO_name'] ?? '',
                    ];

                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);

                    if ($user_data['partner_reseller_id'] != null) {
                        $admin_subject = str_ireplace('{%RESELLER%}', $user_data['reseller']['name'], $emailTemplate->reseller_subject);
                    } else {
                        $admin_subject = $emailTemplate->subject;
                    }
                    $this->sendEmail($emailTemplate->code, $html, [Config::get('app.cs_group_email'), Config::get('app.exec_group_email'), Config::get('app.salesadmin_group_email'), Config::get('app.reseller_group_email')], Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user_data['partner_reseller_id'] != null ? $user_data['reseller']['logo'] : null));

                    //send mail to partner start
                    if ($user_data['partner_reseller_id'] != '' && $user_data['reseller']['email'] != '') {
                        $this->sendEmail($emailTemplate->code, $html, $user_data['reseller']['email'], Config::get('app.from_admin_email'), $admin_subject, null, null, true, $user_data['reseller']['logo']);
                    }
                    //send mail to partner end
                }
            }
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200, []);
        } catch (\Exception $e) {
            Log::error('DashboardController/updateSharedEmailPopupTracks() => '.$e->getMessage());
            Log::error('DashboardController/updateSharedEmailPopupTracks()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * Update New Changes Popup Tracks flag
     *
     * @return \Illuminate\Http\Response
     */
    public function UpdateNewChangesPopupTracks(Request $request)
    {
        try {
            $user_data = $this->GetLoginUserData();
            if ($user_data['user_type'] == 'PCO') {
                $user_type = 'user';
            } else {
                $user_type = 'account_user';
            }
            DB::beginTransaction();
            $create_popup_track = NewChangesPopupTracks::create([
                'user_id' => $user_data['id'],
                'user_type' => $user_type,
            ]);
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200, $create_popup_track);
        } catch (\Exception $e) {
            Log::error('DashboardController/newChangesPopupTracks() => '.$e->getMessage());
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * Check shared email popup track
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function checkSharedEmailPopupTracks()
    {
        try {
            $user_data = $this->GetLoginUserData();
            if ($user_data['user_type'] == 'PCO') {
                $user_type = 'user';
            } else {
                $user_type = 'account_user';
            }
            $old_user_ids = json_decode(file_get_contents(public_path().'/old_user_ids_shared_emils.json'));
            $old_user_ids = $old_user_ids->user_ids;
            if (in_array($user_data['old_hipaa_id'], $old_user_ids)) {
                $user_loggedin_list = SharedEmailPopupTracks::where(['user_id' => $user_data['id'], 'user_type' => $user_type])->get();
                $user_loggedin_count = $user_loggedin_list->count();
                if ($user_loggedin_count < 3) {
                    return $this->success(Config::get('constants.SUCCESS'), 200);
                }
            }

            return $this->error(Config::get('constants.ERROR'), 200);
        } catch (\Exception $e) {
            Log::error('DashboardController/checkSharedEmailPopupTracks() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * Update shared email popup
     *
     * @return \Illuminate\Http\Response
     */
    public function updateSharedEmailPopupTracks(Request $request)
    {
        try {
            $user_data = $this->GetLoginUserData();
            if ($user_data['user_type'] == 'PCO') {
                $user_type = 'user';
            } else {
                $user_type = 'account_user';
            }
            DB::beginTransaction();
            $logged_in_user_list = SharedEmailPopupTracks::where(['user_id' => $user_data['id'], 'user_type' => $user_type])->get();
            $logged_in_user_count = $logged_in_user_list->count();
            if ($logged_in_user_count < 3) {
                $create_shared_email_track = SharedEmailPopupTracks::create([
                    'user_id' => $user_data['id'],
                    'user_type' => $user_type,
                ]);
            }
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200, []);
        } catch (\Exception $e) {
            Log::error('DashboardController/updateSharedEmailPopupTracks() => '.$e->getMessage());
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * Check BA Promotion
     *
     * @return \Illuminate\Http\Response
     */
    public function showCompanyInfoModal(Request $request)
    {
        try {
            $generalController = new GeneralController;
            $location_access_list = $generalController->getAssingedLocationList();
            $locations = Location::whereIn('id', $location_access_list)
                ->whereNull('ce_type_id')
                ->whereHas('companyModuleCompleted')
                ->get();
            if (count($locations)) {
                return $this->success(Config::get('constants.SUCCESS'), 200);
            } else {
                return $this->error(Config::get('constants.ERROR'), 200);
            }
        } catch (\Exception $e) {
            Log::error('DashboardController/checkShowCompanyInfoModal() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }
    /**
     * Check badge open or not
     *
     * @return \Illuminate\Http\Response
     */
    public function showBadgeModal(Request $request)
    {        
        try {            
            $user_data = $this->getMainAccountDetails();                        
            $user_data = UserBadgeEmailHistory::where(['user_id'=> $user_data['id']])->where('popup_open_count', '<=', 1)->first();            
            if (!empty($user_data)) {
                return $this->success(Config::get('constants.SUCCESS'), 200,$user_data);
            } else {
                return $this->error(Config::get('constants.ERROR'), 200);
            }
        } catch (\Exception $e) {
            Log::error('DashboardController/showBadgeModal() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }
    /************************** */
    /*API methods - end
    /*************************** */
}
