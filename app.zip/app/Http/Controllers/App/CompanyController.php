<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AccountUserLocationAccess;
use App\Models\CoveredEntityType;
use App\Models\EmailTemplate;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\LocationNotification;
use App\Models\ModuleCompletedStatus;
use App\Models\Partner;
use App\Models\StateBreachDetail;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\FileUpload;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use App\Traits\Notification;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class CompanyController extends Controller
{
    use ApiResponser, CheckAccessRight, FileUpload, GeneratePolicy, GetMainUserData, Notification, SendMail;

    /**
     * company page
     *
     * @return \Illuminate\Http\Response
     */
    public function showCompany(Request $request, $location_id = '')
    {
        if ($location_id != '') {
            $location_id = base64_decode($location_id, true);
            if ($location_id) {
                if ($this->checkAccessRight('company', $location_id)) {
                    $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                    if ($hco) {
                        return view('app.pages.company', ['location_id' => $location_id]);
                    } else {
                        return redirect('/dashboard');
                    }
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get company info by location id
     *
     * @return \Illuminate\Http\Response
     */
    public function getCompanyByLocationID(Request $request, $location_id = '')
    {
        try {
            if ($location_id == '') {
                dd('Invalid parmas');
            }
            $user_data = $this->getMainAccountDetails();
            $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
            if (! $hco) {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
            $user_id = $user_data->id;
            $data = Location::where([['id', '=', $location_id], ['user_id', '=', $user_id]])->with(['user' => function ($que) {
                $que->select(['id', 'company_name']);
            }, 'state' => function ($stateQuery) {
                $stateQuery->select(['id', 'state_code', 'state_name']);
            }, 'coveredEntityType' => function ($stateQuery) {
                $stateQuery->select(['id', 'name']);
            }])->withCount('companyModuleCompleted')->first();
            if (! is_null($data->logo)) {
                $data->logo = $this->getSignedURL('/company_logo/'.$user_id.'/'.$location_id.'/original/'.$data->logo);
            }
            $user_locations_count = Location::where('user_id', $user_id)->count();
            $data['user_locations_number'] = $user_locations_count;
            $company_module_status = ModuleCompletedStatus::where([['location_id', $location_id], ['module', 'company_info']])->first();
            if ($company_module_status && $company_module_status->is_completed == 1) {
                $data['first_time_compnay_addedd'] = false;
            } else {
                $data['first_time_compnay_addedd'] = true;
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('CompanyController/getCompanyByLocationID() => '.$e->getMessage());
            Log::error('CompanyController/getCompanyByLocationID()[data] => '.json_encode([$location_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * Check unique location nickname user wise
     *
     * @return \Illuminate\Http\Response
     */
    public function checkUniqueLocationNickname(Request $request, $location_nickname = '', $location_id = '')
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $user_id = $user_data->id;
            if ($location_nickname == '' || $user_id == '' || $location_id == '') {
                dd('Invalid parmas');
            }
            $data = Location::where([['location_nickname', '=', $location_nickname], ['user_id', '=', $user_id], ['id', '!=', $location_id]])->count();
            if ($data > 0) {
                return 'available';
            } else {
                return 'not_available';
            }
        } catch (\Exception $e) {
            Log::error('CompanyController/checkUniqueLocationNickname() => '.$e->getMessage());
            Log::error('CompanyController/checkUniqueLocationNickname()[data] => '.json_encode([$location_nickname, $location_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * edit company info
     *
     * @return \Illuminate\Http\Response
     */
    public function editCompany(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'company_name' => 'required',
                'location_nickname' => 'required',
                'address' => 'required',
                'city' => 'required',
                'state_id' => 'required',
                'zip_code' => 'required',
                'phone_no' => 'required',
            ];
            $custom_messages = [];
            if ($request->hasFile('logo')) {
                $validator_rules['logo'] = 'sometimes|image|max:5120';
                $custom_messages = [
                    'logo.max' => 'The :attribute field should not be more than 5mb.',
                    'location_nickname.distinct' => 'Location name :input has a duplicate value. Please try again.',
                ];
            }
            $validator_check = Validator::make($request->all(), $validator_rules, $custom_messages);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $data = Location::findOrFail($input_fields['location_id']);

            // add policy, procedure, form versioning
            if ($data['company_name'] !== $input_fields['company_name'] || $data['address'] !== $input_fields['address'] || $data['city'] !== $input_fields['city'] || $data['state_id'] != $input_fields['state_id'] || $data['zip_code'] != $input_fields['zip_code'] || $data['phone_no'] != $input_fields['phone_no'] || $request->hasFile('logo') || (($input_fields['logo_url'] == 'null' || is_null($input_fields['logo_url'])) && $data['logo'] !== null)) {
                $policy_array = ['AL', 'DRP', 'SPP', 'MMPP', 'AAP', 'BNP', 'BACP', 'EDDP', 'EFP', 'ETP', 'HCUAP', 'HNEP', 'ORP', 'PMP', 'PCFP', 'PHDRP', 'SATP', 'SAP', 'SRA', 'VCP'];
                foreach ($policy_array as $policy_code) {
                    $this->addPolicyVersionData($policy_code, $input_fields['location_id']);
                }
            }
            if ($data['company_name'] !== $input_fields['company_name'] || $data['address'] !== $input_fields['address'] || $data['city'] !== $input_fields['city'] || $data['state_id'] != $input_fields['state_id'] || $data['zip_code'] != $input_fields['zip_code'] || $data['phone_no'] != $input_fields['phone_no']) {
                $policy_array = ['MCF', 'CSPF'];
                foreach ($policy_array as $policy_code) {
                    $this->addPolicyVersionData($policy_code, $input_fields['location_id']);
                }
            }
            if ($data['company_name'] !== $input_fields['company_name'] || $data['phone_no'] != $input_fields['phone_no']) {
                $policy_array = ['NPP', 'HED'];
                foreach ($policy_array as $policy_code) {
                    $this->addPolicyVersionData($policy_code, $input_fields['location_id']);
                }
            }
            if ($data['company_name'] !== $input_fields['company_name']) {
                $policy_array = ['CAV', 'PCF', 'PHDRF'];
                foreach ($policy_array as $policy_code) {
                    $this->addPolicyVersionData($policy_code, $input_fields['location_id']);
                }
            }
            if (($data['location_nickname'] !== $input_fields['location_nickname'])) {
                $policy_array = ['AFFPR', 'CFFEDOP'];
                foreach ($policy_array as $policy_code) {
                    $this->addPolicyVersionData($policy_code, $input_fields['location_id']);
                }
            }
            if ($data['state_id'] != $input_fields['state_id']) {
                $old_breach_detail = StateBreachDetail::where('state_id', $data['state_id'])->first();
                $new_breach_detail = StateBreachDetail::where('state_id', $input_fields['state_id'])->first();
                if (isset($old_breach_detail) && $old_breach_detail != null) {
                    if ($old_breach_detail['request_time'] !== $new_breach_detail['request_time']) {
                        $this->addPolicyVersionData('PHDRF', $input_fields['location_id']);
                    }
                }
            }

            $old_company_name = $data['company_name'];
            $new_company_name = $request->company_name;
            $old_phone_no = $data['phone_no'];
            $new_phone_no = $request->phone_no;
            $logo_url = null;
            if (! is_null($data['logo']) || $data['logo'] != '') {
                $logo_url = $this->getSignedURL('/company_logo/'.$data['user_id'].'/'.$data['id'].'/original/'.$data['logo']);
            }
            if ($request->hasFile('logo')) {
                $filePath = '/company_logo/'.$data['user_id'].'/'.$data['id'].'/original';
                $image = $request->file('logo');
                $file_name = uniqid().'-'.$image->getClientOriginalName();
                $path = $image->storeAs(
                    $filePath,
                    $file_name, //$fileName
                    ['disk' => 's3'] //$options
                );
                $input_fields['logo'] = $file_name;
                $logo_url = $this->getSignedURL('/company_logo/'.$data['user_id'].'/'.$input_fields['location_id'].'/original/'.$file_name);
                if ($data['logo']) {
                    // $filePath = '/company_logo/' . $data['user_id'] . '/' . $data['id'] . '/original';
                    // if (Storage::disk('s3')->exists($filePath . '/' . $data['logo'])) {
                    //     Storage::disk('s3')->delete($filePath . '/' . $data['logo']);
                    // }
                }
            } else {
                if ($input_fields['logo_url'] == 'null' || is_null($input_fields['logo_url'])) {
                    if ($data['logo']) {
                        // $filePath = '/company_logo/'.$data['user_id'].'/'.$data['id'].'/original';
                        // if (Storage::disk('s3')->exists($filePath . '/' . $data['logo'])) {
                        //     Storage::disk('s3')->delete($filePath . '/' . $data['logo']);
                        // }
                        $input_fields['logo'] = null;
                        $logo_url = null;
                    }
                }
            }
            if ($data->update($input_fields)) {
                if ($old_company_name !== $new_company_name) {
                    $hipaa_log = new HipaaLogController;
                    $hipaa_log->updateDeletedAccessLogPdf($input_fields['location_id']);
                    $hipaa_log->updateDeletedAssetLogPdf($input_fields['location_id']);

                }
                if ($old_company_name !== $new_company_name || $old_phone_no !== $new_phone_no) {
                    $SF_location = Location::where('id', $input_fields['location_id'])->whereNotNull('salesforce_unique_id')->first();
                    if ($SF_location) {
                        SendLocationDataToSalesForce::dispatch($SF_location->id);
                    }
                }
                $company_module_status = ModuleCompletedStatus::where([['location_id', $input_fields['location_id']], ['module', 'company_info']])->first();
                $is_first_time_completing = 0;
                if ($company_module_status) {
                    $is_first_time_completing = ($company_module_status->is_completed == 0) ? 1 : 0;
                    $company_module_status->is_completed = 1;
                    $company_module_status->save();
                } else {
                    ModuleCompletedStatus::create([
                        'location_id' => $input_fields['location_id'],
                        'module' => 'company_info',
                        'is_completed' => 1,
                    ]);
                    $is_first_time_completing = 1;
                }
                if ($is_first_time_completing == 1) {
                    $notification_HCE_AN4 = $this->getNotificationByCode('HCE-AN4');
                    $notification_HCE_AN4_data = [
                        'location_id' => $input_fields['location_id'],
                        'notification_id' => $notification_HCE_AN4['id'],
                    ];
                    $this->createNotification($notification_HCE_AN4_data);
                    $user_data = $this->getMainAccountDetails();
                }
                if ($old_company_name != $input_fields['company_name']) {
                    $emailTemplate = EmailTemplate::where('code', 'HCE-AE12')->first();
                    $user_data = $this->getMainAccountDetails();
                    $email_vars = [
                        '{%PRIMARY_COMPLIANCE_OFFICER_NAME%}' => $user_data->first_name.' '.$user_data->last_name,
                        '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_data->email,
                        '{%PREVIOUS_COMPANY_NAME%}' => $old_company_name,
                        '{%NEW_COMPANY_NAME%}' => $input_fields['company_name'],
                        '{%LOCATION_NAME%}' => $data->location_nickname,
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    if ($user_data->partner_reseller_id != null) {
                        $admin_subject = str_ireplace('{%RESELLER%}', $user_data->reseller->name, $emailTemplate->reseller_subject);
                    } else {
                        $admin_subject = $emailTemplate->subject;
                    }
                    $this->sendEmail($emailTemplate->code, $html, Config::get('app.finance_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));

                    //send mail to partner start
                    if ($user_data->partner_reseller_id != null && $user_data->reseller->email != '') {
                        $this->sendEmail($emailTemplate->code, $html, $user_data->reseller->email, Config::get('app.from_admin_email'), $admin_subject, null, null, true, $user_data->reseller->logo);
                    }
                    //send mail to partner end
                }
                $notification_HCE_AN3 = $this->getNotificationByCode('HCE-AN3');
                LocationNotification::where('notification_id', $notification_HCE_AN3->id)
                    ->where('location_id', $data['id'])
                    ->where('is_completed', 0)
                    ->update(['is_completed' => 1]);
                DB::commit();

                return $this->success(Config::get('constants.LOCATION.COMPANY_INFO_UPDATED'), 200, $logo_url);
            } else {
                DB::rollback();

                return $this->error(Config::get('constants.LOCATION.COMPANY_INFO_NOT_UPDATED'), 200);
            }
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('CompanyController/editCompany() => '.$e->getMessage());
            Log::error('CompanyController/editCompany()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function getCETypeList()
    {
        try {
            $data = CoveredEntityType::select('id', 'name')->orderBy('display_order')->get();

            return $this->success('Success', 200, $data);
        } catch (\Exception $e) {
            Log::error('CompanyController/getCETypeList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function addCoveredEntityForLocations(Request $request)
    {
        try {
            $validator_rules = [
                'ce_type_id' => 'required',
                'other' => 'required_if:ce_type_id,1',
            ];
            $custom_messages = [];
            $validator_check = Validator::make($request->all(), $validator_rules, $custom_messages);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $generalController = new GeneralController;
            $location_access_list = $generalController->getAssingedLocationList();
            Location::whereIn('id', $location_access_list)
                ->whereNull('ce_type_id')
                ->whereHas('companyModuleCompleted')
                ->update([
                    'ce_type_id' => $request['ce_type_id'],
                    'other' => $request['other'],
                ]);
            DB::commit();

            return $this->success(Config::get('constants.LOCATION.COMPANY_INFO_UPDATED'), 200);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('CompanyController/addCoveredEntityForLocations() => '.$e->getMessage());
            Log::error('CompanyController/addCoveredEntityForLocations()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
