<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\SitePolicy;
use App\Traits\ApiResponser;
use App\Traits\GetMainUserData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;

class SitePolicyController extends Controller
{
    use ApiResponser, GetMainUserData;

    /**
     * Site Policy  page
     */
    public function showSitePolicy(Request $request)
    {
        return view('app.pages.sitepolicy');

    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get Site Policy
     *
     * @return \Illuminate\Http\Response
     */
    public function getSitePolicies(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            if ($user_data->partner_reseller_id != null) {
                $list = SitePolicy::select('id', 'title', DB::raw('CASE WHEN description_reseller = "" THEN description ELSE description_reseller END as description'), 'display_order');
            } else {
                $list = SitePolicy::select('id', 'title', 'description', 'display_order');
            }
            $list = $list->orderBy('display_order')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('SitePolicyController/getSitePolicies() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
