<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\EmailTemplate;
use App\Models\Employee;
use App\Models\EmployeeAgreement;
use App\Models\EmployeePortalLogin;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\ModuleCompletedStatus;
use App\Models\Training;
use App\Models\TrainingAttempt;
use App\Models\TrainingInvite;
use App\Models\TrainingLocation;
use App\Models\TrainingQuestionAnswer;
use App\Models\TrainingQuizAttempt;
use App\Models\User;
use App\Traits\ApiResponser;
use App\Traits\FileUpload;
use App\Traits\SendMail;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;
use Stripe;

class EmployeeportalController extends Controller
{
    use ApiResponser, FileUpload, SendMail;

    /**
     * Employee page
     *
     * @return \Illuminate\Http\Response
     */
    public function showAgreement($employee_id = '', $ref_token = '')
    {
        if ($employee_id == '' || $ref_token == '') {
            return redirect()->route('login');
        } else {
            if (base64_decode($employee_id, true)) {
                $employee = Employee::with(['user.reseller'])->where('id', base64_decode($employee_id))->first();
                $employee_agreement = EmployeeAgreement::where('reference_token', $ref_token)->where('employee_id', base64_decode($employee_id))->first();

                return view('app.pages.employeeportal_agreement', ['employee_id' => $employee_id, 'ref_token' => $ref_token, 'employee_user_data' => $employee, 'employee_agreement_data' => $employee_agreement]);
            } else {
                return redirect()->route('login');
            }
        }
    }

    /**
     * Employee portal login
     *
     * @return \Illuminate\Http\Response
     */
    public function showLogin(Request $request)
    {
        if ($request->session()->has('employee_id') && $request->session()->has('employee_portal_login_id')) {
            return redirect()->route('employee_portal_dasboard');
        }

        return view('app.pages.employeeportal_login');
    }

    /**
     * Employee portal logout
     */
    public function doLogout(Request $request)
    {
        $request->session()->forget('employee_portal_login_id');
        $request->session()->forget('employee_id');
        $request->session()->save();
        return redirect(Config::get('app.wordpress_url'));
    }

    /**
     * Employee portal dashboard
     */
    public function showDashboard(Request $request)
    {
        $employee = Employee::with(['user.reseller','employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation.location'])->where('id', $request->session()->get('employee_id'))->first();
        $employee_location_ids[] = $employee->primary_work_location_id;
        foreach ($employee->employeeSecondaryWorkLocation as $key => $value) {
            $employee_location_ids[] = $value->location_id;
        }
        $employee['hco_list'] = HipaaComplianceOfficer::with(['hco', 'location'])->whereIn('location_id', $employee_location_ids)->get();
        $primary_loc_hco = HipaaComplianceOfficer::where('location_id', $employee->primary_work_location_id)->first();
        $company_info_completed = ModuleCompletedStatus::where(['location_id' => $employee->primary_work_location_id, 'module' => 'company_info', 'is_completed' => 1])->first();
        $check_is_ra_completed = ModuleCompletedStatus::where(
            [
                'location_id' => $employee->primary_work_location_id,
                'module' => 'risk_analysis',
                'is_completed' => 1,
            ]
        )->first();
        $check_is_EMA_completed = ModuleCompletedStatus::where(
            [
                'location_id' => $employee->primary_work_location_id,
                'module' => 'disaster_recovery_plan',
                'is_completed' => 1,
            ]
        )->first();
        $employee['is_policy_module_enable'] = ($primary_loc_hco && $company_info_completed && $check_is_ra_completed && $check_is_EMA_completed) ? 'yes' : 'no';
        $employee['is_training_module_enable'] = ($primary_loc_hco) ? 'yes' : 'no';

        return view('app.pages.employeeportal_dashboard', ['employee_user_data' => $employee]);
    }

    /**
     * Employee portal Training
     *
     * @return \Illuminate\Http\Response
     */
    public function showTraining(Request $request)
    {
        $employee = Employee::with(['user.reseller'])->where('id', $request->session()->get('employee_id'))->isActive()->first();
        $hco = HipaaComplianceOfficer::where('location_id', $employee->primary_work_location_id)->first();
        $check_is_ra_completed = ModuleCompletedStatus::where(
            [
                'location_id' => $employee->primary_work_location_id,
                'module' => 'risk_analysis',
                'is_completed' => 1,
            ]
        )->first();

        if (! $hco || ! $check_is_ra_completed || ! $employee) {
            return redirect()->route('employee_portal_dasboard');
        }
        $employee_location_ids[] = $employee->primary_work_location_id;
        foreach ($employee->employeeSecondaryWorkLocation as $key => $value) {
            $employee_location_ids[] = $value->location_id;
        }
        $employee['location_list'] = Location::select('id', 'location_nickname')->whereIn('id', $employee_location_ids)->get();

        return view('app.pages.employeeportal_training', ['employee_user_data' => $employee]);
    }

    /**
     * Training Quiz page
     *
     * @return \Illuminate\Http\Response
     */
    public function showTrainingQuiz(Request $request, $invite_id = '')
    {
        if ($invite_id != '') {
            $invite_id = base64_decode($invite_id, true);
            if ($invite_id) {
                $employee = Employee::with(['user.reseller'])->where('id', $request->session()->get('employee_id'))->isActive()->first();
                $check_is_ra_completed = ModuleCompletedStatus::where(
                    [
                        'location_id' => $employee->primary_work_location_id,
                        'module' => 'risk_analysis',
                        'is_completed' => 1,
                    ]
                )->first();
                $hco = HipaaComplianceOfficer::where('location_id', $employee->primary_work_location_id)->first();
                if (! $hco || ! $check_is_ra_completed || ! $employee) {
                    return redirect()->route('employee_portal_dasboard');
                }

                $training_invite = TrainingInvite::find($invite_id);
                if ($training_invite && $training_invite->completed_datetime != null && $training_invite->completed_attempt_id != null) {
                    return redirect('/employeeportal/training');
                }

                $employee_location_ids[] = $employee->primary_work_location_id;
                foreach ($employee->employeeSecondaryWorkLocation as $key => $value) {
                    $employee_location_ids[] = $value->location_id;
                }
                $employee['location_list'] = Location::select('id', 'location_nickname')->whereIn('id', $employee_location_ids)->get();

                return view('app.pages.employeeportal_trainingquiz', ['invite_id' => $invite_id, 'employee_user_data' => $employee]);
            } else {
                return redirect('/employeeportal/dashboard');
            }
        } else {
            return redirect('/employeeportal/dashboard');
        }
    }

    /**
     * Employee portal policy
     */
    public function showProcedurePolicyForm(Request $request)
    {
        $employee = Employee::with(['user.reseller'])->where('id', $request->session()->get('employee_id'))->first();
        $employee_location_ids[] = $employee->primary_work_location_id;
        foreach ($employee->employeeSecondaryWorkLocation as $key => $value) {
            $employee_location_ids[] = $value->location_id;
        }
        $employee_location_ids_ordered = implode(',', $employee_location_ids);
        $employee['location_list'] = Location::select('id', 'location_nickname')->whereIn('id', $employee_location_ids)->orderByRaw("FIELD(id, $employee_location_ids_ordered)")->get();

        return view('app.pages.employeeportal_policy', ['employee_user_data' => $employee]);
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get agreement data
     *
     * @return \Illuminate\Http\Response
     */
    public function getAgreementData(Request $request)
    {
        try {
            $validator_rules = [
                'employee_id' => 'required',
                'ref_token' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $employee = Employee::with('user')->where('id', base64_decode($request->employee_id))->with('employeePrimaryWorkLocation')->first();
            $employee_agreement = EmployeeAgreement::where('reference_token', $request->ref_token)->where('employee_id', base64_decode($request->employee_id))->first();
            if ($employee && $employee_agreement) {

                if ($employee_agreement->signature && $employee_agreement->file_name) {
                    $expire_time = Config::get('app.expire_time');
                    $response = [
                        'employee' => $employee,
                        'employee_agreement' => $employee_agreement,
                        'agreement_pdf_url' => $this->getSignedURL('/generatedpolicydocuments/employeeagreement/'.$employee_agreement->file_name),
                        'agreement_pdf_url_downloadebale' => Storage::disk('s3')->temporaryUrl(
                            'generatedpolicydocuments/employeeagreement/'.$employee_agreement->file_name,
                            now()->addSeconds($expire_time),
                            [
                                'ResponseContentType' => 'application/octet-stream',
                                'ResponseContentDisposition' => 'attachment',
                            ]
                        ),
                    ];
                } else {
                    $public_path = public_path();
                    $storage_path = storage_path('app/public');
                    $generated_agreement_directory_path = $storage_path.'/generatedpolicydocuments/';
                    if (! is_dir($generated_agreement_directory_path)) {
                        mkdir($generated_agreement_directory_path);
                    }
                    $employee_agreement_filename = 'EmployeeAgreement.docx';
                    $gnerated_employee_agreement_filename = $employee->id.'_'.$employee_agreement_filename;
                    if (isset($request->signature) && $request->signature != '') {
                        $gnerated_employee_agreement_filename = $employee->id.'_signed_'.$employee_agreement_filename;
                    } else {
                        $gnerated_employee_agreement_filename = $employee->id.'_'.$employee_agreement_filename;
                    }
                    $gnerated_employee_agreement_pdf_name = str_replace('docx', 'pdf', $gnerated_employee_agreement_filename);

                    $employee_agreement_file_path = $public_path.'/policydocuments/'.$employee_agreement_filename;
                    $gnerated_employee_agreement_file_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_employee_agreement_filename;
                    $gnerated_employee_agreement_pdf_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_employee_agreement_pdf_name;

                    $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($employee_agreement_file_path);
                    if (isset($request->signature) && $request->signature != '') {
                        $template_processor->setValue('EMPLOYEE_NAME', htmlspecialchars($employee->first_name.' '.$employee->last_name));
                        $template_processor->setValue('EMPLOYEE_SIGNATURE', htmlspecialchars($request->signature));
                        $template_processor->setValue('SIGNATURE_DATE_TIME', date('m/d/Y'));
                        $template_processor->setValue('CLIENT_NAME', htmlspecialchars($employee->employeePrimaryWorkLocation->company_name));
                    } else {
                        $template_processor->setValue('EMPLOYEE_NAME', htmlspecialchars($employee->first_name.' '.$employee->last_name));
                        $template_processor->setValue('EMPLOYEE_SIGNATURE', '');
                        $template_processor->setValue('SIGNATURE_DATE_TIME', '');
                        $template_processor->setValue('CLIENT_NAME', htmlspecialchars($employee->employeePrimaryWorkLocation->company_name));
                    }
                    $template_processor->saveAs($gnerated_employee_agreement_file_path);
                    if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                        // change libreoffice path as per installation path from your machine
                        exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  '.$generated_agreement_directory_path.' '.$gnerated_employee_agreement_file_path);
                    } else {
                        exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir '.$generated_agreement_directory_path.' '.$gnerated_employee_agreement_file_path);
                    }
                    if (file_exists($gnerated_employee_agreement_pdf_path)) {
                        $file_contents = \File::get($gnerated_employee_agreement_pdf_path);
                        Storage::disk('s3')->put('/generatedpolicydocuments/employeeagreement/'.$gnerated_employee_agreement_pdf_name, $file_contents);
                        if (isset($request->signature) && $request->signature != '') {
                            $employee_agreement_old = EmployeeAgreement::where('reference_token', $request->ref_token)->where('employee_id', base64_decode($request->employee_id))->first();
                            $employee_agreement_old->update([
                                'signature' => $request->signature,
                                'file_name' => $gnerated_employee_agreement_pdf_name,
                            ]);
                            $employee_agreement = EmployeeAgreement::where('reference_token', $request->ref_token)->where('employee_id', base64_decode($request->employee_id))->first();
                        }
                    }
                    $expire_time = Config::get('app.expire_time');
                    $response = [
                        'employee' => $employee,
                        'employee_agreement' => $employee_agreement,
                        'agreement_pdf_url' => $this->getSignedURL('/generatedpolicydocuments/employeeagreement/'.$gnerated_employee_agreement_pdf_name),
                        'agreement_pdf_url_downloadebale' => Storage::disk('s3')->temporaryUrl(
                            'generatedpolicydocuments/employeeagreement/'.$gnerated_employee_agreement_pdf_name,
                            now()->addSeconds($expire_time),
                            [
                                'ResponseContentType' => 'application/octet-stream',
                                'ResponseContentDisposition' => 'attachment',
                            ]
                        ),
                    ];
                }

                return $this->success(Config::get('constants.SUCCESS'), 200, $response);
            }
        } catch (\Exception $e) {
            Log::error('EmployeeportalController/getAgreementData() => '.$e->getMessage());
            Log::error('EmployeeportalController/getAgreementData()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * send login otp
     *
     * @return \Illuminate\Http\Response
     */
    public function sendLoginOtp(Request $request)
    {
        try {
            $validator_rules = [
                'email' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $employee = Employee::where(['email' => request('email')])->first();
            if ($employee) {
                $PCO_data = User::where('id', $employee->user_id)->with('reseller')->first();
                if (! $PCO_data->is_active ||  $PCO_data->account_status == 'Frozen') {
                    return $this->error(Config::get('constants.EMPLOYEE.PCO_INACTIVE'), 200);
                }
                if (! $PCO_data->is_account_verified) {
                    return $this->error(Config::get('constants.EMPLOYEE.PCO_NOTVERIFIED'), 200);
                }
                if ($employee->status == 'inactive') {
                    return $this->error(Config::get('constants.EMPLOYEE.EMP_INACTIVE'), 200);
                }

                $hco_count = HipaaComplianceOfficer::where('location_id',  $employee->primary_work_location_id)->count();
                if ($hco_count <= 0) {
                    return $this->error(Config::get('constants.EMPLOYEE.HCO_NOT_FOUND'), 200);
                } 
                
                $otp = mt_rand(1000, 9999);
                if (isset($request->otp_ref_id) && ! empty($request->otp_ref_id)) {
                    $employee_login = EmployeePortalLogin::findOrFail($request->otp_ref_id);
                    $employee_login->update(['otp' => $otp, 'login_attempt' => 0, 'created_at' => gmdate('Y-m-d H:i:s')]);
                } else {
                    $employee_login = $employee->employeePortalLogin()->create(['otp' => $otp]);
                }
                if ($employee_login) {
                    $hco = HipaaComplianceOfficer::where('location_id', $employee->primary_work_location_id)->with('hco')->first();
                    $emailTemplate = EmailTemplate::where('code', 'HCE-UE29')->first();
                    $email_vars = [
                        '{%EMPLOYEE_FIRST_NAME%}' => $employee->first_name,
                        '{%ONE_TIME_PASSWORD%}' => $otp,
                        '{%HCO_FIRST_NAME%}' => $hco->hco->first_name,
                        '{%HCO_LAST_NAME%}' => $hco->hco->last_name,
                        '{%HCO_EMAIL%}' => $hco->hco->email,
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $this->sendEmail($emailTemplate->code, $html, $employee->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($PCO_data->partner_reseller_id != null ? $PCO_data->reseller->logo : null), $PCO_data->id);
                    $employee = Employee::where('email', request('email'))->with(['employeePortalLogin' => function ($query) use ($employee_login) {
                        $query->select('id', 'employee_id')->where('id', $employee_login->id);
                    }])->first();

                    return $this->success(Config::get('constants.EMPLOYEE.CHECK_EMAIL_OTP'), 200, $employee);
                }
            } else {
                return $this->error(Config::get('constants.EMPLOYEE.ACCOUNT_NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('EmployeeportalController/sendLoginOtp() => '.$e->getMessage());
            Log::error('EmployeeportalController/sendLoginOtp()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * verify otp & do login
     *
     * @return \Illuminate\Http\Response
     */
    public function doLogin(Request $request)
    {
        try {
            $validator_rules = [
                'verfication_otp' => 'required',
                'otp_ref_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $employee_login = EmployeePortalLogin::where('id', request('otp_ref_id'))->first();
            if ($employee_login) {
                $otp_send_datetime = Carbon::parse($employee_login->created_at);
                $current_datetime = Carbon::now();
                $diff_mins = $otp_send_datetime->diffInMinutes($current_datetime);
                if ($diff_mins > 30) {
                    return $this->error(Config::get('constants.EMPLOYEE.OTP_EXPIRED'), 200);
                } elseif ($employee_login->login_attempt >= 5) {
                    return $this->error(Config::get('constants.EMPLOYEE.OTP_ATTEMPT_OVER'), 200);
                } elseif ($employee_login->otp != str_replace('-', '', $request->verfication_otp)) {
                    $employee_login->update(['login_attempt' => $employee_login->login_attempt + 1]);

                    return $this->error(Config::get('constants.EMPLOYEE.WRONG_OTP'), 200);
                } else {
                    $request->session()->put('employee_portal_login_id', $employee_login->id);
                    $request->session()->put('employee_id', $employee_login->employee_id);
                    $request->session()->save();

                    return $this->success(Config::get('constants.SUCCESS'), 200);
                }
            } else {
                return $this->error(Config::get('constants.EMPLOYEE.WRONG_OTP'), 200);
            }
        } catch (\Exception $e) {
            Log::error('EmployeeportalController/doLogin() => '.$e->getMessage());
            Log::error('EmployeeportalController/doLogin()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get Recommended Training
     *
     * @return \Illuminate\Http\Response
     */
    public function getRecommendedTraining(Request $request)
    {
        $validator_rules = [
            'employee_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $employee = Employee::withCount('employeeSecondaryWorkLocation')->isActive()->find($request['employee_id']);
            if (! $employee) {
                return $this->error('Your account is not active', 401);
            }
            $training_list = Training::isActive()->where('who_can_train', 'employee')
                ->where('parent_training_id', null)
                ->whereHas('trainingLocation', function ($query) use ($employee) {
                    $query->where('location_id', $employee['primary_work_location_id'])
                        ->where('is_disable', 0);
                })
                ->with('trainingLocation', function ($query) use ($employee) {
                    $query->where('location_id', $employee['primary_work_location_id'])
                        ->where('is_disable', 0);
                })
                ->with('childTraining.trainingLocation', function ($query) use ($employee) {
                    $query->where('location_id', $employee['primary_work_location_id']);
                })
                ->orderBy('display_order', 'desc')

                ->get();
            $training_archieved = $data = [];
            $training_invites = TrainingInvite::where('emp_user_acntuser_student_type', \App\Models\Employee::class)
                ->where('emp_user_acntuser_student_id', $employee['id'])
                ->withCount(['trainingAttempt'])
                ->latest()->get();
            foreach ($training_list as $key => $training) {
                $active_training = '';
                $total_completed = $total_training = $total_invite = 0;
                $training_invite = $training_invites->firstWhere('training_id', $training['id']);
                $trainingLocation = $training->trainingLocation[0];

                if ((empty($training_invite) && $trainingLocation->is_triggered == 0) || (isset($training_invite) && $training_invite->completed_datetime == null)) {
                    $data[$key]['training'] = $training;
                    $data[$key]['training']['training_invite'] = $training_invite;
                    $data[$key]['training']['active_training'] = $training['id'];
                } elseif (((empty($training_invite) && $trainingLocation->is_triggered == 0) || (! empty($training->childTraining) && count($training->childTraining) > 0))) {
                    $total_training++;
                    $sub_data = [];
                    $first_completed_training = '';
                    if (! empty($training_invite)) {
                        $total_invite++;
                        if ($training_invite->completed_datetime != '') {
                            $total_completed++;
                            $first_completed_training = $training['id'];
                        } else {
                            $active_training = $training['id'];
                        }
                    }
                    foreach ($training->childTraining as $key_child => $value_child) {
                        $total_training++;
                        $training_invite_child = $training_invites->firstWhere('training_id', $value_child->id);

                        if (empty($training_invite_child)) {
                            continue;
                        }
                        $total_invite++;

                        if (isset($training_invite_child) && $training_invite_child->completed_datetime != null) {
                            $total_completed++;
                            if ($first_completed_training == '') {
                                $first_completed_training = $value_child->id;
                            }
                        }
                        if ($active_training == '' && $training_invite_child->completed_datetime == null) {
                            $active_training = $value_child->id;
                        }
                    }
                    if ($total_completed < $total_training && $total_invite > 0) {
                        $data[$key]['training'] = $training;
                        $data[$key]['training']['training_invite'] = $training_invite;
                        $data[$key]['training']['active_training'] = ($active_training == '' ? $first_completed_training : $active_training);
                    }
                }
                foreach ($training->childTraining as $key_child => $value_child) {
                    $training_invite = $training_invites->firstWhere('training_id', $value_child['id']);
                    $training->childTraining[$key_child]['training_invite'] = $training_invite;
                }

                //archieved count
                $training_invites_archieved = $training_invites->firstWhere('training_id', $training['id']);
                if (isset($training_invites_archieved) && $training_invites_archieved->completed_datetime != null) {
                    $is_archieved = 1;
                    if (! empty($training->childTraining) && count($training->childTraining) > 0) {
                        foreach ($training->childTraining as $key_child => $value_child) {
                            $training_invite_child = $training_invites->firstWhere('training_id', $value_child->id);
                            if (! (isset($training_invite_child) && $training_invite_child->completed_datetime != null)) {
                                $is_archieved = 0;
                                break;
                            }
                        }
                    }
                    if ($is_archieved == 1) {
                        $training_archieved[] = $training;
                    }
                }
            }
            $data = [
                'training_list' => $data,
                'employee_location_count' => $employee->employee_secondary_work_location_count + 1,
            ];

            $data['total_count']['available_training_count_emp'] = count($data['training_list']);
            $data['total_count']['archived_training_count_emp'] = count($training_archieved);

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('EmployeeportalController/getRecommendedTraining() => '.$e->getMessage());
            Log::error('EmployeeportalController/getRecommendedTraining() => '.$e->getLine());
            Log::error('EmployeeportalController/getRecommendedTraining()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get Recommended Training
     *
     * @return \Illuminate\Http\Response
     */
    public function getArchivedTraining(Request $request)
    {
        $validator_rules = [
            'employee_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $employee = Employee::withCount('employeeSecondaryWorkLocation')->isActive()->find($request['employee_id']);
            if (! $employee) {
                return $this->error('Your account is not active', 401);
            }
            $training_list = Training::isActive()->where('who_can_train', 'employee')
                ->where('parent_training_id', null)
                ->whereHas('trainingLocation', function ($query) use ($employee) {
                    $query->where('location_id', $employee['primary_work_location_id'])
                        ->where('is_disable', 0);
                })
                ->with('trainingLocation', function ($query) use ($employee) {
                    $query->where('location_id', $employee['primary_work_location_id'])
                        ->where('is_disable', 0);
                })
                ->with('childTraining.trainingLocation', function ($query) use ($employee) {
                    $query->where('location_id', $employee['primary_work_location_id']);
                })
                ->orderBy('display_order', 'desc')
                ->get();
            $data = [];
            $training_invites = TrainingInvite::where('emp_user_acntuser_student_type', \App\Models\Employee::class)
                ->where('emp_user_acntuser_student_id', $employee['id'])
                ->withCount(['trainingAttempt'])
                ->latest()->get();
            foreach ($training_list as $key => $training) {
                $training_invite = $training_invites->firstWhere('training_id', $training['id']);
                if (isset($training_invite) && $training_invite->completed_datetime != null) {
                    $is_archieved = 1;
                    if (! empty($training->childTraining) && count($training->childTraining) > 0) {
                        foreach ($training->childTraining as $key_child => $value_child) {
                            $training_invite_child = $training_invites->firstWhere('training_id', $value_child->id);
                            if (! (isset($training_invite_child) && $training_invite_child->completed_datetime != null)) {
                                $is_archieved = 0;
                                break;
                            }
                        }
                    }
                    if ($is_archieved == 1) {
                        $data[$key]['training'] = $training;
                        $data[$key]['training']['training_invite'] = $training_invite;
                    }
                }
            }
            $data = [
                'training_list' => $data,
                'employee_location_count' => $employee->employee_secondary_work_location_count + 1,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('EmployeeportalController/getArchivedTraining() => '.$e->getMessage());
            Log::error('EmployeeportalController/getArchivedTraining()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * training listing for recommend
     *
     * @return \Illuminate\Http\Response
     */
    public function TrainingListForReport(Request $request)
    {
        $validator_rules = [
            'employee_id' => 'required|numeric',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $employee = Employee::where('id', $request['employee_id'])->with('employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation.location')->isActive()->first();
            if (! $employee) {
                return $this->error('Your account is not active', 401);
            }

            $training_list = TrainingLocation::where('location_id', $employee['primary_work_location_id'])
                ->where('is_disable', 0)
                ->with(['training'])->whereHas('training', function ($que) {
                    $que->isActive()->where('who_can_train', 'employee')->where('parent_training_id', null);
                })->with('training.childTraining.trainingLocation', function ($query) use ($employee) {
                    $query->where('location_id', $employee['primary_work_location_id']);
                })
                ->get()->sortByDesc(function ($training_location, $key) {
                    return $training_location->training->display_order;
                });

            $hasInvites = TrainingInvite::where('emp_user_acntuser_student_id', $employee['id'])->where('emp_user_acntuser_student_type', \App\Models\Employee::class)->count();
            $finalData = [];
            if ($hasInvites > 0) {
                foreach ($training_list as $key => $training) {
                    $training_invite = TrainingInvite::withCount('trainingAttempt')
                        ->where('emp_user_acntuser_student_id', $employee['id'])->where('emp_user_acntuser_student_type', \App\Models\Employee::class)
                        ->where('training_id', $training['training']['id'])->orderBy('id', 'desc')->get();

                    if (count($training_invite) > 0 || ($training->is_triggered == 1 && (! empty($training->training->childTraining) && count($training->training->childTraining) > 0))) {
                        $tempData = $training;
                        $tempData['location'] = $employee['employeePrimaryWorkLocation'];
                        $tempData['training_invites'] = $training_invite;
                        $tempData['training_invite_count'] = count($training_invite);
                        $training_invite_incomplete = $training_invite->whereNotNull('completed_datetime')->whereNotNull('completed_attempt_id');
                        $tempData['training_invite_complete_count'] = count($training_invite_incomplete);
                        $secondary_work_location_list = [];
                        $training_location = TrainingLocation::where('training_id', $training['training']['id'])->get();
                        foreach ($employee['employeeSecondaryWorkLocation'] as $SLkey => $SLvalue) {
                            $is_added_to_location = $training_location->firstWhere('location_id', $SLvalue->location_id);
                            if ($is_added_to_location) {
                                $secondary_work_location_list[] = $SLvalue;
                            }
                        }
                        $first_completed_training_id = '';
                        $tempData['child_calculation'] = [];
                        $child_calculation = [];
                        $total_invite = count($training_invite);
                        $tempData['active_training'] = '';
                        if ($total_invite > 0 && $total_invite > $tempData['training_invite_complete_count']) {
                            $tempData['active_training'] = $training['training']['id'];
                        }
                        if ($total_invite == $tempData['training_invite_complete_count'] && $total_invite > 0) {
                            $first_completed_training_id = $training['training']['id'];
                        }
                        foreach ($training->training->childTraining as $key_child => $value_child) {
                            $child_calculation[$value_child->id]['training_invite_count'] = $child_calculation[$value_child->id]['training_invite_incomplete'] = 0;
                            $training_invites = TrainingInvite::where('emp_user_acntuser_student_type', \App\Models\Employee::class)
                                ->where('emp_user_acntuser_student_id', $employee['id'])
                                ->where('training_id', $value_child->id)
                                ->latest()->first();
                            if (! empty($training_invites)) {
                                $child_calculation[$value_child->id]['training_invite_count'] = 1;
                                if ($training_invites->completed_datetime != '' && $training_invites->completed_attempt_id != '') {
                                    $child_calculation[$value_child->id]['training_invite_incomplete'] = 1;
                                }
                                if ($training_invites->completed_attempt_id != '' && $first_completed_training_id == '') {
                                    $first_completed_training_id = $value_child->id;
                                }
                            } else {
                                continue;
                            }

                            if ($tempData['active_training'] == '' && $training_invites->completed_datetime == '' && $training_invites->completed_attempt_id == '') {
                                $tempData['active_training'] = $value_child->id;
                            }
                            $total_invite++;
                        }
                        if ($tempData['active_training'] == '') {
                            $tempData['active_training'] = $first_completed_training_id;
                        }

                        $tempData['child_calculation'] = $child_calculation;

                        $tempData['SecondaryWorkLocation'] = $secondary_work_location_list;
                        if ($total_invite > 0) {
                            $finalData[] = $tempData;
                        }
                    }
                }
            }

            //exit;
            return $this->success(Config::get('constants.SUCCESS'), 200, $finalData);
        } catch (\Exception $e) {
            Log::error('EmployeeportalController/TrainingListForReport() => '.$e->getMessage());
            Log::error('EmployeeportalController/TrainingListForReport()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * training quiz
     *
     * @return \Illuminate\Http\Response
     */
    public function TrainingQuiz(Request $request)
    {
        try {
            $validator_rules = [
                'training_id' => 'required|numeric',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $training_quiz_data = Training::select(['id', 'training_code', 'title'])
                ->with(['TrainingQuestion' => function ($trainingQuestionQuery) {
                    $trainingQuestionQuery->select(['id', 'training_id', 'question', 'display_order', 'is_active'])->isActive()->orderBy('display_order', 'asc');
                }, 'TrainingQuestion.TrainingQuestionAnswer' => function ($trainingQuestionAnswerQuery) {
                    $trainingQuestionAnswerQuery->select(['id', 'training_question_id', 'answer']);
                }])->where('id', $request['training_id'])->first();

            return $this->success(Config::get('constants.SUCCESS'), 200, $training_quiz_data);
        } catch (\Exception $e) {
            Log::error('EmployeeportalController/TrainingQuiz() => '.$e->getMessage());
            Log::error('EmployeeportalController/TrainingQuiz()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * training complete record
     *
     * @return \Illuminate\Http\Response
     */
    public function addTrainingCompleteRecord(Request $request)
    {
        try {
            $validator_rules = [
                'invite_id' => 'required|numeric',
                'queans' => 'required|array',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            if ($request['invite_id'] > 0) {

                $training_data = TrainingInvite::where('id', '=', $request['invite_id'])
                    ->with(['training', 'emp_user_acntuser_student'])
                    ->first();
                $training_attempt_data = [
                    'invite_id' => $request['invite_id'],
                    'attempted_from' => 'portal',
                ];
                $add_training_attempt_data = TrainingAttempt::create($training_attempt_data);
                if ($add_training_attempt_data['id'] > 0) {
                    $training_quiz_attempt_data = [];
                    foreach ($request['queans'] as $data) {
                        $checkAnsTrueFalse = TrainingQuestionAnswer::where('training_question_id', '=', $data['question_id'])
                            ->where('id', '=', $data['answer_id'])
                            ->first();
                        $training_quiz_attempt_data[] = [
                            'is_given_correct' => $checkAnsTrueFalse['is_correct_answer'],
                            'training_attempt_id' => $add_training_attempt_data['id'],
                            'question_id' => $data['question_id'],
                            'answer_id' => $data['answer_id'],
                            'created_at' => Carbon::now(),
                            'updated_at' => Carbon::now(),
                        ];
                    }
                    TrainingQuizAttempt::insert($training_quiz_attempt_data);
                    $total_que_attempt = TrainingQuizAttempt::where('training_attempt_id', '=', $add_training_attempt_data['id'])->count();
                    $total_correct_ans_attempt = TrainingQuizAttempt::where('training_attempt_id', '=', $add_training_attempt_data['id'])->where('is_given_correct', '=', 'yes')->count();
                    $result_of_training_quiz = round(($total_correct_ans_attempt * 100) / $total_que_attempt);
                    if ($result_of_training_quiz >= 70) {
                        //complete training and ref token blank
                        $training_invite_data = [
                            'ref_token' => '',
                            'completed_datetime' => gmdate('Y-m-d H:i:s'),
                            'completed_attempt_id' => $add_training_attempt_data['id'],
                        ];
                        $update_invite_data = TrainingInvite::findOrFail($request['invite_id']);
                        $update_invite_data->update($training_invite_data);
                        $trainingController = new TrainingController;
                        $trainingController->moveTrainingToArchive($training_data->emp_user_acntuser_student->primary_work_location_id, $training_data->training_id);

                    }
                    $data = [
                        'training_data' => $training_data,
                        'total_que_attempt' => $total_que_attempt,
                        'total_correct_ans_attempt' => $total_correct_ans_attempt,
                        'result_of_training_quiz' => $result_of_training_quiz,
                    ];
                    DB::commit();

                    return $this->success(Config::get('constants.SUCCESS'), 200, $data);
                } else {
                    DB::rollback();

                    return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
                }
            } else {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('EmployeeportalController/addTrainingCompleteRecord() => '.$e->getMessage());
            Log::error('EmployeeportalController/addTrainingCompleteRecord()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get Training Certificate
     *
     * @return \Illuminate\Http\Response
     */
    public function getTrainingCertificate(Request $request)
    {
        $validator_rules = [
            'location_id' => 'required',
            'invite_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $location = Location::findOrFail($request['location_id']);
            $training_invite = TrainingInvite::with(['training', 'emp_user_acntuser_student'])->findOrFail($request['invite_id']);
            $complete_date = date('F d,Y', strtotime($training_invite->completed_datetime));
            $file = public_path('policydocuments/TrainingCertificate.docx');
            $phpword = new \PhpOffice\PhpWord\TemplateProcessor($file);
            $storage_path = storage_path('app/public');
            $phpword->setValue('EMPLOYEE_NAME', htmlspecialchars($training_invite->emp_user_acntuser_student->first_name).' '.htmlspecialchars($training_invite->emp_user_acntuser_student->last_name));
            $phpword->setValue('TRAINING_MODULE_NAME', htmlspecialchars($training_invite->training->title));
            $phpword->setValue('DATE', $complete_date);
            $phpword->setValue('COMPANY_NAME', htmlspecialchars($location->company_name));
            $generated_training_certificate = $storage_path.'/generatedpolicydocuments/TrainingCertificate_'.$training_invite->id.'.docx';
            $phpword->saveAs($generated_training_certificate);
            $generated_certificate_directory_path = $storage_path.'/generatedpolicydocuments/';
            $generated_training_certificate_pdf = asset('storage/generatedpolicydocuments/TrainingCertificate_'.$training_invite->id.'.pdf');
            if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                // change libreoffice path as per installation path from your machine
                exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  '.$generated_certificate_directory_path.' '.$generated_training_certificate);
            } else {
                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir '.$generated_certificate_directory_path.' '.$generated_training_certificate);
            }
            unlink($generated_training_certificate);

            return $this->success(Config::get('constants.SUCCESS'), 200, $generated_training_certificate_pdf);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('EmployeeportalController/getTrainingCertificate() => '.$e->getMessage());
            Log::error('EmployeeportalController/getTrainingCertificate()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get invite details api
     *
     * @return \Illuminate\Http\Response
     */
    public function getInviteDetails($id)
    {
        try {
            $invite_data = TrainingInvite::where('id', '=', $id)->with(['training'])->first();

            return $this->success(Config::get('constants.SUCCESS'), 200, $invite_data);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('EmployeeportalController/getInviteDetails() => '.$e->getMessage());
            Log::error('EmployeeportalController/getInviteDetails()[data] => '.json_encode([$id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * employee portal hipaa toggle
     *
     * @return \Illuminate\Http\Response
     */
    public function employeePortalHipaaToggle(Request $request)
    {
        $validator_rules = [
            'stripe_customer_id' => 'required',
            'user_email' => 'required|email',
            'employee_email' => 'required|email',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            Stripe\Stripe::setApiKey(Config::get('app.stripe_secret_key'));
            $stripe_customer = Stripe\Customer::retrieve($request->stripe_customer_id);
            if (! empty($stripe_customer) && isset($stripe_customer->id) && $stripe_customer->id) {
                $user = User::where(['stripe_customer_id' => $request->stripe_customer_id, 'email' => $request->user_email])->first();
                if ($user) {
                    if (! $user->is_active || $user->account_status == 'Frozen') {
                        return $this->error(Config::get('constants.EMPLOYEE.PCO_INACTIVE'), 200, ['is_user_found' => 1]);
                        exit;
                    } elseif (! $user->is_account_verified) {
                        return $this->error(Config::get('constants.EMPLOYEE.PCO_NOTVERIFIED'), 200, ['is_user_found' => 1]);
                        exit;
                    } else {
                        $employee = Employee::where('email', $request->employee_email)->where('user_id', $user->id)->first();
                        if ($employee) {
                            if ($employee->status == 'inactive') {
                                return $this->error(Config::get('constants.EMPLOYEE.EMP_INACTIVE'), 200, ['is_user_found' => 1]);
                                exit;
                            } else {
                                $otp = mt_rand(1000, 9999);
                                $employee_login = $employee->employeePortalLogin()->create(['otp' => $otp, 'login_attempt' => 0, 'created_at' => gmdate('Y-m-d H:i:s')]);
                                $request->session()->forget('employee_portal_login_id');
                                $request->session()->forget('employee_id');
                                $request->session()->save();
                                $request->session()->put('employee_portal_login_id', $employee_login->id);
                                $request->session()->put('employee_id', $employee_login->employee_id);
                                $request->session()->save();

                                return $this->success(Config::get('constants.SUCCESS'), 200, ['is_user_found' => 1, 'redirect_url' => Config::get('app.emp_portal_url')]);
                                exit;
                            }
                        } else {
                            return $this->error(Config::get('constants.EMPLOYEE.PRODUCT_SWITCH_FAIL'), 200, ['is_user_found' => 0]);
                            exit;
                        }
                    }

                    return $this->error(Config::get('constants.EMPLOYEE.PRODUCT_SWITCH_FAIL'), 200, ['is_user_found' => 0]);
                } else {
                    return $this->error(Config::get('constants.EMPLOYEE.PRODUCT_SWITCH_FAIL'), 200, ['is_user_found' => 0]);
                }
            } else {
                return $this->error(Config::get('constants.EMPLOYEE.PRODUCT_SWITCH_FAIL'), 200, ['is_user_found' => 0]);
            }
        } catch (\Exception $e) {
            Log::error('EmployeeportalController/employeePortalHipaaToggle() => '.$e->getMessage());
            Log::error('EmployeeportalController/employeePortalHipaaToggle()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.EMPLOYEE.PRODUCT_SWITCH_FAIL'), 200, ['is_user_found' => 0]);
        }
    }

    /**
     * get sub trainings
     *
     * @return \Illuminate\Http\Response
     */
    public function TrainingDetailForChildTraining(Request $request)
    {
        try {
            $validator_rules = [
                'training_id' => 'required|numeric',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $employee_id = $request->session()->get('employee_id');
            $employee = Employee::withCount('employeeSecondaryWorkLocation')->isActive()->find($employee_id);

            $training_id = $request->input('training_id');
            $training_list = Training::isActive()->where('who_can_train', 'employee')
                ->where('id', $training_id)
                ->whereHas('trainingLocation', function ($query) use ($employee) {
                    $query->where('location_id', $employee['primary_work_location_id'])
                        ->where('is_disable', 0);
                })
                ->with('trainingLocation', function ($query) use ($employee) {
                    $query->where('location_id', $employee['primary_work_location_id'])
                        ->where('is_disable', 0);
                })
                ->orderBy('display_order', 'desc')
                ->first();
            $data = [];
            if (! empty($training_list)) {
                $training_invite = TrainingInvite::where('emp_user_acntuser_student_type', \App\Models\Employee::class)
                    ->where('emp_user_acntuser_student_id', $employee['id'])
                    ->where('training_id', $training_id)
                    ->withCount(['trainingAttempt'])
                    ->latest()->first();
                $data['training'] = $training_list;
                $data['training']['training_invite'] = $training_invite;
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, ['single_training' => $data]);
        } catch (\Exception $e) {
            Log::error('EmployeeportalController/TrainingDetailForChildTraining() => '.$e->getMessage());
            Log::error('EmployeeportalController/TrainingDetailForChildTraining()[data] => '.json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get sub trainings for trainig report
     *
     * @return \Illuminate\Http\Response
     */
    public function TrainingReportForChildTraining(Request $request)
    {
        try {
            $validator_rules = [
                'training_id' => 'required|numeric',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $employee_id = $request->session()->get('employee_id');
            $training_id = $request->input('training_id');
            $employee = Employee::where('id', $employee_id)->with('employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation.location')->isActive()->first();

            $hasInvites = TrainingInvite::where('emp_user_acntuser_student_id', $employee_id)->where('emp_user_acntuser_student_type', \App\Models\Employee::class)->count();
            $finalData = '';

            $training = TrainingLocation::where('location_id', $employee['primary_work_location_id'])
                ->where('training_id', $training_id)
                ->with(['training'])
                ->first();
            if ($hasInvites > 0) {
                $training_invite = TrainingInvite::withCount('trainingAttempt')
                    ->where('emp_user_acntuser_student_id', $employee['id'])->where('emp_user_acntuser_student_type', \App\Models\Employee::class)
                    ->where('training_id', $training_id)->orderBy('id', 'desc')->get();
                if (count($training_invite) > 0) {
                    $tempData = $training;
                    $tempData['location'] = $employee['employeePrimaryWorkLocation'];
                    $tempData['training_invites'] = $training_invite;
                    $tempData['training_invite_count'] = count($training_invite);
                    $secondary_work_location_list = [];
                    foreach ($employee['employeeSecondaryWorkLocation'] as $SLkey => $SLvalue) {
                        $is_added_to_location = TrainingLocation::where('location_id', $SLvalue->location_id)->where('training_id', $training_id)->first();
                        if ($is_added_to_location) {
                            $secondary_work_location_list[] = $SLvalue;
                        }
                    }
                    $tempData['SecondaryWorkLocation'] = $secondary_work_location_list;
                    $finalData = $tempData;
                }
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, ['single_training' => $finalData]);
        } catch (\Exception $e) {
            Log::error('EmployeeportalController/TrainingReportForChildTraining() => '.$e->getMessage());
            Log::error('EmployeeportalController/TrainingReportForChildTraining()[data] => '.json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }

    }
    /************************** */
    /*API methods - end
    /*************************** */
}
