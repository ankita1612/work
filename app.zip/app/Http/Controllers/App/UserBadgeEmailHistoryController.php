<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\UserBadgeEmailHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Traits\ApiResponser;
class UserBadgeEmailHistoryController extends Controller
{    
    use ApiResponser;
    public function trackOpenEmailPopup($email_history_id, $open_type)
    {
        try {
            $email_history_id = base64_decode($email_history_id);
            $open_type = base64_decode($open_type);

            $badge_data = UserBadgeEmailHistory::find($email_history_id);
            if(!empty($badge_data) && in_array($open_type,array('email','popup'))){             
                if($open_type =="email")
                {
                    if($badge_data['is_mail_open'] == false){
                        $badge_data->update(['is_mail_open' => true, 'mail_open_date' => gmdate('Y-m-d H:i:s')]);
                    }
                
                    $transparentGif = base64_decode(
                        'R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw=='
                    );

                    return response($transparentGif)
                        ->header('Content-Type', 'image/gif');
                }
                else if($open_type == "popup"){
                    $badge_data->update(['is_popup_triggered' => true, 'popup_triggered_date' => gmdate('Y-m-d H:i:s')]);                   
                    $badge_data->increment('popup_open_count');
                    return $this->success(Config::get('constants.SUCCESS'), 200);
                }                
            }
        } catch (\Exception $e) {
            Log::error('UserBadgeEmailHistoryController/trackOpenEmailPopup() => '.$e->getMessage());
            Log::error('UserBadgeEmailHistoryController/trackOpenEmailPopup Line # => '.$e->getMessage());
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }    
    public function trackOpenAttachment($email_history_id, $download_type)
    { 
        try {
            $email_history_id = base64_decode($email_history_id);
            $download_type = base64_decode($download_type);
            
            $badge_data = UserBadgeEmailHistory::findOrFail($email_history_id);
            
            if(!empty($badge_data) && in_array($download_type,array('email_attachment','popup_attachment'))){                              
                if($download_type== 'email_attachment'){                    
                    if($badge_data['is_mail_attachment_download'] == false)
                    {
                        $badge_data->update([
                            'is_mail_attachment_download' => true, 
                            'mail_attachment_download_date' => gmdate('Y-m-d H:i:s')
                        ]);                     
                    }                    
                                        
                    $appUrl = Config::get('app.url');
                    $file_name = 'Abyde-HIPAA for Covered Entities Certified Badge-2025.png';
                    echo '<script>
                        window.onload = function() {
                            const app_url = "' . $appUrl . '";
                            const file_name = "'. $file_name . '";
                            const link = document.createElement("a");
                            link.href = app_url + "/badge/Abyde-HIPAA for Covered Entities Certified Badge-2025.png";
                            link.download = file_name;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            setTimeout(() => window.close(), 100);
                        };
                    </script>';                    
                    exit;
                }
                else if($download_type== 'popup_attachment'){                    
                    if($badge_data['is_popup_attachment_download'] == false){
                        $badge_data->update([
                            'is_popup_attachment_download' => true,
                            'popup_attachment_download_date' => gmdate('Y-m-d H:i:s')
                        ]);
                    }
                    $gnerated_pdf_url="/badge/Abyde-HIPAA for Covered Entities Certified Badge-2025.png";
                    return $this->success(Config::get('constants.SUCCESS'), 200, ['file_name' => 'Abyde-HIPAA for Covered Entities Certified Badge-2025.png', 'download_url' => $gnerated_pdf_url]);
                }                
            }
            else{                
                return redirect()->route('login');
            }           
        } catch (\Exception $e) {
            Log::error('UserBadgeEmailHistoryController/trackOpenAttachment() => '.$e->getMessage());
            Log::error('UserBadgeEmailHistoryController/trackOpenAttachment Line # => '.$e->getMessage());
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }   
}