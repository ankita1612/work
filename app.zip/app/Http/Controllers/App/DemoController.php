<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\State;
use App\Traits\ApiResponser;
use Carbon\Carbon;
use Carbon\CarbonTimeZone;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;

class DemoController extends Controller
{
    use ApiResponser;

    /**
     * Demo select state page
     */
    public function showSelectState(Request $request)
    {
        return view('app.pages.demo');
    }

    /**
     * scheduled page
     */
    public function showDemoScheduled(Request $request)
    {
        // if required to show timezone
        // $parsedCarbon = Carbon::parse($request->event_start_time);
        // $timezone = new CarbonTimeZone($parsedCarbon->timezoneName);
        // $scheduled_timezone = $timezone->toRegionName(null, 0);
        // dd($scheduled_timezone);
        return view('app.pages.demoscheduled', ['request' => $request]);
    }

    /**
     * List all states
     *
     * @return \Illuminate\Http\Response
     */
    public function listStates(Request $request)
    {
        try {
            $list = State::select(['id', 'state_code', 'state_name'])
                ->with('calendlyLink')
                ->orderBy('state_name')
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('DemoController/listStates() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }
}
