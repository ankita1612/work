<?php

namespace App\Http\Controllers\App;

use App\Events\DownloadLogEvent;
use App\Exports\ExportHipaaTrainingReport;
use App\Exports\ExportStudentHipaaTrainingReport;
use App\Http\Controllers\Controller;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AccountUser;
use App\Models\EmailTemplate;
use App\Models\Employee;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\LocationNotification;
use App\Models\ModuleCompletedStatus;
use App\Models\Setting;
use App\Models\Student;
use App\Models\Training;
use App\Models\TrainingAttempt;
use App\Models\TrainingInvite;
use App\Models\TrainingLocation;
use App\Models\TrainingLocationArchived;
use App\Models\TrainingQuestionAnswer;
use App\Models\TrainingQuizAttempt;
use App\Models\UnassignedTraining;
use App\Models\User;
use App\Support\CustomLengthAwarePaginator;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\FileUpload;
use App\Traits\GetLoginUserData;
use App\Traits\GetMainUserData;
use App\Traits\Notification;
use App\Traits\SendMail;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Maatwebsite\Excel\Facades\Excel;

class TrainingController extends Controller
{
    use ApiResponser, CheckAccessRight, FileUpload, GetLoginUserData, GetMainUserData, Notification, SendMail;
    /**
     * Show training page
     *
     * @return \Illuminate\Http\Response
     */
    public function showTrainings(Request $request, $location_id = '', $current_tab = '')
    {
        if ($location_id != '') {
            $location_id = base64_decode($location_id, true);
            if ($location_id) {
                if ($this->checkAccessRight('training', $location_id, true)) {
                    $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                    $check_is_ra_completed = ModuleCompletedStatus::where(
                        [
                            'location_id' => $location_id,
                            'module' => 'risk_analysis',
                            'is_completed' => 1,
                        ]
                    )->first();
                    $emp_count = Employee::where('primary_work_location_id', $location_id)->isActive()->count();
                    if (! $check_is_ra_completed || ! $hco || $emp_count <= 0) {
                        return redirect('/dashboard');
                    }
                    $user_data = $this->getMainAccountDetails();

                    return view('app.pages.training', ['location_id' => $location_id, 'current_tab' => $current_tab]);
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    public function showTrainingStudents($location_id = '', $training_id = '')
    {
        if ($location_id != '' && $training_id != '') {
            $location_id = base64_decode($location_id, true);
            $training_id = base64_decode($training_id, true);
            if ($location_id) {
                if ($this->checkAccessRight('training', $location_id, true)) {
                    $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                    $check_is_ra_completed = ModuleCompletedStatus::where(
                        [
                            'location_id' => $location_id,
                            'module' => 'risk_analysis',
                            'is_completed' => 1,
                        ]
                    )->first();
                    $emp_count = Employee::where('primary_work_location_id', $location_id)->isActive()->count();
                    if (! $check_is_ra_completed || ! $hco || $emp_count <= 0) {
                        return redirect('/dashboard');
                    }

                    return view('app.pages.trainingStudent', ['location_id' => $location_id, 'training_id' => $training_id]);
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    public function showTrainingEmployees($location_id = '', $training_id = '')
    {
        if ($location_id != '' && $training_id != '') {
            $location_id = base64_decode($location_id, true);
            $training_id = base64_decode($training_id, true);
            if ($location_id) {
                if ($this->checkAccessRight('training', $location_id, true)) {
                    $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                    $check_is_ra_completed = ModuleCompletedStatus::where(
                        [
                            'location_id' => $location_id,
                            'module' => 'risk_analysis',
                            'is_completed' => 1,
                        ]
                    )->first();
                    $emp_count = Employee::where('primary_work_location_id', $location_id)->isActive()->count();
                    if (! $check_is_ra_completed || ! $hco || $emp_count <= 0) {
                        return redirect('/dashboard');
                    }
                    $training_data = Training::where('id', $training_id)->pluck('who_can_train');
                    $tab_title = (!$training_data->isEmpty() ? ($training_data[0] == 'employee' ? 'Manage Employees' : 'Training Insights') : '');
                    return view('app.pages.trainingEmployee', ['location_id' => $location_id, 'training_id' => $training_id, 'tab_title' => $tab_title]);
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /**
     * Training Quiz page
     *
     * @return \Illuminate\Http\Response
     */
    public function showTrainingQuiz($location_id = '', $invite_id = '', $training_id = null, $employee_id = null)
    {
        if ($location_id != '' && $invite_id != '') {
            $location_id = base64_decode($location_id, true);
            $invite_id = base64_decode($invite_id, true);
            $employee_id = isset($employee_id) ? base64_decode($employee_id, true) : $employee_id;
            $training_id = isset($training_id) ? base64_decode($training_id, true) : $training_id;
            if ($location_id && $invite_id) {
                if ($this->checkAccessRight('training', $location_id)) {
                    $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                    $check_is_ra_completed = ModuleCompletedStatus::where(
                        [
                            'location_id' => $location_id,
                            'module' => 'risk_analysis',
                            'is_completed' => 1,
                        ]
                    )->first();
                    $emp_count = Employee::where('primary_work_location_id', $location_id)->isActive()->count();
                    if (! $check_is_ra_completed || ! $hco || $emp_count <= 0) {
                        return redirect('/dashboard');
                    }
                    if ($invite_id !== 'null') {
                        $training_invite = TrainingInvite::find($invite_id);
                        if ($training_invite == null) {
                            return redirect('/training/' . base64_encode($location_id));
                        }
                        if ($training_invite['ref_token'] == '' && $training_invite['completed_datetime'] != null && $training_invite['completed_attempt_id'] != null) {
                            return redirect('/training/' . base64_encode($location_id));
                        }
                    } else {
                        if (! empty($user_data = auth()->guard('account_user')->user())) {
                            $is_hco = HipaaComplianceOfficer::where('hco_id', $user_data['id'])->where('hco_type', \App\Models\AccountUser::class)->count();
                            if ($is_hco == 0) {
                                return redirect('/training/' . base64_encode($location_id));
                            }
                        }
                        $training = Training::findOrFail($training_id);
                        $type = null;
                        if ($training->who_can_train == 'hco') {
                            $hco = HipaaComplianceOfficer::where(['location_id' => $location_id, 'hco_id' => $employee_id])->first();
                            $type = $hco->hco_type;
                        } else {
                            $type = Employee::class;
                        }

                        $training_invite = TrainingInvite::where('training_id', $training_id)
                            ->where('emp_user_acntuser_student_id', $employee_id)
                            ->where('emp_user_acntuser_student_type', $type)
                            ->whereNotNull('completed_datetime')
                            ->whereNotNull('completed_attempt_id')
                            ->latest()->first();

                        if ($training_invite) {
                            return redirect('/training/' . base64_encode($location_id));
                        }
                    }

                    return view('app.pages.trainingquiz', ['location_id' => $location_id, 'invite_id' => $invite_id ?? null, 'employee_id' => $employee_id ?? null, 'training_id' => $training_id ?? null]);
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * training listing for recommend
     *
     * @return \Illuminate\Http\Response
     */
    public function TrainingList(Request $request)
    {
        try {
            $validator_rules = [
                'tab_name' => 'required',
                'location_id' => 'required|numeric',
                'is_archived' => 'sometimes|boolean',
                'fetch_count' => 'sometimes|boolean',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $locationId = $request->input('location_id');
            $tabName = $request->input('tab_name');
            $isArchived = (int) $request->input('is_archived', 0);
            $fetch_count = (int) $request->input('fetch_count', 0);
            $hco = HipaaComplianceOfficer::where('location_id', $locationId)->with(['hco', 'location.user'])->first();
            $check_is_ra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $locationId,
                    'module' => 'risk_analysis',
                    'is_completed' => 1,
                ]
            )->first();
            $emp_count = Employee::where('primary_work_location_id', $locationId)->isActive()->count();
            if (! $check_is_ra_completed || ! $hco || $emp_count <= 0) {
                return $this->error('Complete SRA first', 200);
            }

            $user_data = $this->getLoginUserData();
            $who_can_train_array = [$tabName];

            if ($tabName == 'employee' && $user_data['user_type'] !== 'USER') {
                $who_can_train_array[] = 'hco';
            }

            $model_type = $tabName === 'employee' ? \App\Models\Employee::class : \App\Models\Student::class;
            $invite_ids_query = $tabName === 'employee'
                ? Employee::where('primary_work_location_id', $locationId)->isActive()->pluck('id')
                : Student::where('primary_work_location_id', $locationId)->pluck('id');

            $renewalDate = $hco->location->user->contract_renewal_date;
            $training_list = TrainingLocation::select('training_locations.*', 'trainings.display_order')->where('location_id', $locationId)
                ->with('schedule_by')
                ->with('training.childTraining.trainingLocation', function ($query) use ($request) {
                    $query->where('location_id', $request['location_id']);
                })
                ->whereHas('training', function ($query) use ($who_can_train_array) {
                    $query->isActive()->whereIn('who_can_train', $who_can_train_array)->where('parent_training_id', null);
                })
                ->leftJoin('trainings', 'trainings.id', '=', 'training_locations.training_id')
                ->orderBy('is_disable', 'asc')
                ->orderBy('is_triggered', 'desc')
                ->orderBy('trainings.display_order', 'DESC')
                ->get()
                ->map(function ($item) use ($hco, $invite_ids_query, $model_type, $renewalDate, $isArchived) {
                    $item->is_all_archieved = $item->is_archived;
                    $item->active_training_id = $item->training_id;
                    if ($item->is_archived == 1) {
                        foreach ($item->training->childTraining as $child_training) {

                            $child_training = $child_training->toArray();
                            if ($child_training['training_location'][0]['is_archived'] == 0) {
                                $item->is_all_archieved = $child_training['training_location'][0]['is_archived'];
                                $item->active_training_id = $child_training['training_location'][0]['training_id'];
                                break;
                            }
                        }
                    }
                    if ($isArchived == $item->is_all_archieved) {
                        // $item->display_order = $item->training->display_order;
                        $item->assigned = ($item->training->who_can_train === 'hco') ? '-' : 0;
                        $item->completed = 0;
                        $item->unassigned_trainings_count = 0;
                        $item->renewal_date = $renewalDate;
                        if ($item->is_triggered === 1) {
                            if ($item->training->who_can_train === 'hco') {
                                $invite = TrainingInvite::where([
                                    'training_id' => $item->training_id,
                                    'emp_user_acntuser_student_id' => $hco->hco_id,
                                    'emp_user_acntuser_student_type' => $hco->hco_type,
                                ])->latest()->first();

                                $item->unassigned_trainings_count = UnassignedTraining::where([
                                    'training_id' => $item->training_id,
                                    'emp_user_acntuser_student_id' => $hco->hco_id,
                                    'emp_user_acntuser_student_type' => $hco->hco_type,
                                    'is_hidden' => 0,
                                ])->count();

                                $item->unassigned_hidden_count = UnassignedTraining::where([
                                    'training_id' => $item->training_id,
                                    'emp_user_acntuser_student_id' => $hco->hco_id,
                                    'emp_user_acntuser_student_type' => $hco->hco_type,
                                    'is_hidden' => 1,
                                ])->count();

                                $item->assigned = $invite ? ($hco->hco->first_name . ' ' . $hco->hco->last_name) : '-';
                                $item->completed = $invite && $invite->completed_attempt_id && $invite->completed_datetime ? 1 : 0;

                                if ($item->active_training_id == $item->training_id && $item->assigned == '-') {
                                    foreach ($item->training->childTraining as $child_training) {
                                        $child_training = $child_training->toArray();
                                        $invite_child = TrainingInvite::where([
                                            'training_id' => $child_training['training_location'][0]['training_id'],
                                            'emp_user_acntuser_student_id' => $hco->hco_id,
                                            'emp_user_acntuser_student_type' => $hco->hco_type,
                                        ])->latest()->first();

                                        if ($child_training['training_location'][0]['is_archived'] == 0 && ! empty($invite_child) && $invite_child->completed_datetime == '') {
                                            $item->active_training_id = $child_training['training_location'][0]['training_id'];
                                            break;
                                        }
                                    }
                                }
                            } else {
                                $invites = TrainingInvite::where([
                                    'training_id' => $item->training_id,
                                    'emp_user_acntuser_student_type' => $model_type,
                                ])
                                    ->whereIn('emp_user_acntuser_student_id', $invite_ids_query)
                                    ->orderBy('created_at', 'desc')
                                    ->get()
                                    ->unique('emp_user_acntuser_student_id');

                                $item->unassigned_trainings_count = UnassignedTraining::where([
                                    'training_id' => $item->training_id,
                                    'location_id' => $item->location_id,
                                    'emp_user_acntuser_student_type' => $model_type,
                                    'is_hidden' => 0,
                                ])
                                    ->whereIn('emp_user_acntuser_student_id', $invite_ids_query)
                                    ->count();

                                $item->unassigned_hidden_count = UnassignedTraining::where([
                                    'training_id' => $item->training_id,
                                    'location_id' => $item->location_id,
                                    'emp_user_acntuser_student_type' => $model_type,
                                    'is_hidden' => 1,
                                ])
                                    ->whereIn('emp_user_acntuser_student_id', $invite_ids_query)
                                    ->count();

                                $item->assigned = $invites->count();
                                $item->completed = $invites->whereNotNull('completed_datetime')->whereNotNull('completed_attempt_id')->count();
                            }
                        }

                        return $item;
                    }
                })->filter()->values();
            $total_count['available_training_count_emp'] = $total_count['archived_training_count_emp'] = $total_count['available_training_count_stu'] = $total_count['archived_training_count_stu'] = 0;
            if ($fetch_count == 1) {
                $count_arr = [['name' => 'available_training_count_emp', 'tab_name' => 'employee', 'is_archived' => 0, 'total' => 0], ['name' => 'archived_training_count_emp', 'tab_name' => 'employee', 'is_archived' => 1, 'total' => 0], ['name' => 'available_training_count_stu', 'tab_name' => 'student', 'is_archived' => 0, 'total' => 0], ['name' => 'archived_training_count_stu', 'tab_name' => 'student', 'is_archived' => 1, 'total' => 0]];
                for ($i = 0; $i < count($count_arr); $i++) {
                    $tabName = $count_arr[$i]['tab_name'];
                    $isArchived = (int) $count_arr[$i]['is_archived'];
                    $who_can_train_array = [$tabName];

                    if ($tabName == 'employee' && $user_data['user_type'] !== 'USER') {
                        $who_can_train_array[] = 'hco';
                    }

                    $training_total = TrainingLocation::select('training_locations.*')->where('location_id', $locationId)
                        ->with('training.childTraining.trainingLocation', function ($query) use ($request) {
                            $query->where('location_id', $request['location_id']);
                        })
                        ->whereHas('training', function ($query) use ($who_can_train_array) {
                            $query->isActive()->whereIn('who_can_train', $who_can_train_array)->where('parent_training_id', null);
                        })
                        ->leftJoin('trainings', 'trainings.id', '=', 'training_locations.training_id')
                        ->get()
                        ->map(function ($item) use ($isArchived) {
                            $item->is_all_archieved = $item->is_archived;
                            if ($item->is_archived == 1) {
                                foreach ($item->training->childTraining as $child_training) {
                                    $child_training = $child_training->toArray();
                                    if ($child_training['training_location'][0]['is_archived'] == 0) {
                                        $item->is_all_archieved = $child_training['training_location'][0]['is_archived'];
                                        break;
                                    }
                                }
                            }
                            if ($isArchived == $item->is_all_archieved) {
                                return $item;
                            }
                        })->filter()->values()->count();
                    $count_arr[$i]['total'] = $training_total;
                }
                $total_count['available_training_count_emp'] = $count_arr[0]['total'];
                $total_count['archived_training_count_emp'] = $count_arr[1]['total'];
                $total_count['available_training_count_stu'] = $count_arr[2]['total'];
                $total_count['archived_training_count_stu'] = $count_arr[3]['total'];
            }

            return $this->success(Config::get('constants.TRAINING.TRAINING_LIST'), 200, ['training_list' => $training_list, 'total_count' => $total_count]);
        } catch (\Exception $e) {
            Log::error('TrainingController/TrainingList() => ' . $e->getMessage());
            Log::error('TrainingController/TrainingList()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Employee list for training quiz
     *
     * @return \Illuminate\Http\Response
     */
    public function EmployeeListForTrainingQuiz(Request $request)
    {
        try {
            $validator_rules = [
                'training_id' => 'required|numeric',
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $hco_data = [];
            $emp_list = [];
            $training_data = Training::where('id', $request['training_id'])
                ->with('trainingLocation', function ($query) use ($request) {
                    $query->where('is_disable', 0)
                        ->where('location_id', $request->location_id);
                })
                ->first();
            $emp_count = Employee::where('primary_work_location_id', $request->location_id)->isActive()->count();
            if (! empty($training_data->trainingLocation)) {
                $is_triggered = $training_data->trainingLocation[0]->is_triggered;

                if ($training_data['who_can_train'] == 'hco' && $emp_count > 0) {
                    $hco_list = HipaaComplianceOfficer::where('location_id', $request['location_id'])->with(['hco'])->first();
                    if ($hco_list) {
                        $modelClass = ($hco_list->hco_type == \App\Models\AccountUser::class) ? AccountUser::class : User::class;

                        $hco_query = $modelClass::select(['id', 'first_name', 'last_name', 'email'])
                            ->where('id', $hco_list->hco_id)
                            ->with(['TrainingInvite' => function ($query) use ($request, $is_triggered) {
                                $query->where('training_id', $request['training_id'])
                                    ->when(! $is_triggered, function ($q) {
                                        $q->whereNull('completed_datetime');
                                    });
                            }]);

                        if ($is_triggered) {
                            $hco_query = $hco_query->whereHas('TrainingInvite', function ($query) use ($request) {
                                $query->where('training_id', $request['training_id'])->whereNull('completed_datetime');
                            });
                        } else {
                            $hco_query = $hco_query->where(function ($query) use ($request) {
                                $query->whereDoesntHave('TrainingInvite', function ($subQuery) use ($request) {
                                    $subQuery->where('training_id', $request['training_id']);
                                })
                                    ->orWhereHas('TrainingInvite', function ($subQuery) use ($request) {
                                        $subQuery->where('training_id', $request['training_id'])
                                            ->whereNull('completed_datetime');
                                    });
                            });
                        }
                        $hco_data = $hco_query->first();
                    }
                }
                if ($training_data['who_can_train'] == 'employee') {
                    $emp_list = Employee::select(['id', 'first_name', 'last_name'])
                        ->where('primary_work_location_id', $request['location_id'])
                        ->isActive()
                        ->with(['TrainingInvite' => function ($query) use ($request, $is_triggered) {
                            $query->where('training_id', $request['training_id'])
                                ->when(! $is_triggered, function ($q) {
                                    $q->whereNull('completed_datetime');
                                });
                        }]);
                    if ($is_triggered) {
                        $emp_list = $emp_list->whereHas('TrainingInvite', function ($query) use ($request) {
                            $query->where('training_id', $request['training_id'])->whereNull('completed_datetime');
                        });
                    } else {
                        $emp_list = $emp_list->where(function ($query) use ($request) {
                            $query->whereDoesntHave('TrainingInvite', function ($subQuery) use ($request) {
                                $subQuery->where('training_id', $request['training_id']);
                            })
                                ->orWhereHas('TrainingInvite', function ($subQuery) use ($request) {
                                    $subQuery->where('training_id', $request['training_id'])
                                        ->whereNull('completed_datetime');
                                });
                        });
                    }
                    $emp_list = $emp_list->orderBy('created_at', 'desc')->orderBy('id', 'desc')
                        ->get();
                }
            }
            $data = [
                'hco_list' => $hco_data,
                'emp_list' => $emp_list,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('TrainingController/EmployeeListForTrainingQuiz() => ' . $e->getMessage());
            Log::error('TrainingController/EmployeeListForTrainingQuiz()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Student list for training quiz
     *
     * @return \Illuminate\Http\Response
     */
    public function studentListForTrainingQuiz(Request $request)
    {
        try {
            $validator_rules = [
                'training_id' => 'required|numeric',
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $training_data = Training::where('id', $request['training_id'])->first();
            $student_list = [];
            if ($training_data['who_can_train'] == 'student') {
                $student_list_unfiltered = Student::select(['id', 'first_name', 'last_name'])
                    ->with(['TrainingInvite' => function ($query) use ($request) {
                        $query->where('training_id', $request['training_id']);
                    }])
                    ->where('primary_work_location_id', $request['location_id'])
                    ->whereHas('TrainingInvite', function ($query) use ($request) {
                        $query->where('training_id', $request['training_id']);
                    })
                    ->orderBy('created_at', 'desc')->orderBy('id', 'desc')
                    ->get();
                $student_list = $student_list_unfiltered->filter(function ($stu) {
                    return isset($stu->TrainingInvite) && $stu->TrainingInvite->ref_token != '';
                })->values()->all();
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $student_list);
        } catch (\Exception $e) {
            Log::error('TrainingController/studentListForTrainingQuiz() => ' . $e->getMessage());
            Log::error('TrainingController/studentListForTrainingQuiz()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * training quiz
     *
     * @return \Illuminate\Http\Response
     */
    public function TrainingQuiz(Request $request)
    {
        try {
            $validator_rules = [
                'training_id' => 'required|numeric',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $training_quiz_data = Training::select(['id', 'training_code', 'title'])
                ->with(['TrainingQuestion' => function ($trainingQuestionQuery) {
                    $trainingQuestionQuery->select(['id', 'training_id', 'question', 'display_order', 'is_active'])->isActive()->orderBy('display_order', 'asc');
                }, 'TrainingQuestion.TrainingQuestionAnswer' => function ($trainingQuestionAnswerQuery) {
                    $trainingQuestionAnswerQuery->select(['id', 'training_question_id', 'answer']);
                }])->where('id', $request['training_id'])->first();

            return $this->success(Config::get('constants.SUCCESS'), 200, $training_quiz_data);
        } catch (\Exception $e) {
            Log::error('TrainingController/TrainingQuiz() => ' . $e->getMessage());
            Log::error('TrainingController/TrainingQuiz()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    private function _checkVideoQuizTrainingCompleted($emp_data)
    {
        if (! empty($emp_data['trainingInvite'])) {
            if ($emp_data['trainingInvite']['ref_token'] == null && $emp_data['trainingInvite']['completed_attempt_id'] && $emp_data['trainingInvite']['completed_datetime']) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * training complete record
     *
     * @return \Illuminate\Http\Response
     */
    public function addTrainingCompleteRecord(Request $request)
    {
        try {
            $validator_rules = [
                'invite_id' => 'required_without:training_id|nullable|numeric',
                'queans' => 'required|array',
                'location_id' => 'required',
                'training_id' => 'sometimes|required_without:invite_id|nullable|numeric',
                'employee_id' => 'sometimes|required_without:invite_id|nullable|numeric',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            if (empty($request['invite_id']) && $request['training_id'] && $request['employee_id']) {
                $queAnswer = $request['queans'];
                $training = Training::findOrFail($request['training_id']);
                $type = null;
                if ($training->who_can_train == 'hco') {
                    $hco = HipaaComplianceOfficer::where(['location_id' => $request['location_id'], 'hco_id' => $request['employee_id']])->first();
                    $type = $hco->hco_type;
                } else {
                    $type = Employee::class;
                }
                if (isset($training) && isset($type)) {
                    foreach ($queAnswer as $key => $data) {
                        $checkAnsTrueFalse = TrainingQuestionAnswer::where('training_question_id', '=', $data['question_id'])
                            ->where('id', '=', $data['answer_id'])
                            ->first();
                        $queAnswer[$key]['is_given_correct'] = $checkAnsTrueFalse['is_correct_answer'];
                    }
                    $total_que_attempt = count($queAnswer);
                    $total_correct_ans_attempt = count(array_filter($queAnswer, function ($answer) {
                        return $answer['is_given_correct'] === 'yes';
                    }));
                    $result_of_training_quiz = round(($total_correct_ans_attempt * 100) / $total_que_attempt);
                    if ($result_of_training_quiz >= 70) {
                        $training_invite_data = [
                            'emp_user_acntuser_student_id' => $request['employee_id'],
                            'emp_user_acntuser_student_type' => $type,
                            'training_id' => $training->id,
                            'ref_token' => '',
                            'invite_datetime' => gmdate('Y-m-d H:i:s'),
                            'reason' => 'Standard Training',
                        ];

                        $add_training_invite = TrainingInvite::where([
                            'emp_user_acntuser_student_id' => $request['employee_id'],
                            'emp_user_acntuser_student_type' => $type,
                            'training_id' => $training->id,
                        ])
                            ->whereNull('completed_datetime')
                            ->first();
                        if (empty($add_training_invite)) {
                            $add_training_invite = TrainingInvite::create($training_invite_data);
                        }
                        $training_attempt_data = [
                            'invite_id' => $add_training_invite['id'],
                            'attempted_from' => 'software',
                        ];
                        $add_training_attempt_data = TrainingAttempt::create($training_attempt_data);
                        $add_training_attempt_data->trainingQuizAttempt()->createMany($queAnswer);
                        $add_training_invite->update(['completed_attempt_id' => $add_training_attempt_data['id'], 'completed_datetime' => gmdate('Y-m-d H:i:s')]);
                        if ($training['who_can_train'] == 'hco') {
                            $notification_HCE_AN9 = $this->getNotificationByCode('HCE-AN9');
                            LocationNotification::where('notification_id', $notification_HCE_AN9->id)
                                ->where('location_id', $request['location_id'])->where('is_completed', 0)
                                ->update(['is_completed' => 1]);
                            SendLocationDataToSalesForce::dispatch($request['location_id']);
                        }
                    }
                    $data = [
                        'training_data' => $add_training_invite ?? [],
                        'total_que_attempt' => $total_que_attempt,
                        'total_correct_ans_attempt' => $total_correct_ans_attempt,
                        'result_of_training_quiz' => $result_of_training_quiz,
                    ];
                    DB::commit();

                    return $this->success(Config::get('constants.SUCCESS'), 200, $data);
                } else {
                    DB::rollback();

                    return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
                }
            } elseif ($request['invite_id'] > 0) {

                $training_data = TrainingInvite::select(['id', 'training_id'])
                    ->where('id', '=', $request['invite_id'])
                    ->with(['training'])
                    ->first();
                $training_attempt_data = [
                    'invite_id' => $request['invite_id'],
                    'attempted_from' => 'software',
                ];
                $add_training_attempt_data = TrainingAttempt::create($training_attempt_data);
                if ($add_training_attempt_data['id'] > 0) {
                    $training_quiz_attempt = [];
                    foreach ($request['queans'] as $data) {
                        $checkAnsTrueFalse = TrainingQuestionAnswer::where('training_question_id', '=', $data['question_id'])
                            ->where('id', '=', $data['answer_id'])
                            ->first();
                        $data['is_given_correct'] = $checkAnsTrueFalse['is_correct_answer'];
                        $data['training_attempt_id'] = $add_training_attempt_data['id'];
                        $data['created_at'] = Carbon::now();
                        $data['updated_at'] = Carbon::now();
                        $training_quiz_attempt[] = $data;
                    }
                    TrainingQuizAttempt::insert($training_quiz_attempt);
                    $total_que_attempt = TrainingQuizAttempt::where('training_attempt_id', '=', $add_training_attempt_data['id'])->count();
                    $total_correct_ans_attempt = TrainingQuizAttempt::where('training_attempt_id', '=', $add_training_attempt_data['id'])->where('is_given_correct', '=', 'yes')->count();
                    $result_of_training_quiz = round(($total_correct_ans_attempt * 100) / $total_que_attempt);
                    if ($result_of_training_quiz >= 70) {
                        //complete training and ref token blank
                        $training_invite_data = [
                            'ref_token' => '',
                            'completed_datetime' => gmdate('Y-m-d H:i:s'),
                            'completed_attempt_id' => $add_training_attempt_data['id'],
                        ];
                        $update_invite_data = TrainingInvite::findOrFail($request['invite_id']);
                        $update_invite_data->update($training_invite_data);
                        // complete notification for hco training
                        if ($training_data['training']['who_can_train'] == 'hco') {
                            $notification_HCE_AN9 = $this->getNotificationByCode('HCE-AN9');
                            LocationNotification::where('notification_id', $notification_HCE_AN9->id)
                                ->where('location_id', $request['location_id'])->where('is_completed', 0)
                                ->update(['is_completed' => 1]);
                            SendLocationDataToSalesForce::dispatch($request['location_id']);
                        }
                        $this->moveTrainingToArchive($request['location_id'], $training_data->training_id);
                    }
                    $data = [
                        'training_data' => $training_data,
                        'total_que_attempt' => $total_que_attempt,
                        'total_correct_ans_attempt' => $total_correct_ans_attempt,
                        'result_of_training_quiz' => $result_of_training_quiz,
                    ];
                    DB::commit();

                    return $this->success(Config::get('constants.SUCCESS'), 200, $data);
                } else {
                    DB::rollback();

                    return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
                }
            } else {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/addTrainingCompleteRecord() => ' . $e->getMessage());
            Log::error('TrainingController/addTrainingCompleteRecord()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get invite details api
     *
     * @return \Illuminate\Http\Response
     */
    public function getInviteDetails($id)
    {
        try {
            $invite_data = TrainingInvite::with(['emp_user_acntuser_student', 'training'])->findOrFail($id);

            return $this->success(Config::get('constants.SUCCESS'), 200, $invite_data);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/getInviteDetails() => ' . $e->getMessage());
            Log::error('TrainingController/getInviteDetails()[data] => ' . json_encode([$id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get invite details api
     *
     * @return \Illuminate\Http\Response
     */
    public function getQuizDetails($location_id, $training_id, $employee_id)
    {
        try {
            $training = Training::find($training_id);
            if ($training->who_can_train == 'hco') {
                $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                if ($hco->hco_type == \App\Models\AccountUser::class) {
                    $modelClass = AccountUser::class;
                }
                if ($hco->hco_type == \App\Models\User::class) {
                    $modelClass = User::class;
                }
            } elseif ($training->who_can_train == 'student') {
                $modelClass = Student::class;
            } elseif ($training->who_can_train == 'employee') {
                $modelClass = Employee::class;
            }
            $employee = $modelClass::select(['id', 'first_name', 'last_name', 'email'])
                ->findOrFail($employee_id);

            return $this->success(Config::get('constants.SUCCESS'), 200, ['training' => $training, 'employee' => $employee]);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/getQuizDetails() => ' . $e->getMessage());
            Log::error('TrainingController/getQuizDetails()[data] => ' . json_encode([$location_id, $training_id, $employee_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * send reminder to take training
     *
     * @return \Illuminate\Http\Response
     */
    public function sendReminderTraining(Request $request)
    {
        try {
            $validator_rules = [
                'id' => 'required|numeric',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            if ($request['id'] > 0) {
                DB::beginTransaction();
                $tempdata = [
                    'invite_datetime' => gmdate('Y:m:d H:i:s'),
                ];
                $training_invite = TrainingInvite::with('training', 'emp_user_acntuser_student')->findOrFail($request['id']);
                $user_data = $this->getMainAccountDetails();
                if ($training_invite->update($tempdata)) {
                    if ($training_invite->training->who_can_train == 'hco') {
                        $emailTemplate = EmailTemplate::where('code', 'HCE-UE32')->first();
                        $email_vars = [
                            '{%HCO_FIRST_NAME%}' => $training_invite->emp_user_acntuser_student->first_name,
                            '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        $this->sendEmail($emailTemplate->code, $html, $training_invite->emp_user_acntuser_student->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                    }
                    if ($training_invite->training->who_can_train == 'employee') {
                        $hco = HipaaComplianceOfficer::where('location_id', $training_invite->emp_user_acntuser_student->primary_work_location_id)->with('hco')->first();
                        $emailTemplate = EmailTemplate::where('code', 'HCE-UE31')->first();

                        if ($request['is_send_to_all']) {
                            $emp_list = Employee::select(['id', 'first_name', 'last_name', 'email', 'primary_work_location_id'])
                                ->where('primary_work_location_id', $request['location_id'])
                                ->where('status', 'active')
                                ->with([
                                    'TrainingInvite' => function ($qry) use ($training_invite) {
                                        $qry->where('training_id', $training_invite->training_id)
                                            ->where('ref_token', '!=', '')
                                            ->whereNull('completed_datetime')
                                            ->whereNull('completed_attempt_id');
                                    },
                                ])
                                ->orderBy('created_at', 'desc')->get();
                            if (isset($emp_list)) {
                                $emp_list = $emp_list->toArray();
                            }
                            foreach ($emp_list as $emp) {
                                if (! is_null($emp['training_invite'])) {
                                    TrainingInvite::where('id', $emp['training_invite']['id'])->update(['invite_datetime' => gmdate('Y:m:d H:i:s')]);
                                    $email_vars = [
                                        '{%EMPLOYEE_FIRST_NAME%}' => $emp['first_name'],
                                        '{%LOGIN_TO_ABYDE_EMPLOYEE_PORTAL%}' => Config::get('app.emp_portal_url'),
                                        '{%HCO_FIRST_NAME%}' => $hco->hco->first_name,
                                        '{%HCO_LAST_NAME%}' => $hco->hco->last_name,
                                        '{%HCO_EMAIL%}' => $hco->hco->email,
                                    ];
                                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                    $this->sendEmail($emailTemplate->code, $html, $emp['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                                }
                            }
                        } else {

                            $email_vars = [
                                '{%EMPLOYEE_FIRST_NAME%}' => $training_invite->emp_user_acntuser_student->first_name,
                                '{%LOGIN_TO_ABYDE_EMPLOYEE_PORTAL%}' => Config::get('app.emp_portal_url'),
                                '{%HCO_FIRST_NAME%}' => $hco->hco->first_name,
                                '{%HCO_LAST_NAME%}' => $hco->hco->last_name,
                                '{%HCO_EMAIL%}' => $hco->hco->email,
                            ];
                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                            $this->sendEmail($emailTemplate->code, $html, $training_invite->emp_user_acntuser_student->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                        }
                    }
                    if ($training_invite->training->who_can_train == 'student') {

                        if ($request['is_send_to_all']) {
                            $student_list = Student::select(['id', 'first_name', 'last_name', 'email', 'primary_work_location_id'])
                                ->where('primary_work_location_id', $request['location_id'])
                                ->with([
                                    'TrainingInvite' => function ($qry) use ($training_invite) {
                                        $qry->where('training_id', $training_invite->training_id)
                                            ->where('ref_token', '!=', '')
                                            ->whereNull('completed_datetime')
                                            ->whereNull('completed_attempt_id');
                                    },
                                ])
                                ->orderBy('created_at', 'desc')->get();
                            if (isset($student_list)) {
                                $student_list = $student_list->toArray();
                            }

                            $hco = HipaaComplianceOfficer::where('location_id', $training_invite->emp_user_acntuser_student->primary_work_location_id)->with('hco')->first();
                            $location = Location::findOrFail($training_invite->emp_user_acntuser_student->primary_work_location_id);
                            $emailTemplate_HCE_UE44 = EmailTemplate::where('code', 'HCE-UE44')->first();
                            $emailTemplate_HCE_UE43 = EmailTemplate::where('code', 'HCE-UE43')->first();

                            foreach ($student_list as $std) {
                                if (! is_null($std['training_invite'])) {
                                    TrainingInvite::where('id', $std['training_invite']['id'])->update(['invite_datetime' => gmdate('Y:m:d H:i:s')]);
                                    if ($training_invite->training->training_code == 'HT8') {
                                        // send HCE-UE43
                                        $email_vars = [
                                            '{%FIRST_NAME%}' => $std['first_name'],
                                            '{%COMPLETE_TRAINING%}' => Config::get('app.url') . '/studentportal/training/' . base64_encode($std['id']) . '/' . base64_encode($std['training_invite']['id']),
                                            '{%HIPAA_COMPLIANCE_OFFICER_NAME%}' => $hco->hco->first_name . ' ' . $hco->hco->last_name,
                                            '{%INSTITUTION_NAME%}' => $location->location_nickname,
                                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                        ];
                                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate_HCE_UE43->body);
                                        $html_subject = str_ireplace(['{%INSTITUTION_NAME%}'], [$location->location_nickname], $emailTemplate_HCE_UE43->subject);
                                        $this->sendEmail($emailTemplate_HCE_UE43->code, $html, $std['email'], Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                                    } else {
                                        // send HCE-UE44
                                        $email_vars = [
                                            '{%FIRST_NAME%}' => $std['first_name'],
                                            '{%COMPLETE_TRAINING%}' => Config::get('app.url') . '/studentportal/training/' . base64_encode($std['id']) . '/' . base64_encode($std['training_invite']['id']),
                                            '{%HIPAA_COMPLIANCE_OFFICER_NAME%}' => $hco->hco->first_name . ' ' . $hco->hco->last_name,
                                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                        ];
                                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate_HCE_UE44->body);
                                        $html_subject = str_ireplace(['{%INSTITUTION_NAME%}'], [$location->location_nickname], $emailTemplate_HCE_UE44->subject);
                                        $this->sendEmail($emailTemplate_HCE_UE44->code, $html, $std['email'], Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                                    }
                                }
                            }
                        } else {
                            if ($training_invite->training->training_code == 'HT8') {
                                // send HCE-UE43
                                $hco = HipaaComplianceOfficer::where('location_id', $training_invite->emp_user_acntuser_student->primary_work_location_id)->with('hco')->first();
                                $location = Location::findOrFail($training_invite->emp_user_acntuser_student->primary_work_location_id);
                                $emailTemplate = EmailTemplate::where('code', 'HCE-UE43')->first();
                                $email_vars = [
                                    '{%FIRST_NAME%}' => $training_invite->emp_user_acntuser_student->first_name,
                                    '{%COMPLETE_TRAINING%}' => Config::get('app.url') . '/studentportal/training/' . base64_encode($training_invite->emp_user_acntuser_student->id) . '/' . base64_encode($training_invite->id),
                                    '{%HIPAA_COMPLIANCE_OFFICER_NAME%}' => $hco->hco->first_name . ' ' . $hco->hco->last_name,
                                    '{%INSTITUTION_NAME%}' => $location->location_nickname,
                                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                ];
                                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                $html_subject = str_ireplace(['{%INSTITUTION_NAME%}'], [$location->location_nickname], $emailTemplate->subject);
                                $this->sendEmail($emailTemplate->code, $html, $training_invite->emp_user_acntuser_student->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                            } else {
                                // send HCE-UE44
                                $hco = HipaaComplianceOfficer::where('location_id', $training_invite->emp_user_acntuser_student->primary_work_location_id)->with('hco')->first();
                                $location = Location::findOrFail($training_invite->emp_user_acntuser_student->primary_work_location_id);
                                $emailTemplate = EmailTemplate::where('code', 'HCE-UE44')->first();
                                $email_vars = [
                                    '{%FIRST_NAME%}' => $training_invite->emp_user_acntuser_student->first_name,
                                    '{%COMPLETE_TRAINING%}' => Config::get('app.url') . '/studentportal/training/' . base64_encode($training_invite->emp_user_acntuser_student->id) . '/' . base64_encode($training_invite->id),
                                    '{%HIPAA_COMPLIANCE_OFFICER_NAME%}' => $hco->hco->first_name . ' ' . $hco->hco->last_name,
                                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                ];
                                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                $html_subject = str_ireplace(['{%INSTITUTION_NAME%}'], [$location->location_nickname], $emailTemplate->subject);
                                $this->sendEmail($emailTemplate->code, $html, $training_invite->emp_user_acntuser_student->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                            }
                        }
                    }
                    DB::commit();

                    return $this->success(Config::get('constants.TRAINING.TRAINING_SEND_REMINDER'), 200);
                } else {
                    DB::rollback();

                    return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
                }
            } else {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/sendReminderTraining() => ' . $e->getMessage());
            Log::error('TrainingController/sendReminderTraining()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * add training invite to employee when employee add/edit
     *
     * @return \Illuminate\Http\Response
     */
    public function addTrainingInviteToEmployee($location_id = '', $employee_id = '', $training_arr = [], $is_resend = false, $reason = '', $is_send_to_all = false)
    {
        try {
            if ($location_id == '' || $employee_id == '') {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $is_send_to_emp = 0;
            $training_list = TrainingLocation::select(['id', 'training_id', 'location_id'])
                ->where([
                    'location_id' => $location_id,
                    'is_disable' => 0,
                ]);
            if (! empty($training_arr)) {
                $traning = Training::where('id', $training_arr[0])->first();
                $training_list = $training_list->whereIn('training_id', $training_arr);
            }
            $training_list = $training_list->with(['training' => function ($que) {
                $que->select(['id', 'training_code', 'title', 'who_can_train']);
            }])
                ->whereHas('training', function ($query) {
                    $query->where('who_can_train', 'employee');
                })
                ->get();
            $email_arr = [];
            if (! empty($training_list)) {
                $user_data = $this->getMainAccountDetails();
                $check_user_email_pause = Setting::where('user_id', $user_data['id'])->where('functionality', 'training_email_pause')->count();
                $check_user_notification_pause = Setting::where('user_id', $user_data['id'])->where('functionality', 'training_notification_pause')->count();
                foreach ($training_list as $data) {
                    try {
                        $is_send_to_emp = 0;
                        $emailCode = 'HCE-UE14';
                        if (in_array($data['training']['training_code'], ['HT25', 'HT26', 'HT27'])) {
                            $emailCode = 'HCE-UE52';
                        }
                        if ($data['training']['training_code'] == 'HT2') {
                            $emailCode = 'HCE-UE12';
                        }
                        if ($reason == 'Incident Response') {
                            $emailCode = 'HCE-UE57';
                        } elseif ($reason == 'Refresher') {
                            $emailCode = 'HCE-UE58';
                        }
                        $emailTemplate = EmailTemplate::where('code', $emailCode)->first();
                        if ($is_send_to_all == true) {
                            $emp_list = Employee::select(['id', 'first_name', 'last_name', 'email', 'primary_work_location_id', 'user_id'])
                                ->isActive()
                                ->where('primary_work_location_id', $location_id)
                                ->whereHas('TrainingInvite', function ($qry) use ($data) {
                                    $qry->where('training_id', $data['training_id']);
                                })
                                ->whereDoesntHave('TrainingInvite', function ($qry) use ($data) {
                                    $qry->where('training_id', $data['training_id'])
                                        ->whereNull('completed_datetime')
                                        ->whereNull('completed_attempt_id');
                                })
                                ->with(['employeePrimaryWorkLocation'])
                                ->get();
                        } else {
                            $emp_list = Employee::select(['id', 'first_name', 'last_name', 'email', 'primary_work_location_id', 'user_id'])
                                ->where('id', $employee_id)
                                ->isActive()
                                ->with('TrainingInvite', function ($qry) use ($data) {
                                    $qry->where('training_id', $data['training_id']);
                                })
                                ->with(['employeePrimaryWorkLocation'])
                                ->get();
                        }
                        if (count($emp_list) > 0) {
                            foreach ($emp_list as $emp_data) {
                                if ($is_resend == true || ($is_resend == false && $emp_data->TrainingInvite->isEmpty())) {
                                    $training_invite_data = [
                                        'emp_user_acntuser_student_id' => $emp_data->id,
                                        'emp_user_acntuser_student_type' => \App\Models\Employee::class,
                                        'training_id' => $data['training_id'],
                                        'ref_token' => Str::random(40),
                                        'invite_datetime' => gmdate('Y-m-d H:i:s'),
                                        'reason' => $reason ?? 'Standard Training',
                                    ];
                                    $add_training_invite = TrainingInvite::create($training_invite_data);
                                    $is_send_to_emp = 1;
                                    UnassignedTraining::where(['emp_user_acntuser_student_id' => $emp_data->id, 'emp_user_acntuser_student_type' => \App\Models\Employee::class, 'training_id' => $data['training_id'], 'location_id' => $location_id])->delete();
                                    if (!in_array($emp_data->email, $email_arr)) {
                                        if ($check_user_email_pause == 0) {
                                            $hco = HipaaComplianceOfficer::where('location_id', $emp_data->primary_work_location_id)->with('hco')->first();

                                            $email_vars = [
                                                '{%EMPLOYEE_FIRST_NAME%}' => $emp_data->first_name,
                                                '{%COMPANY_NAME%}' => $emp_data->employeePrimaryWorkLocation->company_name,
                                                '{%LOCATION_NAME%}' => $emp_data->employeePrimaryWorkLocation->location_nickname,
                                                '{%LOGIN_TO_ABYDE_EMPLOYEE_PORTAL%}' => Config::get('app.emp_portal_url'),
                                                '{%HCO_FIRST_NAME%}' => $hco->hco->first_name,
                                                '{%HCO_LAST_NAME%}' => $hco->hco->last_name,
                                                '{%HCO_EMAIL%}' => $hco->hco->email,
                                                '{%FIRST_NAME%}' => $emp_data->first_name,
                                            ];
                                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                            $this->sendEmail($emailTemplate->code, $html, $emp_data->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($user_data['partner_reseller_id'] != null ? $user_data['reseller']['logo'] : null));
                                            $email_arr[] = $emp_data->email;
                                        }
                                        if ($check_user_notification_pause == 0) {
                                            $notification_HCE_AN8 = $this->getNotificationByCode('HCE-AN8');
                                            $notification_HCE_AN8_data = [
                                                'location_id' => $location_id,
                                                'notification_id' => $notification_HCE_AN8['id'],
                                            ];
                                            $this->deleteNotification($notification_HCE_AN8->code, $location_id);
                                            $this->createNotification($notification_HCE_AN8_data);
                                        }
                                    }
                                }
                            }
                            if ($is_send_to_emp == 1) {
                                TrainingLocation::where(['training_id' => $data['training_id'], 'location_id' => $location_id, 'is_archived' => 1])->update(['is_archived' => 0]);
                            }
                        }
                    } catch (\Exception $e) {
                        Log::error('TrainingController/addTrainingInviteToEmployee()[training_list_error] => ' . $e->getMessage());
                        Log::error('TrainingController/addTrainingInviteToEmployee()[training_list_data] => ' . json_encode($data));
                    }
                }
            }
            DB::commit();

            return true;
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/addTrainingInviteToEmployee() => ' . $e->getMessage());
            Log::error('TrainingController/addTrainingInviteToEmployee()[data] => ' . json_encode([$location_id, $employee_id]));

            return false;
        }
    }

    /**
     * add training invite to hco when hco assign/change
     *
     * @return \Illuminate\Http\Response
     */
    public function addTrainingInviteToHCO($location_id = '', $hco_id = '', $training_arr = [], $is_resend = false, $reason = '')
    {
        try {
            if ($location_id == '' || $hco_id == '') {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $training_list = TrainingLocation::select(['id', 'training_id', 'location_id'])
                ->where([
                    'location_id' => $location_id,
                    'is_disable' => 0,
                ]);
            if (! empty($training_arr)) {
                $traning = Training::where('id', $training_arr[0])->first();
                $training_list = $training_list->whereIn('training_id', $training_arr);
            }
            $training_list = $training_list->with(['training' => function ($que) {
                $que->select(['id', 'training_code', 'title', 'who_can_train']);
            }])
                ->whereHas('training', function ($query) {
                    $query->where('who_can_train', 'hco');
                })
                ->get();
            if (! empty($training_list)) {
                $hco_list = HipaaComplianceOfficer::where('location_id', $location_id)->where('hco_id', $hco_id)->with(['hco', 'location'])->first();
                $emp_list = Employee::select(['id', 'first_name', 'last_name', 'email', 'status'])
                    ->with('employeePrimaryWorkLocation')
                    ->where('primary_work_location_id', $location_id)
                    ->isActive()
                    ->get();
                $is_send_to_HCO = 0;
                $user_data = $this->getMainAccountDetails();
                $check_user_email_pause = Setting::where('user_id', $user_data['id'])->where('functionality', 'training_email_pause')->count();
                $check_user_notification_pause = Setting::where('user_id', $user_data['id'])->where('functionality', 'training_notification_pause')->count();
                $training_mail_send = 0;
                foreach ($training_list as $data) {
                    try {
                        if (count($emp_list) > 0) {
                            $check_training_invite = TrainingInvite::where([
                                ['training_id', '=', $data['training_id']],
                                ['emp_user_acntuser_student_id', '=', $hco_list->hco_id],
                                ['emp_user_acntuser_student_type', '=', $hco_list->hco_type],
                            ])->count();
                            if ($check_training_invite == 0 || $is_resend == true) {
                                $training_invite_data = [
                                    'emp_user_acntuser_student_id' => $hco_list->hco_id,
                                    'emp_user_acntuser_student_type' => $hco_list->hco_type,
                                    'training_id' => $data['training_id'],
                                    'ref_token' => Str::random(40),
                                    'invite_datetime' => gmdate('Y-m-d H:i:s'),
                                    'reason' => $reason ?? 'Standard Training',
                                ];
                                $add_training_invite = TrainingInvite::create($training_invite_data);
                                UnassignedTraining::where(['emp_user_acntuser_student_id' => $hco_list->hco_id, 'emp_user_acntuser_student_type' => $hco_list->hco_type, 'training_id' => $data['training_id']])->delete();

                                //fetch locations of given HCO
                                $location_arr = HipaaComplianceOfficer::where('hco_id', $hco_id)->pluck('location_id');

                                //Enable once it is archieved
                                TrainingLocation::whereIn('location_id', $location_arr)->where(['training_id' => $data['training_id'], 'is_archived' => 1])->update(['is_archived' => 0]);
                                if ($is_send_to_HCO == 0 && $training_mail_send == 0) {
                                    if ($check_user_email_pause == 0) {
                                        $emailCode = 'HCE-UE40';
                                        if (in_array($data['training']['training_code'], ['HT22', 'HT23', 'HT24'])) {
                                            $emailCode = 'HCE-UE51';
                                        }
                                        if (in_array($data['training']['training_code'], ['HT1'])) {
                                            $emailCode = 'HCE-UE13';
                                        }

                                        if ($reason == 'Incident Response') {
                                            $emailCode = 'HCE-UE59';
                                        } elseif ($reason == 'Refresher') {
                                            $emailCode = 'HCE-UE60';
                                        }
                                        $emailTemplate = EmailTemplate::where('code', $emailCode)->first();
                                        $email_vars = [
                                            '{%HIPAA_COMPLIANCE_OFFICER_FIRST_NAME%}' => $hco_list->hco->first_name,
                                            '{%HCO_FIRST_NAME%}' => $hco_list->hco->first_name,
                                            '{%LOCATION_NAME%}' => $hco_list->location->location_nickname,
                                            '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                                            '{%LOG_IN_TO_ABYDE%}' => Config::get('app.url'),
                                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                            '{%COMPANY_NAME%}' => $hco_list->location->company_name,
                                        ];
                                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                        $this->sendEmail($emailTemplate->code, $html, $hco_list->hco->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                                        $is_send_to_HCO = 1;
                                    }
                                    if ($check_user_notification_pause == 0) {
                                        $notification_HCE_AN9 = $this->getNotificationByCode('HCE-AN9');
                                        $notification_HCE_AN9_data = [
                                            'location_id' => $location_id,
                                            'notification_id' => $notification_HCE_AN9['id'],
                                        ];
                                        $this->deleteNotification($notification_HCE_AN9->code, $location_id);
                                        $this->createNotification($notification_HCE_AN9_data);
                                        $is_send_to_HCO = 1;
                                    }
                                    $training_mail_send = 1;
                                }
                            }
                        }
                    } catch (\Exception $e) {
                        Log::error('TrainingController/addTrainingInviteToHCO()[training_list_error] => ' . $e->getMessage());
                        Log::error('TrainingController/addTrainingInviteToHCO()[training_list_data] => ' . json_encode($data));
                    }
                }
            }
            DB::commit();

            return true;
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/addTrainingInviteToHCO() => ' . $e->getMessage());
            Log::error('TrainingController/addTrainingInviteToHCO()[data] => ' . json_encode([$location_id, $hco_id]));

            return false;
        }
    }

    /**
     * add training invite to student when student add/edit
     *
     * @return \Illuminate\Http\Response
     */
    public function addTrainingInviteToStudent($location_id, $student_id, $training_arr, $is_resend, $reason, $is_send_to_all)
    {
        try {
            if ($location_id == '' || $student_id == '') {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $training_list = TrainingLocation::select(['id', 'training_id', 'location_id'])
                ->where([
                    'location_id' => $location_id,
                    'is_disable' => 0,
                ]);
            if (! empty($training_arr)) {
                $training_list = $training_list->whereIn('training_id', $training_arr);
            }
            $training_list = $training_list->with(['training' => function ($que) {
                $que->select(['id', 'training_code', 'title', 'who_can_train']);
            }])
                ->whereHas('training', function ($query) {
                    $query->where('who_can_train', 'student');
                })
                ->get();
            if (! empty($training_arr)) {
                $is_send_to_student = 0;
                $user_data = $this->getMainAccountDetails();
                $check_user_email_pause = Setting::where('user_id', $user_data['id'])->where('functionality', 'training_email_pause')->count();
                $training_mail_send = 0;
                foreach ($training_list as $data) {
                    try {

                        $emailCode = 'HCE-UE44';
                        if ($data['training']['training_code'] == 'HT8') {
                            $emailCode = 'HCE-UE43';
                        }
                        if ($reason == 'Incident Response') {
                            $emailCode = 'HCE-UE61';
                        } elseif ($reason == 'Refresher') {
                            $emailCode = 'HCE-UE62';
                        }
                        $emailTemplate = EmailTemplate::where('code', $emailCode)->first();
                        if ($is_send_to_all == true) {
                            $student_list = Student::select(['id', 'first_name', 'last_name', 'email', 'primary_work_location_id', 'user_id'])
                                ->where('primary_work_location_id', $location_id)
                                ->whereHas('TrainingInvite', function ($qry) use ($data) {
                                    $qry->where('training_id', $data['training_id']);
                                })
                                ->whereDoesntHave('TrainingInvite', function ($qry) use ($data) {
                                    $qry->where('training_id', $data['training_id'])
                                        ->whereNull('completed_datetime')
                                        ->whereNull('completed_attempt_id');
                                })
                                ->with(['studentPrimaryWorkLocation'])
                                ->get();
                        } else {
                            $student_list = Student::select(['id', 'first_name', 'last_name', 'email', 'primary_work_location_id', 'user_id'])
                                ->where('id', $student_id)
                                ->with('TrainingInvite', function ($qry) use ($data) {
                                    $qry->where('training_id', $data['training_id']);
                                })
                                ->with(['studentPrimaryWorkLocation'])
                                ->get();
                        }
                        if (count($student_list) > 0) {
                            foreach ($student_list as $student_data) {
                                if ($is_resend == true || ($is_resend == false && $student_data->TrainingInvite->isEmpty())) {
                                    $training_invite_data = [
                                        'emp_user_acntuser_student_id' => $student_data->id,
                                        'emp_user_acntuser_student_type' => \App\Models\Student::class,
                                        'training_id' => $data['training_id'],
                                        'ref_token' => Str::random(40),
                                        'invite_datetime' => gmdate('Y-m-d H:i:s'),
                                        'reason' => $reason ?? 'Standard Training',
                                    ];
                                    $add_training_invite = TrainingInvite::create($training_invite_data);
                                    UnassignedTraining::where(['emp_user_acntuser_student_id' => $student_data->id, 'emp_user_acntuser_student_type' => \App\Models\Student::class, 'training_id' => $data['training_id'], 'location_id' => $location_id])->delete();
                                    //Enable once it is archieved
                                    TrainingLocation::where(['training_id' => $data['training_id'], 'location_id' => $location_id, 'is_archived' => 1])->update(['is_archived' => 0]);
                                    if ($check_user_email_pause == 0 && $training_mail_send == 0) {
                                        $hco = HipaaComplianceOfficer::where('location_id', $student_data->primary_work_location_id)->with('hco')->first();

                                        $email_vars = [
                                            '{%FIRST_NAME%}' => $student_data['first_name'],
                                            '{%COMPLETE_TRAINING%}' => Config::get('app.url') . '/studentportal/training/' . base64_encode($student_data->id) . '/' . base64_encode($add_training_invite->id),
                                            '{%HCO_FIRST_NAME%}' => $hco->hco->first_name,
                                            '{%HCO_LAST_NAME%}' => $hco->hco->last_name,
                                            '{%HIPAA_COMPLIANCE_OFFICER_NAME%}' => $hco->hco->first_name . ' ' . $hco->hco->last_name,
                                            '{%INSTITUTION_NAME%}' => $student_data->studentPrimaryWorkLocation->company_name,
                                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                            '{%LOCATION_NAME%}' => $student_data->studentPrimaryWorkLocation->location_nickname,
                                        ];
                                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                        $html_subject = str_ireplace(['{%INSTITUTION_NAME%}'], [$student_data->studentPrimaryWorkLocation->location_nickname], $emailTemplate->subject);
                                        $this->sendEmail($emailTemplate->code, $html, $student_data->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data['partner_reseller_id'] != null ? $user_data['reseller']['logo'] : null));
                                        $is_send_to_student = 1;
                                    }
                                }
                            }
                            if ($is_send_to_student == 1) {
                                $training_mail_send = 1;
                                TrainingLocation::where(['training_id' => $data['training_id'], 'location_id' => $location_id, 'is_archived' => 1])->update(['is_archived' => 0]);
                            }
                        }
                    } catch (\Exception $e) {
                        Log::error('TrainingController/addTrainingInviteToStudent()[training_list_error] => ' . $e->getMessage());
                        Log::error('TrainingController/addTrainingInviteToStudent()[training_list_data] => ' . json_encode($data));
                    }
                }
            }
            DB::commit();

            return true;
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/addTrainingInviteToStudent() => ' . $e->getMessage());
            Log::error('TrainingController/addTrainingInviteToStudent()[data] => ' . json_encode([$location_id, $student_id]));

            return false;
        }
    }

    /**
     * get Training Certificate
     *
     * @return \Illuminate\Http\Response
     */
    public function getTrainingCertificate(Request $request)
    {
        $validator_rules = [
            'location_id' => 'required',
            'invite_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $location = Location::findOrFail($request['location_id']);
            $training_invite = TrainingInvite::with(['training', 'emp_user_acntuser_student'])->findOrFail($request['invite_id']);
            $complete_date = Carbon::parse($training_invite->completed_datetime)->setTimeZone($request['timezone'])->format('F d,Y');

            $file = public_path('policydocuments/TrainingCertificate.docx');
            $phpword = new \PhpOffice\PhpWord\TemplateProcessor($file);
            $phpword->setValue('EMPLOYEE_NAME', htmlspecialchars($training_invite->emp_user_acntuser_student->first_name) . ' ' . htmlspecialchars($training_invite->emp_user_acntuser_student->last_name));
            $phpword->setValue('TRAINING_MODULE_NAME', htmlspecialchars($training_invite->training->title));
            $phpword->setValue('DATE', $complete_date);
            $phpword->setValue('COMPANY_NAME', htmlspecialchars($location->company_name));
            $generated_training_certificate = storage_path('app/public').'/generatedpolicydocuments/TrainingCertificate_' . $training_invite->id . '.docx';
            $phpword->saveAs($generated_training_certificate);
            $generated_certificate_directory_path = storage_path('app/public').'/generatedpolicydocuments';
            $generated_training_certificate_pdf = asset('storage/generatedpolicydocuments/TrainingCertificate_' . $training_invite->id . '.pdf');
            if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                // change libreoffice path as per installation path from your machine
                exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  ' . $generated_certificate_directory_path . ' ' . $generated_training_certificate);
            } else {
                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir ' . $generated_certificate_directory_path . ' ' . $generated_training_certificate);
            }
            unlink($generated_training_certificate);

            return $this->success(Config::get('constants.SUCCESS'), 200, $generated_training_certificate_pdf);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/getTrainingCertificate() => ' . $e->getMessage());
            Log::error('TrainingController/getTrainingCertificate()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get Training List
     *
     * @return \Illuminate\Http\Response
     */
    public function getTrainingListForDwonloadReport(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'tab_name' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $user_data = $this->getLoginUserData();
            if ($request['tab_name'] == 'employee') {
                $who_can_train_array = ['employee'];
                if ($user_data['user_type'] != 'USER') {
                    $who_can_train_array[] = 'hco';
                }
            }
            if ($request['tab_name'] == 'student') {
                $who_can_train_array = ['student'];
            }
            $trainings = Training::select(['id', 'title', 'who_can_train', 'training_code', 'display_order', 'parent_training_id'])->isActive();

            if ($user_data['user_type'] == 'USER') {
                $trainings = $trainings->whereHas('trainingLocation', function ($query) use ($request) {
                    $query->where('location_id', $request['location_id'])
                        ->where('is_triggered', 1);
                })
                    ->withCount('childTraining')
                    ->with('trainingLocation', function ($query) use ($request) {
                        $query->select('id', 'location_id', 'is_triggered', 'training_id')
                            ->where('location_id', $request['location_id'])
                            ->where('is_triggered', 1);
                    });
            } else {

                $trainings = $trainings->whereHas('trainingLocation', function ($query) use ($request) {
                    $query->where('location_id', $request['location_id'])
                        ->where('is_disable', 0);
                })
                    ->withCount('childTraining')
                    ->with('trainingLocation', function ($query) use ($request) {
                        $query->select('id', 'location_id', 'is_triggered', 'training_id')
                            ->where('location_id', $request['location_id'])
                            ->where('is_disable', 0);
                    });
            }
            $trainings = $trainings
                ->whereIn('who_can_train', $who_can_train_array)->orderBy('display_order', 'DESC')
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $trainings);
        } catch (\Exception $e) {
            Log::error('TrainingController/getTrainingListForDwonloadReport() => ' . $e->getMessage());
            Log::error('TrainingController/getTrainingListForDwonloadReport()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * download HIPAA Training Report
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadHIPAATrainingReport(Request $request)
    {
        $validator_rules = [
            'training_ids' => 'required',
            'location_id' => 'required',
            'tab_name' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $training_ids = explode(',', $request['training_ids']);
            $training_list = TrainingLocation::select(['id', 'training_id', 'location_id'])
                ->where('location_id', $request['location_id'])
                ->where('is_disable', 0)
                ->whereIn('training_id', $training_ids)
                ->with(['training' => function ($que) {
                    $que->select(['id', 'training_code', 'title', 'who_can_train', 'display_order']);
                }])
                // ->orderBy('created_at', 'asc')
                ->get()->sortByDesc(function ($training_location, $key) {
                    return $training_location->training->display_order;
                })->toArray();
            if ($request['tab_name'] == 'employee') {
                $user_data = $this->getLoginUserData();
                $emp_list = Employee::select(['id', 'first_name', 'last_name', 'email', 'primary_work_location_id', DB::raw('IF(primary_work_location_id = "' . $request['location_id'] . '" , "primary" , "secondary") AS emp_type', 'status')])
                    ->where('primary_work_location_id', $request['location_id'])
                    ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($request) {
                        return $query->where('location_id', $request['location_id']);
                    })
                    ->with(['trainingInvites' => function ($query) use ($training_list) {
                        $query->whereIn('training_id', collect($training_list)->pluck('training_id'));
                    }])
                    ->isActive()
                    ->orderBy('created_at', 'desc')
                    ->orderBy('id', 'desc')
                    ->get();
                if ($user_data['user_type'] != 'USER' && count($emp_list) > 0) {
                    $hco_list = HipaaComplianceOfficer::where('location_id', $request['location_id'])->first();
                    if ($hco_list->hco_type == \App\Models\AccountUser::class) {
                        $hco_data = AccountUser::has('trainingInvite')->select(['id', 'first_name', 'last_name', 'email', DB::raw("'hco' AS emp_type"), DB::raw("'account_user' AS morph_type")])
                            ->where('id', $hco_list->hco_id)->first();
                    }
                    if ($hco_list->hco_type == \App\Models\User::class) {
                        $hco_data = User::has('trainingInvite')->select(['id', 'first_name', 'last_name', 'email', DB::raw("'hco' AS emp_type"), DB::raw("'user' AS morph_type")])
                            ->where('id', $hco_list->hco_id)->first();
                    }
                    if ($hco_data != null) {
                        $hco_data = $hco_data->toArray();
                        foreach ($training_list as $key => $value) {
                            $training_invite = TrainingInvite::latest('id')
                                ->where('training_id', $value['training_id'])
                                ->where('emp_user_acntuser_student_id', $hco_data['id'])
                                ->where('emp_user_acntuser_student_type', ($hco_data['morph_type'] == 'user') ? \App\Models\User::class : \App\Models\AccountUser::class)
                                ->first();
                            if ($training_invite && $training_invite['completed_datetime']) {
                                $hco_data['trainings'][$value['training_id']] = $training_invite['completed_datetime'];
                            } elseif (empty($training_invite)) {
                                $hco_data['trainings'][$value['training_id']] = 'disabled';
                            } else {
                                $hco_data['trainings'][$value['training_id']] = '';
                            }
                            if ($value['training']['who_can_train'] == 'employee') {
                                $hco_data['trainings'][$value['training_id']] = 'disabled';
                            }
                        }
                    }
                } else {
                    $hco_data = null;
                }
                $trainingLocations = TrainingLocation::whereIn('training_id', collect($training_list)->pluck('training_id'))
                    ->where('location_id', $request['location_id'])
                    ->get()
                    ->keyBy('training_id');

                $emp_list->each(function ($empObject) use ($training_list, $trainingLocations) {
                    $empObjectTrainings = [];
                    foreach ($training_list as $value) {
                        $training_invite = $empObject->trainingInvites->where('training_id', $value['training_id'])->sortByDesc('id')->first();
                        if ($training_invite && $training_invite->completed_datetime && ($empObject->emp_type == 'primary' || ($empObject->emp_type == 'secondary' && isset($trainingLocations[$value['training_id']])))) {
                            $empObjectTrainings[$value['training_id']] = $training_invite->completed_datetime;
                        } elseif (empty($training_invite)) {
                            $empObjectTrainings[$value['training_id']] = 'disabled';
                        } else {
                            $empObjectTrainings[$value['training_id']] = '';
                        }
                        if ($value['training']['who_can_train'] == 'hco') {
                            $empObjectTrainings[$value['training_id']] = 'disabled';
                        }
                    }
                    $empObject->trainings = $empObjectTrainings;
                });
                $emp_list = $emp_list->sortByDesc(function ($item) {
                    return [
                        $item->emp_type === 'secondary' ? 0 : 1,
                        $item->id,
                    ];
                })->values();
            }
            if ($request['tab_name'] == 'student') {
                $student_list = Student::select(['id', 'first_name', 'last_name', 'email'])
                    ->where('primary_work_location_id', $request['location_id'])
                    ->orderBy('id', 'DESC')->get()->toArray();
                foreach ($student_list as $student_key => $student_object) {
                    foreach ($training_list as $key => $value) {
                        $training_invite = TrainingInvite::latest('id')
                            ->where('training_id', $value['training_id'])
                            ->where('emp_user_acntuser_student_id', $student_object['id'])
                            ->where('emp_user_acntuser_student_type', \App\Models\Student::class)
                            ->first();
                        if ($training_invite && $training_invite['completed_datetime']) {
                            $student_list[$student_key]['trainings'][$value['training_id']] = $training_invite['completed_datetime'];
                        } elseif (empty($training_invite)) {
                            $student_list[$student_key]['trainings'][$value['training_id']] = 'disabled';
                        } else {
                            $student_list[$student_key]['trainings'][$value['training_id']] = '';
                        }
                        if ($value['training']['who_can_train'] == 'hco') {
                            $student_list[$student_key]['trainings'][$value['training_id']] = 'disabled';
                        }
                    }
                }
            }

            $location = Location::find($request['location_id']);
            if (! is_null($location->logo)) {
                $location->logo = $this->getSignedURL('/company_logo/' . $location['user_id'] . '/' . $location['id'] . '/original/' . $location->logo);
            }
            $timezone = $request['timezone'];
            if ($request['tab_name'] == 'employee') {
                $report = new ExportHipaaTrainingReport($emp_list, $hco_data, $training_list, $location, $timezone);
                event(new DownloadLogEvent($location['user_id'], 'HIPAA Employee Training Report.pdf', $request['location_id']));

                return Excel::download($report, 'HIPAA Training Report.xlsx');
            }
            if ($request['tab_name'] == 'student') {
                $report = new ExportStudentHipaaTrainingReport($student_list, $training_list, $location, $timezone);
                event(new DownloadLogEvent($location['user_id'], 'HIPAA Student Training Report.pdf', $request['location_id']));

                return Excel::download($report, 'HIPAA Training Report.xlsx');
            }
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/downloadHIPAATrainingReport() => ' . $e->getMessage());
            Log::error('TrainingController/downloadHIPAATrainingReport()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get last updated training for dashboard
     */
    public function getLastUpdatedTraining($location_id)
    {
        $is_avail = LocationModuleLastUpdate::where(['location_id' => $location_id, 'module_name' => 'training'])->first();

        return ($is_avail) ? $is_avail->updated_at : '';
    }

    /**
     * employee listing for given training
     *
     * @return \Illuminate\Http\Response
     */
    public function employeeStudentListForTraining(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required|numeric',
                'training_id' => 'required|numeric',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $check_is_ra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $request->location_id,
                    'module' => 'risk_analysis',
                    'is_completed' => 1,
                ]
            )->first();
            $emp_count = Employee::where('primary_work_location_id', $request->location_id)->isActive()->count();
            if (! $check_is_ra_completed || $emp_count <= 0) {
                return $this->error('Complete SRA first', 200);
            }

            $trainig_location_data = TrainingLocation::where(['training_id' => $request->training_id, 'location_id' => $request->location_id, 'is_disable' => 0])->first();
            if (!$trainig_location_data) {
                return $this->error('Complete SRA first', 200);
            }
            $training = Training::isActive()
                ->select('id', 'training_code', 'title', 'who_can_train')
                ->find($request['training_id']);

            $emp_student_list = collect();
            if ($training) {
                if ($training['who_can_train'] == 'hco') {
                    $hco_list = HipaaComplianceOfficer::where('location_id', $request['location_id'])->first();

                    if ($hco_list) {
                        $hcoModel = $hco_list->hco_type == \App\Models\AccountUser::class ? AccountUser::class : User::class;
                        $hco_data = $hcoModel::select(['id', 'first_name', 'last_name', 'email', DB::raw("'hco' AS emp_type")])
                            ->where('id', $hco_list->hco_id)
                            ->whereHas('trainingInvite', function ($qry) use ($training) {
                                $qry->where('training_id', $training['id']);
                            })
                            ->with([
                                'trainingInvite' => function ($qry) use ($training) {
                                    $qry->where('training_id', $training['id']);
                                },
                                'trainingInvite.trainingAttempt',
                            ])
                            ->withCount(['trainingInvite' => function ($qry) use ($training) {
                                $qry->where('training_id', $training['id']);
                            }])
                            ->first();

                        if ($trainig_location_data->is_triggered == 0 && !empty($hco_data['trainingInvite']) && $hco_data['trainingInvite']['completed_datetime'] == null) {
                            $hco_data = [];
                        }
                        if ($hco_data) {
                            $hco_data['type'] = $hcoModel;
                            $hco_data['training_attempt_count'] = optional($hco_data['trainingInvite']['trainingAttempt'] ?? null)->count() ?? 0;
                            $hco_data['is_video_quiz_completed'] = $this->_checkVideoQuizTrainingCompleted($hco_data);
                            $last_invite = $hco_data['trainingInvite'];
                            $hco_data['is_resend_enabled'] = $last_invite && $last_invite['completed_datetime'] ? 1 : 0;
                            $emp_student_list->push($hco_data);
                        }
                    }
                }
                if ($training['who_can_train'] == 'employee') {
                    $emp_list = Employee::select(['id', 'first_name', 'last_name', 'email', 'primary_work_location_id', 'status', 'created_at', DB::raw('IF(primary_work_location_id = "' . $request['location_id'] . '", "primary", "secondary") AS emp_type'),])
                        ->where(function ($query) use ($request) {
                            $query->where('primary_work_location_id', $request['location_id'])
                                ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($request) {
                                    $query->where('location_id', $request['location_id']);
                                });
                        })
                        ->whereHas('trainingInvite', function ($qry) use ($training) {
                            $qry->where('training_id', $training['id']);
                        })
                        ->with([
                            'trainingInvite' => function ($qry) use ($training) {
                                $qry->where('training_id', $training['id']);
                            },
                            'trainingInvites' => function ($qry) use ($training) {
                                $qry->where('training_id', $training['id']);
                            },
                            'trainingInvite.trainingAttempt',
                            'employeeSecondaryWorkLocation.location',
                            'employeePrimaryWorkLocation',
                        ])
                        ->isActive()
                        ->get();
                    $emp_student_list = $emp_list->filter(function ($emp_object) use ($training, $trainig_location_data) {
                        if (isset($emp_object['trainingInvite'])) {
                            $is_added_to_location = TrainingLocation::where('location_id', $emp_object['primary_work_location_id'])
                                ->where('training_id', $training['id'])
                                ->exists();

                            if ($trainig_location_data->is_triggered == 0 && !empty($emp_object->trainingInvite) && $emp_object->trainingInvite->completed_datetime == null) {
                                return false;
                            }
                            if ($emp_object['emp_type'] == 'primary' || ($emp_object['emp_type'] == 'secondary' && $is_added_to_location)) {
                                $emp_object['training_attempt_count'] = count($emp_object['trainingInvite']['trainingAttempt'] ?? []);
                                $emp_object['is_video_quiz_completed'] = $this->_checkVideoQuizTrainingCompleted($emp_object);
                                $emp_object['type'] = \App\Models\Employee::class;
                                $last_invite = $emp_object['trainingInvite'];
                                $emp_object['is_resend_enabled'] = $last_invite && $last_invite['completed_datetime'] ? 1 : 0;
                                $emp_object['training_invite_count'] = count($emp_object['trainingInvites']);
                                return true;
                            }
                        }
                        return false;
                    });
                }

                if ($training['who_can_train'] == 'student') {
                    $student_list = Student::select(['id', 'first_name', 'last_name', 'class_id', 'email', 'primary_work_location_id', 'created_at'])
                        ->where('primary_work_location_id', $request['location_id'])
                        ->whereHas('trainingInvite', function ($qry) use ($training) {
                            $qry->where('training_id', $training['id']);
                        })
                        ->with([
                            'trainingInvite' => function ($qry) use ($training) {
                                $qry->where('training_id', $training['id']);
                            },
                            'trainingInvites' => function ($qry) use ($training) {
                                $qry->where('training_id', $training['id']);
                            },
                            'trainingInvite.trainingAttempt',
                            'studentClass',
                        ])
                        ->get();
                    $emp_student_list = $student_list->filter(function ($emp_object) {
                        if (isset($emp_object['trainingInvite'])) {
                            $emp_object['training_attempt_count'] = count($emp_object['trainingInvite']['trainingAttempt'] ?? []);
                            $emp_object['is_video_quiz_completed'] = $this->_checkVideoQuizTrainingCompleted($emp_object);
                            $emp_object['type'] = \App\Models\Student::class;
                            $last_invite = $emp_object['trainingInvite'];
                            $emp_object['is_resend_enabled'] = $last_invite && $last_invite['completed_datetime'] ? 1 : 0;
                            $emp_object['training_invite_count'] = count($emp_object['trainingInvites']);
                            return true;
                        }
                        return false;
                    });
                }
            }

            $originalTotal = $emp_student_list->count();
            if (isset($request->filter_by_class) && $training->who_can_train == 'student') {
                $emp_student_list = $emp_student_list->where('class_id', $request->filter_by_class);
            }
            $sortBy = $request->sort_by ?? 'id';
            if ($sortBy) {
                $sortByDir = ($request->sort_by_dir == 'ASC') ? 'sortBy' : 'sortByDesc';
                $empType = ($sortByDir == 'sortBy') ? 'primary' : 'secondary';
                $emp_student_list = $emp_student_list->{$sortByDir}(function ($item) use ($sortBy, $empType) {
                    return [
                        $item['emp_type'] === $empType ? 0 : 1,
                        strtolower(data_get($item, $sortBy)),
                        $item['id'],
                    ];
                })->values();
            }
            return $this->success(Config::get('constants.TRAINING.TRAINING_LIST'), 200, ['emp_student_list' => $emp_student_list, 'original_total' => $originalTotal]);
        } catch (\Exception $e) {
            Log::error('TrainingController/employeeStudentListForTraining() => ' . $e->getMessage());
            Log::error('TrainingController/employeeStudentListForTraining()[data] => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * employee listing for given training
     *
     * @return \Illuminate\Http\Response
     */
    public function unassignedEmployeeStudentListForTraining(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required|numeric',
                'training_id' => 'required|numeric',
                'sort_by' => 'sometimes|nullable',
                'sort_by_dir' => 'sometimes|nullable|in:ASC,DESC',
                'search_query' => 'sometimes',
                'filter_by_class' => 'sometimes',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $check_is_ra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $request->location_id,
                    'module' => 'risk_analysis',
                    'is_completed' => 1,
                ]
            )->first();
            $employees = Employee::where('primary_work_location_id', $request->location_id)->isActive()->get();
            if (! $check_is_ra_completed || count($employees) <= 0) {
                return $this->error('Complete SRA first', 200);
            }
            if (! TrainingLocation::where(['training_id' => $request->training_id, 'location_id' => $request->location_id, 'is_triggered' => 1, 'is_disable' => 0])->first()) {
                return $this->error('Complete SRA first', 200);
            }
            $training = Training::select(['id', 'training_code', 'title', 'who_can_train', 'training_type'])
                ->where([
                    ['id', '=', $request['training_id']],
                ])->isActive()->first();
            $unassigned_list = [];
            if ($training) {
                if ($training->who_can_train == 'hco') {
                    $hco = HipaaComplianceOfficer::where('location_id', $request['location_id'])->first();
                    $condition = [
                        'training_id' => $request['training_id'],
                        'emp_user_acntuser_student_type' => $hco->hco_type,
                        'emp_user_acntuser_student_id' => $hco->hco_id,
                    ];
                } else {
                    $condition = [
                        'training_id' => $request['training_id'],
                        'location_id' => $request['location_id'],
                        'emp_user_acntuser_student_type' => ($training->who_can_train == 'employee') ? Employee::class : Student::class,
                    ];
                }
                $unassigned_list = UnassignedTraining::with('emp_user_acntuser_student')
                    ->where($condition);
                if ($training->who_can_train == 'employee') {
                    $unassigned_list = $unassigned_list->whereIn('emp_user_acntuser_student_id', $employees->pluck('id')->toArray());
                }

                $unassigned_list = $unassigned_list->get();
                $unassigned_list->each(function ($item) {
                    if ($item->emp_user_acntuser_student_type === Employee::class) {
                        $employee = $item->emp_user_acntuser_student;
                        $employee->load(['employeeSecondaryWorkLocation.location', 'employeePrimaryWorkLocation']);
                        $item->emp_type = 'primary';
                    } elseif ($item->emp_user_acntuser_student_type === Student::class) {
                        $student = $item->emp_user_acntuser_student;
                        $student->load('studentClass');
                        $item->student_class = $student->studentClass;
                    } else {
                        $item->emp_type = 'hco';
                    }
                });
            }
            if ($training->who_can_train == 'employee') {
                $emp_list = Employee::whereHas('employeeSecondaryWorkLocation', function ($query) use ($request) {
                    return $query->where('location_id', $request['location_id']);
                })
                    ->with(['employeePrimaryWorkLocation'])
                    ->isActive()
                    ->pluck('id');
                if (isset($emp_list)) {
                    $emp_list = $emp_list->toArray();
                }
                $secondary_unassigned_list = UnassignedTraining::with('emp_user_acntuser_student')
                    ->where('emp_user_acntuser_student_type', Employee::class)
                    ->where('training_id', $request['training_id'])
                    ->whereIn('emp_user_acntuser_student_id', $emp_list)
                    ->with('emp_user_acntuser_student.employeePrimaryWorkLocation')
                    ->get();

                if ($secondary_unassigned_list) {
                    $secondary_unassigned_list->each(function ($item) {
                        $item->emp_type = 'secondary';
                    });
                    $unassigned_list = $unassigned_list->merge($secondary_unassigned_list);
                }
            }
            $originalTotal = $unassigned_list->count();
            if (isset($request->filter_by_class) && $training->who_can_train == 'student') {
                $unassigned_list = $unassigned_list->where('student_class.id', $request->filter_by_class);
            }

            $sortBy = $request->sort_by ?? 'id';
            if ($sortBy) {
                $sortByDir = ($request->sort_by_dir == 'ASC') ? 'sortBy' : 'sortByDesc';
                $empType = ($sortByDir == 'sortBy') ? 'primary' : 'secondary';
                $unassigned_list = $unassigned_list->{$sortByDir}(function ($item) use ($sortBy, $empType) {
                    return [
                        $item['emp_type'] === $empType ? 0 : 1,
                        strtolower(data_get($item, $sortBy)),
                        $item['id'],
                    ];
                })->values();
            }
            return $this->success(Config::get('constants.TRAINING.TRAINING_LIST'), 200, ['unassigned_list' => $unassigned_list, 'original_total' => $originalTotal]);
        } catch (\Exception $e) {
            Log::error('TrainingController/unassignedEmployeeStudentListForTraining() => ' . $e->getMessage());
            Log::error('TrainingController/unassignedEmployeeStudentListForTraining()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * employee listing for given training
     *
     * @return \Illuminate\Http\Response
     */
    public function hideEmployeeStudentListForTraining(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required|numeric',
                'training_arr' => 'required',
                'emp_user_acntuser_student_id' => 'required',
                'emp_user_acntuser_student_type' => 'required',
                'hide_all' => 'sometimes',
                'is_hidden' => 'required|boolean',
                'user_type' => 'required|string',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $training_arr = $request['training_arr'];
            $userType = $request->user_type === 'hco' ? 'HCO' : ucwords($request->user_type);

            $query = UnassignedTraining::whereIn('training_id', $training_arr);
            if ($userType !== 'HCO') {
                $query->where('location_id', $request['location_id']);
            }

            if (isset($request['hide_all']) && $request['hide_all']) {
                $query->update(['is_hidden' => $request['is_hidden']]);
            } else {
                $query->where('emp_user_acntuser_student_id', $request['emp_user_acntuser_student_id'])
                    ->where('emp_user_acntuser_student_type', $request['emp_user_acntuser_student_type'])
                    ->update(['is_hidden' => $request['is_hidden']]);
            }

            $type = ($request['is_hidden'] == 1) ? 'hidden' : 'unhidden';

            return $this->success("$userType $type successfully", 200);
        } catch (\Exception $e) {
            Log::error('TrainingController/hideEmployeeStudentListForTraining() => ' . $e->getMessage());
            Log::error('TrainingController/hideEmployeeStudentListForTraining()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Employee Failed Attempt Questions List
     *
     * @return \Illuminate\Http\Response
     */
    public function employeeFailedAttemptQuestionList(Request $request)
    {
        try {
            $validator_rules = [
                'invite_id' => 'required|numeric',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $failed_attempt_data = TrainingAttempt::select(['id', 'created_at'])->where('invite_id', $request->invite_id)->with([
                'trainingQuizAttempt' => function ($qry) {
                    $qry->select(['id', 'training_attempt_id', 'question_id'])->where('is_given_correct', 'no')->with(['training_questions:id,question']);
                },
            ])->get();

            return $this->success(Config::get('constants.TRAINING.TRAINING_LIST'), 200, $failed_attempt_data);
        } catch (\Exception $e) {
            Log::error('TrainingController/employeeFailedAttemptQuestionList() => ' . $e->getMessage());
            Log::error('TrainingController/employeeFailedAttemptQuestionList()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function addTrainingLocations($location_id)
    {
        try {
            $location = Location::where('id', $location_id)
                ->with('user.reseller')
                ->with('hipaaComplianceOfficer')
                ->whereHas('hipaaComplianceOfficer')
                ->withCount('employeePrimaryWorkLocation')
                ->whereHas('sraModuleCompleted')
                ->first();
            if (! $location || $location->employee_primary_work_location_count <= 0) {
                return;
            }

            DB::beginTransaction();
            $check_user_pause = Setting::where('user_id', $location['user_id'])->where('functionality', 'training_pause')->count();
            if ($check_user_pause == 0) {
                $training_list = Training::select(['id', 'training_code', 'who_can_train', 'trigger_month', 'parent_training_id', 'notification_code'])
                    ->whereIn('who_can_train', ['hco', 'employee'])
                    ->whereDoesntHave('trainingLocation', function ($query) use ($location) {
                        $query->where('location_id', $location->id);
                    })
                    ->isActive()
                    ->get();
                if ($training_list->isEmpty()) {
                    return;
                }
                $today = Carbon::today()->endOfDay();
                $renewalDate = Carbon::parse($location->user->contract_renewal_date)->endOfDay();

                foreach ($training_list as $training) {
                    try {
                        $check_training_is_already_open_for_location = TrainingLocation::where('location_id', '=', $location->id)->where('training_id', '=', $training->id)->count();
                        if ($check_training_is_already_open_for_location == 0) {
                            if (
                                in_array($training->training_code, ['HT1', 'HT2']) ||
                                $training->trigger_month !== null
                            ) {

                                $schedule_date = $training->trigger_month
                                    ? Carbon::parse($location->training_anchor_date)->addMonth($training->trigger_month)->endOfDay()
                                    : Carbon::now()->endOfDay();
                                if ($schedule_date->lte($renewalDate)) {
                                    $temp_data = [
                                        'location_id' => $location->id,
                                        'training_id' => $training->id,
                                        'trigger_type' => 'auto',
                                        'schedule_date' => $schedule_date->format('Y-m-d'),
                                    ];
                                    if (in_array($training->training_code, ['HT1', 'HT2']) || $schedule_date->lte($today)) {
                                        $temp_data['is_triggered'] = 1;
                                        $temp_data['old_schedule_date'] = $schedule_date->format('Y-m-d');
                                        $temp_data['schedule_date'] = date('Y-m-d');
                                    }
                                    TrainingLocation::create($temp_data);
                                    if (isset($temp_data['is_triggered']) && $temp_data['is_triggered'] == 1) {
                                        $this->sendInitialInvites($training, $location->id);
                                    }
                                }
                            }
                        }
                    } catch (\Exception $e) {
                        Log::error('TrainingController/addTrainingLocations()[training_list_error] => ' . $e->getMessage());
                        Log::error('TrainingController/addTrainingLocations()[training_list_data] => ' . json_encode($training));
                    }
                }
            }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/addTrainingLocations() => ' . $e->getMessage());
            Log::error('TrainingController/addTrainingLocations Line # => ' . $e->getLine());
            Log::error('TrainingController/addTrainingLocations Location id => ' . $location_id);
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function setTrainingSchedule(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required|numeric',
                'training_id' => 'required|numeric',
                'schedule_date' => 'required|date|after:today',
                'training_parent_id' => 'required|numeric',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $user_data = $this->getLoginUserData();
            $trainingLocation = TrainingLocation::where([
                'training_id' => $request->training_id,
                'location_id' => $request->location_id,
            ])->first();

            if (! $trainingLocation || $trainingLocation->is_archived || $trainingLocation->is_triggered) {
                return $this->error('Training cannot be scheduled.', 200);
            }
            $main_user_data = $this->getMainAccountDetails();
            $renewalDate = Carbon::parse($main_user_data->contract_renewal_date)->endOfDay();
            $scheduleDate = Carbon::parse($request->schedule_date)->endOfDay();

            if ($scheduleDate->gt($renewalDate)) {
                return $this->error('The date you have selected is past your renewal date – ' . $renewalDate->format('m-d-Y') . '.', 200);
            }

            $schedule_by = in_array($user_data['user_type'], ['HCO', 'USER']) ? AccountUser::class : User::class;
            $trainingLocations = collect([$trainingLocation]);

            $parent_training_location = TrainingLocation::where([
                'training_id' => $request->training_parent_id,
                'location_id' => $request->location_id,
            ])
                ->with('training.childTraining.trainingLocation', function ($query) use ($request) {
                    $query->where('location_id', $request['location_id'])->where('is_archived', 0)->where('is_triggered', 0);
                })
                ->first()->toArray();

            $cntr = 0;
            $trainig_array[$cntr] = $parent_training_location['training'];
            unset($trainig_array[$cntr]['child_training']);
            $trainig_array[$cntr]['training_location'][0] = $parent_training_location;
            unset($trainig_array[$cntr]['training_location'][0]['training']);

            for ($i = 0; $i < count($parent_training_location['training']['child_training']); $i++) {
                $cntr++;
                $trainig_array[$cntr] = $parent_training_location['training']['child_training'][$i];
            }

            for ($i = 0; $i < count($trainig_array); $i++) {
                if ($trainig_array[$i]['training_location'][0]['is_archived'] == 0 && $trainig_array[$i]['training_location'][0]['is_triggered'] == 0) {
                    TrainingLocationArchived::create([
                        'training_id' => $trainig_array[$i]['training_location'][0]['training_id'],
                        'location_id' => $trainig_array[$i]['training_location'][0]['location_id'],
                        'schedule_date' => $trainig_array[$i]['training_location'][0]['schedule_date'],
                        'schedule_by_id' => $trainig_array[$i]['training_location'][0]['schedule_by_id'],
                        'schedule_by_type' => $trainig_array[$i]['training_location'][0]['schedule_by_type'],
                    ]);
                    TrainingLocation::where('id', $trainig_array[$i]['training_location'][0]['id'])
                        ->update(['schedule_date' => $request->schedule_date, 'schedule_by_id' => $user_data['id'], 'schedule_by_type' => $schedule_by]);
                }
            }

            return $this->success(Config::get('constants.TRAINING.TRAINING_SCHEDULED'), 200);
        } catch (\Exception $e) {
            Log::error('TrainingController/setTrainingSchedule() => ' . $e->getMessage());
            Log::error('TrainingController/setTrainingSchedule()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function sendInvitationForTraining(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required|numeric',
                'emp_stud_user_id' => 'required',
                'type' => 'required',
                'reason' => 'sometimes',
                'is_send_to_all' => 'sometimes',
                'training_arr' => 'required',
                'call_type' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            if ($request->call_type == 'unassignToAssign') {
                $condition = [
                    'emp_user_acntuser_student_id' => $request->emp_stud_user_id,
                    'emp_user_acntuser_student_type' => $request->type,
                    'is_hidden' => 1,
                ];
                if (in_array($request->type, [Employee::class, Student::class])) {
                    $condition['location_id'] = $request->location_id;
                }
                $unassigned_count = UnassignedTraining::where($condition)->whereIn('training_id', $request->training_arr)->count();

                if ($unassigned_count > 0) {
                    return $this->error('Invitation cannot be sent as it is hidden.', 200);
                }
            }
            DB::beginTransaction();
            $reason = $request->reason ?? 'Standard Training';
            if ($request->type === Employee::class) {
                $this->addTrainingInviteToEmployee($request->location_id, $request->emp_stud_user_id, $request->training_arr, true, $reason, $request['is_send_to_all']);
            } elseif ($request->type === Student::class) {
                $this->addTrainingInviteToStudent($request->location_id, $request->emp_stud_user_id, $request->training_arr, true, $reason, $request['is_send_to_all']);
            } else {
                $this->addTrainingInviteToHCO($request->location_id, $request->emp_stud_user_id, $request->training_arr, true, $reason);
            }

            DB::commit();
            $message = ($reason == 'Standard Training') ? 'constants.TRAINING.TRAINING_INVITATION_SENT' : 'constants.TRAINING.TRAINING_INVITATION_RESENT';

            return $this->success(Config::get($message), 200);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/sendInvitationForTraining() => ' . $e->getMessage());
            Log::error('TrainingController/sendInvitationForTraining()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * employee listing for given training
     *
     * @return \Illuminate\Http\Response
     */
    public function employeeStudentInviteListForTraining(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required|numeric',
                'training_id' => 'required|numeric',
                'emp_stud_user_id' => 'required',
                'type' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $allInvites = TrainingInvite::with('trainingAttempt')
                ->withCount('trainingAttempt')
                ->where([
                    'training_id' => $request->training_id,
                    'emp_user_acntuser_student_id' => $request->emp_stud_user_id,
                    'emp_user_acntuser_student_type' => $request->type,
                ])
                ->orderBy('id', 'DESC')
                ->get();
            $allInvites->shift();
            $allInvites->each(function ($invite) {
                $invite->is_video_quiz_completed = ($invite['ref_token'] == null && $invite['completed_attempt_id'] && $invite['completed_datetime']);
                if ($invite->emp_user_acntuser_student_type === Student::class) {
                    $student = $invite->emp_user_acntuser_student;
                    $student->load('studentClass');
                    $invite->student_class = $student->studentClass;
                }
            });

            return $this->success(Config::get('constants.TRAINING.TRAINING_LIST'), 200, $allInvites);
        } catch (\Exception $e) {
            Log::error('TrainingController/employeeStudentListForTraining() => ' . $e->getMessage());
            Log::error('TrainingController/employeeStudentListForTraining()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function moveTrainingToArchive($location_id, $training_id = null)
    {
        try {
            $trainings = Training::whereHas('trainingLocation', function ($query) use ($location_id) {
                $query->where('location_id', $location_id)
                    ->where('is_triggered', 1);
            });
            if (! empty($training_id)) {
                $trainings = $trainings->where('id', $training_id);
            }
            $trainings = $trainings->get();
            $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();

            if ($trainings) {
                foreach ($trainings as $training) {
                    DB::transaction(function () use ($training, $location_id, $hco) {
                        $assigned = 0;
                        $completed = 0;
                        $location_ids = [];
                        if ($training->who_can_train === 'hco') {
                            $invite = TrainingInvite::where([
                                'training_id' => $training->id,
                                'emp_user_acntuser_student_id' => $hco->hco_id,
                                'emp_user_acntuser_student_type' => $hco->hco_type,
                            ])->latest()->first();

                            $location_ids = HipaaComplianceOfficer::where([
                                'hco_id' => $hco->hco_id,
                                'hco_type' => $hco->hco_type
                            ])->pluck('location_id');

                            $assigned = $invite ? 1 : 0;
                            $completed = (isset($invite) && $invite->ref_token == null && $invite->completed_attempt_id && $invite->completed_datetime) ? 1 : 0;
                        } else {
                            $model_type = ($training->who_can_train == 'employee') 
                                ? \App\Models\Employee::class 
                                : \App\Models\Student::class;

                            $invite_ids_query = ($training->who_can_train == 'employee')
                                ? Employee::where('primary_work_location_id', $location_id)->isActive()->pluck('id')
                                : Student::where('primary_work_location_id', $location_id)->pluck('id');

                            $invites = TrainingInvite::where([
                                'training_id' => $training->id,
                                'emp_user_acntuser_student_type' => $model_type,
                            ])
                            ->whereIn('emp_user_acntuser_student_id', $invite_ids_query)
                            ->orderBy('created_at', 'desc')
                            ->get()
                            ->unique('emp_user_acntuser_student_id');

                            $assigned = $invites->count();
                            $completed = $invites->whereNotNull('completed_datetime')
                                                ->whereNotNull('completed_attempt_id')
                                                ->count();
                        }

                        $isArchived = ($completed > 0 && $completed == $assigned) ? 1 : 0;

                        if (count($location_ids) > 0) {
                            TrainingLocation::where('training_id', $training->id)
                                ->whereIn('location_id', $location_ids)
                                ->where('is_triggered', 1)
                                ->update(['is_archived' => $isArchived]);
                        } else {
                            TrainingLocation::where([
                                'training_id' => $training->id,
                                'location_id' => $location_id
                            ])
                            ->where('is_triggered', 1)
                            ->update(['is_archived' => $isArchived]);
                        }
                    }, 3);
                }
            }

        } catch (\Exception $e) {
            Log::error('TrainingController/moveTrainingToArchive() => ' . $e->getMessage());
            Log::error('TrainingController/moveTrainingToArchive()[data] => ' . json_encode([$location_id, $training_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function addToUnassignedTraining($location_id, $userId, $type)
    {

        try {
            DB::beginTransaction();
            $user_data = $this->getMainAccountDetails();
            $who_can_train = 'hco';
            if ($type == Employee::class) {
                $who_can_train = 'employee';
            }
            if ($type == Student::class) {
                $who_can_train = 'student';
            }
            $training_list = TrainingLocation::with('training')
                ->whereHas('training', function ($query) use ($who_can_train) {
                    $query->where('who_can_train', $who_can_train);
                })
                ->where('location_id', $location_id)
                ->where('is_triggered', 1)
                ->get();
            if ($training_list) {
                foreach ($training_list as $training_loc) {
                    try {
                        $invite = TrainingInvite::where([
                            ['training_id', '=', $training_loc->training_id],
                            ['emp_user_acntuser_student_id', '=', $userId],
                            ['emp_user_acntuser_student_type', '=', $type],
                        ])
                            ->latest()
                            ->first();

                        if (empty($invite)) {
                            if (in_array($training_loc->training->training_code, ['HT1', 'HT2'])) {
                                $this->sendInitialInvites($training_loc->training, $location_id, $userId, $type);
                            } else {
                                UnassignedTraining::updateOrCreate(
                                    [
                                        'training_id' => $training_loc->training_id,
                                        'emp_user_acntuser_student_id' => $userId,
                                        'emp_user_acntuser_student_type' => $type,
                                        'user_id' => $user_data['id'],
                                    ],
                                    [
                                        'training_id' => $training_loc->training_id,
                                        'emp_user_acntuser_student_id' => $userId,
                                        'emp_user_acntuser_student_type' => $type,
                                        'location_id' => $location_id,
                                        'user_id' => $user_data['id'],
                                    ]
                                );
                            }
                            if ($training_loc->is_archived == 1 && $who_can_train == 'hco') {
                                $training_loc->update(['is_archived' => 0]);
                            }
                        } elseif ($training_loc->is_archived == 1 && $invite->completed_datetime == null && $invite->completed_attempt_id == null) {
                            $training_loc->update(['is_archived' => 0]);
                        } elseif ($training_loc->is_archived == 0 && $invite->completed_datetime != null && $invite->completed_attempt_id != null) {
                            $this->moveTrainingToArchive($training_loc->location_id, $training_loc->training_id);
                        }
                    } catch (\Exception $e) {
                        Log::error('TrainingController/addToUnassignedTraining()[training_list_error] => ' . $e->getMessage());
                        Log::error('TrainingController/addToUnassignedTraining()[training_list_data] => ' . json_encode($training_loc));
                    }
                }
            }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/addToUnassignedTraining() => ' . $e->getMessage());
            Log::error('TrainingController/addToUnassignedTraining()[data] => ' . json_encode([$location_id, $userId, $type]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function sendInitialInvites($training, $location_id, $emp_id = null, $type = '', $call_from_script = false)
    {
        $location = Location::where('id', $location_id)
            ->with('user.reseller')
            ->with('hipaaComplianceOfficer')
            ->whereHas('hipaaComplianceOfficer')
            ->withCount('employeePrimaryWorkLocation')
            ->whereHas('sraModuleCompleted')
            ->first();
        if (! $location || $location->employee_primary_work_location_count <= 0) {
            return;
        }
        $check_user_email_pause = Setting::where('user_id', $location->user_id)->where('functionality', 'training_email_pause')->count();
        $check_user_notification_pause = Setting::where('user_id', $location->user_id)->where('functionality', 'training_notification_pause')->count();
        $hco = HipaaComplianceOfficer::where('location_id', $location_id)->with('hco')->first();

        if ($training->who_can_train == 'employee') {
            $emp_list = Employee::select(['id', 'first_name', 'last_name', 'email', 'primary_work_location_id'])
                ->where('primary_work_location_id', $location_id)
                ->with('employeePrimaryWorkLocation');
            if (isset($emp_id) && $type == \App\Models\Employee::class) {
                $emp_list = $emp_list->where('id', $emp_id);
            }
            $emp_list = $emp_list->isActive()
                ->get();
            foreach ($emp_list as $emp_data) {
                $check_invite = TrainingInvite::where('emp_user_acntuser_student_id', $emp_data['id'])->where('training_id', $training->id)->where('emp_user_acntuser_student_type', \App\Models\Employee::class)->first();
                if ($check_invite === null || ! $check_invite) {
                    $training_invite_data = [
                        'emp_user_acntuser_student_id' => $emp_data['id'],
                        'emp_user_acntuser_student_type' => \App\Models\Employee::class,
                        'training_id' => $training->id,
                        'ref_token' => Str::random(40),
                        'invite_datetime' => gmdate('Y-m-d H:i:s'),
                    ];
                    $add_training_invite = TrainingInvite::create($training_invite_data);
                    //Enable once it is archieved
                    TrainingLocation::where(['training_id' => $training->id, 'location_id' => $location_id, 'is_archived' => 1])->update(['is_archived' => 0]);
                    if ($training->parent_training_id == '') {
                        if ($check_user_email_pause == 0) {
                            // send HCE-UE14
                            $emailCode = ($training->training_code == 'HT25') ? 'HCE-UE52' : 'HCE-UE14';
                            if ($training->training_code == 'HT2') {
                                $emailCode = 'HCE-UE12';
                            }
                            $emailTemplate = EmailTemplate::where('code', $emailCode)->first();
                            $email_vars = [
                                '{%EMPLOYEE_FIRST_NAME%}' => $emp_data['first_name'],
                                '{%FIRST_NAME%}' => $emp_data['first_name'],
                                '{%LOGIN_TO_ABYDE_EMPLOYEE_PORTAL%}' => Config::get('app.emp_portal_url'),
                                '{%HCO_FIRST_NAME%}' => $hco->hco->first_name,
                                '{%HCO_LAST_NAME%}' => $hco->hco->last_name,
                                '{%HCO_EMAIL%}' => $hco->hco->email,
                                '{%COMPANY_NAME%}' => $emp_data->employeePrimaryWorkLocation->company_name,
                                '{%LOCATION_NAME%}' => $emp_data->employeePrimaryWorkLocation->location_nickname,

                            ];
                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                            if ($location['user']['account_status'] == 'Unfrozen' && $location['user']['is_active'] == '1' && $location['user']['is_account_verified'] == '1') {
                                $this->sendEmail($emailTemplate->code, $html, $emp_data['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($location['user']['partner_reseller_id'] != null ? $location['user']['reseller']['logo'] : null));
                            }
                        }
                        $notification = $this->getNotificationByCode($training->notification_code ?? '');
                        if ($notification && $this->checkNotificationAlreadyAdded($notification->code, $location->id) == 0) {
                            if ($check_user_notification_pause == 0) {
                                $notification_data = [
                                    'location_id' => $location->id,
                                    'notification_id' => $notification['id'],
                                ];
                                $this->createNotification($notification_data);
                            }
                            if ($check_user_email_pause == 0) {
                                // send HCE-UE34
                                $emailTemplate = EmailTemplate::where('code', 'HCE-UE34')->first();
                                $email_vars = [
                                    '{%FIRST_NAME%}' => $hco->hco->first_name,
                                    '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                ];
                                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                if ($location['user']['account_status'] == 'Unfrozen' && $location['user']['is_active'] == '1' && $location['user']['is_account_verified'] == '1') {
                                    $this->sendEmail($emailTemplate->code, $html, $hco->hco->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($location['user']['partner_reseller_id'] != null ? $location['user']['reseller']['logo'] : null));
                                }
                            }
                        }
                    }
                }
            }
        }
        if ($training->who_can_train == 'hco') {
            $hco_list = HipaaComplianceOfficer::where('location_id', $location->id)->with(['hco', 'location'])->first();
            if ($hco_list != null) {
                $check_invite = TrainingInvite::where('emp_user_acntuser_student_id', $hco_list['hco_id'])->where('training_id', $training->id)->where('emp_user_acntuser_student_type', $hco_list['hco_type'])->first();
                if ($check_invite === null || ! $check_invite) {
                    $training_invite_data = [
                        'emp_user_acntuser_student_id' => $hco_list['hco_id'],
                        'emp_user_acntuser_student_type' => $hco_list['hco_type'],
                        'training_id' => $training->id,
                        'ref_token' => Str::random(40),
                        'invite_datetime' => gmdate('Y-m-d H:i:s'),
                    ];
                    $add_training_invite = TrainingInvite::create($training_invite_data);
                    //Enable once it is archieved
                    TrainingLocation::where(['training_id' => $training->id, 'location_id' => $location->id, 'is_archived' => 1])->update(['is_archived' => 0]);
                    if ($training->parent_training_id == '') {
                        $check_user_notification_pause = Setting::where('user_id', $location['user']['id'])->where('functionality', 'training_notification_pause')->count();
                        if ($check_user_notification_pause == 0) {
                            $notification = $this->getNotificationByCode($training->notification_code ?? '');
                            if ($this->checkNotificationAlreadyAdded($notification->code, $location->id) == 0) {
                                $notification_data = [
                                    'location_id' => $location->id,
                                    'notification_id' => $notification['id'],
                                ];
                                $this->createNotification($notification_data);
                            }
                        }
                        $check_user_email_pause = Setting::where('user_id', $location['user']['id'])->where('functionality', 'training_email_pause')->count();
                        if ($check_user_email_pause == 0) {
                            if ($call_from_script == true) {
                                // send HCE-UE63
                                $emailTemplate = EmailTemplate::where('code', 'HCE-UE63')->first();
                                $email_vars = [
                                    '{%HCO_FIRST_NAME%}' => $hco_list['hco']['first_name'],
                                    '{%ABYDE%}' => Config::get('app.url'),

                                ];
                                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                if ($location['user']['account_status'] == 'Unfrozen' && $location['user']['is_active'] == '1' && $location['user']['is_account_verified'] == '1') {
                                    $this->sendEmail($emailTemplate->code, $html, $hco_list['hco']['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($location['user']['partner_reseller_id'] != null ? $location['user']['reseller']['logo'] : null));
                                }
                            } else {
                                // send HCE-UE40
                                $emailCode = ($training->training_code == 'HT22') ? 'HCE-UE51' : 'HCE-UE40';
                                if ($training->training_code == 'HT1') {
                                    $emailCode = 'HCE-UE13';
                                }
                                $emailTemplate = EmailTemplate::where('code', $emailCode)->first();
                                $email_vars = [
                                    '{%HCO_FIRST_NAME%}' => $hco_list['hco']['first_name'],
                                    '{%LOG_IN_TO_ABYDE%}' => Config::get('app.url'),
                                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                    '{%HIPAA_COMPLIANCE_OFFICER_FIRST_NAME%}' => $hco_list->hco->first_name,
                                    '{%LOCATION_NAME%}' => $hco_list->location->location_nickname,
                                    '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),

                                ];
                                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                if ($location['user']['account_status'] == 'Unfrozen' && $location['user']['is_active'] == '1' && $location['user']['is_account_verified'] == '1') {
                                    $this->sendEmail($emailTemplate->code, $html, $hco_list['hco']['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($location['user']['partner_reseller_id'] != null ? $location['user']['reseller']['logo'] : null));
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * training listing for recommend
     *
     * @return \Illuminate\Http\Response
     */
    public function getTrainingCount($locationId)
    {
        try {

            $user_data = $this->getLoginUserData();
            $hco = HipaaComplianceOfficer::where('location_id', $locationId)->first();
            if (! empty($hco)) {
                $emp_invite_ids_query = Employee::where('primary_work_location_id', $locationId)->isActive()->pluck('id');
                $stud_invite_ids_query = Student::where('primary_work_location_id', $locationId)->pluck('id');
                $training_ids = TrainingLocation::where('location_id', $locationId)->whereHas('training', function ($query) {
                    $query->isActive();
                })
                    ->where('is_disable', 0)
                    ->pluck('training_id');

                $hcoPending = 0;
                $hcoUnassigned = 0;
                if ($user_data['user_type'] !== 'USER') {
                    $hcoPending = TrainingInvite::where([
                        'emp_user_acntuser_student_id' => $hco->hco_id,
                        'emp_user_acntuser_student_type' => $hco->hco_type,
                    ])
                        ->whereIn('training_id', $training_ids)
                        ->whereNull('completed_datetime')
                        ->whereNull('completed_attempt_id')
                        ->count();

                    $hcoUnassigned = UnassignedTraining::where([
                        'emp_user_acntuser_student_id' => $hco->hco_id,
                        'emp_user_acntuser_student_type' => $hco->hco_type,
                        'is_hidden' => 0,
                    ])
                        ->whereIn('training_id', $training_ids)
                        ->count();
                }

                $stud_invites = TrainingInvite::where([
                    'emp_user_acntuser_student_type' => Student::class,
                ])
                    ->whereIn('training_id', $training_ids)
                    ->whereIn('emp_user_acntuser_student_id', $stud_invite_ids_query)
                    ->whereNull('completed_datetime')
                    ->whereNull('completed_attempt_id')
                    ->count();

                $emp_invites = TrainingInvite::where([
                    'emp_user_acntuser_student_type' => Employee::class,
                ])
                    ->whereIn('training_id', $training_ids)
                    ->whereIn('emp_user_acntuser_student_id', $emp_invite_ids_query)
                    ->whereNull('completed_datetime')
                    ->whereNull('completed_attempt_id')
                    ->limit(100)
                    ->count();

                $empUnassigned_trainings_count = UnassignedTraining::where([
                    'location_id' => $locationId,
                    'emp_user_acntuser_student_type' => Employee::class,
                    'is_hidden' => 0,
                ])
                    ->whereIn('training_id', $training_ids)
                    ->whereIn('emp_user_acntuser_student_id', $emp_invite_ids_query)
                    ->limit(100)
                    ->count();

                $studUnassigned_trainings_count = UnassignedTraining::where([
                    'location_id' => $locationId,
                    'emp_user_acntuser_student_type' => Student::class,
                    'is_hidden' => 0,
                ])
                    ->whereIn('training_id', $training_ids)
                    ->whereIn('emp_user_acntuser_student_id', $stud_invite_ids_query)
                    ->count();

                return [
                    'pending_invites' => ($hcoPending ?? 0) + ($stud_invites ?? 0) + ($emp_invites ?? 0),
                    'unassigned_invites' => ($hcoUnassigned ?? 0) + ($empUnassigned_trainings_count ?? 0) + ($studUnassigned_trainings_count ?? 0),
                ];
            }

            return [];
        } catch (\Exception $e) {
            Log::error('TrainingController/getTrainingCount() => ' . $e->getMessage());
            Log::error('TrainingController/getTrainingCount()[data] => ' . json_encode([$locationId]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * training invite count
     *
     * @return \Illuminate\Http\Response
     */
    public function getTrainingInviteCount($location_id, $start_date, $end_date)
    {
        try {
            $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
            if (! empty($hco)) {
                $emp_invite_ids_query = Employee::where('primary_work_location_id', $location_id)->isActive()->pluck('id');
                $stud_invite_ids_query = Student::where('primary_work_location_id', $location_id)->pluck('id');
                $training_ids = TrainingLocation::where('location_id', $location_id)->whereHas('training', function ($query) {
                    $query->isActive();
                })
                    ->where('is_disable', 0)
                    ->pluck('training_id');

                $acc_completed_invites = $stu_completed_invites = $emp_completed_invites = 0;
                $acc_total_invites = $stu_total_invites = $emp_total_invites = 0;

                $acc_completed_invites = TrainingInvite::where([
                    'emp_user_acntuser_student_id' => $hco->hco_id,
                    'emp_user_acntuser_student_type' => $hco->hco_type,
                ])
                    ->whereIn('training_id', $training_ids)
                    ->whereBetween('created_at', [$start_date, $end_date])
                    ->whereBetween('completed_datetime', [$start_date, $end_date])
                    ->count();

                $acc_total_invites = TrainingInvite::where([
                    'emp_user_acntuser_student_id' => $hco->hco_id,
                    'emp_user_acntuser_student_type' => $hco->hco_type,
                ])
                    ->whereIn('training_id', $training_ids)
                    ->whereBetween('created_at', [$start_date, $end_date])
                    ->count();

                $stu_completed_invites = TrainingInvite::where([
                    'emp_user_acntuser_student_type' => Student::class,
                ])
                    ->whereIn('training_id', $training_ids)
                    ->whereIn('emp_user_acntuser_student_id', $stud_invite_ids_query)
                    ->whereBetween('created_at', [$start_date, $end_date])
                    ->whereBetween('completed_datetime', [$start_date, $end_date])
                    ->count();

                $stu_total_invites = TrainingInvite::where([
                    'emp_user_acntuser_student_type' => Student::class,
                ])
                    ->whereIn('training_id', $training_ids)
                    ->whereIn('emp_user_acntuser_student_id', $stud_invite_ids_query)
                    ->whereBetween('created_at', [$start_date, $end_date])
                    ->count();

                $emp_completed_invites = TrainingInvite::where([
                    'emp_user_acntuser_student_type' => Employee::class,
                ])
                    ->whereIn('training_id', $training_ids)
                    ->whereIn('emp_user_acntuser_student_id', $emp_invite_ids_query)
                    ->whereBetween('created_at', [$start_date, $end_date])
                    ->whereBetween('completed_datetime', [$start_date, $end_date])
                    ->count();

                $emp_total_invites = TrainingInvite::where([
                    'emp_user_acntuser_student_type' => Employee::class,
                ])
                    ->whereIn('training_id', $training_ids)
                    ->whereIn('emp_user_acntuser_student_id', $emp_invite_ids_query)
                    ->whereBetween('created_at', [$start_date, $end_date])
                    ->count();

                $completed_invites = $acc_completed_invites + $stu_completed_invites + $emp_completed_invites;
                $total_invites = $acc_total_invites + $stu_total_invites + $emp_total_invites;
                $show_location = ($completed_invites == $total_invites && $emp_total_invites > 0 && $total_invites > 0 ? 1 : 0);

                return $show_location;
            }

            return 0;
        } catch (\Exception $e) {
            Log::error('TrainingController/getTrainingInviteCount() => ' . $e->getMessage());
            Log::error('TrainingController/getTrainingInviteCount()[data] => ' . json_encode([$location_id, $start_date, $end_date]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Reset training for demo account
     *
     * @return \Illuminate\Http\Response
     */
    public function demoResetTraining($location_id)
    {
        try {
            $reset_training_codes = ['HT1', 'HT2', 'HT34A', 'HT34B', 'HT34C', 'HT3A', 'HT3B', 'HT3C'];
            // Fetch New employee, new hco training, hco and full staff training Ids
            $training_ids = Training::whereIn('training_code', $reset_training_codes)->pluck('id');

            // Delete new employee, new hco training, hco and full staff training for given location
            TrainingLocation::where('location_id', $location_id)->whereIn('training_id', $training_ids)->delete();

            $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
            $emp_invite_ids = Employee::where('primary_work_location_id', $location_id)->isActive()->pluck('id');
            // Delete training invites
            $hco_training_invites = TrainingInvite::where([
                'emp_user_acntuser_student_id' => $hco->hco_id,
                'emp_user_acntuser_student_type' => $hco->hco_type,
            ])
                ->whereIn('training_id', $training_ids)
                ->get();

            foreach ($hco_training_invites as $invite) {
                $invite->delete();
            }

            // Delete employee invites
            $employee_training_invites = TrainingInvite::where([
                'emp_user_acntuser_student_type' => Employee::class,
            ])
                ->whereIn('training_id', $training_ids)
                ->whereIn('emp_user_acntuser_student_id', $emp_invite_ids)
                ->get();

            foreach ($employee_training_invites as $invite) {
                $invite->delete();
            }
            DB::beginTransaction();
            $user_data = $this->getMainAccountDetails();
            $check_user_pause = Setting::where('user_id', $user_data['id'])->where('functionality', 'training_pause')->count();
            if ($check_user_pause == 0) {
                // Fetch training list
                $training_list = Training::select(['id', 'training_code', 'who_can_train', 'trigger_month', 'parent_training_id', 'notification_code'])
                    ->whereIn('training_code', $reset_training_codes)
                    ->isActive()
                    ->get();

                if ($training_list->isEmpty()) {
                    return;
                }

                foreach ($training_list as $training) {
                    try {
                        $schedule_date = Carbon::now()->endOfDay();
                        $temp_data = [
                            'location_id' => $location_id,
                            'training_id' => $training->id,
                            'trigger_type' => 'auto',
                        ];
                        $training_month = $training->trigger_month == null ? 0 : $training->trigger_month;

                        if ($training->training_code === 'HT1') {
                            $temp_data['is_triggered'] = 0;
                            $temp_data['schedule_date'] = $schedule_date->addMonth()->format('Y-m-d');
                        }
                        if (in_array($training->training_code, ['HT34A', 'HT34B', 'HT34C'])) {
                            $temp_data['is_triggered'] = 0;
                            $temp_data['schedule_date'] = $schedule_date->addMonth($training_month)->format('Y-m-d');
                        }

                        if (in_array($training->training_code, ['HT3A', 'HT3B', 'HT3C'])) {
                            $temp_data['is_triggered'] = 0;
                            $temp_data['schedule_date'] = $schedule_date->addMonth($training_month)->format('Y-m-d');
                        }

                        if ($training->training_code === 'HT2') {
                            $temp_data['is_triggered'] = 1;
                            $temp_data['schedule_date'] = $schedule_date->format('Y-m-d');
                        }

                        TrainingLocation::create($temp_data);
                        if ($training->training_code === 'HT2') {
                            $this->sendInitialInvites($training, $location_id);
                        }
                    } catch (\Exception $e) {
                        Log::error('TrainingController/demoResetTraining()[training_list_error] => ' . $e->getMessage());
                        Log::error('TrainingController/demoResetTraining()[training_list_data] => ' . json_encode($training));
                    }
                }
                DB::commit();

                return $this->success(Config::get('constants.SUCCESS'), 200, []);
            }
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('TrainingController/demoResetTraining() => ' . $e->getMessage());
            Log::error('TrainingController/demoResetTraining()[data] => ' . json_encode([$location_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get sub trainings
     *
     * @return \Illuminate\Http\Response
     */
    public function TrainingDetailForChildTraining(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required|numeric',
                'training_id' => 'required|numeric',
                'is_archived' => 'sometimes|boolean',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $locationId = $request->input('location_id');
            $training_id = $request->input('training_id');
            $hco = HipaaComplianceOfficer::where('location_id', $locationId)->with(['hco', 'location.user'])->first();
            $tabName = $request->input('tab_name');
            $isArchived = (int) $request->input('is_archived', 0);
            $user_data = $this->getLoginUserData();
            $tabName = $request->input('tab_name');
            $isArchived = (int) $request->input('is_archived', 0);

            if ($tabName == 'employee' && $user_data['user_type'] !== 'USER') {
                $who_can_train_array[] = 'hco';
            }

            $model_type = $tabName === 'employee' ? \App\Models\Employee::class : \App\Models\Student::class;
            $invite_ids_query = $tabName === 'employee'
                ? Employee::where('primary_work_location_id', $locationId)->isActive()->pluck('id')
                : Student::where('primary_work_location_id', $locationId)->pluck('id');

            $renewalDate = $hco->location->user->contract_renewal_date;
            $training_list = TrainingLocation::select('training_locations.*', 'trainings.display_order')->where('location_id', $locationId)
                ->where('training_id', $training_id)
                ->with('schedule_by')
                ->leftJoin('trainings', 'trainings.id', '=', 'training_locations.training_id')
                ->orderBy('is_disable', 'asc')
                ->orderBy('is_triggered', 'desc')
                ->orderBy('trainings.display_order', 'DESC')
                ->get()
                ->map(function ($item) use ($hco, $invite_ids_query, $model_type, $renewalDate) {
                    // $item->display_order = $item->training->display_order;
                    $item->assigned = ($item->training->who_can_train === 'hco') ? '-' : 0;
                    $item->completed = 0;
                    $item->unassigned_trainings_count = 0;
                    $item->renewal_date = $renewalDate;
                    if ($item->is_triggered === 1) {
                        if ($item->training->who_can_train === 'hco') {
                            $invite = TrainingInvite::where([
                                'training_id' => $item->training_id,
                                'emp_user_acntuser_student_id' => $hco->hco_id,
                                'emp_user_acntuser_student_type' => $hco->hco_type,
                            ])->latest()->first();

                            $item->unassigned_trainings_count = UnassignedTraining::where([
                                'training_id' => $item->training_id,
                                'emp_user_acntuser_student_id' => $hco->hco_id,
                                'emp_user_acntuser_student_type' => $hco->hco_type,
                                'is_hidden' => 0,
                            ])->count();

                            $item->unassigned_hidden_count = UnassignedTraining::where([
                                'training_id' => $item->training_id,
                                'emp_user_acntuser_student_id' => $hco->hco_id,
                                'emp_user_acntuser_student_type' => $hco->hco_type,
                                'is_hidden' => 1,
                            ])->count();

                            $item->assigned = $invite ? ($hco->hco->first_name . ' ' . $hco->hco->last_name) : '-';
                            $item->completed = $invite && $invite->completed_attempt_id && $invite->completed_datetime ? 1 : 0;
                        } else {
                            $invites = TrainingInvite::where([
                                'training_id' => $item->training_id,
                                'emp_user_acntuser_student_type' => $model_type,
                            ])
                                ->whereIn('emp_user_acntuser_student_id', $invite_ids_query)
                                ->orderBy('created_at', 'desc')
                                ->get()
                                ->unique('emp_user_acntuser_student_id');

                            $item->unassigned_trainings_count = UnassignedTraining::where([
                                'training_id' => $item->training_id,
                                'location_id' => $item->location_id,
                                'emp_user_acntuser_student_type' => $model_type,
                                'is_hidden' => 0,
                            ])
                                ->whereIn('emp_user_acntuser_student_id', $invite_ids_query)
                                ->count();

                            $item->unassigned_hidden_count = UnassignedTraining::where([
                                'training_id' => $item->training_id,
                                'location_id' => $item->location_id,
                                'emp_user_acntuser_student_type' => $model_type,
                                'is_hidden' => 1,
                            ])
                                ->whereIn('emp_user_acntuser_student_id', $invite_ids_query)
                                ->count();

                            $item->assigned = $invites->count();
                            $item->completed = $invites->whereNotNull('completed_datetime')->whereNotNull('completed_attempt_id')->count();
                        }
                    }

                    return $item;
                });

            return $this->success(Config::get('constants.SUCCESS'), 200, ['single_training' => $training_list]);
        } catch (\Exception $e) {
            Log::error('TrainingController/TrainingDetailForChildTraining() => ' . $e->getMessage());
            Log::error('TrainingController/TrainingDetailForChildTraining()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get subtraining list for resend
     *
     * @return \Illuminate\Http\Response
     */
    public function getSubTrainingListForResend(Request $request)
    {

        try {
            $validator_rules = [
                'location_id' => 'required|numeric',
                'training_id' => 'required|numeric',
                'emp_stud_type' => 'required',
                'emp_stud_user_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $training = Training::where('id', $request['training_id'])
                ->with('childTraining')
                ->first();

            $sub_trainig_arr = [];
            $trainig_id_name_array[$training->id] = ['id' => $training->id, 'title' => $training->title, 'title_for_tab' => $training->title_for_tab];
            $trainig_id_array[] = $training->id;
            foreach ($training->childTraining as $key) {
                $trainig_id_array[] = $key->id;
                $trainig_id_name_array[$key->id] = ['id' => $key->id, 'title' => $key->title, 'title_for_tab' => $key->title_for_tab];
            }
            $training_id_str = implode(',', $trainig_id_array);

            $emp_stud_type = $request->input('emp_stud_type');
            $emp_stud_user_id = $request->input('emp_stud_user_id');
            foreach ($trainig_id_array as $key => $value) {
                $sub_trainig_data = TrainingInvite::where('training_id', $value)
                    ->where(['emp_user_acntuser_student_type' => $emp_stud_type, 'emp_user_acntuser_student_id' => $emp_stud_user_id])
                    //->orderBy("id","desc")
                    ->orderByRaw("FIELD(training_id,$training_id_str)")
                    ->latest()->first();

                if (! empty($sub_trainig_data)) {
                    if ($sub_trainig_data->completed_datetime != '' && $sub_trainig_data->completed_attempt_id != '') {
                        $sub_trainig_arr[] = $trainig_id_name_array[$value];
                    }
                }
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $sub_trainig_arr);
        } catch (\Exception $e) {
            Log::error('TrainingController/getSubTrainingListForResend() => ' . $e->getMessage());
            Log::error('TrainingController/getSubTrainingListForResend()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get subtraining list of unassigned
     *
     * @return \Illuminate\Http\Response
     */
    public function getUnassignedSubTrainingList(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required|numeric',
                'training_id' => 'required|numeric',
                'emp_stud_type' => 'required',
                'emp_stud_user_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $training = Training::where('id', $request['training_id'])
                ->with('childTraining')
                ->first();

            $trainig_array[] = $training->id;
            foreach ($training->childTraining as $key) {
                $trainig_array[] = $key->id;
            }
            $training_id_str = implode(',', $trainig_array);

            $emp_stud_type = $request->input('emp_stud_type');
            $emp_stud_user_id = $request->input('emp_stud_user_id');
            $sub_trainig_data = UnassignedTraining::whereIn('training_id', $trainig_array)
                ->where(['emp_user_acntuser_student_type' => $emp_stud_type, 'emp_user_acntuser_student_id' => $emp_stud_user_id])
                ->where('is_hidden', 0)
                ->with('training:id,title,title_for_list,title_for_tab')
                ->orderByRaw("FIELD(training_id,$training_id_str)")
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $sub_trainig_data);
        } catch (\Exception $e) {
            Log::error('TrainingController/getUnassignedSubTrainingList() => ' . $e->getMessage());
            Log::error('TrainingController/getUnassignedSubTrainingList()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get subtraining list of hidden
     *
     * @return \Illuminate\Http\Response
     */
    public function getHiddenSubTrainingList(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required|numeric',
                'training_id' => 'required|numeric',
                'emp_user_acntuser_student_type' => 'required',
                'is_hidden' => 'required',
                'emp_user_acntuser_student_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $training = Training::where('id', $request['training_id'])
                ->with('childTraining')
                ->first();

            $trainig_array[] = $training->id;
            foreach ($training->childTraining as $key) {
                $trainig_array[] = $key->id;
            }
            $training_id_str = implode(',', $trainig_array);
            $emp_user_acntuser_student_type = $request->input('emp_user_acntuser_student_type');
            $is_hidden = $request->input('is_hidden');
            $emp_user_acntuser_student_id = $request->input('emp_user_acntuser_student_id');
            $sub_trainig_data = UnassignedTraining::whereIn('training_id', $trainig_array)
                ->where(['emp_user_acntuser_student_type' => $emp_user_acntuser_student_type, 'emp_user_acntuser_student_id' => $emp_user_acntuser_student_id])
                ->where('is_hidden', $is_hidden)
                ->with('training:id,title,title_for_list,title_for_tab')
                ->orderByRaw("FIELD(training_id,$training_id_str)")
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $sub_trainig_data);
        } catch (\Exception $e) {
            Log::error('TrainingController/getHiddenSubTrainingList() => ' . $e->getMessage());
            Log::error('TrainingController/getHiddenSubTrainingList()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
