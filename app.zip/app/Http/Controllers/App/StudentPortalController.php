<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\Location;
use App\Models\Student;
use App\Models\Training;
use App\Models\TrainingAttempt;
use App\Models\TrainingInvite;
use App\Models\TrainingQuestionAnswer;
use App\Models\TrainingQuizAttempt;
use App\Traits\ApiResponser;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;

class StudentPortalController extends Controller
{
    use ApiResponser, SendMail;

    /**
     * student training page
     *
     * @return \Illuminate\Http\Response
     */
    public function showTraining($student_id = '', $invite_id = '')
    {
        if ($student_id == '' || $invite_id == '') {
            return redirect()->route('login');
        } else {
            $student = Student::with(['user.reseller'])->where('id', base64_decode($student_id))->first();
            if ($student == null) {
                return redirect()->route('login');
            }
            $training_invite = TrainingInvite::withCount(['trainingAttempt'])->where('emp_user_acntuser_student_id', base64_decode($student_id))
                ->where('emp_user_acntuser_student_type', \App\Models\Student::class)
                ->where('id', base64_decode($invite_id))->latest()->first();

            return view('app.pages.studentportaltraining', ['student' => $student, 'training_invite' => $training_invite]);
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get invite details
     *
     * @return \Illuminate\Http\Response
     */
    public function getInviteDetails(Request $request)
    {
        try {
            $validator_rules = [
                'invite_id' => 'required|numeric',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $invite_details = TrainingInvite::with(['training', 'trainingAttempt', 'emp_user_acntuser_student'])->findOrFail($request['invite_id']);
            $location = Location::findOrFail($invite_details->emp_user_acntuser_student->primary_work_location_id);
            $data = [
                'invite_details' => $invite_details,
                'location' => $location,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('StudentPortalController/getInviteDetails() => '.$e->getMessage());
            Log::error('StudentPortalController/getInviteDetails()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * training quiz
     *
     * @return \Illuminate\Http\Response
     */
    public function getTrainingQuiz(Request $request)
    {
        try {
            $validator_rules = [
                'training_id' => 'required|numeric',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $training_quiz_data = Training::select(['id', 'training_code', 'title'])
                ->with(['TrainingQuestion' => function ($trainingQuestionQuery) {
                    $trainingQuestionQuery->select(['id', 'training_id', 'question', 'display_order', 'is_active'])->isActive()->orderBy('display_order', 'asc');
                }, 'TrainingQuestion.TrainingQuestionAnswer' => function ($trainingQuestionAnswerQuery) {
                    $trainingQuestionAnswerQuery->select(['id', 'training_question_id', 'answer']);
                }])->where('id', $request['training_id'])->first();

            return $this->success(Config::get('constants.SUCCESS'), 200, $training_quiz_data);
        } catch (\Exception $e) {
            Log::error('StudentPortalController/TrainingQuiz() => '.$e->getMessage());
            Log::error('StudentPortalController/TrainingQuiz()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * training complete record
     *
     * @return \Illuminate\Http\Response
     */
    public function addTrainingCompleteRecord(Request $request)
    {
        try {
            $validator_rules = [
                'invite_id' => 'required|numeric',
                'queans' => 'required|array',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            if ($request['invite_id'] > 0) {
                $training_data = TrainingInvite::where('id', '=', $request['invite_id'])
                    ->with(['training', 'emp_user_acntuser_student'])
                    ->first();
                $training_attempt_data = [
                    'invite_id' => $request['invite_id'],
                    'attempted_from' => 'software',
                ];
                $add_training_attempt_data = TrainingAttempt::create($training_attempt_data);
                if ($add_training_attempt_data['id'] > 0) {
                    $training_quiz_attempt_data = [];
                    foreach ($request['queans'] as $data) {
                        $checkAnsTrueFalse = TrainingQuestionAnswer::where('training_question_id', '=', $data['question_id'])
                            ->where('id', '=', $data['answer_id'])
                            ->first();
                        $training_quiz_attempt_data[] = [
                            'is_given_correct' => $checkAnsTrueFalse['is_correct_answer'],
                            'training_attempt_id' => $add_training_attempt_data['id'],
                            'question_id' => $data['question_id'],
                            'answer_id' => $data['answer_id'],
                            'created_at' => Carbon::now(),
                            'updated_at' => Carbon::now(),
                        ];
                    }
                    TrainingQuizAttempt::insert($training_quiz_attempt_data);
                    $total_que_attempt = TrainingQuizAttempt::where('training_attempt_id', '=', $add_training_attempt_data['id'])->count();
                    $total_correct_ans_attempt = TrainingQuizAttempt::where('training_attempt_id', '=', $add_training_attempt_data['id'])->where('is_given_correct', '=', 'yes')->count();
                    $result_of_training_quiz = round(($total_correct_ans_attempt * 100) / $total_que_attempt);
                    if ($result_of_training_quiz >= 70) {
                        //complete training and ref token blank
                        $training_invite_data = [
                            'ref_token' => '',
                            'completed_datetime' => gmdate('Y-m-d H:i:s'),
                            'completed_attempt_id' => $add_training_attempt_data['id'],
                        ];
                        $update_invite_data = TrainingInvite::findOrFail($request['invite_id']);
                        $update_invite_data->update($training_invite_data);
                        $trainingController = new TrainingController;
                        $trainingController->moveTrainingToArchive($training_data->emp_user_acntuser_student->primary_work_location_id, $training_data->training_id);

                    }
                    $data = [
                        'training_data' => $training_data,
                        'total_que_attempt' => $total_que_attempt,
                        'total_correct_ans_attempt' => $total_correct_ans_attempt,
                        'result_of_training_quiz' => $result_of_training_quiz,
                    ];
                    DB::commit();

                    return $this->success(Config::get('constants.SUCCESS'), 200, $data);
                } else {
                    DB::rollback();

                    return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
                }
            } else {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('StudentPortalController/addTrainingCompleteRecord() => '.$e->getMessage());
            Log::error('StudentPortalController/addTrainingCompleteRecord()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get Training Certificate
     *
     * @return \Illuminate\Http\Response
     */
    public function getTrainingCertificate(Request $request)
    {
        $validator_rules = [
            'location_id' => 'required',
            'invite_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $location = Location::findOrFail($request['location_id']);
            $training_invite = TrainingInvite::with(['training', 'emp_user_acntuser_student'])->findOrFail($request['invite_id']);
            $complete_date = Carbon::parse($training_invite->completed_datetime)->setTimeZone($request['timezone'])->format('F d,Y');

            $file = public_path('policydocuments/TrainingCertificate.docx');
            $phpword = new \PhpOffice\PhpWord\TemplateProcessor($file);
            $phpword->setValue('EMPLOYEE_NAME', htmlspecialchars($training_invite->emp_user_acntuser_student->first_name).' '.htmlspecialchars($training_invite->emp_user_acntuser_student->last_name));
            $phpword->setValue('TRAINING_MODULE_NAME', htmlspecialchars($training_invite->training->title));
            $phpword->setValue('DATE', $complete_date);
            $phpword->setValue('COMPANY_NAME', htmlspecialchars($location->company_name));
            $generated_training_certificate = storage_path('app/public').'/generatedpolicydocuments/TrainingCertificate_'.$training_invite->id.'.docx';
            $phpword->saveAs($generated_training_certificate);
            $generated_certificate_directory_path = storage_path('app/public').'/generatedpolicydocuments';
            $generated_training_certificate_pdf = asset('storage/generatedpolicydocuments/TrainingCertificate_'.$training_invite->id.'.pdf');
            if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                // change libreoffice path as per installation path from your machine
                exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  '.$generated_certificate_directory_path.' '.$generated_training_certificate);
            } else {
                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir '.$generated_certificate_directory_path.' '.$generated_training_certificate);
            }
            unlink($generated_training_certificate);

            return $this->success(Config::get('constants.SUCCESS'), 200, $generated_training_certificate_pdf);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('StudentPortalController/getTrainingCertificate() => '.$e->getMessage());
            Log::error('StudentPortalController/getTrainingCertificate()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
