<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AccountUserLocationAccess;
use App\Models\EmailTemplate;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\LocationNotification;
use App\Models\ModuleCompletedStatus;
use App\Models\OngoingRiskAnalysisQuestion;
use App\Models\RiskAnalysisAttemptedQuestion;
use App\Models\RiskAnalysisAttemptedQuestionAnswer;
use App\Models\RiskAnalysisPreviousAttemptedQuestionAnswer;
use App\Models\RiskAnalysisQuestion;
use App\Models\RiskAnalysisQuestionAnswerOption;
use App\Models\RiskAnalysisContributorQuestion;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\GetMainUserData;
use App\Traits\Notification;
use App\Traits\SendMail;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class SecurityRiskAnalysisController extends Controller
{
    use ApiResponser, CheckAccessRight, GetMainUserData, Notification, SendMail;

    /**
     * SRA page
     *
     * @return \Illuminate\Http\Response
     */
    public function showSecurityRiskAnalysis(Request $request, $location_id = '')
    {
        if ($location_id != '') {
            $location_id = base64_decode($location_id, true);
            if ($location_id) {
                if ($this->checkAccessRight('security_risk_analysis', $location_id)) {
                    $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                    $company_info_completed = ModuleCompletedStatus::where(['location_id' => $location_id, 'module' => 'company_info', 'is_completed' => 1])->first();
                    if ($hco && $company_info_completed) {
                        return view('app.pages.securityRiskAnalysis', ['location_id' => $location_id]);
                    } else {
                        return redirect('/dashboard');
                    }
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Get risk analysis percentage status
     *
     * @return \Illuminate\Http\Response
     */
    public function getRiskAnalysisStatus(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $hco = HipaaComplianceOfficer::where('location_id', $request->location_id)->first();
            $company_info_completed = ModuleCompletedStatus::where(['location_id' => $request->location_id, 'module' => 'company_info', 'is_completed' => 1])->first();
            if (! $company_info_completed || ! $hco) {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
            $data = $this->getPercentageCount($request['location_id']);

            $completed = ModuleCompletedStatus::where([
                'location_id' => $request['location_id'],
                'module' => 'risk_analysis',
            ])->first();
            $data['is_completed'] = $completed ? $completed['is_completed'] : 0;
            if ($completed && $completed['is_completed'] == 1) {
                $data['first_time_sra_added'] = false;
            } else {
                $data['first_time_sra_added'] = true;
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/getRiskAnalysisStatus() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/getRiskAnalysisStatus()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * load risk analysis question
     *
     * @return \Illuminate\Http\Response
     */
    public function loadRiskAnalysisQuestion(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'pagination_type' => 'required|in:next,previous,resume,first,continue_for_demo',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $location_id = $request['location_id'];
            $question_id = $request->has('question_id') ? $request['question_id'] : null;
            $answer_id = $request->has('answer_id') ? $request['answer_id'] : null;
            $pagination_type = $request->has('pagination_type') ? $request['pagination_type'] : 'next';
            $percentage_count = $this->getPercentageCount($location_id);
            if ($pagination_type == 'first') {
                $question_detail = RiskAnalysisQuestion::with(['riskAnalysisQuestionAnswerOptions', 'questionCategory', 'questionLawSection'])
                    ->isActive()->orderBy('display_order', 'asc')->first();
                $check_pervious = 0;
            } elseif ($pagination_type == 'next') {
                $question_detail = $this->getNextQuestion($location_id, $question_id, $answer_id);
                $check_pervious = RiskAnalysisAttemptedQuestion::where('location_id', $location_id)->count();
            } elseif ($pagination_type == 'resume') {
                $resume_que = RiskAnalysisAttemptedQuestion::where('location_id', $location_id)
                    ->select(['risk_analysis_attempted_questions.id', 'risk_analysis_attempted_questions.question_id'])
                    ->join('risk_analysis_questions', 'risk_analysis_questions.id', '=', 'risk_analysis_attempted_questions.question_id')
                    ->join('risk_analysis_attempted_question_answers', 'risk_analysis_attempted_question_answers.attempted_question_id', '=', 'risk_analysis_attempted_questions.id')
                    ->orderBy('risk_analysis_attempted_question_answers.created_at', 'desc')
                    ->first();

                $attempted_ans = RiskAnalysisAttemptedQuestionAnswer::where('attempted_question_id', $resume_que['id'])->get()->toArray();
                $ans_ids = array_column($attempted_ans, 'answer_id');
                if ($resume_que) {
                    $question_detail = $this->getNextQuestion($location_id, $resume_que['question_id'], count($ans_ids) > 0 ? $ans_ids : null);
                } else {
                    $question_detail = null;
                }
                $check_pervious = RiskAnalysisAttemptedQuestion::where('location_id', $location_id)->count();
            }
            if ($pagination_type == 'previous') {
                $question_detail = $this->getPreviousQuestion($location_id, $question_id);
                $check_pervious = RiskAnalysisAttemptedQuestion::where('location_id', $location_id)
                    ->where('id', '<', $question_detail['riskAnalysisAttemptedQuestion'][0]['id'])
                    ->count();
            }

            if ($pagination_type == 'continue_for_demo') {
                $check_pervious = RiskAnalysisAttemptedQuestion::where('location_id', $location_id)->count();
                $question_detail = $this->getContinueForDemoQuestion($location_id);
            }

            if ($question_detail && ($question_detail->question_code == 'Q75S3' || $question_detail->question_code == 'Q75S4' || $question_detail->question_code == 'Q75S5')) {
                $str_to_replace = $this->getDynamicString($location_id, 'Q75');
                $question_detail['question'] = str_replace('{%IT_PROVIDER_QUESTION%}', $str_to_replace, $question_detail['question']);
            }

            $data = [
                'question_detail' => $question_detail,
                'percentage_count' => $percentage_count,
                'has_previous' => $check_pervious > 0 ? true : false,
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('SecurityRiskAnalysisController/loadRiskAnalysisQuestion() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/loadRiskAnalysisQuestion()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Save answer
     *
     * @return \Illuminate\Http\Response
     */
    public function saveAnswer(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'question_id' => 'required',
                'answer_id' => 'required_without:answer|array',
                'answer' => 'required_without:answer_id',
                'is_ans_same' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $answer_fields = $request->all();
            DB::beginTransaction();
            $attempted_question = RiskAnalysisAttemptedQuestion::where(['question_id' => $answer_fields['question_id'], 'location_id' => $answer_fields['location_id']])->first();
            if ($attempted_question) {
                if ($request->has('note')) {
                    $attempted_question->update(['note' => $request['note']]);
                }
                if (! $request['is_ans_same']) {
                    $attempted_question_answer = RiskAnalysisAttemptedQuestionAnswer::where('attempted_question_id', $attempted_question['id'])->get();
                    if (count($attempted_question_answer) > 0) {
                        $attempted_question_answer->each(function ($ans) use ($attempted_question) {
                            $ans->delete();
                            $this->removeAnswerRecursive($attempted_question['question_id'], $ans['answer_id'], $attempted_question['location_id']);
                        });
                    }
                    $this->removeOngoingRecursive($attempted_question['question_id'], $attempted_question['location_id']);
                }
            } else {
                $attempted_question = RiskAnalysisAttemptedQuestion::create($answer_fields);
            }
            if (! $request['is_ans_same']) {
                $selected_answer = [];
                if (isset($answer_fields['answer']) && $answer_fields['answer'] != '') {
                    $selected_answer[0]['answer'] = $answer_fields['answer'];
                }
                if (isset($answer_fields['answer_id']) && is_array($answer_fields['answer_id'])) {
                    foreach ($answer_fields['answer_id'] as $key => $ans) {
                        $selected_answer[$key]['answer_id'] = $ans;
                    }
                }
                $attempted_question->attemptedQuestionAnswer()->createMany($selected_answer);
            }

            $question_detail = RiskAnalysisQuestion::where('id', $answer_fields['question_id'])->with('remindOption')->first();
            if ($question_detail['question_answer_layout'] == 'radio') {
                $answer_detail = RiskAnalysisQuestionAnswerOption::where('id', $answer_fields['answer_id'][0])
                    ->with('remindOption')->first();
                if (! empty($answer_detail['remindOption']) && ($answer_detail['remindOption']['ongoing_question_id'] != null && $answer_detail['remindOption']['remind_month'] != null)) {
                    $current_date = gmdate('Y-m-d');
                    $next_remind_date = gmdate('Y-m-d', strtotime('+'.$answer_detail['remindOption']['remind_month'].' month', strtotime($current_date)));
                    $attempted_question->update(['next_remind_date' => $next_remind_date]);
                } elseif ($attempted_question['next_remind_date'] != null) {
                    $attempted_question->update(['next_remind_date' => null]);
                }
            } else {
                if (! empty($question_detail['remindOption']) && ($question_detail['remindOption']['ongoing_question_id'] != null && $question_detail['remindOption']['remind_month'] != null)) {
                    $current_date = gmdate('Y-m-d');
                    $next_remind_date = gmdate('Y-m-d', strtotime('+'.$question_detail['remindOption']['remind_month'].' month', strtotime($current_date)));
                    $attempted_question->update(['next_remind_date' => $next_remind_date]);
                } elseif ($attempted_question['next_remind_date'] != null) {
                    $attempted_question->update(['next_remind_date' => null]);
                }
            }

            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200, $answer_fields);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('SecurityRiskAnalysisController/saveAnswer() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/saveAnswer()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Complete RA status and send required emails
     *
     * @return \Illuminate\Http\Response
     */
    public function completeRA(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            ModuleCompletedStatus::updateOrCreate(
                [
                    'location_id' => $request['location_id'],
                    'module' => 'risk_analysis',
                ],
                ['is_completed' => 1]
            );

            $hco = HipaaComplianceOfficer::where('location_id', $request['location_id'])->with('hco')->first();
            $location = Location::with(['employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation', 'activeEmployeePrimaryWorkLocation', 'user.reseller'])->findOrFail($request['location_id']);
            $logo = ($location->user->partner_reseller_id != null ? $location->user->reseller->logo : '');

            if ((count($location->employeePrimaryWorkLocation) > 0 || count($location->employeeSecondaryWorkLocation) > 0)) {
                $notification_HCE_AN6 = $this->getNotificationByCode('HCE-AN6');
                if ($this->checkNotificationAlreadyAdded($notification_HCE_AN6->code, $request['location_id']) == 0) {
                    $notification_HCE_AN6_data = [
                        'location_id' => $request['location_id'],
                        'notification_id' => $notification_HCE_AN6['id'],
                    ];
                    $this->createNotification($notification_HCE_AN6_data);
                }
                $notification_HCE_AN12 = $this->getNotificationByCode('HCE-AN12');
                if ($this->checkNotificationAlreadyAdded($notification_HCE_AN12->code, $request['location_id']) == 0) {
                    $notification_HCE_AN12_data = [
                        'location_id' => $request['location_id'],
                        'notification_id' => $notification_HCE_AN12['id'],
                    ];
                    $this->createNotification($notification_HCE_AN12_data);
                }
            }
            if (count($location->activeEmployeePrimaryWorkLocation) > 0) {
                (new TrainingController)->addTrainingLocations($request['location_id']);
            }

            $notification_HCE_AN4 = $this->getNotificationByCode('HCE-AN4');
            LocationNotification::where('notification_id', $notification_HCE_AN4->id)
                ->where('location_id', $request['location_id'])
                ->where('is_completed', 0)
                ->update(['is_completed' => 1]);

            //update Q77 question is answer is no or don't know
            $this->updateQ77andQ77S1Answers($request['location_id']);
            // add scorecard history entry for sra complete
            \Artisan::call('scorecard:history '.$request['location_id']);

            $SF_location = Location::where('id', $request['location_id'])->whereNotNull('salesforce_unique_id')->first();
            if ($SF_location) {
                SendLocationDataToSalesForce::dispatch($SF_location->id);
            }

            return $this->success(Config::get('constants.SUCCESS'), 200);
        } catch (Exception $e) {
            Log::error('SecurityRiskAnalysisController/completeRA() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/completeRA()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * start over the ra questions
     *
     * @return \Illuminate\Http\Response
     */
    public function startOver(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            ModuleCompletedStatus::updateOrCreate(
                [
                    'location_id' => $request['location_id'],
                    'module' => 'risk_analysis',
                ],
                ['is_completed' => 0]
            );
            RiskAnalysisAttemptedQuestion::where('location_id', $request['location_id'])
                ->each(function ($que) {
                    $que->delete();
                });
            OngoingRiskAnalysisQuestion::where('location_id', $request['location_id'])
                ->each(function ($que) {
                    $que->delete();
                });

            RiskAnalysisContributorQuestion::where('location_id', $request['location_id'])
                ->each(function ($que) {
                    $que->delete();
                });
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200);
        } catch (Exception $e) {
            DB::rollback();
            Log::error('SecurityRiskAnalysisController/startOver() => '.$e->getMessage());
            Log::error('SecurityRiskAnalysisController/startOver()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Get Percentage Count
     *
     * @param  \Illuminate\Http\Request  $request
     */
    public function getPercentageCount($location_id)
    {
        $all_question_ids = RiskAnalysisQuestion::isActive()->pluck('id')->toArray();

        $attempted_questions = RiskAnalysisQuestion::isActive()
            ->where('level', 1)
            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location_id) {
                return $que->where(['location_id' => $location_id]);
            })
            ->with('childQuestionNested')
            ->get();
        $attempted_question_ids = $attempted_questions->pluck('id')->toArray();

        $this->getRecursiveCountOfQuestion($attempted_questions, $attempted_question_ids);

        $attempted_with_total_child = $attempted_question_ids;
        foreach ($attempted_with_total_child as $attempted_id) {
            $attempted = RiskAnalysisAttemptedQuestion::where([
                'question_id' => $attempted_id,
                'location_id' => $location_id,
            ])->with('attemptedQuestionAnswer')->first();
            if (isset($attempted->attemptedQuestionAnswer)) {
                foreach ($attempted->attemptedQuestionAnswer as $ans) {
                    $sub_question = RiskAnalysisQuestion::where([
                        'parent_question_id' => $attempted_id,
                        'parent_answer_id' => $ans['answer_id'],
                    ])->isActive()->get();

                    $sub_questions_attempted = RiskAnalysisAttemptedQuestion::where('location_id', $location_id)->get();
                    foreach ($sub_question as $sq) {
                        $sub_attempted = $sub_questions_attempted->firstWhere('question_id', $sq['id']);

                        if (! $sub_attempted) {
                            if (($key = array_search($sq['id'], $attempted_question_ids)) !== false) {
                                unset($attempted_question_ids[$key]);
                            }
                        }
                    }
                }
            }
        }
        $ongoing_question_count = OngoingRiskAnalysisQuestion::where([
            'location_id' => $location_id,
            'is_answered' => 0,
            'question_type' => 'normal',
        ])->count();
        $total_questions = count($all_question_ids);
        $attempted_questions_count = count($attempted_question_ids) + $ongoing_question_count;

        if ($total_questions > 0) {
            $per = ($attempted_questions_count / $total_questions) * 100;
        } else {
            $per = 0;
        }

        return [
            'total_questions' => $total_questions,
            'attempted_questions' => $attempted_questions_count,
            'percentage' => round($per),
        ];
    }

    /**
     * Get Recursive Count Of Question
     */
    private function getRecursiveCountOfQuestion($questions, &$attempted_question_ids)
    {
        foreach ($questions as $que) {
            if (! in_array($que['id'], $attempted_question_ids)) {
                $attempted_question_ids[] = $que['id'];
            }
            if (count($que->childQuestionNested) > 0) {
                $this->getRecursiveCountOfQuestion($que->childQuestionNested, $attempted_question_ids);
            }
        }
    }

    /**
     * Get Next Question
     */
    public function getNextQuestion($location_id, $question_id, $answer_id)
    {

        $current_question = RiskAnalysisQuestion::where('id', $question_id)->first();
        if ($current_question) {
            $question = RiskAnalysisQuestion::with(['riskAnalysisQuestionAnswerOptions', 'questionCategory', 'questionLawSection', 'riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                return $que->where(['location_id' => $location_id]);
            }])
                ->where('parent_question_id', $question_id);
            if (is_array($answer_id)) {
                $question = $question->whereIn('parent_answer_id', $answer_id);
            } else {
                $question = $question->where('parent_answer_id', $answer_id);
            }
            $question = $question->isActive()
                ->orderBy('display_order', 'asc')
                ->first();
            if (! $question) {
                $question = RiskAnalysisQuestion::with(['riskAnalysisQuestionAnswerOptions', 'questionCategory', 'questionLawSection', 'riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                    return $que->where(['location_id' => $location_id]);
                }])
                    ->where('parent_question_id', $current_question['parent_question_id'])
                    ->where('parent_answer_id', $current_question['parent_answer_id'])
                    ->where('display_order', '>', $current_question['display_order'])
                    ->where('level', '=', $current_question['level'])
                    ->isActive()
                    ->orderBy('display_order', 'asc')
                    ->first();

                if (! $question) {
                    $next_parent_question = null;
                    $question = $this->getNextParentQuestion($current_question['parent_question_id'], $location_id, $next_parent_question);
                    $question = $next_parent_question;
                }
            }

            return $question;
        }

        return null;
    }

    /**
     * Get Next Parent Question
     */
    public function getNextParentQuestion($question_id, $location_id, &$next_parent_question)
    {
        $parent_question = RiskAnalysisQuestion::where('id', $question_id)->first();
        if (! $parent_question) {
            return null;
        }
        $question = RiskAnalysisQuestion::with(['riskAnalysisQuestionAnswerOptions', 'questionCategory', 'questionLawSection', 'riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
            return $que->where(['location_id' => $location_id]);
        }])
            ->where('parent_question_id', $parent_question['parent_question_id'])
            ->where('display_order', '>', $parent_question['display_order'])
            ->where('level', '=', $parent_question['level'])
            ->isActive()
            ->orderBy('display_order', 'asc')
            ->first();
        if (! $question) {
            $this->getNextParentQuestion($parent_question['parent_question_id'], $location_id, $next_parent_question);
        } else {
            $next_parent_question = $question;
        }
    }

    /**
     * Get Previous Question
     */
    public function getPreviousQuestion($location_id, $question_id)
    {

        $currentQuestion = RiskAnalysisQuestion::where('id', $question_id)->first();
        if ($currentQuestion) {
            $question = RiskAnalysisQuestion::with([
                'riskAnalysisQuestionAnswerOptions', 'questionCategory', 'questionLawSection',
                'riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                    return $que->where('location_id', $location_id);
                },
            ])
                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location_id) {
                    return $que->where('location_id', $location_id);
                })
                ->where('display_order', '<', $currentQuestion['display_order'])
                ->orderBy('display_order', 'desc')
                ->first();

            return $question;
        }

        return null;
    }

    /**
     * Remove Answer recursive
     */
    public function removeAnswerRecursive($question_id, $answer_id, $location_id)
    {
        $questions = RiskAnalysisQuestion::where([
            'parent_question_id' => $question_id,
            'parent_answer_id' => $answer_id,
        ])->get();
        if (count($questions) > 0) {
            foreach ($questions as $que) {
                $attempted_question = RiskAnalysisAttemptedQuestion::where(['question_id' => $que['id'], 'location_id' => $location_id])->first();
                RiskAnalysisAttemptedQuestion::where(['question_id' => $que['id'], 'location_id' => $location_id])->delete();
                if ($attempted_question) {
                    $question_id = $attempted_question['question_id'];
                    $location_id = $attempted_question['location_id'];
                    $attempted_question_answer = RiskAnalysisAttemptedQuestionAnswer::where('attempted_question_id', $attempted_question['id'])->get();
                    if ($attempted_question_answer) {
                        $attempted_question_answer->each(function ($ans) use ($question_id, $location_id) {
                            $ans_id = $ans['answer_id'];
                            $ans->delete();
                            $this->removeAnswerRecursive($question_id, $ans_id, $location_id);
                        });
                    }
                }
            }
        }
    }

    private function removeOngoingRecursive($question_id, $location_id)
    {
        $ongoing_question = OngoingRiskAnalysisQuestion::where([
            'question_id' => $question_id,
            'location_id' => $location_id,
        ]);
        if ($ongoing_question) {
            $ongoing_question->delete();
        }
        $question_list = RiskAnalysisQuestion::where('parent_question_id', $question_id)->get();
        foreach ($question_list as $que) {
            $this->removeOngoingRecursive($que['id'], $location_id);
        }
    }

    /**
     * get last updated scorecard for dashboard
     */
    public function getLastUpdatedScorecard($location_id)
    {
        $is_avail = LocationModuleLastUpdate::where(['location_id' => $location_id, 'module_name' => 'scorecard'])->first();

        return ($is_avail) ? $is_avail->updated_at : '';
    }

    /**
     * Get Question for demo account and continue is pressed
     */
    public function getContinueForDemoQuestion($location_id)
    {

        $question = RiskAnalysisQuestion::with([
            'riskAnalysisQuestionAnswerOptions', 'questionCategory', 'questionLawSection',
            'riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                return $que->where('location_id', $location_id);
            },
        ])
            ->where('question_code', 'Q74')
            // ->skip(4)
            // ->where('parent_question_id', null)
            // ->orderBy('display_order', 'desc')
            ->first();

        return $question;
    }

    public function getDynamicString($location_id, $question_code)
    {
        if ($question_code == 'Q75') {
            $questionQ75 = RiskAnalysisQuestion::with([
                'riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                    return $que->where('location_id', $location_id);
                },
            ])
                ->where('question_code', $question_code)
                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location_id) {
                    return $que->where('location_id', $location_id);
                })
                ->first();
            if ($questionQ75) {
                if ($questionQ75['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A33' || $questionQ75['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A35') {
                    return $questionQ75['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer'];
                } else {
                    $questionQ75S1 = RiskAnalysisQuestion::with([
                        'riskAnalysisAttemptedQuestion' => function ($que) use ($location_id) {
                            return $que->where('location_id', $location_id);
                        },
                    ])
                        ->where('question_code', 'Q75S1')
                        ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($location_id) {
                            return $que->where('location_id', $location_id);
                        })
                        ->first();
                    if ($questionQ75S1) {
                        return $questionQ75S1['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answer'];
                    } else {
                        return $questionQ75['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer'];
                    }
                }
            }
        }
    }

    // update Q77 if answer is no or don't know after complete sra
    private function updateQ77andQ77S1Answers($location_id)
    {
        $Q77NoAnswers = ['A2', 'A3'];
        $q77_answer = RiskAnalysisAttemptedQuestion::with(['attemptedQuestionAnswer.answerContent'])
            ->where('location_id', $location_id)
            ->whereHas('question', function ($query) {
                $query->where('question_code', 'Q77');
            })
            ->whereHas('attemptedQuestionAnswer.answerContent', function ($query) use ($Q77NoAnswers) {
                $query->whereIn('answer_code', $Q77NoAnswers);
            })->first();
        if ($q77_answer != null) {
            RiskAnalysisPreviousAttemptedQuestionAnswer::where([
                'question_id' => $q77_answer['question_id'],
                'location_id' => $q77_answer['location_id'],
            ])->delete();
            $perv_answer = [
                'question_id' => $q77_answer['question_id'],
                'location_id' => $q77_answer['location_id'],
                'answer_id' => $q77_answer['attemptedQuestionAnswer'][0]['answer_id'],
            ];
            RiskAnalysisPreviousAttemptedQuestionAnswer::create($perv_answer);

            RiskAnalysisAttemptedQuestionAnswer::where('attempted_question_id', $q77_answer['id'])->delete();
            $A1_answer_option = RiskAnalysisQuestionAnswerOption::with('remindOption')->where('answer_code', 'A1')->where('question_id', $q77_answer['question_id'])->first();
            $new_attempt_question_answer = [
                'attempted_question_id' => $q77_answer['id'],
                'answer_id' => $A1_answer_option['id'],
            ];
            RiskAnalysisAttemptedQuestionAnswer::create($new_attempt_question_answer);

            if (! empty($A1_answer_option['remindOption']) && ($A1_answer_option['remindOption']['ongoing_question_id'] != null && $A1_answer_option['remindOption']['remind_month'] != null)) {
                $current_date = gmdate('Y-m-d');
                $next_remind_date = gmdate('Y-m-d', strtotime('+'.$A1_answer_option['remindOption']['remind_month'].' month', strtotime($current_date)));
                $q77_answer->update(['next_remind_date' => $next_remind_date]);
            } elseif ($q77_answer['next_remind_date'] != null) {
                $q77_answer->update(['next_remind_date' => null]);
            }

            RiskAnalysisAttemptedQuestion::where('location_id', $location_id)
                ->whereHas('question', function ($query) {
                    $query->where('question_code', 'Q77S1');
                })->delete();
            $sub_question = RiskAnalysisQuestion::where('question_code', 'Q77S1')->first();
            $attempted_sub_question = RiskAnalysisAttemptedQuestion::create([
                'question_id' => $sub_question['id'],
                'location_id' => $location_id,
            ]);

            $answer_detail = RiskAnalysisQuestionAnswerOption::where('answer_code', 'A41')
                ->where('question_id', $sub_question['id'])
                ->with('remindOption')->first();
            $selected_answer[0]['answer_id'] = $answer_detail['id'];
            $attempted_sub_question->attemptedQuestionAnswer()->createMany($selected_answer);

            if (! empty($answer_detail['remindOption']) && ($answer_detail['remindOption']['ongoing_question_id'] != null && $answer_detail['remindOption']['remind_month'] != null)) {
                $current_date = gmdate('Y-m-d');
                $next_remind_date = gmdate('Y-m-d', strtotime('+'.$answer_detail['remindOption']['remind_month'].' month', strtotime($current_date)));
                $attempted_sub_question->update(['next_remind_date' => $next_remind_date]);
            } elseif ($attempted_sub_question['next_remind_date'] != null) {
                $attempted_sub_question->update(['next_remind_date' => null]);
            }
        }
    }
    /************************** */
    /*API methods - end
    /*************************** */
}
