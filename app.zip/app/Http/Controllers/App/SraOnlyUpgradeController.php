<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Models\LocationLimitPrice;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\GetLoginUserData;
use App\Traits\GetMainUserData;
use App\Traits\PricingHelper;
use App\Traits\SendMail;
use App\Traits\ChargebeePlan;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Exceptions\PaymentException;
use ChargeBee\ChargeBee\Models\Estimate;
use ChargeBee\ChargeBee\Models\Subscription;
use ChargeBee\ChargeBee\Models\Invoice;
use Stripe;

class SraOnlyUpgradeController extends Controller
{
    use ApiResponser, ApiResponser, CheckAccessRight, GetLoginUserData, GetMainUserData, PricingHelper, SendMail, ChargebeePlan;

    /**
     * Upgrade page
     *
     * @return \Illuminate\Http\Response
     */
    public function showUpgrade(Request $request)
    {
        $user_data = $this->getLoginUserData();
        if ($this->checkAccessRight('upgrade') && $user_data->is_sra_user == 1 && ($user_data->partner_reseller_id == null || ($user_data->partner_reseller_id != null && $user_data->is_admin_panel_login == 'true'))) {
            return view('app.pages.sra_only_upgrade');
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get user current plan information
     *
     * @return \Illuminate\Http\Response
     */
    public function getLocationInformation(Request $request)
    {
        $user_data = $this->getMainAccountDetails();
        $location_max_limit = LocationLimitPrice::max('limit');
        Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
        $subscription_response = Subscription::retrieve($user_data->chargebee_subscription_id);
        $subscription = $subscription_response->subscription();
        if ($subscription->billingPeriodUnit == "month") {
            $plan_type = "monthly";
            if ($subscription->billingPeriod == 3) {
                $plan_type = "quarterly";
            }
            if ($subscription->billingPeriod == 6) {
                $plan_type = "biannually";
            }
        } else {
            $plan_type = "yearly";
        }
        $location_limit = 0;
        foreach($subscription->subscriptionItems as $subscriptionItems){
            if($subscriptionItems->itemType == 'plan' && str_contains($subscriptionItems->itemPriceId, 'SRA-ONLY')){
                $location_limit = $subscriptionItems->quantity;
            }
        }
                        
        $data = [
            'user_current_location_limit' => $location_limit,
            'location_max_limit' => $location_max_limit,
            'chargebee_subscription' => ['plan_type' => $plan_type],
            'has_scheduled_changes' => $subscription->hasScheduledChanges,
            'subscription_status' => $subscription->status,
        ];

        return $this->success('', 200, $data);
    }
        /**
     * get chargebee price upgrade estimation for show information in upgrade page
     *
     * @return \Illuminate\Http\Response
     */
    public function getChargebeePriceUpgradeEstimation(Request $request)
    {

        try {
            $validator_rules = [
                'location_limit' => 'required',
                'plan_type' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $user_data = $this->getMainAccountDetails();
            Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
            $chargebee_plan_ids = $this->getChargebeePlanId($request->plan_type, $user_data->chargebe_addon_type,'sra_only');
            $estimation_array = array(
                "invoiceImmediately" => true,
                "subscription" => array(
                    "id" => $user_data->chargebee_subscription_id
                ),
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => $request->location_limit
                    ),
                ),
            );
            $estimate_response = Estimate::updateSubscriptionForItems($estimation_array);
            $estimate = $estimate_response->estimate();
            $taxes = '';
            $discount = '';
            $invoice_estimate = $estimate->invoiceEstimate;

            if (isset($invoice_estimate->taxes) && !empty($invoice_estimate->taxes)) {
                $taxes = [];
                foreach ($invoice_estimate->taxes as $key => $value) {
                    $taxes[] = array(
                        'percentage' => $value->description,
                        'amount' => $value->amount
                    );
                }
            }
            if (isset($invoice_estimate->discounts[0]) && !empty($invoice_estimate->discounts[0])) {
                $discount = array(
                    'id' => $invoice_estimate->discounts[0]->entityId,
                    'promocode' => $invoice_estimate->discounts[0]->description,
                    'discount_percentage' => (isset($invoice_estimate->discounts[0]->discountPercentage)) ? $invoice_estimate->discounts[0]->discountPercentage : '',
                    'discount_type' => $invoice_estimate->discounts[0]->discountType,
                    'discount_amount' => $invoice_estimate->discounts[0]->amount
                );
            }
            
            $final_response = array(
                'subscription_status' => $estimate->subscriptionEstimate->status,
                'total' => $invoice_estimate->amountDue,
                'taxes' => $taxes,
                'discounts' => $discount,
            );
            
            return $this->success(Config::get('constants.SUCCESS'), 200, $final_response);
        } catch (\Exception $e) {
            Log::error('SraOnlyUpgradeController/getChargebeePriceUpgradeEstimation() => ' . $e->getMessage());
            Log::error('SraOnlyUpgradeController/getChargebeePriceUpgradeEstimation()[data] => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    public function doUpgrade(Request $request)
      {
        $validator_rules = [
            'location_limit' => 'required',
            'location_limit_old' => 'required',
            'plan_type' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            DB::beginTransaction();
            $user_data = $this->getMainAccountDetails();
            Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
            $chargebee_plan_ids = $this->getChargebeePlanId($request->plan_type, $user_data->chargebe_addon_type,'sra_only');
            // previous invoice
            $previous_invoice_estimate_response = Estimate::renewalEstimate(
                $user_data->chargebee_subscription_id,
                array(
                    'ignoreScheduledCancellation' => true,
                    'ignoreScheduledChanges' => true,
                )
            );
            $previous_invoice_estimate = $previous_invoice_estimate_response->estimate();
            $prev_payment_price = $previous_invoice_estimate->invoiceEstimate->total / 100;
            $prev_charge_price = $prev_payment_price;
            $prev_payment_price = round($prev_payment_price, 2);
            $prev_sales_tax = [];
            if (isset($previous_invoice_estimate->invoiceEstimate->taxes) && !empty($previous_invoice_estimate->invoiceEstimate->taxes)) {
                foreach ($previous_invoice_estimate->invoiceEstimate->taxes as $key => $value) {
                    $prev_sales_tax[] = array(
                        'amount' => $value->amount / 100
                    );
                }
            }
            if (!empty($prev_sales_tax)) {
                $prev_payment_price = round($prev_payment_price - array_sum(array_column($prev_sales_tax, 'amount')), 2);
            }
            $prev_discount_price = 0;
            $final_promocode = '';
            if (isset($previous_invoice_estimate->invoiceEstimate->discounts[0]) && !empty($previous_invoice_estimate->invoiceEstimate->discounts[0])) {
                $prev_discount_price = $previous_invoice_estimate->invoiceEstimate->discounts[0]->amount / 100;
                $final_promocode = $previous_invoice_estimate->invoiceEstimate->discounts[0]->entityId;
            }
            if ($prev_discount_price > 0) {
                $prev_payment_price = round($prev_payment_price + $prev_discount_price, 2);
            }
            $subscription_array = array(
                "invoiceImmediately" => true,
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => $request->location_limit
                    ),
                )
            );
            $chargebee_subscription_response = Subscription::updateForItems($user_data->chargebee_subscription_id, $subscription_array);
            $chargebee_invoice_created = $chargebee_subscription_response->invoice();
            // next invoice
            $next_invoice_estimate_response = Estimate::renewalEstimate(
                $user_data->chargebee_subscription_id,
                array(
                    'ignoreScheduledCancellation' => true,
                    'ignoreScheduledChanges' => true,
                )
            );
            $next_invoice_estimate = $next_invoice_estimate_response->estimate();
            $next_payment_price = $next_invoice_estimate->invoiceEstimate->total / 100;
            $next_charge_price = $next_payment_price;
            $next_sales_tax = [];
            if (isset($next_invoice_estimate->invoiceEstimate->taxes) && !empty($next_invoice_estimate->invoiceEstimate->taxes)) {
                foreach ($next_invoice_estimate->invoiceEstimate->taxes as $key => $value) {
                    $next_sales_tax[] = array(
                        'amount' => $value->amount / 100
                    );
                }
            }
            if (!empty($next_sales_tax)) {
                $next_payment_price = round($next_payment_price - array_sum(array_column($next_sales_tax, 'amount')), 2);
            }
            $next_discount_price = 0;
            $final_promocode = '';
            if (isset($next_invoice_estimate->invoiceEstimate->discounts[0]) && !empty($next_invoice_estimate->invoiceEstimate->discounts[0])) {
                $next_discount_price = $next_invoice_estimate->invoiceEstimate->discounts[0]->amount / 100;
                $final_promocode = $next_invoice_estimate->invoiceEstimate->discounts[0]->entityId;
            }
            if ($next_discount_price > 0) {
                $next_payment_price = round($next_payment_price + $next_discount_price, 2);
            }
           

            $emailTemplate = EmailTemplate::where('code', 'HCE-UE23')->first();
            $email_dynamic_paragrah = '<p style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 14px;line-height: 1.6;margin-bottom: 10px;font-weight: normal;">New locations have been added to ' . $user_data->company_name . '\'s account! Please log in and name each location. Then assign any additional HIPAA Compliance Officers or users to help you manage the compliance program for these locations.</p>';

            $email_vars = [
                '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_data->first_name,
                '{%DYNAMIC_PARAGRAPH%}' => $email_dynamic_paragrah,
                '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
            ];
            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
            $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
            $this->sendEmail($emailTemplate->code, $html, $user_data->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
            if ($chargebee_invoice_created) {
                $charge_price = (($chargebee_invoice_created->status == 'payment_due') ? $chargebee_invoice_created->amountDue : $chargebee_invoice_created->amountPaid) / 100;
                $user_data['previous_employee_range'] = 0;
                $user_data['new_employee_range'] = 0;
                $emailTemplate = EmailTemplate::where('code', 'HCE-AE5')->first();
                $email_vars = [
                    '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_data->first_name,
                    '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user_data->last_name,
                    '{%COMPANY_NAME%}' => $user_data->company_name,
                    '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_data->email,
                    '{%PROMO_CODE%}' =>  $final_promocode,
                    '{%PREVIOUS_NUMBER_OF_LOCATIONS%}' => $request->location_limit_old,
                    '{%PREVIOUS_EMPLOYEE_RANGE%}' => $user_data['previous_employee_range'],
                    '{%PREVIOUS_PRICE%}' => $this->formatPrice($prev_payment_price),
                    '{%PREVIOUS_PROMO_DISCOUNT%}' => $this->formatPrice($prev_discount_price),
                    '{%PREVIOUS_DISCOUNT_PRICE%}' => $this->formatPrice(round($prev_payment_price - $prev_discount_price, 2)),
                    '{%PREVIOUS_SALES_TAX%}' => $this->formatPrice(array_sum(array_column($prev_sales_tax, 'amount'))),
                    '{%PREVIOUS_CHARGE_PRICE%}' => $this->formatPrice($prev_charge_price),
                    '{%NEW_NUMBER_OF_LOCATIONS%}' => $request->location_limit,
                    '{%NEW_EMPLOYEE_RANGE%}' => $user_data['new_employee_range'],
                    '{%NEW_PRICE%}' => $this->formatPrice($next_payment_price),
                    '{%NEW_PROMO_DISCOUNT%}' => $this->formatPrice($next_discount_price),
                    '{%NEW_DISCOUNT_PRICE%}' => $this->formatPrice(round($next_payment_price - $next_discount_price, 2)),
                    '{%NEW_TRANSACTION_FEE_AMOUNT%}' => 0,
                    '{%NEW_SALES_TAX%}' => $this->formatPrice(array_sum(array_column($next_sales_tax, 'amount'))),
                    '{%NEW_CHARGE_PRICE%}' => $this->formatPrice($next_charge_price),
                    '{%PAYMENT_TERM%}' => ($request->plan_type == 'biannually') ? 'Bi-Annually' : ucfirst($request->plan_type),
                    '{%PRORATED_CHARGE_PRICE%}' => $this->formatPrice($charge_price),
                    '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                ];
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                if ($user_data->partner_reseller_id != null) {
                    $admin_subject = str_ireplace('{%RESELLER%}', $user_data->reseller->name, $emailTemplate->reseller_subject);
                } else {
                    $admin_subject = $emailTemplate->subject;
                }
                $delayTime = Carbon::now()->addHours(24)->format('Y-m-d H:i:s');
                $this->sendEmail($emailTemplate->code, $html, [Config::get('app.finance_group_email'), Config::get('app.cs_group_email'), Config::get('app.salesadmin_group_email')], Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null), null, null, $delayTime);

                //send mail to partner start
                if ($user_data->partner_reseller_id != '' && $user_data->reseller->email != '') {
                    $attachment_invoice = null;
                    $chargebee_invoice_download = Invoice::pdf($chargebee_invoice_created->id, ['dispositionType' => 'attachment']);
                    $chargebee_invoice_pdf = $chargebee_invoice_download->download();
                    $attachment_invoice = storage_path('app/public'). '/generatedpolicydocuments/' . 'Abyde_Receipt_' . strtotime($user_data->created_at) . '.pdf';
                    file_put_contents($attachment_invoice, file_get_contents($chargebee_invoice_pdf->downloadUrl));
                    $this->sendEmail($emailTemplate->code, $html, $user_data->reseller->email, Config::get('app.from_admin_email'), $admin_subject, $attachment_invoice, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null), null, null, $delayTime);
                }
                //send mail to partner end
            }
            DB::commit();
            $sales_force_locations = Location::where('user_id', $user_data->id)->whereNotNull('salesforce_unique_id')->get();
            foreach($sales_force_locations as $location){
                SendLocationDataToSalesForce::dispatch($location->id);
            }

            return $this->success(Config::get('constants.USER.UPGRADE_SUCCESS'), 200);
        } catch (Stripe\Exception\CardException $e) {
            DB::rollback();
            Log::error('SraOnlyUpgradeController/doUpgrade() => ' . $e->getError()->message);
            Log::error('SraOnlyUpgradeController/doUpgrade()[data] => ' . json_encode($request->all()));
            return $this->error($e->getError()->message, 200);
        } catch (PaymentException $e) {
            DB::rollback();
            Log::error('UpgradeController/doUpgrade() => ' . $e->getMessage());
            Log::error('UpgradeController/doUpgrade()[data] => ' . json_encode($request->all()));
            preg_match('/Error message:\s*\(.*?\)\s*(.*)/', $e->getMessage(), $matches);
            $error = isset($matches[1]) ? trim($matches[1]) : $e->getMessage();
            return $this->error($error, 200);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('SraOnlyUpgradeController/doUpgrade() => ' . $e->getMessage());
            Log::error('SraOnlyUpgradeController/doUpgrade()[data] => ' . json_encode($request->all()));
            return $this->error(Config::get('constants.USER.UPGRADE_FAILED'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
