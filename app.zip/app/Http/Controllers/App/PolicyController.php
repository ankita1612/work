<?php

namespace App\Http\Controllers\App;

use App\Events\DownloadLogEvent;
use App\Http\Controllers\Controller;
use App\Models\AccessLog;
use App\Models\BusinessAssociates;
use App\Models\CoveredEntityPolicyAccess;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\ModuleCompletedStatus;
use App\Models\Policy;
use App\Models\PolicyVersioning;
use App\Models\RiskAnalysisQuestion;
use App\Models\User;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\FileUpload;
use App\Traits\GeneratePolicy;
use App\Traits\GetLoginUserData;
use App\Traits\GetMainUserData;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class PolicyController extends Controller
{
    use ApiResponser, CheckAccessRight, FileUpload, GeneratePolicy, GetLoginUserData, GetMainUserData;

    /**
     * Procedures Policies Forms page
     *
     * @return \Illuminate\Http\Response
     */
    public function showProceduresPoliciesForms(Request $request, $location_id = '')
    {
        if ($location_id != '') {
            $location_id = base64_decode($location_id, true);
            if ($location_id) {
                if ($this->checkAccessRight('procedures_policies_forms', $location_id)) {
                    $disaster_recovery_plan_completed = ModuleCompletedStatus::where(['location_id' => $location_id, 'module' => 'disaster_recovery_plan', 'is_completed' => 1])->first();
                    $company_info_completed = ModuleCompletedStatus::where(['location_id' => $location_id, 'module' => 'company_info', 'is_completed' => 1])->first();
                    $check_is_ra_completed = ModuleCompletedStatus::where(
                        [
                            'location_id' => $location_id,
                            'module' => 'risk_analysis',
                            'is_completed' => 1,
                        ]
                    )->first();
                    $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                    $location = Location::where('id', $location_id)
                        ->with(['employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation'])
                        ->first();
                    if ($disaster_recovery_plan_completed && $hco && $company_info_completed && $check_is_ra_completed && (count($location->employeePrimaryWorkLocation) > 0 || count($location->employeeSecondaryWorkLocation) > 0)) {
                        return view('app.pages.policy', ['location_id' => $location_id]);
                    } else {
                        return redirect('/dashboard');
                    }
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get all policy list
     *
     * @return \Illuminate\Http\Response
     */
    public function getPolicyList(Request $request)
    {
        try {
            $validator_rules = [
                'type' => 'required',
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $hco = HipaaComplianceOfficer::where('location_id', $request->location_id)->first();
            $location = Location::where('id', $request->location_id)
                ->with(['employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation'])
                ->first();
            $disaster_recovery_plan_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $request->location_id,
                    'module' => 'disaster_recovery_plan',
                    'is_completed' => 1,
                ]
            )->first();
            $company_info_completed = ModuleCompletedStatus::where(['location_id' => $request->location_id, 'module' => 'company_info', 'is_completed' => 1])->first();
            $check_is_ra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $request->location_id,
                    'module' => 'risk_analysis',
                    'is_completed' => 1,
                ]
            )->first();
            if ((count($location->employeePrimaryWorkLocation) == 0 && count($location->employeeSecondaryWorkLocation) == 0) || ! $disaster_recovery_plan_completed || ! $hco || ! $company_info_completed || ! $check_is_ra_completed) {
                return $this->error('Complete DRP first', 200);
            }
            $not_show_policy = [];
            if ($location->ce_type_id != null) {
                $not_show_policy = CoveredEntityPolicyAccess::whereNotIn('ce_type_id', [$location->ce_type_id])->get()->pluck('policy_id');
            } else {
                $not_show_policy = CoveredEntityPolicyAccess::get()->pluck('policy_id');
            }
            $list = Policy::with(['policyVersioning' => function ($que) use ($location) {
                $que->where('location_id', $location['id']);
            }])->select(['id', 'code', 'title', 'doc_description', 'doc_eye_description', 'doc_warning_description', DB::raw('IF(ISNULL(doc_spanish_file_name), false, true) AS has_spanish')]);
            $list = $list->where('type', $request['type']);
            if (count($not_show_policy) > 0) {
                $list = $list->whereNotIn('id', $not_show_policy);
            }
            if (isset($request['search_query']) && $request['search_query'] != '') {
                $list = $list->where('title', 'LIKE', '%' . $request['search_query'] . '%');
            }
            $list = $list->orderBy('title', 'ASC')->get()->toArray();

            foreach ($list as $key => $val) {
                if ($val['code'] == 'BACP') {
                    $ba_count = BusinessAssociates::whereHas('businessAssociatesLocation', function ($query) use ($location) {
                        $query->where('location_id', $location->id);
                    })->count();
                    if ($ba_count == 0) {
                        $list[$key]['is_disabled'] = true;
                    } else {
                        if (! $val['policy_versioning']) {
                            $ba = BusinessAssociates::where('user_id', $location->user_id)->first();
                            $list[$key]['module_complete_date'] = $ba->created_at;
                        }
                    }
                } elseif ($val['code'] == 'EDDP') {
                    $Q12_data = RiskAnalysisQuestion::where('question_code', 'Q12')
                        ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($request) {
                            $que->where(['location_id' => $request->location_id]);
                        })
                        ->with(
                            ['riskAnalysisAttemptedQuestion' => function ($que) use ($request) {
                                return $que->where('location_id', $request->location_id)
                                    ->with('attemptedQuestionAnswer.answerContent');
                            }]
                        )->first();
                    if ($Q12_data) {
                        if ($Q12_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A1') {
                            $list[$key]['is_disabled'] = true;
                        } else {
                            if (! $val['policy_versioning']) {
                                $list[$key]['module_complete_date'] = $Q12_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['created_at'];
                            }
                        }
                    }
                } elseif ($val['code'] == 'SAP') {
                    $Q1_data = RiskAnalysisQuestion::where('question_code', 'Q1')
                        ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($request) {
                            $que->where(['location_id' => $request->location_id]);
                        })
                        ->with(
                            ['riskAnalysisAttemptedQuestion' => function ($que) use ($request) {
                                return $que->where('location_id', $request->location_id)
                                    ->with('attemptedQuestionAnswer.answerContent');
                            }]
                        )->first();
                    if ($Q1_data) {
                        if ($Q1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A1') {
                            $list[$key]['is_disabled'] = true;
                        } else {
                            if (! $val['policy_versioning']) {
                                $list[$key]['module_complete_date'] = $Q1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['created_at'];
                            }
                        }
                    }
                    if ($request->has('source') && $request['source'] == 'employee_portal') {
                        $list[$key]['is_disabled'] = true;
                    }
                } elseif ($val['code'] == 'AL') {
                    $access_log_count = AccessLog::where('location_id', $request->location_id)->count();
                    if ($access_log_count <= 0) {
                        $list[$key]['is_disabled'] = true;
                    } else {
                        if (! $val['policy_versioning']) {
                            $al = AccessLog::where('location_id', $request->location_id)->first();
                            $list[$key]['module_complete_date'] = $al->created_at;
                        }
                    }
                } elseif ($val['code'] == 'MMPP') {
                    $Q64_data = RiskAnalysisQuestion::where('question_code', 'Q64')
                        ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($request) {
                            $que->where(['location_id' => $request->location_id]);
                        })
                        ->with(
                            ['riskAnalysisAttemptedQuestion' => function ($que) use ($request) {
                                return $que->where('location_id', $request->location_id)
                                    ->with('attemptedQuestionAnswer.answerContent');
                            }]
                        )->first();
                    if ($Q64_data) {
                        if ($Q64_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A1') {
                            $Q64S1_data = RiskAnalysisQuestion::where('question_code', 'Q64S1')
                                ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($request) {
                                    $que->where(['location_id' => $request->location_id]);
                                })
                                ->with(
                                    ['riskAnalysisAttemptedQuestion' => function ($que) use ($request) {
                                        return $que->where('location_id', $request->location_id)
                                            ->with('attemptedQuestionAnswer.answerContent');
                                    }]
                                )->first();
                            if ($Q64S1_data) {
                                if ($Q64S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A1' && $Q64S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A2') {
                                    $list[$key]['is_disabled'] = true;
                                } else {
                                    if (! $val['policy_versioning']) {
                                        $list[$key]['module_complete_date'] = $Q64S1_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['created_at'];
                                    }
                                }
                            } else {
                                $list[$key]['is_disabled'] = true;
                            }
                        } elseif ($Q64_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A2') {
                            $list[$key]['is_disabled'] = true;
                        } else {
                            if (! $val['policy_versioning']) {
                                $list[$key]['module_complete_date'] = $Q64_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['created_at'];
                            }
                        }
                    }
                } elseif ($val['code'] == 'CSPF') {
                    $Q51_data = RiskAnalysisQuestion::where('question_code', 'Q51')
                        ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($request) {
                            $que->where(['location_id' => $request->location_id]);
                        })
                        ->with(
                            ['riskAnalysisAttemptedQuestion' => function ($que) use ($request) {
                                return $que->where('location_id', $request->location_id)
                                    ->with('attemptedQuestionAnswer.answerContent');
                            }]
                        )->first();
                    if ($Q51_data) {
                        if ($Q51_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] != 'A1') {
                            $list[$key]['is_disabled'] = true;
                        } else {
                            if (! $val['policy_versioning']) {
                                $list[$key]['module_complete_date'] = $Q51_data['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['created_at'];
                            }
                        }
                    }
                }
            }

            $data = [
                'policy' => $list,
                'module_complete_date' => $disaster_recovery_plan_completed['created_at'],
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('PolicyController/getPolicyList() => ' . $e->getMessage());
            Log::error('PolicyController/getPolicyList()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * download policy pdf
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadPolicy(Request $request)
    {
        try {
            $validator_rules = [
                'policy_id' => 'required',
                'location_id' => 'required',
                'effective_date_text' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $lang = 'english';
            if (isset($request['lang']) && $request['lang'] == 'spanish') {
                $lang = 'spanish';
            }
            $policy_response = $this->generateDynamicPolicy($request->location_id, $request->policy_id, $lang, $request->effective_date_text);

            $user_data = $this->getMainAccountDetails();
            if (! empty($user_data)) {
                event(new DownloadLogEvent($user_data->id ?? '', $policy_response['file_name'] ?? '', $request->location_id));
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $policy_response);
        } catch (\Exception $e) {
            Log::error('PolicyController/downloadPolicy() => ' . $e->getMessage());
            Log::error('PolicyController/downloadPolicy()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    private function _addCompanyLogoOnCoverPage($location)
    {
        $public_path = public_path();
        $storage_path = storage_path('app/public');
        $temp_file_path = '';
        if ($location->logo != '') {
            $company_logo_image_s3 = Storage::disk('s3')->get('/company_logo/' . $location->user_id . '/' . $location->id . '/original/' . $location->logo);
            $temp_file_name_ext = pathinfo($location->logo, PATHINFO_EXTENSION);
            $temp_file_name = $location->id . '_' . time() . '.' . $temp_file_name_ext;
            $temp_file_path = $storage_path . '/generatedpolicydocuments/' . $temp_file_name;
            if ($company_logo_image_s3 != null) {
                \Image::make($company_logo_image_s3)->save($temp_file_path);
            }
        } else {
            $temp_file_path = $public_path . '/policydocuments/blank_company_logo.png';
        }
        // list($logo_width, $logo_height) = getimagesize($temp_file_path);
        // $maxWidth = ($logo_width >= 350)?400:350;
        // $maxHeight = 130;
        // $ratio = min($maxHeight / $logo_height, $maxWidth / $logo_width);
        // $newHeight = ceil($logo_height * $ratio);
        // $newWidth = ceil($logo_width * $ratio);
        // $ratio = $logo_width / $logo_height;
        // if (350/130 > $ratio) {
        //     $newWidth = 130*$ratio;
        //     $newHeight = 130;
        // } else {
        //     $newHeight = 350/$ratio;
        //     $newWidth = 350;
        // }
        $company_logo_data = [
            'path' => $temp_file_path,
            'width' => 350,
            'height' => 130,
            'ratio' => true,
        ];

        return ['company_logo_data' => $company_logo_data, 'temp_file_path' => $temp_file_path];
    }

    private function _removeTempCompanyLogo($location, $temp_file_path)
    {
        if ($location->logo != '') {
            if (file_exists($temp_file_path)) {
                unlink($temp_file_path);
            }
        }
    }

    /**
     * get last updated policy for dashboard
     */
    public function getLastUpdatedPolicy($location_id)
    {
        $is_avail = LocationModuleLastUpdate::where(['location_id' => $location_id, 'module_name' => 'policy'])->first();
        if ($is_avail) {
            return $is_avail->updated_at;
        } else {
            $disaster_recovery_plan_completed = ModuleCompletedStatus::where(['location_id' => $location_id, 'module' => 'disaster_recovery_plan', 'is_completed' => 1])->first();

            return ($disaster_recovery_plan_completed) ? $disaster_recovery_plan_completed['created_at'] : '';
        }
    }

    public function generateDynamicPolicy($location_id, $policy_id, $lang = 'english', $effective_date_text = '')
    {
        $location = Location::with('state')->findOrFail($location_id);
        $policy = Policy::findOrFail($policy_id);
        $user_data = User::findOrFail($location->user_id);

        $policy_doc_file_name = '';
        if ($user_data['is_educational_account'] == 1 && $policy->doc_educational_file_name != null) {
            $policy_doc_file_name = $policy->doc_educational_file_name;
        } elseif ($lang == 'spanish') {
            $policy_doc_file_name = $policy->doc_spanish_file_name;
        } else {
            $policy_doc_file_name = $policy->doc_file_name;
        }
        $file_name = explode('.', $policy_doc_file_name);
        if ($file_name[count($file_name) - 1] == 'pdf') {
            $gnerated_policy_pdf_url = config('app.url') . '/policydocuments/' . $policy_doc_file_name;

            return ['file_name' => $policy->title . '.pdf', 'download_url' => $gnerated_policy_pdf_url];
            exit;
        }

        $public_path = public_path();
        $storage_path = storage_path('app/public');
        $policy_filename = $policy_doc_file_name;
        $policy_file_path = $public_path . '/policydocuments/' . $policy_filename;
        $generated_policy_directory_path = $storage_path . '/generatedpolicydocuments/';
        $gnerated_policy_doc_name = $location->id . '_' . $policy_filename;
        $gnerated_policy_pdf_name = str_replace('docx', 'pdf', $gnerated_policy_doc_name);

        $gnerated_policy_file_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_policy_doc_name;
        $gnerated_policy_pdf_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_policy_pdf_name;
        $gnerated_policy_pdf_url = asset('storage/generatedpolicydocuments/' . $gnerated_policy_pdf_name);
        $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($policy_file_path);
        $template_processor->setValue('EFFECTIVE_DATE', $effective_date_text);
        if ($policy->type == 'form') {
            $this->_dynamicGenerationForm($policy, $location, false, $template_processor);
        }
        if ($policy->type == 'procedure') {
            $this->_dynamicGenerationProcedure($policy, $location, false, $template_processor);
        }
        if ($policy->type == 'policy') {
            $this->_dynamicGenerationPolicy($policy, $location, false, $user_data['is_educational_account'] == 1 ? true : false, $template_processor);
        }
        $template_processor->saveAs($gnerated_policy_file_path);
        if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
            // change libreoffice path as per installation path from your machine
            exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  ' . $generated_policy_directory_path . ' ' . $gnerated_policy_file_path);
        } else {
            exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir ' . $generated_policy_directory_path . ' ' . $gnerated_policy_file_path);
        }

        // header("Content-type:application/pdf");
        // header("Content-Disposition:attachment;filename=".str_replace("docx","pdf",$policy_filename));
        // readfile($gnerated_policy_pdf_path);
        return ['file_name' => $policy->title . '.pdf', 'download_url' => $gnerated_policy_pdf_url];
    }

    /**
     * generate NPP policy
     *
     * @return \Illuminate\Http\Response
     */
    public function generateNppPolicy($policy_name, $policy_id, $location_id, $lang = 'english')
    {
        try {

            if (! $policy_name || ! $policy_id || ! $location_id) {
                return view('app.pages.policylink', ['policy_data' => []]);
                exit;
            }

            $policy_data = [];

            if (base64_decode($location_id, true) && base64_decode($policy_id, true)) {
                $location_id = base64_decode($location_id, true);
                $location = Location::where('id', $location_id)->first();
                $policy_id = base64_decode($policy_id);
                $date = gmdate('m/d/Y');
                if ($lang == 'spanish') {
                    $effective_date = 'Accedido en ' . $date;
                } else {
                    $effective_date = 'Accessed on ' . $date;
                }
                $policy_data = $this->generateDynamicPolicy($location_id, $policy_id, $lang, $effective_date);
            }

            return view('app.pages.policylink', ['policy_data' => $policy_data, 'location' => $location]);
        } catch (\Exception $e) {
            Log::error('PolicyController/generateNppPolicy() => ' . $e->getMessage());
            Log::error('PolicyController/generateNppPolicy()[data] => ' . json_encode(['policy_name' => $policy_name, 'policy_id' => $policy_id, 'location_id' => $location_id, 'lang' => $lang]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * old hipaa generate NPP policy redirect
     */
    public function OldHIPAAgenerateNppPolicyRedirect($location_id, $lang = 'english')
    {
        try {
            if ($location_id) {
                $location_id = urldecode($location_id);
                $location_id = trim(base64_decode(base64_decode($location_id, true), true));
                $location = Location::where('old_hipaa_id', $location_id)->first();
                if ($location_id && $location) {
                    $policy = Policy::where('code', 'NPP')->first();
                    $url = Config::get('app.url') . '/policy-url/notice-privacy-practices/' . base64_encode($policy->id) . '/' . base64_encode($location->id);
                    if ($lang == 'spanish') {
                        $url .= '/spanish';
                    }

                    return redirect()->away($url);
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } catch (\Exception $e) {
            Log::error('PolicyController/OldHIPAAgenerateNppPolicyRedirect() => ' . $e->getMessage());
            Log::error('PolicyController/OldHIPAAgenerateNppPolicyRedirect()[data] => ' . json_encode(['location_id' => $location_id, 'lang' => $lang]));

            return redirect('/dashboard');
        }
    }

    /**
     * download policy pdf
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadPolicyVersioning(Request $request)
    {
        try {
            $validator_rules = [
                'policy_versioning_id' => 'required',
                'effective_date_text' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $lang = 'english';
            if (isset($request['lang']) && $request['lang'] == 'spanish') {
                $lang = 'spanish';
            }
            $policy_versioning = PolicyVersioning::findOrFail($request['policy_versioning_id']);
            $policy = Policy::findOrFail($policy_versioning->policy_id);
            if ($lang == 'spanish') {
                if ($policy_versioning['file_name_spanish'] != null) {
                    $policy_pdf_url = $this->getSignedURL('/generatedpolicydocuments/' . $policy_versioning->location_id . '/' . $policy_versioning->file_name_spanish);

                    return $this->success(Config::get('constants.SUCCESS'), 200, ['file_name' => $policy->title . '.pdf', 'download_url' => $policy_pdf_url]);
                }
            } else {
                if ($policy_versioning['file_name'] != null) {
                    $policy_pdf_url = $this->getSignedURL('/generatedpolicydocuments/' . $policy_versioning->location_id . '/' . $policy_versioning->file_name);

                    return $this->success(Config::get('constants.SUCCESS'), 200, ['file_name' => $policy->title . '.pdf', 'download_url' => $policy_pdf_url]);
                }
            }

            $version_data = json_decode($policy_versioning['version_data']);
            $location = Location::findOrFail($policy_versioning->location_id);
            $user_data = User::findOrFail($location->user_id);
            $public_path = public_path();
            $storage_path = storage_path('app/public');
            if ($user_data['is_educational_account'] == 1 && $policy_versioning->doc_educational_file_name != null) {
                $policy_filename = $policy_versioning->doc_educational_file_name;
            } elseif ($lang == 'spanish') {
                $policy_filename = $policy_versioning->doc_spanish_file_name;
            } else {
                $policy_filename = $policy_versioning->doc_file_name;
            }
            $policy_file_path = $public_path . '/policydocuments/' . $policy_filename;
            $generated_policy_directory_path = $storage_path . '/generatedpolicydocuments/';
            $create_date = $policy_versioning->created_at->format('Y-m-d');
            $gnerated_policy_doc_name = $policy_versioning->location_id . '_' . $create_date . '_' . $policy_filename;
            $gnerated_policy_pdf_name = str_replace('docx', 'pdf', $gnerated_policy_doc_name);

            $gnerated_policy_file_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_policy_doc_name;
            $gnerated_policy_pdf_path = $storage_path . '/generatedpolicydocuments/' . $gnerated_policy_pdf_name;
            $gnerated_policy_pdf_url = asset('storage/generatedpolicydocuments/' . $gnerated_policy_pdf_name);	
            $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($policy_file_path);
            $template_processor->setValue('EFFECTIVE_DATE', $request->effective_date_text);
            if ($policy->type == 'form') {
                $this->_dynamicGenerationFormVersioning($policy, $version_data, $location, $template_processor);
            }
            if ($policy->type == 'procedure') {
                $this->_dynamicGenerationProcedureVersioning($policy, $version_data, $location, $template_processor);
            }
            if ($policy->type == 'policy') {
                $this->_dynamicGenerationPolicyVersioning($policy, $version_data, $location, $template_processor);
            }
            $template_processor->saveAs($gnerated_policy_file_path);
            if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                // change libreoffice path as per installation path from your machine
                exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  ' . $generated_policy_directory_path . ' ' . $gnerated_policy_file_path);
            } else {
                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir ' . $generated_policy_directory_path . ' ' . $gnerated_policy_file_path);
            }
            if (file_exists($gnerated_policy_pdf_path)) {
                $file_contents = \File::get($gnerated_policy_pdf_path);
                Storage::disk('s3')->put('/generatedpolicydocuments/' . $location['id'] . '/' . $gnerated_policy_pdf_name, $file_contents, [
                    'ContentType' => 'application/octet-stream',
                    'ContentDisposition' => 'attachment; filename="' . $policy->title . '".pdf',
                ]);
                $update_data = [];
                if ($lang == 'spanish') {
                    $update_data['file_name_spanish'] = $gnerated_policy_pdf_name;
                } else {
                    $update_data['file_name'] = $gnerated_policy_pdf_name;
                }

                $policy_versioning->update($update_data);

                $policy_versioning = PolicyVersioning::findOrFail($request['policy_versioning_id']);
                if (($policy_versioning['doc_spanish_file_name'] == null && $policy_versioning['file_name'] != null) || ($policy_versioning['doc_spanish_file_name'] != null && $policy_versioning['file_name'] != null && $policy_versioning['file_name_spanish'] != null)) {
                    $policy_versioning->update([
                        'version_data' => null,
                    ]);
                }
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, ['file_name' => $policy->title . '.pdf', 'download_url' => $gnerated_policy_pdf_url]);
        } catch (\Exception $e) {
            Log::error('PolicyController/downloadPolicyVersioning() => ' . $e->getMessage());
            Log::error('PolicyController/downloadPolicyVersioning()[data] => ' . json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
