<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\AccountUser;
use App\Models\User;
use App\Models\Whatsnew;
use App\Traits\ApiResponser;
use App\Traits\FileUpload;
use App\Traits\GetLoginUserData;
use App\Traits\GetMainUserData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class WhatsnewController extends Controller
{
    use ApiResponser, FileUpload, GetLoginUserData, GetMainUserData;

    /**
     * Site Policy  page
     */
    public function showWhatsnew(Request $request, $whatsnew_id = '')
    {
        $whatsnew_id = base64_decode($whatsnew_id, true);

        return view('app.pages.whatsnew', ['whatsnew_id' => $whatsnew_id]);
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Whatsnew list with pagination, searching and sorting
     *
     * @return \Illuminate\Http\Response
     */
    public function list(Request $request)
    {
        try {
            //  user's state wise list is still need to apply as user functionality is not yet complete.
            $limit = $request->has('per_page') ? request('per_page') : Config::get('constants.PER_PAGE');
            $user_details = $this->getMainAccountDetails();
            $query = Whatsnew::whereHas('whatsnewState', function ($query) use ($user_details) {
                            $query->where('state_id', $user_details['state_id']);
                    })
                    ->orHas('whatsnewState', '=', 0)
                    ->orderBy('post_date', 'desc')
                    ->orderBy('id', 'desc');
            $list = $query->isActive()->paginate($limit);
            $list->getCollection()->transform(function ($value, $key) {
                if ($value->media) {
                    $value->media = $this->getSignedURL('whatsnew/'.$value->id.'/'.$value->media);
                }
                return $value;
            });
            $custom = collect(['seen_status' => auth()->user()->whatsnewSeenStatus]);
            $list = $custom->merge($list);

            return $this->success(Config::get('constants.WHATSNEW.LIST'), 200, $list);
        } catch (\Exception $e) {
            Log::error('WhatsnewController/list() => '.$e->getMessage());
            Log::error('WhatsnewController/list()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Get whatsnew detail
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function detail(Request $request)
    {
        try {
            $validator_rules = [
                'whatsnew_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $whatsnew = Whatsnew::find($request['whatsnew_id']);
            if ($whatsnew) {
                $whatsnew['media'] = $this->getSignedURL('whatsnew/'.$whatsnew['id'].'/'.$whatsnew['media']);

                return $this->success(Config::get('constants.WHATSNEW.DETAILS'), 200, $whatsnew);
            } else {
                return $this->error(Config::get('constants.NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('WhatsnewController/detail() => '.$e->getMessage());
            Log::error('WhatsnewController/detail()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Update last seen or not flag of user
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function addWhatsnewSeenFlag()
    {
        try {
            $user_data = $this->GetLoginUserData();
            $check_current_login = auth()->getDefaultDriver();
            if ($check_current_login == 'user') {
                $data = User::find($user_data->id)->whatsnewSeenStatus()->create([
                    'is_seen' => 1,
                ]);
            } elseif ($check_current_login == 'account_user') {
                $data = AccountUser::find($user_data->id)->whatsnewSeenStatus()->create([
                    'is_seen' => 1,
                ]);
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('WhatsnewController/addWhatsnewSeenFlag() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Get data that whats new is seen by the user or not
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function getWhatsnewSeenFlag()
    {
        try {
            $whatsnew_seen = auth()->user()->whatsnewSeenStatus;

            return $this->success(Config::get('constants.SUCCESS'), 200, $whatsnew_seen);
        } catch (\Exception $e) {
            Log::error('WhatsnewController/getWhatsnewSeenFlag() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
