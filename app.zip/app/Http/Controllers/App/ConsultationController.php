<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\Partner;
use App\Models\State;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\View\View;

class ConsultationController extends Controller
{
    use ApiResponser;

    /**
     * consultation select state page
     */
    public function showSelectState(Request $request, $partner = null)
    {
        return view('app.pages.consultation');
    }

    /**
     * scheduled page
     */
    public function showConsultationScheduled(Request $request)
    {
        return view('app.pages.consultationcheduled', ['request' => $request]);
    }

    /**
     * List all states
     *
     * @return \Illuminate\Http\Response
     */
    public function listStates(Request $request)
    {
        try {
            $list = State::select(['id', 'state_code', 'state_name'])
                ->with('calendlyLink')
                ->orderBy('state_name')
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('ConsultationController/listStates() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * hipaa challenge question
     *
     * @return \Illuminate\Http\Response
     */
    public function partnerInfo(Request $request)
    {
        try {
            $validator_rules = [
                'slug' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $partner = Partner::where('slug', $request['slug'])->first();

            return $this->success(Config::get('constants.SUCCESS'), 200, $partner);
        } catch (\Exception $e) {
            Log::error('GeneralController/partnerInfo() => '.$e->getMessage());
            Log::error('GeneralController/partnerInfo()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
}
