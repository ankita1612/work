<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Imports\EmployeeImport;
use App\Jobs\MoveEmployeeCertificateToAbydeDrive;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AbydeDriveArchiveFile;
use App\Models\AbydeDriveArchiveFolder;
use App\Models\AbydeDriveArchiveFolderLocation;
use App\Models\AccountUserLocationAccess;
use App\Models\DisasterCommunicationAuthority;
use App\Models\DisasterCommunicationEmployee;
use App\Models\DisasterCommunicationMedia;
use App\Models\DisasterCommunicationPartnerVendor;
use App\Models\DisasterCommunicationPatient;
use App\Models\DisasterRecoveryLead;
use App\Models\EmailTemplate;
use App\Models\Employee;
use App\Models\EmployeeAccessRight;
use App\Models\EmployeeAgreement;
use App\Models\EmployeeDeleteAccessUpdateTrack;
use App\Models\EmployeeSecondaryWorkLocation;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\ModuleCompletedStatus;
use App\Models\Training;
use App\Traits\ApiResponser;
use App\Traits\ChargebeePlan;
use App\Traits\CheckAccessRight;
use App\Traits\FileUpload;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use App\Traits\Notification;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\HeadingRowImport;

class EmployeeController extends Controller
{
    use ApiResponser, CheckAccessRight, FileUpload, GeneratePolicy, GetMainUserData, Notification, SendMail,ChargebeePlan;

    /**
     * Employee page
     *
     * @return \Illuminate\Http\Response
     */
    public function showEmployee()
    {
        if ($this->checkAccessRight('employee')) {
            $general_controller = new GeneralController;
            $accessible_location_list = $general_controller->getAssingedLocationList();
            $is_atleast_one_loc_hco = HipaaComplianceOfficer::whereIn('location_id', $accessible_location_list)->count();
            if ($is_atleast_one_loc_hco > 0) {
                return view('app.pages.employee');
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Add employee
     *
     * @return \Illuminate\Http\Response
     */
    public function addEmployee(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required|email|unique:App\Models\Employee,email,NULL,id,deleted_at,NULL',
                'phone_number' => 'required',
                'primary_work_location_id' => 'required',
                'location_list' => 'sometimes|array',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $total_employee_added = Employee::where('user_id', $user_data->id)->count();
            $subscription = $this->getSubscriptionDetails($user_data['chargebee_subscription_id']);
            $employee_limit = $subscription['employee_limit'];
            
            if ($total_employee_added == $employee_limit) {
                return $this->error(Config::get('constants.EMPLOYEE.EMPLOYEE_LIMIT_REACHED'), 200, ['reason' => 'employee_limit_reached']);
            } else {
                if ($total_employee_added === 0) {
                    $first_employee_added = true;
                } else {
                    $first_employee_added = false;
                }
            }
            DB::beginTransaction();
            $check_atleast_one_emp[$request->primary_work_location_id] = Employee::where('primary_work_location_id', $request->primary_work_location_id)
                ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($request) {
                    return $query->where('location_id', $request->primary_work_location_id);
                })->count();
            foreach ($request->location_list as $key => $value) {
                $check_atleast_one_emp[$value['location_id']] = Employee::where('primary_work_location_id', $value['location_id'])
                    ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($value) {
                        return $query->where('location_id', $value['location_id']);
                    })->count();
            }
            $input_fields = $request->all();

            // policy versioning code
            $policy_array = ['AAP', 'DRP', 'SAP'];
            foreach ($policy_array as $policy_code) {
                $this->addPolicyVersionData($policy_code, $input_fields['primary_work_location_id']);
                foreach ($input_fields['location_list'] as $secoundary_location) {
                    $this->addPolicyVersionData($policy_code, $secoundary_location['location_id']);
                }
            }

            $input_fields['user_id'] = $user_data['id'];
            $employee_created = Employee::create($input_fields);
            $total_employees = Employee::where('user_id', $user_data->id)->count();
            if (isset($input_fields['location_list']) && ! empty($input_fields['location_list'])) {
                $employee_created->employeeSecondaryWorkLocation()->createMany($input_fields['location_list']);
            }
            $training_controller = new TrainingController;

            //If it is first employee for location
            $check_is_ra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $input_fields['primary_work_location_id'],
                    'module' => 'risk_analysis',
                    'is_completed' => 1,
                ]
            )->first();
            $locationEmployee = Employee::where('primary_work_location_id', $input_fields['primary_work_location_id'])->isActive()->count();
            if ($locationEmployee == 1 && $check_is_ra_completed) {
                $training_controller->addTrainingLocations($input_fields['primary_work_location_id']);
            }
            //Add in unassigned Training
            $training_controller->addToUnassignedTraining($input_fields['primary_work_location_id'], $employee_created['id'], \App\Models\Employee::class);
            $hco = HipaaComplianceOfficer::where('location_id', $input_fields['primary_work_location_id'])->first();
            //Add in unassigned Training
            $training_controller->addToUnassignedTraining($input_fields['primary_work_location_id'], $hco->hco_id, $hco->hco_type);

            $notification_HCE_AN6 = $this->getNotificationByCode('HCE-AN6');
            $notification_HCE_AN12 = $this->getNotificationByCode('HCE-AN12');
            foreach ($check_atleast_one_emp as $loc_id => $emp_count) {
                try {
                    if ($emp_count == 0) {
                        $check_is_ra_completed = ModuleCompletedStatus::where(
                            [
                                'location_id' => $loc_id,
                                'module' => 'risk_analysis',
                                'is_completed' => 1,
                            ]
                        )->first();
                        $check_is_EMA_completed = ModuleCompletedStatus::where(
                            [
                                'location_id' => $loc_id,
                                'module' => 'disaster_recovery_plan',
                                'is_completed' => 1,
                            ]
                        )->first();
                        if ($check_is_ra_completed) {
                            // Notification HCE-AN12
                            if ($this->checkNotificationAlreadyAdded($notification_HCE_AN12->code, $loc_id) == 0) {
                                $notification_HCE_AN12_data = [
                                    'location_id' => $loc_id,
                                    'notification_id' => $notification_HCE_AN12['id'],
                                ];
                                $this->createNotification($notification_HCE_AN12_data);
                            }
                        }
                        if ($check_is_ra_completed && ! $check_is_EMA_completed) {
                            if ($this->checkNotificationAlreadyAdded($notification_HCE_AN6->code, $loc_id) == 0) {
                                $notification_HCE_AN6_data = [
                                    'location_id' => $loc_id,
                                    'notification_id' => $notification_HCE_AN6['id'],
                                ];
                                $this->createNotification($notification_HCE_AN6_data);
                                $loc_data = Location::findOrFail($loc_id);
                                $hco = HipaaComplianceOfficer::where('location_id', $loc_id)->with('hco')->first();
                            }
                        }
                    }
                } catch (\Exception $e) {
                    Log::error('EmployeeController/addEmployee()[check_atleast_one_emp_error] => '.$e->getMessage());
                    Log::error('EmployeeController/addEmployee()[check_atleast_one_emp_data] => '.json_encode([$loc_id, $emp_count]));
                }
            }
            $SF_location = Location::where('id', $input_fields['primary_work_location_id'])->whereNotNull('salesforce_unique_id')->first();
            if ($SF_location) {
                SendLocationDataToSalesForce::dispatch($SF_location->id);
            }
            if (isset($input_fields['location_list']) && ! empty($input_fields['location_list'])) {
                foreach ($input_fields['location_list'] as $secoundary_location) {
                    $SF_location = Location::where('id', $secoundary_location['location_id'])->whereNotNull('salesforce_unique_id')->first();
                    if ($SF_location) {
                        SendLocationDataToSalesForce::dispatch($SF_location->id);
                    }
                }
            }
            DB::commit();
            $data = [
                'employee_created' => $employee_created,
                'first_employee_added' => $first_employee_added,
                'total_employee_added' => $total_employees,
            ];

            return $this->success(Config::get('constants.EMPLOYEE.EMPLOYEE_ADDED'), 200, $data);
        } catch (\Exception $e) {
            Log::error('EmployeeController/addEmployee() => '.$e->getMessage());
            Log::error('EmployeeController/addEmployee()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Check unique email address in employee
     *
     * @return \Illuminate\Http\Response
     */
    public function checkUniqueEmail(Request $request, $email = '', $employee_id = '')
    {
        try {
            if ($email == '') {
                dd('Invalid parmas');
            }
            $employee = Employee::where('email', $request['email']);
            if ($employee_id != '') {
                $employee = $employee->where('id', '!=', $employee_id);
            }
            $employee = $employee->count();
            if ($employee > 0) {
                return 'available';
            } else {
                return 'not_available';
            }
        } catch (\Exception $e) {
            Log::error('EmployeeController/checkUniqueEmail() => '.$e->getMessage());
            Log::error('EmployeeController/checkUniqueEmail()[request] => '.json_encode([$request]));
            Log::error('EmployeeController/checkUniqueEmail()[data] => '.json_encode([$email, $employee_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get employee list
     *
     * @return \Illuminate\Http\Response
     */
    public function allEmployeeList(Request $request)
    {
        try {
            $validator_rules = [
                'sort_by' => 'sometimes|nullable|in:first_name,last_name,email,phone_number',
                'sort_by_dir' => 'sometimes|nullable|in:ASC,DESC',
                'filter_by_location' => 'sometimes|nullable|array',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $limit = $request->has('per_page') ? request('per_page') : Config::get('constants.PER_PAGE');
            $user_data = $this->getMainAccountDetails();
            $generalController = new GeneralController;
            $location_access_list = $generalController->getAssingedLocationList();

            $employee = Employee::where('user_id', $user_data['id'])
                ->with(['employeeSecondaryWorkLocation', 'employeeSecondaryWorkLocation.location' => function ($q) {
                    $q->select(['id', 'location_nickname', 'company_name']);
                }, 'employeePrimaryWorkLocation' => function ($q) {
                    $q->select(['id', 'location_nickname', 'company_name']);
                }, 'employeeAgreement'])->withCount(['employeeAccessRights']);

            $employee = $employee->where(function ($subquery) use ($location_access_list) {
                $subquery->whereHas('employeeSecondaryWorkLocation', function ($que) use ($location_access_list) {
                    $que->whereIn('location_id', $location_access_list);
                })
                    ->orWhereIn('primary_work_location_id', $location_access_list);
            });

            $input_fields = $request->all();
            if (isset($input_fields['search_query']) && $input_fields['search_query'] != '') {
                $employee = $employee->where(function ($que) use ($input_fields) {
                    return $que->whereRaw('concat(first_name, " ", last_name) like "%'.$input_fields['search_query'].'%" ')
                        ->orWhereRaw('concat(last_name, " ", first_name) like "%'.$input_fields['search_query'].'%" ')
                        ->orWhere('email', 'LIKE', '%'.$input_fields['search_query'].'%')
                        ->orWhere('phone_number', 'LIKE', '%'.$input_fields['search_query'].'%');
                });
            }
            if (isset($input_fields['filter_by_location']) && ! empty($input_fields['filter_by_location'])) {
                $employee = $employee->where(function ($subquery) use ($input_fields) {
                    $subquery->whereHas('employeeSecondaryWorkLocation', function ($que) use ($input_fields) {
                        $que->whereIn('location_id', $input_fields['filter_by_location']);
                    })->orWhereHas('employeePrimaryWorkLocation', function ($que) use ($input_fields) {
                        $que->whereIn('id', $input_fields['filter_by_location']);
                    });
                });
            }
            if (isset($input_fields['sort_by']) && ! empty($input_fields['sort_by']) && isset($input_fields['sort_by_dir']) && ! empty($input_fields['sort_by_dir'])) {
                $employee = $employee->orderBy($input_fields['sort_by'], $input_fields['sort_by_dir']);
                $employee = $employee->orderBy('id', $input_fields['sort_by_dir']);
            }
            else {
                $employee = $employee->orderBy('id', 'DESC');
            }
            $employee = $employee->paginate($limit);

            $employee->getCollection()->transform(function ($emp, $key) {
                if ($emp->employeeAgreement) {
                    $expire_time = Config::get('app.expire_time');
                    $employeeAgreement = $emp->employeeAgreement;
                    $employeeAgreement->file_name = Storage::disk('s3')->temporaryUrl(
                        'generatedpolicydocuments/employeeagreement/'.$employeeAgreement->file_name,
                        now()->addSeconds($expire_time),
                        [
                            'ResponseContentType' => 'application/octet-stream',
                            'ResponseContentDisposition' => 'attachment',
                        ]
                    );
                    $emp->employeeAgreement = $employeeAgreement;
                }

                return $emp;
            });

            $location_list_count = Location::where('user_id', $user_data['id'])
                ->select(['id', 'location_nickname'])
                ->whereHas('hipaaComplianceOfficer')
                ->whereIn('id', $location_access_list)
                ->count();
            $data = [
                'employee_list' => $employee,
                'sample_import_file_link' => ($location_list_count == 1) ? url('/sample_docs/employee_template_std.xlsx') : url('/sample_docs/employee_template_ent.xlsx'),
            ];

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('EmployeeController/allEmployeeList() => '.$e->getMessage());
            Log::error('EmployeeController/allEmployeeList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * delete employee
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteEmployee(Request $request)
    {
        try {
            $validator_rules = [
                'employee_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $employee = Employee::with(['employeeAgreement', 'employeeSecondaryWorkLocation'])->findOrFail($request['employee_id']);
            // policy versioning code
            $policy_array = ['AAP', 'DRP', 'SAP'];
            foreach ($policy_array as $policy_code) {
                $this->addPolicyVersionData($policy_code, $employee['primary_work_location_id']);
                foreach ($employee['employeeSecondaryWorkLocation'] as $secoundary_location) {
                    $this->addPolicyVersionData($policy_code, $secoundary_location['location_id']);
                }
            }
            if ($employee->employeeAgreement != null && $employee->employeeAgreement->file_name != null) {
                $old_file = '/generatedpolicydocuments/employeeagreement/'.$employee->employeeAgreement->file_name;
                $file_size = $this->getReadableFilesize(Storage::disk('s3')->size('/generatedpolicydocuments/employeeagreement/'.$employee->employeeAgreement->file_name));

                $employee_first_name = str_replace(' ', '_', trim($employee->first_name));
                $employee_first_name = preg_replace('/[^A-Za-z0-9\-\_]/', '', $employee_first_name);
                $employee_last_name = str_replace(' ', '_', trim($employee->last_name));
                $employee_last_name = preg_replace('/[^A-Za-z0-9\-\_]/', '', $employee_last_name);

                $file_extenstion = substr(strrchr($employee->employeeAgreement->file_name, '.'), 1);
                $new_file_name_without_ext = $employee->id.'_'.$employee_first_name.'_'.$employee_last_name.'_'.'agreement';
                $new_file_name = $new_file_name_without_ext.'.'.$file_extenstion;
                $new_file = '/abyde_drive_archive/employees/'.$employee->user_id.'/'.$new_file_name;
                $title = $new_file_name_without_ext;
                if (Storage::disk('s3')->copy($old_file, $new_file)) {
                    $abyde_drive_folder = AbydeDriveArchiveFolder::where('folder_name', 'Employees')->first();

                    $emp_name_folder = AbydeDriveArchiveFolder::create([
                        'folder_name' => $employee_first_name.'_'.$employee_last_name.'_'.$employee->id,
                        'parent_folder_id' => $abyde_drive_folder->id,
                    ]);

                    $agreement_folder = AbydeDriveArchiveFolder::create([
                        'folder_name' => 'Agreement',
                        'parent_folder_id' => $emp_name_folder->id,
                    ]);

                    $emp_name_folder_location = AbydeDriveArchiveFolderLocation::create([
                        'archive_folder_id' => $emp_name_folder->id,
                        'location_id' => $employee->primary_work_location_id,
                    ]);

                    $agreement_folder_location = AbydeDriveArchiveFolderLocation::create([
                        'archive_folder_id' => $agreement_folder->id,
                        'location_id' => $employee->primary_work_location_id,
                    ]);

                    $file_data = [
                        'file_name' => $new_file_name,
                        'title' => $title,
                        'archive_folder_id' => $agreement_folder_location->id,
                        'file_size' => $file_size,
                    ];
                    AbydeDriveArchiveFile::create($file_data);

                    $abyde_drive_archive_file_data = [];
                    foreach ($employee->employeeSecondaryWorkLocation as $location) {
                        try {
                            $emp_name_folder_location_sec = AbydeDriveArchiveFolderLocation::create([
                                'archive_folder_id' => $emp_name_folder->id,
                                'location_id' => $location->location_id,
                            ]);

                            $agreement_folder_location_sec = AbydeDriveArchiveFolderLocation::create([
                                'archive_folder_id' => $agreement_folder->id,
                                'location_id' => $location->location_id,
                            ]);

                            $abyde_drive_archive_file_data[] = [
                                'file_name' => $new_file_name,
                                'title' => $title,
                                'archive_folder_id' => $agreement_folder_location_sec->id,
                                'file_size' => $file_size,
                                'created_at' => Carbon::now(),
                                'updated_at' => Carbon::now(),
                            ];
                        } catch (\Exception $e) {
                            DB::rollback();
                            Log::error('EmployeeController/deleteEmployee()[employeeSecondaryWorkLocation_error] => '.$e->getMessage());
                            Log::error('EmployeeController/deleteEmployee()[employeeSecondaryWorkLocation_data] => '.json_encode($location));
                        }
                    }
                    AbydeDriveArchiveFile::insert($abyde_drive_archive_file_data);
                }
            }
            $employee_move_certi = Employee::with(['employeeSecondaryWorkLocation', 'trainingInvites.training'])
                ->findOrFail($request['employee_id'])->toArray();
            MoveEmployeeCertificateToAbydeDrive::dispatch($employee_move_certi);
            $SF_location = Location::where('id', $employee['primary_work_location_id'])->whereNotNull('salesforce_unique_id')->first();
            if ($SF_location) {
                SendLocationDataToSalesForce::dispatch($SF_location->id);
            }
            if (count($employee->employeeSecondaryWorkLocation) > 0) {
                foreach ($employee->employeeSecondaryWorkLocation as $secoundary_location) {
                    $SF_location = Location::where('id', $secoundary_location['location_id'])->whereNotNull('salesforce_unique_id')->first();
                    if ($SF_location) {
                        SendLocationDataToSalesForce::dispatch($SF_location->id);
                    }
                }
            }
            $employee->delete();
            DB::commit();

            return $this->success(Config::get('constants.EMPLOYEE.EMPLOYEE_DELETED'), 200);
        } catch (\Exception $e) {
            Log::error('EmployeeController/deleteEmployee() => '.$e->getMessage());
            Log::error('EmployeeController/deleteEmployee()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * update employee access reminder flag
     *
     * @return \Illuminate\Http\Response
     */
    public function updateEmployeeAccessReminderFlag(Request $request)
    {
        try {
            $validator_rules = [
                'employee_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $add_access_update_reminder = EmployeeDeleteAccessUpdateTrack::create([
                'employee_id' => $request->employee_id,
                'email_notification_sent' => 0,
            ]);
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200);
        } catch (\Exception $e) {
            Log::error('EmployeeController/updateEmployeeAccessReminderFlag() => '.$e->getMessage());
            Log::error('EmployeeController/updateEmployeeAccessReminderFlag()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Edit employee
     *
     * @return \Illuminate\Http\Response
     */
    public function editEmployee(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'employee_id' => 'required',
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required|email|unique:App\Models\Employee,email,'.$request->employee_id.',id,deleted_at,NULL',
                'phone_number' => 'required',
                'primary_work_location_id' => 'required',
                'location_work_new' => 'sometimes|array',
                'location_work_removed' => 'sometimes|array',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $check_atleast_one_emp[$request->primary_work_location_id] = Employee::where('primary_work_location_id', $request->primary_work_location_id)
                ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($request) {
                    return $query->where('location_id', $request->primary_work_location_id);
                })->count();
            foreach ($request->location_work_new as $key => $value) {
                $check_atleast_one_emp[$value['location_id']] = Employee::where('primary_work_location_id', $value['location_id'])
                    ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($value) {
                        return $query->where('location_id', $value['location_id']);
                    })->count();
            }
            $input_fields = $request->all();
            $employee = Employee::with(['employeeSecondaryWorkLocation', 'disasterCommunicationAuthority', 'disasterCommunicationEmployee', 'disasterCommunicationMedia', 'disasterCommunicationPatient', 'disasterCommunicationPartnerVendor', 'disasterRecoveryLead'])->findOrFail($input_fields['employee_id']);
            $old_emp_id = $employee->primary_work_location_id;
            $removed_location_temp_array = [];

            $policy_array = ['AAP', 'DRP', 'SAP'];

            if ($employee['primary_work_location_id'] != $input_fields['primary_work_location_id']) {

                $has_old_in_new_location = in_array($employee['primary_work_location_id'], array_column($request['location_work_new'], 'location_id'));
                if (! $has_old_in_new_location) {
                    foreach ($policy_array as $policy_code) {
                        $this->addPolicyVersionData($policy_code, $employee['primary_work_location_id']);
                    }
                    $SF_location = Location::where('id', $employee['primary_work_location_id'])->whereNotNull('salesforce_unique_id')->first();
                    if ($SF_location) {
                        SendLocationDataToSalesForce::dispatch($SF_location->id);
                    }
                }

                $has_new_in_removed_location = in_array($input_fields['primary_work_location_id'], array_column($request['location_work_removed'], 'location_id'));
                if (! $has_new_in_removed_location) {
                    foreach ($policy_array as $policy_code) {
                        $this->addPolicyVersionData($policy_code, $input_fields['primary_work_location_id']);
                    }
                    $SF_location = Location::where('id', $input_fields['primary_work_location_id'])->whereNotNull('salesforce_unique_id')->first();
                    if ($SF_location) {
                        SendLocationDataToSalesForce::dispatch($SF_location->id);
                    }
                }
            }

            if ($request->has('location_work_removed')) {
                foreach ($request['location_work_removed'] as $removed_location) {
                    foreach ($policy_array as $policy_code) {
                        if ($removed_location['location_id'] != $input_fields['primary_work_location_id']) {
                            $this->addPolicyVersionData($policy_code, $removed_location['location_id']);
                        }
                    }
                    $SF_location = Location::where('id', $removed_location['location_id'])->whereNotNull('salesforce_unique_id')->first();
                    if ($SF_location) {
                        SendLocationDataToSalesForce::dispatch($SF_location->id);
                    }
                }
            }

            if ($request->has('location_work_new')) {
                foreach ($input_fields['location_work_new'] as $new_work_location) {
                    foreach ($policy_array as $policy_code) {
                        if ($new_work_location['location_id'] != $employee['primary_work_location_id']) {
                            $this->addPolicyVersionData($policy_code, $new_work_location['location_id']);
                        }
                    }
                    $SF_location = Location::where('id', $new_work_location['location_id'])->whereNotNull('salesforce_unique_id')->first();
                    if ($SF_location) {
                        SendLocationDataToSalesForce::dispatch($SF_location->id);
                    }
                }
            }
            if ($employee['first_name'] !== $input_fields['first_name'] || $employee['last_name'] !== $input_fields['last_name']) {

                foreach ($policy_array as $policy_code) {
                    $this->addPolicyVersionData($policy_code, $employee['primary_work_location_id']);
                    foreach ($employee['employeeSecondaryWorkLocation'] as $secoundary_location) {
                        $this->addPolicyVersionData($policy_code, $secoundary_location['location_id']);
                    }

                    foreach ($employee->disasterCommunicationAuthority as $disasterCommunicationAuthority) {
                        $this->addPolicyVersionData('DRP', $disasterCommunicationAuthority['location_id']);
                    }
                    foreach ($employee->disasterCommunicationEmployee as $disasterCommunicationEmployee) {
                        $this->addPolicyVersionData('DRP', $disasterCommunicationEmployee['location_id']);
                    }
                    foreach ($employee->disasterCommunicationMedia as $disasterCommunicationMedia) {
                        $this->addPolicyVersionData('DRP', $disasterCommunicationMedia['location_id']);
                    }
                    foreach ($employee->disasterCommunicationPatient as $disasterCommunicationPatient) {
                        $this->addPolicyVersionData('DRP', $disasterCommunicationPatient['location_id']);
                    }
                    foreach ($employee->disasterCommunicationPartnerVendor as $disasterCommunicationPartnerVendor) {
                        $this->addPolicyVersionData('DRP', $disasterCommunicationPartnerVendor['location_id']);
                    }
                    foreach ($employee->disasterRecoveryLead as $disasterRecoveryLead) {
                        $this->addPolicyVersionData('DRP', $disasterRecoveryLead['location_id']);
                    }

                }
            }
            if ($employee['phone_number'] !== $input_fields['phone_number'] || $employee['email'] !== $input_fields['email']) {
                $this->addPolicyVersionData('DRP', $employee['primary_work_location_id']);
                foreach ($employee['employeeSecondaryWorkLocation'] as $secoundary_location) {
                    $this->addPolicyVersionData('DRP', $secoundary_location['location_id']);
                }
            }
            if ($request->has('location_work_removed')) {
                $removed_location_temp_array = $request['location_work_removed'];
            }

            if ($employee->primary_work_location_id != $request['primary_work_location_id']) {
                $removed_location_temp_array[] = ['location_id' => $employee->primary_work_location_id];
                $employee_swipe = false;
                foreach ($input_fields['location_work_new'] as $location_work_new) {
                    if ($location_work_new['location_id'] == $employee->primary_work_location_id) {
                        $employee_swipe = true;
                    }
                }
                if ($employee_swipe == false) {
                    $employee->employeeAccessRights()->where('location_id', $employee->primary_work_location_id)->delete();
                }
            }
            if (! empty($removed_location_temp_array)) {
                $has_employee_communication_authority = DisasterCommunicationAuthority::where('employee_id', $request['employee_id'])->whereIn('location_id', $removed_location_temp_array)->get()->each(function ($esc) {
                    $esc->delete();
                });
                $has_communication_employee = DisasterCommunicationEmployee::where('employee_id', $request['employee_id'])->whereIn('location_id', $removed_location_temp_array)->get()->each(function ($ec) {
                    $ec->delete();
                });
                $has_employee_communication_media = DisasterCommunicationMedia::where('employee_id', $request['employee_id'])->whereIn('location_id', $removed_location_temp_array)->get()->each(function ($em) {
                    $em->delete();
                });
                $has_employee_communication_patient = DisasterCommunicationPatient::where('employee_id', $request['employee_id'])->whereIn('location_id', $removed_location_temp_array)->get()->each(function ($er) {
                    $er->delete();
                });
                $has_employee_communication_partner_vendor = DisasterCommunicationPartnerVendor::where('employee_id', $request['employee_id'])->whereIn('location_id', $removed_location_temp_array)->get()->each(function ($emr) {
                    $emr->delete();
                });
                $has_employee_recovery_list = DisasterRecoveryLead::where('employee_id', $request['employee_id'])->whereIn('location_id', $removed_location_temp_array)->get()->each(function ($elo) {
                    $elo->delete();
                });
            }
            if ($employee->update($input_fields)) {
                if ($request->has('location_work_removed')) {
                    EmployeeSecondaryWorkLocation::whereIn('location_id', $input_fields['location_work_removed'])
                        ->where('employee_id', $input_fields['employee_id'])->get()->each(function ($esw) {
                            $esw->delete();
                        });
                    $employee_access_rights = EmployeeAccessRight::whereIn('location_id', $input_fields['location_work_removed'])->get();
                    foreach ($employee_access_rights as $employee_access_right) {
                        if ($employee->primary_work_location_id != $employee_access_right->location_id) {
                            EmployeeAccessRight::find($employee_access_right->id)->delete();
                        }
                    }
                }
                if ($request->has('location_work_new')) {
                    $employee->employeeSecondaryWorkLocation()->createMany($input_fields['location_work_new']);
                }
                $check_is_ra_completed = ModuleCompletedStatus::where(
                    [
                        'location_id' => $input_fields['primary_work_location_id'],
                        'module' => 'risk_analysis',
                        'is_completed' => 1,
                    ]
                )->first();
                if ($old_emp_id != $request['primary_work_location_id']) {
                    $training_controller = new TrainingController;
                    $training_controller->moveTrainingToArchive($old_emp_id);
                    //If it is first employee for location
                    $locationEmployee = Employee::where('primary_work_location_id', $request['primary_work_location_id'])->count();
                    if ($locationEmployee == 1 && $check_is_ra_completed) {
                        $training_controller->addTrainingLocations($request['primary_work_location_id']);
                    }

                    //Add in unassigned Training
                    $training_controller->addToUnassignedTraining($input_fields['primary_work_location_id'], $request['employee_id'], \App\Models\Employee::class);
                    $hco = HipaaComplianceOfficer::where('location_id', $request['primary_work_location_id'])->first();
                    $training_controller->addToUnassignedTraining($input_fields['primary_work_location_id'], $hco->hco_id, $hco->hco_type);
                }
                $notification_HCE_AN12 = $this->getNotificationByCode('HCE-AN12');
                $notification_HCE_AN6 = $this->getNotificationByCode('HCE-AN6');
                foreach ($check_atleast_one_emp as $loc_id => $emp_count) {
                    try {
                        if ($emp_count == 0) {
                            $check_is_EMA_completed = ModuleCompletedStatus::where(
                                [
                                    'location_id' => $loc_id,
                                    'module' => 'disaster_recovery_plan',
                                    'is_completed' => 1,
                                ]
                            )->first();
                            $check_is_ra_completed = ModuleCompletedStatus::where(
                                [
                                    'location_id' => $loc_id,
                                    'module' => 'risk_analysis',
                                    'is_completed' => 1,
                                ]
                            )->first();
                            if ($check_is_ra_completed) {
                                // Notification HCE-AN12
                                if ($this->checkNotificationAlreadyAdded($notification_HCE_AN12->code, $loc_id) == 0) {
                                    $notification_HCE_AN12_data = [
                                        'location_id' => $loc_id,
                                        'notification_id' => $notification_HCE_AN12['id'],
                                    ];
                                    $this->createNotification($notification_HCE_AN12_data);
                                }
                            }
                            if ($check_is_ra_completed && ! $check_is_EMA_completed) {
                                // Notification HCE-AN6
                                if ($this->checkNotificationAlreadyAdded($notification_HCE_AN6->code, $loc_id) == 0) {
                                    $notification_HCE_AN6_data = [
                                        'location_id' => $loc_id,
                                        'notification_id' => $notification_HCE_AN6['id'],
                                    ];
                                    $this->createNotification($notification_HCE_AN6_data);
                                }
                            }
                        }
                    } catch (\Exception $e) {
                        Log::error('EmployeeController/editEmployee()[check_atleast_one_emp_error] => '.$e->getMessage());
                        Log::error('EmployeeController/editEmployee()[check_atleast_one_emp_data] => '.json_encode([$loc_id, $emp_count]));
                    }
                }
            }

            $employee = Employee::where('id', $input_fields['employee_id'])
                ->with(['employeeSecondaryWorkLocation', 'employeeSecondaryWorkLocation.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }, 'employeePrimaryWorkLocation' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }, 'employeeAgreement'])->withCount(['employeeAccessRights'])->first();
            if ($employee->employeeAgreement) {
                $expire_time = Config::get('app.expire_time');
                $employeeAgreement = $employee->employeeAgreement;
                $employeeAgreement->file_name = Storage::disk('s3')->temporaryUrl(
                    'generatedpolicydocuments/employeeagreement/'.$employeeAgreement->file_name,
                    now()->addSeconds($expire_time),
                    [
                        'ResponseContentType' => 'application/octet-stream',
                        'ResponseContentDisposition' => 'attachment',
                    ]
                );
                $employee->employeeAgreement = $employeeAgreement;
            }
            DB::commit();

            return $this->success(Config::get('constants.EMPLOYEE.EMPLOYEE_EDITED'), 200, $employee);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('EmployeeController/editEmployee() => '.$e->getMessage());
            Log::error('EmployeeController/editEmployee()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Send agreement email
     *
     * @return \Illuminate\Http\Response
     */
    public function sendAgreementEmail(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'employee_id' => 'required',
                'is_send_to_all_employee' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $employee_list = Employee::where('user_id', $user_data['id'])->where('status', 'active');
            if (! $request->is_send_to_all_employee) {
                $employee_list = $employee_list->where('id', $request->employee_id);
            } else {
                $general_controller = new GeneralController;
                $location_access_list = $general_controller->getAssingedLocationList();
                $employee_list = $employee_list->where(function ($subquery) use ($location_access_list) {
                    $subquery->whereHas('employeeSecondaryWorkLocation', function ($que) use ($location_access_list) {
                        $que->whereIn('location_id', $location_access_list);
                    })
                        ->orWhereIn('primary_work_location_id', $location_access_list);
                });
            }
            $employee_list = $employee_list->with('employeePrimaryWorkLocation')->get();

            $emailTemplate_HCE_UE8 = EmailTemplate::where('code', 'HCE-UE8')->first();
            foreach ($employee_list as $employee) {
                try {
                    $ref_token = \Str::random(10);
                    $employee_agreement_count = EmployeeAgreement::where('employee_id', $employee->id)->count();
                    if ($employee_agreement_count == 0) {
                        if (EmployeeAgreement::create([
                            'employee_id' => $employee->id,
                            'agreement_type' => 'system',
                            'reference_token' => $ref_token,
                        ])) {
                            $hco = HipaaComplianceOfficer::where('location_id', $employee->primary_work_location_id)->with('hco')->first();
                            // Send HCE-UE8
                            $email_vars = [
                                '{%EMPLOYEE_FIRST_NAME%}' => $employee->first_name,
                                '{%VIEW_AGREEMENT%}' => Config::get('app.url').'/employeeportal/agreement/'.base64_encode($employee->id).'/'.$ref_token,
                                '{%HCO_FIRST_NAME%}' => $hco->hco->first_name,
                                '{%HCO_LAST_NAME%}' => $hco->hco->last_name,
                                '{%HCO_EMAIL%}' => $hco->hco->email,
                                '{%COMPANY_NAME%}' => $employee->employeePrimaryWorkLocation->company_name,
                            ];
                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate_HCE_UE8->body);
                            $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$employee->employeePrimaryWorkLocation->company_name], $emailTemplate_HCE_UE8->subject);
                            $this->sendEmail($emailTemplate_HCE_UE8->code, $html, $employee->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                        }
                    }
                } catch (\Exception $e) {
                    Log::error('EmployeeController/sendAgreementEmail()[employee_list_error] => '.$e->getMessage());
                    Log::error('EmployeeController/sendAgreementEmail()[employee_list_data] => '.json_encode($employee));
                }
            }

            return $this->success(Config::get('constants.EMPLOYEE.EMPLOYEE_SEND_AGREEMENT'), 200);
        } catch (\Exception $e) {
            Log::error('EmployeeController/sendAgreementEmail() => '.$e->getMessage());
            Log::error('EmployeeController/sendAgreementEmail()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Send reminder email
     *
     * @return \Illuminate\Http\Response
     */
    public function sendReminderEmail(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'employee_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $ref_token = \Str::random(10);
            $employee = Employee::with('employeePrimaryWorkLocation')->findOrFail(request('employee_id'));
            $employee_agreement_count = EmployeeAgreement::where('employee_id', request('employee_id'))->count();
            if ($employee_agreement_count == 1) {
                if (EmployeeAgreement::where('employee_id', request('employee_id'))->update([
                    'reference_token' => $ref_token,
                ])) {
                    $hco = HipaaComplianceOfficer::where('location_id', $employee->primary_work_location_id)->with('hco')->first();
                    $emailTemplate = EmailTemplate::where('code', 'HCE-UE9')->first();
                    $email_vars = [
                        '{%EMPLOYEE_FIRST_NAME%}' => $employee->first_name,
                        '{%VIEW_AGREEMENT%}' => Config::get('app.url').'/employeeportal/agreement/'.base64_encode($employee->id).'/'.$ref_token,
                        '{%HCO_FIRST_NAME%}' => $hco->hco->first_name,
                        '{%HCO_LAST_NAME%}' => $hco->hco->last_name,
                        '{%HCO_EMAIL%}' => $hco->hco->email,
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$employee->employeePrimaryWorkLocation->company_name], $emailTemplate->subject);
                    $this->sendEmail($emailTemplate->code, $html, $employee->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));

                    return $this->success(Config::get('constants.EMPLOYEE.EMPLOYEE_SEND_AGREEMENT_REMIND'), 200, $employee);
                }
            }

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        } catch (\Exception $e) {
            Log::error('EmployeeController/sendReminderEmail() => '.$e->getMessage());
            Log::error('EmployeeController/sendReminderEmail()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Import employees from file
     *
     * @return \Illuminate\Http\Response
     */
    public function importEmployee(Request $request)
    {
        $user_data = $this->getMainAccountDetails();
        $generalController = new GeneralController;
        $location_access_list = $generalController->getAssingedLocationList();
        $location_list_count = Location::where('user_id', $user_data['id'])
            ->select(['id', 'location_nickname'])
            ->whereHas('hipaaComplianceOfficer')
            ->whereIn('id', $location_access_list)
            ->count();
        $validator_rules = [
            'import_file' => 'required|mimes:xlsx,xls',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules, []);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.EMPLOYEE.INVALID_IMPORT_FILE'), 200, $validator_check->errors()->all());
        }

        $headings = (new HeadingRowImport)->toArray($request['import_file']);
        if ($location_list_count == 1) {
            $heading_array = ['first_name', 'last_name', 'email', 'phone_number', 'facility_access_key', 'full_facility_access', 'full_software_access', 'software_admin_privilages', 'full_network_access', 'network_admin_privilages', 'security_code'];
        } else {
            $heading_array = ['first_name', 'last_name', 'email', 'phone_number', 'primary_work_location', 'secondary_work_locations', 'facility_access_key', 'full_facility_access', 'full_software_access', 'software_admin_privilages', 'full_network_access', 'network_admin_privilages', 'security_code'];
        }
        $headings[0][0] = array_filter($headings[0][0], function ($v) {
            return trim($v) == true;
        });
        $missing_heading = array_diff($heading_array, $headings[0][0]);
        if ($missing_heading) {
            return $this->error(Config::get('constants.EMPLOYEE.IMPORT_FILE_INVALID_TEMPLETE'), 200);
        }

        try {
            if ($request->has('import_file')) {
                $import = new EmployeeImport;
                $import->import($request['import_file']);
                if ($import->failures()->isNotEmpty()) {
                    $error = [];
                    $i = 0;
                    foreach ($import->failures() as $failure) {
                        foreach ($failure->errors() as $value) {
                            $error[$i] = $value.'Row No :'.$failure->row();
                            $i++;
                        }
                    }
                    Log::error('EmployeeController/importEmployee(ImportValidation) => '.json_encode($error));

                    if ($import->row_count == 0) {
                        return $this->error(Config::get('constants.EMPLOYEE.IMPORT_ERROR'), 200, $error);
                    } else {
                        return $this->success(Config::get('constants.EMPLOYEE.PARTIALLY_IMPORT_ERROR'), 200, $error);
                    }
                }
                if ($import->row_count == 0) {
                    return $this->error(Config::get('constants.EMPLOYEE.IMPORT_ERROR'), 200, $import->invalid_primary_location);
                }
                if ($import->row_count == $import->total_row_count) {
                    return $this->success(Config::get('constants.EMPLOYEE.IMPORTED'), 200);
                } else {
                    return $this->success(Config::get('constants.EMPLOYEE.PARTIALLY_IMPORT_ERROR'), 200, $import->invalid_primary_location);
                }
            }
        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            Log::error('EmployeeController/importEmployee(Import) => '.$e->getMessage());

            return $this->error(Config::get('constants.EMPLOYEE.IMPORT_ERROR'), 200);
        } catch (\Exception $e) {
            if ($e->getMessage() == 'more_than_limit_records') {
                Log::error('EmployeeController/importEmployee(limit) => Limit reached');

                return $this->error(Config::get('constants.IMPORT_LIMIT'), 200);
            } elseif ($e->getLine() == 392) {
                $invalid_primmary_locations = explode(',', $e->getMessage());

                return $this->error(Config::get('constants.EMPLOYEE.IMPORT_ERROR'), 200, $invalid_primmary_locations);
            } elseif ($e->getMessage() == 'employee_limit_exceeded') {
                return $this->error(Config::get('constants.EMPLOYEE.EMPLOYEE_LIMIT_REACHED'), 200, ['reason' => 'employee_limit_reached']);
            } else {
                Log::error('EmployeeController/importEmployee(error) => '.$e->getMessage());

                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        }
    }

    /**
     * get last updated employee for dashboard
     */
    public function getLastUpdatedEmployee($location_id)
    {
        $is_avail = LocationModuleLastUpdate::where(['location_id' => $location_id, 'module_name' => 'employee'])->first();

        return ($is_avail) ? $is_avail->updated_at : '';
    }

    /**
     * Send agreement email
     *
     * @return \Illuminate\Http\Response
     */
    public function getEmployeeWorkLocations(Request $request)
    {
        try {
            $validator_rules = [
                'employee_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $employee = Employee::where('id', $request['employee_id'])->with(['employeeSecondaryWorkLocation'])->first();
            $employee_location_ids[] = $employee->primary_work_location_id;
            $employee_location_ids = array_merge($employee_location_ids, $employee->employeeSecondaryWorkLocation->pluck('location_id')->toArray());

            $user_data = auth()->user();
            $check_current_login = auth()->getDefaultDriver();
            if ($check_current_login == 'account_user') {
                $account_user_location_ids = AccountUserLocationAccess::select(['location_id'])
                    ->where('account_user_id', $user_data->id)
                    ->get()->pluck('location_id')->toArray();
                $employee_location_ids = array_intersect($employee_location_ids, $account_user_location_ids);
            }

            $location_list = Location::with(['employeeAccessRight' => function ($q) use ($request) {
                $q->where('employee_id', $request['employee_id']);
            }])
                ->select('id', 'location_nickname')
                ->whereIn('id', $employee_location_ids)
                ->orderByRaw('FIELD(id, '.implode(',', $employee_location_ids).')')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $location_list);
        } catch (\Exception $e) {
            Log::error('EmployeeController/getEmployeeWorkLocations() => '.$e->getMessage());
            Log::error('EmployeeController/getEmployeeWorkLocations()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Add or edit access right of employee
     *
     * @return \Illuminate\Http\Response
     */
    public function addEditEmployeeAcessRight(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $validator_rules = [
                'apply_to_all_location' => 'required|in:yes,no',
                'employee_id' => 'required',
                'location_id' => 'required',
                'facility_access_key' => 'required',
                'full_facility_access' => 'required',
                'full_software_access' => 'required',
                'software_admin_privilages' => 'required',
                'full_network_access' => 'required',
                'network_admin_privilages' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $params = [
                'facility_access_key' => $request['facility_access_key'],
                'full_facility_access' => $request['full_facility_access'],
                'full_software_access' => $request['full_software_access'],
                'software_admin_privilages' => $request['software_admin_privilages'],
                'full_network_access' => $request['full_network_access'],
                'network_admin_privilages' => $request['network_admin_privilages'],
            ];
            $params['security_code'] = $request->has('security_code') ? $request['security_code'] : null;

            if ($request->has('apply_to_all_location') && $request['apply_to_all_location'] == 'yes') {
                $employee = Employee::where('id', $request['employee_id'])->with(['employeeSecondaryWorkLocation'])->first();
                $employee_location_ids[] = $employee->primary_work_location_id;
                $employee_location_ids = array_merge($employee_location_ids, $employee->employeeSecondaryWorkLocation->pluck('location_id')->toArray());
                foreach ($employee_location_ids as $loc_id) {
                    try {
                        $emp_access_right = EmployeeAccessRight::where([
                            'location_id' => $loc_id,
                            'employee_id' => $request['employee_id'],
                        ])->first();
                        if (($params['security_code'] != null || ($emp_access_right && $emp_access_right['security_code'] != $params['security_code']))) {
                            $this->addPolicyVersionData('SAP', $loc_id);
                        }
                        if (
                            ! $emp_access_right && ($params['facility_access_key'] == 'Yes' ||
                            $params['full_facility_access'] == 'Yes' ||
                            $params['full_software_access'] == 'Yes' ||
                            $params['software_admin_privilages'] == 'Yes' ||
                            $params['full_network_access'] == 'Yes' ||
                            $params['network_admin_privilages'] == 'Yes')
                        ) {
                            $this->addPolicyVersionData('AAP', $loc_id);
                        } elseif (
                            $emp_access_right &&
                            ($emp_access_right['facility_access_key'] != $params['facility_access_key'] ||
                                $emp_access_right['full_facility_access'] != $params['full_facility_access'] ||
                                $emp_access_right['full_software_access'] != $params['full_software_access'] ||
                                $emp_access_right['software_admin_privilages'] != $params['software_admin_privilages'] ||
                                $emp_access_right['full_network_access'] != $params['full_network_access'] ||
                                $emp_access_right['network_admin_privilages'] != $params['network_admin_privilages'])
                        ) {
                            $this->addPolicyVersionData('AAP', $loc_id);
                        }
                        $result = EmployeeAccessRight::updateOrCreate(
                            [
                                'location_id' => $loc_id,
                                'employee_id' => $request['employee_id'],
                            ],
                            $params
                        );
                    } catch (\Exception $e) {
                        Log::error('EmployeeController/addEditEmployeeAcessRight()[employee_location_error] => '.$e->getMessage());
                        Log::error('EmployeeController/addEditEmployeeAcessRight()[employee_location_data] => '.json_encode([$loc_id]));
                    }
                }
            } else {
                $emp_access_right = EmployeeAccessRight::where([
                    'location_id' => $request['location_id'],
                    'employee_id' => $request['employee_id'],
                ])->first();

                if (($params['security_code'] != null || ($emp_access_right && $emp_access_right['security_code'] != $params['security_code']))) {
                    $this->addPolicyVersionData('SAP', $request['location_id']);
                }
                if (
                    ! $emp_access_right && ($params['facility_access_key'] == 'Yes' ||
                    $params['full_facility_access'] == 'Yes' ||
                    $params['full_software_access'] == 'Yes' ||
                    $params['software_admin_privilages'] == 'Yes' ||
                    $params['full_network_access'] == 'Yes' ||
                    $params['network_admin_privilages'] == 'Yes')
                ) {
                    $this->addPolicyVersionData('AAP', $request['location_id']);
                } elseif (
                    $emp_access_right &&
                    ($emp_access_right['facility_access_key'] != $params['facility_access_key'] ||
                        $emp_access_right['full_facility_access'] != $params['full_facility_access'] ||
                        $emp_access_right['full_software_access'] != $params['full_software_access'] ||
                        $emp_access_right['software_admin_privilages'] != $params['software_admin_privilages'] ||
                        $emp_access_right['full_network_access'] != $params['full_network_access'] ||
                        $emp_access_right['network_admin_privilages'] != $params['network_admin_privilages'])
                ) {
                    $this->addPolicyVersionData('AAP', $request['location_id']);
                }
                $result = EmployeeAccessRight::updateOrCreate(
                    [
                        'location_id' => $request['location_id'],
                        'employee_id' => $request['employee_id'],
                    ],
                    $params
                );
            }

            return $this->success(Config::get('constants.EMPLOYEE.ACCESS_RIGHT_CHANGED'), 200, $result);
        } catch (\Exception $e) {
            Log::error('EmployeeController/addEditEmployeeAcessRight() => '.$e->getMessage());
            Log::error('EmployeeController/addEditEmployeeAcessRight()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * change employee status
     *
     * @return \Illuminate\Http\Response
     */
    public function changeEmployeeStatus(Request $request)
    {
        try {
            $validator_rules = [
                'employee_id' => 'required',
                'type' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $employee = Employee::where('id', $request['employee_id'])->update(['status' => $request->type]);
            $employee_updated_data = Employee::where('id', $request['employee_id'])
                ->with(['employeeSecondaryWorkLocation', 'employeeSecondaryWorkLocation.location' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }, 'employeePrimaryWorkLocation' => function ($q) {
                    $q->select(['id', 'location_nickname']);
                }, 'employeeAgreement'])->withCount(['employeeAccessRights'])->first();

            $training_controller = new TrainingController;
            if ($employee && $request->type == 'active') {
                $location_id = $employee_updated_data->primary_work_location_id;
                $checkCount = Location::whereHas('sraModuleCompleted')->withCount('activeEmployeePrimaryWorkLocation')->where('id', $location_id)->first();
                if ($checkCount && $checkCount->active_employee_primary_work_location_count == 1) {
                    $training_controller->addTrainingLocations($location_id);
                }
                $training_controller->addToUnassignedTraining($location_id, $request['employee_id'], \App\Models\Employee::class);
            }
            $training_controller->moveTrainingToArchive($employee_updated_data->primary_work_location_id);

            if ($employee_updated_data->employeeAgreement) {
                $expire_time = Config::get('app.expire_time');
                $employeeAgreement = $employee_updated_data->employeeAgreement;
                $employeeAgreement->file_name = Storage::disk('s3')->temporaryUrl(
                    'generatedpolicydocuments/employeeagreement/'.$employeeAgreement->file_name,
                    now()->addSeconds($expire_time),
                    [
                        'ResponseContentType' => 'application/octet-stream',
                        'ResponseContentDisposition' => 'attachment',
                    ]
                );
                $employee_updated_data->employeeAgreement = $employeeAgreement;
            }
            DB::commit();

            return $this->success(Config::get('constants.EMPLOYEE.EMPLOYEE_ACCOUNT_STATUS'), 200, $employee_updated_data);
        } catch (\Exception $e) {
            Log::error('EmployeeController/changeEmployeeStatus() => '.$e->getMessage());
            Log::error('EmployeeController/changeEmployeeStatus()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $employee);
        }
    }

    /**
     * download employee agreement
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadAgreementWithoutSignature(Request $request)
    {
        try {
            $validator_rules = [
                'employee_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            $employee = Employee::with('user')->where('id', $request->employee_id)->with('employeePrimaryWorkLocation')->first();

            $public_path = public_path();
            $storage_path = storage_path('app/public');
            $filename = 'EmployeeAgreement.docx';
            $file_path = $public_path.'/policydocuments/'.$filename;
            $generated_agreement_directory_path = $storage_path.'/generatedpolicydocuments/';
            $gnerated_doc_name = $employee->id.'_'.$filename;
            $gnerated_pdf_name = str_replace('docx', 'pdf', $gnerated_doc_name);

            $gnerated_file_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_doc_name;
            $gnerated_pdf_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_pdf_name;
            $gnerated_pdf_url = asset('storage/generatedpolicydocuments/' . $gnerated_pdf_name);	
            $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($file_path);
            $template_processor->setValue('EMPLOYEE_NAME', htmlspecialchars($employee->first_name.' '.$employee->last_name));
            $template_processor->setValue('EMPLOYEE_SIGNATURE', '');
            $template_processor->setValue('SIGNATURE_DATE_TIME', '');
            $template_processor->setValue('CLIENT_NAME', htmlspecialchars($employee->employeePrimaryWorkLocation->company_name));
            $template_processor->saveAs($gnerated_file_path);
            if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                // change libreoffice path as per installation path from your machine
                exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  '.$generated_agreement_directory_path.' '.$gnerated_file_path);
            } else {
                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir '.$generated_agreement_directory_path.' '.$gnerated_file_path);
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, ['file_name' => $employee->id.'_EmployeeAgreement.pdf', 'download_url' => $gnerated_pdf_url]);
        } catch (\Exception $e) {
            Log::error('EmployeeController/downloadAgreementWithoutSignature() => '.$e->getMessage());
            Log::error('EmployeeController/downloadAgreementWithoutSignature()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * generate agreement by doc file
     *
     * @return \Illuminate\Http\Response
     */
    public function agreementByDocOfEmployee(Request $request)
    {
        try {
            $validator_rules = [
                'employee_id' => 'required',
                'agreement_type' => 'required|in:doc',
                'file' => 'nullable',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $employee = Employee::findOrFail($request['employee_id']);
            $employee_agreement = EmployeeAgreement::where('employee_id', $employee->id)->first();
            $locations = Location::where('user_id', $employee->user_id)
                ->whereHas('hipaaComplianceOfficer')
                ->whereHas('companyModuleCompleted')
                ->whereHas('sraModuleCompleted')
                ->whereHas('disasterRecoveryPlanModuleCompleted')
                ->where(function ($query) {
                    $query->whereHas('employeePrimaryWorkLocation')->orWhereHas('employeeSecondaryWorkLocation');
                })->get();
            foreach ($locations as $location) {
                $this->addPolicyVersionData('BACP', $location->id);
            }
            $input_fields = $request->all();
            if ($request->has('file')) {
                $filePath = '/generatedpolicydocuments/employeeagreement/';
                $doc = $request->file('file');
                $file_name = $employee->id.'_'.$doc->getClientOriginalName();
                $path = $doc->storeAs(
                    $filePath,
                    $file_name, //$fileName
                    ['disk' => 's3'] //$options
                );
                $employees_agreement = $this->getSignedURL('/generatedpolicydocuments/employeeagreement/'.$employee->id.'/'.$file_name);
                if ($employee_agreement == null) {
                    EmployeeAgreement::create([
                        'employee_id' => $employee->id,
                        'file_name' => $file_name,
                        'agreement_type' => $request['agreement_type'],
                    ]);
                } else {

                    $employee_agreement->update([
                        'reference_token' => null,
                        'agreement_type' => $request['agreement_type'],
                        'file_name' => $file_name,
                    ]);
                }
            }

            return $this->success(Config::get('constants.BUSINESSASSOCIATES.BUSINESSASSOCIATES_SEND_AGREEMENT_UPLOAD'), 200);
        } catch (\Exception $e) {
            Log::error('EmployeeController/agreementByDocOfEmployee() => '.$e->getMessage());
            Log::error('EmployeeController/agreementByDocOfEmployee()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }
    /************************** */
    /*API methods - end
    /*************************** */
}
