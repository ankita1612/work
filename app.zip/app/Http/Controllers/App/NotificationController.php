<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\Location;
use App\Models\LocationNotification;
use App\Models\Notification;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\GetLoginUserData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class NotificationController extends Controller
{
    use ApiResponser, CheckAccessRight, GetLoginUserData;

    /**
     * Notification page
     *
     * @return \Illuminate\Http\Response
     */
    public function showNotifications(Request $request, $location_id = '')
    {
        if ($location_id != '') {
            $location_id = base64_decode($location_id, true);
            if ($location_id == null) {
                return redirect('/dashboard');
            }
            if ($location_id) {
                if ($this->checkAccessRight('notification', $location_id)) {
                    return view('app.pages.notification', ['location_id' => $location_id]);
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get Notification List
     *
     * @return \Illuminate\Http\Response
     */
    public function notificationList(Request $request)
    {
        try {
            $validator_rules = [
                'notification_type' => 'required|in:complete,all,incomplete',
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $user_data = $this->getLoginUserData();
            if ($user_data['user_type'] == 'USER') {
                $user_data['user_type'] = 'User';
            }
            $notification_list = LocationNotification::where('location_id', $request['location_id'])
                ->with(['notification.userNotification' => function ($query) use ($user_data) {
                    $query->where('user_type', $user_data['user_type']);
                }]);
            if ($request['notification_type'] == 'complete') {
                $notification_list = $notification_list->where('location_id', $request['location_id'])->where('is_completed', 1);
            }
            if ($request['notification_type'] == 'incomplete') {
                $notification_list = $notification_list->where('location_id', $request['location_id'])->where('is_completed', 0);
            }
            if ($request['notification_type'] == 'all') {
                $notification_list = $notification_list->where('location_id', $request['location_id']);
            }
            if ($request->has('search') && ($request['search'] != '' || $request['search'] != null)) {
                $notification_list = $notification_list->whereHas('notification', function ($query) use ($request) {
                    return $query->where('title', 'LIKE', '%'.$request['search'].'%');
                });
            }
            $notification_list = $notification_list->whereHas('notification.userNotification', function ($query) use ($user_data) {
                $query->where('user_type', $user_data['user_type']);
            });
            $notification_list = $notification_list->orderBy('id', 'DESC');
            $limit = $request->has('per_page') ? request('per_page') : Config::get('constants.PER_PAGE');
            $notification_list = $notification_list->paginate($limit);

            return $this->success(Config::get('constants.SUCCESS'), 200, $notification_list);
        } catch (\Exception $e) {
            Log::error('NotificationController/notificationList() => '.$e->getMessage());
            Log::error('NotificationController/notificationList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * change Notification status
     *
     * @return \Illuminate\Http\Response
     */
    public function changeNotificationStatus(Request $request)
    {
        try {
            $validator_rules = [
                'location_notification_id' => 'required',
                'status' => 'required|in:complete,restore',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }

            DB::beginTransaction();
            $notification = LocationNotification::findOrFail($request['location_notification_id']);
            $location_id = $notification->location_id;
            $SF_location = Location::where('id', $notification->location_id)->whereNotNull('salesforce_unique_id')->first();
            if ($request['status'] == 'complete') {
                $notification = $notification->update(['is_completed' => 1]);
            }
            if ($request['status'] == 'restore') {
                $notification = $notification->update(['is_completed' => 0]);
            }
            if ($SF_location) {
                SendLocationDataToSalesForce::dispatch($SF_location->id);
            }
            DB::commit();
            $list = $this->openNotificationlist($location_id);

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('NotificationController/changeNotificationStatus() => '.$e->getMessage());
            Log::error('NotificationController/changeNotificationStatus()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * open notification list
     *
     * @return \Illuminate\Http\Response
     */
    public function openNotificationlist($location_id)
    {
        try {
            $user_data = $this->getLoginUserData();
            if ($user_data['user_type'] == 'USER') {
                $user_data['user_type'] = 'User';
            }
            $open_notification_list = LocationNotification::where('location_id', $location_id)
                ->where('is_completed', 0)
                ->with(['notification'])
                ->whereHas('notification.userNotification', function ($query) use ($user_data) {
                    $query->where('user_type', $user_data['user_type']);
                })->orderBy('id', 'DESC')->get();

            return $open_notification_list;
        } catch (\Exception $e) {
            Log::error('NotificationController/openNotificationlist() => '.$e->getMessage());
            Log::error('NotificationController/openNotificationlist()[data] => '.json_encode(['location_id' => $location_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
