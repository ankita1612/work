<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Models\State;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;

class AbydeAcademyController extends Controller
{
    use ApiResponser;

    /**
     * abyde academy select state page
     */
    public function showSelectState(Request $request)
    {
        return view('app.pages.abydeacademy');
    }

    /**
     * List all states
     *
     * @return \Illuminate\Http\Response
     */
    public function listStates(Request $request)
    {
        try {
            $list = State::select(['id', 'state_code', 'state_name'])
                ->with('calendlyLink')
                ->orderBy('state_name')
                ->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $list);
        } catch (\Exception $e) {
            Log::error('AbydeAcademyController/listStates() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }
    /**
     * abyde academy refresher select state page
     */
    public function showSelectStateRefresher(Request $request)
    {
        return view('app.pages.abydeacademyRefresher');
    }
    /**
     * abyde academy assessment review select state page
     */
    public function showSelectStateAssessmentReview(Request $request)
    {
        return view('app.pages.abydeacademyAssessmentReview');
    }
    /**
     * abyde academy offboarding select state page
     */
    public function showSelectStateOffboarding(Request $request)
    {
        return view('app.pages.abydeacademyOffboarding');
    }
}
