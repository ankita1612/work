<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AccountUser;
use App\Models\AccountUserLocationAccess;
use App\Models\EmailTemplate;
use App\Models\EmployeeLimitPrice;
use App\Models\Location;
use App\Models\LocationLimitPrice;
use App\Models\SraOnlyLocationLimitPrice;
use App\Models\Partner;
use App\Models\Promocode;
use App\Models\User;
use App\Models\UserLogin;
use App\Models\UserProductToken;
use App\Traits\ApiResponser;
use App\Traits\PricingHelper;
use App\Traits\SendMail;
use App\Traits\ChargebeePlan;
use App\Traits\{SyncLocationDataWithSalesForce};
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Exceptions\PaymentException;
use ChargeBee\ChargeBee\Models\Customer;
use ChargeBee\ChargeBee\Models\Estimate;
use ChargeBee\ChargeBee\Models\Invoice;
use ChargeBee\ChargeBee\Models\PaymentSource;
use ChargeBee\ChargeBee\Models\Subscription;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Stripe;

class AuthController extends Controller
{
    use ApiResponser, PricingHelper, SendMail, SyncLocationDataWithSalesForce, ChargebeePlan;

    /**
     * one time synct
        - temp route
     *
     * @return \Illuminate\Http\Response
     */
    public function syncWithSalesForce($location_id)
    {
        try {
            if ($location_id == '') {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
            $sync_sales_force_data = $this->SyncLocationDataWithSalesForce($location_id);

            return $this->success(Config::get('constants.SUCCESS'), 200, $sync_sales_force_data);
        } catch (\Exception $e) {
            Log::error('AuthController/syncWithSalesForce() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Login page.
     *
     * @return \Illuminate\Http\Response
     */
    public function showLogin(Request $request, $verification_code = '', $user_id = '', $account_type = '')
    {
        if (Auth::guard('user')->check() || Auth::guard('account_user')->check()) {
            return redirect()->route('dashboard');
        }

        return view('app.pages.login', ['verification_code' => $verification_code, 'user_id' => $user_id, 'account_type' => $account_type]);
    }

    /**
     * Signup page.
     *
     * @return \Illuminate\Http\Response
     */
    public function showSignup(Request $request)
    {
        $partner_data = [];
        if (Auth::guard('user')->check() || Auth::guard('account_user')->check()) {
            return redirect()->route('dashboard');
        }
        if ($request->has('rp')) {
            $partner_data = Partner::where(['slug' => $request->input('rp'), 'is_reseller' => 1])->first();
            if (empty($partner_data)) {
                return redirect()->route('login');
            } else {
                $partner_data = $partner_data->toArray();
            }
        }

        return view('app.pages.signup_new_product', ['partner_data' => $partner_data]);
    }

    /**
     * Signup existing product page.
     *
     * @return \Illuminate\Http\Response
     */
    public function showSignupWithExistingProduct(Request $request)
    {
        if (Auth::guard('user')->check() || Auth::guard('account_user')->check()) {
            return redirect()->route('dashboard');
        }

        return view('app.pages.signup_existing_product');
    }

    public function showSRAOnlySignup(Request $request)
    {
         $partner_data = [];
        if (Auth::guard('user')->check() || Auth::guard('account_user')->check()) {
            return redirect()->route('dashboard');
        }
        if ($request->has('rp')) {
            $partner_data = Partner::where(['slug' => $request->input('rp'), 'is_reseller' => 1])->first();
            if (empty($partner_data)) {
                return redirect()->route('login');
            } else {
                $partner_data = $partner_data->toArray();
            }
        }

        return view('app.pages.sra_only_signup', ['partner_data' => $partner_data]);
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * User & Account user login
     *
     * @return \Illuminate\Http\Response
     */
    public function doLogin(Request $request)
    {
        if (Auth::guard('user')->check() || Auth::guard('account_user')->check()) {
            return $this->error(Config::get('constants.USER.LOGOUT_CURRENT_SESSION'), 200);
        }
        $validator_rules = [
            'email' => 'required|email',
            'password' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $user = User::where('email', $request->email)->with('reseller')->first();
            if ($user) {
                if (! $user->is_active) {
                    return $this->error(Config::get('constants.USER.INACTIVE'), 200);
                    exit;
                } elseif (! $user->is_account_verified) {
                    return $this->error(Config::get('constants.USER.ACCOUNT_NOT_VERIFIED'), 200);
                    exit;
                } elseif (Auth::guard('user')->validate(['email' => $request['email'], 'password' => $request['password']])) {
                    $this->deletePastUserLogins($user->id);
                    $otp = mt_rand(1000, 9999);
                    $user_login = UserLogin::create([
                        'main_user_id' => $user->id,
                        'user_id' => $user->id,
                        'user_type' => \App\Models\User::class,
                        'otp' => $otp,
                    ]);
                    if ($user->is_demo_account) {
                        Auth::guard('user')->login($user);
                        User::where(['id' => $user_login->mainUser->id])->update(['timezone' => $request['timezone']]);
                        $user_login->update(['login_success' => 'yes']);

                        return $this->success(Config::get('constants.USER.USER_LOGIN_SUCCESS'), 200);
                        exit;
                    }
                    $emailTemplate = EmailTemplate::where('code', 'HUE53')->first();
                    $email_vars = [
                        '{%FIRST_NAME%}' => $user->first_name,
                        '{%ONE_TIME_PASSWORD%}' => $otp,
                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $this->sendEmail($emailTemplate->code, $html, $user->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                    return $this->success(Config::get('constants.USER.CHECK_EMAIL_OTP'), 200, ['user_login_id' => $user_login->id]);
                    exit;
                }
            }
            $accountuser = AccountUser::where('email', $request->email)->first();
            if ($accountuser && $accountuser['password'] != null) {
                $user = User::where('id', $accountuser['user_id'])->with(['reseller'])->first();
                $subscription = $this->getSubscriptionDetails($user->chargebee_subscription_id);
                $total_location = Location::where('user_id', $user['id'])->count();
                $is_access_location = 0;
                $is_access_location = AccountUserLocationAccess::where('account_user_id', $accountuser['id'])->count();
                if ((int) $subscription['location_limit'] > (int) $total_location) {
                    return $this->error(Config::get('constants.USER.ASK_PCO_ADD_LOCATION'), 200);
                    exit;
                } elseif (! $user->is_active) {
                    return $this->error(Config::get('constants.USER.INACTIVE'), 200);
                    exit;
                } elseif (! $user->is_account_verified) {
                    return $this->error(Config::get('constants.USER.ACCOUNT_NOT_VERIFIED'), 200);
                    exit;
                } elseif ($user->account_status == 'Frozen') {
                    return $this->error(Config::get('constants.USER.ACCOUNT_FROZEN'), 200);
                    exit;
                } elseif ($is_access_location == 0) {
                    return $this->error(Config::get('constants.USER.NO_LOCATION_ACCESS'), 200);
                    exit;
                } elseif (Auth::guard('account_user')->validate(['email' => $request['email'], 'password' => $request['password']])) {
                    $this->deletePastUserLogins($user->id);
                    $otp = mt_rand(1000, 9999);
                    $user_login = UserLogin::create([
                        'main_user_id' => $user->id,
                        'user_id' => $accountuser->id,
                        'user_type' => \App\Models\AccountUser::class,
                        'otp' => $otp,
                    ]);
                    if ($user->is_demo_account) {
                        Auth::guard('account_user')->login($accountuser);
                        User::where(['id' => $user_login->mainUser->id])->update(['timezone' => $request['timezone']]);
                        $user_login->update(['login_success' => 'yes']);

                        return $this->success(Config::get('constants.USER.USER_LOGIN_SUCCESS'), 200);
                        exit;
                    }
                    $emailTemplate = EmailTemplate::where('code', 'HUE53')->first();
                    $email_vars = [
                        '{%FIRST_NAME%}' => $accountuser->first_name,
                        '{%ONE_TIME_PASSWORD%}' => $otp,
                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $this->sendEmail($emailTemplate->code, $html, $accountuser->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                    return $this->success(Config::get('constants.USER.CHECK_EMAIL_OTP'), 200, ['user_login_id' => $user_login->id]);
                    exit;
                }
            }

            return $this->error(Config::get('constants.USER.USER_LOGIN_FAIL'), 200);
        } catch (\Exception $e) {
            Log::error('AuthController/doLogin() => '.$e->getMessage());
            Log::error('AuthController/doLogin()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * User & Account user verify otp
     *
     * @return \Illuminate\Http\Response
     */
    public function verifyOTP(Request $request)
    {
        $validator_rules = [
            'user_login_id' => 'required',
            'verfication_otp' => 'required',
            'timezone' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $user_login = UserLogin::with(['mainUser'])->findOrFail($request->user_login_id);
            if (! $user_login->mainUser->is_active) {
                return $this->error(Config::get('constants.USER.INACTIVE'), 200);
                exit;
            } elseif (! $user_login->mainUser->is_account_verified) {
                return $this->error(Config::get('constants.USER.ACCOUNT_NOT_VERIFIED'), 200);
                exit;
            } else {
                if ($user_login->user_type == \App\Models\AccountUser::class) {
                    $accountuser = AccountUser::where('id', $user_login->user_id)->first();
                    $total_location = Location::where('user_id', $user_login['mainUser']['id'])->count();
                    $is_access_location = 0;
                    $is_access_location = AccountUserLocationAccess::where('account_user_id', $accountuser['id'])->count();
                    $subscription = $this->getSubscriptionDetails($user_login['mainUser']['chargebee_subscription_id']);
                    $location_limit = $subscription['location_limit'];
                    if ((int) $location_limit > (int) $total_location) {
                        return $this->error(Config::get('constants.USER.ASK_PCO_ADD_LOCATION'), 200);
                        exit;
                    } elseif ($user_login->mainUser->account_status == 'Frozen') {
                        return $this->error(Config::get('constants.USER.ACCOUNT_FROZEN'), 200);
                        exit;
                    } elseif ($is_access_location == 0) {
                        return $this->error(Config::get('constants.USER.NO_LOCATION_ACCESS'), 200);
                        exit;
                    }
                }
                $otp_send_datetime = Carbon::parse($user_login->created_at);
                $current_datetime = Carbon::now();
                $diff_mins = $otp_send_datetime->diffInMinutes($current_datetime);
                if ($diff_mins > 30) {
                    return $this->error(Config::get('constants.USER.OTP_EXPIRED'), 200);
                } elseif ($user_login->login_attempt >= 5) {
                    return $this->error(Config::get('constants.USER.OTP_ATTEMPT_OVER'), 200);
                } elseif ($user_login->otp != str_replace('-', '', $request->verfication_otp)) {
                    $user_login->update(['login_attempt' => $user_login->login_attempt + 1]);

                    return $this->error(Config::get('constants.USER.WRONG_OTP'), 200);
                } else {
                    if ($user_login->user_type == \App\Models\AccountUser::class) {
                        Auth::guard('account_user')->login($accountuser);
                    } else {
                        Auth::guard('user')->login($user_login->mainUser);
                    }
                    $user_login->update(['login_success' => 'yes']);
                    User::where(['id' => $user_login->mainUser->id])->update(['timezone' => $request['timezone']]);

                    return $this->success(Config::get('constants.USER.USER_LOGIN_SUCCESS'), 200);
                }
            }
        } catch (\Exception $e) {
            Log::error('AuthController/verifyOTP() => '.$e->getMessage());
            Log::error('AuthController/verifyOTP()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * User & Account user resend otp
     *
     * @return \Illuminate\Http\Response
     */
    public function resendOTP(Request $request)
    {
        $validator_rules = [
            'user_login_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $otp = mt_rand(1000, 9999);
            $user_login = UserLogin::with(['mainUser.reseller'])->findOrFail($request->user_login_id);
            $user_login->update(['otp' => $otp, 'created_at' => gmdate('Y-m-d H:i:s'), 'login_attempt' => 0]);
            if ($user_login->user_type == \App\Models\AccountUser::class) {
                $accountuser = AccountUser::where('id', $user_login->user_id)->first();
            }
            $emailTemplate = EmailTemplate::where('code', 'HUE53')->first();
            $email_vars = [
                '{%FIRST_NAME%}' => ($user_login->user_type == \App\Models\AccountUser::class) ? $accountuser->first_name : $user_login->mainUser->first_name,
                '{%ONE_TIME_PASSWORD%}' => $otp,
                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
            ];
            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
            $this->sendEmail($emailTemplate->code, $html, ($user_login->user_type == \App\Models\AccountUser::class) ? $accountuser->email : $user_login->mainUser->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($user_login->mainUser->partner_reseller_id != null ? $user_login->mainUser->reseller->logo : null), $user_login->mainUser->id);

            return $this->success(Config::get('constants.USER.CHECK_EMAIL_OTP'), 200);
        } catch (\Exception $e) {
            Log::error('AuthController/resendOTP() => '.$e->getMessage());
            Log::error('AuthController/resendOTP()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * hipaa toggle
     *
     * @return \Illuminate\Http\Response
     */
    public function hipaaToggle(Request $request)
    {
        $validator_rules = [
            'stripe_customer_id' => 'required',
            'email' => 'required|email',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            Stripe\Stripe::setApiKey(Config::get('app.stripe_secret_key'));
            $stripe_customer = Stripe\Customer::retrieve($request->stripe_customer_id);
            if (! empty($stripe_customer) && isset($stripe_customer->id) && $stripe_customer->id) {
                $user = User::where('stripe_customer_id', $request->stripe_customer_id)->where('email', $request->email)->first();
                if ($user) {
                    if (! $user->is_active) {
                        return $this->error(Config::get('constants.USER.INACTIVE'), 200, ['is_user_found' => 1]);
                        exit;
                    } elseif (! $user->is_account_verified) {
                        return $this->error(Config::get('constants.USER.ACCOUNT_NOT_VERIFIED'), 200, ['is_user_found' => 1]);
                        exit;
                    } elseif (Auth::guard('user')->loginUsingId($user->id)) {
                        $this->deletePastUserLogins($user->id);
                        UserLogin::create([
                            'main_user_id' => $user->id,
                            'user_id' => $user->id,
                            'user_type' => \App\Models\User::class,
                            'login_success' => 'yes',
                        ]);
                        User::where(['id' => $user->id])->update(['timezone' => $request['timezone']]);

                        return $this->success(Config::get('constants.USER.USER_LOGIN_SUCCESS'), 200, ['is_user_found' => 1, 'redirect_url' => Config::get('app.url')]);
                        exit;
                    }
                }
                $user_AU = User::where('stripe_customer_id', $request->stripe_customer_id)->first();
                if ($user_AU) {
                    $accountuser = AccountUser::where('user_id', $user_AU->id)->where('email', $request->email)->first();
                    if ($accountuser) {
                        $total_location = Location::where('user_id', $user_AU['id'])->count();
                        $is_access_location = 0;
                        $is_access_location = AccountUserLocationAccess::where('account_user_id', $accountuser['id'])->count();
                        $subscription = $this->getSubscriptionDetails($user_AU['chargebee_subscription_id']);
                        $location_limit = $subscription['location_limit'];
                        if ((int) $location_limit > (int) $total_location) {
                            return $this->error(Config::get('constants.USER.ASK_PCO_ADD_LOCATION'), 200, ['is_user_found' => 1]);
                            exit;
                        } elseif (! $user_AU->is_active) {
                            return $this->error(Config::get('constants.USER.INACTIVE'), 200, ['is_user_found' => 1]);
                            exit;
                        } elseif (! $user_AU->is_account_verified) {
                            return $this->error(Config::get('constants.USER.ACCOUNT_NOT_VERIFIED'), 200, ['is_user_found' => 1]);
                            exit;
                        } elseif ($user_AU->account_status == 'Frozen') {
                            return $this->error(Config::get('constants.USER.ACCOUNT_FROZEN'), 200, ['is_user_found' => 1]);
                            exit;
                        } elseif ($is_access_location == 0) {
                            return $this->error(Config::get('constants.USER.NO_LOCATION_ACCESS'), 200, ['is_user_found' => 1]);
                            exit;
                        } elseif (Auth::guard('account_user')->loginUsingId($accountuser->id)) {
                            $this->deletePastUserLogins($user_AU->id);
                            UserLogin::create([
                                'main_user_id' => $user_AU->id,
                                'user_id' => $accountuser->id,
                                'user_type' => \App\Models\AccountUser::class,
                                'login_success' => 'yes',
                            ]);
                            User::where(['id' => $user_AU->id])->update(['timezone' => $request['timezone']]);

                            return $this->success(Config::get('constants.USER.USER_LOGIN_SUCCESS'), 200, ['is_user_found' => 1, 'redirect_url' => Config::get('app.url')]);
                            exit;
                        }
                    }

                    return $this->error(Config::get('constants.USER.PRODUCT_SWITCH_FAIL'), 200, ['is_user_found' => 0]);
                } else {
                    return $this->success(Config::get('constants.SUCCESS'), 200, ['is_user_found' => 0]);
                }
            } else {
                return $this->error(Config::get('constants.USER.PRODUCT_SWITCH_FAIL'), 200, ['is_user_found' => 0]);
            }
        } catch (\Exception $e) {
            Log::error('AuthController/hipaaToggle() => '.$e->getMessage());

            return $this->error(Config::get('constants.USER.PRODUCT_SWITCH_FAIL'), 200, ['is_user_found' => 0]);
        }
    }

    /**
     * Forgot password
     *
     * @return \Illuminate\Http\Response
     */
    public function forgotPassword(Request $request)
    {
        $validator_rules = [
            'email' => 'required|email',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $user = User::where('email', request('email'))->with(['reseller'])->first();
            $account_user = AccountUser::where('email', request('email'))->with(['user.reseller'])->first();
            if ($user || $account_user) {
                $token = \Str::random(10);
                $account_type = '';
                if ($user) {
                    $general_user = $user;
                    $account_type = 'user';
                    $user_id = $user->id;
                } else {
                    $general_user = $account_user;
                    $account_type = 'accountuser';
                    $user_id = $account_user->user->id;
                }
                if ($general_user->update([
                    'reset_password_token' => $token,
                ])) {
                    $emailTemplate = EmailTemplate::where('code', 'HCE-UE3')->first();
                    $email_vars = [
                        '{%EMAIL_ADDRESS_ENTERED_FIRST_NAME%}' => $general_user->first_name,
                        '{%RESET_PASSWORD%}' => Config::get('app.url').'/login/'.$token.'/'.base64_encode($general_user->id).'/'.$account_type,
                        '{%SUPPORT_PHONE%}' => Config::get('app.support_phone_number'),
                        '{%SUPPORT_PHONE_NUMBER_DISPLAY%}' => Config::get('app.support_phone_number_display'),
                    ];
                    $PCO_data = ($user) ? $user : $account_user->user;
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $this->sendEmail($emailTemplate->code, $html, $general_user->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($PCO_data->partner_reseller_id != null ? $PCO_data->reseller->logo : null), $user_id);

                    return $this->success(Config::get('constants.USER.CHECK_EMAIL_RESET_PASSWORD'), 200);
                }
            } else {
                return $this->error(Config::get('constants.USER.ACCOUNT_NOT_FOUND'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AuthController/forgotPassword() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Reset password verify token
     *
     * @return \Illuminate\Http\Response
     */
    public function resetPasswordVerifyToken(Request $request)
    {
        $validator_rules = [
            'verification_code' => 'required',
            'user_id' => 'required',
            'account_type' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            if (base64_decode(request('user_id'), true)) {
                $general_user = '';
                if (request('account_type') == 'user') {
                    $general_user = User::where(['reset_password_token' => request('verification_code'), 'id' => \base64_decode(request('user_id'))])->firstOrFail();
                }
                if (request('account_type') == 'accountuser') {
                    $general_user = AccountUser::where(['reset_password_token' => request('verification_code'), 'id' => \base64_decode(request('user_id'))])->firstOrFail();
                }
                if ($general_user) {
                    return $this->success(Config::get('constants.SUCCESS'), 200, ['token' => request('verification_code'), 'id' => request('user_id'), 'account_type' => request('account_type'), 'action_type' => ($general_user->password) ? 'reset' : 'set']);
                } else {
                    return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
                }
            } else {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AuthController/resetPasswordVerifyToken() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Verify account
     *
     * @return \Illuminate\Http\Response
     */
    public function accountVerification(Request $request)
    {
        $validator_rules = [
            'verification_code' => 'required',
            'user_id' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            if (base64_decode($request->user_id, true)) {
                $user = User::where('id', base64_decode($request->user_id))->where('account_verification_code', $request->verification_code)->first();
                if ($user) {
                    if ($user->update([
                        'is_active' => 1,
                        'is_account_verified' => 1,
                        'account_verification_code' => '',
                    ])) {
                        return $this->success(Config::get('constants.USER.ACCOUNT_VERIFIED'), 200);
                    } else {
                        return $this->error(Config::get('constants.USER.FAIL_ACCOUNT_VERIFIED'), 200);
                    }
                } else {
                    return $this->error(Config::get('constants.USER.FAIL_ACCOUNT_VERIFIED'), 200);
                }
            } else {
                return $this->error(Config::get('constants.USER.FAIL_ACCOUNT_VERIFIED'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AuthController/accountVerification() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Reset password
     *
     * @return \Illuminate\Http\Response
     */
    public function resetPassword(Request $request)
    {
        $validator_rules = [
            'verification_code' => 'required',
            'user_id' => 'required',
            'account_type' => 'required',
            'action_type' => 'required',
            'new_password' => 'required|confirmed|min:6',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            if (base64_decode(request('user_id'), true)) {
                $partner_logo = $general_user = '';
                if (request('account_type') == 'user') {
                    $general_user = User::where(['reset_password_token' => request('verification_code'), 'id' => \base64_decode(request('user_id'))])->with(['reseller'])->firstOrFail();
                    $partner_logo = (! empty($general_user->reseller->logo) ? $general_user->reseller->logo : null);
                    $user_id = $general_user->id;
                }
                if (request('account_type') == 'accountuser') {
                    $general_user = AccountUser::where(['reset_password_token' => request('verification_code'), 'id' => \base64_decode(request('user_id'))])->firstOrFail();
                    $user_data = User::where(['id' => $general_user->user_id])->with(['reseller'])->firstOrFail();
                    $partner_logo = (! empty($user_data->reseller->logo) ? $user_data->reseller->logo : null);
                    $user_id = $user_data->id;
                }

                if ($general_user) {
                    $was_set = $general_user->password;
                    if ($general_user->update([
                        'password' => bcrypt(request('new_password')),
                        'reset_password_token' => '',
                    ])) {
                        if ($was_set) {
                            if ($request['action_type'] == 'reset') {
                                $emailTemplate = EmailTemplate::where('code', 'HCE-UE27')->first();
                                $email_vars = [
                                    '{%USER_FIRST_NAME%}' => $general_user->first_name,
                                    '{%LOGIN_TO_ABYDE%}' => Config::get('app.url').'/login',
                                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                ];
                                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                $this->sendEmail($emailTemplate->code, $html, $general_user->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, $partner_logo, $user_id);
                            }

                            return $this->success(Config::get('constants.USER.RESET_PASSWORD_SUCCESS'), 200);
                        } else {
                            return $this->success(Config::get('constants.ACCOUNT_USER.SET_PASSWORD_SUCCESS'), 200);
                        }
                    }
                } else {
                    return $this->error(Config::get('constants.USER.RESET_PASSWORD_FAIL'), 200);
                }
            } else {
                return $this->error(Config::get('constants.USER.RESET_PASSWORD_FAIL'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AuthController/resetPassword() => '.$e->getMessage());

            return $this->error(Config::get('constants.USER.RESET_PASSWORD_FAIL'), 200);
        }
    }

    /**
     * Check valid promocode
     *
     * @return \Illuminate\Http\Response
     */
    public function checkPromocodeForSingup(Request $request)
    {
        $validator_rules = [
            'promo_code' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        
        try {            
            $current_date = gmdate('Y-m-d');
            $promocode_data = Promocode::isActive()->where(['promo_code'=> $request->promo_code, 'user_type' =>'Normal'])->first();            
            if ($promocode_data) {                
                if ($promocode_data->flash_sale_end_date && $promocode_data->flash_sale_end_date < $current_date) {
                    $promocode_data = '';
                }                
            }
            if ($promocode_data) {
                return $this->success('<b>'.$promocode_data->promo_code.'</b> '.$promocode_data->discount_percentage.'% discount successfully applied', 200, $promocode_data);
            } else {
                return $this->error(Config::get('constants.USER.PROMO_NOT_VALID'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AuthController/checkPromocodeForSingup() => '.$e->getMessage());

            return $this->error(Config::get('constants.USER.PROMO_NOT_VALID'), 200);
        }
    }

    /**
     * Check Email Already Signup
     *
     * @return \Illuminate\Http\Response
     */
    public function checkEmailAlreadySignup(Request $request)
    {
        $validator_rules = [
            'email' => 'required',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $user = User::where('email', $request->email)->first();
            $account_user = AccountUser::where('email', $request->email)->first();
            if ($user || $account_user) {
                return $this->success(Config::get('constants.SUCCESS'), 200, ['is_availabe' => 1]);
            } else {
                return $this->success(Config::get('constants.SUCCESS'), 200, ['is_availabe' => 0]);
            }
        } catch (\Exception $e) {
            Log::error('AuthController/checkEmailAlreadySignup() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * New user signup
     *
     * @return \Illuminate\Http\Response
     */
    public function doSignup(Request $request)
    {
        $validator_rules = [
            'first_name' => 'required',
            'last_name' => 'required',
            'company_name' => 'required',
            'phone_number' => 'required_without:signup_call_type',
            'email' => ['required', 'email', 'unique:App\Models\AccountUser,email,NULL,id,deleted_at,NULL', 'unique:App\Models\User,email,NULL,id,deleted_at,NULL'],
            'password' => 'required|confirmed|min:6',
            'selected_state' => 'required',
            'zip_code' => 'required',
            'plan_type' => 'required|in:monthly,yearly,biannually,quarterly',
            'location_limit' => 'required',
            'employee_limit' => 'required',
            'timezone' => 'required',
            'transaction_fee' => 'required',
        ];
        if ($request->has('billing_info') == false || ($request->has('billing_info') && $request->billing_info == 'new')) {
            $validator_rules['payment_source_type'] = 'required|in:card,bank';
            $validator_rules['stripe_payment_method'] = 'required';
        } else {
            $validator_rules['reference_id'] = 'required';
            $validator_rules['payment_source_type'] = 'required';
        }

        if ($request->has('billing_info')) {
            $validator_rules['signup_call_type'] = 'required';
        }
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        $stripe_customer_created = [];
        try {
            if ($request->has('billing_info') == false) {
                //OSHA HC email exists check
                $result_oshahc_check_email = Http::post(Config::get('app.osha_hc_url').'/check-email-already-signup', [
                    'email' => $request->email,
                ]);
                if ($result_oshahc_check_email->successful() == true) {
                    if ($result_oshahc_check_email->json()['status'] == 'Success') {
                        if ($result_oshahc_check_email->json()['data']['is_availabe'] == 1) {
                            return $this->error(Config::get('constants.USER.EMAIL_REGISTERED'), 200);
                        }
                    } else {
                        return $this->error(Config::get('constants.USER.EMAIL_REGISTERED'), 200);
                    }
                } else {
                    return $this->error(Config::get('constants.USER.EMAIL_REGISTERED'), 200);
                }
            }
            DB::beginTransaction();
            // calculate amount based on promocode
            $location_pricing = LocationLimitPrice::where('limit', $request->location_limit)->first();
            $employee_pricing = EmployeeLimitPrice::where('limit', $request->employee_limit['limit'])->first();
            // stripe customer create
            Stripe\Stripe::setApiKey(Config::get('app.stripe_secret_key'));
            if ($request->has('billing_info') == false || ($request->has('billing_info') && $request->billing_info == 'new')) {
                if ($request->has('billing_info') == false) {
                    $stripe_customer_created = Stripe\Customer::create ([
                        "name" => $request->company_name,
                        "description" => $request->first_name.' '.$request->last_name.' :: '.$request->email.' :: '.$request->company_name,
                        "email" => $request->email,
                        'phone' => $request->phone_number,
                        "invoice_settings" => ['default_payment_method' => $request->stripe_payment_method],
                        "payment_method" => $request->stripe_payment_method,
                    ]);
                } else {
                    $stripe_customer_created = Stripe\Customer::retrieve($request->stripe_customer_id);
                    $stripe_pm = Stripe\PaymentMethod::retrieve($request->stripe_payment_method);
                    if ($stripe_customer_created && $stripe_pm) {
                        $stripe_customer_pm = $stripe_pm->attach([
                            'customer' => $stripe_customer_created->id,
                        ]);
                    }
                }
                $stripe_customer_source_id = $request->stripe_payment_method;
            } else {
                $stripe_customer_created = Stripe\Customer::retrieve($request->stripe_customer_id);
                $stripe_customer_source_id = explode('/',$request->reference_id)[1];
            }            
            if($request->filled('promo_code')){
                // Check promocode in database
                $user_type = ($request->partner_reseller_slug != null) ? 'Reseller' : 'Normal';
                $promocode_data = Promocode::isActive()->where(['promo_code'=> $request->promo_code,'user_type'=>$user_type])->first();
                if(empty($promocode_data)){                    
                    return $this->error(Config::get('constants.USER.PROMO_NOT_VALID'), 200, ['error_type' => 'coupon']);
                }               
            }

            // CB customer create
            Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
            if($request->has('chargebee_customer_id') && $request->chargebee_customer_id != null){
                $chargebee_customer_response = Customer::retrieve($request->chargebee_customer_id);
                $chargebee_customer_created = $chargebee_customer_response->customer();
                if($request->has('billing_info') && $request->billing_info == 'new'){
                    $chargebee_payment_source_result = PaymentSource::createUsingPermanentToken(array(
                        "customerId" => $request->chargebee_customer_id,
                        "gatewayAccountId" => Config::get('app.chargebee_gateway_account_id'),
                        "referenceId" => $stripe_customer_created->id."/".$stripe_customer_source_id,
                        "type" => ($request->payment_source_type == 'card')?'card':'direct_debit',
                    ));
                    $paymentSource = $chargebee_payment_source_result->paymentSource();
                    $chargebee_payament_source_id = $paymentSource->id;
                }else{
                    $all_payment_sources = PaymentSource::all(array(
                        "customerId[is]" => $request->chargebee_customer_id
                    ));
                    foreach($all_payment_sources as $all_payment_source){
                        $payment_source = $all_payment_source->paymentSource();
                        if($payment_source->referenceId == $stripe_customer_created->id."/".$stripe_customer_source_id){
                            $chargebee_payament_source_id = $payment_source->id;
                        }
                    }
                }
            }else{
                $chargebee_customer_response = Customer::create(array(
                    "firstName" => $request->first_name,
                    "lastName" => $request->last_name,
                    "email" => $request->email,
                    "phone" => $request->phone_number,
                    "company" => $request->company_name,
                    "cf_Customer_Type" => ($request->partner_reseller_slug != null) ? 'Reseller' : 'Normal',
                    "allowDirectDebit" => true,
                    "billingAddress" => array(
                        "firstName" => $request->first_name,
                        "lastName" => $request->last_name,
                        "email" => $request->email,
                        'phone' => $request->phone_number,
                        "company" => $request->company_name,
                        "stateCode" => $request->selected_state['state_code'],
                        "state" => $request->selected_state['state_name'],
                        "zip" => $request->zip_code,
                        "country" => "US",
                    ),
                    "paymentMethod" => array(
                        'type' => ($request->payment_source_type  == 'card')?'card':'direct_debit',
                        "gatewayAccountId" => Config::get('app.chargebee_gateway_account_id'),
                        "referenceId" => $stripe_customer_created->id."/".$stripe_customer_source_id
                    ),
                    "taxability" => ($request->partner_reseller_slug != null) ? 'exempt' : 'taxable'
                ));
                $chargebee_customer_created = $chargebee_customer_response->customer();
                $chargebee_payament_source_id = $chargebee_customer_created->primaryPaymentSourceId;
            }
            $chargebee_plan_ids = $this->getChargebeePlanId($request->plan_type,'new');
            // CB subscription create
            $subscription_array = array(
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => 1
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['location_item_id'],
                        "quantity" => $request->location_limit
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['employee_item_id'],
                        "quantity" => $request->employee_limit['max_limit']
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['transaction_fee_item_id'],
                        "unitPriceInDecimal" => $request->transaction_fee
                    ),
                ),
                "contractTerm" => array(
                    "actionAtTermEnd" => "renew",
                    "cancellationCutoffPeriod" => "30"
                ),
                "paymentSourceId" => $chargebee_payament_source_id,
            );
            if($request->filled('promo_code')){
                $subscription_array["couponIds"] = array($request->promo_code);
            }
            $chargebee_subscription_response = Subscription::createWithItems($chargebee_customer_created->id ,$subscription_array);
            $chargebee_subscription_created = $chargebee_subscription_response->subscription();
            $chargebee_invoice_created = $chargebee_subscription_response->invoice();
            $account_verification_code = \Str::random(10);
            $primary_location_salesforce_unique_id = null;
            $primary_location_salesforce_unique_id_hash = null;
            if ($request->has('primary_location_salesforce_unique_id') && $request->has('primary_location_salesforce_unique_id_hash')) {
                if (md5($request->primary_location_salesforce_unique_id) == $request->primary_location_salesforce_unique_id_hash) {
                    $primary_location_salesforce_unique_id = $request->primary_location_salesforce_unique_id;
                    $primary_location_salesforce_unique_id_hash = $request->primary_location_salesforce_unique_id_hash;
                }
            }
            // create user in DB
            $partner = Partner::where('slug', $request->partner_reseller_slug)->first();
            $user_create_fileds = [
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'email' => $request->email,
                'password' =>($request->is_admin_panel_login=='1'? base64_decode($request->password) : bcrypt($request->password)),
                'company_name' => $request->company_name,
                'state_id' => $request->selected_state['id'],
                'phone_number' => $request->phone_number,
                'zip_code' => $request->zip_code,
                'is_active' => ($request->has('signup_call_type') && $request->signup_call_type == 'inside') ? 1 : 0,
                'account_status' => 'Unfrozen',
                'account_verification_code' => ($request->has('signup_call_type') && $request->signup_call_type == 'inside') ? '' : $account_verification_code,
                'is_account_verified' => ($request->has('signup_call_type') && $request->signup_call_type == 'inside') ? 1 : 0,
                'timezone' => $request->timezone,
                'partner_reseller_id' => $partner != null ? $partner->id : null,
                'contract_renewal_date' => Carbon::parse($chargebee_subscription_created->contractTerm->contractEnd)->format('Y-m-d'),
                'stripe_customer_id' => $stripe_customer_created->id,
                'chargebee_customer_id' => $chargebee_customer_created->id,
                'chargebee_subscription_id' => $chargebee_subscription_created->id,
                'chargebee_first_renewal_date' => Carbon::today()->format('Y-m-d'),
                'chargebe_addon_type' => 'new',
                'chargebe_first_contract_end_date' => Carbon::parse($chargebee_subscription_created->contractTerm->contractEnd)->subDay()->format('Y-m-d'),
                'primary_location_salesforce_unique_id' => $primary_location_salesforce_unique_id,
                'primary_location_salesforce_unique_id_hash' => $primary_location_salesforce_unique_id_hash,
            ];
            $user_created = User::create($user_create_fileds);
            if ($user_created && $chargebee_invoice_created && $chargebee_subscription_created) {
                    $storage_path = storage_path('app/public');
                    $promocode_data = null;
                    if($request->filled('promo_code')){
                        $promocode_data = Promocode::where('promo_code',$request->promo_code)->first();
                    }
                    $partner_data = [];
                    $partner_logo = '';
                    if ($partner != null) {
                        $partner_data = Partner::select('name', 'email', 'logo')->where('id', $partner->id)->where('is_reseller', 1)->first();
                        $partner_logo = $partner_data->logo;
                    }
                    $date = Carbon::now()->setTimezone($user_created->timezone);
                    $attachment_invoice = null;
                    $chargebee_invoice_download = Invoice::pdf($chargebee_invoice_created->id, ['dispositionType' => 'attachment']);
                    $chargebee_invoice_pdf = $chargebee_invoice_download->download();
                    $attachment_invoice = $storage_path.'/generatedpolicydocuments/'.'Abyde_Receipt_'.strtotime($user_created->created_at).'.pdf';
                    file_put_contents($attachment_invoice, file_get_contents($chargebee_invoice_pdf->downloadUrl));
                    if ($request->has('signup_call_type') && $request->signup_call_type == 'inside') {
                        $emailTemplate = EmailTemplate::where('code', 'HCE-UE2')->first();
                        $email_vars = [
                            '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_created->first_name,
                            '{%SCHEDULE_TRAINING%}' => Config::get('app.calendly_url_for_singup'),
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        $this->sendEmail($emailTemplate->code, $html, $user_created->email, Config::get('app.from_user_email'), $emailTemplate->subject,($partner == null? $attachment_invoice : null), null, true,$partner_logo, $user_created->id);
                    }else{
                        $emailTemplate = EmailTemplate::where('code', 'HCE-UE1')->first();
                        $email_vars = [
                            '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_created->first_name,
                            '{%SCHEDULE_TRAINING%}' => Config::get('app.calendly_url_for_singup'),
                            '{%ACTIVATE_ACCOUNT%}' => Config::get('app.url').'/login/'.$account_verification_code.'/'.base64_encode($user_created->id),
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        ];

                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        $this->sendEmail($emailTemplate->code, $html, $user_created->email, Config::get('app.from_user_email'), $emailTemplate->subject, ($partner == null? $attachment_invoice : null),null,true,$partner_logo, $user_created->id);
                    }
                    // create user invoice
                    $final_payment_price = (($chargebee_invoice_created->status == 'payment_due')?$chargebee_invoice_created->amountDue:$chargebee_invoice_created->amountPaid) / 100;
                    $charge_price = $final_payment_price;
                    $final_payment_price = round($final_payment_price - $request->transaction_fee, 2);
                    $sales_tax = [];
                    $sales_tax_percentage = 0;
                    if(isset($chargebee_invoice_created->taxes) && !empty($chargebee_invoice_created->taxes)){
                        foreach ($chargebee_invoice_created->taxes as $key => $value) {
                            $sales_tax[] = array(
                                'amount' => $value->amount / 100
                            );
                        }
                        foreach ($chargebee_invoice_created->lineItems as $key => $value) {
                            $sales_tax_percentage  = (isset($value->taxRate))?$value->taxRate:0;
                        }
                    }
                    if(!empty($sales_tax)){
                        $final_payment_price = round($final_payment_price - array_sum(array_column($sales_tax, 'amount')), 2);
                    }
                    $final_discount_price = 0;
                    if(isset($chargebee_invoice_created->discounts[0]) && !empty($chargebee_invoice_created->discounts[0])){
                        $final_discount_price = $chargebee_invoice_created->discounts[0]->amount / 100;
                    }
                    if($final_discount_price > 0){
                        $final_payment_price = round($final_payment_price + $final_discount_price, 2);
                    }

                    // send emails
                    $date = Carbon::now()->setTimezone($user_created->timezone);

                    if ($request->has('signup_call_type') && $request->signup_call_type == 'inside') {
                        $emailTemplate = EmailTemplate::where('code', 'HCE-AE2')->first();
                        $email_vars = [
                            '{%CHRGEBEE_INVOICE_ID%}' => $chargebee_invoice_created->id,
                            '{%CHRGEBEE_CUSTOMER_ID%}' => $user_created->chargebee_customer_id,
                            '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_created->first_name,
                            '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user_created->last_name,
                            '{%COMPANY_NAME%}' => $user_created->company_name,
                            '{%PHONE_NUMBER%}' => $user_created->phone_number,
                            '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_created->email,
                            '{%NUMBERS_OF_LOCATIONS%}' => $request->location_limit,
                            '{%EMPLOYEE_RANGE%}' => $request->employee_limit['limit'],
                            '{%PROMO_CODE%}' => ($request->promo_code) ? $request->promo_code : '',
                            '{%PRICE%}' => $this->formatPrice($final_payment_price),
                            '{%PROMO_DISCOUNT%}' => $this->formatPrice($final_discount_price),
                            '{%DISCOUNT_PRICE%}' => $this->formatPrice(round(($final_payment_price - $final_discount_price), 2)),
                            '{%SALES_TAX_PERCENTAGE%}' => (!empty($sales_tax))?$sales_tax_percentage:0,
                            '{%SALES_TAX_AMOUNT%}' => $this->formatPrice((!empty($sales_tax))?array_sum(array_column($sales_tax, 'amount')):0),
                            '{%TRANSACTION_FEE_AMOUNT%}' => $this->formatPrice($request->transaction_fee),
                            '{%PAYMENT_PRICE%}' => $this->formatPrice($charge_price),
                            '{%PAYMENT_TERM%}' => ($request->plan_type == 'biannually' ? 'Bi-Annually' : ucfirst($request->plan_type)),
                            '{%PAYMENT_DATE%}' => Carbon::parse($date)->format('Y-m-d'),
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        if (! empty($partner_data)) {
                            $admin_subject = str_ireplace('{%RESELLER%}', $partner_data->name, $emailTemplate->reseller_subject);
                        } else {
                            $admin_subject = $emailTemplate->subject;
                        }
                        $this->sendEmail($emailTemplate->code, $html, Config::get('app.aw_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, $partner_logo, $user_created->id);

                        //send mail to partner start
                        if (! empty($partner_data) && $partner_data->email != '') {
                            $this->sendEmail($emailTemplate->code, $html, $partner_data->email, Config::get('app.from_admin_email'), $admin_subject, $attachment_invoice, null, true, $partner_logo, $user_created->id);
                        }
                        //send mail to partner 'HCE-UE
                    } else {
                        $emailTemplate = EmailTemplate::where('code', 'HCE-AE1')->first();
                        $email_vars = [
                            '{%CHRGEBEE_INVOICE_ID%}' => $chargebee_invoice_created->id,
                            '{%CHRGEBEE_CUSTOMER_ID%}' => $user_created->chargebee_customer_id,
                            '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_created->first_name,
                            '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user_created->last_name,
                            '{%COMPANY_NAME%}' => $user_created->company_name,
                            '{%PHONE_NUMBER%}' => $user_created->phone_number,
                            '{%SRA_ONLY%}' => 'NO',
                            '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_created->email,
                            '{%NUMBERS_OF_LOCATIONS%}' => $request->location_limit,
                            '{%EMPLOYEE_RANGE%}' => $request->employee_limit['limit'],
                            '{%PROMO_CODE%}' => ($request->promo_code) ? $request->promo_code : '',
                            '{%PROMO_CODE_PERCENTAGE%}' => ($promocode_data) ? $promocode_data->discount_percentage : '',
                            '{%PRICE%}' => $this->formatPrice($final_payment_price),
                            '{%PROMO_DISCOUNT%}' => $this->formatPrice($final_discount_price),
                            '{%DISCOUNT_PRICE%}' => $this->formatPrice(round(($final_payment_price - $final_discount_price), 2)),
                            '{%SALES_TAX_PERCENTAGE%}' => (!empty($sales_tax))?$sales_tax_percentage:0,
                            '{%SALES_TAX_AMOUNT%}' => $this->formatPrice((!empty($sales_tax))?array_sum(array_column($sales_tax, 'amount')):0),
                            '{%TRANSACTION_FEE_AMOUNT%}' => $this->formatPrice($request->transaction_fee),
                            '{%PAYMENT_PRICE%}' => $this->formatPrice($charge_price),
                            '{%PAYMENT_TERM%}' => ($request->plan_type == 'biannually' ? 'Bi-Annually' : ucfirst($request->plan_type)),
                            '{%PAYMENT_DATE%}' => Carbon::parse($date)->format('Y-m-d'),
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        if (! empty($partner_data)) {
                            $admin_subject = str_ireplace('{%RESELLER%}', $partner_data->name, $emailTemplate->reseller_subject);
                        } else {
                            $admin_subject = $emailTemplate->subject;
                        }
                        $this->sendEmail($emailTemplate->code, $html, Config::get('app.aw_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, $partner_logo, $user_created->id);

                        //send mail to partner start
                        if (! empty($partner_data) && $partner_data->email != '') {
                            $this->sendEmail($emailTemplate->code, $html, $partner_data->email, Config::get('app.from_admin_email'), $admin_subject, $attachment_invoice, null, true, $partner_logo, $user_created->id);
                        }
                        //send mail to partner end
                    }
                    $emailTemplate = EmailTemplate::where('code', 'HCE-AE16')->first();
                    $email_vars = [
                        '{%CHRGEBEE_INVOICE_ID%}' => $chargebee_invoice_created->id,
                        '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_created->first_name,
                        '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user_created->last_name,
                        '{%COMPANY_NAME%}' => $user_created->company_name,
                        '{%PHONE_NUMBER%}' => $user_created->phone_number,
                        '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_created->email,
                        '{%PROMO_CODE%}' => ($request->promo_code) ? $request->promo_code : '',
                        '{%PRICE%}' => $this->formatPrice($final_payment_price),
                        '{%PROMO_DISCOUNT%}' => $this->formatPrice($final_discount_price),
                        '{%DISCOUNT_PRICE%}' => $this->formatPrice(round(($final_payment_price - $final_discount_price), 2)),
                        '{%SALES_TAX_PERCENTAGE%}' => (!empty($sales_tax))?$sales_tax_percentage:0,
                        '{%SALES_TAX_AMOUNT%}' => $this->formatPrice((!empty($sales_tax))?array_sum(array_column($sales_tax, 'amount')):0),
                        '{%TRANSACTION_FEE_AMOUNT%}' => $this->formatPrice($request->transaction_fee),
                        '{%PAYMENT_PRICE%}' => $this->formatPrice($charge_price),
                        '{%PAYMENT_TERM%}' => ($request->plan_type == 'biannually' ? 'Bi-Annually' : ucfirst($request->plan_type)),
                        '{%PAYMENT_DATE%}' => Carbon::parse($date)->format('Y-m-d'),
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    if (! empty($partner_data)) {
                        $admin_subject = str_ireplace('{%RESELLER%}', $partner_data->name, $emailTemplate->reseller_subject);
                    } else {
                        $admin_subject = $emailTemplate->subject;
                    }
                    $this->sendEmail($emailTemplate->code, $html, Config::get('app.finance_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, $partner_logo, $user_created->id);

                    DB::commit();
                    if ($request->has('signup_call_type') && $request->signup_call_type == 'inside') {
                        return $this->success(Config::get('constants.USER.SIGNUP_SUCCESS_FOR_PRODUCT'), 200, ['chargebee_invoice_id' => $chargebee_invoice_created->id]);
                    } else {
                        return $this->success(Config::get('constants.USER.SIGNUP_SUCCESS'), 200,  ['chargebee_invoice_id' => $chargebee_invoice_created->id]);
                    }
            } else {
                throw new \Exception('Signup - User not created');
            }
        } catch (Stripe\Exception\CardException $e) {
            DB::rollback();
            Log::error('AuthController/doSignup() => '.$e->getError()->message);

            return $this->error($e->getError()->message, 200);
        } catch (PaymentException $e) {
            DB::rollback();
            Log::error('AuthController/doSignup() => ' . $e->getMessage());
            Log::error('AuthController/doSignup()[data] => ' . json_encode($request->all()));
            preg_match('/Error message:\s*\(.*?\)\s*(.*)/', $e->getMessage(), $matches);
            $error = isset($matches[1]) ? trim($matches[1]) : $e->getMessage();
            return $this->error($error, 200);
        } catch (\Exception $e) {
            DB::rollback();
            // // delete stripe customer if created
            // if (!empty($stripe_customer_created) && $request->has('billing_info') == false) {
            //     if (isset($stripe_customer_created->id) && $stripe_customer_created->id) {
            //         Stripe\Stripe::setApiKey(Config::get('app.stripe_secret_key'));
            //         try {
            //             $customer = Stripe\Customer::retrieve($stripe_customer_created->id);
            //             $customer->delete();
            //         } catch (\Exception $eD) {
            //             Log::error('AuthController/doSignup(StripeCustomerDelete) => ' . $eD->getMessage());
            //             return $this->error(Config::get('constants.USER.SIGNUP_FAILED'), 200);
            //         }
            //     }
            // }
            Log::error('AuthController/doSignup() => '.$e->getMessage());

            return $this->error(Config::get('constants.USER.SIGNUP_FAILED'), 200);
        }
    }

    /**
     * Resend email for verification
     *
     * @return \Illuminate\Http\Response
     */
    public function resendEmailVerification(Request $request)
    {
        $validator_rules = [
            'email' => ['required', 'email'],
            'chargebee_invoice_id' => ['required'],
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        try {
            $user = User::where('email', $request->email)->with(['reseller'])->first();
            $storage_path = storage_path('app/public');
            if ($user) {
                if ($user->is_account_verified) {
                    return $this->error(Config::get('constants.USER.RESEND_EMAIL_VERIFICATION_AVAIL'), 200);
                } else {
                    Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
                    $attachment_invoice = null;
                    if($user->partner_reseller_id == null){
                        $chargebee_invoice_download = Invoice::pdf($request->chargebee_invoice_id, ['dispositionType' => 'attachment']);
                        $chargebee_invoice_pdf = $chargebee_invoice_download->download();
                        $attachment_invoice = $storage_path.'/generatedpolicydocuments/'.'Abyde_Receipt_'.strtotime($user->created_at).'.pdf';
                        file_put_contents($attachment_invoice, file_get_contents($chargebee_invoice_pdf->downloadUrl));
                    }
                    if ($user->is_sra_user == 1) {
                        $emailTemplate = EmailTemplate::where('code', 'HCE-UE70')->first();
                        $email_vars = [
                            '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user->first_name,
                            '{%ACTIVATE_ACCOUNT%}' => Config::get('app.url').'/login/'.$user->account_verification_code.'/'.base64_encode($user->id),
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        ];
                    }else{
                        $emailTemplate = EmailTemplate::where('code', 'HCE-UE1')->first();
                        $email_vars = [
                            '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user->first_name,
                            '{%SCHEDULE_TRAINING%}' => Config::get('app.calendly_url_for_singup'),
                            '{%ACTIVATE_ACCOUNT%}' => Config::get('app.url').'/login/'.$user->account_verification_code.'/'.base64_encode($user->id),
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        ];
                    }
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $this->sendEmail($emailTemplate->code, $html, $user->email, Config::get('app.from_user_email'), $emailTemplate->subject, $attachment_invoice, null, true, ($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                    return $this->success(Config::get('constants.USER.RESEND_EMAIL_VERIFICATION_SUCCESS'), 200);
                }
            } else {
                return $this->error(Config::get('constants.USER.RESEND_EMAIL_VERIFICATION_FAIL'), 200);
            }
        } catch (\Exception $e) {
            Log::error('AuthController/resendEmailVerification() => '.$e->getMessage());
            Log::error('AuthController/resendEmailVerification()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.USER.RESEND_EMAIL_VERIFICATION_FAIL'), 200);
        }
    }

    /**
     * get user plan information for product
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getUserPlanInfoForProduct($product_token, $product_type)
    {
        if ($product_token && $product_type) {
            Stripe\Stripe::setApiKey(Config::get('app.stripe_secret_key'));
            $is_valid_token = UserProductToken::where('token', $product_token)->where('product', $product_type)->first();
            if ($is_valid_token) {
                $user_info = User::select([
                    'id', 'first_name', 'last_name', 'email', 'company_name','phone_number', 'zip_code','chargebee_customer_id','chargebee_subscription_id',
                    'stripe_customer_id', 'state_id', 'partner_reseller_id', 'password As pw'
                ])
                    ->with([
                        'state' => function ($que) {
                            $que->select('state_code', 'id','state_name');
                        },
                        'reseller' => function ($que) {
                            $que->select('id', 'name', 'logo', 'email', 'link', 'slug', 'is_reseller');
                        },
                    ])
                    ->where('id', $is_valid_token->user_id)
                    ->first();
                $subscriptionDetails = $this->getSubscriptionDetails($user_info->chargebee_subscription_id,true);
                $user_info['payment_source_data'] = $subscriptionDetails['payment_source'];
                $user_info['plan_type'] = $subscriptionDetails['plan_type'];
                $user_info['pw']=base64_encode($user_info['pw']); 
                if (!empty($subscriptionDetails['coupon'])){
                    $user_info['promo_code'] =  $subscriptionDetails['coupon'] ?? null;             
                }
                $employee_pricing = EmployeeLimitPrice::where('min_limit', '<=', $subscriptionDetails['employee_limit'])->where('max_limit','>=', $subscriptionDetails['employee_limit'])->first();
                $user_info['user_plan'] = [
                    'employee_limit' => $employee_pricing,
                    'location_limit' => $subscriptionDetails['location_limit'],
                ];                
                $is_valid_token->delete();                
                return $this->success('', 200, $user_info);
            } else {
                return $this->error('invalid param', 200);
            }
        } else {
            return $this->error('invalid param', 200);
        }
    }

    private function deletePastUserLogins($user_id)
    {
        if ($user_id) {
            UserLogin::where('main_user_id', $user_id)
                ->whereDate('created_at', '<=', now()->subDays(90))
                ->delete();

            session()->put('AUTORENEWALREVIEWYPOPUPSHOWN', 0);
            $user = User::findOrFail($user_id);
            foreach ($user->locations as $key => $value) {
                $SF_location = Location::where('id', $value->id)->whereNotNull('salesforce_unique_id')->first();
                if ($SF_location) {
                    SendLocationDataToSalesForce::dispatch($SF_location->id);
                }
            }
        }
    }

    /**
     * get location, employee pricing
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getLocationEmployeePricing()
    {
        try {
            $location_pricing = LocationLimitPrice::get();
            $location_pricing_final = [];
            foreach ($location_pricing as $key => $value) {
                $location_pricing_final[$value['limit']] = (int) $value['price'];
            }
            $employee_pricing = EmployeeLimitPrice::whereNot('limit','3501+')->get();
            $employee_pricing_result = EmployeeLimitPrice::get();
            $employee_pricing_final = [];
            foreach ($employee_pricing_result as $key => $value) {
                $employee_pricing_final[$value['limit']] = (int) $value['price'];
            }
            $sraonly_location_pricing = SraOnlyLocationLimitPrice::select('price')
            ->selectRaw('count(id) as size')
            ->groupBy('price')
            ->OrderBy('price', 'desc')
            ->get();
            return $this->success(Config::get('constants.SUCCESS'), 200, [
                'location_pricing' => $location_pricing,
                'employee_pricing' => $employee_pricing,
                'location_pricing_wordpress' => $location_pricing_final,
                'employee_pricing_wordpress' => $employee_pricing_final,
                'sraonly_location_pricing_wordpress' => $sraonly_location_pricing,
            ]);
        } catch (\Exception $e) {
            Log::error('AuthController/getLocationEmployeePricing() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get chrgbee price estimation
     *
     * @return \Illuminate\Http\Response
     */
    public function getChargebeePriceEstimation(Request $request)
    {
        try {
            $validator_rules = [
                'selected_location' => 'required',
                'selected_employee' => 'required',
                'payment_plan' => 'required',
                'user_type' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
            $chargebee_plan_ids = $this->getChargebeePlanId($request->payment_plan,'new');
            $first_estimation_array = array(
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => 1
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['location_item_id'],
                        "quantity" => $request->selected_location
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['employee_item_id'],
                        "quantity" => $request->selected_employee
                    )
                ),
            );
            if($request->filled('entered_promocode')){
                // check promocode in database
                $promocode_data = Promocode::isActive()->where(['promo_code'=> $request->entered_promocode,'user_type'=>$request->user_type])->first();
                if(empty($promocode_data)){
                    return $this->error(Config::get('constants.USER.PROMO_NOT_VALID'), 200, ['error_type' => 'coupon']);
                }
                $first_estimation_array["couponIds"] = array($request->entered_promocode);
            }
            $first_estimate_response = Estimate::createSubItemEstimate($first_estimation_array);
            $first_estimate = $first_estimate_response->estimate();
            $transaction_fee_percentage = Config::get('app.transaction_fee_percentage');
            $transaction_fee = (int)(($first_estimate->invoiceEstimate->total*$transaction_fee_percentage)/100);
            $estimation_array = array(
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => 1
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['location_item_id'],
                        "quantity" => $request->selected_location
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['employee_item_id'],
                        "quantity" => $request->selected_employee
                    ),
                    array(
                        "itemPriceId" => $chargebee_plan_ids['transaction_fee_item_id'],
                        "unitPriceInDecimal" => ($transaction_fee/100)
                    ),
                ),
            );
            if($request->filled('selected_state') && $request->filled('zip_code')){
                $estimation_array["billingAddress"] = array(
                    "stateCode" => $request->selected_state['state_code'],
                    "zip" => $request->zip_code,
                    "country" => "US",
                );
                $estimation_array["customer"] = array(
                    "taxability" => ($request->user_type == 'Reseller') ? 'exempt' : 'taxable'
                );
            }
            if($request->filled('entered_promocode')){
                $estimation_array["couponIds"] = array($request->entered_promocode);
            }
            $estimate_response = Estimate::createSubItemEstimate($estimation_array);
            $estimate = $estimate_response->estimate();
            $taxes = '';
            if(isset($estimate->invoiceEstimate->taxes) && !empty($estimate->invoiceEstimate->taxes)){
                $taxes = [];
                foreach ($estimate->invoiceEstimate->taxes as $key => $value) {
                    $taxes[] = array(
                        'percentage' => $value->description,
                        'amount' => $value->amount
                    );
                }
            }
            $discount = '';
            if(isset($estimate->invoiceEstimate->discounts[0]) && !empty($estimate->invoiceEstimate->discounts[0])){
                $discount = array(
                    'id' => $estimate->invoiceEstimate->discounts[0]->entityId,
                    'promocode' => $estimate->invoiceEstimate->discounts[0]->description,
                    'discount_percentage' => (isset($estimate->invoiceEstimate->discounts[0]->discountPercentage))?$estimate->invoiceEstimate->discounts[0]->discountPercentage:'',
                    'discount_type' => $estimate->invoiceEstimate->discounts[0]->discountType,
                    'discount_amount' => $estimate->invoiceEstimate->discounts[0]->amount
                );
            }

            $final_response = array(
                'total' => $estimate->invoiceEstimate->total,
                'taxes' => $taxes,
                'discounts' => $discount,
                'transaction_fee' => $transaction_fee
            );
            return $this->success(Config::get('constants.SUCCESS'), 200, $final_response);
        } catch (\Exception $e) {
            Log::error('AuthController/getChargebeePriceEstimation() => '.$e->getMessage());
            Log::error('AuthController/getChargebeePriceEstimation()[data] => '.json_encode($request->all()));
            if ("coupon_ids[0]" == $e->getParam()) {
                return $this->error(Config::get('constants.USER.PROMO_NOT_VALID'), 200, ['error_type' => 'coupon']);
            }else if("destination_address_error" == $e->getJsonObject()['error_code']){
                return $this->error($e->getMessage(), 200, ['error_type' => 'zipcode']);
            }
            else if("invalid_request" == $e->getApiErrorCode()){
                return $this->error($e->getMessage(), 200, ['error_type' => 'other']);
            }else{
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, ['error_type' => 'other']);
            }
        }
    }

    /**
     * save product token
     *
     * @return \Illuminate\Http\Response
     */
    public function saveProductToken(Request $request)
    {
        try {
            $validator_rules = [
                'email' => 'required|email',
                'product' => 'required|in:oshahc',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $user = User::where('email', $request->email)->first();
            if ($user) {
                $token = \Str::random(50);
                UserProductToken::create(['user_id' => $user['id'], 'token' => $token, 'product' => $request->product]);

                return $this->success(Config::get('constants.SUCCESS'), 200, ['token' => $token, 'is_admin_panel_login' =>request()->session()->has('is_admin_panel_login')]);
            } else {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }

        } catch (\Exception $e) {
            Log::error('AuthController/saveProductToken() => '.$e->getMessage());
            Log::error('AuthController/saveProductToken()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get stripe setup intent
     *
     * @return \Illuminate\Http\Response
     */
    public function getStripeSetupIntent(Request $request)
    {
        try {
            Stripe\Stripe::setApiKey(Config::get('app.stripe_secret_key'));
            $setup_intent = Stripe\SetupIntent::Create([
                'payment_method_types' => ['card', 'us_bank_account'],
                'payment_method_options' => [
                    'us_bank_account' => [
                        'verification_method' => 'instant',
                        'financial_connections' => ['permissions' => ['payment_method']],
                    ],
                ],
            ]);

            return $this->success(Config::get('constants.SUCCESS'), 200, [
                'setup_intent_client_secret' => $setup_intent->client_secret,
            ]);
        } catch (\Exception $e) {
            Log::error('AuthController/getStripeSetupIntent() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get chrgbee price estimation for SRA only
     *
     * @return \Illuminate\Http\Response
     */
    public function getChargebeePriceEstimationForSRAOnly(Request $request)
    {
        try {
            $validator_rules = [
                'selected_location' => 'required',
                'user_type' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
            $chargebee_plan_ids = $this->getChargebeePlanId('yearly','new','sra_only');
            $first_estimation_array = array(
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => $request->selected_location
                    ),
                ),
            );
            if($request->filled('entered_promocode')){
                // check promocode in database
                $promocode_data = Promocode::isActive()->where(['promo_code'=> $request->entered_promocode,'user_type'=>$request->user_type])->first();
                if(empty($promocode_data)){
                    return $this->error(Config::get('constants.USER.PROMO_NOT_VALID'), 200, ['error_type' => 'coupon']);
                }
                $first_estimation_array["couponIds"] = array($request->entered_promocode);
            }
            $first_estimate_response = Estimate::createSubItemEstimate($first_estimation_array);
            $first_estimate = $first_estimate_response->estimate();
            $transaction_fee_percentage = Config::get('app.transaction_fee_percentage');
            $transaction_fee = (int)(($first_estimate->invoiceEstimate->total*$transaction_fee_percentage)/100);
            $estimation_array = array(
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => $request->selected_location
                    )
                ),
            );
            if($request->filled('selected_state') && $request->filled('zip_code')){
                $estimation_array["billingAddress"] = array(
                    "stateCode" => $request->selected_state['state_code'],
                    "zip" => $request->zip_code,
                    "country" => "US",
                );
                $estimation_array["customer"] = array(
                    "taxability" => ($request->user_type == 'Reseller') ? 'exempt' : 'taxable'
                );
            }
            if($request->filled('entered_promocode')){
                $estimation_array["couponIds"] = array($request->entered_promocode);
            }
            $estimate_response = Estimate::createSubItemEstimate($estimation_array);
            $estimate = $estimate_response->estimate();
            $taxes = '';
            if(isset($estimate->invoiceEstimate->taxes) && !empty($estimate->invoiceEstimate->taxes)){
                $taxes = [];
                foreach ($estimate->invoiceEstimate->taxes as $key => $value) {
                    $taxes[] = array(
                        'percentage' => $value->description,
                        'amount' => $value->amount
                    );
                }
            }
            $discount = '';
            if(isset($estimate->invoiceEstimate->discounts[0]) && !empty($estimate->invoiceEstimate->discounts[0])){
                $discount = array(
                    'id' => $estimate->invoiceEstimate->discounts[0]->entityId,
                    'promocode' => $estimate->invoiceEstimate->discounts[0]->description,
                    'discount_percentage' => (isset($estimate->invoiceEstimate->discounts[0]->discountPercentage))?$estimate->invoiceEstimate->discounts[0]->discountPercentage:'',
                    'discount_type' => $estimate->invoiceEstimate->discounts[0]->discountType,
                    'discount_amount' => $estimate->invoiceEstimate->discounts[0]->amount
                );
            }

            $final_response = array(
                'total' => $estimate->invoiceEstimate->total,
                'taxes' => $taxes,
                'discounts' => $discount,
                'transaction_fee' => $transaction_fee
            );
            return $this->success(Config::get('constants.SUCCESS'), 200, $final_response);
        } catch (\Exception $e) {
            Log::error('AuthController/getChargebeePriceEstimation() => '.$e->getMessage());
            Log::error('AuthController/getChargebeePriceEstimation()[data] => '.json_encode($request->all()));
            if ("coupon_ids[0]" == $e->getParam()) {
                return $this->error(Config::get('constants.USER.PROMO_NOT_VALID'), 200, ['error_type' => 'coupon']);
            }else if("destination_address_error" == $e->getJsonObject()['error_code']){
                return $this->error($e->getMessage(), 200, ['error_type' => 'zipcode']);
            }
            else if("invalid_request" == $e->getApiErrorCode()){
                return $this->error($e->getMessage(), 200, ['error_type' => 'other']);
            }else{
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, ['error_type' => 'other']);
            }
        }
    }

    
    /**
     * New user signup
     *
     * @return \Illuminate\Http\Response
     */
   public function doSignupForSRAOnly(Request $request)
    {
        $validator_rules = [
            'first_name' => 'required',
            'last_name' => 'required',
            'company_name' => 'required',
            'phone_number' => 'required_without:signup_call_type',
            'email' => ['required', 'email', 'unique:App\Models\AccountUser,email,NULL,id,deleted_at,NULL', 'unique:App\Models\User,email,NULL,id,deleted_at,NULL'],
            'password' => 'required|confirmed|min:6',
            'selected_state' => 'required',
            'zip_code' => 'required',
            'location_limit' => 'required',
            'timezone' => 'required',
            'stripe_payment_source_type' => 'required|in:card,bank',
            'stripe_payment_method' => 'required',
        ];
        
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
        }
        $stripe_customer_created = [];
        try {
            //OSHA HC email exists check
            $result_oshahc_check_email = Http::post(Config::get('app.osha_hc_url').'/check-email-already-signup', [
                'email' => $request->email,
            ]);
            if ($result_oshahc_check_email->successful() == true) {
                if ($result_oshahc_check_email->json()['status'] == 'Success') {
                    if ($result_oshahc_check_email->json()['data']['is_availabe'] == 1) {
                        return $this->error(Config::get('constants.USER.EMAIL_REGISTERED'), 200);
                    }
                } else {
                    return $this->error(Config::get('constants.USER.EMAIL_REGISTERED'), 200);
                }
            } else {
                return $this->error(Config::get('constants.USER.EMAIL_REGISTERED'), 200);
            }
            DB::beginTransaction();
            // stripe customer create
            Stripe\Stripe::setApiKey(Config::get('app.stripe_secret_key'));
            $stripe_customer_created = Stripe\Customer::create ([
                "name" => $request->company_name,
                "description" => $request->first_name.' '.$request->last_name.' :: '.$request->email.' :: '.$request->company_name,
                "email" => $request->email,
                'phone' => $request->phone_number,
                "invoice_settings" => ['default_payment_method' => $request->stripe_payment_method],
                "payment_method" => $request->stripe_payment_method,
            ]);
            $stripe_customer_source_id = $request->stripe_payment_method;
            
            // CB customer create
            Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
            $chargebee_customer_response = Customer::create(array(
                "firstName" => $request->first_name,
                "lastName" => $request->last_name,
                "email" => $request->email,
                "phone" => $request->phone_number,
                "company" => $request->company_name,
                "cf_Customer_Type" => ($request->partner_reseller_slug != null) ? 'Reseller' : 'Normal',
                "allowDirectDebit" => true,
                "billingAddress" => array(
                    "firstName" => $request->first_name,
                    "lastName" => $request->last_name,
                    "email" => $request->email,
                    'phone' => $request->phone_number,
                    "company" => $request->company_name,
                    "stateCode" => $request->selected_state['state_code'],
                    "state" => $request->selected_state['state_name'],
                    "zip" => $request->zip_code,
                    "country" => "US",
                ),
                "paymentMethod" => array(
                    'type' => ($request->stripe_payment_source_type == 'card')?'card':'direct_debit',
                    "gatewayAccountId" => Config::get('app.chargebee_gateway_account_id'),
                    "referenceId" => $stripe_customer_created->id."/".$stripe_customer_source_id
                ),
                "taxability" => ($request->partner_reseller_slug != null) ? 'exempt' : 'taxable'
            ));
            $chargebee_customer_created = $chargebee_customer_response->customer();
            $chargebee_payament_source_id = $chargebee_customer_created->primaryPaymentSourceId;
            
            $chargebee_plan_ids = $this->getChargebeePlanId('yearly','new','sra_only');
            // CB subscription create
            $subscription_array = array(
                "subscriptionItems" => array(
                    array(
                        "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                        "quantity" => $request->location_limit
                    )
                ),
                "contractTerm" => array(
                    "actionAtTermEnd" => "renew",
                    "cancellationCutoffPeriod" => "30"
                ),
                "paymentSourceId" => $chargebee_payament_source_id,
            );
            if($request->filled('promo_code')){
                // Check promocode in database
                $user_type = ($request->partner_reseller_slug != null) ? 'Reseller' : 'Normal';
                $promocode_data = Promocode::isActive()->where(['promo_code'=> $request->promo_code,'user_type'=>$user_type])->first();
                if(empty($promocode_data)){                    
                    return $this->error(Config::get('constants.USER.PROMO_NOT_VALID'), 200);
                }    
                $subscription_array["couponIds"] = array($request->promo_code);
            }
            $chargebee_subscription_response = Subscription::createWithItems($chargebee_customer_created->id ,$subscription_array);
            $chargebee_subscription_created = $chargebee_subscription_response->subscription();
            $chargebee_invoice_created = $chargebee_subscription_response->invoice();
            $account_verification_code = \Str::random(10);
            $primary_location_salesforce_unique_id = null;
            $primary_location_salesforce_unique_id_hash = null;
            if ($request->has('primary_location_salesforce_unique_id') && $request->has('primary_location_salesforce_unique_id_hash')) {
                if (md5($request->primary_location_salesforce_unique_id) == $request->primary_location_salesforce_unique_id_hash) {
                    $primary_location_salesforce_unique_id = $request->primary_location_salesforce_unique_id;
                    $primary_location_salesforce_unique_id_hash = $request->primary_location_salesforce_unique_id_hash;
                }
            }
            // create user in DB
            $partner = Partner::where('slug', $request->partner_reseller_slug)->first();
            $user_create_fileds = [
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'email' => $request->email,
                'password' =>($request->is_admin_panel_login=='1'? base64_decode($request->password) : bcrypt($request->password)),
                'company_name' => $request->company_name,
                'state_id' => $request->selected_state['id'],
                'phone_number' => $request->phone_number,
                'zip_code' => $request->zip_code,
                'is_active' => 0,
                'account_status' => 'Unfrozen',
                'account_verification_code' => $account_verification_code,
                'is_account_verified' => 0,
                'timezone' => $request->timezone,
                'partner_reseller_id' => $partner != null ? $partner->id : null,
                'contract_renewal_date' => Carbon::parse($chargebee_subscription_created->contractTerm->contractEnd)->format('Y-m-d'),
                'stripe_customer_id' => $stripe_customer_created->id,
                'chargebee_customer_id' => $chargebee_customer_created->id,
                'chargebee_subscription_id' => $chargebee_subscription_created->id,
                'chargebee_first_renewal_date' => Carbon::today()->format('Y-m-d'),
                'chargebe_addon_type' => 'new',
                'chargebe_first_contract_end_date' => Carbon::parse($chargebee_subscription_created->contractTerm->contractEnd)->subDay()->format('Y-m-d'),
                'is_sra_user' => 1,
                'primary_location_salesforce_unique_id' => $primary_location_salesforce_unique_id,
                'primary_location_salesforce_unique_id_hash' => $primary_location_salesforce_unique_id_hash,
            ];
            $user_created = User::create($user_create_fileds);
            if ($user_created && $chargebee_invoice_created && $chargebee_subscription_created) {
                     $storage_path = storage_path('app/public');
                    $promocode_data = null;
                    if($request->filled('promo_code')){
                        $promocode_data = Promocode::where('promo_code',$request->promo_code)->first();
                    }
                    $partner_data = [];
                    $partner_logo = '';
                    if ($partner != null) {
                        $partner_data = Partner::select('name', 'email', 'logo')->where('id', $partner->id)->where('is_reseller', 1)->first();
                        $partner_logo = $partner_data->logo;
                    }
                    $date = Carbon::now()->setTimezone($user_created->timezone);
                    $attachment_invoice = null;
                    $chargebee_invoice_download = Invoice::pdf($chargebee_invoice_created->id, ['dispositionType' => 'attachment']);
                    $chargebee_invoice_pdf = $chargebee_invoice_download->download();
                    $attachment_invoice = $storage_path.'/generatedpolicydocuments/'.'Abyde_Receipt_'.strtotime($user_created->created_at).'.pdf';
                    file_put_contents($attachment_invoice, file_get_contents($chargebee_invoice_pdf->downloadUrl));
                    
                    $emailTemplate = EmailTemplate::where('code', 'HCE-UE70')->first();
                    $email_vars = [
                        '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_created->first_name,
                        '{%ACTIVATE_ACCOUNT%}' => Config::get('app.url').'/login/'.$account_verification_code.'/'.base64_encode($user_created->id),
                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                    ];

                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $this->sendEmail($emailTemplate->code, $html, $user_created->email, Config::get('app.from_user_email'), $emailTemplate->subject, ($partner == null? $attachment_invoice : null),null,true,$partner_logo, $user_created->id);
                    
                    // create user invoice
                    $final_payment_price = (($chargebee_invoice_created->status == 'payment_due')?$chargebee_invoice_created->amountDue:$chargebee_invoice_created->amountPaid) / 100;
                    $charge_price = $final_payment_price;
                    $sales_tax = [];
                    $sales_tax_percentage = 0;
                    if(isset($chargebee_invoice_created->taxes) && !empty($chargebee_invoice_created->taxes)){
                        foreach ($chargebee_invoice_created->taxes as $key => $value) {
                            $sales_tax[] = array(
                                'amount' => $value->amount / 100
                            );
                        }
                        foreach ($chargebee_invoice_created->lineItems as $key => $value) {
                            $sales_tax_percentage  = (isset($value->taxRate))?$value->taxRate:0;
                        }
                    }
                    if(!empty($sales_tax)){
                        $final_payment_price = round($final_payment_price - array_sum(array_column($sales_tax, 'amount')), 2);
                    }
                    $final_discount_price = 0;
                    if(isset($chargebee_invoice_created->discounts[0]) && !empty($chargebee_invoice_created->discounts[0])){
                        $final_discount_price = $chargebee_invoice_created->discounts[0]->amount / 100;
                    }
                    if($final_discount_price > 0){
                        $final_payment_price = round($final_payment_price + $final_discount_price, 2);
                    }
                    // send emails
                    $date = Carbon::now()->setTimezone($user_created->timezone);
                    $emailTemplate = EmailTemplate::where('code', 'HCE-AE1')->first();
                    $email_vars = [
                        '{%CHRGEBEE_INVOICE_ID%}' => $chargebee_invoice_created->id,
                        '{%CHRGEBEE_CUSTOMER_ID%}' => $chargebee_customer_created->id,
                        '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_created->first_name,
                        '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user_created->last_name,
                        '{%COMPANY_NAME%}' => $user_created->company_name,
                        '{%PHONE_NUMBER%}' => $user_created->phone_number,
                        '{%SRA_ONLY%}' => 'YES',
                        '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_created->email,
                        '{%NUMBERS_OF_LOCATIONS%}' => $request->location_limit,
                        '{%EMPLOYEE_RANGE%}' => 0,
                        '{%PROMO_CODE%}' => ($request->promo_code) ? $request->promo_code : '',
                        '{%PROMO_CODE_PERCENTAGE%}' => ($promocode_data) ? $promocode_data->discount_percentage : '',
                        '{%PRICE%}' => $this->formatPrice($final_payment_price),
                        '{%PROMO_DISCOUNT%}' => $this->formatPrice($final_discount_price),
                        '{%DISCOUNT_PRICE%}' => $this->formatPrice(round(($final_payment_price - $final_discount_price), 2)),
                        '{%SALES_TAX_PERCENTAGE%}' => (!empty($sales_tax))?$sales_tax_percentage:0,
                        '{%SALES_TAX_AMOUNT%}' => $this->formatPrice((!empty($sales_tax))?array_sum(array_column($sales_tax, 'amount')):0),
                        '{%TRANSACTION_FEE_AMOUNT%}' => 0,
                        '{%PAYMENT_PRICE%}' => $this->formatPrice($charge_price),
                        '{%PAYMENT_TERM%}' => 'Yearly',
                        '{%PAYMENT_DATE%}' => Carbon::parse($date)->format('Y-m-d'),
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    if (! empty($partner_data)) {
                        $admin_subject = str_ireplace('{%RESELLER%}', $partner_data->name, $emailTemplate->reseller_subject);
                    } else {
                        $admin_subject = $emailTemplate->subject;
                    }
                    $this->sendEmail($emailTemplate->code, $html, Config::get('app.aw_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, $partner_logo, $user_created->id);

                    //send mail to partner start
                    if (! empty($partner_data) && $partner_data->email != '') {
                        $this->sendEmail($emailTemplate->code, $html, $partner_data->email, Config::get('app.from_admin_email'), $admin_subject, $attachment_invoice, null, true, $partner_logo, $user_created->id);
                    }
                    //send mail to partner end
                    
                    $emailTemplate = EmailTemplate::where('code', 'HCE-AE16')->first();
                    $email_vars = [
                        '{%CHRGEBEE_INVOICE_ID%}' => $chargebee_invoice_created->id,
                        '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_created->first_name,
                        '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user_created->last_name,
                        '{%COMPANY_NAME%}' => $user_created->company_name,
                        '{%PHONE_NUMBER%}' => $user_created->phone_number,
                        '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_created->email,
                        '{%PROMO_CODE%}' => ($request->promo_code) ? $request->promo_code : '',
                        '{%PRICE%}' => $this->formatPrice($final_payment_price),
                        '{%PROMO_DISCOUNT%}' => $this->formatPrice($final_discount_price),
                        '{%DISCOUNT_PRICE%}' => $this->formatPrice(round(($final_payment_price - $final_discount_price), 2)),
                        '{%SALES_TAX_PERCENTAGE%}' => (!empty($sales_tax))?$sales_tax_percentage:0,
                        '{%SALES_TAX_AMOUNT%}' => $this->formatPrice((!empty($sales_tax))?array_sum(array_column($sales_tax, 'amount')):0),
                        '{%TRANSACTION_FEE_AMOUNT%}' => 0,
                        '{%PAYMENT_PRICE%}' => $this->formatPrice($charge_price),
                        '{%PAYMENT_TERM%}' => 'Yearly',
                        '{%PAYMENT_DATE%}' => Carbon::parse($date)->format('Y-m-d'),
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    if (! empty($partner_data)) {
                        $admin_subject = str_ireplace('{%RESELLER%}', $partner_data->name, $emailTemplate->reseller_subject);
                    } else {
                        $admin_subject = $emailTemplate->subject;
                    }
                    $this->sendEmail($emailTemplate->code, $html, Config::get('app.finance_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, $partner_logo, $user_created->id);

                    DB::commit();
                    return $this->success(Config::get('constants.USER.SIGNUP_SUCCESS'), 200,  ['chargebee_invoice_id' => $chargebee_invoice_created->id]);
            } else {
                throw new \Exception('Signup - User not created');
            }
        } catch (Stripe\Exception\CardException $e) {
            DB::rollback();
            Log::error('AuthController/doSignupForSRAOnly() => '.$e->getError()->message);

            return $this->error($e->getError()->message, 200);
        } catch (PaymentException $e) {
            DB::rollback();
            Log::error('UpgradeController/doUpgrade() => ' . $e->getMessage());
            Log::error('UpgradeController/doUpgrade()[data] => ' . json_encode($request->all()));
            preg_match('/Error message:\s*\(.*?\)\s*(.*)/', $e->getMessage(), $matches);
            $error = isset($matches[1]) ? trim($matches[1]) : $e->getMessage();
            return $this->error($error, 200);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('AuthController/doSignupForSRAOnly() => '.$e->getMessage());

            return $this->error(Config::get('constants.USER.SIGNUP_FAILED'), 200);
        }
    }
    /************************** */
    /*API methods - end
    /*************************** */
}
