<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Imports\DisasterRespondersImport;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AccountUserLocationAccess;
use App\Models\BusinessAssociates;
use App\Models\BusinessAssociatesLocation;
use App\Models\DisasterCommunicationAuthority;
use App\Models\DisasterCommunicationEmployee;
use App\Models\DisasterCommunicationMedia;
use App\Models\DisasterCommunicationPartnerVendor;
use App\Models\DisasterCommunicationPatient;
use App\Models\DisasterRecoveryLead;
use App\Models\DisasterVendor;
use App\Models\DisasterVendorManual;
use App\Models\DisasterVulnerability;
use App\Models\EmailTemplate;
use App\Models\HipaaComplianceOfficer;
use App\Models\LocalFirstResponder;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\ModuleCompletedStatus;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use App\Traits\Notification;
use App\Traits\SendMail;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use Maatwebsite\Excel\HeadingRowImport;

class DisasterRecoveryPlanController extends Controller
{
    use ApiResponser, CheckAccessRight, GeneratePolicy, GetMainUserData, Notification, SendMail;

    /**
     * Disaster recovery plan Page
     *
     * @return \Illuminate\Http\Response
     */
    public function showDisasterRecoveryPlan($location_id = '')
    {
        if ($location_id != '') {
            $location_id = base64_decode($location_id, true);
            if ($location_id) {
                if ($this->checkAccessRight('disaster_recovery_plan', $location_id)) {
                    $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                    $company_info_completed = ModuleCompletedStatus::where(['location_id' => $location_id, 'module' => 'company_info', 'is_completed' => 1])->first();
                    $location = Location::where('id', $location_id)
                        ->with(['employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation'])
                        ->first();
                    if ($location == null) {
                        return redirect('/dashboard');
                    }
                    $check_is_ra_completed = ModuleCompletedStatus::where(
                        [
                            'location_id' => $location_id,
                            'module' => 'risk_analysis',
                            'is_completed' => 1,
                        ]
                    )->first();
                    if ($check_is_ra_completed && $hco && $company_info_completed && (count($location->employeePrimaryWorkLocation) > 0 || count($location->employeeSecondaryWorkLocation) > 0)) {
                        return view('app.pages.disaster_recovery_plan', ['location_id' => $location_id]);
                    } else {
                        return redirect('/dashboard');
                    }
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * Get details of disaster recovery plan
     *
     * @return \Illuminate\Http\Response
     */
    public function getDisasterRecoveryPlanByLocationId(Request $request, $location_id)
    {
        try {
            if ($location_id == '') {
                dd('Invalid parmas');
            }
            $user_data = $this->getMainAccountDetails();
            $user_id = $user_data->id;
            $data = Location::where([['id', '=', $location_id], ['user_id', '=', $user_id]])->count();
            if ($data == 1) {
                $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                $check_is_ra_completed = ModuleCompletedStatus::where(
                    [
                        'location_id' => $location_id,
                        'module' => 'risk_analysis',
                        'is_completed' => 1,
                    ]
                )->first();
                $location = Location::where('id', $location_id)
                    ->with(['employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation'])
                    ->first();
                $check_is_company_completed = ModuleCompletedStatus::where(
                    [
                        'location_id' => $location_id,
                        'module' => 'company_info',
                        'is_completed' => 1,
                    ]
                )->first();
                if ((count($location->employeePrimaryWorkLocation) == 0 && count($location->employeeSecondaryWorkLocation) == 0) || ! $check_is_company_completed || ! $hco || ! $check_is_ra_completed) {
                    return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
                }
                $local_first_responders = LocalFirstResponder::where('location_id', $location_id)->first();
                $disaster_vendors = DisasterVendor::where('location_id', $location_id)->first();
                $disaster_recovery_leads = DisasterRecoveryLead::where('location_id', $location_id)->with('employee')->get();
                $disaster_communication_employee = DisasterCommunicationEmployee::where('location_id', $location_id)->with('employee')->get();
                $disaster_communication_authority = DisasterCommunicationAuthority::where('location_id', $location_id)->with('employee')->get();
                $disaster_communication_partner_vendor = DisasterCommunicationPartnerVendor::where('location_id', $location_id)->with('employee')->get();
                $disaster_communication_patients = DisasterCommunicationPatient::where('location_id', $location_id)->with('employee')->get();
                $disaster_communication_media = DisasterCommunicationMedia::where('location_id', $location_id)->with('employee')->get();
                $disaster_vulnerabilities = DisasterVulnerability::where('location_id', $location_id)->first();
                $disaster_vendor_manual = DisasterVendorManual::where('location_id', $location_id)->get();
                $disaster_recovery_plan_module_status = ModuleCompletedStatus::where([['location_id', $location_id], ['module', 'disaster_recovery_plan']])->first();
                $data = [
                    'disaster_local_first_responders' => $local_first_responders,
                    'disaster_vendors' => $disaster_vendors,
                    'disaster_recovery_leads' => $disaster_recovery_leads,
                    'disaster_communication_employee' => $disaster_communication_employee,
                    'disaster_communication_authority' => $disaster_communication_authority,
                    'disaster_communication_partner_vendor' => $disaster_communication_partner_vendor,
                    'disaster_communication_patients' => $disaster_communication_patients,
                    'disaster_communication_media' => $disaster_communication_media,
                    'disaster_vulnerabilities' => $disaster_vulnerabilities,
                    'disaster_vendor_manual' => $disaster_vendor_manual,
                    'disaster_recovery_plan_module_status' => ($disaster_recovery_plan_module_status == null) ? false : true,
                    'sample_import_doc' => url('/sample_docs/disaster_recovery_plan_template.xlsx'),
                ];
                if ($disaster_vendors) {
                    $disaster_vendors['has_alarm_system_company'] =
                        $disaster_vendors['alarm_system_company'] == null &&
                        $disaster_vendors['alarm_system_company_phone'] == null
                        ? true
                        : false;
                    $disaster_vendors['has_data_backup_vendor'] =
                        $disaster_vendors['data_backup_vendor'] == null &&
                        $disaster_vendors['data_backup_vendor_phone'] == null
                        ? true
                        : false;
                    $disaster_vendors['has_landlord_property_manager'] =
                        $disaster_vendors['landlord_property_manager'] == null &&
                        $disaster_vendors['landlord_property_manager_phone'] == null
                        ? true
                        : false;
                    $disaster_vendors['has_practice_management_software'] =
                        $disaster_vendors['practice_management_software'] == null &&
                        $disaster_vendors['practice_management_software_phone'] == null
                        ? true
                        : false;
                    $disaster_vendors['has_ehr_software'] =
                        $disaster_vendors['ehr_software'] == null &&
                        $disaster_vendors['ehr_software_phone'] == null
                        ? true
                        : false;
                    $disaster_vendors['has_it_vendor'] =
                        $disaster_vendors['it_vendor'] == null &&
                        $disaster_vendors['it_vendor_phone'] == null
                        ? true
                        : false;
                }
                if ($disaster_recovery_plan_module_status && $disaster_recovery_plan_module_status['is_completed'] == 1) {
                    $data['first_time_disaster_added'] = false;
                } else {
                    $data['first_time_disaster_added'] = true;
                }

                return $this->success(Config::get('constants.SUCCESS'), 200, $data);
            } else {
                return redirect('/dashboard');
            }
        } catch (\Exception $e) {
            Log::error('DisasterRecoveryPlanController/getDisasterRecoveryPlanByLocationId() => '.$e->getMessage());
            Log::error('DisasterRecoveryPlanController/getDisasterRecoveryPlanByLocationId()[data] => '.json_encode(['location_id' => $location_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Add or edit details of disaster recovery plan
     *
     * @return \Illuminate\Http\Response
     */
    public function addEditDisasterRecoveryPlan(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'disaster_vendors' => 'required',
                'disaster_vulnerability' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $updated = false;
            DB::beginTransaction();
            $location_id = $request['location_id'];
            $drp_versioning = false;

            if (! empty($request['disaster_communication_authority_new']) || ! empty($request['disaster_communication_authority_removed']) || ! empty($request['disaster_communication_employee_new']) || ! empty($request['disaster_communication_employee_removed']) || ! empty($request['disaster_communication_media_new']) || ! empty($request['disaster_communication_media_new']) || ! empty($request['disaster_communication_partner_vendor_new']) || ! empty($request['disaster_communication_partner_vendor_removed']) || ! empty($request['disaster_communication_patient_new']) || ! empty($request['disaster_communication_patient_removed']) || ! empty($request['disaster_recovery_lead_new']) || ! empty($request['disaster_recovery_lead_removed'])) {
                $this->addPolicyVersionData('DRP', $location_id);
                $drp_versioning = true;
            }

            // local first responders
            if ($request->has('disaster_local_first_responders')) {
                $local_first_responders_data = $request['disaster_local_first_responders'];
                $local_first_responders = LocalFirstResponder::where('location_id', $location_id)->first();
                if ($local_first_responders) {
                    $local_first_responders_arr = $local_first_responders->toArray();
                } else {
                    $local_first_responders_arr = [];
                }
                if ($local_first_responders_arr != $local_first_responders_data && ! $drp_versioning) {
                    $this->addPolicyVersionData('DRP', $location_id);
                    $drp_versioning = true;
                }

                if ($local_first_responders) {
                    $local_first_responders->update($local_first_responders_data);
                } else {
                    $local_first_responders_data['location_id'] = $location_id;
                    $local_first_responders = LocalFirstResponder::create($local_first_responders_data);
                }
            }
            // disaster vendors
            $disaster_vendors_data = $request['disaster_vendors'];
            $disaster_vendors = DisasterVendor::where('location_id', $location_id)->first();
            if ($disaster_vendors) {
                $disaster_vendors_arr = $disaster_vendors->toArray();
            } else {
                $disaster_vendors_arr = [];
            }
            if ($disaster_vendors && ($disaster_vendors_arr['data_backup_vendor'] != $disaster_vendors_data['data_backup_vendor'] ||
            $disaster_vendors_arr['data_backup_vendor_phone'] != $disaster_vendors_data['data_backup_vendor_phone'] ||
            $disaster_vendors_arr['data_backup_vendor_location'] != $disaster_vendors_data['data_backup_vendor_location'] ||
            $disaster_vendors_arr['landlord_property_manager'] != $disaster_vendors_data['landlord_property_manager'] ||
            $disaster_vendors_arr['landlord_property_manager_phone'] != $disaster_vendors_data['landlord_property_manager_phone'] || $disaster_vendors_arr['practice_management_software'] != $disaster_vendors_data['practice_management_software']) && ! $drp_versioning) {
                $this->addPolicyVersionData('DRP', $location_id);
                $drp_versioning = true;
            }
            if ($disaster_vendors && $disaster_vendors_arr['alarm_system_company'] != $disaster_vendors_data['alarm_system_company']) {
                $this->addPolicyVersionData('SAP', $location_id);
            }
            if ($disaster_vendors) {
                $updated = true;
                $disaster_vendors->update($disaster_vendors_data);
            } else {
                $disaster_vendors_data['location_id'] = $location_id;
                $disaster_vendors = DisasterVendor::create($disaster_vendors_data);
            }

            // disaster recovery lead(s)
            if ($request->has('disaster_recovery_lead_new') && ! empty($request['disaster_recovery_lead_new'])) {
                $disaster_recovery_lead_data = [];
                foreach ($request['disaster_recovery_lead_new'] as $row) {
                    $disaster_recovery_lead_data[] = [
                        'location_id' => $location_id,
                        'employee_id' => $row['id'],
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ];
                }
                DisasterRecoveryLead::insert($disaster_recovery_lead_data);
            }
            if ($request->has('disaster_recovery_lead_removed') && ! empty($request['disaster_recovery_lead_removed'])) {
                DisasterRecoveryLead::whereIn('employee_id', $request['disaster_recovery_lead_removed'])
                    ->where('location_id', $location_id)->get()->each(function ($drl) {
                        $drl->delete();
                    });
            }
            // communication to employees
            if ($request->has('disaster_communication_employee_new') && ! empty($request['disaster_communication_employee_new'])) {
                $disaster_communication_employee_data = [];
                foreach ($request['disaster_communication_employee_new'] as $row) {
                    $disaster_communication_employee_data[] = [
                        'location_id' => $location_id,
                        'employee_id' => $row['id'],
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ];
                }
                DisasterCommunicationEmployee::insert($disaster_communication_employee_data);
            }
            if ($request->has('disaster_communication_employee_removed') && ! empty($request['disaster_communication_employee_removed'])) {
                DisasterCommunicationEmployee::whereIn('employee_id', $request['disaster_communication_employee_removed'])
                    ->where('location_id', $location_id)->get()->each(function ($dce) {
                        $dce->delete();
                    });
            }
            // communication to authorities
            if ($request->has('disaster_communication_authority_new') && ! empty($request['disaster_communication_authority_new'])) {
                $disaster_communication_authority_data = [];
                foreach ($request['disaster_communication_authority_new'] as $row) {
                    $disaster_communication_authority_data[] = [
                        'location_id' => $location_id,
                        'employee_id' => $row['id'],
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ];
                }
                DisasterCommunicationAuthority::insert($disaster_communication_authority_data);
            }
            if ($request->has('disaster_communication_authority_removed') && ! empty($request['disaster_communication_authority_removed'])) {
                DisasterCommunicationAuthority::whereIn('employee_id', $request['disaster_communication_authority_removed'])
                    ->where('location_id', $location_id)->get()->each(function ($dca) {
                        $dca->delete();
                    });
            }
            // communication to all partners and vendors
            if ($request->has('disaster_communication_partner_vendor_new') && ! empty($request['disaster_communication_partner_vendor_new'])) {
                $disaster_communication_partner_vendor_data = [];
                foreach ($request['disaster_communication_partner_vendor_new'] as $row) {
                    $disaster_communication_partner_vendor_data[] = [
                        'location_id' => $location_id,
                        'employee_id' => $row['id'],
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ];
                }
                DisasterCommunicationPartnerVendor::insert($disaster_communication_partner_vendor_data);
            }
            if ($request->has('disaster_communication_partner_vendor_removed') && ! empty($request['disaster_communication_partner_vendor_removed'])) {
                DisasterCommunicationPartnerVendor::whereIn('employee_id', $request['disaster_communication_partner_vendor_removed'])
                    ->where('location_id', $location_id)->get()->each(function ($dcpv) {
                        $dcpv->delete();
                    });
            }
            // communication to patients
            if ($request->has('disaster_communication_patient_new') && ! empty($request['disaster_communication_patient_new'])) {
                $disaster_communication_patient_data = [];
                foreach ($request['disaster_communication_patient_new'] as $row) {
                    $disaster_communication_patient_data[] = [
                        'location_id' => $location_id,
                        'employee_id' => $row['id'],
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ];
                }
                DisasterCommunicationPatient::insert($disaster_communication_patient_data);
            }
            if ($request->has('disaster_communication_patient_removed') && ! empty($request['disaster_communication_patient_removed'])) {
                DisasterCommunicationPatient::whereIn('employee_id', $request['disaster_communication_patient_removed'])
                    ->where('location_id', $location_id)->get()->each(function ($dcp) {
                        $dcp->delete();
                    });
            }
            // communication to media
            if ($request->has('disaster_communication_media_new') && ! empty($request['disaster_communication_media_new'])) {
                $disaster_communication_media_data = [];
                foreach ($request['disaster_communication_media_new'] as $row) {
                    $disaster_communication_media_data[] = [
                        'location_id' => $location_id,
                        'employee_id' => $row['id'],
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ];
                }
                DisasterCommunicationMedia::insert($disaster_communication_media_data);
            }
            if ($request->has('disaster_communication_media_removed') && ! empty($request['disaster_communication_media_removed'])) {
                DisasterCommunicationMedia::whereIn('employee_id', $request['disaster_communication_media_removed'])
                    ->where('location_id', $location_id)->get()->each(function ($dcp) {
                        $dcp->delete();
                    });
            }
            // disaster vulnerability
            $disaster_vulnerability_data = $request['disaster_vulnerability'];
            $disaster_vulnerability = DisasterVulnerability::where('location_id', $location_id)->first();
            if ($disaster_vulnerability) {
                $disaster_vulnerability_arr = $disaster_vulnerability->toArray();
            } else {
                $disaster_vulnerability_arr = [];
            }
            if ($disaster_vulnerability_arr != $disaster_vulnerability_data && ! $drp_versioning) {
                $this->addPolicyVersionData('DRP', $location_id);
                $drp_versioning = true;
            }
            if ($disaster_vulnerability) {
                $disaster_vulnerability->update($disaster_vulnerability_data);
            } else {
                $disaster_vulnerability_data['location_id'] = $location_id;
                $disaster_vulnerability = DisasterVulnerability::create($disaster_vulnerability_data);
            }
            // disaster vendor manuals
            if ($request->has('disaster_vendor_manual') && ! empty($request['disaster_vendor_manual'])) {
                foreach ($request['disaster_vendor_manual'] as $row) {
                    $vendor_data['location_id'] = $location_id;
                    $vendor_data['vendor_name'] = $row['vendor_name'];
                    $vendor_data['vendor_phone'] = $row['vendor_phone'];
                    $vendor_data['vendor_responsibility'] = $row['vendor_responsibility'];
                    if (isset($row['id'])) {
                        $vendor = DisasterVendorManual::where('id', $row['id'])->first();
                        if (($vendor->vendor_name != $vendor_data['vendor_name'] || $vendor->vendor_phone != $vendor_data['vendor_phone']) && ! $drp_versioning) {
                            $this->addPolicyVersionData('DRP', $location_id);
                            $drp_versioning = true;
                        }
                        DisasterVendorManual::where('id', $row['id'])->update($vendor_data);
                    } else {
                        if (! $drp_versioning) {
                            $this->addPolicyVersionData('DRP', $location_id);
                            $drp_versioning = true;
                        }
                        DisasterVendorManual::create($vendor_data);
                    }
                }
            }

            $disaster_recovery_plan_module_status = ModuleCompletedStatus::where([['location_id', $location_id], ['module', 'disaster_recovery_plan']])->first();
            if ($disaster_recovery_plan_module_status) {
                $disaster_recovery_plan_module_status->is_completed = 1;
                $disaster_recovery_plan_module_status->save();
            } else {
                ModuleCompletedStatus::create([
                    'location_id' => $location_id,
                    'module' => 'disaster_recovery_plan',
                    'is_completed' => 1,
                ]);

                SendLocationDataToSalesForce::dispatch($location_id);
                $notification_HCE_AN10 = $this->getNotificationByCode('HCE-AN10');
                if ($this->checkNotificationAlreadyAdded($notification_HCE_AN10->code, $location_id) == 0) {
                    $notification_HCE_AN10_data = [
                        'location_id' => $location_id,
                        'notification_id' => $notification_HCE_AN10['id'],
                    ];
                    $this->createNotification($notification_HCE_AN10_data);
                }

                $notification_HCE_AN11 = $this->getNotificationByCode('HCE-AN11');
                if ($this->checkNotificationAlreadyAdded($notification_HCE_AN11->code, $location_id) == 0) {
                    $notification_HCE_AN11_data = [
                        'location_id' => $location_id,
                        'notification_id' => $notification_HCE_AN11['id'],
                    ];
                    $this->createNotification($notification_HCE_AN11_data);
                }

                $location_data = Location::where('id', $request['location_id'])->with(['user.reseller'])->first();
                // if($location_data->created_at < new DateTime('2024-12-20')){
                $business_associates_list = BusinessAssociates::where('user_id', $location_data->user_id)->get();
                foreach ($business_associates_list as $key => $ba_data) {
                    $check = BusinessAssociatesLocation::where('location_id', $request['location_id'])
                        ->where('business_associate_id', $ba_data->id)
                        ->first();
                    if (! $check) {
                        BusinessAssociatesLocation::create([
                            'business_associate_id' => $ba_data->id,
                            'location_id' => $request['location_id'],
                        ]);
                    }
                }
                // }
            }
            DB::commit();
            if ($updated) {
                $message = Config::get('constants.DISASTERRECOVERYPLAN.UPDATED');
            } else {
                $message = Config::get('constants.DISASTERRECOVERYPLAN.ADDED');
            }

            return $this->success($message, 200);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('DisasterRecoveryPlanController/addEditDisasterRecoveryPlan() => '.$e->getMessage());
            Log::error('DisasterRecoveryPlanController/addEditDisasterRecoveryPlan()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200, $e->getMessage());
        }
    }

    /**
     * Import location from file
     *
     * @return \Illuminate\Http\Response
     */
    public function importResponders(Request $request)
    {
        $validator_rules = [
            'location_id' => 'required',
            'import_file' => 'required|mimes:xls,xlsx',
        ];

        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.DISASTERRECOVERYPLAN.INVALID_IMPORT_FILE'), 200, $validator_check->errors()->all());
        }

        $headings = (new HeadingRowImport)->toArray($request['import_file']);
        $heading_array = [
            'local_police_department_name',
            'local_police_department_phone',
            'local_fire_department_name',
            'local_fire_department_phone',
            'alarm_system_company',
            'alarm_system_company_phone',
            'data_backup_vendor',
            'data_backup_vendor_phone',
            'data_backup_vendor_location',
            'landlord_property_manager',
            'landlord_property_manager_phone',
            'practice_management_software',
            'practice_management_software_phone',
            'ehr_software',
            'ehr_software_phone',
            'it_vendor',
            'it_vendor_phone',
            'hurricane',
            'flood',
            'tornado',
            'earthquake',
            'fire',
            'rogue_staff_vendor',
            'theft',
            'malicious_software_virus',
            'utility_interruption_failure',
            'public_health_emergency',
            'have_lab',
        ];
        $missing_heading = array_diff($heading_array, $headings[0][0]);
        if ($missing_heading) {
            return $this->error(Config::get('constants.DISASTERRECOVERYPLAN.IMPORT_FILE_INVALID_TEMPLETE'), 200);
        }

        try {
            if ($request->has('import_file')) {
                $import = new DisasterRespondersImport;
                $import->location_id = $request['location_id'];
                $import->import($request['import_file']);
                if ($import->failures()->isNotEmpty()) {
                    $error = [];
                    $i = 0;
                    foreach ($import->failures() as $failure) {
                        foreach ($failure->errors() as $value) {
                            $error[$i] = $value.'Row No :'.$failure->row();
                            $i++;
                        }
                    }
                    Log::error('DisasterRecoveryPlanController/importResponders(ImportValidation) => '.json_encode($error));

                    return $this->error(Config::get('constants.DISASTERRECOVERYPLAN.IMPORT_ERROR'), 200, $error);
                }
                if ($import->row_count == 0) {
                    return $this->error(Config::get('constants.DISASTERRECOVERYPLAN.IMPORT_ERROR'), 200);
                }
                if ($import->row_count > 0) {
                    return $this->success(Config::get('constants.DISASTERRECOVERYPLAN.IMPORTED'), 200);
                }
            }
        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            Log::error('DisasterRecoveryPlanController/importResponders(LimitExeception) => '.$e->getMessage());
            Log::error('DisasterRecoveryPlanController/importResponders(LimitExeception)[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.DISASTERRECOVERYPLAN.IMPORT_ERROR'), 200);
        } catch (ValidationException $e) {
            Log::error('DisasterRecoveryPlanController/importResponders(FileInvalidTemplete) => '.$e->getMessage());
            Log::error('DisasterRecoveryPlanController/importResponders(FileInvalidTemplete)[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.DISASTERRECOVERYPLAN.IMPORT_FILE_INVALID_TEMPLETE'), 200);
        } catch (\Exception $e) {
            Log::error('DisasterRecoveryPlanController/importResponders() => '.$e->getMessage());
            Log::error('DisasterRecoveryPlanController/importResponders()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.DISASTERRECOVERYPLAN.IMPORT_ERROR'), 200);
        }
    }

    /**
     * Delete disaster vendor manuals by id
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deleteVendorManualById($vendor_manual_id = '')
    {
        try {
            if ($vendor_manual_id == '') {
                dd('Invalid parmas');
            }
            DB::beginTransaction();
            $disaster_vendor_manual = DisasterVendorManual::where('id', $vendor_manual_id)->first();
            $this->addPolicyVersionData('DRP', $disaster_vendor_manual['location_id']);
            $disaster_vendor_manual->delete();

            DB::commit();

            return $this->success(Config::get('constants.DISASTERRECOVERYPLAN.VENDORDELETE'), 200);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('DisasterRecoveryPlanController/deleteVendorManualById() => '.$e->getMessage());
            Log::error('DisasterRecoveryPlanController/deleteVendorManualById()[data] => '.json_encode(['vendor_manual_id' => $vendor_manual_id]));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get last updated disaster for dashboard
     */
    public function getLastUpdatedDisaster($location_id)
    {
        $is_avail = LocationModuleLastUpdate::where(['location_id' => $location_id, 'module_name' => 'disaster'])->first();

        return ($is_avail) ? $is_avail->updated_at : '';
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
