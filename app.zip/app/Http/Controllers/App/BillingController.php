<?php

namespace App\Http\Controllers\App;

use App\Http\Controllers\Controller;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\EmailTemplate;
use App\Models\FullUpgradeSraUserDetail;
use App\Models\Location;
use App\Models\User;
use App\Traits\ApiResponser;
use App\Traits\ChargebeePlan;
use App\Traits\CheckAccessRight;
use App\Traits\GetLoginUserData;
use App\Traits\GetMainUserData;
use App\Traits\PricingHelper;
use App\Traits\SendMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Models\Customer;
use ChargeBee\ChargeBee\Models\Invoice;
use ChargeBee\ChargeBee\Models\PaymentSource;
use ChargeBee\ChargeBee\Models\Subscription;
use Stripe;

class BillingController extends Controller
{
    use ApiResponser, CheckAccessRight, GetLoginUserData, GetMainUserData, PricingHelper, SendMail, ChargebeePlan;

    /**
     * Billing page
     *
     * @return \Illuminate\Http\Response
     */
    public function showBilling(Request $request)
    {
        $user_data = $this->getLoginUserData();
        if ($this->checkAccessRight('billing') && ($user_data->partner_reseller_id == null || ($user_data->partner_reseller_id != null && $user_data->is_admin_panel_login == 'true'))) {
            return view('app.pages.billing');
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start
    /*************************** */

    /**
     * get invoice list
     *
     * @return \Illuminate\Http\Response
     */
    public function allInvoiceList(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $limit = $request->has('per_page') ? request('per_page') : Config::get('constants.PER_PAGE');
            Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
           $full_upgrade_sra_only_details = FullUpgradeSraUserDetail::where('user_id',$user_data->id)->first();
            if($full_upgrade_sra_only_details != Null){
                $invoice_param = [
                    "limit" => $limit,
                    "customerId[is]" => $user_data->chargebee_customer_id,
                    "subscriptionId[in]" =>[$user_data->chargebee_subscription_id,$full_upgrade_sra_only_details->sra_only_subscription_id],
                    "sortBy[desc]" => "date"
                ];
            }else{
                $invoice_param = [
                    "limit" => $limit,
                    "customerId[is]" => $user_data->chargebee_customer_id,
                    "subscriptionId[is]" => $user_data->chargebee_subscription_id,
                    "sortBy[desc]" => "date"
                ];
            }
            if($request->has('next_offset')){
                $invoice_param['offset'] = request('next_offset');
            }
            $all_invoice = Invoice::all($invoice_param);
            $next_offset = $all_invoice->nextOffset();
            $invoice_list = [];
            foreach($all_invoice as $entry){
                $invoice = $entry->invoice();
                $invoice_list[] = [
                    'id' => $invoice->id,
                    'payment_status' => $invoice->status,
                    'created_at' => Carbon::parse($invoice->date)->format("Y-m-d")
                ];
            }
            $data = [
                'list' => $invoice_list,
                'next_offset' => $next_offset
            ];
            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('BillingController/allInvoiceList() => '.$e->getMessage());
            Log::error('BillingController/allInvoiceList()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get payment method
     *
     * @return \Illuminate\Http\Response
     */
    public function getPaymentMethod(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            $subscription = $this->getSubscriptionDetails($user_data->chargebee_subscription_id,true);
            if($subscription && $subscription != null && !empty($subscription['payment_source'])){
                $paymentSource = $subscription['payment_source'];
                if(! empty($paymentSource['card'])){
                    $final_array = [
                        'type' => 'card',
                        'name' => (isset($paymentSource['card']['first_name'])?$paymentSource['card']['first_name']:'').' '.(isset($paymentSource['card']['last_name'])?$paymentSource['card']['last_name']:''),
                        'brand' => $paymentSource['card']['brand'],
                        'exp_month' => $paymentSource['card']['expiry_month'],
                        'exp_year' => $paymentSource['card']['expiry_year'],
                        'last4' => $paymentSource['card']['last4'],
                        'account_holder_name' => '',
                        'bank_name' => ''
                    ];
                    return $this->success(Config::get('constants.SUCCESS'), 200, $final_array);
                } else if (! empty($paymentSource['bank_account'])) {
                    $final_array = [
                        'type' => 'bank_account',
                        'name' => (isset($paymentSource['bank_account']['first_name'])?$paymentSource['bank_account']['first_name']:'').' '.(isset($paymentSource['bank_account']['last_name'])?$paymentSource['bank_account']['last_name']:''),
                        'brand' => '',
                        'exp_month' => '',
                        'exp_year' => '',
                        'last4' => $paymentSource['bank_account']['last4'],
                        'account_holder_name' => $paymentSource['bank_account']['name_on_account'],
                        'bank_name' => $paymentSource['bank_account']['bank_name']
                    ];
                    return $this->success(Config::get('constants.SUCCESS'), 200, $final_array);
                }
            }
        } catch (\Exception $e) {
            Log::error('BillingController/getPaymentMethod() => '.$e->getMessage());
            return $this->error(Config::get('constants.BILLING.FAIL_GET_PAYMENT_METHOD'), 200);
        }
    }

    /**
     * download invoice
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadInvoice(Request $request)
    {
        try {
            $validator_rules = [
                'invoice_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
            $invoice_response = Invoice::pdf($request->invoice_id);
            $invoice_download = $invoice_response->download();
            $invoice_url = $invoice_download->downloadUrl;
            return $this->success(Config::get('constants.SUCCESS'), 200, ['invoice_url' => $invoice_url, 'file_name' => 'Abyde_Receipt_'.$request->invoice_id.'.pdf']);
        } catch (\Exception $e) {
            Log::error('BillingController/downloadInvoice() => '.$e->getMessage());
            Log::error('BillingController/downloadInvoice()[data] => '.json_encode($request->all()));
            return $this->error(Config::get('constants.BILLING.DOWNLOAD_FAILED'), 200);
        }
    }

    /**
     * add new card
     *
     * @return \Illuminate\Http\Response
     */
    public function addNewPaymentMethod(Request $request)
    {
        try {
            $validator_rules = [
                'payment_method_type' => 'required|in:card,bank',
                'payment_method_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $user_data = $this->getMainAccountDetails();
            Stripe\Stripe::setApiKey(Config::get('app.stripe_secret_key'));
            $stripe_customer = Stripe\Customer::retrieve($user_data->stripe_customer_id);
            $stripe_pm = Stripe\PaymentMethod::retrieve($request->payment_method_id);
            if ($stripe_customer && $stripe_pm) {
                $stripe_customer_pm = $stripe_pm->attach([
                    'customer' => $stripe_customer->id,
                ]);
                Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
                $chargebee_payment_source_result = PaymentSource::createUsingPermanentToken(array(
                    "customerId" => $user_data->chargebee_customer_id,
                    "gatewayAccountId" => Config::get('app.chargebee_gateway_account_id'),
                    "referenceId" => $user_data->stripe_customer_id.'/'.$request->payment_method_id,
                    "type" => $request->payment_method_type == 'card'?"card":'direct_debit',
                ));
                $paymentSource = $chargebee_payment_source_result->paymentSource(); 
                // $stripe_type = $this->determineStripePaymentSourceMethod($user_payment_method->stripe_payment_source_id);
                // if($stripe_type == 'payment_intent'){
                //     $is_old_pm = Stripe\PaymentMethod::retrieve($user_payment_method->stripe_payment_source_id);
                //     if($is_old_pm){
                //         $is_old_pm->detach();
                //     }
                // }else{
                //     $is_old_source = $stripe_customer->sources->retrieve($user_payment_method->stripe_payment_source_id);
                //     if($is_old_source){
                //         $is_old_source->delete();
                //     }
                // }
                // PaymentSource::deleteLocal($user_payment_method->chargebee_payment_source_id);
                $unpaid_due_invoice_list = Invoice::all([
                    "customerId[is]" => $user_data->chargebee_customer_id,
                    "subscriptionId[is]" => $user_data->chargebee_subscription_id,
                    "status[in]" => ["not_paid", "payment_due"]
                ]);
                foreach ($unpaid_due_invoice_list as $key => $value) {
                    $each_invoice = $value->invoice();
                    $each_invoice_paid_response = Invoice::collectPayment($each_invoice->id, array(
                        "paymentSourceId" => $paymentSource->id
                    ));
                }
                Subscription::overrideBillingProfile($user_data->chargebee_subscription_id,array(
                   "paymentSourceId" => $paymentSource->id,
                ));
                $emailTemplate = EmailTemplate::where('code', 'HCE-UE21')->first();
                $email_vars = [
                    '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_data->first_name,
                    '{%COMPANY_NAME%}' => $user_data->company_name,
                    '{%PAYMENT_METHOD%}' => $request->payment_method_type,
                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                    '{%SUPPORT_PHONE%}' => Config::get('app.support_phone_number'),
                    '{%SUPPORT_PHONE_NUMBER_DISPLAY%}' => Config::get('app.support_phone_number_display'),
                ];
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
                $this->sendEmail($emailTemplate->code, $html, $user_data->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                $emailTemplate = EmailTemplate::where('code', 'HCE-AE3')->first();
                $email_vars = [
                    '{%USER_FIRST_NAME%}' => $user_data->first_name,
                    '{%USER_LAST_NAME%}' => $user_data->last_name,
                    '{%COMPANY_NAME%}' => $user_data->company_name,
                    '{%EMAIL%}' => $user_data->email,
                    '{%PAYMENT_METHOD%}' => ucfirst(($request->payment_method_type == 'card') ? 'card' : 'bank'),
                    '{%LAST_4_DIGITS%}' => ($request->payment_method_type == 'card') ? $stripe_pm->card->last4 : $stripe_pm->us_bank_account->last4,
                ];

                if ($user_data->partner_reseller_id != null) {
                    $admin_subject = str_ireplace('{%RESELLER%}', $user_data->reseller->name, $emailTemplate->reseller_subject);
                } else {
                    $admin_subject = $emailTemplate->subject;
                }
                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                $this->sendEmail($emailTemplate->code, $html, Config::get('app.finance_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                DB::commit();

                return $this->success(Config::get('constants.BILLING.PAYMENT_METHOD_ADDED'), 200);
            } else {
                throw new \Exception('Stripe - Customer/Payment method not found');
            }
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('BillingController/addNewPaymentMethod() => '.$e->getMessage());
            Log::error('BillingController/addNewPaymentMethod()[data] => '.json_encode($request->all()));
            return $this->error($e->getMessage(), 200);
        }
    }

    /**
     * get stripe setup intent
     *
     * @return \Illuminate\Http\Response
     */
    public function getStripeSetupIntent(Request $request)
    {
        try {
            $user_data = $this->getMainAccountDetails();
            Stripe\Stripe::setApiKey(Config::get('app.stripe_secret_key'));
            $setup_intent = Stripe\SetupIntent::Create([
                'payment_method_types' => ['card', 'us_bank_account'],
                'payment_method_options' => [
                    'us_bank_account' => [
                        'verification_method' => 'instant',
                        'financial_connections' => ['permissions' => ['payment_method']],
                    ],
                ],
            ]);

            return $this->success(Config::get('constants.SUCCESS'), 200, [
                'setup_intent_client_secret' => $setup_intent->client_secret,
                'user_data' => $user_data,
            ]);
        } catch (\Exception $e) {
            Log::error('BillingController/getStripeSetupIntent() => '.$e->getMessage());
            Log::error('BillingController/getStripeSetupIntent()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end
    /*************************** */
}
