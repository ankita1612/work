<?php

namespace App\Http\Controllers\App;

use App\Exports\ExportAssetLog;
use App\Http\Controllers\Controller;
use App\Imports\AssetLogImport;
use App\Models\AbydeDriveArchiveFile;
use App\Models\AbydeDriveArchiveFolder;
use App\Models\AbydeDriveArchiveFolderLocation;
use App\Models\AccessLog;
use App\Models\AssetLog;
use App\Models\AssetLogDeviceType;
use App\Models\AssetLogDisposalStatus;
use App\Models\AssetLogEncryption;
use App\Models\AssetLogEphiAccess;
use App\Models\AssetLogOperatingLocation;
use App\Models\AssetLogOperatingSystem;
use App\Models\BreachLog;
use App\Models\BreachLogIncidentReporter;
use App\Models\BreachLogIncidentReporterType;
use App\Models\BreachLogPhi;
use App\Models\BreachLogPhiType;
use App\Models\BreachLogRaAttempt;
use App\Models\BreachLogRaQuestion;
use App\Models\BusinessAssociates;
use App\Models\EmailTemplate;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\ModuleCompletedStatus;
use App\Models\State;
use App\Traits\ApiResponser;
use App\Traits\CheckAccessRight;
use App\Traits\FileUpload;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use App\Traits\SendMail;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Excel as ExcelC;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\HeadingRowImport;

class HipaaLogController extends Controller
{
    use ApiResponser, CheckAccessRight, FileUpload, GeneratePolicy, GetMainUserData, SendMail;

    /**
     * show hipaa logs
     *
     * @return \Illuminate\Http\Response
     */
    public function showHipaaLog(Request $request, $location_id = '', $current_tab = '')
    {
        if ($location_id != '') {
            $location_id = base64_decode($location_id, true);
            if ($location_id) {
                if ($this->checkAccessRight('hipaa_log', $location_id)) {
                    $hco = HipaaComplianceOfficer::where('location_id', $location_id)->first();
                    $company_info_completed = ModuleCompletedStatus::where(['location_id' => $location_id, 'module' => 'company_info', 'is_completed' => 1])->first();
                    $location = Location::where('id', $location_id)
                        ->with(['employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation'])
                        ->first();
                    if ($location == null) {
                        return redirect('/dashboard');
                    }
                    $check_is_ra_completed = ModuleCompletedStatus::where(
                        [
                            'location_id' => $location_id,
                            'module' => 'risk_analysis',
                            'is_completed' => 1,
                        ]
                    )->first();
                    if ($check_is_ra_completed && $hco && $company_info_completed && (count($location->employeePrimaryWorkLocation) > 0 || count($location->employeeSecondaryWorkLocation) > 0)) {
                        return view('app.pages.hipaalog', ['location_id' => $location_id, 'current_tab' => $current_tab]);
                    } else {
                        return redirect('/dashboard');
                    }
                } else {
                    return redirect('/dashboard');
                }
            } else {
                return redirect('/dashboard');
            }
        } else {
            return redirect('/dashboard');
        }
    }

    /**
     * show breach log quiz page
     *
     * @return \Illuminate\Http\Response
     */
    public function showBreachLogQuiz(Request $request, $breach_log_id = '')
    {
        $breach_log_id = base64_decode($breach_log_id, true);
        if ($breach_log_id) {
            $breach_data = BreachLog::where('id', $breach_log_id)->first();

            return view('app.pages.breachlogquiz', ['breach_log_id' => $breach_log_id, 'location_id' => $breach_data->location_id]);
        } else {
            return redirect('/dashboard');
        }
    }

    /************************** */
    /*API methods - start - Access log
    /*************************** */

    /**
     * List Access Log
     *
     *
     * @return \Illuminate\Http\Response
     */
    public function getAccessLogByLocationID(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $hco = HipaaComplianceOfficer::where('location_id', $request['location_id'])->first();
            $company_info_completed = ModuleCompletedStatus::where(['location_id' => $request['location_id'], 'module' => 'company_info', 'is_completed' => 1])->first();
            $location = Location::where('id', $request['location_id'])
                ->with(['employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation'])
                ->first();
            $check_is_sra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $request['location_id'],
                    'module' => 'risk_analysis',
                    'is_completed' => 1,
                ]
            )->first();
            if ((count($location->employeePrimaryWorkLocation) == 0 && count($location->employeeSecondaryWorkLocation) == 0) || ! $check_is_sra_completed || ! $hco || ! $company_info_completed) {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
            $limit = $request->has('per_page') ? request('per_page') : Config::get('constants.PER_PAGE');
            $access_log_list = AccessLog::where('location_id', $request['location_id']);
            $access_log_list = $access_log_list->orderBy('created_at', 'desc');
            $access_log_list = $access_log_list->paginate($limit);

            return $this->success(Config::get('constants.ACCESS_LOG.ACCESS_LOG_LIST'), 200, $access_log_list);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/getAccessLogByLocationID() => '.$e->getMessage());
            Log::error('HipaaLogController/getAccessLogByLocationID()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Add Access Log
     *
     * @return \Illuminate\Http\Response
     */
    public function addAccessLog(Request $request)
    {
        try {
            $validator_rules = [
                'name' => 'required',
                'company_name' => 'required',
                'date_log_in' => 'required|date_format:Y-m-d',
                'time_log_in' => 'required|date_format:H:i',
                'time_log_out' => 'required|date_format:H:i|after_or_equal:time_log_in',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $this->addPolicyVersionData('AL', $input_fields['location_id']);
            $access_log_created = AccessLog::create($input_fields);
            DB::commit();

            return $this->success(Config::get('constants.ACCESS_LOG.ACCESS_LOG_ADDED'), 200, $access_log_created);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/addAccessLog() => '.$e->getMessage());
            Log::error('HipaaLogController/addAccessLog()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Edit Access Log
     *
     * @return \Illuminate\Http\Response
     */
    public function editAccessLog(Request $request)
    {
        try {
            $validator_rules = [
                'access_log_id' => 'required',
                'name' => 'required',
                'company_name' => 'required',
                'date_log_in' => 'required|date_format:Y-m-d',
                'time_log_in' => 'required|date_format:H:i',
                'time_log_out' => 'required|date_format:H:i|after_or_equal:time_log_in',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $access_log = AccessLog::findorFail($input_fields['access_log_id']);
            if ($input_fields['name'] != $access_log['name'] || $input_fields['company_name'] != $access_log['company_name'] || $input_fields['date_log_in'] != $access_log['date_log_in'] || $access_log['time_log_in'] != $input_fields['time_log_in'].':00' || $access_log['time_log_out'] != $input_fields['time_log_out'].':00') {
                $this->addPolicyVersionData('AL', $access_log['location_id']);
            }
            $access_log->update($input_fields);
            $access_log_updated = AccessLog::findorFail($input_fields['access_log_id']);
            DB::commit();

            return $this->success(Config::get('constants.ACCESS_LOG.ACCESS_LOG_EDIT'), 200, $access_log_updated);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/editAccessLog() => '.$e->getMessage());
            Log::error('HipaaLogController/editAccessLog()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Delete Access Log
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteAccessLog(Request $request)
    {
        try {
            $validator_rules = [
                'access_log_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $input_fields = $request->all();
            $access_log = AccessLog::findorFail($input_fields['access_log_id']);
            $this->addPolicyVersionData('AL', $access_log['location_id']);
            DB::beginTransaction();
            if ($access_log) {
                $access_log->delete();
                $this->updateDeletedAccessLogPdf($access_log->location_id);
            }
            DB::commit();

            return $this->success(Config::get('constants.ACCESS_LOG.ACCESS_LOG_DELETE'), 200);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/deleteAccessLog() => '.$e->getMessage());
            Log::error('HipaaLogController/deleteAccessLog()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function updateDeletedAccessLogPdf($location_id)
    {
        $trashed_access_log = AccessLog::onlyTrashed()
            ->where('location_id', $location_id)
            ->orderBy('deleted_at', 'desc')
            ->get()->toArray();

        if (count($trashed_access_log) == 0) {
            return;
        }

        $location = Location::where('id', $location_id)->select('company_name')->first();

        $abyde_drive_folder = AbydeDriveArchiveFolder::where('folder_name', 'Hipaa Logs')->first();

        $access_log_folder = AbydeDriveArchiveFolder::updateOrCreate([
            'folder_name' => 'Access Logs',
            'parent_folder_id' => $abyde_drive_folder->id,
        ]);

        $access_log_folder_location = AbydeDriveArchiveFolderLocation::updateOrCreate([
            'archive_folder_id' => $access_log_folder->id,
            'location_id' => $location_id,
        ]);

        $file_name = 'Access_logs'.uniqid().'.pdf';
        $file_path = '/abyde_drive_archive/access_logs/'.$location_id.'/'.$file_name;
        $delete_directory_path = '/abyde_drive_archive/access_logs/'.$location_id;
        $delete_file = Storage::disk('s3')->deleteDirectory($delete_directory_path);
        $pdf = PDF::loadView('reports/accesslog', [
            'trashed_access_log' => $trashed_access_log,
            'company_name' => $location->company_name,
        ]);
        $is_uploaded = Storage::disk('s3')->put($file_path, $pdf->output(), ['ContentType' => 'application/pdf']);
        if ($is_uploaded) {
            $file_size = $this->getReadableFilesize(Storage::disk('s3')->size($file_path));

            AbydeDriveArchiveFile::updateOrCreate(
                [
                    'title' => 'Access_Log',
                    'archive_folder_id' => $access_log_folder_location->id,
                ],
                [
                    'file_name' => $file_name,
                    'file_size' => $file_size,
                    'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                ]
            );
        }
    }

    /************************** */
    /*API methods - end - Access log
    /*************************** */

    /************************** */
    /*API methods - start - Breach log
    /*************************** */

    /**
     * Check whether there is previous log or not
     *
     * @return \Illuminate\Http\Response
     */
    public function checkPreviousBreachLog(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $data = AbydeDriveArchiveFolderLocation::where('location_id', $request->location_id)
                ->whereHas('abydeDriveArchiveFolder', function ($q) {
                    $q->where('folder_name', 'Breach Logs');
                })->with('abydeDriveArchiveFolder:id,parent_folder_id')->first();

            return $this->success(Config::get('constants.SUCCESS'), 200, $data);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/checkPreviousBreachLog() => '.$e->getMessage());
            Log::error('HipaaLogController/checkPreviousBreachLog()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get all Breach log list
     *
     * @return \Illuminate\Http\Response
     */
    public function getBreachLogByLocationID(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];

            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $hco = HipaaComplianceOfficer::where('location_id', $request['location_id'])->first();
            $company_info_completed = ModuleCompletedStatus::where(['location_id' => $request['location_id'], 'module' => 'company_info', 'is_completed' => 1])->first();
            $location = Location::where('id', $request['location_id'])
                ->with(['employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation'])
                ->first();
            $check_is_sra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $request['location_id'],
                    'module' => 'risk_analysis',
                    'is_completed' => 1,
                ]
            )->first();
            if ((count($location->employeePrimaryWorkLocation) == 0 && count($location->employeeSecondaryWorkLocation) == 0) || ! $check_is_sra_completed || ! $hco || ! $company_info_completed) {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
            $limit = $request->has('per_page') ? request('per_page') : Config::get('constants.PER_PAGE');
            $breach_log_list = BreachLog::where('location_id', $request['location_id'])
                ->whereYear('created_at', gmdate('Y'))
                ->with([
                    'location:id,location_nickname',
                    'phiType:id,breach_log_id,phi_type_id,other_details',
                    'phiType.PhiTypeName:id,name',
                    'incidentReport:id,breach_log_id,incident_reporter_id,incident_date',
                    'incidentReport.incidentReporterType:id,name',
                    'raAttemptQuestions',
                ]);
            if (isset($request['sort_by']) && ! empty($request['sort_by']) && isset($request['sort_by_dir']) && ! empty($request['sort_by_dir'])) {
                $breach_log_list = $breach_log_list->orderBy($request['sort_by'], $request['sort_by_dir'])->orderBy('id', $request['sort_by_dir']);
            } else {
                $breach_log_list = $breach_log_list->orderBy('created_at', 'DESC');
            }
            $breach_log_list = $breach_log_list->paginate($limit);

            return $this->success(Config::get('constants.BREACH_LOG.BREACH_LOG_LIST'), 200, $breach_log_list);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/getBreachLogByLocationID() => '.$e->getMessage());
            Log::error('HipaaLogController/getBreachLogByLocationID()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Add Breach Log
     *
     * @return \Illuminate\Http\Response
     */
    public function addBreachLog(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'incident_reporter_name' => 'required',
                'discovered_by' => 'required',
                'discovered_start_date' => 'required|date_format:Y-m-d',
                'discovered_end_date' => 'required|date_format:Y-m-d|after_or_equal:discovered_start_date',
                'individuals_affected' => 'required|in:less_than_500,500_or_more_than_500',
                'type_of_incident' => 'required|in:hacking_it_incident,improper_disposal,loss,theft,unauthorized_access',
                'breach_start_date' => 'required|date_format:Y-m-d',
                'breach_end_date' => 'required|date_format:Y-m-d|after_or_equal:breach_start_date',
                'selected_phi_list' => 'required|array',
                'selected_incident_list' => 'required|array',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $breach_log_created = BreachLog::create($input_fields);
            $breach_log_created->phiType()->createMany($input_fields['selected_phi_list']);
            $breach_log_created->incidentReport()->createMany($input_fields['selected_incident_list']);
            DB::commit();
            $location = Location::where('id', $request['location_id'])
                ->with('user')
                ->first();
                $type_of_incident = [
                    'hacking_it_incident' => 'Hacking/IT',
                    'improper_disposal' => 'Improper Disposal',
                    'loss' => 'Loss of PHI',
                    'theft' => 'Theft of PHI',
                    'unauthorized_access' => 'Unauthorized Access/Disclosure'
                ];
                $emailTemplate_HCE_AE25 = EmailTemplate::where('code', 'HCE-AE25')->first();
                    $email_vars = [
                        '{%COMPANY_NAME%}' => $location->company_name,
                        '{%LOCATION_NAME%}' => $location->location_nickname,
                        '{%PRIMARY_COMPLIANCE_OFFICER_NAME%}' => $location->user->first_name.' '.$location->user->last_name,
                        '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $location->user->email,
                        '{%INCIDENT_TYPE%}' => $type_of_incident[$request->input('type_of_incident')],
                        '{%INDIVIDUALS_AFFECTED%}' => $request->input('individuals_affected') == 'less_than_500' ? 'Less than 500' : '500 or more',
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate_HCE_AE25->body);
                    if ($location->user->partner_reseller_id != null) {
                            $admin_subject = str_ireplace('{%RESELLER%}', $location->user->reseller->name, $emailTemplate_HCE_AE25->reseller_subject);
                        } else {
                            $admin_subject = $emailTemplate_HCE_AE25->subject;
                        }
            $this->sendEmail($emailTemplate_HCE_AE25->code, $html, Config::get('app.cs_group_email'), Config::get('app.from_admin_email'), $admin_subject, null, null,true,($location->user->partner_reseller_id != null ? $location->user->reseller->logo : null));
            return $this->success(Config::get('constants.BREACH_LOG.BREACH_LOG_ADDED'), 200, $breach_log_created);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/addBreachLog() => '.$e->getMessage());
            Log::error('HipaaLogController/addBreachLog()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Edit Breach Log
     *
     * @return \Illuminate\Http\Response
     */
    public function editBreachLog(Request $request)
    {
        try {
            $validator_rules = [
                'breach_log_id' => 'required',
                'location_id' => 'required',
                'incident_reporter_name' => 'required',
                'discovered_by' => 'required',
                'discovered_start_date' => 'required|date_format:Y-m-d',
                'discovered_end_date' => 'required|date_format:Y-m-d|after_or_equal:discovered_start_date',
                'individuals_affected' => 'required|in:less_than_500,500_or_more_than_500',
                'type_of_incident' => 'required|in:hacking_it_incident,improper_disposal,loss,theft,unauthorized_access',
                'breach_start_date' => 'required|date_format:Y-m-d',
                'breach_end_date' => 'required|date_format:Y-m-d|after_or_equal:breach_start_date',
                'selected_phi_list_new' => 'array|sometimes',
                'selected_phi_list_removed' => 'array|sometimes',
                'selected_incident_list_new' => 'array|sometimes',
                'selected_incident_list_removed' => 'array|sometimes',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $input_fields['updated_at'] = Carbon::now()->format('Y-m-d H:i:s');
            $breach_log = BreachLog::findorFail($input_fields['breach_log_id']);
            $is_any_changes_found = 0;
            if (
                $request->incident_reporter_name !== $breach_log->incident_reporter_name
                || $request->discovered_by !== $breach_log->discovered_by
                || $request->discovered_start_date !== $breach_log->discovered_start_date
                || $request->discovered_end_date !== $breach_log->discovered_end_date
                || $request->breach_start_date !== $breach_log->breach_start_date
                || $request->breach_end_date !== $breach_log->breach_end_date
                || $request->individuals_affected !== $breach_log->individuals_affected
                || $request->type_of_incident !== $breach_log->type_of_incident
                || count($request->selected_phi_list_new) > 0
                || count($request->selected_phi_list_removed) > 0
                || count($request->selected_incident_list_new) > 0
                || count($request->selected_incident_list_removed) > 0
            ) {
                $is_any_changes_found = 1;
            }
            $breach_log_updated = $breach_log->update($input_fields);
            if ($breach_log_updated) {
                if ($request->has('selected_phi_list_removed')) {
                    BreachLogPhi::whereIn('phi_type_id', $request['selected_phi_list_removed'])
                        ->where('breach_log_id', $input_fields['breach_log_id'])->get()->each(function ($blp) {
                            $blp->delete();
                        });
                }
                if ($request->has('selected_phi_list_new')) {
                    $breach_log->phiType()->createMany($input_fields['selected_phi_list_new']);
                }

                if ($request->has('selected_incident_list_removed')) {
                    BreachLogIncidentReporter::whereIn('incident_reporter_id', $request['selected_incident_list_removed'])
                        ->where('breach_log_id', $input_fields['breach_log_id'])->get()->each(function ($bli) {
                            $bli->delete();
                        });
                }
                if ($request->has('selected_incident_list_new')) {
                    $breach_log->incidentReport()->createMany($input_fields['selected_incident_list_new']);
                }
                if ($is_any_changes_found == 1) {
                    $breach_log->raAttemptQuestions()->delete();
                }
                $updated_breach_log_data = BreachLog::where('location_id', $request['location_id'])
                    ->where('id', $request->breach_log_id)
                    ->whereYear('created_at', gmdate('Y'))
                    ->with([
                        'location:id,location_nickname',
                        'phiType:id,breach_log_id,phi_type_id,other_details',
                        'phiType.PhiTypeName:id,name',
                        'incidentReport:id,breach_log_id,incident_reporter_id,incident_date',
                        'incidentReport.incidentReporterType:id,name',
                        'raAttemptQuestions',
                    ])->first();
                DB::commit();

                return $this->success(Config::get('constants.BREACH_LOG.BREACH_LOG_EDIT'), 200, $updated_breach_log_data);
            }
        } catch (\Exception $e) {
            Log::error('HipaaLogController/editBreachLog() => '.$e->getMessage());
            Log::error('HipaaLogController/editBreachLog()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get all Phi type list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getPhiTypeList()
    {
        try {
            $data = BreachLogPhiType::select('id as phi_type_id', 'name')->get();

            return $this->success('Success', 200, $data);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/getPhiTypeList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get all Incident Reporter list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getIncidentReporterList()
    {
        try {
            $data = BreachLogIncidentReporterType::select('id as incident_reporter_id', 'name')->get();

            return $this->success('Success', 200, $data);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/getIncidentReporterList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * download breach log pdf
     *
     * @return \Illuminate\Http\Response
     */
    public function downloadBreachLogPDF(Request $request)
    {
        try {
            $validator_rules = [
                'breach_log_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $breach_log = BreachLog::with([
                'location.state.breachDetail',
                'location.hipaaComplianceOfficer',
                'phiType.PhiTypeName',
                'incidentReport.incidentReporterType',
                'raAttemptQuestions.question',
                'raAttemptQuestions.answer',
            ])->findOrFail($request->breach_log_id);
            $public_path = public_path();
            $storage_path = storage_path('app/public');
            if (count($breach_log->raAttemptQuestions) > 0) {
                // breach log with RA completed
                $policy_filename = 'BreachLogReportRA.docx';
                $policy_file_path = $public_path.'/policydocuments/'.$policy_filename;
                $generated_policy_directory_path = $storage_path.'/generatedpolicydocuments/';
                $gnerated_policy_doc_name = $breach_log->id.'_'.$policy_filename;
                $gnerated_policy_pdf_name = str_replace('docx', 'pdf', $gnerated_policy_doc_name);
                $gnerated_policy_file_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_policy_doc_name;
                $gnerated_policy_pdf_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_policy_pdf_name;
                $gnerated_policy_pdf_url = asset('storage/generatedpolicydocuments/' . $gnerated_policy_pdf_name);
                $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($policy_file_path);
                $generalController = new GeneralController;
                $logo_data = $generalController->_addCompanyLogoOnCoverPage($breach_log->location);
                $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
                $generalController->_removeTempCompanyLogo($breach_log->location, $logo_data['temp_file_path']);
                $template_processor->setValue('COMPANY_NAME', htmlspecialchars($breach_log->location->company_name));
                $template_processor->setValue('LAST_MODIFIED_DATE', date('F j, Y', strtotime($breach_log->updated_at)));
                if ($breach_log->type_of_incident == 'hacking_it_incident') {
                    $type_of_incident = 'Hacking/IT';
                }
                if ($breach_log->type_of_incident == 'improper_disposal') {
                    $type_of_incident = 'Improper Disposal';
                }
                if ($breach_log->type_of_incident == 'loss') {
                    $type_of_incident = 'Loss of PHI';
                }
                if ($breach_log->type_of_incident == 'theft') {
                    $type_of_incident = 'Theft of PHI';
                }
                if ($breach_log->type_of_incident == 'unauthorized_access') {
                    $type_of_incident = 'Unauthorized Access/Disclosure';
                }
                $template_processor->setValue('BREACH_TYPE', htmlspecialchars($type_of_incident));
                $template_processor->setValue('BREACH_DATE', date('F j, Y', strtotime($breach_log->breach_start_date)));
                $template_processor->setValue('CLIENT_NAME', htmlspecialchars($breach_log->location->company_name));
                $template_processor->setValue('CLIENT_ADDRESS', htmlspecialchars($breach_log->location->address));
                $template_processor->setValue('CLIENT_PHONE_NUMBER', $breach_log->location->phone_no);
                $template_processor->setValue('CLIENT_CITY', htmlspecialchars($breach_log->location->city));
                $template_processor->setValue('CLIENT_STATE', htmlspecialchars($breach_log->location->state->state_name));
                $template_processor->setValue('CLIENT_ZIP', $breach_log->location->zip_code);
                $template_processor->setValue('BREACH_REPORTER', htmlspecialchars($breach_log->incident_reporter_name));
                $BN2_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN2S1', $breach_log->raAttemptQuestions);
                if ($BN2_RESPONSE == '') {
                    $BN2_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN2S2', $breach_log->raAttemptQuestions);
                }
                $template_processor->setValue('BN2_RESPONSE', htmlspecialchars(lcfirst($BN2_RESPONSE->answer->answer)));
                $template_processor->setValue('BREACH_DISCOVERY', htmlspecialchars($breach_log->discovered_by));
                $template_processor->setValue('HCO_NAME', htmlspecialchars($breach_log->location->hipaaComplianceOfficer->hco->first_name.' '.$breach_log->location->hipaaComplianceOfficer->hco->last_name));
                $template_processor->setValue('HCO_EMAIL', htmlspecialchars($breach_log->location->hipaaComplianceOfficer->hco->email));
                $template_processor->setValue('HCO_PHONE_NUMBER', $breach_log->location->phone_no);
                $BN1S2_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN1S2', $breach_log->raAttemptQuestions);
                if ($BN1S2_RESPONSE) {
                    if ($BN1S2_RESPONSE->custom_answer == 'Other') {
                        $BN1S2S1_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN1S2S1', $breach_log->raAttemptQuestions);
                        $BN1S2S2_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN1S2S2', $breach_log->raAttemptQuestions);
                        $BN1S2S3_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN1S2S3', $breach_log->raAttemptQuestions);
                        $BN1S2S4_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN1S2S4', $breach_log->raAttemptQuestions);
                        $template_processor->setValue('BN1_A2_RESPONSE_TITLE', 'THIRD PARTY BUSINESS CONTACT INFORMATION</w:t><w:br/><w:t>');
                        $template_processor->setValue('BN1_A2_RESPONSE_LIST1', '
</w:t><w:br/><w:t>As this breach occurred at or by '.htmlspecialchars($BN1S2S1_RESPONSE->custom_answer).' and '.htmlspecialchars($breach_log->location->company_name).' is filing this breach on behalf of '.htmlspecialchars($BN1S2S1_RESPONSE->custom_answer).'. '.htmlspecialchars($BN1S2S1_RESPONSE->custom_answer)."'s contact information is listed below:</w:t><w:br/><w:t></w:t><w:br/><w:t>
</w:t><w:tab/><w:t>●   Name of Business Associate: ".htmlspecialchars($BN1S2S1_RESPONSE->custom_answer).'</w:t><w:br/><w:t>
</w:t><w:tab/><w:t>●   Address:</w:t><w:br/><w:t>
</w:t><w:tab/><w:t></w:t><w:br/><w:t></w:t><w:tab/><w:t>'.htmlspecialchars($BN1S2S2_RESPONSE->custom_answer).'

');
                        $template_processor->setValue(
                            'BN1_A2_RESPONSE_LIST2',
                            '</w:t><w:br/><w:t></w:t><w:br/><w:t>'.
                                htmlspecialchars($BN1S2S1_RESPONSE->custom_answer)."'s contact information is listed below:</w:t><w:br/><w:t></w:t><w:br/><w:t>
 </w:t><w:tab/><w:t>●   Name: ".htmlspecialchars($BN1S2S3_RESPONSE->custom_answer).'</w:t><w:br/><w:t>
 </w:t><w:tab/><w:t>●   Email: '.htmlspecialchars($BN1S2S4_RESPONSE->custom_answer).'</w:t><w:br/><w:t>'
                        );
                    } else {
                        $BA_DATA = $this->_getBAData($BN1S2_RESPONSE->custom_answer);
                        if (empty($BA_DATA)) {
                            $BA_DATA['name'] = '';
                            $BA_DATA['email'] = '';
                        }

                        $template_processor->setValue('BN1_A2_RESPONSE_TITLE', 'THIRD PARTY BUSINESS CONTACT INFORMATION</w:t><w:br/><w:t>');
                        $template_processor->setValue('BN1_A2_RESPONSE_LIST1', '
</w:t><w:br/><w:t>As this breach occurred at or by '.htmlspecialchars($BA_DATA['name']).' and '.htmlspecialchars($breach_log->location->company_name).' is filing this breach on behalf of '.htmlspecialchars($BA_DATA['name']).'. '.htmlspecialchars($BA_DATA['name'])."'s contact information is listed below:</w:t><w:br/><w:t></w:t><w:br/><w:t>
</w:t><w:tab/><w:t>●   Name of Business Associate: ".htmlspecialchars($BA_DATA['name']).'</w:t><w:br/><w:t>
</w:t><w:tab/><w:t>●   Address:</w:t><w:br/><w:t>
</w:t><w:br/><w:t></w:t><w:br/><w:t></w:t><w:tab/><w:t>'.htmlspecialchars(($BA_DATA['name'] != '') ? $breach_log->location->address : '').'

');
                        $template_processor->setValue(
                            'BN1_A2_RESPONSE_LIST2',
                            '</w:t><w:br/><w:t></w:t><w:br/><w:t>'.
                                htmlspecialchars($BA_DATA['name'])."'s contact information is listed below:</w:t><w:br/><w:t></w:t><w:br/><w:t>
</w:t><w:tab/><w:t>●   Name: ".htmlspecialchars($BA_DATA['name']).'</w:t><w:br/><w:t>
</w:t><w:tab/><w:t>●   Email: '.htmlspecialchars($BA_DATA['email']).'</w:t><w:br/><w:t>'
                        );
                    }
                } else {
                    $template_processor->setValue('BN1_A2_RESPONSE_TITLE', '');
                    $template_processor->setValue('BN1_A2_RESPONSE_LIST1', '');
                    $template_processor->setValue('BN1_A2_RESPONSE_LIST2', '');
                }
                if ($breach_log->individuals_affected == 'less_than_500') {
                    $individuals_affected = 'less than 500 individuals';
                }
                if ($breach_log->individuals_affected == '500_or_more_than_500') {
                    $individuals_affected = '500 or more individuals';
                }
                $template_processor->setValue('INDIVIDUALS', htmlspecialchars($individuals_affected));
                $BN4_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN4', $breach_log->raAttemptQuestions);
                $template_processor->setValue('BN4_RESPONSE', htmlspecialchars($BN4_RESPONSE->custom_answer));
                $BN3_answers = $this->_getAttemptDataFromQuestionCode('BN3', $breach_log->raAttemptQuestions, 'all');
                $BN3_answers_array = [];
                foreach ($BN3_answers as $key => $value) {
                    $BN3_answers_array[] = $value->answer->answer;
                }
                if (in_array('Other', $BN3_answers_array)) {
                    if (($key = array_search('Other', $BN3_answers_array)) !== false) {
                        unset($BN3_answers_array[$key]);
                    }
                    $BN3S1_answer = $this->_getAttemptDataFromQuestionCode('BN3S1', $breach_log->raAttemptQuestions);
                    $BN3_answers_array[] = $BN3S1_answer->custom_answer;
                }
                $BN3_RESPONSE = implode(', ', $BN3_answers_array);
                $template_processor->setValue('BN3_RESPONSE', htmlspecialchars($BN3_RESPONSE));
                $template_processor->setValue('BREACH_START', date('F j, Y', strtotime($breach_log->breach_start_date)));
                $template_processor->setValue('BREACH_END', date('F j, Y', strtotime($breach_log->breach_end_date)));
                $template_processor->setValue('DISCOVERY_START', date('F j, Y', strtotime($breach_log->discovered_start_date)));
                $template_processor->setValue('DISCOVERY_END', date('F j, Y', strtotime($breach_log->discovered_end_date)));
                $phis_array = [];
                $PHI_OTHER_TEXT = '';
                foreach ($breach_log->phiType as $key => $value) {
                    if ($value->phiTypeName->name == 'Other') {
                        $PHI_OTHER_TEXT = '</w:t><w:br/><w:t>
Other types of Protected Health Information included or potentially included: '.htmlspecialchars($value->other_details);
                    } else {
                        $phis_array[] = $value->phiTypeName->name;
                    }
                }
                if (in_array('Other', $phis_array)) {
                    if (($key = array_search('Other', $phis_array)) !== false) {
                        unset($phis_array[$key]);
                    }
                }
                $PHI_LIST = '';
                foreach ($phis_array as $key => $value) {
                    $PHI_LIST .= '</w:t><w:tab/><w:t>●  '.ucfirst($value).'</w:t><w:br/><w:t>';
                }
                $template_processor->setValue('PHI', $PHI_LIST);
                $template_processor->setValue('PHI_OTHER_TEXT', $PHI_OTHER_TEXT);
                $BN5_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN5', $breach_log->raAttemptQuestions);
                $template_processor->setValue('BN5_RESPONSE', htmlspecialchars($BN5_RESPONSE->custom_answer));
                $BN8S1_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN8S1', $breach_log->raAttemptQuestions);
                if ($BN8S1_RESPONSE) {
                    $BN8S3_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN8S3', $breach_log->raAttemptQuestions);
                    if ($BN8S3_RESPONSE->answer->answer_code == 'A1') {
                        $BN8S3 = 'required for fewer than 10 individuals.';
                    } elseif ($BN8S3_RESPONSE->answer->answer_code == 'A2') {
                        $BN8S3 = 'required for more than 10 individuals.';
                    } else {
                        $BN8S3 = 'not required.';
                    }
                    $BN8S4_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN8S4', $breach_log->raAttemptQuestions);
                    if ($BN8S4_RESPONSE->answer->answer_code == 'A1') {
                        $BN8S4S1_answers = $this->_getAttemptDataFromQuestionCode('BN8S4S1', $breach_log->raAttemptQuestions, 'all');
                        $state_array = [];
                        foreach ($BN8S4S1_answers as $key => $value) {
                            $state_array[] = $this->_getStateName($value->custom_answer);
                        }
                        sort($state_array);
                        $BN8S4 = 'required for '.implode(', ', $state_array).'.';
                    } else {
                        $BN8S4 = 'not required for this breach.';
                    }
                    $BN8_RESPONSE = '</w:t><w:br/><w:t>
</w:t><w:tab/><w:t>●  Individual notice to affected individuals was provided on '.date('m/d/Y', strtotime($BN8S1_RESPONSE->custom_answer)).'</w:t><w:br/><w:t>
</w:t><w:tab/><w:t>●  Substitute notice was '.$BN8S3.'</w:t><w:br/><w:t>
</w:t><w:tab/><w:t>●  Media notice was '.$BN8S4;
                } else {
                    $BN8S2_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN8S2', $breach_log->raAttemptQuestions);
                    $BN8_RESPONSE = '</w:t><w:br/><w:t>
</w:t><w:tab/><w:t>●  Individual notice to affected individuals will be provided starting on '.date('m/d/Y', strtotime($BN8S2_RESPONSE->custom_answer)).' (projected).';
                }
                $template_processor->setValue('BN8_RESPONSE', $BN8_RESPONSE);
                $BN6_RESPONSE = $this->_getAttemptDataFromQuestionCode('BN6', $breach_log->raAttemptQuestions);
                $template_processor->setValue('BREACH_RISK', htmlspecialchars($BN6_RESPONSE->answer->answer));
                $BN6_RESPONSE_TEXT = '';
                if ($BN6_RESPONSE->answer->answer_code == 'A4') {
                    $BN6_RESPONSE_TEXT = '';
                } elseif ($BN6_RESPONSE->answer->answer_code == 'A1') {
                    $BN6_RESPONSE_TEXT = $breach_log->location->company_name.' has also determined that the exposed PHI has been retrieved and/or deleted.';
                } elseif ($BN6_RESPONSE->answer->answer_code == 'A2') {
                    $BN6_RESPONSE_TEXT = $breach_log->location->company_name.' has also determined that the exposed PHI has not been retrieved and/or deleted.';
                } else {
                    $BN6_RESPONSE_TEXT = $breach_log->location->company_name.' has also determined that the exposed PHI is currently in the process of being retrieved and/or deleted.';
                }
                $template_processor->setValue('BN6_RESPONSE', htmlspecialchars($BN6_RESPONSE_TEXT));
                $BN9_RESPONSE = '</w:t><w:tab/><w:t>●  Complete an incident risk assessment</w:t><w:br/><w:t>';
                $BN9_answers = $this->_getAttemptDataFromQuestionCode('BN9', $breach_log->raAttemptQuestions, 'all');
                $BN9_answers_array = [];
                foreach ($BN9_answers as $key => $value) {
                    $BN9_answers_array[] = $value->answer->answer;
                }
                if (in_array('Other', $BN9_answers_array)) {
                    if (($key = array_search('Other', $BN9_answers_array)) !== false) {
                        unset($BN9_answers_array[$key]);
                    }
                }
                foreach ($BN9_answers_array as $key => $value) {
                    $BN9_RESPONSE .= '
</w:t><w:tab/><w:t>●  '.$value.'</w:t><w:br/><w:t>';
                }
                $template_processor->setValue('BN9_RESPONSE', $BN9_RESPONSE);
                $BN9S1_answers = $this->_getAttemptDataFromQuestionCode('BN9S1', $breach_log->raAttemptQuestions);
                if ($BN9S1_answers) {
                    $template_processor->setValue('BREACH_RESPONSE_ADDITIONAL', '
</w:t><w:br/><w:t>Other responses include: '.htmlspecialchars($BN9S1_answers->custom_answer));
                } else {
                    $template_processor->setValue('BREACH_RESPONSE_ADDITIONAL', '');
                }
                $PREVIOUSLY_REPORTED = '';
                foreach ($breach_log->incidentReport as $key => $value) {
                    if ($value->incidentReporterType->name == 'None') {
                        $PREVIOUSLY_REPORTED = 'not yet reported the breach';
                    } elseif ($value->incidentReporterType->name == 'Office for Civil Rights') {
                        $PREVIOUSLY_REPORTED .= 'already reported the breach to the Office for Civil Rights on '.date('F j, Y', strtotime($value->incident_date));
                    } elseif ($value->incidentReporterType->name == 'Affected Individuals') {
                        if ($PREVIOUSLY_REPORTED != '') {
                            $PREVIOUSLY_REPORTED .= ' and ';
                        }
                        $PREVIOUSLY_REPORTED .= 'already reported the breach to the Affected Individuals on '.date('F j, Y', strtotime($value->incident_date));
                    } elseif ($value->incidentReporterType->name == 'Abyde') {
                        if ($PREVIOUSLY_REPORTED != '') {
                            $PREVIOUSLY_REPORTED .= ' and ';
                        }
                        $PREVIOUSLY_REPORTED .= 'already reported the breach to the Abyde team on '.date('F j, Y', strtotime($value->incident_date));
                    }
                }
                $template_processor->setValue('PREVIOUSLY_REPORTED', htmlspecialchars($PREVIOUSLY_REPORTED));
                if ($breach_log->individuals_affected == 'less_than_500') {
                    $FILING_TIMEFRAME = 'on an annual basis and within 60 calendar days of the end of the current year';
                }
                if ($breach_log->individuals_affected == '500_or_more_than_500') {
                    $FILING_TIMEFRAME = 'without unreasonable delay and in no case later than '.$breach_log->location->state->breachDetail->breach_time.' following a breach';
                }
                $template_processor->setValue('FILING_TIMEFRAME', htmlspecialchars($FILING_TIMEFRAME));
            } else {
                // breach log without RA completed
                $policy_filename = 'BreachLogReport.docx';
                $policy_file_path = $public_path.'/policydocuments/'.$policy_filename;
                $generated_policy_directory_path = $storage_path.'/generatedpolicydocuments/';
                $gnerated_policy_doc_name = $breach_log->id.'_'.$policy_filename;
                $gnerated_policy_pdf_name = str_replace('docx', 'pdf', $gnerated_policy_doc_name);
                $gnerated_policy_file_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_policy_doc_name;
                $gnerated_policy_pdf_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_policy_pdf_name;
                $gnerated_policy_pdf_url = asset('storage/generatedpolicydocuments/' . $gnerated_policy_pdf_name);
                $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($policy_file_path);
                $generalController = new GeneralController;
                $logo_data = $generalController->_addCompanyLogoOnCoverPage($breach_log->location);
                $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
                $generalController->_removeTempCompanyLogo($breach_log->location, $logo_data['temp_file_path']);
                $template_processor->setValue('COMPANY_NAME', htmlspecialchars($breach_log->location->company_name));
                $template_processor->setValue('LAST_MODIFIED_DATE', date('F j, Y', strtotime($breach_log->updated_at)));
                $template_processor->setValue('BREACH_DATE', date('F j, Y', strtotime($breach_log->breach_start_date)));
                $template_processor->setValue('CLIENT_NAME', htmlspecialchars($breach_log->location->company_name));
                $template_processor->setValue('CLIENT_ADDRESS', htmlspecialchars($breach_log->location->address));
                $template_processor->setValue('CLIENT_PHONE_NUMBER', $breach_log->location->phone_no);
                $template_processor->setValue('CLIENT_CITY', htmlspecialchars($breach_log->location->city));
                $template_processor->setValue('CLIENT_STATE', htmlspecialchars($breach_log->location->state->state_name));
                $template_processor->setValue('CLIENT_ZIP', $breach_log->location->zip_code);
                $template_processor->setValue('BREACH_START', date('F j, Y', strtotime($breach_log->breach_start_date)));
                $template_processor->setValue('BREACH_END', date('F j, Y', strtotime($breach_log->breach_end_date)));
                $template_processor->setValue('BREACH_REPORTER', htmlspecialchars($breach_log->incident_reporter_name));
                $template_processor->setValue('HCO_NAME', htmlspecialchars($breach_log->location->hipaaComplianceOfficer->hco->first_name.' '.$breach_log->location->hipaaComplianceOfficer->hco->last_name));
                $template_processor->setValue('HCO_EMAIL', htmlspecialchars($breach_log->location->hipaaComplianceOfficer->hco->email));
                $template_processor->setValue('HCO_PHONE_NUMBER', $breach_log->location->phone_no);
                if ($breach_log->type_of_incident == 'hacking_it_incident') {
                    $type_of_incident = 'Hacking/IT';
                }
                if ($breach_log->type_of_incident == 'improper_disposal') {
                    $type_of_incident = 'Improper Disposal';
                }
                if ($breach_log->type_of_incident == 'loss') {
                    $type_of_incident = 'Loss of PHI';
                }
                if ($breach_log->type_of_incident == 'theft') {
                    $type_of_incident = 'Theft of PHI';
                }
                if ($breach_log->type_of_incident == 'unauthorized_access') {
                    $type_of_incident = 'Unauthorized Access/Disclosure';
                }
                $template_processor->setValue('BREACH_TYPE', htmlspecialchars($type_of_incident));
                $template_processor->setValue('BREACH_DISCOVERY', htmlspecialchars($breach_log->discovered_by));
                if ($breach_log->individuals_affected == 'less_than_500') {
                    $individuals_affected = 'less than 500 individuals';
                }
                if ($breach_log->individuals_affected == '500_or_more_than_500') {
                    $individuals_affected = '500 or more individuals';
                }
                $template_processor->setValue('INDIVIDUALS', htmlspecialchars($individuals_affected));
                $type_of_phis = [];
                foreach ($breach_log->phiType as $key => $value) {
                    if ($value->phiTypeName->name == 'Other') {
                        $type_of_phis[] = $value->other_details;
                    } else {
                        $type_of_phis[] = $value->phiTypeName->name;
                    }
                }
                $template_processor->setValue('PHI', implode(', ', array_map('ucfirst', $type_of_phis)));
                $template_processor->setValue('DISCOVERY_START', date('F j, Y', strtotime($breach_log->discovered_start_date)));
                $template_processor->setValue('DISCOVERY_END', date('F j, Y', strtotime($breach_log->discovered_end_date)));
                $PREVIOUSLY_REPORTED = '';
                foreach ($breach_log->incidentReport as $key => $value) {
                    if ($value->incidentReporterType->name == 'None') {
                        $PREVIOUSLY_REPORTED = 'not yet reported the breach';
                    } elseif ($value->incidentReporterType->name == 'Office for Civil Rights') {
                        $PREVIOUSLY_REPORTED .= 'already reported the breach to the Office for Civil Rights on '.date('F j, Y', strtotime($value->incident_date));
                    } elseif ($value->incidentReporterType->name == 'Affected Individuals') {
                        if ($PREVIOUSLY_REPORTED != '') {
                            $PREVIOUSLY_REPORTED .= ' and ';
                        }
                        $PREVIOUSLY_REPORTED .= 'already reported the breach to the Affected Individuals on '.date('F j, Y', strtotime($value->incident_date));
                    } elseif ($value->incidentReporterType->name == 'Abyde') {
                        if ($PREVIOUSLY_REPORTED != '') {
                            $PREVIOUSLY_REPORTED .= ' and ';
                        }
                        $PREVIOUSLY_REPORTED .= 'already reported the breach to the Abyde team on '.date('F j, Y', strtotime($value->incident_date));
                    }
                }
                $template_processor->setValue('PREVIOUSLY_REPORTED', htmlspecialchars($PREVIOUSLY_REPORTED));
                if ($breach_log->individuals_affected == 'less_than_500') {
                    $FILING_TIMEFRAME = 'on an annual basis and within 60 calendar days of the end of the current year';
                }
                if ($breach_log->individuals_affected == '500_or_more_than_500') {
                    $FILING_TIMEFRAME = 'without unreasonable delay and in no case later than '.$breach_log->location->state->breachDetail->breach_time.' following a breach';
                }
                $template_processor->setValue('FILING_TIMEFRAME', htmlspecialchars($FILING_TIMEFRAME));
            }
            $template_processor->saveAs($gnerated_policy_file_path);
            if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                // change libreoffice path as per installation path from your machine
                exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  '.$generated_policy_directory_path.' '.$gnerated_policy_file_path);
            } else {
                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir '.$generated_policy_directory_path.' '.$gnerated_policy_file_path);
            }

            return $this->success(Config::get('constants.SUCCESS'), 200, ['file_name' => $breach_log->location->location_nickname.' Breach Report '.date('m/d/Y', strtotime($breach_log->created_at)).'.pdf', 'download_url' => $gnerated_policy_pdf_url]);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/downloadBreachLogPDF() => '.$e->getMessage());
            Log::error('HipaaLogController/downloadBreachLogPDF()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    public function _getAttemptDataFromQuestionCode($question_code, $questions_attempted_list, $return_type = 'one')
    {
        if ($return_type == 'one') {
            $attempt_data = '';
            foreach ($questions_attempted_list as $key => $value) {
                if ($value->question->question_code == $question_code) {
                    $attempt_data = $value;
                    break;
                }
            }

            return $attempt_data;
        } else {
            $attempt_data = [];
            foreach ($questions_attempted_list as $key => $value) {
                if ($value->question->question_code == $question_code) {
                    $attempt_data[] = $value;
                }
            }

            return $attempt_data;
        }
    }

    public function _getBAData($ba_id)
    {
        return BusinessAssociates::where('id', $ba_id)->first();
    }

    public function _getStateName($state_id)
    {
        $state = State::where('id', $state_id)->first();

        return $state->state_name;
    }

    /**
     * load risk assessment question
     *
     * @return \Illuminate\Http\Response
     */
    public function loadQuestions(Request $request)
    {
        try {
            $question_list = BreachLogRaQuestion::with(['breachLogRaQuestionAnswers'])->orderBy('sequence_no', 'asc')->get();

            return $this->success(Config::get('constants.SUCCESS'), 200, $question_list);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/loadQuestions() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * load risk assessment question answer save
     *
     * @return \Illuminate\Http\Response
     */
    public function saveBreachLogQuestionAnswer(Request $request)
    {
        try {
            $validator_rules = [
                'breach_log_id' => 'required',
                'attempted_questions' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            foreach ($request['attempted_questions'] as $attmpted_answer) {
                switch ($attmpted_answer['qeustion_type']) {
                    case 'radio':
                        $attempted = [
                            'breach_log_id' => $request['breach_log_id'],
                            'question_id' => $attmpted_answer['id'],
                            'answer_id' => $attmpted_answer['selected_answer'],
                        ];
                        BreachLogRaAttempt::create($attempted);
                        break;
                    case 'checkbox':
                        foreach ($attmpted_answer['selected_answer'] as $ans) {
                            $attempted = [
                                'breach_log_id' => $request['breach_log_id'],
                                'question_id' => $attmpted_answer['id'],
                                'answer_id' => $ans,
                            ];
                            BreachLogRaAttempt::create($attempted);
                        }
                        break;
                    case 'single_select_dropdown':
                        $attempted = [
                            'breach_log_id' => $request['breach_log_id'],
                            'question_id' => $attmpted_answer['id'],
                        ];
                        if ($attmpted_answer['question_answer_layout_data'] == 'BA') {
                            if ($attmpted_answer['selected_answer']['name'] == 'Other') {
                                $attempted['custom_answer'] = $attmpted_answer['selected_answer']['name'];
                            } else {
                                $attempted['custom_answer'] = $attmpted_answer['selected_answer']['id'];
                            }
                        }
                        BreachLogRaAttempt::create($attempted);
                        break;
                    case 'multi_select_dropdown':
                        foreach ($attmpted_answer['selected_answer'] as $ans) {
                            $attempted = [
                                'breach_log_id' => $request['breach_log_id'],
                                'question_id' => $attmpted_answer['id'],
                                'custom_answer' => $ans['id'],
                            ];
                            BreachLogRaAttempt::create($attempted);
                        }
                        break;
                    default:
                        $attempted = [
                            'breach_log_id' => $request['breach_log_id'],
                            'question_id' => $attmpted_answer['id'],
                            'custom_answer' => $attmpted_answer['selected_answer'],
                        ];
                        BreachLogRaAttempt::create($attempted);
                        break;
                }
            }
            DB::commit();

            return $this->success(Config::get('constants.SUCCESS'), 200);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('HipaaLogController/saveBreachLogQuestionAnswer() => '.$e->getMessage());
            Log::error('HipaaLogController/saveBreachLogQuestionAnswer()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end - Breach log
    /*************************** */

    /************************** */
    /*API methods - start - Asset log
    /*************************** */

    /**
     * List Asset Log
     *
     * @return \Illuminate\Http\Response
     */
    public function getAssetLogByLocationID(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $hco = HipaaComplianceOfficer::where('location_id', $request['location_id'])->first();
            $company_info_completed = ModuleCompletedStatus::where(['location_id' => $request['location_id'], 'module' => 'company_info', 'is_completed' => 1])->first();
            $location = Location::where('id', $request['location_id'])
                ->with(['employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation'])
                ->first();
            $check_is_sra_completed = ModuleCompletedStatus::where(
                [
                    'location_id' => $request['location_id'],
                    'module' => 'risk_analysis',
                    'is_completed' => 1,
                ]
            )->first();
            if ((count($location->employeePrimaryWorkLocation) == 0 && count($location->employeeSecondaryWorkLocation) == 0) || ! $check_is_sra_completed || ! $hco || ! $company_info_completed) {
                return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
            }
            $asset_log_list = AssetLog::where('location_id', $request['location_id'])
                ->with([
                    'deviceType:id,name',
                    'operatingSystem:id,name',
                    'assetEncryption:id,name',
                    'ephiAccess:id,name',
                    'operatingLocation:id,name',
                    'assignedEmployee:id,first_name,last_name',
                    'location:id,location_nickname',
                    'disposalStatus:id,name',
                ]);
            $asset_log_list = $asset_log_list->orderBy('created_at', 'desc')->get();
            $data = [
                'asset_log_list' => $asset_log_list,
                'sample_import_doc' => url('/sample_docs/assetlog_template.xlsx'),
            ];

            return $this->success(Config::get('constants.ASSET_LOG.ASSET_LOG_LIST'), 200, $data);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/getAssetLogByLocationID() => '.$e->getMessage());
            Log::error('HipaaLogController/getAssetLogByLocationID()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Add Asset Log
     *
     * @return \Illuminate\Http\Response
     */
    public function addAssetLog(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'device_type_id' => 'required',
                'operating_system_id' => 'required',
                'status' => 'required|in:active,inactive',
                'name' => 'required',
                'purchased_date' => 'required|date_format:Y-m-d',
                'asset_encryption_id' => 'required',
                'ephi_access_id' => 'required',
                'operating_location_id' => 'sometimes|nullable',
                'assigned_employee_id' => 'required',
                'disposal_status_id' => 'sometimes|nullable',
                'disposal_date' => 'sometimes|nullable|date_format:Y-m-d|after_or_equal:purchased_date',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $asset_log_created = AssetLog::create($input_fields);
            DB::commit();

            return $this->success(Config::get('constants.ASSET_LOG.ASSET_LOG_ADDED'), 200, $asset_log_created);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/addAssetLog() => '.$e->getMessage());
            Log::error('HipaaLogController/addAssetLog()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Edit Asset Log
     *
     * @return \Illuminate\Http\Response
     */
    public function editAssetLog(Request $request)
    {
        try {
            $validator_rules = [
                'location_id' => 'required',
                'asset_log_id' => 'required',
                'device_type_id' => 'required',
                'operating_system_id' => 'required',
                'status' => 'required|in:active,inactive',
                'name' => 'required',
                'purchased_date' => 'required|date_format:Y-m-d',
                'asset_encryption_id' => 'required',
                'ephi_access_id' => 'required',
                'operating_location_id' => 'sometimes|nullable',
                'assigned_employee_id' => 'required',
                'disposal_status_id' => 'sometimes|nullable',
                'disposal_date' => 'sometimes|nullable|date_format:Y-m-d|after_or_equal:purchased_date',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            DB::beginTransaction();
            $input_fields = $request->all();
            $asset_log = AssetLog::findorFail($input_fields['asset_log_id']);
            $asset_log_updated = $asset_log->update($input_fields);
            $updated_asset_log = AssetLog::where('location_id', $request['location_id'])
                ->where('id', $request->asset_log_id)
                ->with([
                    'deviceType:id,name',
                    'operatingSystem:id,name',
                    'assetEncryption:id,name',
                    'ephiAccess:id,name',
                    'operatingLocation:id,name',
                    'assignedEmployee:id,first_name,last_name',
                    'location:id,location_nickname',
                    'disposalStatus:id,name',
                ])->first();
            DB::commit();

            return $this->success(Config::get('constants.ASSET_LOG.ASSET_LOG_EDIT'), 200, $updated_asset_log);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/editAssetLog() => '.$e->getMessage());
            Log::error('HipaaLogController/editAssetLog()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Delete Asset Log
     *
     * @return \Illuminate\Http\Response
     */
    public function deleteAssetLog(Request $request)
    {
        try {
            $validator_rules = [
                'asset_log_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $input_fields = $request->all();

            $asset_log = AssetLog::findorFail($input_fields['asset_log_id']);
            DB::beginTransaction();
            if ($asset_log) {
                $asset_log->delete();

                $abyde_drive_folder = AbydeDriveArchiveFolder::where('folder_name', 'Hipaa Logs')->first();

                $asset_log_folder = AbydeDriveArchiveFolder::updateOrCreate([
                    'folder_name' => 'Asset Logs',
                    'parent_folder_id' => $abyde_drive_folder->id,
                ]);

                $asset_log_folder_location = AbydeDriveArchiveFolderLocation::updateOrCreate([
                    'archive_folder_id' => $asset_log_folder->id,
                    'location_id' => $asset_log->location_id,
                ]);

                $trashed_asset_log = AssetLog::onlyTrashed()->where('location_id', $asset_log->location_id)
                    ->with([
                        'deviceType:id,name',
                        'operatingSystem:id,name',
                        'assetEncryption:id,name',
                        'ephiAccess:id,name',
                        'operatingLocation:id,name',
                        'assignedEmployee:id,first_name,last_name',
                        'location:id,location_nickname',
                        'disposalStatus:id,name',
                    ])->orderBy('deleted_at', 'desc');

                $location = Location::where('id', $asset_log->location_id)->select('company_name')->first();

                if ($asset_log->status == 'active') {
                    $file_name = 'Active_asset_logs'.uniqid().'.pdf';
                    $title = 'Active_Asset_Log';
                    $trashed_asset_log = $trashed_asset_log->where('status', 'active');
                    $file_path = '/abyde_drive_archive/asset_logs/'.$asset_log->location_id.'/active_asset_log/'.$file_name;
                    $delete_directory_path = '/abyde_drive_archive/asset_logs/'.$asset_log->location_id.'/active_asset_log/';
                    $delete_file = Storage::disk('s3')->deleteDirectory($delete_directory_path);
                } elseif ($asset_log->status == 'inactive') {
                    $file_name = 'Inactive_asset_logs'.uniqid().'.pdf';
                    $title = 'Inactive_Asset_Log';
                    $trashed_asset_log = $trashed_asset_log->where('status', 'inactive');
                    $file_path = '/abyde_drive_archive/asset_logs/'.$asset_log->location_id.'/inactive_asset_log/'.$file_name;
                    $delete_directory_path = '/abyde_drive_archive/asset_logs/'.$asset_log->location_id.'/inactive_asset_log/';
                    $delete_file = Storage::disk('s3')->deleteDirectory($delete_directory_path);
                }
                $trashed_asset_log = $trashed_asset_log->get()->toArray();

                $pdf = PDF::loadView('reports/assetlog', [
                    'trashed_asset_log' => $trashed_asset_log,
                    'status' => $asset_log->status,
                    'company_name' => $location->company_name,
                ]);
                $is_uploaded = Storage::disk('s3')->put($file_path, $pdf->output(), ['ContentType' => 'application/pdf']);
                if ($is_uploaded) {
                    $file_size = $this->getReadableFilesize(Storage::disk('s3')->size($file_path));
                    AbydeDriveArchiveFile::updateOrCreate(
                        [
                            'title' => $title,
                            'archive_folder_id' => $asset_log_folder_location->id,
                        ],
                        [
                            'file_name' => $file_name,
                            'file_size' => $file_size,
                            'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                        ]
                    );
                }
            }
            DB::commit();

            return $this->success(Config::get('constants.ASSET_LOG.ASSET_LOG_DELETE'), 200);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/deleteAssetLog() => '.$e->getMessage());
            Log::error('HipaaLogController/deleteAssetLog()[data] => '.json_encode($request->all()));
            DB::rollback();

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Update Deleted Asset Log Pdf
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateDeletedAssetLogPdf($location_id)
    {
        $active_trashed_asset_log = AssetLog::onlyTrashed()->where('location_id', $location_id)
            ->with([
                'deviceType:id,name',
                'operatingSystem:id,name',
                'assetEncryption:id,name',
                'ephiAccess:id,name',
                'operatingLocation:id,name',
                'assignedEmployee:id,first_name,last_name',
                'location:id,location_nickname',
                'disposalStatus:id,name',
            ])->orderBy('deleted_at', 'desc')->where('status', 'active')->get()->toArray();

        $inactive_trashed_asset_log = AssetLog::onlyTrashed()->where('location_id', $location_id)
            ->with([
                'deviceType:id,name',
                'operatingSystem:id,name',
                'assetEncryption:id,name',
                'ephiAccess:id,name',
                'operatingLocation:id,name',
                'assignedEmployee:id,first_name,last_name',
                'location:id,location_nickname',
                'disposalStatus:id,name',
            ])->orderBy('deleted_at', 'desc')->where('status', 'inactive')->get()->toArray();

        $location = Location::where('id', $location_id)->select('company_name')->first();

        if (count($active_trashed_asset_log) > 0 || count($inactive_trashed_asset_log) > 0) {
            $abyde_drive_folder = AbydeDriveArchiveFolder::where('folder_name', 'Hipaa Logs')->first();

            $asset_log_folder = AbydeDriveArchiveFolder::updateOrCreate([
                'folder_name' => 'Asset Logs',
                'parent_folder_id' => $abyde_drive_folder->id,
            ]);

            $asset_log_folder_location = AbydeDriveArchiveFolderLocation::updateOrCreate([
                'archive_folder_id' => $asset_log_folder->id,
                'location_id' => $location_id,
            ]);
        }

        if (count($active_trashed_asset_log) > 0) {
            $active_file_name = 'Active_asset_logs'.uniqid().'.pdf';
            $active_title = 'Active_Asset_Log';
            $active_file_path = '/abyde_drive_archive/asset_logs/'.$location_id.'/active_asset_log/'.$active_file_name;
            $active_delete_directory_path = '/abyde_drive_archive/asset_logs/'.$location_id.'/active_asset_log/';
            $active_delete_file = Storage::disk('s3')->deleteDirectory($active_delete_directory_path);

            $active_pdf = PDF::loadView('reports/assetlog', [
                'trashed_asset_log' => $active_trashed_asset_log,
                'status' => 'active',
                'company_name' => $location->company_name,
            ]);
            $is_uploaded_active = Storage::disk('s3')->put($active_file_path, $active_pdf->output(), ['ContentType' => 'application/pdf']);

            if ($is_uploaded_active) {
                $active_file_size = $this->getReadableFilesize(Storage::disk('s3')->size($active_file_path));
                AbydeDriveArchiveFile::updateOrCreate(
                    [
                        'title' => $active_title,
                        'archive_folder_id' => $asset_log_folder_location->id,
                    ],
                    [
                        'file_name' => $active_file_name,
                        'file_size' => $active_file_size,
                        'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    ]
                );
            }
        }

        if (count($inactive_trashed_asset_log) > 0) {
            $inactive_file_name = 'Inactive_asset_logs'.uniqid().'.pdf';
            $inactive_title = 'Inactive_Asset_Log';
            $inactive_file_path = '/abyde_drive_archive/asset_logs/'.$location_id.'/inactive_asset_log/'.$inactive_file_name;
            $inactive_delete_directory_path = '/abyde_drive_archive/asset_logs/'.$location_id.'/inactive_asset_log/';
            $inactive_delete_file = Storage::disk('s3')->deleteDirectory($inactive_delete_directory_path);

            $inactive_pdf = PDF::loadView('reports/assetlog', [
                'trashed_asset_log' => $inactive_trashed_asset_log,
                'status' => 'inactive',
                'company_name' => $location->company_name,
            ]);

            $is_uploaded_inactive = Storage::disk('s3')->put($inactive_file_path, $inactive_pdf->output(), ['ContentType' => 'application/pdf']);

            if ($is_uploaded_inactive) {
                $inactive_file_size = $this->getReadableFilesize(Storage::disk('s3')->size($inactive_file_path));
                AbydeDriveArchiveFile::updateOrCreate(
                    [
                        'title' => $inactive_title,
                        'archive_folder_id' => $asset_log_folder_location->id,
                    ],
                    [
                        'file_name' => $inactive_file_name,
                        'file_size' => $inactive_file_size,
                        'updated_at' => Carbon::now()->format('Y-m-d H:i:s'),
                    ]
                );
            }
        }
    }

    /**
     * get all Device Type list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getDeviceTypeList()
    {
        try {
            $data = AssetLogDeviceType::select('id', 'name')->get();

            return $this->success('Success', 200, $data);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/getDeviceTypeList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get all Operating System list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getOperatingSystemList()
    {
        try {
            $data = AssetLogOperatingSystem::select('id', 'name')->get();

            return $this->success('Success', 200, $data);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/getOperatingSystemList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get all Asset Encryption list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getAssetEncryptionList()
    {
        try {
            $data = AssetLogEncryption::select('id', 'name')->get();

            return $this->success('Success', 200, $data);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/getAssetEncryptionList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get all Ephi Access list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getEphiAccessList()
    {
        try {
            $data = AssetLogEphiAccess::select('id', 'name')->get();

            return $this->success('Success', 200, $data);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/getEphiAccessList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get all Operating Location list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getOperatingLocationList()
    {
        try {
            $data = AssetLogOperatingLocation::select('id', 'name')->get();

            return $this->success('Success', 200, $data);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/getOperatingLocationList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * get all Disposal Status list
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getDisposalStatusList()
    {
        try {
            $data = AssetLogDisposalStatus::select('id', 'name')->get();

            return $this->success('Success', 200, $data);
        } catch (\Exception $e) {
            Log::error('HipaaLogController/getDisposalStatusList() => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Export Asset Log list
     *
     * @return \Illuminate\Http\Response
     */
    public function exportAssetsLog(Request $request)
    {

        try {
            $validator_rules = [
                'location_id' => 'required',
            ];
            $validator_check = Validator::make($request->all(), $validator_rules);
            if ($validator_check->fails()) {
                return $this->error(Config::get('constants.FIELDS_ERROR'), 200, $validator_check->errors()->all());
            }
            $location = Location::find($request['location_id']);
            $export = new ExportAssetLog($request['location_id']);

            return $this->success(
                Config::get('constants.SUCCESS'),
                200,
                [
                    'name' => $location->location_nickname.' - Asset Log.xlsx',
                    'file' => 'data:application/vnd.ms-excel;base64,'.base64_encode(Excel::raw($export, ExcelC::XLSX)),
                ]
            );
        } catch (\Exception $e) {
            Log::error('HipaaLogController/exportAssetsLog() => '.$e->getMessage());
            Log::error('HipaaLogController/exportAssetsLog()[data] => '.json_encode($request->all()));

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /**
     * Import Asset Log list
     *
     * @return \Illuminate\Http\Response
     */
    public function importAssetLog(Request $request)
    {
        $validator_rules = [
            'location_id' => 'required',
            'import_file' => 'required|mimes:xlsx,xls',
        ];
        $validator_check = Validator::make($request->all(), $validator_rules);
        if ($validator_check->fails()) {
            return $this->error(Config::get('constants.ASSET_LOG.INVALID_IMPORT_FILE'), 200, $validator_check->errors()->all());
        }
        $headings = (new HeadingRowImport)->toArray($request['import_file']);
        $heading_array = [
            'device_type',
            'name',
            'operating_system',
            'purchased_date',
            'asset_encryption',
            'ephi_access',
            'additional_operating_location',
            'assigned_employee',
            'status',
            'disposal_status',
            'disposal_date',
        ];
        $missing_heading = array_diff($heading_array, $headings[0][0]);
        if ($missing_heading) {
            return $this->error(Config::get('constants.ASSET_LOG.IMPORT_FILE_INVALID_TEMPLETE'), 200);
        }
        try {
            if ($request->has('import_file')) {
                $import = new AssetLogImport;
                $import->location_id = $request['location_id'];
                $import->import($request['import_file']);
                if ($import->failures()->isNotEmpty()) {
                    $error = [];
                    $i = 0;
                    foreach ($import->failures() as $failure) {
                        foreach ($failure->errors() as $value) {
                            $error[$i] = $value.'Row No :'.$failure->row();
                            $i++;
                        }
                    }
                    Log::error('HipaaLogController/importAssetLog(ImportValidation) => '.json_encode($error));
                    if ($import->row_count == 0) {
                        return $this->error(Config::get('constants.ASSET_LOG.IMPORT_ERROR'), 200, $error);
                    } else {
                        return $this->success(Config::get('constants.ASSET_LOG.PARTIALLY_IMPORT_ERROR'), 200, $error);
                    }
                }
                if ($import->row_count == 0) {
                    return $this->error(Config::get('constants.ASSET_LOG.IMPORT_ERROR'), 200);
                }
                if ($import->row_count == $import->total_row_count) {
                    return $this->success(Config::get('constants.ASSET_LOG.IMPORTED'), 200);
                } else {
                    return $this->success(Config::get('constants.ASSET_LOG.PARTIALLY_IMPORT_ERROR'), 200);
                }
            }
        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            Log::error('HipaaLogController/importAssetLog(Import) => '.$e->getMessage());
            return $this->error(Config::get('constants.ASSET_LOG.IMPORT_ERROR'), 200);
        } catch (\Exception $e) {
            if ($e->getLine() == 126) {
                $invalid_email = explode(',', $e->getMessage());
                return $this->error(Config::get('constants.EMPLOYEE.IMPORT_ERROR'), 200, $invalid_email);
            }
            Log::error('HipaaLogController/importAssetLog(Import) => '.$e->getMessage());

            return $this->error(Config::get('constants.SOMETHING_WENT_WRONG'), 200);
        }
    }

    /************************** */
    /*API methods - end - Asset log
    /*************************** */

    /**
     * get last updated hipaa log for dashboard
     */
    public function getLastUpdatedHipaaLogs($location_id)
    {
        $is_avail = LocationModuleLastUpdate::where(['location_id' => $location_id, 'module_name' => 'hipaa_logs'])->first();

        return ($is_avail) ? $is_avail->updated_at : '';
    }
}
