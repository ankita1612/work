<?php

namespace App\Http\Middleware;

use App\Models\{Admin};
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class checkAdminAccessRights
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     */
    public function handle(Request $request, Closure $next)
    {
        $url = explode('/', $request->path());
        $admin = Admin::with('role.accessibleModules')->whereHas('role.accessibleModules', function ($que) use ($url) {
            $que->where(['url_slug' => $url[1]]);
        })->where('id', auth()->user()->id)->first();
        if (! $admin && $url[1] != 'location') {
            return redirect()->route('admin_dashboard');
        }

        return $next($request);
    }
}
