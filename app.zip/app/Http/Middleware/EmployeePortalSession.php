<?php

namespace App\Http\Middleware;

use App\Models\Employee;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Symfony\Component\HttpFoundation\Response;

class EmployeePortalSession
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     */
    public function handle(Request $request, Closure $next)
    {
        if (! $request->session()->has('employee_id') || ! $request->session()->has('employee_portal_login_id')) {
            $request->session()->forget('employee_portal_login_id');
            $request->session()->forget('employee_id');
            $request->session()->save();
            if(request()->expectsJson()){       
                return Response()->json( ['message' =>'UnAuthorized'], 401); //exeption for api
            }      
            return redirect(Config::get('app.wordpress_url'));

        }
        if ($request->session()->has('employee_id') && $request->session()->has('employee_portal_login_id')) {
            $employee = Employee::where('id', $request->session()->get('employee_id'))->whereHas('user', function ($query) {
                $query->where('account_status', 'Unfrozen')->where('is_active', '1')->where('is_account_verified', '1');
            })->isActive()->first();
            if (! $employee) {
                $request->session()->forget('employee_portal_login_id');
                $request->session()->forget('employee_id');
                $request->session()->save();
                if(request()->expectsJson()){       
                    return Response()->json( ['message' =>'UnAuthorized'], 401); //exeption for api
                }
                return redirect(Config::get('app.wordpress_url'));
            }
        }

        return $next($request);
    }
}
