<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array<int, string>
     */
    protected $except = [
        'check-promocode',
        'check-email-already-signup',
        'hipaace-toggle',
        'wordpress-contactus',
        'employee-portal-hipaace-toggle',
        'quoter-validate-password',
        'quoter-save',
        'close-tab',
        'check-strip-customer-already-signup-for-chargebee-migration',
        'chargebee-webhook'
    ];
}
