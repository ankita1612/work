<?php

namespace App\Http\Middleware;

use App\Models\Location;
use App\Traits\ChargebeePlan;
use App\Traits\GetMainUserData;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{Auth};
use Symfony\Component\HttpFoundation\Response;

class CheckAllLocationAdded
{
    use GetMainUserData,ChargebeePlan;

    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     */
    public function handle(Request $request, Closure $next)
    {
        $user_data = $this->getMainAccountDetails();
        $total_location = Location::where('user_id', $user_data['id'])->count();
        $subscription = $this->getSubscriptionDetails($user_data['chargebee_subscription_id']);
        $location_limit = $subscription['location_limit'];
            
        if ((int) $location_limit > (int) $total_location) {
            if (! empty(auth()->guard('account_user')->user())) {
                Auth::logout();
            }

            return redirect()->route('dashboard');
        }

        return $next($request);
    }
}
