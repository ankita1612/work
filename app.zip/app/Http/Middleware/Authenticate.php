<?php

namespace App\Http\Middleware;

use App\Traits\ApiResponser;
use Illuminate\Auth\Middleware\Authenticate as Middleware;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Authenticate extends Middleware
{
    use ApiResponser;

    /**
     * Get the path the user should be redirected to when they are not authenticated.
     */
    protected function redirectTo(Request $request)
    {
        if (! $request->expectsJson()) {
            if (in_array('auth:admin', $request->route()->middleware())) {
                if (! Auth::guard('admin')->check()) {
                    return route('admin_login');
                }
            }
            if (in_array('auth:user', $request->route()->middleware()) || in_array('auth:account_user', $request->route()->middleware())) {
                if (! Auth::guard('user')->check() && ! Auth::guard('account_user')->check()) {
                    return route('login');
                }
            }
        }
    }
}
