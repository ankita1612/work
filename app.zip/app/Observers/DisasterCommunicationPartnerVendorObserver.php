<?php

namespace App\Observers;

use App\Models\DisasterCommunicationPartnerVendor;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class DisasterCommunicationPartnerVendorObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the DisasterCommunicationPartnerVendor "created" event.
     */
    public function created(DisasterCommunicationPartnerVendor $disasterCommunicationPartnerVendor): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationPartnerVendor);
    }

    /**
     * Handle the DisasterCommunicationPartnerVendor "updated" event.
     */
    public function updated(DisasterCommunicationPartnerVendor $disasterCommunicationPartnerVendor): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationPartnerVendor);
    }

    /**
     * Handle the DisasterCommunicationPartnerVendor "deleted" event.
     */
    public function deleted(DisasterCommunicationPartnerVendor $disasterCommunicationPartnerVendor): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationPartnerVendor);
    }

    /**
     * Handle the DisasterCommunicationPartnerVendor "restored" event.
     */
    public function restored(DisasterCommunicationPartnerVendor $disasterCommunicationPartnerVendor): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationPartnerVendor);
    }

    /**
     * Handle the DisasterCommunicationPartnerVendor "force deleted" event.
     */
    public function forceDeleted(DisasterCommunicationPartnerVendor $disasterCommunicationPartnerVendor): void
    {
        // $this->updateLastModuleAccessDateTime($disasterCommunicationPartnerVendor);
    }

    public function updateLastModuleAccessDateTime($disasterCommunicationPartnerVendor)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $disasterCommunicationPartnerVendor->location_id, 'module_name' => 'disaster'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $disasterCommunicationPartnerVendor->location_id, 'module_name' => 'disaster'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $disasterCommunicationPartnerVendor->location_id, 'module_name' => 'disaster']);
            }
        } catch (\Exception $e) {
            Log::error('DisasterCommunicationPartnerVendorObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('DisasterCommunicationPartnerVendorObserver/updateLastModuleAccessDateTime() => ' . json_encode($disasterCommunicationPartnerVendor));
        }
    }
}
