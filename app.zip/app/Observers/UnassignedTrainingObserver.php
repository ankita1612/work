<?php

namespace App\Observers;

use App\Models\Employee;
use App\Models\HipaaComplianceOfficer;
use App\Models\LocationModuleLastUpdate;
use App\Models\Student;
use App\Models\UnassignedTraining;
use Illuminate\Support\Facades\Log;

class UnassignedTrainingObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the UnassignedTraining "created" event.
     */
    public function created(UnassignedTraining $unassignedTraining): void
    {
        $this->updateLastModuleAccessDateTime($unassignedTraining);
    }

    /**
     * Handle the UnassignedTraining "updated" event.
     */
    public function updated(UnassignedTraining $unassignedTraining): void
    {
        $this->updateLastModuleAccessDateTime($unassignedTraining);
    }

    /**
     * Handle the UnassignedTraining "deleted" event.
     */
    public function deleted(UnassignedTraining $unassignedTraining): void
    {
        $this->updateLastModuleAccessDateTime($unassignedTraining);
    }

    /**
     * Handle the UnassignedTraining "restored" event.
     */
    public function restored(UnassignedTraining $unassignedTraining): void
    {
        $this->updateLastModuleAccessDateTime($unassignedTraining);
    }

    /**
     * Handle the UnassignedTraining "force deleted" event.
     */
    public function forceDeleted(UnassignedTraining $unassignedTraining): void
    {
        // $this->updateLastModuleAccessDateTime($unassignedTraining);
    }

    public function updateLastModuleAccessDateTime($unassignedTraining)
    {
        try {
            if ($unassignedTraining->emp_user_acntuser_student_type == \App\Models\Employee::class) {
                $employee = Employee::where('id', $unassignedTraining->emp_user_acntuser_student_id)
                    ->with('employeeSecondaryWorkLocation')->get();
                foreach ($employee as $key => $value) {
                    try{
                        $is_avail_primary = LocationModuleLastUpdate::where(['location_id' => $value->primary_work_location_id, 'module_name' => 'training'])->first();
                        if ($is_avail_primary) {
                            LocationModuleLastUpdate::where(['location_id' => $value->primary_work_location_id, 'module_name' => 'training'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                        } else {
                            LocationModuleLastUpdate::create(['location_id' => $value->primary_work_location_id, 'module_name' => 'training']);
                        }
                        foreach ($value->employeeSecondaryWorkLocation as $key_sec => $value_sec) {
                            try{
                                $is_avail_sec = LocationModuleLastUpdate::where(['location_id' => $value_sec->location_id, 'module_name' => 'training'])->first();
                                if ($is_avail_sec) {
                                    LocationModuleLastUpdate::where(['location_id' => $value_sec->location_id, 'module_name' => 'training'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                                } else {
                                    LocationModuleLastUpdate::create(['location_id' => $value_sec->location_id, 'module_name' => 'training']);
                                }
                            }catch (\Exception $e) {
                                Log::error('UnassignedTrainingObserver/updateLastModuleAccessDateTime()[employeeSecondaryWorkLocation_error] => ' . $e->getMessage());
                                Log::error('UnassignedTrainingObserver/updateLastModuleAccessDateTime() =>[employeeSecondaryWorkLocation_error] ' . json_encode($value_sec));
                            }
                        }
                    }catch (\Exception $e) {
                        Log::error('UnassignedTrainingObserver/updateLastModuleAccessDateTime()[employee_list_error] => ' . $e->getMessage());
                        Log::error('UnassignedTrainingObserver/updateLastModuleAccessDateTime() =>[employee_list_error] ' . json_encode($value));
                    }
                }
            } elseif ($unassignedTraining->emp_user_acntuser_student_type == \App\Models\Student::class) {
                $student = Student::find($unassignedTraining->emp_user_acntuser_student_id);
                if ($student) {
                    $is_avail_primary = LocationModuleLastUpdate::where(['location_id' => $student->primary_work_location_id, 'module_name' => 'training'])->first();
                    if ($is_avail_primary) {
                        LocationModuleLastUpdate::where(['location_id' => $student->primary_work_location_id, 'module_name' => 'training'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                    } else {
                        LocationModuleLastUpdate::create(['location_id' => $student->primary_work_location_id, 'module_name' => 'training']);
                    }
                }
            } else {
                $hco = HipaaComplianceOfficer::where(['hco_id' => $unassignedTraining->emp_user_acntuser_student_id, 'hco_type' => $unassignedTraining->emp_user_acntuser_student_type])->get();
                foreach ($hco as $key => $value) {
                    try{
                        $is_avail_sec = LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'training'])->first();
                        if ($is_avail_sec) {
                            LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'training'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                        } else {
                            LocationModuleLastUpdate::create(['location_id' => $value->location_id, 'module_name' => 'training']);
                        }
                    }catch (\Exception $e) {
                        Log::error('UnassignedTrainingObserver/updateLastModuleAccessDateTime()[hco_list_error] => ' . $e->getMessage());
                        Log::error('UnassignedTrainingObserver/updateLastModuleAccessDateTime() =>[hco_list_error] ' . json_encode($value));
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('UnassignedTrainingObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('UnassignedTrainingObserver/updateLastModuleAccessDateTime() => ' . json_encode($unassignedTraining));
        }
    }
}
