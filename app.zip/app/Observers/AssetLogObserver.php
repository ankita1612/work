<?php

namespace App\Observers;

use App\Models\AssetLog;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class AssetLogObserver
{
    /**
     * Handle the AssetLog "created" event.
     */
    public function created(AssetLog $assetLog): void
    {
        $this->updateLastModuleAccessDateTime($assetLog);
    }

    /**
     * Handle the AssetLog "updated" event.
     */
    public function updated(AssetLog $assetLog): void
    {
        $this->updateLastModuleAccessDateTime($assetLog);
    }

    /**
     * Handle the AssetLog "deleted" event.
     */
    public function deleted(AssetLog $assetLog): void
    {
        $this->updateLastModuleAccessDateTime($assetLog);
    }

    /**
     * Handle the AssetLog "restored" event.
     */
    public function restored(AssetLog $assetLog): void
    {
        $this->updateLastModuleAccessDateTime($assetLog);
    }

    /**
     * Handle the AssetLog "force deleted" event.
     */
    public function forceDeleted(AssetLog $assetLog): void
    {
        //
    }

    public function updateLastModuleAccessDateTime($assetLog)
    {
        try{
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $assetLog->location_id, 'module_name' => 'hipaa_logs'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $assetLog->location_id, 'module_name' => 'hipaa_logs'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $assetLog->location_id, 'module_name' => 'hipaa_logs']);
            }
        } catch (\Exception $e) {
            Log::error('AssetLogObserver/updateLastModuleAccessDateTime() => '.$e->getMessage());
            Log::error('AssetLogObserver/updateLastModuleAccessDateTime() => '.json_encode($assetLog));
        }
    }
}
