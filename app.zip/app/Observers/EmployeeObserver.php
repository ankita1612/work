<?php

namespace App\Observers;

use App\Models\Employee;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class EmployeeObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the Employee "created" event.
     */
    public function created(Employee $employee): void
    {
        $this->updateLastModuleAccessDateTime($employee);
    }

    /**
     * Handle the Employee "updated" event.
     */
    public function updated(Employee $employee): void
    {
        $this->updateLastModuleAccessDateTime($employee);
    }

    /**
     * Handle the Employee "deleted" event.
     */
    public function deleted(Employee $employee): void
    {
        $this->updateLastModuleAccessDateTime($employee);
    }

    /**
     * Handle the Employee "restored" event.
     */
    public function restored(Employee $employee): void
    {
        $this->updateLastModuleAccessDateTime($employee);
    }

    /**
     * Handle the Employee "force deleted" event.
     */
    public function forceDeleted(Employee $employee): void
    {
        // $this->updateLastModuleAccessDateTime($employee);
    }

    public function updateLastModuleAccessDateTime($employee)
    {
        try {
            $employee_list = Employee::where('id', $employee->id)
                ->with('employeeSecondaryWorkLocation')->get();
            foreach ($employee_list as $key => $value) {
                try{
                    $is_avail = LocationModuleLastUpdate::where(['location_id' => $value->primary_work_location_id, 'module_name' => 'employee'])->first();
                    if ($is_avail) {
                        LocationModuleLastUpdate::where(['location_id' => $value->primary_work_location_id, 'module_name' => 'employee'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                    } else {
                        LocationModuleLastUpdate::create(['location_id' => $value->primary_work_location_id, 'module_name' => 'employee']);
                    }
                    foreach ($value->employeeSecondaryWorkLocation as $key_sec => $value_sec) {
                        try{
                            $is_avail_sec = LocationModuleLastUpdate::where(['location_id' => $value_sec->location_id, 'module_name' => 'employee'])->first();
                            if ($is_avail_sec) {
                                LocationModuleLastUpdate::where(['location_id' => $value_sec->location_id, 'module_name' => 'employee'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                            } else {
                                LocationModuleLastUpdate::create(['location_id' => $value_sec->location_id, 'module_name' => 'employee']);
                            }
                        } catch (\Exception $e) {
                            Log::error('EmployeeObserver/updateLastModuleAccessDateTime()[employeeSecondaryWorkLocation_error] => '.$e->getMessage());
                            Log::error('EmployeeObserver/updateLastModuleAccessDateTime() =>[employeeSecondaryWorkLocation_data] '.json_encode($value_sec));
                        }
                    }
                } catch (\Exception $e) {
                    Log::error('EmployeeObserver/updateLastModuleAccessDateTime()[employee_list_error] => '.$e->getMessage());
                    Log::error('EmployeeObserver/updateLastModuleAccessDateTime() =>[employee_list_data] '.json_encode($value));
                }
            }
        } catch (\Exception $e) {
            Log::error('EmployeeObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('EmployeeObserver/updateLastModuleAccessDateTime() => ' . json_encode($employee));
        }
    }
}
