<?php

namespace App\Observers;

use App\Models\BusinessAssociatesLocation;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class BusinessAssociatesLocationObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the BusinessAssociatesLocation "created" event.
     */
    public function created(BusinessAssociatesLocation $businessAssociatesLocation): void
    {
        $this->updateLastModuleAccessDateTime($businessAssociatesLocation);
    }

    /**
     * Handle the BusinessAssociatesLocation "updated" event.
     */
    public function updated(BusinessAssociatesLocation $businessAssociatesLocation): void
    {
        $this->updateLastModuleAccessDateTime($businessAssociatesLocation);
    }

    /**
     * Handle the BusinessAssociatesLocation "deleted" event.
     */
    public function deleted(BusinessAssociatesLocation $businessAssociatesLocation): void
    {
        $this->updateLastModuleAccessDateTime($businessAssociatesLocation);
    }

    /**
     * Handle the BusinessAssociatesLocation "restored" event.
     */
    public function restored(BusinessAssociatesLocation $businessAssociatesLocation): void
    {
        $this->updateLastModuleAccessDateTime($businessAssociatesLocation);
    }

    /**
     * Handle the BusinessAssociatesLocation "force deleted" event.
     */
    public function forceDeleted(BusinessAssociatesLocation $businessAssociatesLocation): void
    {
        // $this->updateLastModuleAccessDateTime($businessAssociatesLocation);
    }

    public function updateLastModuleAccessDateTime($businessAssociatesLocation)
    {
        try{
            $BusinessAssociatesLocation_list = BusinessAssociatesLocation::where('id', $businessAssociatesLocation->id)->get();
            foreach ($BusinessAssociatesLocation_list as $key => $value) {
                $is_avail = LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'business_associates'])->first();
                if ($is_avail) {
                    LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'business_associates'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                } else {
                    LocationModuleLastUpdate::create(['location_id' => $value->location_id, 'module_name' => 'business_associates']);
                }
            }
        }catch (\Exception $e) {
            Log::error('BusinessAssociatesLocationObserver/updateLastModuleAccessDateTime() => '.$e->getMessage());
            Log::error('BusinessAssociatesLocationObserver/updateLastModuleAccessDateTime() => '.json_encode($businessAssociatesLocation));
        }
    }
}
