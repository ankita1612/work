<?php

namespace App\Observers;

use App\Models\Employee;
use App\Models\HipaaComplianceOfficer;
use App\Models\LocationModuleLastUpdate;
use App\Models\Student;
use App\Models\TrainingAttempt;
use App\Models\TrainingInvite;
use Illuminate\Support\Facades\Log;

class TrainingAttemptObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the TrainingAttempt "created" event.
     */
    public function created(TrainingAttempt $trainingAttempt): void
    {
        $this->updateLastModuleAccessDateTime($trainingAttempt);
    }

    /**
     * Handle the TrainingAttempt "updated" event.
     */
    public function updated(TrainingAttempt $trainingAttempt): void
    {
        $this->updateLastModuleAccessDateTime($trainingAttempt);
    }

    /**
     * Handle the TrainingAttempt "deleted" event.
     */
    public function deleted(TrainingAttempt $trainingAttempt): void
    {
        $this->updateLastModuleAccessDateTime($trainingAttempt);
    }

    /**
     * Handle the TrainingAttempt "restored" event.
     */
    public function restored(TrainingAttempt $trainingAttempt): void
    {
        $this->updateLastModuleAccessDateTime($trainingAttempt);
    }

    /**
     * Handle the TrainingAttempt "force deleted" event.
     */
    public function forceDeleted(TrainingAttempt $trainingAttempt): void
    {
        // $this->updateLastModuleAccessDateTime($trainingAttempt);
    }

    public function updateLastModuleAccessDateTime($trainingAttempt)
    {
        try {
            $trainingInvite = TrainingInvite::where('id', $trainingAttempt->invite_id)->first();
            if ($trainingInvite) {
                if ($trainingInvite->emp_user_acntuser_student_type == \App\Models\Employee::class) {
                    $employee = Employee::where('id', $trainingInvite->emp_user_acntuser_student_id)
                        ->with('employeeSecondaryWorkLocation')->get();
                    foreach ($employee as $key => $value) {
                        try{
                            $is_avail_primary = LocationModuleLastUpdate::where(['location_id' => $value->primary_work_location_id, 'module_name' => 'training'])->first();
                            if ($is_avail_primary) {
                                LocationModuleLastUpdate::where(['location_id' => $value->primary_work_location_id, 'module_name' => 'training'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                            } else {
                                LocationModuleLastUpdate::create(['location_id' => $value->primary_work_location_id, 'module_name' => 'training']);
                            }
                            foreach ($value->employeeSecondaryWorkLocation as $key_sec => $value_sec) {
                                try{
                                    $is_avail_sec = LocationModuleLastUpdate::where(['location_id' => $value_sec->location_id, 'module_name' => 'training'])->first();
                                    if ($is_avail_sec) {
                                        LocationModuleLastUpdate::where(['location_id' => $value_sec->location_id, 'module_name' => 'training'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                                    } else {
                                        LocationModuleLastUpdate::create(['location_id' => $value_sec->location_id, 'module_name' => 'training']);
                                    }
                                }catch (\Exception $e) {
                                    Log::error('TrainingAttemptObserver/updateLastModuleAccessDateTime()[employeeSecondaryWorkLocation_error] => ' . $e->getMessage());
                                    Log::error('TrainingAttemptObserver/updateLastModuleAccessDateTime() =>[employeeSecondaryWorkLocation_error] ' . json_encode($value_sec));
                                }
                            }
                        }catch (\Exception $e) {
                            Log::error('TrainingAttemptObserver/updateLastModuleAccessDateTime()[employee_list_error] => ' . $e->getMessage());
                            Log::error('TrainingAttemptObserver/updateLastModuleAccessDateTime() =>[employee_list_error] ' . json_encode($value));
                        }
                    }
                } elseif ($trainingInvite->emp_user_acntuser_student_type == \App\Models\Student::class) {
                    $student = Student::find($trainingInvite->emp_user_acntuser_student_id);
                    if ($student) {
                        $is_avail_primary = LocationModuleLastUpdate::where(['location_id' => $student->primary_work_location_id, 'module_name' => 'training'])->first();
                        if ($is_avail_primary) {
                            LocationModuleLastUpdate::where(['location_id' => $student->primary_work_location_id, 'module_name' => 'training'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                        } else {
                            LocationModuleLastUpdate::create(['location_id' => $student->primary_work_location_id, 'module_name' => 'training']);
                        }
                    }
                } else {
                    $hco = HipaaComplianceOfficer::where(['hco_id' => $trainingInvite->emp_user_acntuser_student_id, 'hco_type' => $trainingInvite->emp_user_acntuser_student_type])->get();
                    foreach ($hco as $key => $value) {
                        try{
                            $is_avail_sec = LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'training'])->first();
                            if ($is_avail_sec) {
                                LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'training'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                            } else {
                                LocationModuleLastUpdate::create(['location_id' => $value->location_id, 'module_name' => 'training']);
                            }
                        }catch (\Exception $e) {
                            Log::error('TrainingAttemptObserver/updateLastModuleAccessDateTime()[hco_list_error] => ' . $e->getMessage());
                            Log::error('TrainingAttemptObserver/updateLastModuleAccessDateTime() =>[hco_list_error] ' . json_encode($value));
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('TrainingAttemptObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('TrainingAttemptObserver/updateLastModuleAccessDateTime() => ' . json_encode($trainingAttempt));
        }
    }
}
