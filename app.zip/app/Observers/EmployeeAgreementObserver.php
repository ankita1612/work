<?php

namespace App\Observers;

use App\Models\Employee;
use App\Models\EmployeeAgreement;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class EmployeeAgreementObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the EmployeeAgreement "created" event.
     */
    public function created(EmployeeAgreement $employeeAgreement): void
    {
        $this->updateLastModuleAccessDateTime($employeeAgreement);
    }

    /**
     * Handle the EmployeeAgreement "updated" event.
     */
    public function updated(EmployeeAgreement $employeeAgreement): void
    {
        $this->updateLastModuleAccessDateTime($employeeAgreement);
    }

    /**
     * Handle the EmployeeAgreement "deleted" event.
     */
    public function deleted(EmployeeAgreement $employeeAgreement): void
    {
        $this->updateLastModuleAccessDateTime($employeeAgreement);
    }

    /**
     * Handle the EmployeeAgreement "restored" event.
     */
    public function restored(EmployeeAgreement $employeeAgreement): void
    {
        $this->updateLastModuleAccessDateTime($employeeAgreement);
    }

    /**
     * Handle the EmployeeAgreement "force deleted" event.
     */
    public function forceDeleted(EmployeeAgreement $employeeAgreement): void
    {
        // $this->updateLastModuleAccessDateTime($employeeAgreement);
    }

    public function updateLastModuleAccessDateTime($employeeAgreement)
    {
        try {
            $employee = Employee::where('id', $employeeAgreement->employee_id)
                ->with('employeeSecondaryWorkLocation')->get();
            foreach ($employee as $key => $value) {
                $is_avail_primary = LocationModuleLastUpdate::where(['location_id' => $value->primary_work_location_id, 'module_name' => 'employee'])->first();
                if ($is_avail_primary) {
                    LocationModuleLastUpdate::where(['location_id' => $value->primary_work_location_id, 'module_name' => 'employee'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                } else {
                    LocationModuleLastUpdate::create(['location_id' => $value->primary_work_location_id, 'module_name' => 'employee']);
                }
                foreach ($value->employeeSecondaryWorkLocation as $key_sec => $value_sec) {
                    $is_avail_sec = LocationModuleLastUpdate::where(['location_id' => $value_sec->location_id, 'module_name' => 'employee'])->first();
                    if ($is_avail_sec) {
                        LocationModuleLastUpdate::where(['location_id' => $value_sec->location_id, 'module_name' => 'employee'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                    } else {
                        LocationModuleLastUpdate::create(['location_id' => $value_sec->location_id, 'module_name' => 'employee']);
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('EmployeeAgreementObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('EmployeeAgreementObserver/updateLastModuleAccessDateTime() => ' . json_encode($employeeAgreement));
        }
    }
}
