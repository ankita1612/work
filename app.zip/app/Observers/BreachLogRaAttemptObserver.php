<?php

namespace App\Observers;

use App\Models\BreachLog;
use App\Models\BreachLogRaAttempt;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class BreachLogRaAttemptObserver
{
    /**
     * Handle the BreachLogRaAttempt "created" event.
     */
    public function created(BreachLogRaAttempt $breachLogRaAttempt): void
    {
        $this->updateLastModuleAccessDateTime($breachLogRaAttempt);
    }

    /**
     * Handle the BreachLogRaAttempt "updated" event.
     */
    public function updated(BreachLogRaAttempt $breachLogRaAttempt): void
    {
        $this->updateLastModuleAccessDateTime($breachLogRaAttempt);
    }

    /**
     * Handle the BreachLogRaAttempt "deleted" event.
     */
    public function deleted(BreachLogRaAttempt $breachLogRaAttempt): void
    {
        $this->updateLastModuleAccessDateTime($breachLogRaAttempt);
    }

    /**
     * Handle the BreachLogRaAttempt "restored" event.
     */
    public function restored(BreachLogRaAttempt $breachLogRaAttempt): void
    {
        $this->updateLastModuleAccessDateTime($breachLogRaAttempt);
    }

    /**
     * Handle the BreachLogRaAttempt "force deleted" event.
     */
    public function forceDeleted(BreachLogRaAttempt $breachLogRaAttempt): void
    {
        //
    }

    public function updateLastModuleAccessDateTime($breachLogRaAttempt)
    {
        try{
            $breachLog = BreachLog::find($breachLogRaAttempt->breach_log_id);
            if ($breachLog) {
                $is_avail = LocationModuleLastUpdate::where(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs'])->first();
                if ($is_avail) {
                    LocationModuleLastUpdate::where(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                } else {
                    LocationModuleLastUpdate::create(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs']);
                }
            }
         } catch (\Exception $e) {
            Log::error('BreachLogRaAttemptObserver/updateLastModuleAccessDateTime() => '.$e->getMessage());
            Log::error('BreachLogRaAttemptObserver/updateLastModuleAccessDateTime() => '.json_encode($breachLogRaAttempt));
        }
    }
}
