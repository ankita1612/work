<?php

namespace App\Observers;

use App\Models\AccessLog;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class AccessLogObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the AccessLog "created" event.
     */
    public function created(AccessLog $accessLog): void
    {
        $this->updateLastModuleAccessDateTime($accessLog);
    }

    /**
     * Handle the AccessLog "updated" event.
     */
    public function updated(AccessLog $accessLog): void
    {
        $this->updateLastModuleAccessDateTime($accessLog);
    }

    /**
     * Handle the AccessLog "deleted" event.
     */
    public function deleted(AccessLog $accessLog): void
    {
        $this->updateLastModuleAccessDateTime($accessLog);
    }

    /**
     * Handle the AccessLog "restored" event.
     */
    public function restored(AccessLog $accessLog): void
    {
        $this->updateLastModuleAccessDateTime($accessLog);
    }

    /**
     * Handle the AccessLog "force deleted" event.
     */
    public function forceDeleted(AccessLog $accessLog): void
    {
        // $this->updateLastModuleAccessDateTime($accessLog);
    }

    public function updateLastModuleAccessDateTime($accessLog)
    {
        try{
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $accessLog->location_id, 'module_name' => 'hipaa_logs'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $accessLog->location_id, 'module_name' => 'hipaa_logs'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $accessLog->location_id, 'module_name' => 'hipaa_logs']);
            }
        } catch (\Exception $e) {
            Log::error('AccessLogObserver/updateLastModuleAccessDateTime() => '.$e->getMessage());
            Log::error('AccessLogObserver/updateLastModuleAccessDateTime() => '.json_encode($accessLog));
        }
    }
}
