<?php

namespace App\Observers;

use App\Models\HipaaComplianceOfficer;

class HipaaComplianceOfficerObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the HipaaComplianceOfficer "created" event.
     */
    public function created(HipaaComplianceOfficer $hipaaComplianceOfficer): void
    {
        $this->updateLastModuleAccessDateTime($hipaaComplianceOfficer);
    }

    /**
     * Handle the HipaaComplianceOfficer "updated" event.
     */
    public function updated(HipaaComplianceOfficer $hipaaComplianceOfficer): void
    {
        $this->updateLastModuleAccessDateTime($hipaaComplianceOfficer);
    }

    /**
     * Handle the HipaaComplianceOfficer "deleted" event.
     */
    public function deleted(HipaaComplianceOfficer $hipaaComplianceOfficer): void
    {
        $this->updateLastModuleAccessDateTime($hipaaComplianceOfficer);
    }

    /**
     * Handle the HipaaComplianceOfficer "restored" event.
     */
    public function restored(HipaaComplianceOfficer $hipaaComplianceOfficer): void
    {
        $this->updateLastModuleAccessDateTime($hipaaComplianceOfficer);
    }

    /**
     * Handle the HipaaComplianceOfficer "force deleted" event.
     */
    public function forceDeleted(HipaaComplianceOfficer $hipaaComplianceOfficer): void
    {
        // $this->updateLastModuleAccessDateTime($hipaaComplianceOfficer);
    }

    public function updateLastModuleAccessDateTime($hipaaComplianceOfficer) {}
}
