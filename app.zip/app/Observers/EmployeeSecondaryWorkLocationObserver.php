<?php

namespace App\Observers;

use App\Models\EmployeeSecondaryWorkLocation;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class EmployeeSecondaryWorkLocationObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the EmployeeSecondaryWorkLocation "created" event.
     */
    public function created(EmployeeSecondaryWorkLocation $employeeSecondaryWorkLocation): void
    {
        $this->updateLastModuleAccessDateTime($employeeSecondaryWorkLocation);
    }

    /**
     * Handle the EmployeeSecondaryWorkLocation "updated" event.
     */
    public function updated(EmployeeSecondaryWorkLocation $employeeSecondaryWorkLocation): void
    {
        $this->updateLastModuleAccessDateTime($employeeSecondaryWorkLocation);
    }

    /**
     * Handle the EmployeeSecondaryWorkLocation "deleted" event.
     */
    public function deleted(EmployeeSecondaryWorkLocation $employeeSecondaryWorkLocation): void
    {
        $this->updateLastModuleAccessDateTime($employeeSecondaryWorkLocation);
    }

    /**
     * Handle the EmployeeSecondaryWorkLocation "restored" event.
     */
    public function restored(EmployeeSecondaryWorkLocation $employeeSecondaryWorkLocation): void
    {
        $this->updateLastModuleAccessDateTime($employeeSecondaryWorkLocation);
    }

    /**
     * Handle the EmployeeSecondaryWorkLocation "force deleted" event.
     */
    public function forceDeleted(EmployeeSecondaryWorkLocation $employeeSecondaryWorkLocation): void
    {
        // $this->updateLastModuleAccessDateTime($employeeSecondaryWorkLocation);
    }

    public function updateLastModuleAccessDateTime($employeeSecondaryWorkLocation)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $employeeSecondaryWorkLocation->location_id, 'module_name' => 'employee'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $employeeSecondaryWorkLocation->location_id, 'module_name' => 'employee'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $employeeSecondaryWorkLocation->location_id, 'module_name' => 'employee']);
            }
        } catch (\Exception $e) {
            Log::error('EmployeeSecondaryWorkLocationObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('EmployeeSecondaryWorkLocationObserver/updateLastModuleAccessDateTime() => ' . json_encode($employeeSecondaryWorkLocation));
        }
    }
}
