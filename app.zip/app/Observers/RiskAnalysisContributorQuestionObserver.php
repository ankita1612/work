<?php

namespace App\Observers;

use App\Models\RiskAnalysisContributorQuestion;
use App\Models\RiskAnalysisContributorLocation;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class RiskAnalysisContributorQuestionObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the RiskAnalysisContributorQuestion "created" event.
     */
    public function created(RiskAnalysisContributorQuestion $risk_analysis_contributor_question): void
    {
        $this->updateLastModuleAccessDateTime($risk_analysis_contributor_question);
    }

    /**
     * Handle the RiskAnalysisContributorQuestion "updated" event.
     */
    public function updated(RiskAnalysisContributorQuestion $risk_analysis_contributor_question): void
    {
        $this->updateLastModuleAccessDateTime($risk_analysis_contributor_question);
    }

    /**
     * Handle the RiskAnalysisContributorQuestion "deleted" event.
     */
    public function deleted(RiskAnalysisContributorQuestion $risk_analysis_contributor_question): void
    {
        $this->updateLastModuleAccessDateTime($risk_analysis_contributor_question);
    }

    /**
     * Handle the RiskAnalysisContributorQuestion "restored" event.
     */
    public function restored(RiskAnalysisContributorQuestion $risk_analysis_contributor_question): void
    {
        $this->updateLastModuleAccessDateTime($risk_analysis_contributor_question);
    }

    /**
     * Handle the RiskAnalysisContributorQuestion "force deleted" event.
     */
    public function forceDeleted(RiskAnalysisContributorQuestion $risk_analysis_contributor_question): void
    {
        // $this->updateLastModuleAccessDateTime($risk_analysis_contributor_question);
    }

    public function updateLastModuleAccessDateTime($risk_analysis_contributor_question)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $risk_analysis_contributor_question->location_id, 'module_name' => 'scorecard'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $risk_analysis_contributor_question->location_id, 'module_name' => 'scorecard'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $risk_analysis_contributor_question->location_id, 'module_name' => 'scorecard']);
            }
        } catch (\Exception $e) {
            Log::error('RiskAnalysisContributorQuestionObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('RiskAnalysisContributorQuestionObserver/updateLastModuleAccessDateTime() => ' . json_encode($risk_analysis_contributor_question));
        }
    }
}
