<?php

namespace App\Observers;

use App\Models\LocationModuleLastUpdate;
use App\Models\RiskAnalysisAttemptedQuestion;
use Illuminate\Support\Facades\Log;

class RiskAnalysisAttemptedQuestionObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the RiskAnalysisAttemptedQuestion "created" event.
     */
    public function created(RiskAnalysisAttemptedQuestion $riskAnalysisAttemptedQuestion): void
    {
        $this->updateLastModuleAccessDateTime($riskAnalysisAttemptedQuestion);
    }

    /**
     * Handle the RiskAnalysisAttemptedQuestion "updated" event.
     */
    public function updated(RiskAnalysisAttemptedQuestion $riskAnalysisAttemptedQuestion): void
    {
        $this->updateLastModuleAccessDateTime($riskAnalysisAttemptedQuestion);
    }

    /**
     * Handle the RiskAnalysisAttemptedQuestion "deleted" event.
     */
    public function deleted(RiskAnalysisAttemptedQuestion $riskAnalysisAttemptedQuestion): void
    {
        $this->updateLastModuleAccessDateTime($riskAnalysisAttemptedQuestion);
    }

    /**
     * Handle the RiskAnalysisAttemptedQuestion "restored" event.
     */
    public function restored(RiskAnalysisAttemptedQuestion $riskAnalysisAttemptedQuestion): void
    {
        $this->updateLastModuleAccessDateTime($riskAnalysisAttemptedQuestion);
    }

    /**
     * Handle the RiskAnalysisAttemptedQuestion "force deleted" event.
     */
    public function forceDeleted(RiskAnalysisAttemptedQuestion $riskAnalysisAttemptedQuestion): void
    {
        // $this->updateLastModuleAccessDateTime($riskAnalysisAttemptedQuestion);
    }

    public function updateLastModuleAccessDateTime($riskAnalysisAttemptedQuestion)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $riskAnalysisAttemptedQuestion->location_id, 'module_name' => 'scorecard'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $riskAnalysisAttemptedQuestion->location_id, 'module_name' => 'scorecard'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $riskAnalysisAttemptedQuestion->location_id, 'module_name' => 'scorecard']);
            }
        } catch (\Exception $e) {
            Log::error('RiskAnalysisAttemptedQuestionObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('RiskAnalysisAttemptedQuestionObserver/updateLastModuleAccessDateTime() => ' . json_encode($riskAnalysisAttemptedQuestion));
        }
    }
}
