<?php

namespace App\Observers;

use App\Models\AccountUserLocationAccess;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class AccountUserLocationAccessObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the AccountUserLocationAccess "created" event.
     */
    public function created(AccountUserLocationAccess $accountUserLocationAccess): void
    {
        $this->updateLastModuleAccessDateTime($accountUserLocationAccess);
    }

    /**
     * Handle the AccountUserLocationAccess "updated" event.
     */
    public function updated(AccountUserLocationAccess $accountUserLocationAccess): void
    {
        $this->updateLastModuleAccessDateTime($accountUserLocationAccess);
    }

    /**
     * Handle the AccountUserLocationAccess "deleted" event.
     */
    public function deleted(AccountUserLocationAccess $accountUserLocationAccess): void
    {
        $this->updateLastModuleAccessDateTime($accountUserLocationAccess);
    }

    /**
     * Handle the AccountUserLocationAccess "restored" event.
     */
    public function restored(AccountUserLocationAccess $accountUserLocationAccess): void
    {
        $this->updateLastModuleAccessDateTime($accountUserLocationAccess);
    }

    /**
     * Handle the AccountUserLocationAccess "force deleted" event.
     */
    public function forceDeleted(AccountUserLocationAccess $accountUserLocationAccess): void
    {
        // $this->updateLastModuleAccessDateTime($accountUserLocationAccess);
    }

    public function updateLastModuleAccessDateTime($accountUserLocationAccess)
    {
        try{
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $accountUserLocationAccess->location_id, 'module_name' => 'account_user'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $accountUserLocationAccess->location_id, 'module_name' => 'account_user'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $accountUserLocationAccess->location_id, 'module_name' => 'account_user']);
            }
        } catch (\Exception $e) {
            Log::error('AccountUserLocationAccessObserver/updateLastModuleAccessDateTime() => '.$e->getMessage());
            Log::error('AccountUserLocationAccessObserver/updateLastModuleAccessDateTime() => '.json_encode($accountUserLocationAccess));
        }
    }
}
