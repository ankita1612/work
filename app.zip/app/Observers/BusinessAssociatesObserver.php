<?php

namespace App\Observers;

use App\Models\BusinessAssociates;
use App\Models\BusinessAssociatesLocation;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class BusinessAssociatesObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the BusinessAssociates "created" event.
     */
    public function created(BusinessAssociates $business_associates): void
    {
        $this->updateLastModuleAccessDateTime($business_associates);
    }

    /**
     * Handle the BusinessAssociates "updated" event.
     */
    public function updated(BusinessAssociates $business_associates): void
    {
        $this->updateLastModuleAccessDateTime($business_associates);
    }

    /**
     * Handle the BusinessAssociates "deleted" event.
     */
    public function deleted(BusinessAssociates $business_associates): void
    {
        $this->updateLastModuleAccessDateTime($business_associates);
    }

    /**
     * Handle the BusinessAssociates "restored" event.
     */
    public function restored(BusinessAssociates $business_associates): void
    {
        $this->updateLastModuleAccessDateTime($business_associates);
    }

    /**
     * Handle the BusinessAssociates "force deleted" event.
     */
    public function forceDeleted(BusinessAssociates $business_associates): void
    {
        // $this->updateLastModuleAccessDateTime($business_associates);
    }

    public function updateLastModuleAccessDateTime($business_associates)
    {
        try {
            $business_associates_location_list = BusinessAssociatesLocation::where('business_associate_id', $business_associates->id)->get();
            foreach ($business_associates_location_list as $key => $value) {
                $is_avail = LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'business_associates'])->first();
                if ($is_avail) {
                    LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'business_associates'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                } else {
                    LocationModuleLastUpdate::create(['location_id' => $value->location_id, 'module_name' => 'business_associates']);
                }
            }
        } catch (\Exception $e) {
            Log::error('BusinessAssociatesObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('BusinessAssociatesObserver/updateLastModuleAccessDateTime() => ' . json_encode($business_associates));
        }
    }
}
