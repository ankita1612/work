<?php

namespace App\Observers;

use App\Models\Location;

class LocationObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the Location "created" event.
     */
    public function created(Location $location): void
    {
        $this->updateLastModuleAccessDateTime($location);
    }

    /**
     * Handle the Location "updated" event.
     */
    public function updated(Location $location): void
    {
        $this->updateLastModuleAccessDateTime($location);
    }

    /**
     * Handle the Location "deleted" event.
     */
    public function deleted(Location $location): void
    {
        $this->updateLastModuleAccessDateTime($location);
    }

    /**
     * Handle the Location "restored" event.
     */
    public function restored(Location $location): void
    {
        $this->updateLastModuleAccessDateTime($location);
    }

    /**
     * Handle the Location "force deleted" event.
     */
    public function forceDeleted(Location $location): void
    {
        // $this->updateLastModuleAccessDateTime($location);
    }

    public function updateLastModuleAccessDateTime($location) {}
}
