<?php

namespace App\Observers;

use App\Models\RiskAnalysisContributorLocation;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class RiskAnalysisContributorLocationObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the RiskAnalysisContributorLocation "created" event.
     */
    public function created(RiskAnalysisContributorLocation $RiskAnalysisContributorLocation): void
    {
        $this->updateLastModuleAccessDateTime($RiskAnalysisContributorLocation);
    }

    /**
     * Handle the RiskAnalysisContributorLocation "updated" event.
     */
    public function updated(RiskAnalysisContributorLocation $RiskAnalysisContributorLocation): void
    {
        $this->updateLastModuleAccessDateTime($RiskAnalysisContributorLocation);
    }

    /**
     * Handle the RiskAnalysisContributorLocation "deleted" event.
     */
    public function deleted(RiskAnalysisContributorLocation $RiskAnalysisContributorLocation): void
    {
        $this->updateLastModuleAccessDateTime($RiskAnalysisContributorLocation);
    }

    /**
     * Handle the RiskAnalysisContributorLocation "restored" event.
     */
    public function restored(RiskAnalysisContributorLocation $RiskAnalysisContributorLocation): void
    {
        $this->updateLastModuleAccessDateTime($RiskAnalysisContributorLocation);
    }

    /**
     * Handle the RiskAnalysisContributorLocation "force deleted" event.
     */
    public function forceDeleted(RiskAnalysisContributorLocation $RiskAnalysisContributorLocation): void
    {
        // $this->updateLastModuleAccessDateTime($RiskAnalysisContributorLocation);
    }

    public function updateLastModuleAccessDateTime($RiskAnalysisContributorLocation)
    {
        try {
            $RiskAnalysisContributorLocation_list = RiskAnalysisContributorLocation::where('id', $RiskAnalysisContributorLocation->id)->get();
            foreach ($RiskAnalysisContributorLocation_list as $key => $value) {
                try{
                    $is_avail = LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'account_user'])->first();
                    if ($is_avail) {
                        LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'account_user'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                    } else {
                        LocationModuleLastUpdate::create(['location_id' => $value->location_id, 'module_name' => 'account_user']);
                    }
                } catch (\Exception $e) {
                    Log::error('RiskAnalysisContributorLocationObserver/updateLastModuleAccessDateTime()[RiskAnalysisContributorLocation_list_error] => '.$e->getMessage());
                    Log::error('RiskAnalysisContributorLocationObserver/updateLastModuleAccessDateTime() =>[RiskAnalysisContributorLocation_list_data] '.json_encode($value));
                }
            }
        } catch (\Exception $e) {
            Log::error('RiskAnalysisContributorLocationObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('RiskAnalysisContributorLocationObserver/updateLastModuleAccessDateTime() => ' . json_encode($RiskAnalysisContributorLocation));
        }
    }
}
