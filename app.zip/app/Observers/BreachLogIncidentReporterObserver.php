<?php

namespace App\Observers;

use App\Models\BreachLog;
use App\Models\BreachLogIncidentReporter;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class BreachLogIncidentReporterObserver
{
    /**
     * Handle the BreachLogIncidentReporter "created" event.
     */
    public function created(BreachLogIncidentReporter $breachLogIncidentReporter): void
    {
        $this->updateLastModuleAccessDateTime($breachLogIncidentReporter);
    }

    /**
     * Handle the BreachLogIncidentReporter "updated" event.
     */
    public function updated(BreachLogIncidentReporter $breachLogIncidentReporter): void
    {
        $this->updateLastModuleAccessDateTime($breachLogIncidentReporter);
    }

    /**
     * Handle the BreachLogIncidentReporter "deleted" event.
     */
    public function deleted(BreachLogIncidentReporter $breachLogIncidentReporter): void
    {
        $this->updateLastModuleAccessDateTime($breachLogIncidentReporter);
    }

    /**
     * Handle the BreachLogIncidentReporter "restored" event.
     */
    public function restored(BreachLogIncidentReporter $breachLogIncidentReporter): void
    {
        $this->updateLastModuleAccessDateTime($breachLogIncidentReporter);
    }

    /**
     * Handle the BreachLogIncidentReporter "force deleted" event.
     */
    public function forceDeleted(BreachLogIncidentReporter $breachLogIncidentReporter): void
    {
        //
    }

    public function updateLastModuleAccessDateTime($breachLogIncidentReporter)
    {
        try{
            $breachLog = BreachLog::find($breachLogIncidentReporter->breach_log_id);
            if ($breachLog) {
                $is_avail = LocationModuleLastUpdate::where(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs'])->first();
                if ($is_avail) {
                    LocationModuleLastUpdate::where(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                } else {
                    LocationModuleLastUpdate::create(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs']);
                }
            }
        } catch (\Exception $e) {
            Log::error('BreachLogIncidentReporterObserver/updateLastModuleAccessDateTime() => '.$e->getMessage());
            Log::error('BreachLogIncidentReporterObserver/updateLastModuleAccessDateTime() => '.json_encode($breachLogIncidentReporter));
        }
    }
}
