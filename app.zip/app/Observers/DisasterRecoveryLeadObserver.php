<?php

namespace App\Observers;

use App\Models\DisasterRecoveryLead;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class DisasterRecoveryLeadObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the DisasterRecoveryLead "created" event.
     */
    public function created(DisasterRecoveryLead $disasterRecoveryLead): void
    {
        $this->updateLastModuleAccessDateTime($disasterRecoveryLead);
    }

    /**
     * Handle the DisasterRecoveryLead "updated" event.
     */
    public function updated(DisasterRecoveryLead $disasterRecoveryLead): void
    {
        $this->updateLastModuleAccessDateTime($disasterRecoveryLead);
    }

    /**
     * Handle the DisasterRecoveryLead "deleted" event.
     */
    public function deleted(DisasterRecoveryLead $disasterRecoveryLead): void
    {
        $this->updateLastModuleAccessDateTime($disasterRecoveryLead);
    }

    /**
     * Handle the DisasterRecoveryLead "restored" event.
     */
    public function restored(DisasterRecoveryLead $disasterRecoveryLead): void
    {
        $this->updateLastModuleAccessDateTime($disasterRecoveryLead);
    }

    /**
     * Handle the DisasterRecoveryLead "force deleted" event.
     */
    public function forceDeleted(DisasterRecoveryLead $disasterRecoveryLead): void
    {
        // $this->updateLastModuleAccessDateTime($disasterRecoveryLead);
    }

    public function updateLastModuleAccessDateTime($disasterRecoveryLead)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $disasterRecoveryLead->location_id, 'module_name' => 'disaster'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $disasterRecoveryLead->location_id, 'module_name' => 'disaster'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $disasterRecoveryLead->location_id, 'module_name' => 'disaster']);
            }
        } catch (\Exception $e) {
            Log::error('DisasterRecoveryLeadObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('DisasterRecoveryLeadObserver/updateLastModuleAccessDateTime() => ' . json_encode($disasterRecoveryLead));
        }
    }
}
