<?php

namespace App\Observers;

use App\Models\DisasterVendor;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class DisasterVendorObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the DisasterVendor "created" event.
     */
    public function created(DisasterVendor $disasterVendor): void
    {
        $this->updateLastModuleAccessDateTime($disasterVendor);
    }

    /**
     * Handle the DisasterVendor "updated" event.
     */
    public function updated(DisasterVendor $disasterVendor): void
    {
        $this->updateLastModuleAccessDateTime($disasterVendor);
    }

    /**
     * Handle the DisasterVendor "deleted" event.
     */
    public function deleted(DisasterVendor $disasterVendor): void
    {
        $this->updateLastModuleAccessDateTime($disasterVendor);
    }

    /**
     * Handle the DisasterVendor "restored" event.
     */
    public function restored(DisasterVendor $disasterVendor): void
    {
        $this->updateLastModuleAccessDateTime($disasterVendor);
    }

    /**
     * Handle the DisasterVendor "force deleted" event.
     */
    public function forceDeleted(DisasterVendor $disasterVendor): void
    {
        // $this->updateLastModuleAccessDateTime($disasterVendor);
    }

    public function updateLastModuleAccessDateTime($disasterVendor)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $disasterVendor->location_id, 'module_name' => 'disaster'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $disasterVendor->location_id, 'module_name' => 'disaster'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $disasterVendor->location_id, 'module_name' => 'disaster']);
            }
        } catch (\Exception $e) {
            Log::error('DisasterVendorObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('DisasterVendorObserver/updateLastModuleAccessDateTime() => ' . json_encode($disasterVendor));
        }
    }
}
