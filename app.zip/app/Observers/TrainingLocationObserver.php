<?php

namespace App\Observers;

use App\Jobs\SendLocationDataToSalesForce;
use App\Models\Location;
use App\Models\LocationModuleLastUpdate;
use App\Models\TrainingLocation;
use Illuminate\Support\Facades\Log;

class TrainingLocationObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the TrainingLocation "created" event.
     */
    public function created(TrainingLocation $training_location): void
    {
        $this->sendLocationDataToSF($training_location);
        $this->updateLastModuleAccessDateTime($training_location);
    }

    /**
     * Handle the TrainingLocation "updated" event.
     */
    public function updated(TrainingLocation $training_location): void
    {
        $this->updateLastModuleAccessDateTime($training_location);
    }

    /**
     * Handle the TrainingLocation "deleted" event.
     */
    public function deleted(TrainingLocation $training_location): void
    {
        $this->updateLastModuleAccessDateTime($training_location);
    }

    /**
     * Handle the TrainingLocation "restored" event.
     */
    public function restored(TrainingLocation $training_location): void
    {
        $this->updateLastModuleAccessDateTime($training_location);
    }

    /**
     * Handle the TrainingLocation "force deleted" event.
     */
    public function forceDeleted(TrainingLocation $training_location): void
    {
        // $this->updateLastModuleAccessDateTime($training_location);
    }

    public function updateLastModuleAccessDateTime($training_location)
    {
        try {
            $training_location_list = TrainingLocation::where('id', $training_location->id)->get();
            foreach ($training_location_list as $key => $value) {
                try{
                    $is_avail = LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'training'])->first();
                    if ($is_avail) {
                        LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'training'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                    } else {
                        LocationModuleLastUpdate::create(['location_id' => $value->location_id, 'module_name' => 'training']);
                    }
                }catch (\Exception $e) {
                    Log::error('TrainingLocationObserver/updateLastModuleAccessDateTime()[training_location_list_error] => ' . $e->getMessage());
                    Log::error('TrainingLocationObserver/updateLastModuleAccessDateTime() =>[training_location_list_error] ' . json_encode($value));
                }
            }
        } catch (\Exception $e) {
            Log::error('TrainingLocationObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('TrainingLocationObserver/updateLastModuleAccessDateTime() => ' . json_encode($training_location));
        }
    }

    public function sendLocationDataToSF($training_location)
    {
        $SF_location = Location::where('id', $training_location->location_id)->whereNotNull('salesforce_unique_id')->first();
        if ($SF_location) {
            SendLocationDataToSalesForce::dispatch($SF_location->id);
        }
    }
}
