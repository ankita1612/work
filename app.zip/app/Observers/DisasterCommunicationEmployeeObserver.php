<?php

namespace App\Observers;

use App\Models\DisasterCommunicationEmployee;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class DisasterCommunicationEmployeeObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the DisasterCommunicationEmployee "created" event.
     */
    public function created(DisasterCommunicationEmployee $disasterCommunicationEmployee): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationEmployee);
    }

    /**
     * Handle the DisasterCommunicationEmployee "updated" event.
     */
    public function updated(DisasterCommunicationEmployee $disasterCommunicationEmployee): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationEmployee);
    }

    /**
     * Handle the DisasterCommunicationEmployee "deleted" event.
     */
    public function deleted(DisasterCommunicationEmployee $disasterCommunicationEmployee): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationEmployee);
    }

    /**
     * Handle the DisasterCommunicationEmployee "restored" event.
     */
    public function restored(DisasterCommunicationEmployee $disasterCommunicationEmployee): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationEmployee);
    }

    /**
     * Handle the DisasterCommunicationEmployee "force deleted" event.
     */
    public function forceDeleted(DisasterCommunicationEmployee $disasterCommunicationEmployee): void
    {
        // $this->updateLastModuleAccessDateTime($disasterCommunicationEmployee);
    }

    public function updateLastModuleAccessDateTime($disasterCommunicationEmployee)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $disasterCommunicationEmployee->location_id, 'module_name' => 'disaster'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $disasterCommunicationEmployee->location_id, 'module_name' => 'disaster'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $disasterCommunicationEmployee->location_id, 'module_name' => 'disaster']);
            }
        } catch (\Exception $e) {
            Log::error('DisasterCommunicationEmployeeObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('DisasterCommunicationEmployeeObserver/updateLastModuleAccessDateTime() => ' . json_encode($disasterCommunicationEmployee));
        }
    }
}
