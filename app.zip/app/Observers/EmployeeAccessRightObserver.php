<?php

namespace App\Observers;

use App\Models\EmployeeAccessRight;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class EmployeeAccessRightObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the EmployeeAccessRight "created" event.
     */
    public function created(EmployeeAccessRight $employeeAccessRight): void
    {
        $this->updateLastModuleAccessDateTime($employeeAccessRight);
    }

    /**
     * Handle the EmployeeAccessRight "updated" event.
     */
    public function updated(EmployeeAccessRight $employeeAccessRight): void
    {
        $this->updateLastModuleAccessDateTime($employeeAccessRight);
    }

    /**
     * Handle the EmployeeAccessRight "deleted" event.
     */
    public function deleted(EmployeeAccessRight $employeeAccessRight): void
    {
        $this->updateLastModuleAccessDateTime($employeeAccessRight);
    }

    /**
     * Handle the EmployeeAccessRight "restored" event.
     */
    public function restored(EmployeeAccessRight $employeeAccessRight): void
    {
        $this->updateLastModuleAccessDateTime($employeeAccessRight);
    }

    /**
     * Handle the EmployeeAccessRight "force deleted" event.
     */
    public function forceDeleted(EmployeeAccessRight $employeeAccessRight): void
    {
        // $this->updateLastModuleAccessDateTime($employeeAccessRight);
    }

    public function updateLastModuleAccessDateTime($employeeAccessRight)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $employeeAccessRight->location_id, 'module_name' => 'employee'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $employeeAccessRight->location_id, 'module_name' => 'employee'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $employeeAccessRight->location_id, 'module_name' => 'employee']);
            }
        } catch (\Exception $e) {
            Log::error('EmployeeAccessRightObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('EmployeeAccessRightObserver/updateLastModuleAccessDateTime() => ' . json_encode($employeeAccessRight));
        }
    }
}
