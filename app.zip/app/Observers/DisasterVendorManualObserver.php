<?php

namespace App\Observers;

use App\Models\DisasterVendorManual;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class DisasterVendorManualObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the DisasterVendorManual "created" event.
     */
    public function created(DisasterVendorManual $disasterVendorManual): void
    {
        $this->updateLastModuleAccessDateTime($disasterVendorManual);
    }

    /**
     * Handle the DisasterVendorManual "updated" event.
     */
    public function updated(DisasterVendorManual $disasterVendorManual): void
    {
        $this->updateLastModuleAccessDateTime($disasterVendorManual);
    }

    /**
     * Handle the DisasterVendorManual "deleted" event.
     */
    public function deleted(DisasterVendorManual $disasterVendorManual): void
    {
        $this->updateLastModuleAccessDateTime($disasterVendorManual);
    }

    /**
     * Handle the DisasterVendorManual "restored" event.
     */
    public function restored(DisasterVendorManual $disasterVendorManual): void
    {
        $this->updateLastModuleAccessDateTime($disasterVendorManual);
    }

    /**
     * Handle the DisasterVendorManual "force deleted" event.
     */
    public function forceDeleted(DisasterVendorManual $disasterVendorManual): void
    {
        // $this->updateLastModuleAccessDateTime($disasterVendorManual);
    }

    public function updateLastModuleAccessDateTime($disasterVendorManual)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $disasterVendorManual->location_id, 'module_name' => 'disaster'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $disasterVendorManual->location_id, 'module_name' => 'disaster'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $disasterVendorManual->location_id, 'module_name' => 'disaster']);
            }
        } catch (\Exception $e) {
            Log::error('DisasterVendorManualObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('DisasterVendorManualObserver/updateLastModuleAccessDateTime() => ' . json_encode($disasterVendorManual));
        }
    }
}
