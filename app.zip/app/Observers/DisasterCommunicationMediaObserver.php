<?php

namespace App\Observers;

use App\Models\DisasterCommunicationMedia;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class DisasterCommunicationMediaObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the DisasterCommunicationMedia "created" event.
     */
    public function created(DisasterCommunicationMedia $disasterCommunicationMedia): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationMedia);
    }

    /**
     * Handle the DisasterCommunicationMedia "updated" event.
     */
    public function updated(DisasterCommunicationMedia $disasterCommunicationMedia): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationMedia);
    }

    /**
     * Handle the DisasterCommunicationMedia "deleted" event.
     */
    public function deleted(DisasterCommunicationMedia $disasterCommunicationMedia): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationMedia);
    }

    /**
     * Handle the DisasterCommunicationMedia "restored" event.
     */
    public function restored(DisasterCommunicationMedia $disasterCommunicationMedia): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationMedia);
    }

    /**
     * Handle the DisasterCommunicationMedia "force deleted" event.
     */
    public function forceDeleted(DisasterCommunicationMedia $disasterCommunicationMedia): void
    {
        // $this->updateLastModuleAccessDateTime($disasterCommunicationMedia);
    }

    public function updateLastModuleAccessDateTime($disasterCommunicationMedia)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $disasterCommunicationMedia->location_id, 'module_name' => 'disaster'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $disasterCommunicationMedia->location_id, 'module_name' => 'disaster'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $disasterCommunicationMedia->location_id, 'module_name' => 'disaster']);
            }
        } catch (\Exception $e) {
            Log::error('DisasterCommunicationMediaObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('DisasterCommunicationMediaObserver/updateLastModuleAccessDateTime() => ' . json_encode($disasterCommunicationMedia));
        }
    }
}
