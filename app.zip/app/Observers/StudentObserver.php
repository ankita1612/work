<?php

namespace App\Observers;

use App\Models\LocationModuleLastUpdate;
use App\Models\Student;
use Illuminate\Support\Facades\Log;

class StudentObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the Student "created" event.
     */
    public function created(Student $student): void
    {
        $this->updateLastModuleAccessDateTime($student);
    }

    /**
     * Handle the Student "updated" event.
     */
    public function updated(Student $student): void
    {
        $this->updateLastModuleAccessDateTime($student);
    }

    /**
     * Handle the Student "deleted" event.
     */
    public function deleted(Student $student): void
    {
        $this->updateLastModuleAccessDateTime($student);
    }

    /**
     * Handle the Student "restored" event.
     */
    public function restored(Student $student): void
    {
        $this->updateLastModuleAccessDateTime($student);
    }

    /**
     * Handle the Student "force deleted" event.
     */
    public function forceDeleted(Student $student): void
    {
        // $this->updateLastModuleAccessDateTime($student);
    }

    public function updateLastModuleAccessDateTime($student)
    {
        try {
            $student_list = Student::where('id', $student->id)->get();
            foreach ($student_list as $key => $value) {
                try{
                    $is_avail = LocationModuleLastUpdate::where(['location_id' => $value->primary_work_location_id, 'module_name' => 'student'])->first();
                    if ($is_avail) {
                        LocationModuleLastUpdate::where(['location_id' => $value->primary_work_location_id, 'module_name' => 'student'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                    } else {
                        LocationModuleLastUpdate::create(['location_id' => $value->primary_work_location_id, 'module_name' => 'student']);
                    }
                } catch (\Exception $e) {
                    Log::error('StudentObserver/updateLastModuleAccessDateTime()[student_list_error] => ' . $e->getMessage());
                    Log::error('StudentObserver/updateLastModuleAccessDateTime() => [student_list_data] ' . json_encode($value));
                }
            }
        } catch (\Exception $e) {
            Log::error('StudentObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('StudentObserver/updateLastModuleAccessDateTime() => ' . json_encode($student));
        }
    }
}
