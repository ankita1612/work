<?php

namespace App\Observers;

use App\Models\RiskAnalysisContributor;
use App\Models\RiskAnalysisContributorLocation;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class RiskAnalysisContributorObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the RiskAnalysisContributor "created" event.
     */
    public function created(RiskAnalysisContributor $risk_analysis_contributor): void
    {
        $this->updateLastModuleAccessDateTime($risk_analysis_contributor);
    }

    /**
     * Handle the RiskAnalysisContributor "updated" event.
     */
    public function updated(RiskAnalysisContributor $risk_analysis_contributor): void
    {
        $this->updateLastModuleAccessDateTime($risk_analysis_contributor);
    }

    /**
     * Handle the RiskAnalysisContributor "deleted" event.
     */
    public function deleted(RiskAnalysisContributor $risk_analysis_contributor): void
    {
        $this->updateLastModuleAccessDateTime($risk_analysis_contributor);
    }

    /**
     * Handle the RiskAnalysisContributor "restored" event.
     */
    public function restored(RiskAnalysisContributor $risk_analysis_contributor): void
    {
        $this->updateLastModuleAccessDateTime($risk_analysis_contributor);
    }

    /**
     * Handle the RiskAnalysisContributor "force deleted" event.
     */
    public function forceDeleted(RiskAnalysisContributor $risk_analysis_contributor): void
    {
        // $this->updateLastModuleAccessDateTime($risk_analysis_contributor);
    }

    public function updateLastModuleAccessDateTime($risk_analysis_contributor)
    {
        try {
            $risk_analysis_contributor_location_list = RiskAnalysisContributorLocation::where('risk_analysis_contributor_id', $risk_analysis_contributor->id)->get();
            foreach ($risk_analysis_contributor_location_list as $key => $value) {
                try{
                    $is_avail = LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'account_user'])->first();
                    if ($is_avail) {
                        LocationModuleLastUpdate::where(['location_id' => $value->location_id, 'module_name' => 'account_user'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                    } else {
                        LocationModuleLastUpdate::create(['location_id' => $value->location_id, 'module_name' => 'account_user']);
                    }
                } catch (\Exception $e) {
                    Log::error('RiskAnalysisContributorObserver/updateLastModuleAccessDateTime()[risk_analysis_contributor_location_list_error] => ' . $e->getMessage());
                    Log::error('RiskAnalysisContributorObserver/updateLastModuleAccessDateTime() =>[risk_analysis_contributor_location_list_data] ' . json_encode($value));
                }
            }
        } catch (\Exception $e) {
            Log::error('RiskAnalysisContributorObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('RiskAnalysisContributorObserver/updateLastModuleAccessDateTime() => ' . json_encode($risk_analysis_contributor));
        }
    }
}
