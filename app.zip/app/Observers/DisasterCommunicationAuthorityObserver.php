<?php

namespace App\Observers;

use App\Models\DisasterCommunicationAuthority;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class DisasterCommunicationAuthorityObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the DisasterCommunicationAuthority "created" event.
     */
    public function created(DisasterCommunicationAuthority $disasterCommunicationAuthority): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationAuthority);
    }

    /**
     * Handle the DisasterCommunicationAuthority "updated" event.
     */
    public function updated(DisasterCommunicationAuthority $disasterCommunicationAuthority): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationAuthority);
    }

    /**
     * Handle the DisasterCommunicationAuthority "deleted" event.
     */
    public function deleted(DisasterCommunicationAuthority $disasterCommunicationAuthority): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationAuthority);
    }

    /**
     * Handle the DisasterCommunicationAuthority "restored" event.
     */
    public function restored(DisasterCommunicationAuthority $disasterCommunicationAuthority): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationAuthority);
    }

    /**
     * Handle the DisasterCommunicationAuthority "force deleted" event.
     */
    public function forceDeleted(DisasterCommunicationAuthority $disasterCommunicationAuthority): void
    {
        // $this->updateLastModuleAccessDateTime($disasterCommunicationAuthority);
    }

    public function updateLastModuleAccessDateTime($disasterCommunicationAuthority)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $disasterCommunicationAuthority->location_id, 'module_name' => 'disaster'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $disasterCommunicationAuthority->location_id, 'module_name' => 'disaster'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $disasterCommunicationAuthority->location_id, 'module_name' => 'disaster']);
            }
        } catch (\Exception $e) {
            Log::error('DisasterCommunicationAuthorityObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('DisasterCommunicationAuthorityObserver/updateLastModuleAccessDateTime() => ' . json_encode($disasterCommunicationAuthority));
        }
    }
}
