<?php

namespace App\Observers;

use App\Models\DisasterCommunicationPatient;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class DisasterCommunicationPatientObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the DisasterCommunicationPatient "created" event.
     */
    public function created(DisasterCommunicationPatient $disasterCommunicationPatient): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationPatient);
    }

    /**
     * Handle the DisasterCommunicationPatient "updated" event.
     */
    public function updated(DisasterCommunicationPatient $disasterCommunicationPatient): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationPatient);
    }

    /**
     * Handle the DisasterCommunicationPatient "deleted" event.
     */
    public function deleted(DisasterCommunicationPatient $disasterCommunicationPatient): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationPatient);
    }

    /**
     * Handle the DisasterCommunicationPatient "restored" event.
     */
    public function restored(DisasterCommunicationPatient $disasterCommunicationPatient): void
    {
        $this->updateLastModuleAccessDateTime($disasterCommunicationPatient);
    }

    /**
     * Handle the DisasterCommunicationPatient "force deleted" event.
     */
    public function forceDeleted(DisasterCommunicationPatient $disasterCommunicationPatient): void
    {
        // $this->updateLastModuleAccessDateTime($disasterCommunicationPatient);
    }

    public function updateLastModuleAccessDateTime($disasterCommunicationPatient)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $disasterCommunicationPatient->location_id, 'module_name' => 'disaster'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $disasterCommunicationPatient->location_id, 'module_name' => 'disaster'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $disasterCommunicationPatient->location_id, 'module_name' => 'disaster']);
            }
        } catch (\Exception $e) {
            Log::error('DisasterCommunicationPatientObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('DisasterCommunicationPatientObserver/updateLastModuleAccessDateTime() => ' . json_encode($disasterCommunicationPatient));
        }
    }
}
