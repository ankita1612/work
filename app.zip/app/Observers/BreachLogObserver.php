<?php

namespace App\Observers;

use App\Models\BreachLog;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class BreachLogObserver
{
    /**
     * Handle the BreachLog "created" event.
     */
    public function created(BreachLog $breachLog): void
    {
        $this->updateLastModuleAccessDateTime($breachLog);
    }

    /**
     * Handle the BreachLog "updated" event.
     */
    public function updated(BreachLog $breachLog): void
    {
        $this->updateLastModuleAccessDateTime($breachLog);
    }

    /**
     * Handle the BreachLog "deleted" event.
     */
    public function deleted(BreachLog $breachLog): void
    {
        $this->updateLastModuleAccessDateTime($breachLog);
    }

    /**
     * Handle the BreachLog "restored" event.
     */
    public function restored(BreachLog $breachLog): void
    {
        $this->updateLastModuleAccessDateTime($breachLog);
    }

    /**
     * Handle the BreachLog "force deleted" event.
     */
    public function forceDeleted(BreachLog $breachLog): void
    {
        //
    }

    public function updateLastModuleAccessDateTime($breachLog)
    {
        try{
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs']);
            }
        } catch (\Exception $e) {
            Log::error('BreachLogObserver/updateLastModuleAccessDateTime() => '.$e->getMessage());
            Log::error('BreachLogObserver/updateLastModuleAccessDateTime() => '.json_encode($breachLog));
        }
    }
}
