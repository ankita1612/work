<?php

namespace App\Observers;

use App\Models\BreachLog;
use App\Models\BreachLogPhi;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class BreachLogPhiObserver
{
    /**
     * Handle the BreachLogPhi "created" event.
     */
    public function created(BreachLogPhi $breachLogPhi): void
    {
        $this->updateLastModuleAccessDateTime($breachLogPhi);
    }

    /**
     * Handle the BreachLogPhi "updated" event.
     */
    public function updated(BreachLogPhi $breachLogPhi): void
    {
        $this->updateLastModuleAccessDateTime($breachLogPhi);
    }

    /**
     * Handle the BreachLogPhi "deleted" event.
     */
    public function deleted(BreachLogPhi $breachLogPhi): void
    {
        $this->updateLastModuleAccessDateTime($breachLogPhi);
    }

    /**
     * Handle the BreachLogPhi "restored" event.
     */
    public function restored(BreachLogPhi $breachLogPhi): void
    {
        $this->updateLastModuleAccessDateTime($breachLogPhi);
    }

    /**
     * Handle the BreachLogPhi "force deleted" event.
     */
    public function forceDeleted(BreachLogPhi $breachLogPhi): void
    {
        //
    }

    public function updateLastModuleAccessDateTime($breachLogPhi)
    {
        try{
            $breachLog = BreachLog::find($breachLogPhi->breach_log_id);
            if ($breachLog) {
                $is_avail = LocationModuleLastUpdate::where(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs'])->first();
                if ($is_avail) {
                    LocationModuleLastUpdate::where(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
                } else {
                    LocationModuleLastUpdate::create(['location_id' => $breachLog->location_id, 'module_name' => 'hipaa_logs']);
                }
            }
        } catch (\Exception $e) {
            Log::error('BreachLogPhiObserver/updateLastModuleAccessDateTime() => '.$e->getMessage());
            Log::error('BreachLogPhiObserver/updateLastModuleAccessDateTime() => '.json_encode($breachLogPhi));
        }
    }
}
