<?php

namespace App\Observers;

use App\Models\LocalFirstResponder;
use App\Models\LocationModuleLastUpdate;
use Illuminate\Support\Facades\Log;

class LocalFirstResponderObserver
{
    /**
     * Handle events after all transactions are committed.
     *
     * @var bool
     */
    public $afterCommit = true;

    /**
     * Handle the LocalFirstResponder "created" event.
     */
    public function created(LocalFirstResponder $localFirstResponder): void
    {
        $this->updateLastModuleAccessDateTime($localFirstResponder);
    }

    /**
     * Handle the LocalFirstResponder "updated" event.
     */
    public function updated(LocalFirstResponder $localFirstResponder): void
    {
        $this->updateLastModuleAccessDateTime($localFirstResponder);
    }

    /**
     * Handle the LocalFirstResponder "deleted" event.
     */
    public function deleted(LocalFirstResponder $localFirstResponder): void
    {
        $this->updateLastModuleAccessDateTime($localFirstResponder);
    }

    /**
     * Handle the LocalFirstResponder "restored" event.
     */
    public function restored(LocalFirstResponder $localFirstResponder): void
    {
        $this->updateLastModuleAccessDateTime($localFirstResponder);
    }

    /**
     * Handle the LocalFirstResponder "force deleted" event.
     */
    public function forceDeleted(LocalFirstResponder $localFirstResponder): void
    {
        // $this->updateLastModuleAccessDateTime($localFirstResponder);
    }

    public function updateLastModuleAccessDateTime($localFirstResponder)
    {
        try {
            $is_avail = LocationModuleLastUpdate::where(['location_id' => $localFirstResponder->location_id, 'module_name' => 'disaster'])->first();
            if ($is_avail) {
                LocationModuleLastUpdate::where(['location_id' => $localFirstResponder->location_id, 'module_name' => 'disaster'])->update(['updated_at' => gmdate('Y-m-d H:i:s')]);
            } else {
                LocationModuleLastUpdate::create(['location_id' => $localFirstResponder->location_id, 'module_name' => 'disaster']);
            }
        } catch (\Exception $e) {
            Log::error('LocalFirstResponderObserver/updateLastModuleAccessDateTime() => ' . $e->getMessage());
            Log::error('LocalFirstResponderObserver/updateLastModuleAccessDateTime() => ' . json_encode($localFirstResponder));
        }
    }
}
