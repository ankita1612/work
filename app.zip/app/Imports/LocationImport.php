<?php

namespace App\Imports;

use App\Models\Location;
use App\Traits\ChargebeePlan;
use App\Traits\GetMainUserData;
use App\Traits\Notification;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Carbon\Carbon;

class LocationImport implements SkipsEmptyRows, ToCollection, WithHeadingRow, WithMapping, WithStartRow, WithValidation
{
    use GetMainUserData, Importable, Notification,ChargebeePlan;

    public $row_count = 0;

    public $total_row_count = 0;

    public function collection(Collection $rows)
    {
        $user_data = $this->getMainAccountDetails();
        $total_location = Location::where('user_id', $user_data['id'])->count();
        $this->total_row_count = count($rows);
        $subscription = $this->getSubscriptionDetails($user_data['chargebee_subscription_id']);
        $location_limit = $subscription['location_limit'];
        if ($location_limit - $total_location == count($rows)) {
            foreach ($rows as $row) {
                try{
                    DB::beginTransaction();
                    $cleaned_location_name = preg_replace(Config::get('app.allowed_chars'), '', $row['location_nickname']);
                    if (trim($cleaned_location_name)) {
                        $location_created = Location::create([
                            'user_id' => $user_data['id'],
                            'company_name' => $user_data['company_name'],
                            'location_nickname' => trim($cleaned_location_name),
                            'salesforce_unique_id' => ($total_location == 0 && $this->row_count == 0) ? $user_data['primary_location_salesforce_unique_id'] : null,
                            'training_anchor_date' => Carbon::now(),
                        ]);
                        $notification_HCE_AN2 = $this->getNotificationByCode('HCE-AN2');
                        $notification_HCE_AN2_data = [
                            'location_id' => $location_created['id'],
                            'notification_id' => $notification_HCE_AN2['id'],
                        ];
                        $this->createNotification($notification_HCE_AN2_data);
                        $this->row_count++;
                    }
                    DB::commit();
                } catch (\Exception $e) {
                    DB::rollBack();
                    Log::error('LocationImport/collection()[rows_error] => '.$e->getMessage());
                    Log::error('LocationImport/collection()[rows_data] => '.json_encode($row));
                }
            }
        } else {
            throw new \Exception('location_limit_exceeded');
        }
    }

    public function startRow(): int
    {
        return 3;
    }

    /**
     * @param  mixed  $row
     */
    public function map($row): array
    {
        return array_map(function ($item) {
            return trim(preg_replace('/\s+/', ' ', (preg_replace(Config::get('app.allowed_chars'), '', $item))));
        }, $row);
    }

    public function rules(): array
    {
        $user_data = $this->getMainAccountDetails();

        return [
            Str::lower('*.location_nickname') => ['required', 'max:100', 'distinct:ignore_case', 'unique:locations,location_nickname,NULL,id,deleted_at,NULL,user_id,'.$user_data['id']],
        ];
    }
}
