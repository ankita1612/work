<?php

namespace App\Imports;

use App\Http\Controllers\App\GeneralController;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\BusinessAssociates;
use App\Models\Location;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Validators\Failure;

class BusinessAssociatesImport implements SkipsEmptyRows, SkipsOnError, SkipsOnFailure, ToCollection, WithChunkReading, WithHeadingRow, WithMapping, WithMultipleSheets, WithStartRow, WithValidation
{
    use GeneratePolicy, GetMainUserData, Importable, SkipsFailures;

    public $row_count = 0;

    public $total_row_count = 0;

    public $invalid_locations = [];

    public function collection(Collection $rows)
    {
        $user_data = $this->getMainAccountDetails();
        $this->total_row_count = count($rows);
        if ($this->total_row_count <= 50) {
            $generalController = new GeneralController;
            $location_access_list = $generalController->getAssingedLocationList();
            $locations = Location::whereHas('hipaaComplianceOfficer')
                ->whereHas('companyModuleCompleted')
                ->whereHas('sraModuleCompleted')
                ->whereHas('disasterRecoveryPlanModuleCompleted')
                ->where(function ($query) {
                    $query->whereHas('employeePrimaryWorkLocation')->orWhereHas('employeeSecondaryWorkLocation');
                })
                ->where('user_id', $user_data['id'])
                ->whereIn('id', $location_access_list)
                ->get();
            $locations_ba_unlocked = $locations->pluck('id');
            $allowed_location_count = count($locations);
            foreach ($rows as $row) {
                try{
                    DB::beginTransaction();
                    if ($allowed_location_count > 1) {
                        if ($row['assigned_locations']) {
                            $locations = array_unique(array_map('trim', explode('#', $row['assigned_locations'])));
                            $location_access = [];
                            foreach ($locations as $key => $value) {
                                $allowed_location = Location::where(['user_id' => $user_data['id'], 'location_nickname' => trim($value)])->whereIn('id', $locations_ba_unlocked)->first();
                                if ($allowed_location) {
                                    $location_access[$key] = [
                                        'location_id' => $allowed_location->id,
                                        'salesforce_unique_id' => $allowed_location->salesforce_unique_id,
                                    ];
                                } else {
                                    array_push($this->invalid_locations, 'Invalid Assigned location(s) name:'.' '.$value);
                                }
                            }
                        }
                        if (! empty($location_access)) {
                            foreach ($location_access as $ls) {
                                $this->addPolicyVersionData('BACP', $ls['location_id']);
                                if ($ls['salesforce_unique_id'] != null) {
                                    SendLocationDataToSalesForce::dispatch($ls['location_id']);
                                }
                            }

                            $businessAssociates = BusinessAssociates::create([
                                'user_id' => $user_data['id'],
                                'name' => trim(preg_replace(Config::get('app.allowed_chars'), '', $row['vendor_name'])),
                                'email' => trim($row['email']),
                                'expired_date' => $row['expiration_date'] == '' ? null : Carbon::parse($row['expiration_date'])->format('Y-m-d'),
                                'phone_number' => trim($row['phone_number']),
                            ]);
                            $businessAssociates->businessAssociatesLocation()->createMany($location_access);
                            $this->row_count++;
                        }
                    } else {

                        $this->addPolicyVersionData('BACP', $locations[0]->id);
                        if ($locations[0]->salesforce_unique_id != null) {
                            SendLocationDataToSalesForce::dispatch($locations[0]->id);
                        }

                        $businessAssociates = BusinessAssociates::create([
                            'user_id' => $user_data['id'],
                            'name' => trim(preg_replace(Config::get('app.allowed_chars'), '', $row['vendor_name'])),
                            'email' => trim($row['email']),
                            'expired_date' => $row['expiration_date'] == '' ? null : Carbon::parse($row['expiration_date'])->format('Y-m-d'),
                            'phone_number' => trim($row['phone_number']),
                        ]);
                        $this->row_count++;
                        $businessAssociates->businessAssociatesLocation()->create(['location_id' => $locations[0]->id]);
                    }
                    DB::commit();
                } catch (\Exception $e) {
                    DB::rollBack();
                    Log::error('BusinessAssociatesImport/collection()[rows_error] => '.$e->getMessage());
                    Log::error('BusinessAssociatesImport/collection()[rows_data] => '.json_encode($row));
                }
            }
        } else {
            throw new \Exception('more_than_limit_records');
        }
    }

    public function sheets(): array
    {
        return [
            0 => $this,
        ];
    }

    /**
     * @param  Failure[]  $failures
     */
    public function onFailure(Failure ...$failures)
    {
        $this->failures = array_merge($this->failures, $failures);
    }

    public function onError(\Throwable $e)
    {
        throw $e;
    }

    public function startRow(): int
    {
        return 3;
    }

    /**
     * @param  mixed  $row
     */
    public function map($row): array
    {
        return array_map('trim', $row);
    }

    public function rules(): array
    {
        $user_data = $this->getMainAccountDetails();

        return [
            '*.vendor_name' => ['required', 'string', "regex:/^[a-z\d\-'!_.,()&\s]+$/i", 'max:40'],
            '*.email' => ['required', 'email:rfc,dns', 'max:100', 'distinct:ignore_case', 'unique:App\Models\BusinessAssociates,email,NULL,id,deleted_at,NULL,user_id,'.$user_data['id']],
            '*.expiration_date' => ['nullable', 'date', 'date_format:m/d/Y', 'after:01/01/1970'],
            '*.phone_number' => ['nullable', 'string', 'regex:/^(\d{3})(\-)(\d{3})(\-)(\d{4})$/', 'max:12', 'min:12'],
            '*.assigned_locations' => ['sometimes', 'required'],
        ];
    }

    public function customValidationMessages()
    {
        return [
            'vendor_name.required' => 'Vendor Name field is required.',
            'vendor_name.string' => 'Vendor Name must be string.',
            'vendor_name.max' => 'Vendor Name must not be greater than 40 characters.',
            'vendor_name.regex' => "Vendor Name valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !. ",
            'email.required' => 'Email field is required.',
            'email.max' => 'Email must not be greater than 100 characters.',
            'email.unique' => 'Email has already been taken.',
            'email.email' => 'Email must be a valid email address.',
            'expiration_date.date' => 'Expiration Date is not a valid date.',
            'expiration_date.date_format' => 'Expiration Date does not match the format m/d/Y.',
            'expiration_date.after' => 'Expiration Date must be a date after 01/01/1970.',
            'phone_number.string' => 'Phone Number must be string.',
            'phone_number.regex' => 'Phone Number format is invalid.',
            'phone_number.max' => 'Phone Number must not be greater than 12 characters.',
            'phone_number.min' => 'Phone Number must be at least 12 characters.',
            'assigned_locations.required' => 'Assigned location(s) field is required. ',
        ];
    }

    public function chunkSize(): int
    {
        return 1000;
    }
}
