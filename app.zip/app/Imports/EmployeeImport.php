<?php

namespace App\Imports;

use App\Http\Controllers\App\TrainingController;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AccountUserLocationAccess;
use App\Models\EmailTemplate;
use App\Models\Employee;
use App\Models\EmployeeAccessRight;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\ModuleCompletedStatus;
use App\Traits\ChargebeePlan;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use App\Traits\Notification;
use App\Traits\SendMail;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Validators\Failure;

class EmployeeImport implements SkipsEmptyRows, SkipsOnError, SkipsOnFailure, ToCollection, WithChunkReading, WithHeadingRow, WithMapping, WithStartRow, WithValidation
{
    use GeneratePolicy, GetMainUserData, Importable, Notification, SendMail, SkipsFailures,ChargebeePlan;

    public $row_count = 0;

    public $total_row_count = 0;

    public $invalid_primary_location = [];

    public function collection(Collection $rows)
    {
        $user_data = $this->getMainAccountDetails();
        $generalController = new \App\Http\Controllers\App\GeneralController;
        $location_access_list = $generalController->getAssingedLocationList();
        $location_list = Location::where('user_id', $user_data['id'])
            ->select(['id', 'location_nickname'])
            ->whereHas('hipaaComplianceOfficer')
            ->whereIn('id', $location_access_list)
            ->get();
        $allowed_location_count = count($location_list);
        $total_employee = Employee::where('user_id', $user_data['id'])->count();
        $this->total_row_count = count($rows);
        $training_controller = new TrainingController;
        $logged_in_user_data = auth()->user();
        $account_user_location_ids = [];
        $check_current_login = auth()->getDefaultDriver();
        $has_secondary_location_access = true;
        $is_first_emp_data = [];
        if ($check_current_login == 'account_user') {
            $account_user_location_ids = AccountUserLocationAccess::select(['location_id'])
                ->where('account_user_id', $logged_in_user_data->id)
                ->get()->pluck('location_id')->toArray();
        }
        $subscription = $this->getSubscriptionDetails($user_data['chargebee_subscription_id']);
        $employee_limit = $subscription['employee_limit'];
        
        if ($this->total_row_count <= ($employee_limit - $total_employee)) {
            if ($this->total_row_count <= 50) {
                foreach ($rows as $row) {
                    try{
                        DB::beginTransaction();
                        $cleaned_first_name = preg_replace(Config::get('app.allowed_chars'), '', $row['first_name']);
                        $cleaned_last_name = preg_replace(Config::get('app.allowed_chars'), '', $row['last_name']);
                        if (trim($cleaned_first_name) && trim($cleaned_last_name)) {
                            if ($allowed_location_count > 1) {
                                if ($account_user_location_ids) {
                                    $valid_allowed_location_primary = Location::where(['user_id' => $user_data['id'], 'location_nickname' => trim($row['primary_work_location'])])->whereHas('hipaaComplianceOfficer')
                                        ->whereHas('accountLocationAccess', function ($query) use ($account_user_location_ids, $logged_in_user_data) {
                                            return $query->where('account_user_id', $logged_in_user_data->id)
                                                ->whereIn('location_id', $account_user_location_ids);
                                        })->first();
                                } else {
                                    $valid_allowed_location_primary = Location::where(['user_id' => $user_data['id'], 'location_nickname' => trim($row['primary_work_location'])])->whereHas('hipaaComplianceOfficer')->first();
                                }
                                if ($valid_allowed_location_primary) {
                                    $secondary_work_locations = array_unique(array_map('trim', explode('#', $row['secondary_work_locations'])));
                                    $secondary_work_locations_ins = [];
                                    foreach ($secondary_work_locations as $key => $loc) {
                                        if ($account_user_location_ids) {
                                            $valid_allowed_location_secondary = Location::where(['user_id' => $user_data['id'], 'location_nickname' => trim($loc)])->whereHas('hipaaComplianceOfficer')->whereHas('accountLocationAccess', function ($query) use ($account_user_location_ids, $logged_in_user_data) {
                                                return $query->where('account_user_id', $logged_in_user_data->id)
                                                    ->whereIn('location_id', $account_user_location_ids);
                                            })->first();
                                        } else {
                                            $valid_allowed_location_secondary = Location::where(['user_id' => $user_data['id'], 'location_nickname' => trim($loc)])->whereHas('hipaaComplianceOfficer')->first();
                                        }
                                        if ($valid_allowed_location_secondary && $valid_allowed_location_primary['id'] != $valid_allowed_location_secondary['id']) {
                                            $is_already_avail = array_search($valid_allowed_location_secondary['id'], array_column($secondary_work_locations_ins, 'location_id'));
                                            if ($is_already_avail === false) {
                                                $secondary_work_locations_ins[$key] = [
                                                    'location_id' => $valid_allowed_location_secondary['id'],
                                                ];
                                            }
                                        } else {
                                            if ($row['secondary_work_locations'] != null) {
                                                array_push($this->invalid_primary_location, 'Invalid Secondary Location name:'.' '.trim($loc));
                                                if (! $valid_allowed_location_secondary && $account_user_location_ids && trim($loc) != '') {
                                                    $has_secondary_location_access = false;
                                                }
                                            }
                                        }
                                    }
                                    if ($has_secondary_location_access) {
                                        $checkCount = Location::whereHas('sraModuleCompleted')->withCount('activeEmployeePrimaryWorkLocation')->where('id', $valid_allowed_location_primary['id'])->first();
                                        if ($checkCount && $checkCount->active_employee_primary_work_location_count == 0 && ! in_array($valid_allowed_location_primary['id'], $is_first_emp_data)) {
                                            $is_first_emp_data[] = $valid_allowed_location_primary['id'];
                                        }
                                        $check_atleast_one_emp[$valid_allowed_location_primary['id']] = Employee::where('primary_work_location_id', $valid_allowed_location_primary['id'])
                                            ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($valid_allowed_location_primary) {
                                                return $query->where('location_id', $valid_allowed_location_primary['id']);
                                            })->count();
                                        foreach ($secondary_work_locations_ins as $key => $value) {
                                            $check_atleast_one_emp[$value['location_id']] = Employee::where('primary_work_location_id', $value['location_id'])
                                                ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($value) {
                                                    return $query->where('location_id', $value['location_id']);
                                                })->count();
                                        }

                                        // policy versioning code
                                        $policy_array = ['AAP', 'DRP', 'SAP'];
                                        foreach ($policy_array as $policy_code) {
                                            $this->addPolicyVersionData($policy_code, $valid_allowed_location_primary['id']);
                                            foreach ($secondary_work_locations_ins as $secoundary_location) {
                                                $this->addPolicyVersionData($policy_code, $secoundary_location['location_id']);
                                            }
                                        }

                                        $employee_create = Employee::create([
                                            'user_id' => $user_data['id'],
                                            'first_name' => trim($cleaned_first_name),
                                            'last_name' => trim($cleaned_last_name),
                                            'email' => trim($row['email']),
                                            'phone_number' => trim($row['phone_number']),
                                            'primary_work_location_id' => $valid_allowed_location_primary['id'],
                                        ]);
                                        EmployeeAccessRight::create(
                                            [
                                                'location_id' => $valid_allowed_location_primary['id'],
                                                'employee_id' => $employee_create['id'],
                                                'facility_access_key' => ($row['facility_access_key'] == 'Yes') ? $row['facility_access_key'] : 'No',
                                                'full_facility_access' => ($row['full_facility_access'] == 'Yes') ? $row['full_facility_access'] : 'No',
                                                'full_software_access' => ($row['full_software_access'] == 'Yes') ? $row['full_software_access'] : 'No',
                                                'software_admin_privilages' => ($row['software_admin_privilages'] == 'Yes') ? $row['software_admin_privilages'] : 'No',
                                                'full_network_access' => ($row['full_network_access'] == 'Yes') ? $row['full_network_access'] : 'No',
                                                'network_admin_privilages' => ($row['network_admin_privilages'] == 'Yes') ? $row['network_admin_privilages'] : 'No',
                                                'security_code' => ($row['security_code'] != '') ? $row['security_code'] : null,
                                            ]
                                        );
                                        if (! empty($secondary_work_locations_ins)) {
                                            $employee_create->employeeSecondaryWorkLocation()->createMany($secondary_work_locations_ins);

                                            foreach ($secondary_work_locations_ins as $secoundary_location) {
                                                EmployeeAccessRight::create(
                                                    [
                                                        'location_id' => $secoundary_location['location_id'],
                                                        'employee_id' => $employee_create['id'],
                                                        'facility_access_key' => ($row['facility_access_key'] == 'Yes') ? $row['facility_access_key'] : 'No',
                                                        'full_facility_access' => ($row['full_facility_access'] == 'Yes') ? $row['full_facility_access'] : 'No',
                                                        'full_software_access' => ($row['full_software_access'] == 'Yes') ? $row['full_software_access'] : 'No',
                                                        'software_admin_privilages' => ($row['software_admin_privilages'] == 'Yes') ? $row['software_admin_privilages'] : 'No',
                                                        'full_network_access' => ($row['full_network_access'] == 'Yes') ? $row['full_network_access'] : 'No',
                                                        'network_admin_privilages' => ($row['network_admin_privilages'] == 'Yes') ? $row['network_admin_privilages'] : 'No',
                                                        'security_code' => ($row['security_code'] != '') ? $row['security_code'] : null,
                                                    ]
                                                );
                                            }
                                        }
                                        $SF_location = Location::where('id', $valid_allowed_location_primary['id'])->whereNotNull('salesforce_unique_id')->first();
                                        if ($SF_location) {
                                            SendLocationDataToSalesForce::dispatch($SF_location->id);
                                        }
                                        if (! empty($secondary_work_locations_ins)) {
                                            foreach ($secondary_work_locations_ins as $secoundary_location) {
                                                $SF_location = Location::where('id', $secoundary_location['location_id'])->whereNotNull('salesforce_unique_id')->first();
                                                if ($SF_location) {
                                                    SendLocationDataToSalesForce::dispatch($SF_location->id);
                                                }
                                            }
                                        }
                                        //Add in unassigned Training
                                        $training_controller->addToUnassignedTraining($valid_allowed_location_primary['id'], $employee_create['id'], \App\Models\Employee::class);
                                        $hco = HipaaComplianceOfficer::where('location_id', $valid_allowed_location_primary['id'])->first();
                                        //Add in unassigned Training
                                        $training_controller->addToUnassignedTraining($valid_allowed_location_primary['id'], $hco->hco_id, $hco->hco_type);
                                        foreach ($check_atleast_one_emp as $loc_id => $emp_count) {
                                            if ($emp_count == 0) {
                                                $check_is_ra_completed = ModuleCompletedStatus::where(
                                                    [
                                                        'location_id' => $loc_id,
                                                        'module' => 'risk_analysis',
                                                        'is_completed' => 1,
                                                    ]
                                                )->first();
                                                $check_is_DRA_completed = ModuleCompletedStatus::where(
                                                    [
                                                        'location_id' => $loc_id,
                                                        'module' => 'disaster_recovery_plan',
                                                        'is_completed' => 1,
                                                    ]
                                                )->first();
                                                if ($check_is_ra_completed) {
                                                    $notification_HCE_AN12 = $this->getNotificationByCode('HCE-AN12');
                                                    if ($this->checkNotificationAlreadyAdded($notification_HCE_AN12->code, $loc_id) == 0) {
                                                        $notification_HCE_AN12_data = [
                                                            'location_id' => $loc_id,
                                                            'notification_id' => $notification_HCE_AN12['id'],
                                                        ];
                                                        $this->createNotification($notification_HCE_AN12_data);
                                                    }
                                                }
                                                if ($check_is_ra_completed && ! $check_is_DRA_completed) {
                                                    $notification_HCE_AN6 = $this->getNotificationByCode('HCE-AN6');
                                                    if ($this->checkNotificationAlreadyAdded($notification_HCE_AN6->code, $loc_id) == 0) {
                                                        $notification_HCE_AN6_data = [
                                                            'location_id' => $loc_id,
                                                            'notification_id' => $notification_HCE_AN6['id'],
                                                        ];
                                                        $this->createNotification($notification_HCE_AN6_data);
                                                        $loc_data = Location::findOrFail($loc_id);
                                                        $hco = HipaaComplianceOfficer::where('location_id', $loc_id)->with('hco')->first();
                                                    }
                                                }
                                            }
                                        }
                                        $this->row_count++;
                                    }
                                } else {
                                    array_push($this->invalid_primary_location, 'Invalid Primary Location name:'.' '.$row['primary_work_location']);
                                }
                            } else {
                                $check_atleast_one_emp[$location_list[0]['id']] = Employee::where('primary_work_location_id', $location_list[0]['id'])
                                    ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($location_list) {
                                        return $query->where('location_id', $location_list[0]['id']);
                                    })->count();
                                $checkCount = Location::whereHas('sraModuleCompleted')->withCount('activeEmployeePrimaryWorkLocation')->where('id', $location_list[0]['id'])->first();
                                if ($checkCount && $checkCount->active_employee_primary_work_location_count == 0 && ! in_array($location_list[0]['id'], $is_first_emp_data)) {
                                    $is_first_emp_data[] = $location_list[0]['id'];
                                }

                                $policy_array = ['AAP', 'DRP', 'SAP'];
                                foreach ($policy_array as $policy_code) {
                                    $this->addPolicyVersionData($policy_code, $location_list[0]['id']);
                                }

                                $employee_create = Employee::create([
                                    'user_id' => $user_data['id'],
                                    'first_name' => trim($cleaned_first_name),
                                    'last_name' => trim($cleaned_last_name),
                                    'email' => trim($row['email']),
                                    'phone_number' => trim($row['phone_number']),
                                    'primary_work_location_id' => $location_list[0]['id'],
                                ]);
                                EmployeeAccessRight::create(
                                    [
                                        'location_id' => $location_list[0]['id'],
                                        'employee_id' => $employee_create['id'],
                                        'facility_access_key' => ($row['facility_access_key'] == 'Yes') ? $row['facility_access_key'] : 'No',
                                        'full_facility_access' => ($row['full_facility_access'] == 'Yes') ? $row['full_facility_access'] : 'No',
                                        'full_software_access' => ($row['full_software_access'] == 'Yes') ? $row['full_software_access'] : 'No',
                                        'software_admin_privilages' => ($row['software_admin_privilages'] == 'Yes') ? $row['software_admin_privilages'] : 'No',
                                        'full_network_access' => ($row['full_network_access'] == 'Yes') ? $row['full_network_access'] : 'No',
                                        'network_admin_privilages' => ($row['network_admin_privilages'] == 'Yes') ? $row['network_admin_privilages'] : 'No',
                                        'security_code' => ($row['security_code'] != '') ? $row['security_code'] : null,
                                    ]
                                );
                                $SF_location = Location::where('id', $location_list[0]['id'])->whereNotNull('salesforce_unique_id')->first();
                                if ($SF_location) {
                                    SendLocationDataToSalesForce::dispatch($SF_location->id);
                                }
                                //Add in unassigned Training
                                $training_controller->addToUnassignedTraining($location_list[0]['id'], $employee_create['id'], \App\Models\Employee::class);
                                $hco = HipaaComplianceOfficer::where('location_id', $location_list[0]['id'])->first();
                                //Add in unassigned Training
                                $training_controller->addToUnassignedTraining($location_list[0]['id'], $hco->hco_id, $hco->hco_type);
                                foreach ($check_atleast_one_emp as $loc_id => $emp_count) {
                                    if ($emp_count == 0) {
                                        $check_is_ra_completed = ModuleCompletedStatus::where(
                                            [
                                                'location_id' => $loc_id,
                                                'module' => 'risk_analysis',
                                                'is_completed' => 1,
                                            ]
                                        )->first();
                                        $check_is_DRA_completed = ModuleCompletedStatus::where(
                                            [
                                                'location_id' => $loc_id,
                                                'module' => 'disaster_recovery_plan',
                                                'is_completed' => 1,
                                            ]
                                        )->first();
                                        if ($check_is_ra_completed) {
                                            $notification_HCE_AN12 = $this->getNotificationByCode('HCE-AN12');
                                            if ($this->checkNotificationAlreadyAdded($notification_HCE_AN12->code, $loc_id) == 0) {
                                                $notification_HCE_AN12_data = [
                                                    'location_id' => $loc_id,
                                                    'notification_id' => $notification_HCE_AN12['id'],
                                                ];
                                                $this->createNotification($notification_HCE_AN12_data);
                                            }
                                        }

                                        if ($check_is_ra_completed && ! $check_is_DRA_completed) {
                                            $notification_HCE_AN6 = $this->getNotificationByCode('HCE-AN6');
                                            if ($this->checkNotificationAlreadyAdded($notification_HCE_AN6->code, $loc_id) == 0) {
                                                $notification_HCE_AN6_data = [
                                                    'location_id' => $loc_id,
                                                    'notification_id' => $notification_HCE_AN6['id'],
                                                ];
                                                $this->createNotification($notification_HCE_AN6_data);
                                                $loc_data = Location::findOrFail($loc_id);
                                                $hco = HipaaComplianceOfficer::where('location_id', $loc_id)->with('hco')->first();
                                            }
                                        }
                                    }
                                }
                                $this->row_count++;
                            }

                        }
                        DB::commit();
                    } catch (\Exception $e) {
                        DB::rollBack();
                        Log::error('EmployeeImport/collection()[rows_error] => '.$e->getMessage());
                        Log::error('EmployeeImport/collection()[rows_data] => '.json_encode($row));
                    }
                }
            } else {
                throw new \Exception('more_than_limit_records');
            }
        } else {
            throw new \Exception('employee_limit_exceeded');
        }
        if ($is_first_emp_data != []) {
            foreach ($is_first_emp_data as $loc_id) {
                $training_controller->addTrainingLocations($loc_id);
            }
        }

    }

    /**
     * @param  Failure[]  $failures
     */
    public function onFailure(Failure ...$failures)
    {
        $this->failures = array_merge($this->failures, $failures);
    }

    public function startRow(): int
    {
        return 3;
    }

    public function onError(\Throwable $e)
    {
        throw $e;
    }

    /**
     * @param  mixed  $row
     */
    public function map($row): array
    {
        return array_map('trim', $row);
    }

    public function rules(): array
    {
        $user_data = $this->getMainAccountDetails();

        return [
            '*.first_name' => ['required', 'string', 'max:40', "regex:/^[a-z\d\-'!_.,()&\s]+$/i"],
            '*.last_name' => ['required', 'string', 'max:40', "regex:/^[a-z\d\-'!_.,()&\s]+$/i"],
            '*.email' => ['required', 'email:rfc,dns', 'max:100', 'distinct:ignore_case', 'unique:App\Models\Employee,email,NULL,id,deleted_at,NULL'],
            '*.phone_number' => ['required', 'string', 'regex:/^(\d{3})(\-)(\d{3})(\-)(\d{4})$/', 'max:12', 'min:12'],
            '*.primary_work_location' => ['sometimes', 'required'],
            '*.facility_access_key' => ['required', 'in:yes,no,Yes,No,YES,NO'],
            '*.full_facility_access' => ['required', 'in:yes,no,Yes,No,YES,NO'],
            '*.full_software_access' => ['required', 'in:yes,no,Yes,No,YES,NO'],
            '*.software_admin_privilages' => ['required', 'in:yes,no,Yes,No,YES,NO'],
            '*.full_network_access' => ['required', 'in:yes,no,Yes,No,YES,NO'],
            '*.network_admin_privilages' => ['required', 'in:yes,no,Yes,No,YES,NO'],
            '*.security_code' => ['max:30'],
        ];
    }

    public function customValidationMessages()
    {
        return [
            'first_name.required' => 'First Name field is required.',
            'first_name.max' => 'First Name must not be greater than 40 characters.',
            'first_name.regex' => "First Name valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !. ",
            'last_name.required' => 'Last Name field is required.',
            'last_name.max' => 'Last Name must not be greater than 40 characters.',
            'last_name.regex' => "Last Name valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !. ",
            'email.required' => 'Email field is required.',
            'email.max' => 'Email must not be greater than 100 characters.',
            'email.unique' => 'Email has already been taken.',
            'email.email' => 'Email must be a valid email address.',
            'phone_number.required' => 'Phone Number field is required.',
            'phone_number.regex' => 'Phone Number format is invalid.',
            'phone_number.min' => 'Phone Number must be at least 12 characters.',
            'phone_number.max' => 'Phone Number must not be greater than 12 characters.',
            'phone_number.required' => 'Phone Number field is required.',
            'primary_work_location.required' => 'Primary Work Location field is required.',
            'facility_access_key.required' => 'Facility Access Key field is required.',
            'facility_access_key.in' => 'Entered Facility Access Key is invalid.',
            'full_facility_access.required' => 'Full Facility Access field is required.',
            'full_facility_access.in' => 'Entered Full Facility Access is invalid.',
            'full_software_access.required' => 'Full Software Access field is required.',
            'full_software_access.in' => 'Entered Full Software Access is invalid.',
            'software_admin_privilages.required' => 'Software Admin Privilages field is required.',
            'software_admin_privilages.in' => 'Entered Software Admin Privilages is invalid.',
            'full_network_access.required' => 'Full Network Access field is required.',
            'full_network_access.in' => 'Entered Full Network Access is invalid.',
            'network_admin_privilages.required' => 'Network Admin Privilages field is required.',
            'network_admin_privilages.in' => 'Entered Full Network Access is invalid.',
            'security_code.max' => 'Security Code must not be greater than 30 characters.',
        ];
    }

    public function chunkSize(): int
    {
        return 1000;
    }
}
