<?php

namespace App\Imports;

use App\Http\Controllers\App\TrainingController;
use App\Models\Location;
use App\Models\Student;
use App\Models\StudentClass;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Validators\Failure;

class StudentImport implements SkipsEmptyRows, SkipsOnError, SkipsOnFailure, ToCollection, WithChunkReading, WithHeadingRow, WithMapping, WithMultipleSheets, WithStartRow, WithValidation
{
    use GeneratePolicy, GetMainUserData, Importable, SkipsFailures;

    public $row_count = 0;

    public $total_row_count = 0;

    public function collection(Collection $rows)
    {
        $user_data = $this->getMainAccountDetails();
        $location_list = Location::where('user_id', $user_data['id'])
            ->select(['id', 'location_nickname'])
            ->whereHas('hipaaComplianceOfficer')
            ->get();
        $allowed_location_count = count($location_list);
        $training_controller = new TrainingController;
        $this->total_row_count = count($rows);
        if ($this->total_row_count <= 50) {
            $invalid_primary_education_location = [];
            foreach ($rows as $row) {
                try{
                    DB::beginTransaction();
                    $cleaned_first_name = preg_replace(Config::get('app.allowed_chars'), '', $row['first_name']);
                    $cleaned_last_name = preg_replace(Config::get('app.allowed_chars'), '', $row['last_name']);
                    if (trim($cleaned_first_name) && trim($cleaned_last_name)) {
                        if ($allowed_location_count > 1) {
                            $valid_allowed_location_primary = Location::where(['user_id' => $user_data['id'], 'location_nickname' => trim($row['primary_education_location'])])->whereHas('hipaaComplianceOfficer')->first();
                            $valid_allowed_class = StudentClass::where(['class_name' => trim($row['class_name'])])->first();
                            if ($valid_allowed_location_primary) {
                                $this->addPolicyVersionData('AAP', $valid_allowed_location_primary['id']);
                                $student_create = Student::create([
                                    'user_id' => $user_data['id'],
                                    'first_name' => trim($cleaned_first_name),
                                    'last_name' => trim($cleaned_last_name),
                                    'email' => trim($row['email']),
                                    'phone_number' => trim($row['phone_number']),
                                    'class_id' => $valid_allowed_class['id'],
                                    'imaging_device_access' => trim($row['imaging_device_access']),
                                    'full_network_access' => trim($row['full_network_access']),
                                    'full_software_access' => trim($row['full_software_access']),
                                    'primary_work_location_id' => $valid_allowed_location_primary['id'],
                                ]);
                                $training_controller->addToUnassignedTraining($valid_allowed_location_primary['id'], $student_create['id'], \App\Models\Student::class);
                                $this->row_count++;
                            } else {
                                array_push($invalid_primary_education_location, 'Invalid Primary Education Location Name:'.' '.trim($row['primary_education_location']));
                            }
                        } else {
                            $valid_allowed_class = StudentClass::where(['class_name' => trim($row['class_name'])])->first();
                            $this->addPolicyVersionData('AAP', $location_list[0]['id']);
                            $student_create = Student::create([
                                'user_id' => $user_data['id'],
                                'first_name' => trim($cleaned_first_name),
                                'last_name' => trim($cleaned_last_name),
                                'email' => trim($row['email']),
                                'phone_number' => trim($row['phone_number']),
                                'class_id' => $valid_allowed_class['id'],
                                'imaging_device_access' => trim($row['imaging_device_access']),
                                'full_network_access' => trim($row['full_network_access']),
                                'full_software_access' => trim($row['full_software_access']),
                                'primary_work_location_id' => $location_list[0]['id'],
                            ]);
                            $training_controller->addToUnassignedTraining($location_list[0]['id'], $student_create['id'], \App\Models\Student::class);
                            $this->row_count++;
                        }
                    }
                    DB::commit();
                } catch (\Exception $e) {
                    DB::rollBack();
                    Log::error('StudentImport/collection()[rows_error] => '.$e->getMessage());
                    Log::error('StudentImport/collection()[rows_data] => '.json_encode($row));
                }
            }
            if (! empty($invalid_primary_education_location)) {
                $data = implode(',', $invalid_primary_education_location);
                throw new \Exception($data, 100);
            }
        } else {
            throw new \Exception('more_than_limit_records');
        }
    }

    public function sheets(): array
    {
        return [
            0 => $this,
        ];
    }

    /**
     * @param  Failure[]  $failures
     */
    public function onFailure(Failure ...$failures)
    {
        $this->failures = array_merge($this->failures, $failures);
    }

    public function startRow(): int
    {
        return 3;
    }

    public function onError(\Throwable $e)
    {
        throw $e;
    }

    /**
     * @param  mixed  $row
     */
    public function map($row): array
    {
        return array_map('trim', $row);
    }

    public function rules(): array
    {
        $user_data = $this->getMainAccountDetails();

        return [
            '*.first_name' => ['required', 'string', 'max:40', "regex:/^[a-z\d\-'!_.,()&\s]+$/i"],
            '*.last_name' => ['required', 'string', 'max:40', "regex:/^[a-z\d\-'!_.,()&\s]+$/i"],
            '*.email' => ['required', 'email:rfc,dns', 'max:100', 'distinct:ignore_case', 'unique:App\Models\Student,email,NULL,id,deleted_at,NULL'],
            '*.phone_number' => ['required', 'string', 'regex:/^(\d{3})(\-)(\d{3})(\-)(\d{4})$/', 'max:12', 'min:12'],
            '*.primary_education_location' => ['sometimes', 'required'],
            '*.class_name' => ['required', 'string', 'max:40'],
            '*.imaging_device_access' => ['required', 'in:yes,no,Yes,No,YES,NO'],
            '*.full_network_access' => ['required', 'in:yes,no,Yes,No,YES,NO'],
            '*.full_software_access' => ['required', 'in:yes,no,Yes,No,YES,NO'],
        ];
    }

    public function customValidationMessages()
    {
        return [
            'first_name.required' => 'First Name field is required.',
            'first_name.max' => 'First Name must not be greater than 40 characters.',
            'first_name.regex' => "First Name valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !. ",
            'last_name.required' => 'Last Name field is required.',
            'last_name.max' => 'Last Name must not be greater than 40 characters.',
            'last_name.regex' => "Last Name valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !. ",
            'email.required' => 'Email field is required.',
            'email.max' => 'Email must not be greater than 100 characters.',
            'email.unique' => 'Email has already been taken.',
            'email.email' => 'Email must be a valid email address.',
            'phone_number.required' => 'Phone Number field is required.',
            'phone_number.regex' => 'Phone Number format is invalid.',
            'phone_number.min' => 'Phone Number must be at least 12 characters.',
            'phone_number.max' => 'Phone Number must not be greater than 12 characters',
            'phone_number.required' => 'Phone Number field is required.',
            'primary_education_location.required' => 'Primary Education Location field is required.',
            'class_name.required' => 'Class Name field is required.',
            'class_name.max' => 'Class Name must not be greater than 40 characters.',
            'imaging_device_access.required' => 'Imaging Device Access field is required.',
            'imaging_device_access.in' => 'Entered Imaging Device Access is invalid.',
            'full_software_access.required' => 'Full Software Access field is required.',
            'full_software_access.in' => 'Entered Full Software Access is invalid.',
            'full_network_access.required' => 'Full Network Access field is required.',
            'full_network_access.in' => 'Entered Full Network Access is invalid.',
        ];
    }

    public function chunkSize(): int
    {
        return 1000;
    }
}
