<?php

namespace App\Imports;

use App\Jobs\SendLocationDataToSalesForce;
use App\Models\AccountUserLocationAccess;
use App\Models\BusinessAssociates;
use App\Models\BusinessAssociatesLocation;
use App\Models\DisasterVendor;
use App\Models\DisasterVulnerability;
use App\Models\EmailTemplate;
use App\Models\HipaaComplianceOfficer;
use App\Models\LocalFirstResponder;
use App\Models\Location;
use App\Models\ModuleCompletedStatus;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use App\Traits\Notification;
use App\Traits\SendMail;
use DateTime;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithColumnLimit;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Validators\Failure;

class DisasterRespondersImport implements SkipsEmptyRows, SkipsOnError, SkipsOnFailure, ToCollection, WithColumnLimit, WithHeadingRow, WithMapping, WithMultipleSheets, WithStartRow, WithValidation
{
    use GeneratePolicy, GetMainUserData, Importable, Notification, SendMail, SkipsFailures;

    public $location_id;

    public $row_count = 0;

    /**
     * @param  Collection  $collection
     */
    public function collection(Collection $rows)
    {
        try {
            foreach ($rows as $row) {
                try{
                    DB::beginTransaction();
                    $user_data = $this->getMainAccountDetails();
                    $drp_versioning = false;
                    $local_police_department_name = preg_replace(Config::get('app.allowed_chars'), '', $row['local_police_department_name']);
                    $local_fire_department_name = preg_replace(Config::get('app.allowed_chars'), '', $row['local_fire_department_name']);

                    $alarm_system_company = preg_replace(Config::get('app.allowed_chars'), '', $row['alarm_system_company']);
                    $alarm_system_company_phone = preg_replace(Config::get('app.allowed_chars'), '', $row['alarm_system_company_phone']);
                    $data_backup_vendor = preg_replace(Config::get('app.allowed_chars'), '', $row['data_backup_vendor']);
                    $data_backup_vendor_phone = preg_replace(Config::get('app.allowed_chars'), '', $row['data_backup_vendor_phone']);
                    $data_backup_vendor_location = preg_replace(Config::get('app.allowed_chars'), '', $row['data_backup_vendor_location']);
                    $landlord_property_manager = preg_replace(Config::get('app.allowed_chars'), '', $row['landlord_property_manager']);
                    $landlord_property_manager_phone = preg_replace(Config::get('app.allowed_chars'), '', $row['landlord_property_manager_phone']);
                    $practice_management_software = preg_replace(Config::get('app.allowed_chars'), '', $row['practice_management_software']);
                    $practice_management_software_phone = preg_replace(Config::get('app.allowed_chars'), '', $row['practice_management_software_phone']);
                    $ehr_software = preg_replace(Config::get('app.allowed_chars'), '', $row['ehr_software']);
                    $ehr_software_phone = preg_replace(Config::get('app.allowed_chars'), '', $row['ehr_software_phone']);
                    $it_vendor = preg_replace(Config::get('app.allowed_chars'), '', $row['it_vendor']);
                    $it_vendor_phone = preg_replace(Config::get('app.allowed_chars'), '', $row['it_vendor_phone']);

                    $hurricane = preg_replace(Config::get('app.allowed_chars'), '', $row['hurricane']);
                    $flood = preg_replace(Config::get('app.allowed_chars'), '', $row['flood']);
                    $tornado = preg_replace(Config::get('app.allowed_chars'), '', $row['tornado']);
                    $earthquake = preg_replace(Config::get('app.allowed_chars'), '', $row['earthquake']);
                    $fire = preg_replace(Config::get('app.allowed_chars'), '', $row['fire']);
                    $rogue_staff_vendor = preg_replace(Config::get('app.allowed_chars'), '', $row['rogue_staff_vendor']);
                    $theft = preg_replace(Config::get('app.allowed_chars'), '', $row['theft']);
                    $malicious_software_virus = preg_replace(Config::get('app.allowed_chars'), '', $row['malicious_software_virus']);
                    $utility_interruption_failure = preg_replace(Config::get('app.allowed_chars'), '', $row['utility_interruption_failure']);
                    $public_health_emergency = preg_replace(Config::get('app.allowed_chars'), '', $row['public_health_emergency']);
                    $have_lab = preg_replace(Config::get('app.allowed_chars'), '', $row['have_lab']);

                    $local_first_responders = LocalFirstResponder::where('location_id', $this->location_id)->first();
                    $disaster_vendors = DisasterVendor::where('location_id', $this->location_id)->first();
                    $disaster_vulnerability = DisasterVulnerability::where('location_id', $this->location_id)->first();

                    // local first responders
                    $local_first_responders_data = [
                        'local_police_department_name' => trim($local_police_department_name),
                        'local_police_department_phone' => trim($row['local_police_department_phone']),
                        'local_fire_department_name' => trim($local_fire_department_name),
                        'local_fire_department_phone' => trim($row['local_fire_department_phone']),
                    ];
                    if ($local_first_responders) {
                        $local_first_responders_arr = [
                            'local_police_department_name' => $local_first_responders['local_police_department_name'],
                            'local_police_department_phone' => $local_first_responders['local_police_department_phone'],
                            'local_fire_department_name' => $local_first_responders['local_fire_department_name'],
                            'local_fire_department_phone' => $local_first_responders['local_fire_department_phone'],
                        ];
                    } else {
                        $local_first_responders_arr = [];
                    }
                    if ($local_first_responders_arr != $local_first_responders_data) {
                        $this->addPolicyVersionData('DRP', $this->location_id);
                        $drp_versioning = true;
                    }
                    if ($local_first_responders) {
                        $local_first_responders->update($local_first_responders_data);
                        $this->row_count++;
                    } else {
                        $local_first_responders_data['location_id'] = $this->location_id;
                        $local_first_responders = LocalFirstResponder::create($local_first_responders_data);
                        $this->row_count++;
                    }
                    // vendors
                    $disaster_vendors_data = [
                        'alarm_system_company' => (trim($alarm_system_company) && trim($alarm_system_company_phone)) ? trim($alarm_system_company) : null,
                        'alarm_system_company_phone' => (trim($alarm_system_company) && trim($alarm_system_company_phone)) ? trim($alarm_system_company_phone) : null,
                        'data_backup_vendor' => (trim($data_backup_vendor) && trim($data_backup_vendor_phone) && trim($data_backup_vendor_location)) ? trim($data_backup_vendor) : null,
                        'data_backup_vendor_phone' => (trim($data_backup_vendor) && trim($data_backup_vendor_phone) && trim($data_backup_vendor_location)) ? trim($data_backup_vendor_phone) : null,
                        'data_backup_vendor_location' => (trim($data_backup_vendor) && trim($data_backup_vendor_phone) && trim($data_backup_vendor_location)) ? ((trim($data_backup_vendor_location) == 'Cloud_OR_Hosted') ? 'Cloud/Hosted' : trim($data_backup_vendor_location)) : null,
                        'landlord_property_manager' => (trim($landlord_property_manager) && trim($landlord_property_manager_phone)) ? trim($landlord_property_manager) : null,
                        'landlord_property_manager_phone' => (trim($landlord_property_manager) && trim($landlord_property_manager_phone)) ? trim($landlord_property_manager_phone) : null,
                        'practice_management_software' => (trim($practice_management_software) && trim($practice_management_software_phone)) ? trim($practice_management_software) : null,
                        'practice_management_software_phone' => (trim($practice_management_software) && trim($practice_management_software_phone)) ? trim($practice_management_software_phone) : null,
                        'ehr_software' => (trim($ehr_software) && trim($ehr_software_phone)) ? trim($ehr_software) : null,
                        'ehr_software_phone' => (trim($ehr_software) && trim($ehr_software_phone)) ? trim($ehr_software_phone) : null,
                        'it_vendor' => (trim($it_vendor) && trim($it_vendor_phone)) ? trim($it_vendor) : null,
                        'it_vendor_phone' => (trim($it_vendor) && trim($it_vendor_phone)) ? trim($it_vendor_phone) : null,
                    ];
                    if ($disaster_vendors) {
                        $disaster_vendors_arr = [
                            'alarm_system_company' => $disaster_vendors['alarm_system_company'],
                            'alarm_system_company_phone' => $disaster_vendors['alarm_system_company_phone'],
                            'data_backup_vendor' => $disaster_vendors['data_backup_vendor'],
                            'data_backup_vendor_phone' => $disaster_vendors['data_backup_vendor_phone'],
                            'data_backup_vendor_location' => $disaster_vendors['data_backup_vendor_location'],
                            'landlord_property_manager' => $disaster_vendors['landlord_property_manager'],
                            'landlord_property_manager_phone' => $disaster_vendors['landlord_property_manager_phone'],
                            'practice_management_software' => $disaster_vendors['practice_management_software'],
                            'practice_management_software_phone' => $disaster_vendors['practice_management_software_phone'],
                            'ehr_software' => $disaster_vendors['ehr_software'],
                            'ehr_software_phone' => $disaster_vendors['ehr_software_phone'],
                            'it_vendor' => $disaster_vendors['it_vendor'],
                            'it_vendor_phone' => $disaster_vendors['it_vendor_phone'],
                        ];
                    } else {
                        $disaster_vendors_arr = [];
                    }
                    if ($disaster_vendors_arr != $disaster_vendors_data && ! $drp_versioning) {
                        $this->addPolicyVersionData('DRP', $this->location_id);
                    }
                    if (! empty($disaster_vendors_arr) && $disaster_vendors_arr['alarm_system_company'] != $disaster_vendors_data['alarm_system_company']) {
                        $this->addPolicyVersionData('SAP', $this->location_id);
                    }
                    if ($disaster_vendors) {
                        $disaster_vendors->update($disaster_vendors_data);
                        $this->row_count++;
                    } else {
                        $disaster_vendors_data['location_id'] = $this->location_id;
                        $disaster_vendors = DisasterVendor::create($disaster_vendors_data);
                        $this->row_count++;
                    }
                    // vulnerability
                    $disaster_vulnerability_data = [
                        'hurricane' => trim($hurricane),
                        'flood' => trim($flood),
                        'tornado' => trim($tornado),
                        'earthquake' => trim($earthquake),
                        'fire' => trim($fire),
                        'rogue_staff_vendor' => trim($rogue_staff_vendor),
                        'theft' => trim($theft),
                        'malicious_software_virus' => trim($malicious_software_virus),
                        'utility_interruption_failure' => trim($utility_interruption_failure),
                        'public_health_emergency' => trim($public_health_emergency),
                        'have_lab' => trim(strtolower($have_lab)),
                    ];
                    if ($disaster_vulnerability) {
                        $disaster_vulnerability_arr = [
                            'hurricane' => $disaster_vulnerability['hurricane'],
                            'flood' => $disaster_vulnerability['flood'],
                            'tornado' => $disaster_vulnerability['tornado'],
                            'earthquake' => $disaster_vulnerability['earthquake'],
                            'fire' => $disaster_vulnerability['fire'],
                            'rogue_staff_vendor' => $disaster_vulnerability['rogue_staff_vendor'],
                            'theft' => $disaster_vulnerability['theft'],
                            'malicious_software_virus' => $disaster_vulnerability['malicious_software_virus'],
                            'utility_interruption_failure' => $disaster_vulnerability['utility_interruption_failure'],
                            'public_health_emergency' => $disaster_vulnerability['public_health_emergency'],
                            'have_lab' => $disaster_vulnerability['have_lab'],
                        ];
                    } else {
                        $disaster_vulnerability_arr = [];
                    }
                    if ($disaster_vulnerability_arr != $disaster_vulnerability_data && ! $drp_versioning) {
                        $this->addPolicyVersionData('DRP', $this->location_id);
                    }
                    if ($disaster_vulnerability) {
                        $disaster_vulnerability->update($disaster_vulnerability_data);
                        $this->row_count++;
                    } else {
                        $disaster_vulnerability_data['location_id'] = $this->location_id;
                        $disaster_vulnerability = DisasterVulnerability::create($disaster_vulnerability_data);
                        $this->row_count++;
                    }
                    $disaster_recovery_plan_module_status = ModuleCompletedStatus::where([['location_id', $this->location_id], ['module', 'disaster_recovery_plan']])->first();
                    if ($disaster_recovery_plan_module_status) {
                        $disaster_recovery_plan_module_status->is_completed = 1;
                        $disaster_recovery_plan_module_status->save();
                    } else {
                        ModuleCompletedStatus::create([
                            'location_id' => $this->location_id,
                            'module' => 'disaster_recovery_plan',
                            'is_completed' => 1,
                        ]);

                        SendLocationDataToSalesForce::dispatch($this->location_id);
                        $notification_HCE_AN10 = $this->getNotificationByCode('HCE-AN10');
                        if ($this->checkNotificationAlreadyAdded($notification_HCE_AN10->code, $this->location_id) == 0) {
                            $notification_HCE_AN10_data = [
                                'location_id' => $this->location_id,
                                'notification_id' => $notification_HCE_AN10['id'],
                            ];
                            $this->createNotification($notification_HCE_AN10_data);
                        }

                        $notification_HCE_AN11 = $this->getNotificationByCode('HCE-AN11');
                        if ($this->checkNotificationAlreadyAdded($notification_HCE_AN11->code, $this->location_id) == 0) {
                            $notification_HCE_AN11_data = [
                                'location_id' => $this->location_id,
                                'notification_id' => $notification_HCE_AN11['id'],
                            ];
                            $this->createNotification($notification_HCE_AN11_data);
                        }

                        $location = Location::find($this->location_id);
                        // if($location->created_at < new DateTime('2024-12-20')){
                        $business_associates_list = BusinessAssociates::where('user_id', $user_data->id)->get();
                        foreach ($business_associates_list as $key => $ba_data) {
                            $check = BusinessAssociatesLocation::where('location_id', $this->location_id)
                                ->where('business_associate_id', $ba_data->id)
                                ->first();
                            if (! $check) {
                                BusinessAssociatesLocation::create([
                                    'business_associate_id' => $ba_data->id,
                                    'location_id' => $this->location_id,
                                ]);
                            }
                        }
                        // }
                    }
                    DB::commit();
                } catch (\Exception $e) {
                    DB::rollBack();
                    Log::error('DisasterRespondersImport/collection()[rows_error] => '.$e->getMessage());
                    Log::error('DisasterRespondersImport/collection()[rows_data] => '.json_encode($row));
                }
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function sheets(): array
    {
        return [
            0 => $this,
        ];
    }

    /**
     * @param  Failure[]  $failures
     */
    public function onFailure(Failure ...$failures)
    {
        $this->failures = array_merge($this->failures, $failures);
    }

    public function onError(\Throwable $e)
    {
        throw $e;
    }

    public function startRow(): int
    {
        return 3;
    }

    public function endColumn(): string
    {
        return 'AB';
    }

    /**
     * @param  mixed  $row
     */
    public function map($row): array
    {
        return array_map('trim', $row);
    }

    public function rules(): array
    {
        return [
            '*.local_police_department_name' => ['max:40'],
            '*.local_police_department_phone' => ['string', 'regex:/^(\d{3})(\-)(\d{3})(\-)(\d{4})$/', 'max:12', 'min:12'],
            '*.local_fire_department_name' => ['max:40'],
            '*.local_fire_department_phone' => ['string', 'regex:/^(\d{3})(\-)(\d{3})(\-)(\d{4})$/', 'max:12', 'min:12'],
            '*.alarm_system_company' => ['string', 'max:40'],
            '*.alarm_system_company_phone' => ['string', 'regex:/^(\d{3})(\-)(\d{3})(\-)(\d{4})$/', 'max:12', 'min:12'],
            '*.data_backup_vendor' => ['string', 'max:40'],
            '*.data_backup_vendor_phone' => ['string', 'regex:/^(\d{3})(\-)(\d{3})(\-)(\d{4})$/', 'max:12', 'min:12'],
            '*.data_backup_vendor_location' => ['in:Cloud_OR_Hosted,Offsite,Onsite,Not Applicable'],
            '*.landlord_property_manager' => ['string', 'max:40'],
            '*.landlord_property_manager_phone' => ['string', 'regex:/^(\d{3})(\-)(\d{3})(\-)(\d{4})$/', 'max:12', 'min:12'],
            '*.practice_management_software' => ['string', 'max:40'],
            '*.practice_management_software_phone' => ['string', 'regex:/^(\d{3})(\-)(\d{3})(\-)(\d{4})$/', 'max:12', 'min:12'],
            '*.ehr_software' => ['string', 'max:40'],
            '*.ehr_software_phone' => ['string', 'regex:/^(\d{3})(\-)(\d{3})(\-)(\d{4})$/', 'max:12', 'min:12'],
            '*.it_vendor' => ['string', 'max:40'],
            '*.it_vendor_phone' => ['string', 'regex:/^(\d{3})(\-)(\d{3})(\-)(\d{4})$/', 'max:12', 'min:12'],
            '*.hurricane' => ['required', 'in:1,2,3'],
            '*.flood' => ['required', 'in:1,2,3'],
            '*.tornado' => ['required', 'in:1,2,3'],
            '*.earthquake' => ['required', 'in:1,2,3'],
            '*.fire' => ['required', 'in:1,2,3'],
            '*.rogue_staff_vendor' => ['required', 'in:1,2,3'],
            '*.theft' => ['required', 'in:1,2,3'],
            '*.malicious_software_virus' => ['required', 'in:1,2,3'],
            '*.utility_interruption_failure' => ['required', 'in:1,2,3'],
            '*.public_health_emergency' => ['required', 'in:1,2,3'],
            '*.have_lab' => ['required', 'in:yes,no,Yes,No,YES,NO'],
        ];
    }

    public function customValidationMessages()
    {
        return [
            'local_police_department_name.max' => 'Local Police Department Name must not be greater than 40 characters.',
            'local_police_department_phone.regex' => 'Local Police Department Phone format is invalid.',
            'local_police_department_phone.string' => 'Local Police Department Phone must be string.',
            'local_police_department_phone.max' => 'Local Police Department Phone must not be greater than 12 characters.',
            'local_police_department_phone.min' => 'Local Police Department Phone must be at least 12 characters.',
            'local_fire_department_name.max' => 'Local Fire Department Name must not be greater than 40 characters.',
            'local_fire_department_phone.regex' => 'Local Fire Department Phone format is invalid.',
            'local_fire_department_phone.string' => 'Local Fire Department Phone must be string.',
            'local_fire_department_phone.max' => 'Local Fire Department Phone must not be greater than 12 characters.',
            'local_fire_department_phone.min' => 'Local Fire Department Phone must be at least 12 characters.',
            'alarm_system_company.max' => 'Alarm System Company must not be greater than 40 characters.',
            'alarm_system_company.string' => 'Alarm System Company must be string.',
            'alarm_system_company_phone.regex' => 'Alarm System Company Phone format is invalid.',
            'alarm_system_company_phone.string' => 'Alarm System Company Phone must be string.',
            'alarm_system_company_phone.max' => 'Alarm System Company Phone must not be greater than 12 characters.',
            'alarm_system_company_phone.min' => 'Alarm System Company Phone must be at least 12 characters.',
            'data_backup_vendor.max' => 'Data Backup Vendor must not be greater than 40 characters.',
            'data_backup_vendor.string' => 'Data Backup Vendor must be string.',
            'data_backup_vendor_phone.regex' => 'Data Backup Vendor Phone format is invalid.',
            'data_backup_vendor_phone.string' => 'Data Backup Vendor Phone must be string.',
            'data_backup_vendor_phone.max' => 'Data Backup Vendor Phone must not be greater than 12 characters.',
            'data_backup_vendor_phone.min' => 'Data Backup Vendor Phone must be at least 12 characters.',
            'data_backup_vendor_location.in' => 'Entered Data Backup Vendor Location is invalid.',
            'landlord_property_manager.max' => 'Landlord Property Manager must not be greater than 40 characters.',
            'landlord_property_manager.string' => 'Landlord Property Manager must be string.',
            'landlord_property_manager_phone.regex' => 'Landlord Property Manager Phone format is invalid.',
            'landlord_property_manager_phone.string' => 'Landlord Property Manager Phone must be string.',
            'landlord_property_manager_phone.max' => 'Landlord Property Manager Phone must not be greater than 12 characters.',
            'landlord_property_manager_phone.min' => 'Landlord Property Manager Phone must be at least 12 characters.',
            'practice_management_software.max' => 'Practice Management Software must not be greater than 40 characters.',
            'practice_management_software.string' => 'Practice Management Software must be string.',
            'practice_management_software_phone.regex' => 'Practice Management Software Phone format is invalid.',
            'practice_management_software_phone.string' => 'Practice Management Software Phone must be string.',
            'practice_management_software_phone.max' => 'Practice Management Software Phone must not be greater than 12 characters.',
            'practice_management_software_phone.min' => 'Practice Management Software Phone must be at least 12 characters.',
            'ehr_software.max' => 'EHR Software must not be greater than 40 characters.',
            'ehr_software.string' => 'EHR Software must be string.',
            'ehr_software_phone.regex' => 'EHR Software Phone format is invalid.',
            'ehr_software_phone.string' => 'EHR Software Phone must be string.',
            'ehr_software_phone.max' => 'EHR Software Phone must not be greater than 12 characters.',
            'ehr_software_phone.min' => 'EHR Software Phone must be at least 12 characters.',
            'it_vendor.max' => 'IT Vendor must not be greater than 40 characters.',
            'it_vendor.string' => 'IT Vendor must be string.',
            'it_vendor_phone.regex' => 'IT Vendor Phone format is invalid.',
            'it_vendor_phone.string' => 'IT Vendor Phone must be string.',
            'it_vendor_phone.max' => 'IT Vendor Phone must not be greater than 12 characters.',
            'it_vendor_phone.min' => 'IT Vendor Phone must be at least 12 characters.',
            'hurricane.required' => 'Hurricane field is required.',
            'hurricane.in' => 'Entered Hurricane is invalid.',
            'flood.required' => 'Flood field is required.',
            'flood.in' => 'Entered Flood is invalid.',
            'tornado.required' => 'Tornado field is required.',
            'tornado.in' => 'Entered Tornado is invalid.',
            'earthquake.required' => 'Earthquake field is required.',
            'earthquake.in' => 'Entered Earthquake is invalid.',
            'fire.required' => 'Fire field is required.',
            'fire.in' => 'Entered Fire is invalid.',
            'rogue_staff_vendor.required' => 'Rogue Staff Vendor field is required.',
            'rogue_staff_vendor.in' => 'Entered Rogue Staff Vendor is invalid.',
            'theft.required' => 'Theft field is required.',
            'theft.in' => 'Entered Theft is invalid.',
            'malicious_software_virus.required' => 'Malicious Software Virus field is required.',
            'malicious_software_virus.in' => 'Entered Malicious Software Virus is invalid.',
            'utility_interruption_failure.required' => 'Utility Interruption Failure field is required.',
            'utility_interruption_failure.in' => 'Entered Utility Interruption Failure is invalid.',
            'public_health_emergency.required' => 'Public Health Emergency field is required.',
            'public_health_emergency.in' => 'Entered Public Health Emergency is invalid.',
            'have_lab.required' => 'Have Lab field is required.',
            'have_lab.in' => 'Entered Have Lab is invalid.',
        ];
    }
}
