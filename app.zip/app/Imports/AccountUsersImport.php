<?php

namespace App\Imports;

use App\Models\AccountUser;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Traits\GetMainUserData;
use App\Traits\SendMail;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Validators\Failure;

class AccountUsersImport implements SkipsEmptyRows, SkipsOnError, SkipsOnFailure, ToCollection, WithChunkReading, WithHeadingRow, WithMapping, WithStartRow, WithValidation
{
    use GetMainUserData, Importable, SendMail, SkipsFailures;

    public $account_users;

    public $row_count = 0;

    public $total_row_count = 0;

    public $invalid_primary_location = [];

    public function collection(Collection $rows)
    {
        $user_data = $this->getMainAccountDetails();
        $location_list = Location::where('user_id', $user_data['id'])
            ->select(['id', 'location_nickname'])
            ->get();
        $this->total_row_count = count($rows);
        $errors_row = [];
        try {
            if ($this->total_row_count <= 50) {
                foreach ($rows as $row) {
                    try{
                        DB::beginTransaction();
                        $cleaned_first_name = preg_replace(Config::get('app.allowed_chars'), '', $row['first_name']);
                        $cleaned_last_name = preg_replace(Config::get('app.allowed_chars'), '', $row['last_name']);
                        $allowed_location_count = count($location_list);
                        if ($allowed_location_count > 1) {
                            if ($row['location_access']) {
                                $locations = array_unique(array_map('trim', explode('#', $row['location_access'])));
                                $location_access = [];
                                foreach ($locations as $key => $value) {
                                    $allowed_location = Location::where(['user_id' => $user_data['id'], 'location_nickname' => trim($value)])->first();
                                    if ($allowed_location) {
                                        $is_already_avail = array_search($allowed_location['id'], array_column($location_access, 'location_id'));
                                        if ($is_already_avail === false) {
                                            $location_access[$key] = [
                                                'location_id' => $allowed_location['id'],
                                            ];
                                        }
                                    } else {
                                        array_push($this->invalid_primary_location, 'Invalid location name:'.' '.$value);
                                    }
                                }
                                if (! empty($location_access)) {
                                    if (trim($cleaned_first_name) && trim($cleaned_last_name)) {
                                        $account_user = AccountUser::create([
                                            'user_id' => $user_data['id'],
                                            'first_name' => trim($cleaned_first_name),
                                            'last_name' => trim($cleaned_last_name),
                                            'email' => trim($row['email']),
                                        ]);
                                        $token = \Str::random(10);
                                        if ($account_user->update([
                                            'reset_password_token' => $token,
                                        ])) {
                                            $location_list_for_email = Location::select('location_nickname')->whereIn('id', array_values($location_access))->get();
                                            $emailTemplate = EmailTemplate::where('code', 'HCE-UE4')->first();
                                            $email_vars = [
                                                '{%USER_FIRST_NAME%}' => $account_user->first_name,
                                                '{%LOGIN_TO_ABYDE%}' => Config::get('app.url').'/login/'.$token.'/'.base64_encode($account_user->id).'/accountuser',
                                                '{%LOCATION_LIST_USER_ADDED_TO%}' => implode(', ', \Arr::pluck($location_list_for_email, 'location_nickname')),
                                                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                            ];
                                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                            $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
                                            $this->sendEmail($emailTemplate->code, $html, $account_user->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                                        }
                                        $account_user->accountLocationAccess()->createMany($location_access);
                                        $this->row_count++;
                                    }
                                }
                            }
                        } else {
                            if (trim($cleaned_first_name) && trim($cleaned_last_name)) {
                                $account_user = AccountUser::create([
                                    'user_id' => $user_data['id'],
                                    'first_name' => trim($cleaned_first_name),
                                    'last_name' => trim($cleaned_last_name),
                                    'email' => trim($row['email']),
                                ]);
                                $token = \Str::random(10);
                                if ($account_user->update([
                                    'reset_password_token' => $token,
                                ])) {
                                    $location_list_for_email = Location::select('location_nickname')->where('id', $location_list[0]['id'])->get();
                                    $emailTemplate = EmailTemplate::where('code', 'HCE-UE4')->first();
                                    $email_vars = [
                                        '{%USER_FIRST_NAME%}' => $account_user->first_name,
                                        '{%LOGIN_TO_ABYDE%}' => Config::get('app.url').'/login/'.$token.'/'.base64_encode($account_user->id).'/accountuser',
                                        '{%LOCATION_LIST_USER_ADDED_TO%}' => implode(', ', \Arr::pluck($location_list_for_email, 'location_nickname')),
                                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                    ];
                                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                    $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
                                    $this->sendEmail($emailTemplate->code, $html, $account_user->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                                    $this->row_count++;
                                }
                                $account_user->accountLocationAccess()->create(['location_id' => $location_list[0]['id']]);
                            }
                        }
                        DB::commit();
                    } catch (\Exception $e) {
                        DB::rollBack();
                        Log::error('AccountUsersImport/collection()[rows_error] => '.$e->getMessage());
                        Log::error('AccountUsersImport/collection()[rows_data] => '.json_encode($row));
                    }
                }
            } else {
                throw new \Exception('more_than_limit_records');
            }
        } catch (\Exception $e) {
            throw $e;
        }

    }

    /**
     * @param  Failure[]  $failures
     */
    public function onFailure(Failure ...$failures)
    {
        $this->failures = array_merge($this->failures, $failures);
    }

    public function startRow(): int
    {
        return 3;
    }

    public function onError(\Throwable $e)
    {
        throw $e;
    }

    /**
     * @param  mixed  $row
     */
    public function map($row): array
    {
        return array_map('trim', $row);
    }

    public function rules(): array
    {
        return [
            '*.first_name' => ['required', 'string', 'max:40', "regex:/^[a-z\d\-'!_.,()&\s]+$/i"],
            '*.last_name' => ['required', 'string', 'max:40', "regex:/^[a-z\d\-'!_.,()&\s]+$/i"],
            '*.location_access' => ['sometimes', 'required'],
            '*.email' => ['required', 'email:rfc,dns', 'max:100', 'distinct:ignore_case', 'unique:App\Models\AccountUser,email,NULL,id,deleted_at,NULL', 'unique:App\Models\User,email,NULL,id,deleted_at,NULL'],
        ];
    }

    public function customValidationMessages()
    {
        return [
            'first_name.required' => 'First Name field is required.',
            'first_name.max' => 'First Name must not be greater than 40 characters.',
            'first_name.regex' => "First Name valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !. ",
            'last_name.required' => 'Last Name field is required.',
            'last_name.max' => 'Last Name must not be greater than 40 characters.',
            'last_name.regex' => "Last Name valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !. ",
            'location_access.required' => 'Location field is required.',
            'email.required' => 'Email field is required.',
            'email.max' => 'Email must not be greater than 100 characters.',
            'email.unique' => 'Email has already been taken.',
            'email.email' => 'Email must be a valid email address.',
        ];
    }

    public function chunkSize(): int
    {
        return 1000;
    }
}
