<?php

namespace App\Imports;

use App\Models\AssetLog;
use App\Models\AssetLogDeviceType;
use App\Models\AssetLogDisposalStatus;
use App\Models\AssetLogEncryption;
use App\Models\AssetLogEphiAccess;
use App\Models\AssetLogOperatingLocation;
use App\Models\AssetLogOperatingSystem;
use App\Models\Employee;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithColumnLimit;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Validators\Failure;

class AssetLogImport implements SkipsEmptyRows, SkipsOnError, SkipsOnFailure, ToCollection, WithColumnLimit, WithHeadingRow, WithMapping, WithMultipleSheets, WithStartRow, WithValidation
{
    use Importable, SkipsFailures;

    public $location_id;

    public $row_count = 0;

    public $total_row_count = 0;

    /**
     * @param  Collection  $collection
     */
    public function collection(Collection $rows)
    {
        try {
            $this->total_row_count = count($rows);
            $invalid_email = [];
            foreach ($rows as $row) {
                try{
                    DB::beginTransaction();
                    $device_type = $row['device_type'];
                    $operating_system = $row['operating_system'];
                    $name = trim(preg_replace(Config::get('app.allowed_chars'), '', $row['name']));
                    $purchased_date = Carbon::parse($row['purchased_date'])->format('Y-m-d');
                    $asset_encryption = $row['asset_encryption'];
                    $ephi_access = $row['ephi_access'];
                    $operating_location = $row['additional_operating_location'];
                    $assigned_employee = $row['assigned_employee'];
                    $disposal_status = $row['disposal_status'];
                    $status = $row['status'];
                    if (! empty($row['disposal_date'])) {
                        $disposal_date = Carbon::parse($row['disposal_date'])->format('Y-m-d');
                    }
                    $device_type_id = AssetLogDeviceType::where('name', $device_type)->first('id');
                    $operating_system_id = AssetLogOperatingSystem::where('name', $operating_system)->first('id');
                    $asset_encryption_id = AssetLogEncryption::where('name', $asset_encryption)->first('id');
                    $ephi_access_id = AssetLogEphiAccess::where('name', $ephi_access)->first('id');

                    $operating_location_id = AssetLogOperatingLocation::where('name', $operating_location)->first('id');
                    $operating_location_id = $operating_location_id['id'];
                    $assigned_employee_id = '';
                    if ($assigned_employee == 'Assigned to Business Associate') {
                        $assigned_employee_id = 'assigned_to_business_associate';
                    } else {
                        $assigned_employee_data = Employee::where(function ($query) use ($assigned_employee) {
                            $query->where('email', $assigned_employee)
                                ->where(function ($q) {
                                    $q->where('primary_work_location_id', $this->location_id)
                                        ->orWhereHas('employeeSecondaryWorkLocation', function ($subQuery) {
                                            $subQuery->where('location_id', $this->location_id);
                                        });
                                });
                        })->first();
                        if ($assigned_employee_data) {
                            $assigned_employee_id = $assigned_employee_data->id;
                        } else {
                            array_push($invalid_email, 'Invalid email: '.$assigned_employee);
                        }
                    }

                    if ($status == 'Active') {
                        $disposal_status_id = null;
                        $disposal_date = null;
                    } else {
                        $disposal_status_id = AssetLogDisposalStatus::where('name', $disposal_status)->first('id')['id'];
                    }
                    // Asset Log
                    if ($assigned_employee_id && $name) {
                        $asset_log_create = AssetLog::create([
                            'location_id' => $this->location_id,
                            'device_type_id' => $device_type_id['id'],
                            'operating_system_id' => $operating_system_id['id'],
                            'status' => $status == 'Active' ? 'active' : 'inactive',
                            'name' => $name,
                            'purchased_date' => $purchased_date,
                            'asset_encryption_id' => $asset_encryption_id['id'],
                            'ephi_access_id' => $ephi_access_id['id'],
                            'operating_location_id' => $operating_location_id,
                            'assigned_employee_id' => $assigned_employee_id,
                            'disposal_status_id' => $disposal_status_id,
                            'disposal_date' => $disposal_date,
                        ]);
                        $this->row_count++;
                    }
                    DB::commit();
                } catch (\Exception $e) {
                    DB::rollBack();
                    Log::error('AssetLogImport/collection()[rows_error] => '.$e->getMessage());
                    Log::error('AssetLogImport/collection()[rows_data] => '.json_encode($row));
                }
            }
            if (! empty($invalid_email)) {
                $data = implode(',', $invalid_email);
                throw new \Exception($data);
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function sheets(): array
    {
        return [
            0 => $this,
        ];
    }

    /**
     * @param  Failure[]  $failures
     */
    public function onFailure(Failure ...$failures)
    {
        $this->failures = array_merge($this->failures, $failures);
    }

    public function onError(\Throwable $e)
    {
        throw $e;
    }

    public function startRow(): int
    {
        return 3;
    }

    public function endColumn(): string
    {
        return 'K';
    }

    /**
     * @param  mixed  $row
     */
    public function map($row): array
    {
        return array_map('trim', $row);
    }

    public function rules(): array
    {
        return [

            '*.device_type' => ['required'],
            '*.operating_system' => ['required'],
            '*.name' => ['required', 'max:100',  "regex:/^[a-z\d\-'!_.,()&\s]+$/i"],
            '*.additional_operating_location' => ['required'],
            '*.assigned_employee' => ['required'],
            '*.purchased_date' => ['required', 'date_format:m/d/Y', 'after:01/01/1970'],
            '*.asset_encryption' => ['required'],
            '*.ephi_access' => ['required'],
            '*.status' => ['required'],
            '*.disposal_status' => ['required_if:*.status,Inactive', 'required_with:*.disposal_date', 'nullable'],
            '*.disposal_date' => ['required_if:*.status,Inactive', 'required_with:*.disposal_status', 'nullable', 'date_format:m/d/Y', 'after_or_equal:*.purchased_date'],
        ];
    }

    public function customValidationMessages()
    {
        return [
            'device_type.required' => 'Device Type field is required.',
            'operating_system.required' => 'Operating System field is required.',
            'name.required' => 'Name field is required.',
            'name.max' => 'Name must not be greater than 100 characters.',
            'name.regex' => "Name valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !. ",
            'additional_operating_location.required' => 'Additional Operating Location field is required.',
            'assigned_employee.required' => 'Assigned Employee field is required.',
            'purchased_date.required' => 'Purchased Date field is required.',
            'purchased_date.date_format' => 'Purchased Date does not match the format m/d/Y.',
            'purchased_date.after' => 'Purchased Date must be a date after 01/01/1970.',
            'asset_encryption.required' => 'Asset Encryption field is required.',
            'ephi_access.required' => 'ePHI Access field is required.',
            'status.required' => 'Status field is required.',
            'disposal_status.required_if' => 'Disposal Status field is required when status is inactive. ',
            'disposal_status.required_with' => 'Disposal Status field is required when Disposal Date is present',
            'disposal_date.required_with' => 'Disposal Date field is required when Disposal Status is present.',
            'disposal_date.required_if' => 'Disposal Date field is required when status is inactive. ',
            'disposal_date.date_format' => 'Disposal Date does not match the format m/d/Y.',
            'disposal_date.after_or_equal' => 'Disposal Date must be a date after or equal to Purchased Date.',
        ];
    }
}
