<?php

namespace App\Imports;

use App\Http\Controllers\App\GeneralController;
use App\Jobs\SendLocationDataToSalesForce;
use App\Models\RiskAnalysisContributor;
use App\Models\Location;
use App\Traits\GeneratePolicy;
use App\Traits\GetMainUserData;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Validators\Failure;
use App\Models\EmailTemplate;
use App\Traits\SendMail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class RiskAnalysisContributorImport implements SkipsEmptyRows, SkipsOnError, SkipsOnFailure, ToCollection, WithChunkReading, WithHeadingRow, WithMapping, WithMultipleSheets, WithStartRow, WithValidation
{
    use GeneratePolicy, GetMainUserData, Importable, SkipsFailures, SendMail;

    public $row_count = 0;

    public $total_row_count = 0;

    public $invalid_locations = [];

    public function collection(Collection $rows)
    {
        $user_data = $this->getMainAccountDetails();
        $this->total_row_count = count($rows);
        if ($this->total_row_count <= 50) {
            $generalController = new GeneralController;
            $location_access_list = $generalController->getAssingedLocationList();
            $locations = Location::where('user_id', $user_data['id'])
                ->whereIn('id', $location_access_list)
                ->get();
            $locations_ba_unlocked = $locations->pluck('id');
            $allowed_location_count = count($locations);
            foreach ($rows as $row) {
                try{
                    DB::beginTransaction();
                    if ($allowed_location_count > 1) {
                        if ($row['location_access']) {
                            $locations = array_unique(array_map('trim', explode('#', $row['location_access'])));
                            $location_access = [];                       
                            foreach ($locations as $key => $value) {
                                $allowed_location = Location::where(['user_id' => $user_data['id'], 'location_nickname' => trim($value)])->first();
                                if ($allowed_location) {
                                    $location_access[$key] = [
                                        'location_id' => $allowed_location->id,
                                        
                                    ];
                                } else {
                                    array_push($this->invalid_locations, 'Invalid Assigned location(s) name:'.' '.$value);
                                }
                            }
                        }
                        if (! empty($location_access)) {
                            $first_name = trim(preg_replace(Config::get('app.allowed_chars'), '', $row['first_name']));                        
                            $sra_contributor = RiskAnalysisContributor::create([
                                'user_id' => $user_data['id'],
                                'first_name' => $first_name,
                                'last_name' => trim(preg_replace(Config::get('app.allowed_chars'), '', $row['last_name'])),
                                'company_name' => trim(preg_replace(Config::get('app.allowed_chars'), '', $row['company_name'])),
                                'email' => trim($row['email']),
                            ]);
                            $sra_contributor->riskAnalysisContributorLocation()->createMany($location_access);


                            $location_list_for_email = Location::select('location_nickname')->whereIn('id', array_values($location_access))->get();
                            $emailTemplate = EmailTemplate::where('code', 'HCE-UE64')->first();
                            $email_vars = [
                            '{%CONTRIBUTOR_FIRST_NAME%}' => $first_name,
                            '{%COMPANY_NAME%}' => $user_data->company_name,                
                            '{%PCO_OFFICER%}' => $user_data->first_name . ' '. $user_data->last_name,
                            '{%PCO_OFFICER_EMAIL%}' => $user_data->email,
                            '{%HIPAABA_LINK%}' => Config::get('app.hipaa_business_associates_url'),
                            '{%PARTNER_LINK%}' => Config::get('app.partner_url')
                            ];
                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                            $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
                            $this->sendEmail($emailTemplate->code, $html, $sra_contributor->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));



                            $this->row_count++;
                        }
                    } else {
                        $first_name = trim(preg_replace(Config::get('app.allowed_chars'), '', $row['first_name']));                    
                        $sra_contributor = RiskAnalysisContributor::create([
                            'user_id' => $user_data['id'],
                            'first_name' => $first_name,
                            'last_name' => trim(preg_replace(Config::get('app.allowed_chars'), '', $row['last_name'])),
                            'company_name' => trim(preg_replace(Config::get('app.allowed_chars'), '', $row['company_name'])),
                            'email' => trim($row['email']),                        
                        ]);
                        $this->row_count++;
                        $sra_contributor->riskAnalysisContributorLocation()->create(['location_id' => $locations[0]->id]);

                        $location_list_for_email = Location::select('location_nickname')->where('id', $locations[0]->id)->get();
                        $emailTemplate = EmailTemplate::where('code', 'HCE-UE64')->first();
                        $email_vars = [     
                            '{%CONTRIBUTOR_FIRST_NAME%}' => $first_name,                   
                            '{%COMPANY_NAME%}' => $user_data->company_name,                
                            '{%PCO_OFFICER%}' => $user_data->first_name . ' '. $user_data->last_name,
                            '{%PCO_OFFICER_EMAIL%}' => $user_data->email,
                            '{%HIPAABA_LINK%}' => Config::get('app.hipaa_business_associates_url'),
                            '{%PARTNER_LINK%}' => Config::get('app.partner_url')
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        $html_subject = str_ireplace(['{%COMPANY_NAME%}'], [$user_data->company_name], $emailTemplate->subject);
                        $this->sendEmail($emailTemplate->code, $html, $sra_contributor->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user_data->partner_reseller_id != null ? $user_data->reseller->logo : null));
                    }
                    DB::commit();
                } catch (\Exception $e) {
                    DB::rollBack();
                    Log::error('RiskAnalysisContributorImport/collection()[rows_error] => '.$e->getMessage());
                    Log::error('RiskAnalysisContributorImport/collection()[rows_data] => '.json_encode($row));
                }
            }
        } else {
            throw new \Exception('more_than_limit_records');
        }
    }

    public function sheets(): array
    {
        return [
            0 => $this,
        ];
    }

    /**
     * @param  Failure[]  $failures
     */
    public function onFailure(Failure ...$failures)
    {
        $this->failures = array_merge($this->failures, $failures);
    }

    public function onError(\Throwable $e)
    {
        throw $e;
    }

    public function startRow(): int
    {
        return 3;
    }

    /**
     * @param  mixed  $row
     */
    public function map($row): array
    {
        return array_map('trim', $row);
    }

    public function rules(): array
    {
        $user_data = $this->getMainAccountDetails();

        return [
            '*.first_name' => ['required', 'string', "regex:/^[a-z\d\-'!_.,()&\s]+$/i", 'max:40'],
            '*.last_name' => ['required', 'string', "regex:/^[a-z\d\-'!_.,()&\s]+$/i", 'max:40'],
            '*.company_name' => ['required', 'string', "regex:/^[a-z\d\-'!_.,()&\s]+$/i", 'max:100'],
            '*.email' => ['required', 'email:rfc,dns', 'max:100', 'distinct:ignore_case', 'unique:App\Models\RiskAnalysisContributor,email,NULL,id,deleted_at,NULL,user_id,'.$user_data['id']],            
            '*.location_access' => ['sometimes', 'required'],
        ];
    }

    public function customValidationMessages()
    {
        return [
            'first_name.required' => 'First Name field is required.',
            'first_name.string' => 'First Name must be string.',
            'first_name.max' => 'First Name must not be greater than 40 characters.',
            'first_name.regex' => "First Name valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !. ",
            'last_name.required' => 'Last Name field is required.',
            'last_name.string' => 'Last Name must be string.',
            'last_name.max' => 'Last Name must not be greater than 40 characters.',
            'last_name.regex' => "Last Name valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !. ",
            'company_name.required' => 'Company Name field is required.',
            'company_name.string' => 'Company Name must be string.',
            'company_name.max' => 'Company Name must not be greater than 100 characters.',
            'company_name.regex' => "Company Name valid characters are A-Z a-z 0-9 . _ - , & ( ) ' !. ",
            'email.required' => 'Email field is required.',
            'email.max' => 'Email must not be greater than 100 characters.',
            'email.unique' => 'Email has already been taken.',
            'email.email' => 'Email must be a valid email address.',            
            'location_access.required' => 'Assigned location(s) field is required. ',
        ];
    }

    public function chunkSize(): int
    {
        return 1000;
    }
}
