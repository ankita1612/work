<?php

namespace App\Console\Commands;

use App\Http\Controllers\App\TrainingController;
use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\Employee;
use App\Models\HipaaComplianceOfficer;
use App\Models\Setting;
use App\Models\TrainingInvite;
use App\Models\TrainingLocation;
use App\Traits\Notification;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class AllTrainingsInvite extends Command
{
    use Notification, SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'all:traininginvite';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'send invite to employee for all training on schedule date';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'AllTrainingsInvite',
            'start' => now(),
        ]);
        try {
            $pause_user = Setting::where('functionality', 'training_pause')->pluck('user_id');
            $training_location_list = TrainingLocation::where('schedule_date', '<=', Carbon::today()->format('Y-m-d'))
                ->with(['training', 'location' => function ($query) use ($pause_user) {
                    $query->whereNotIn('user_id', $pause_user);
                }, 'location.sraModuleCompleted', 'location.hipaaComplianceOfficer', 'location.employeePrimaryWorkLocation'])
                ->where('is_triggered', 0)
                ->where('is_disable', 0)
                ->whereHas('location', function ($query) use ($pause_user) {
                    $query->whereNotIn('user_id', $pause_user);
                })
                ->get();
            if (! empty($training_location_list)) {
                foreach ($training_location_list as $training_location) {
                    if ($training_location->location->sraModuleCompleted != null && $training_location->location->hipaaComplianceOfficer != null && count($training_location->location->employeePrimaryWorkLocation) > 0) {
                        try {
                            TrainingLocation::where(['location_id' => $training_location->location->id, 'training_id' => $training_location->training->id])->update(['is_triggered' => 1]);
                            if ($training_location->training->who_can_train == 'employee') {
                                $emp_list = Employee::select(['id', 'first_name', 'last_name', 'email', 'primary_work_location_id'])
                                    ->where('primary_work_location_id', $training_location->location->id)
                                    ->with('employeePrimaryWorkLocation')
                                    ->isActive()
                                    ->get();
                                if (count($emp_list) > 0) {
                                    $check_user_email_pause = Setting::where('user_id', $training_location->location['user']['id'])->where('functionality', 'training_email_pause')->count();
                                    $check_user_notification_pause = Setting::where('user_id', $training_location->location['user']['id'])->where('functionality', 'training_notification_pause')->count();
                                    foreach ($emp_list as $emp_data) {
                                        try {
                                            $check_invite = TrainingInvite::where('emp_user_acntuser_student_id', $emp_data['id'])->where('training_id', $training_location->training->id)->where('emp_user_acntuser_student_type', \App\Models\Employee::class)->first();
                                            if ($check_invite === null || ! $check_invite) {
                                                $training_invite_data = [
                                                    'emp_user_acntuser_student_id' => $emp_data['id'],
                                                    'emp_user_acntuser_student_type' => \App\Models\Employee::class,
                                                    'training_id' => $training_location->training->id,
                                                    'ref_token' => Str::random(40),
                                                    'invite_datetime' => gmdate('Y-m-d H:i:s'),
                                                ];
                                                $add_training_invite = TrainingInvite::create($training_invite_data);
                                                if ($training_location->training->parent_training_id == '') {
                                                    if ($check_user_email_pause == 0) {
                                                        // send HCE-UE14
                                                        $hco = HipaaComplianceOfficer::where('location_id', $emp_data->primary_work_location_id)->with('hco')->first();
                                                        $emailCode = ($training_location->training->training_code == 'HT25') ? 'HCE-UE52' : 'HCE-UE14';
                                                        $emailTemplate = EmailTemplate::where('code', $emailCode)->first();
                                                        $email_vars = [
                                                            '{%EMPLOYEE_FIRST_NAME%}' => $emp_data['first_name'],
                                                            '{%FIRST_NAME%}' => $emp_data['first_name'],
                                                            '{%LOGIN_TO_ABYDE_EMPLOYEE_PORTAL%}' => Config::get('app.emp_portal_url'),
                                                            '{%HCO_FIRST_NAME%}' => $hco->hco->first_name,
                                                            '{%HCO_LAST_NAME%}' => $hco->hco->last_name,
                                                            '{%HCO_EMAIL%}' => $hco->hco->email,
                                                        ];
                                                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                                        if ($training_location->location['user']['account_status'] == 'Unfrozen' && $training_location->location['user']['is_active'] == '1' && $training_location->location['user']['is_account_verified'] == '1') {
                                                            $this->sendEmail($emailTemplate->code, $html, $emp_data['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($training_location->location['user']['partner_reseller_id'] != null ? $training_location->location['user']['reseller']['logo'] : null), $training_location->location['user']['id']);
                                                        }
                                                    }
                                                    $notification = $this->getNotificationByCode($training_location->training->notification_code);
                                                    if ($notification && $this->checkNotificationAlreadyAdded($notification->code, $training_location->location->id) == 0) {
                                                        if ($check_user_notification_pause == 0) {
                                                            $notification_data = [
                                                                'location_id' => $training_location->location->id,
                                                                'notification_id' => $notification['id'],
                                                            ];
                                                            $this->createNotification($notification_data);
                                                        }
                                                        if ($check_user_email_pause == 0) {
                                                            // send HCE-UE34
                                                            $emailTemplate = EmailTemplate::where('code', 'HCE-UE34')->first();
                                                            $email_vars = [
                                                                '{%FIRST_NAME%}' => $hco->hco->first_name,
                                                                '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                                                                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                                            ];
                                                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                                            if ($training_location->location['user']['account_status'] == 'Unfrozen' && $training_location->location['user']['is_active'] == '1' && $training_location->location['user']['is_account_verified'] == '1') {
                                                                $this->sendEmail($emailTemplate->code, $html, $hco->hco->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($training_location->location['user']['partner_reseller_id'] != null ? $training_location->location['user']['reseller']['logo'] : null), $training_location->location['user']['id']);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } catch (\Exception $e) {
                                            Log::error('AllTrainingsInvite/handle()[emp_list_loop_error] => '.$e->getMessage());
                                            Log::error('AllTrainingsInvite/handle()[emp_list_loop_data] => '.json_encode($emp_data));
                                        }
                                    }
                                }
                            }

                            if ($training_location->training->who_can_train == 'hco') {
                                $hco_list = HipaaComplianceOfficer::where('location_id', $training_location->location->id)->with(['hco', 'location'])->first();
                                if ($hco_list != null) {
                                    $emp_count = Employee::where('primary_work_location_id', $training_location->location->id)->count();
                                    if ($emp_count > 0) {
                                        $check_invite = TrainingInvite::where('emp_user_acntuser_student_id', $hco_list['hco_id'])->where('training_id', $training_location->training->id)->where('emp_user_acntuser_student_type', $hco_list['hco_type'])->first();
                                        if ($check_invite === null || ! $check_invite) {
                                            $training_invite_data = [
                                                'emp_user_acntuser_student_id' => $hco_list['hco_id'],
                                                'emp_user_acntuser_student_type' => $hco_list['hco_type'],
                                                'training_id' => $training_location->training->id,
                                                'ref_token' => Str::random(40),
                                                'invite_datetime' => gmdate('Y-m-d H:i:s'),
                                            ];
                                            $add_training_invite = TrainingInvite::create($training_invite_data);
                                            if ($training_location->training->parent_training_id == '') {
                                                $check_user_notification_pause = Setting::where('user_id', $training_location->location['user']['id'])->where('functionality', 'training_notification_pause')->count();
                                                if ($check_user_notification_pause == 0) {
                                                    $notification = $this->getNotificationByCode($training_location->training->notification_code);
                                                    if ($this->checkNotificationAlreadyAdded($notification->code, $training_location->location->id) == 0) {
                                                        $notification_data = [
                                                            'location_id' => $training_location->location->id,
                                                            'notification_id' => $notification['id'],
                                                        ];
                                                        $this->createNotification($notification_data);
                                                    }
                                                }
                                                $check_user_email_pause = Setting::where('user_id', $training_location->location['user']['id'])->where('functionality', 'training_email_pause')->count();
                                                if ($check_user_email_pause == 0) {
                                                    // send HCE-UE40
                                                    $emailCode = ($training_location->training->training_code == 'HT22') ? 'HCE-UE51' : 'HCE-UE40';
                                                    if ($training_location->training->parent_training_id == '') {
                                                        $emailTemplate = EmailTemplate::where('code', $emailCode)->first();
                                                        $email_vars = [
                                                            '{%HCO_FIRST_NAME%}' => $hco_list['hco']['first_name'],
                                                            '{%LOG_IN_TO_ABYDE%}' => Config::get('app.url'),
                                                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                                        ];
                                                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                                        if ($training_location->location['user']['account_status'] == 'Unfrozen' && $training_location->location['user']['is_active'] == '1' && $training_location->location['user']['is_account_verified'] == '1') {
                                                            $this->sendEmail($emailTemplate->code, $html, $hco_list['hco']['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($training_location->location['user']['partner_reseller_id'] != null ? $training_location->location['user']['reseller']['logo'] : null), $training_location->location['user']['id']);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            $training_controller = new TrainingController;
                            $training_controller->moveTrainingToArchive($training_location->location->id, $training_location->training->id);
                        } catch (\Exception $e) {
                            Log::error('AllTrainingsInvite/handle()[training_location_list_loop_error] => '.$e->getMessage());
                            Log::error('AllTrainingsInvite/handle()[training_location_list_loop_data] => '.json_encode($training_location->location));
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('AddTrainingToLocation/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
