<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\Training;
use App\Models\TrainingLocation;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SplitTrainingLocationScript extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'splitscript:traininglocation';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'SplitTrainingLocationScript',
            'start' => now(),
        ]);
        try {
            $old_training_code = "HT4";
            $new_training_code_A = ($old_training_code == "HT5") ? "HT5A" : "HT4A";
            $new_training_code_B = ($old_training_code == "HT5") ? "HT5B" : "HT4B";
            $new_training_code_C = ($old_training_code == "HT5") ? "HT5C" : "HT4C";
            
            $training = Training::where('training_code', $old_training_code)->first();
            $new_training_1_1 = Training::where('training_code', $new_training_code_A)->first();
            $new_training_1_2 = Training::where('training_code', $new_training_code_B)->first();
            $new_training_1_3 = Training::where('training_code', $new_training_code_C)->first();            
         
              
            if ($training) {
                $training_locations = TrainingLocation::where('training_id', $training['id'])->skip(0)->take(500)->get();
                foreach ($training_locations as $training_location) {
                    $temp_data = [
                        'location_id' => $training_location->location_id,
                        'training_id' => $new_training_1_1['id'],
                        'trigger_type' => $training_location->trigger_type,
                        'schedule_date' => $training_location->schedule_date,
                        'old_schedule_date' => $training_location->old_schedule_date,
                        'schedule_by_id' => $training_location->schedule_by_id,
                        'schedule_by_type' => $training_location->schedule_by_type,
                        'is_disable' => $training_location->is_disable,
                        'is_triggered' => $training_location->is_triggered,
                        'is_archived' => $training_location->is_archived,
                    ];
                    TrainingLocation::create($temp_data);
                    $temp_data['training_id'] = $new_training_1_2['id'];
                    TrainingLocation::create($temp_data);
                    $temp_data['training_id'] = $new_training_1_3['id'];
                    TrainingLocation::create($temp_data);
                    $training_location->delete();
                }
            } else {
                Log::error('SplitTrainingLocationScript/handle() => Training not found');
            }
        } catch (\Exception $e) {
            Log::error('Training Location: '.$training_location->id);
            Log::error('SplitTrainingLocationScript/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
