<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Traits\{SendMail};
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class GenrateMonthlyHipaaTrainingReport extends Command
{
    use SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'genratereport:monthlyhipaatraining';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Genrate monthly hipaa trining report and send to HCO';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'GenrateMonthlyHipaaTrainingReport',
            'start' => now(),
        ]);
        try {
            $location_data = Location::with('hipaaComplianceOfficer.hco', 'user.reseller')
                ->whereHas('hipaaComplianceOfficer')
                ->whereHas('sraModuleCompleted')
                ->where(function ($query) {
                    $query->whereHas('activeEmployeePrimaryWorkLocation');
                })
                ->whereHas('user', function ($query) {
                    $query->where('account_status', 'Unfrozen')->where('is_active', '1')->where('is_account_verified', '1')->where('is_sra_user', 0);
                })
                ->get();

            $emailTemplate = EmailTemplate::where('code', 'HCE-UE38')->first();
            $email_array = [];
            $delayTime = Carbon::today()->format('Y-m-d') .' '. Config::get('app.send_email_delay_time');
            foreach ($location_data as $location) {
                try{
                    $logo = '';
                    if (! empty($location->hipaaComplianceOfficer) && ! empty($location->hipaaComplianceOfficer->hco) && ! in_array($location->hipaaComplianceOfficer->hco->email, $email_array)) {
                        $email_array[] = $location->hipaaComplianceOfficer->hco->email;
                        $email_vars = [
                            '{%FIRST_NAME%}' => $location->hipaaComplianceOfficer->hco->first_name,
                            '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        if ($location->user->partner_reseller_id != null) {
                            $logo = ($location->user->partner_reseller_id != null) ? $location->user->reseller->logo : null;
                        }
                        $this->sendEmail($emailTemplate->code, $html, $location->hipaaComplianceOfficer->hco->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, $logo, $location->user->id, null, $delayTime);
                    }
                } catch (\Exception $e) {
                    Log::error('GenrateMonthlyHipaaTrainingReport/handle()[location_error]  => '.$e->getMessage());
                    Log::error('GenrateMonthlyHipaaTrainingReport/handle()[location_data]  => '.json_encode($location));
                }
            }
        } catch (\Exception $e) {
            Log::error('GenrateMonthlyHipaaTrainingReport/handle() => '.$e->getMessage());
            Log::error('GenrateMonthlyHipaaTrainingReport/handle() Error line => '.$e->getLine());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
