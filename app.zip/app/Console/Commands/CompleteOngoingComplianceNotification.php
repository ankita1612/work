<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Models\OngoingRiskAnalysisQuestion;
use App\Traits\Notification;
use App\Traits\SendMail;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CompleteOngoingComplianceNotification extends Command
{
    use Notification, SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'complete_ongoing_Compliance:notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Notification will be send 1st day of month by checking previous month OG if unanswered questions are available';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'CompleteOngoingComplianceNotification',
            'start' => now(),
        ]);
        try{
            $month_start_date = new Carbon('first day of last month');
            $month_end_date = new Carbon('last day of last month');
            $last_month_start_datetime = $month_start_date->format('Y-m-d').' 00:00:00';
            $last_month_end_datetime = $month_end_date->format('Y-m-d').' 23:59:59';
            $not_answered_questions = OngoingRiskAnalysisQuestion::select(DB::raw('count(*) as total_questions, id, location_id'))
                ->where('added_date', '>=', $last_month_start_datetime)
                ->where('added_date', '<=', $last_month_end_datetime)
                ->where('is_answered', 0)
                ->groupBy('location_id')
                ->get();

            $notification_HCE_AN7 = $this->getNotificationByCode('HCE-AN7');

            $emailTemplate = EmailTemplate::where('code', 'HCE-UE11')->first();
            $loctions_data = Location::with([
                'user.reseller',
                'hipaaComplianceOfficer.hco',
                'accountLocationAccess.accountUser',
            ])
                ->get();
            foreach ($not_answered_questions as $que) {
                try{
                    $notification_HCE_AN7_data = [
                        'location_id' => $que['location_id'],
                        'notification_id' => $notification_HCE_AN7['id'],
                    ];
                    $loc_data = $loctions_data->where('id', $que['location_id'])->first();
                    if ($loc_data) {
                        $this->createNotification($notification_HCE_AN7_data);

                        $email_send_hcouser_list = [];

                        $hco = $loc_data->hipaaComplianceOfficer;

                        if ($hco) {
                            $email_send_hcouser_list[] = ['first_name' => $hco->hco->first_name, 'email' => $hco->hco->email];
                        }
                        $account_users_list = $loc_data->accountLocationAccess;
                        foreach ($account_users_list as $key => $value) {
                            try{
                                if ($hco && $value->accountUser->email != $hco->hco->email) {
                                    $email_send_hcouser_list[] = ['first_name' => $value->accountUser->first_name, 'email' => $value->accountUser->email];
                                }
                                if (! $hco) {
                                    $email_send_hcouser_list[] = ['first_name' => $value->accountUser->first_name, 'email' => $value->accountUser->email];
                                }
                            } catch (\Exception $e) {
                                Log::error('CompleteOngoingComplianceNotification/handle()[account_users_list_error] => '.$e->getMessage());
                                Log::error('CompleteOngoingComplianceNotification/handle()[account_users_list_data] => '.json_encode($value));
                            }
                        }
                        foreach ($email_send_hcouser_list as $key => $value) {
                            try{
                                $email_vars = [
                                    '{%FIRST_NAME%}' => $value['first_name'],
                                    '{%LOCATION_NAME%}' => $loc_data->location_nickname,
                                    '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                ];
                                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                if ($loc_data['user']['account_status'] == 'Unfrozen' && $loc_data['user']['is_active'] == '1' && $loc_data['user']['is_account_verified'] == '1') {
                                    $this->sendEmail($emailTemplate->code, $html, $value['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($loc_data['user']['partner_reseller_id'] != null ? $loc_data['user']['reseller']['logo'] : null), $loc_data['user']['id']);
                                }
                             } catch (\Exception $e) {
                                Log::error('CompleteOngoingComplianceNotification/handle()[email_send_osouser_list_error] => '.$e->getMessage());
                                Log::error('CompleteOngoingComplianceNotification/handle()[email_send_osouser_list_data] => '.json_encode($value));
                            }
                        }
                    }
                } catch (\Exception $e) {
                    Log::error('CompleteOngoingComplianceNotification/handle()[not_answered_questions_error] => '.$e->getMessage());
                    Log::error('CompleteOngoingComplianceNotification/handle()[not_answered_questions_data] => '.json_encode($que));
                }
            }
        }catch (\Exception $e) {
            Log::error('CompleteOngoingComplianceNotification/handle() => '.$e->getMessage());
        }

        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
