<?php

namespace App\Console\Commands;

use App\Http\Controllers\App\SecurityRiskAnalysisController;
use App\Models\CronExcecution;
use App\Models\Location;
use App\Models\RiskAnalysisQuestion;
use App\Models\ScorecardDownloadHistory;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class ScorecardHistory extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'scorecard:history {location_id?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Gather data for SRA and store as json to create pdf';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if (! $this->argument('location_id')) {
            $cron_excecution = CronExcecution::create([
                'name' => 'ScorecardHistory',
                'start' => now(),
            ]);
        }
        $locations = Location::whereHas('sraModuleCompleted')->with(['user', 'state', 'sraModuleCompleted']);
        if ($this->argument('location_id')) {
            $locations = $locations->where('id', $this->argument('location_id'));
        }
        $locations = $locations->get();

        foreach ($locations as $loc) {
            try{
                $check_is_ra_completed = $loc->sraModuleCompleted;

                if ($check_is_ra_completed) {
                    $file_name = preg_replace('/[^A-Za-z0-9\-\_]/', '', str_replace(' ', '_', trim($loc['location_nickname']))).'-Security-Risk-Analysis-'.date('YmdHis');
                    $data = RiskAnalysisQuestion::isActive()
                        ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($loc) {
                            $que->where(['location_id' => $loc['id']]);
                        })->with(
                            ['RiskAnalysisAttemptedQuestion' => function ($que) use ($loc) {
                                return $que->where('location_id', $loc['id'])
                                    ->with('attemptedQuestionAnswer.answerContent', 'attemptedQuestionAnswer.answerContent.remindOptionDetail');
                            }, 'riskAnalysisQuestionAnswerOptions', 'questionCategory', 'questionLawSection', 'riskAnalysisPreviousAttemptedQuestionAnswer' => function ($que) use ($loc) {
                                return $que->where('location_id', $loc['id'])
                                    ->with('answerContent');
                            }]
                        );
                    $data = $data->orderBy('display_order', 'ASC')->get()->toArray();

                    $question_list = [];
                    $risk_count = [];
                    $low_risk_count = 0;
                    $medium_risk_count = 0;
                    $high_risk_count = 0;
                    foreach ($data as $key => $list) {
                        $risk_level = '';
                        $risk_levele_image = '';
                        if ($list['question_answer_layout'] == 'radio') {
                            $answer = $list['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content'];
                            $score = $answer['score'];
                            switch ($score) {
                                case 1:
                                    $risk_level = 'Very Low';
                                    $risk_levele_image = 'very-low.png';
                                    $low_risk_count++;
                                    break;
                                case 2:
                                case 3:
                                    $risk_level = 'Low';
                                    $risk_levele_image = 'low.png';
                                    $low_risk_count++;
                                    break;
                                case 4:
                                case 5:
                                case 6:
                                    $risk_level = 'Medium';
                                    $risk_levele_image = 'medium.png';
                                    $medium_risk_count++;
                                    break;
                                case 7:
                                case 8:
                                    $risk_level = 'High';
                                    $risk_levele_image = 'high.png';
                                    $high_risk_count++;
                                    break;
                                case 9:
                                case 10:
                                    $risk_level = 'Very High';
                                    $risk_levele_image = 'very-high.png';
                                    $high_risk_count++;
                                    break;
                            }
                            $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['risk_level'] = $risk_level;
                            $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['risk_level_image'] = $risk_levele_image;

                            $likelihood = $answer['likelihood'];
                            $likelihood_text = '';
                            switch ($likelihood) {
                                case 1:
                                    $likelihood_text = 'Low';
                                    break;
                                case 2:
                                    $likelihood_text = 'Medium';
                                    break;
                                case 3:
                                    $likelihood_text = 'High';
                                    break;
                            }
                            $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['likelihood_text'] = $likelihood_text;

                            $impact = $answer['impact'];
                            $impact_text = '';
                            switch ($impact) {
                                case 1:
                                    $impact_text = 'Low';
                                    break;
                                case 2:
                                    $impact_text = 'Medium';
                                    break;
                                case 3:
                                    $impact_text = 'High';
                                    break;
                            }
                            $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['impact_text'] = $impact_text;
                        }
                        if (isset($data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content'])) {
                            $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['remind_option_detail'] = isset($data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['remind_option_detail']) ? $data[$key]['risk_analysis_attempted_question'][0]['attempted_question_answer'][0]['answer_content']['remind_option_detail'] : null;
                        }
                        if (($list['question_code'] == 'Q75S3' || $list['question_code'] == 'Q75S4' || $list['question_code'] == 'Q75S5')) {
                            $ra = new SecurityRiskAnalysisController;
                            $str_to_replace = $ra->getDynamicString($loc['id'], 'Q75');
                            $data[$key]['question'] = str_replace('{%IT_PROVIDER_QUESTION%}', $str_to_replace, $list['question']);
                        }
                        $question_list[] = $data[$key];
                    }
                    $risk_count['low_risk_count'] = $low_risk_count;
                    $risk_count['medium_risk_count'] = $medium_risk_count;
                    $risk_count['high_risk_count'] = $high_risk_count;

                    $pdf_data = [
                        'title' => $file_name.'.pdf',
                        'location' => $loc,
                        'question_list' => $question_list,
                        'sra_complete_details' => $check_is_ra_completed,
                        'risk_count' => $risk_count,
                    ];

                    $jsonData = json_encode($pdf_data);
                    $file_path = 'scorecard_history_json/';
                    $file_name = $file_name.'.json';
                    Storage::disk('s3')->put($file_path.$file_name, $jsonData);

                    ScorecardDownloadHistory::create([
                        'history_data_json_file' => $file_name,
                        'location_id' => $loc['id'],
                        'low_risk_count' => $risk_count['low_risk_count'],
                        'medium_risk_count' => $risk_count['medium_risk_count'],
                        'high_risk_count' => $risk_count['high_risk_count'],
                    ]);
                }
            } catch (\Exception $e) {
                Log::error('ScorecardHistory/handle()[location_error] => '.$e->getMessage());
                Log::error('ScorecardHistory/handle()[location_data] => '.json_encode($loc));
            }
        }
        if (! $this->argument('location_id')) {
            $cron_excecution->update([
                'end' => now(),
            ]);
        }
    }
}
