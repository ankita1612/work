<?php

namespace App\Console\Commands;

use App\Models\AbydeDriveFile;
use App\Models\AbydeDriveFolder;
use App\Models\CronExcecution;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class AbydeDriveTrash extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'abydedrive:trash';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'check trash file and folder and delete permanently';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'AbydeDriveTrash',
            'start' => now(),
        ]);

        try{
            $folders = AbydeDriveFolder::onlyTrashed()->where('deleted_at', '<', now()->subDays(30)->endOfDay())->forceDelete();

            $files = AbydeDriveFile::onlyTrashed()->where('deleted_at', '<', now()->subDays(30)->endOfDay())->get();
            foreach ($files as $file) {
                $file_path = '/abyde_drive/'.$file->location_id.'/'.$file->file_name;
                if (Storage::disk('s3')->exists($file_path)) {
                    Storage::disk('s3')->delete($file_path);
                }
            }
            $files = AbydeDriveFile::onlyTrashed()->where('deleted_at', '<', now()->subDays(30)->endOfDay())->forceDelete();
        }catch (\Exception $e) {
            Log::error('AbydeDriveTrash/handle() => '.$e->getMessage());
        }

        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
