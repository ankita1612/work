<?php

namespace App\Console\Commands;

use App\Http\Controllers\App\GeneralController;
use App\Http\Controllers\App\HipaaLogController;
use App\Models\AbydeDriveArchiveFile;
use App\Models\AbydeDriveArchiveFolder;
use App\Models\AbydeDriveArchiveFolderLocation;
use App\Models\BreachLog;
use App\Models\CronExcecution;
use App\Models\Location;
use App\Traits\FileUpload;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class ArchiveBreachLog extends Command
{
    use FileUpload;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'archive:breachlog';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Archive current year breach log at end day of every year';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        try {
            $cron_excecution = CronExcecution::create([
                'name' => 'ArchiveBreachLog',
                'start' => now(),
            ]);

            $current_year = gmdate('Y');
            $locations = Location::with('user')
                ->whereHas('user', function($query){
                    $query->where('is_sra_user', 0);
                })->get();
            $abyde_drive_folder = AbydeDriveArchiveFolder::where('folder_name', 'Hipaa Logs')->first();
            $breach_log_folder = AbydeDriveArchiveFolder::updateOrCreate([
                'folder_name' => 'Breach Logs',
                'parent_folder_id' => $abyde_drive_folder->id,
            ]);
            $year_folder = AbydeDriveArchiveFolder::updateOrCreate([
                'folder_name' => $current_year,
                'parent_folder_id' => $breach_log_folder->id,
            ]);
            $breach_log_lists =
                BreachLog::with([
                    'location.state.breachDetail',
                    'location.hipaaComplianceOfficer',
                    'phiType.PhiTypeName',
                    'incidentReport.incidentReporterType',
                    'raAttemptQuestions.question',
                    'raAttemptQuestions.answer',
                ])->whereYear('created_at', $current_year)->get();
            foreach ($locations as $l_key => $location) {
                try{
                    $breach_log_list = $breach_log_lists->where('location_id', $location->id);
                    if (count($breach_log_list) > 0) {
                        $year_folder_location = AbydeDriveArchiveFolderLocation::updateOrCreate([
                            'archive_folder_id' => $year_folder->id,
                            'location_id' => $location->id,
                        ]);
                        $breach_log_folder_location = AbydeDriveArchiveFolderLocation::updateOrCreate([
                            'archive_folder_id' => $breach_log_folder->id,
                            'location_id' => $location->id,
                        ]);
                        $public_path = public_path();
                        $storage_path = storage_path('app/public');
                        foreach ($breach_log_list as $w_key => $breach_log) {
                            try{
                                $breach_log_controller = new HipaaLogController;
                                if (count($breach_log->raAttemptQuestions) > 0) {
                                    // breach log with RA completed
                                    $policy_filename = 'BreachLogReportRA.docx';
                                    $policy_file_path = $public_path.'/policydocuments/'.$policy_filename;
                                    $generated_policy_directory_path = $storage_path.'/generatedpolicydocuments/';
                                    $gnerated_policy_doc_name = $breach_log->id.'_'.$policy_filename;
                                    $gnerated_policy_pdf_name = str_replace('docx', 'pdf', $gnerated_policy_doc_name);
                                    $gnerated_policy_file_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_policy_doc_name;
                                    $gnerated_policy_pdf_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_policy_pdf_name;

                                    $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($policy_file_path);
                                    $generalController = new GeneralController;
                                    $logo_data = $generalController->_addCompanyLogoOnCoverPage($breach_log->location);
                                    $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
                                    $generalController->_removeTempCompanyLogo($breach_log->location, $logo_data['temp_file_path']);
                                    $template_processor->setValue('COMPANY_NAME', htmlspecialchars($breach_log->location->company_name));
                                    $template_processor->setValue('LAST_MODIFIED_DATE', date('F j, Y', strtotime($breach_log->updated_at)));
                                    if ($breach_log->type_of_incident == 'hacking_it_incident') {
                                        $type_of_incident = 'Hacking/IT';
                                    }
                                    if ($breach_log->type_of_incident == 'improper_disposal') {
                                        $type_of_incident = 'Improper Disposal';
                                    }
                                    if ($breach_log->type_of_incident == 'loss') {
                                        $type_of_incident = 'Loss of PHI';
                                    }
                                    if ($breach_log->type_of_incident == 'theft') {
                                        $type_of_incident = 'Theft of PHI';
                                    }
                                    if ($breach_log->type_of_incident == 'unauthorized_access') {
                                        $type_of_incident = 'Unauthorized Access/Disclosure';
                                    }
                                    $template_processor->setValue('BREACH_TYPE', htmlspecialchars($type_of_incident));
                                    $template_processor->setValue('BREACH_DATE', date('F j, Y', strtotime($breach_log->breach_start_date)));
                                    $template_processor->setValue('CLIENT_NAME', htmlspecialchars($breach_log->location->company_name));
                                    $template_processor->setValue('CLIENT_ADDRESS', htmlspecialchars($breach_log->location->address));
                                    $template_processor->setValue('CLIENT_PHONE_NUMBER', $breach_log->location->phone_no);
                                    $template_processor->setValue('CLIENT_CITY', htmlspecialchars($breach_log->location->city));
                                    $template_processor->setValue('CLIENT_STATE', htmlspecialchars($breach_log->location->state->state_name));
                                    $template_processor->setValue('CLIENT_ZIP', $breach_log->location->zip_code);
                                    $template_processor->setValue('BREACH_REPORTER', htmlspecialchars($breach_log->incident_reporter_name));
                                    $BN2_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN2S1', $breach_log->raAttemptQuestions);
                                    if ($BN2_RESPONSE == '') {
                                        $BN2_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN2S2', $breach_log->raAttemptQuestions);
                                    }
                                    $template_processor->setValue('BN2_RESPONSE', htmlspecialchars(lcfirst($BN2_RESPONSE->answer->answer)));
                                    $template_processor->setValue('BREACH_DISCOVERY', htmlspecialchars($breach_log->discovered_by));
                                    $template_processor->setValue('HCO_NAME', htmlspecialchars($breach_log->location->hipaaComplianceOfficer->hco->first_name.' '.$breach_log->location->hipaaComplianceOfficer->hco->last_name));
                                    $template_processor->setValue('HCO_EMAIL', htmlspecialchars($breach_log->location->hipaaComplianceOfficer->hco->email));
                                    $template_processor->setValue('HCO_PHONE_NUMBER', $breach_log->location->phone_no);
                                    $BN1S2_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN1S2', $breach_log->raAttemptQuestions);
                                    if ($BN1S2_RESPONSE) {
                                        if ($BN1S2_RESPONSE->custom_answer == 'Other') {
                                            $BN1S2S1_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN1S2S1', $breach_log->raAttemptQuestions);
                                            $BN1S2S2_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN1S2S2', $breach_log->raAttemptQuestions);
                                            $BN1S2S3_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN1S2S3', $breach_log->raAttemptQuestions);
                                            $BN1S2S4_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN1S2S4', $breach_log->raAttemptQuestions);
                                            $template_processor->setValue('BN1_A2_RESPONSE_TITLE', 'THIRD PARTY BUSINESS CONTACT INFORMATION</w:t><w:br/><w:t>');
                                            $template_processor->setValue('BN1_A2_RESPONSE_LIST1', '
                </w:t><w:br/><w:t>As this breach occurred at or by '.htmlspecialchars($BN1S2S1_RESPONSE->custom_answer).' and '.htmlspecialchars($breach_log->location->company_name).' is filing this breach on behalf of '.htmlspecialchars($BN1S2S1_RESPONSE->custom_answer).'. '.htmlspecialchars($BN1S2S1_RESPONSE->custom_answer)."'s contact information is listed below:</w:t><w:br/><w:t></w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●   Name of Business Associate: ".htmlspecialchars($BN1S2S1_RESPONSE->custom_answer).'</w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●   Address:</w:t><w:br/><w:t>
                </w:t><w:tab/><w:t></w:t><w:br/><w:t></w:t><w:tab/><w:t>'.htmlspecialchars($BN1S2S2_RESPONSE->custom_answer).'

                ');
                                            $template_processor->setValue(
                                                'BN1_A2_RESPONSE_LIST2',
                                                '</w:t><w:br/><w:t></w:t><w:br/><w:t>'.
                                                    htmlspecialchars($BN1S2S1_RESPONSE->custom_answer)."'s contact information is listed below:</w:t><w:br/><w:t></w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●   Name: ".htmlspecialchars($BN1S2S3_RESPONSE->custom_answer).'</w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●   Email: '.htmlspecialchars($BN1S2S4_RESPONSE->custom_answer).'</w:t><w:br/><w:t>'
                                            );
                                        } else {
                                            $BA_DATA = $breach_log_controller->_getBAData($BN1S2_RESPONSE->custom_answer);
                                            if (empty($BA_DATA)) {
                                                $BA_DATA['name'] = '';
                                                $BA_DATA['email'] = '';
                                            }

                                            $template_processor->setValue('BN1_A2_RESPONSE_TITLE', 'THIRD PARTY BUSINESS CONTACT INFORMATION</w:t><w:br/><w:t>');
                                            $template_processor->setValue('BN1_A2_RESPONSE_LIST1', '
                </w:t><w:br/><w:t>As this breach occurred at or by '.htmlspecialchars($BA_DATA['name']).' and '.htmlspecialchars($breach_log->location->company_name).' is filing this breach on behalf of '.htmlspecialchars($BA_DATA['name']).'. '.htmlspecialchars($BA_DATA['name'])."'s contact information is listed below:</w:t><w:br/><w:t></w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●   Name of Business Associate: ".htmlspecialchars($BA_DATA['name']).'</w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●   Address:</w:t><w:br/><w:t>
                </w:t><w:br/><w:t></w:t><w:br/><w:t></w:t><w:tab/><w:t>'.htmlspecialchars(($BA_DATA['name'] != '') ? $breach_log->location->address : '').'

                ');
                                            $template_processor->setValue(
                                                'BN1_A2_RESPONSE_LIST2',
                                                '</w:t><w:br/><w:t></w:t><w:br/><w:t>'.
                                                    htmlspecialchars($BA_DATA['name'])."'s contact information is listed below:</w:t><w:br/><w:t></w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●   Name: ".htmlspecialchars($BA_DATA['name']).'</w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●   Email: '.htmlspecialchars($BA_DATA['email']).'</w:t><w:br/><w:t>'
                                            );
                                        }
                                    } else {
                                        $template_processor->setValue('BN1_A2_RESPONSE_TITLE', '');
                                        $template_processor->setValue('BN1_A2_RESPONSE_LIST1', '');
                                        $template_processor->setValue('BN1_A2_RESPONSE_LIST2', '');
                                    }
                                    if ($breach_log->individuals_affected == 'less_than_500') {
                                        $individuals_affected = 'less than 500 individuals';
                                    }
                                    if ($breach_log->individuals_affected == '500_or_more_than_500') {
                                        $individuals_affected = '500 or more individuals';
                                    }
                                    $template_processor->setValue('INDIVIDUALS', htmlspecialchars($individuals_affected));
                                    $BN4_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN4', $breach_log->raAttemptQuestions);
                                    $template_processor->setValue('BN4_RESPONSE', htmlspecialchars($BN4_RESPONSE->custom_answer));
                                    $BN3_answers = $breach_log_controller->_getAttemptDataFromQuestionCode('BN3', $breach_log->raAttemptQuestions, 'all');
                                    $BN3_answers_array = [];
                                    foreach ($BN3_answers as $key => $value) {
                                        $BN3_answers_array[] = $value->answer->answer;
                                    }
                                    if (in_array('Other', $BN3_answers_array)) {
                                        if (($key = array_search('Other', $BN3_answers_array)) !== false) {
                                            unset($BN3_answers_array[$key]);
                                        }
                                        $BN3S1_answer = $breach_log_controller->_getAttemptDataFromQuestionCode('BN3S1', $breach_log->raAttemptQuestions);
                                        $BN3_answers_array[] = $BN3S1_answer->custom_answer;
                                    }
                                    $BN3_RESPONSE = implode(', ', $BN3_answers_array);
                                    $template_processor->setValue('BN3_RESPONSE', htmlspecialchars($BN3_RESPONSE));
                                    $template_processor->setValue('BREACH_START', date('F j, Y', strtotime($breach_log->breach_start_date)));
                                    $template_processor->setValue('BREACH_END', date('F j, Y', strtotime($breach_log->breach_end_date)));
                                    $template_processor->setValue('DISCOVERY_START', date('F j, Y', strtotime($breach_log->discovered_start_date)));
                                    $template_processor->setValue('DISCOVERY_END', date('F j, Y', strtotime($breach_log->discovered_end_date)));
                                    $phis_array = [];
                                    $PHI_OTHER_TEXT = '';
                                    foreach ($breach_log->phiType as $key => $value) {
                                        if ($value->phiTypeName->name == 'Other') {
                                            $PHI_OTHER_TEXT = '</w:t><w:br/><w:t>
                Other types of Protected Health Information included or potentially included: '.htmlspecialchars($value->other_details);
                                        } else {
                                            $phis_array[] = $value->phiTypeName->name;
                                        }
                                    }
                                    if (in_array('Other', $phis_array)) {
                                        if (($key = array_search('Other', $phis_array)) !== false) {
                                            unset($phis_array[$key]);
                                        }
                                    }
                                    $PHI_LIST = '';
                                    foreach ($phis_array as $key => $value) {
                                        $PHI_LIST .= '</w:t><w:tab/><w:t>●  '.ucfirst($value).'</w:t><w:br/><w:t>';
                                    }
                                    $template_processor->setValue('PHI', $PHI_LIST);
                                    $template_processor->setValue('PHI_OTHER_TEXT', $PHI_OTHER_TEXT);
                                    $BN5_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN5', $breach_log->raAttemptQuestions);
                                    $template_processor->setValue('BN5_RESPONSE', htmlspecialchars($BN5_RESPONSE->custom_answer));
                                    $BN8S1_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN8S1', $breach_log->raAttemptQuestions);
                                    if ($BN8S1_RESPONSE) {
                                        $BN8S3_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN8S3', $breach_log->raAttemptQuestions);
                                        if ($BN8S3_RESPONSE->answer->answer_code == 'A1') {
                                            $BN8S3 = 'required for fewer than 10 individuals.';
                                        } elseif ($BN8S3_RESPONSE->answer->answer_code == 'A2') {
                                            $BN8S3 = 'required for more than 10 individuals.';
                                        } else {
                                            $BN8S3 = 'not required.';
                                        }
                                        $BN8S4_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN8S4', $breach_log->raAttemptQuestions);
                                        if ($BN8S4_RESPONSE->answer->answer_code == 'A1') {
                                            $BN8S4S1_answers = $breach_log_controller->_getAttemptDataFromQuestionCode('BN8S4S1', $breach_log->raAttemptQuestions, 'all');
                                            $state_array = [];
                                            foreach ($BN8S4S1_answers as $key => $value) {
                                                $state_array[] = $breach_log_controller->_getStateName($value->custom_answer);
                                            }
                                            sort($state_array);
                                            $BN8S4 = 'required for '.implode(', ', $state_array).'.';
                                        } else {
                                            $BN8S4 = 'not required for this breach.';
                                        }
                                        $BN8_RESPONSE = '</w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●  Individual notice to affected individuals was provided on '.date('m/d/Y', strtotime($BN8S1_RESPONSE->custom_answer)).'</w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●  Substitute notice was '.$BN8S3.'</w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●  Media notice was '.$BN8S4;
                                    } else {
                                        $BN8S2_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN8S2', $breach_log->raAttemptQuestions);
                                        $BN8_RESPONSE = '</w:t><w:br/><w:t>
                </w:t><w:tab/><w:t>●  Individual notice to affected individuals will be provided starting on '.date('m/d/Y', strtotime($BN8S2_RESPONSE->custom_answer)).' (projected).';
                                    }
                                    $template_processor->setValue('BN8_RESPONSE', $BN8_RESPONSE);
                                    $BN6_RESPONSE = $breach_log_controller->_getAttemptDataFromQuestionCode('BN6', $breach_log->raAttemptQuestions);
                                    $template_processor->setValue('BREACH_RISK', htmlspecialchars($BN6_RESPONSE->answer->answer));
                                    $BN6_RESPONSE_TEXT = '';
                                    if ($BN6_RESPONSE->answer->answer_code == 'A4') {
                                        $BN6_RESPONSE_TEXT = '';
                                    } elseif ($BN6_RESPONSE->answer->answer_code == 'A1') {
                                        $BN6_RESPONSE_TEXT = $breach_log->location->company_name.' has also determined that the exposed PHI has been retrieved and/or deleted.';
                                    } elseif ($BN6_RESPONSE->answer->answer_code == 'A2') {
                                        $BN6_RESPONSE_TEXT = $breach_log->location->company_name.' has also determined that the exposed PHI has not been retrieved and/or deleted.';
                                    } else {
                                        $BN6_RESPONSE_TEXT = $breach_log->location->company_name.' has also determined that the exposed PHI is currently in the process of being retrieved and/or deleted.';
                                    }
                                    $template_processor->setValue('BN6_RESPONSE', htmlspecialchars($BN6_RESPONSE_TEXT));
                                    $BN9_RESPONSE = '</w:t><w:tab/><w:t>●  Complete an incident risk assessment</w:t><w:br/><w:t>';
                                    $BN9_answers = $breach_log_controller->_getAttemptDataFromQuestionCode('BN9', $breach_log->raAttemptQuestions, 'all');
                                    $BN9_answers_array = [];
                                    foreach ($BN9_answers as $key => $value) {
                                        $BN9_answers_array[] = $value->answer->answer;
                                    }
                                    if (in_array('Other', $BN9_answers_array)) {
                                        if (($key = array_search('Other', $BN9_answers_array)) !== false) {
                                            unset($BN9_answers_array[$key]);
                                        }
                                    }
                                    foreach ($BN9_answers_array as $key => $value) {
                                        $BN9_RESPONSE .= '
                </w:t><w:tab/><w:t>●  '.$value.'</w:t><w:br/><w:t>';
                                    }
                                    $template_processor->setValue('BN9_RESPONSE', $BN9_RESPONSE);
                                    $BN9S1_answers = $breach_log_controller->_getAttemptDataFromQuestionCode('BN9S1', $breach_log->raAttemptQuestions);
                                    if ($BN9S1_answers) {
                                        $template_processor->setValue('BREACH_RESPONSE_ADDITIONAL', '
                </w:t><w:br/><w:t>Other responses include: '.htmlspecialchars($BN9S1_answers->custom_answer));
                                    } else {
                                        $template_processor->setValue('BREACH_RESPONSE_ADDITIONAL', '');
                                    }
                                    $PREVIOUSLY_REPORTED = '';
                                    foreach ($breach_log->incidentReport as $key => $value) {
                                        if ($value->incidentReporterType->name == 'None') {
                                            $PREVIOUSLY_REPORTED = 'not yet reported the breach';
                                        } elseif ($value->incidentReporterType->name == 'Office for Civil Rights') {
                                            $PREVIOUSLY_REPORTED .= 'already reported the breach to the Office for Civil Rights on '.date('F j, Y', strtotime($value->incident_date));
                                        } elseif ($value->incidentReporterType->name == 'Affected Individuals') {
                                            if ($PREVIOUSLY_REPORTED != '') {
                                                $PREVIOUSLY_REPORTED .= ' and ';
                                            }
                                            $PREVIOUSLY_REPORTED .= 'already reported the breach to the Affected Individuals on '.date('F j, Y', strtotime($value->incident_date));
                                        } elseif ($value->incidentReporterType->name == 'Abyde') {
                                            if ($PREVIOUSLY_REPORTED != '') {
                                                $PREVIOUSLY_REPORTED .= ' and ';
                                            }
                                            $PREVIOUSLY_REPORTED .= 'already reported the breach to the Abyde team on '.date('F j, Y', strtotime($value->incident_date));
                                        }
                                    }
                                    $template_processor->setValue('PREVIOUSLY_REPORTED', htmlspecialchars($PREVIOUSLY_REPORTED));
                                    if ($breach_log->individuals_affected == 'less_than_500') {
                                        $FILING_TIMEFRAME = 'on an annual basis and within 60 calendar days of the end of the current year';
                                    }
                                    if ($breach_log->individuals_affected == '500_or_more_than_500') {
                                        $FILING_TIMEFRAME = 'without unreasonable delay and in no case later than '.$breach_log->location->state->breachDetail->breach_time.' following a breach';
                                    }
                                    $template_processor->setValue('FILING_TIMEFRAME', htmlspecialchars($FILING_TIMEFRAME));
                                } else {
                                    // breach log without RA completed
                                    $policy_filename = 'BreachLogReport.docx';
                                    $policy_file_path = $public_path.'/policydocuments/'.$policy_filename;
                                    $generated_policy_directory_path = $storage_path.'/generatedpolicydocuments/';
                                    $gnerated_policy_doc_name = $breach_log->id.'_'.$policy_filename;
                                    $gnerated_policy_pdf_name = str_replace('docx', 'pdf', $gnerated_policy_doc_name);
                                    $gnerated_policy_file_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_policy_doc_name;
                                    $gnerated_policy_pdf_path = $storage_path.'/generatedpolicydocuments/'.$gnerated_policy_pdf_name;

                                    $template_processor = new \PhpOffice\PhpWord\TemplateProcessor($policy_file_path);
                                    $generalController = new GeneralController;
                                    $logo_data = $generalController->_addCompanyLogoOnCoverPage($breach_log->location);
                                    $template_processor->setImageValue('COMPANY_LOGO', $logo_data['company_logo_data']);
                                    $generalController->_removeTempCompanyLogo($breach_log->location, $logo_data['temp_file_path']);
                                    $template_processor->setValue('COMPANY_NAME', htmlspecialchars($breach_log->location->company_name));
                                    $template_processor->setValue('LAST_MODIFIED_DATE', date('F j, Y', strtotime($breach_log->updated_at)));
                                    $template_processor->setValue('BREACH_DATE', date('F j, Y', strtotime($breach_log->breach_start_date)));
                                    $template_processor->setValue('CLIENT_NAME', htmlspecialchars($breach_log->location->company_name));
                                    $template_processor->setValue('CLIENT_ADDRESS', htmlspecialchars($breach_log->location->address));
                                    $template_processor->setValue('CLIENT_PHONE_NUMBER', $breach_log->location->phone_no);
                                    $template_processor->setValue('CLIENT_CITY', htmlspecialchars($breach_log->location->city));
                                    $template_processor->setValue('CLIENT_STATE', htmlspecialchars($breach_log->location->state->state_name));
                                    $template_processor->setValue('CLIENT_ZIP', $breach_log->location->zip_code);
                                    $template_processor->setValue('BREACH_START', date('F j, Y', strtotime($breach_log->breach_start_date)));
                                    $template_processor->setValue('BREACH_END', date('F j, Y', strtotime($breach_log->breach_end_date)));
                                    $template_processor->setValue('BREACH_REPORTER', htmlspecialchars($breach_log->incident_reporter_name));
                                    $template_processor->setValue('HCO_NAME', htmlspecialchars($breach_log->location->hipaaComplianceOfficer->hco->first_name.' '.$breach_log->location->hipaaComplianceOfficer->hco->last_name));
                                    $template_processor->setValue('HCO_EMAIL', htmlspecialchars($breach_log->location->hipaaComplianceOfficer->hco->email));
                                    $template_processor->setValue('HCO_PHONE_NUMBER', $breach_log->location->phone_no);
                                    if ($breach_log->type_of_incident == 'hacking_it_incident') {
                                        $type_of_incident = 'Hacking/IT';
                                    }
                                    if ($breach_log->type_of_incident == 'improper_disposal') {
                                        $type_of_incident = 'Improper Disposal';
                                    }
                                    if ($breach_log->type_of_incident == 'loss') {
                                        $type_of_incident = 'Loss of PHI';
                                    }
                                    if ($breach_log->type_of_incident == 'theft') {
                                        $type_of_incident = 'Theft of PHI';
                                    }
                                    if ($breach_log->type_of_incident == 'unauthorized_access') {
                                        $type_of_incident = 'Unauthorized Access/Disclosure';
                                    }
                                    $template_processor->setValue('BREACH_TYPE', htmlspecialchars($type_of_incident));
                                    $template_processor->setValue('BREACH_DISCOVERY', htmlspecialchars($breach_log->discovered_by));
                                    if ($breach_log->individuals_affected == 'less_than_500') {
                                        $individuals_affected = 'less than 500 individuals';
                                    }
                                    if ($breach_log->individuals_affected == '500_or_more_than_500') {
                                        $individuals_affected = '500 or more individuals';
                                    }
                                    $template_processor->setValue('INDIVIDUALS', htmlspecialchars($individuals_affected));
                                    $type_of_phis = [];
                                    foreach ($breach_log->phiType as $key => $value) {
                                        if ($value->phiTypeName->name == 'Other') {
                                            $type_of_phis[] = $value->other_details;
                                        } else {
                                            $type_of_phis[] = $value->phiTypeName->name;
                                        }
                                    }
                                    $template_processor->setValue('PHI', implode(', ', array_map('ucfirst', $type_of_phis)));
                                    $template_processor->setValue('DISCOVERY_START', date('F j, Y', strtotime($breach_log->discovered_start_date)));
                                    $template_processor->setValue('DISCOVERY_END', date('F j, Y', strtotime($breach_log->discovered_end_date)));
                                    $PREVIOUSLY_REPORTED = '';
                                    foreach ($breach_log->incidentReport as $key => $value) {
                                        if ($value->incidentReporterType->name == 'None') {
                                            $PREVIOUSLY_REPORTED = 'not yet reported the breach';
                                        } elseif ($value->incidentReporterType->name == 'Office for Civil Rights') {
                                            $PREVIOUSLY_REPORTED .= 'already reported the breach to the Office for Civil Rights on '.date('F j, Y', strtotime($value->incident_date));
                                        } elseif ($value->incidentReporterType->name == 'Affected Individuals') {
                                            if ($PREVIOUSLY_REPORTED != '') {
                                                $PREVIOUSLY_REPORTED .= ' and ';
                                            }
                                            $PREVIOUSLY_REPORTED .= 'already reported the breach to the Affected Individuals on '.date('F j, Y', strtotime($value->incident_date));
                                        } elseif ($value->incidentReporterType->name == 'Abyde') {
                                            if ($PREVIOUSLY_REPORTED != '') {
                                                $PREVIOUSLY_REPORTED .= ' and ';
                                            }
                                            $PREVIOUSLY_REPORTED .= 'already reported the breach to the Abyde team on '.date('F j, Y', strtotime($value->incident_date));
                                        }
                                    }
                                    $template_processor->setValue('PREVIOUSLY_REPORTED', htmlspecialchars($PREVIOUSLY_REPORTED));
                                    if ($breach_log->individuals_affected == 'less_than_500') {
                                        $FILING_TIMEFRAME = 'on an annual basis and within 60 calendar days of the end of the current year';
                                    }
                                    if ($breach_log->individuals_affected == '500_or_more_than_500') {
                                        $FILING_TIMEFRAME = 'without unreasonable delay and in no case later than '.$breach_log->location->state->breachDetail->breach_time.' following a breach';
                                    }
                                    $template_processor->setValue('FILING_TIMEFRAME', htmlspecialchars($FILING_TIMEFRAME));
                                }

                                $template_processor->saveAs($gnerated_policy_file_path);
                                // if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                                // change libreoffice path as per installation path from your machine
                                // exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  ' . $generated_policy_directory_path . ' ' . $gnerated_policy_file_path);
                                // } else {
                                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir '.$generated_policy_directory_path.' '.$gnerated_policy_file_path);
                                // }

                                $file_name = '/abyde_drive_archive/breach_logs/'.$breach_log['location_id'].'/'.$breach_log['id'].'_'.date('m_d_Y', strtotime($breach_log->created_at)).'_'.$breach_log->location->location_nickname.'_Breach_Log_Report.pdf';
                                $is_uploaded = Storage::disk('s3')->put($file_name, file_get_contents($gnerated_policy_pdf_path));
                                if ($is_uploaded) {
                                    $file_title = $breach_log['id'].'_'.date('m_d_Y', strtotime($breach_log->created_at)).'_'.$breach_log->location->location_nickname.'_Breach_Log_Report';
                                    $file_size = $this->getReadableFilesize(Storage::disk('s3')->size($file_name));
                                    $file_data = [
                                        'file_name' => $file_title.'.pdf',
                                        'title' => $file_title,
                                        'archive_folder_id' => $year_folder_location->id,
                                        'file_size' => $file_size,
                                    ];
                                    AbydeDriveArchiveFile::create($file_data);
                                }
                            }catch (\Exception $e) {
                                Log::error('ArchiveBreachLog/handle()[breach_log_error] => '.$e->getMessage());
                                Log::error('ArchiveBreachLog/handle()[breach_log_data] => '.json_encode($breach_log));
                            }  
                        }
                    }
                }catch (\Exception $e) {
                    Log::error('ArchiveBreachLog/handle()[locations_error] => '.$e->getMessage());
                    Log::error('ArchiveBreachLog/handle()[locations_data] => '.json_encode($location));
                }   
            }
            $cron_excecution->update([
                'end' => now(),
            ]);
        } catch (\Exception $e) {
            Log::error('ArchiveBreachLog : CronJob'.$e->getMessage());
        }
    }
}
