<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\User;
use Carbon\Carbon;
use App\Traits\ChargebeePlan;
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Models\Subscription;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class CheckLocationLimit extends Command
{
    use ChargebeePlan;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'check-location-limit';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Check location limit in chargebee';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'CheckLocationLimit',
            'start' => now(),
        ]);        
            $users = User::where('chargebee_subscription_id', '!=', '')
                ->where('is_active', 1)
                ->withCount('locations')
                ->get();
            Environment::configure(Config::get('app.chargebee_site'),Config::get('app.chargebee_api_key'));
            foreach($users as $user){
                try{
                    $subscription_response = Subscription::retrieve($user->chargebee_subscription_id);
                    $subscription = $subscription_response->subscription();
                    if($subscription->status == 'active'){
                        $location_limit = 0;
                        foreach($subscription->subscriptionItems as $subscriptionItems){
                            if($subscriptionItems->itemType == 'addon' && str_contains($subscriptionItems->itemPriceId, 'Locations')){
                                $location_limit = $subscriptionItems->quantity;
                            }
                            else if($subscriptionItems->itemType == 'plan' && str_contains($subscriptionItems->itemPriceId, 'SRA-ONLY')){
                                $location_limit = $subscriptionItems->quantity;
                            }
                        }
                        if ($location_limit > 0 && $user->locations_count > $location_limit) {
                            Log::info("Exceeding location limit: " .$user->id);
                            $this->info("Exceeding location limit: " . $user->id);
                        }
                    }
                } catch (\Exception $e) {
                    Log::error("CheckLocationLimit : location limit check for user id:" . $user->id);
                    Log::error('CheckLocationLimit/handle() => '.$e->getMessage());
                }
            }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}