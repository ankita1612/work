<?php

namespace App\Console\Commands;

use App\Http\Controllers\App\SecurityRiskAnalysisController;
use App\Models\Location;
use App\Models\RiskAnalysisAttemptedQuestion;
use App\Models\RiskAnalysisAttemptedQuestionAnswer;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CopyRAToLocation extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */

    // Command to be run: php artisan copy:ra {from_location_id} {to_location_id}
    protected $signature = 'copy:ra {from_location_id} {to_location_id}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This script is used copy RA of source location to specified location';
    private $SRAController;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(SecurityRiskAnalysisController $SRAController)
    {
        parent::__construct();
        $this->SRAController = $SRAController;
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        try {
            if ($this->argument('to_location_id')) {
                
                $sourceLocation = Location::where([
                    'id' => (int) $this->argument('from_location_id'),
                ])
                ->has('sraModuleCompleted')
                ->first();
                if (empty($sourceLocation)) {
                    $this->error('SRA not completed for source location '.$this->argument('from_location_id'));
                    return;
                }

                $location = Location::where([
                    'id' => (int) $this->argument('to_location_id'),
                    'user_id' => $sourceLocation->user_id
                ])
                ->has('companyModuleCompleted')
                ->doesntHave('sraModuleCompleted')
                ->first();
                if (empty($location)) {
                    $this->error('Location not found or location is not eligible for copy RA');
                    return;
                }
                DB::beginTransaction();

                //Delete if any existing answers are given for the location
                RiskAnalysisAttemptedQuestion::with('attemptedQuestionAnswer')
                ->where('location_id', $location->id)
                ->get()
                ->each(function ($ra) {
                    $ra->attemptedQuestionAnswer()->delete();
                    $ra->delete();
                });

                //Copy RA questions and answers from source location to destination location
                $sourceRAQuestions = RiskAnalysisAttemptedQuestion::with('attemptedQuestionAnswer')
                ->where('location_id',  $this->argument('from_location_id'))
                ->get();

                foreach ($sourceRAQuestions as $sourceQuestion) {
                    $answer_id_array = [];
                    foreach($sourceQuestion->attemptedQuestionAnswer as $sourceAnswer){
                        $answer = $sourceAnswer->answer;
                        $answer_id_array[] = $sourceAnswer->answer_id;
                    }
                    $request = new Request([
                        'answer_id' => (array) $answer_id_array,
                        'answer' => $answer,
                        'note' => $sourceQuestion->note,
                        'is_ans_same' => false,
                        'question_id' => $sourceQuestion->question_id,
                        'location_id' => $location->id
                    ]);
                    ($this->SRAController)->saveAnswer($request);
                }

                //Complete RA for the location
                $request = new Request(['location_id' => $location->id]);
                ($this->SRAController)->completeRA($request);
                DB::commit();
                $this->info('SRA copied from location '.$this->argument('from_location_id').' to location '.$location->id);

            }
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('CopyRAToLocation/handle() => '.$e->getMessage());
            Log::error('CopyRAToLocation/handle()[from_location_id] => '.json_encode(['from_location_id' => $this->argument('from_location_id')]));
        }
    }
}
