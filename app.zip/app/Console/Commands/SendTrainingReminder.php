<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\HipaaComplianceOfficer;
use App\Models\Setting;
use App\Models\TrainingLocation;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class SendTrainingReminder extends Command
{
    use SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send:trainingremindermail';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send training reminder email before one month';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'SendTrainingReminder',
            'start' => now(),
        ]);
        try {
            $pause_user = Setting::where('functionality', 'training_pause')->pluck('user_id');
            $after_one_month = Carbon::today()->addMonth()->format('Y-m-d');
            $training_location_list = TrainingLocation::where('schedule_date', $after_one_month)
                ->with(['training' => function ($query) {
                    $query->whereIn('who_can_train', ['hco', 'employee']);
                },
                    'location' => function ($query) use ($pause_user) {
                        $query->whereNotIn('user_id', $pause_user);
                    }, 'location.sraModuleCompleted', 'location.hipaaComplianceOfficer', 'location.employeePrimaryWorkLocation'])
                ->with('training.childTraining')
                ->where('is_triggered', 0)
                ->where('is_disable', 0)
                ->whereHas('training', function ($query) {
                    $query->whereIn('who_can_train', ['hco', 'employee'])->whereNull('parent_training_id');
                })
                ->whereHas('location', function ($query) use ($pause_user) {
                    $query->whereNotIn('user_id', $pause_user);
                })
                ->get();
            if (! empty($training_location_list)) {
                $delayTime = Carbon::today()->format('Y-m-d') .' '. Config::get('app.send_email_delay_time');
                foreach ($training_location_list as $training_location) {
                    try{
                        if ($training_location->location->sraModuleCompleted != null && $training_location->location->hipaaComplianceOfficer != null && count($training_location->location->employeePrimaryWorkLocation) > 0) {
                            if ($training_location->reminder_email_date == null || (Carbon::today()->gt(Carbon::parse($training_location->reminder_email_date)->addMonth()))) {
                                $check_user_email_pause = Setting::where('user_id', $training_location->location['user']['id'])->where('functionality', 'training_email_pause')->count();
                                if ($check_user_email_pause == 0) {
                                    // send HCE-UE55 and HCE-UE56
                                    $training_title = (! empty($training_location->training->childTraining) && count($training_location->training->childTraining) > 0 ? substr($training_location->training->title, 0, strlen($training_location->training->title) - 1) : $training_location->training->title);

                                    $hco = HipaaComplianceOfficer::where('location_id', $training_location->location['id'])->with('hco')->first();
                                    $emailCode = ($training_location->training->who_can_train == 'hco') ? 'HCE-UE56' : 'HCE-UE55';
                                    $emailTemplate = EmailTemplate::where('code', $emailCode)->first();
                                    $email_vars = [
                                        '{%HCO_FIRST_NAME%}' => $hco->hco->first_name,
                                        '{%HCO_LAST_NAME%}' => $hco->hco->last_name,
                                        '{%LOG_IN_TO_ABYDE%}' => Config::get('app.url'),
                                        '{%HCO_EMAIL%}' => $hco->hco->email,
                                        '{%TRAINING_NAME%}' => $training_title,
                                        '{%TRAINING_DATE%}' => date('m/d/Y', strtotime($training_location->schedule_date)),
                                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                    ];
                                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                    if ($training_location->location['user']['account_status'] == 'Unfrozen' && $training_location->location['user']['is_active'] == '1' && $training_location->location['user']['is_account_verified'] == '1') {
                                        $this->sendEmail($emailTemplate->code, $html, $hco->hco->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($training_location->location['user']['partner_reseller_id'] != null ? $training_location->location['user']['reseller']['logo'] : null), $training_location->location['user']['id'], null, $delayTime);
                                        TrainingLocation::where('id', $training_location->id)->update([
                                            'reminder_email_date' => Carbon::today()->format('Y-m-d'),
                                        ]);
                                    }
                                }
                            }
                        }
                    } catch (\Exception $e) {
                        Log::error('SendTrainingReminder/handle()[training_location_error] => '.$e->getMessage());
                        Log::error('SendTrainingReminder/handle()[training_location_data] => '.json_encode($training_location));
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('SendTrainingReminder/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
