<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\Location;
use App\Models\Setting;
use App\Models\Training;
use App\Models\TrainingLocation;
use App\Models\User;
use App\Traits\Notification;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class AddTrainingToLocation extends Command
{
    use Notification, SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'add:trainingLocation';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'add training for locations';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'AddTrainingToLocation',
            'start' => now(),
        ]);
        try {
            $pause_user = Setting::where('functionality', 'training_pause')->pluck('user_id');
            $user_list = User::whereNotIn('id', $pause_user)
                ->where('is_sra_user', 0)
                ->whereRaw('DATE_SUB(DATE(contract_renewal_date), INTERVAL 2 MONTH) = CURDATE()')
                ->get();
            foreach ($user_list as $user) {
                try{
                    $nextRenewalDate = Carbon::parse($user->contract_renewal_date)->addYear()->endOfDay();
                    $location_list = Location::where('user_id', $user->id)
                        ->withCount('trainingLocation')
                        ->whereHas('hipaaComplianceOfficer')
                        ->whereHas('sraModuleCompleted')
                        ->get();
                    foreach ($location_list as $location) {
                        try{
                            if ($location->training_location_count > 0) {
                                $training_list = Training::select(['id', 'training_code', 'who_can_train', 'trigger_month'])
                                    ->whereIn('who_can_train', ['hco', 'employee'])
                                    ->whereNotIn('training_code', ['HT1', 'HT2'])
                                    ->whereDoesntHave('trainingLocation', function ($query) use ($location) {
                                        $query->where('location_id', $location->id);
                                    })
                                    ->isActive()
                                    ->get();
                                $temp_data = [];
                                foreach ($training_list as $training) {
                                    try{
                                        if ($training->trigger_month !== null) {
                                            $schedule_date = Carbon::parse($location->training_anchor_date)->addMonth($training->trigger_month)->endOfDay();
                                            if ($schedule_date->lte($nextRenewalDate)) {
                                                $check_training_is_already_open_for_location = TrainingLocation::where('location_id', '=', $location->id)->where('training_id', '=', $training->id)->count();
                                                if ($check_training_is_already_open_for_location == 0) {
                                                    $temp_data[] = [
                                                        'location_id' => $location->id,
                                                        'training_id' => $training->id,
                                                        'trigger_type' => 'auto',
                                                        'schedule_date' => $schedule_date->format('Y-m-d'),
                                                        'is_disable' => 1,
                                                        'created_at' => Carbon::now(),
                                                        'updated_at' => Carbon::now(),
                                                    ];
                                                }
                                            }
                                        }
                                    }catch (\Exception $e) {
                                        Log::error('AddTrainingToLocation/handle()[training_list_error] => '.$e->getMessage());
                                        Log::error('AddTrainingToLocation/handle()[training_list_data] => '.json_encode($training));
                                    }  
                                }
                                TrainingLocation::insert($temp_data);
                            }
                        } catch (\Exception $e) {
                            Log::error('AddTrainingToLocation/handle()[location_list_error] => '.$e->getMessage());
                            Log::error('AddTrainingToLocation/handle()[location_list_data] => '.json_encode($location));
                        }  
                    }
                }catch (\Exception $e) {
                    Log::error('AddTrainingToLocation/handle()[user_list_error] => '.$e->getMessage());
                    Log::error('AddTrainingToLocation/handle()[user_list_data] => '.json_encode($user));
                }
            }

        } catch (\Exception $e) {
            Log::error('AddTrainingToLocation/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
