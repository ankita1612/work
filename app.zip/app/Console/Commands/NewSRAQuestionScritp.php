<?php

namespace App\Console\Commands;

use App\Models\AccountUser;
use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Models\OngoingRiskAnalysisQuestion;
use App\Models\RiskAnalysisQuestion;
use App\Traits\Notification;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class NewSRAQuestionScritp extends Command
{
    use Notification, SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'addogquestion:newsraquestion';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'add new sra questions in OG for locations whose SRA is completed';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'NewSRAQuestionScritp',
            'start' => now(),
        ]);
        try {
            // new main question array in sequence
            $new_main_ques_arr = [];
            // get question details
            $questions = RiskAnalysisQuestion::whereIn('question_code', $new_main_ques_arr)->get();
            // get location which is completed sra
            $loctions = Location::with(['hipaaComplianceOfficer.hco', 'user.reseller'])->whereHas('sraModuleCompleted')->get();
            $send_email_email_id_array = [];
            foreach ($loctions as $loction) {
                try{
                    $i = 0;
                    foreach ($questions as $question) {
                        $temp_data = [
                            'question_id' => $question->id,
                            'location_id' => $loction->id,
                            'question_type' => 'normal',
                            'is_answered' => 0,
                            'added_date' => Carbon::now()->addSeconds($i)->format('Y-m-d H:i:s'),
                        ];
                        // add question in onging
                        OngoingRiskAnalysisQuestion::create($temp_data);
                        $i++;
                    }
                    if ($i > 0) {
                        // HCE-AN21 notifiction integration
                        $notification_HCE_AN21 = $this->getNotificationByCode('HCE-AN21');
                        $notification_HCE_AN21_data = [
                            'location_id' => $loction['id'],
                            'notification_id' => $notification_HCE_AN21['id'],
                        ];
                        $this->createNotification($notification_HCE_AN21_data);
                        if (! in_array($loction['hipaaComplianceOfficer']['hco']['email'], $send_email_email_id_array)) {
                            // send HCE-UE36
                            $emailTemplate = EmailTemplate::where('code', 'HCE-UE36')->first();
                            $email_vars = [
                                '{%FIRST_NAME%}' => $loction['hipaaComplianceOfficer']['hco']['first_name'],
                                '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                            ];
                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                            if (
                                $loction['user']['account_status'] == 'Unfrozen' && $loction['user']['is_active'] == '1' && $loction['user']['is_account_verified'] == '1'
                            ) {
                                $this->sendEmail($emailTemplate->code, $html, $loction['hipaaComplianceOfficer']['hco']['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($loction['user']['partner_reseller_id'] != null ? $loction['user']['reseller']['logo'] : null), $loction['user']['id']);
                            }
                            array_push($send_email_email_id_array, $loction['hipaaComplianceOfficer']['hco']['email']);
                        }
                        // get account user
                        $account_users = AccountUser::whereHas('accountLocationAccess', function ($query) use ($loction) {
                            $query->where('location_id', $loction['id']);
                        })->get();
                        foreach ($account_users as $account_user) {
                            if (! in_array($account_user['email'], $send_email_email_id_array)) {
                                // send HCE-UE36
                                $emailTemplate = EmailTemplate::where('code', 'HCE-UE36')->first();
                                $email_vars = [
                                    '{%FIRST_NAME%}' => $account_user['first_name'],
                                    '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                ];
                                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                if (
                                    $loction['user']['account_status'] == 'Unfrozen' && $loction['user']['is_active'] == '1' && $loction['user']['is_account_verified'] == '1'
                                ) {
                                    $this->sendEmail($emailTemplate->code, $html, $account_user['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($loction['user']['partner_reseller_id'] != null ? $loction['user']['reseller']['logo'] : null), $loction['user']['id']);
                                }
                                array_push($send_email_email_id_array, $account_user['email']);
                            }
                        }
                    }
                } catch (\Exception $e) {
                    Log::error('NewSRAQuestionScritp/handle()[location_error] => '.$e->getMessage());
                    Log::error('NewSRAQuestionScritp/handle()[location_data] => '.json_encode($loction));
                }
            }
        } catch (\Exception $e) {
            Log::error('NewSRAQuestionScritp/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
