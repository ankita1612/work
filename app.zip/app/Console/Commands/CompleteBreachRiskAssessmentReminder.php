<?php

namespace App\Console\Commands;

use App\Models\BreachLog;
use App\Models\CronExcecution;
use App\Traits\Notification;
use App\Traits\SendMail;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;

class CompleteBreachRiskAssessmentReminder extends Command
{
    use Notification, SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'complete_breach_risk_assessment_reminder:notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Notification will be send 3 days after the Breach Log submission if Breach RA has not yet been completed by that date';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'CompleteBreachRiskAssessmentReminder',
            'start' => now(),
        ]);
        try {
            $before_3_days = Carbon::today()->subDays(3)->format('Y-m-d');
            $breach_log_list = BreachLog::whereDate('created_at', $before_3_days)->WhereDoesntHave('raAttemptQuestions')->get();
            $notification_HCE_AN14 = $this->getNotificationByCode('HCE-AN14');

            foreach ($breach_log_list as $lst) {
                try{
                    $notification_data = [
                        'location_id' => $lst['location_id'],
                        'notification_id' => $notification_HCE_AN14['id'],
                        'other_details' => $lst['name'],
                    ];
                    $this->createNotification($notification_data);
                } catch (\Exception $e) {
                    Log::error('CompleteBreachRiskAssessmentReminder/handle()[breach_log_list_error] => '.$e->getMessage());
                    Log::error('CompleteBreachRiskAssessmentReminder/handle()[breach_log_list_data] => '.json_encode($lst));
                }
            }
        } catch (\Exception $e) {
            Log::error('CompleteBreachRiskAssessmentReminder/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
