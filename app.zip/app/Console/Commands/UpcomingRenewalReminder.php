<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Models\User;
use App\Traits\Notification;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class UpcomingRenewalReminder extends Command
{
    use Notification,SendMail;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'upcoming_renewal_reminder:notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Notification will be send before 60 days of renewal date upcoming_renewal_reminder:notification';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'UpcomingRenewalReminder',
            'start' => now(),
        ]);
        try {
             $user_list = User::with('reseller')
                ->whereRaw('DATE_SUB(DATE(contract_renewal_date), INTERVAL 60 DAY) = CURDATE()')
                ->get();
            $notification_HCE_AN20 = $this->getNotificationByCode('HCE-AN20');
            $emailTemplate_HCE_AE23 = EmailTemplate::where('code', 'HCE-AE23')->first();
            $delayTime = Carbon::today()->format('Y-m-d') .' '. Config::get('app.send_email_delay_time');
            foreach ($user_list as $user) {
                try{
                    $locations = Location::where('user_id', $user->id)->get();
                    foreach ($locations as $location) {
                        $notification_HCE_AN20_data = [
                            'location_id' => $location['id'],
                            'notification_id' => $notification_HCE_AN20['id'],
                            'other_details' => $user->contract_renewal_date,
                        ];
                        $this->createNotification($notification_HCE_AN20_data);
                    }
                    //send Mail to Reseller
                    if ($user->partner_reseller_id != null) {
                        $email_vars_admin = [
                            '{%CUSTOMER_NAME%}' => $user->first_name.' '.$user->last_name,
                            '{%RENEWAL_DATE%}' => $user->contract_renewal_date,
                            '{%ADMIN_PORTAL%}' => Config::get('app.url') . "/pkO0OA17otP61RwETtNn",
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email')
                        ];
                        $subject = str_ireplace(['{%RESELLER%}'], [$user->reseller->name], $emailTemplate_HCE_AE23->reseller_subject);
                        $html_admin = str_ireplace(array_keys($email_vars_admin), array_values($email_vars_admin), $emailTemplate_HCE_AE23->body);
                        $this->sendEmail($emailTemplate_HCE_AE23->code, $html_admin, $user->reseller->email, Config::get('app.from_admin_email'), $subject, null, null,true, ($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id, null, $delayTime);
                    }
                } catch (\Exception $e) {
                    Log::error('UpcomingRenewalReminder/handle()[user_error] => '.$e->getMessage());
                    Log::error('UpcomingRenewalReminder/handle()[user_data] => '.json_encode($user));
                }
            }
        } catch (\Exception $e) {
            Log::error('UpcomingRenewalReminder/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
