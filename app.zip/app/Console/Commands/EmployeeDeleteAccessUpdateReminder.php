<?php

namespace App\Console\Commands;

use App\Models\AccountUserLocationAccess;
use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\Employee;
use App\Models\EmployeeAccessRight;
use App\Models\EmployeeDeleteAccessUpdateTrack;
use App\Models\HipaaComplianceOfficer;
use App\Traits\Notification;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class EmployeeDeleteAccessUpdateReminder extends Command
{
    use Notification, SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'employee_delete_access_update_reminder:email_notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'When employee is deleted Email/Noti will be send after 3 days for access update reminder';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'EmployeeDeleteAccessUpdateReminder',
            'start' => now(),
        ]);
        try {
            $employees = Employee::onlyTrashed()->whereHas('employeeDeleteAccessUpdateTracks', function ($q) {
                $q->where('email_notification_sent', 0);
            })->with(['user', 'employeeSecondaryWorkLocation' => function ($e) {
                $e->onlyTrashed();
            }, 'user.reseller'])->get();
            $emailTemplate = EmailTemplate::where('code', 'HCE-UE46')->first();
            $notification_HCE_AN15 = $this->getNotificationByCode('HCE-AN15');
            $emp_email_name_list = [];
            $email_send_user_list = [];

            foreach ($employees as $emp) {
                try{
                    $emp_deleted_date = Carbon::parse($emp->deleted_at);
                    $today_date = Carbon::now();
                    $diff_in_days = $emp_deleted_date->diffInDays($today_date);
                    $logo = ! empty($emp->user->partner_reseller_id) ? $emp->user->reseller->logo : null;
                    if ($diff_in_days >= 3) {
                        $empAccessRightPrimary = EmployeeAccessRight::where(['location_id' => $emp->primary_work_location_id, 'employee_id' => $emp->id])->onlyTrashed()->first();

                        if ($empAccessRightPrimary) {
                            if ($emp->user->account_status == 'Unfrozen' && $emp->user->is_active == '1' && $emp->user->is_account_verified == '1') {
                                $emp_email_name_list[$emp->user_id][$emp->primary_work_location_id][] = $emp->first_name.' '.$emp->last_name;
                                $hco = HipaaComplianceOfficer::where('location_id', $emp->primary_work_location_id)->with('hco')->first();

                                $email_send_user_list[$emp->user_id][] = ['first_name' => $hco->hco->first_name, 'email' => $hco->hco->email, 'location_id' => $emp->primary_work_location_id, 'logo' => $logo];

                                $account_users_list = AccountUserLocationAccess::where('location_id', $emp->primary_work_location_id)->with('accountUser')->get();
                                foreach ($account_users_list as $key => $value) {
                                    if ($value->accountUser->email != $hco->hco->email) {
                                        $email_send_user_list[$emp->user_id][] = ['first_name' => $value->accountUser->first_name, 'email' => $value->accountUser->email, 'location_id' => $emp->primary_work_location_id, 'logo' => $logo];
                                    }
                                }
                            }
                            // add HCE-AN15
                            $notification_HCE_AN15_data = [
                                'location_id' => $emp->primary_work_location_id,
                                'notification_id' => $notification_HCE_AN15['id'],
                                'other_details' => $emp->first_name.' '.$emp->last_name,
                            ];
                            $this->createNotification($notification_HCE_AN15_data);
                        }

                        // generate HCE-AN15 for secondary location
                        foreach ($emp->employeeSecondaryWorkLocation as $second_location) {
                            try{
                                $empAccessRightSecondary = EmployeeAccessRight::where(['location_id' => $second_location->location_id, 'employee_id' => $emp->id])->onlyTrashed()->first();
                                if ($empAccessRightSecondary) {
                                    $notification_HCE_AN15_data = [
                                        'location_id' => $second_location->location_id,
                                        'notification_id' => $notification_HCE_AN15['id'],
                                        'other_details' => $emp->first_name.' '.$emp->last_name,
                                    ];
                                    $this->createNotification($notification_HCE_AN15_data);

                                    if ($emp->user->account_status == 'Unfrozen' && $emp->user->is_active == '1' && $emp->user->is_account_verified == '1') {

                                        $emp_email_name_list[$emp->user_id][$second_location->location_id][] = $emp->first_name.' '.$emp->last_name;
                                        $hco = HipaaComplianceOfficer::where('location_id', $second_location->location_id)->with('hco')->first();

                                        $email_send_user_list[$emp->user_id][] = ['first_name' => $hco->hco->first_name, 'email' => $hco->hco->email, 'location_id' => $second_location->location_id, 'logo' => $logo];

                                        $account_users_list = AccountUserLocationAccess::where('location_id', $second_location->location_id)->with('accountUser')->get();

                                        foreach ($account_users_list as $key => $value) {
                                            if ($value->accountUser->email != $hco->hco->email) {
                                                $email_send_user_list[$emp->user_id][] = ['first_name' => $value->accountUser->first_name, 'email' => $value->accountUser->email, 'location_id' => $second_location->location_id, 'logo' => $logo];
                                            }
                                        }
                                    }
                                }
                            }catch (\Exception $e) {
                                Log::error('EmployeeDeleteAccessUpdateReminder/handle()[second_location_error] => '.$e->getMessage());
                                Log::error('EmployeeDeleteAccessUpdateReminder/handle()[second_location_data] => '.json_encode($second_location));
                            }
                        }
                        EmployeeDeleteAccessUpdateTrack::where('employee_id', $emp->id)->update([
                            'email_notification_sent' => 1,
                        ]);
                    }
                }catch (\Exception $e) {
                    Log::error('EmployeeDeleteAccessUpdateReminder/handle()[employee_error] => '.$e->getMessage());
                    Log::error('EmployeeDeleteAccessUpdateReminder/handle()[employee_data] => '.json_encode($emp));
                }
            }
            $delayTime = Carbon::today()->format('Y-m-d') .' '. Config::get('app.send_email_delay_time');
            // send HCE-UE46
            foreach ($email_send_user_list as $key => $user) {
                $email_list = array_unique($user, SORT_REGULAR);
                foreach ($email_list as $value) {
                    try{
                        $bullets_count_of_emp = '<ul>';
                        foreach ($emp_email_name_list[$key][$value['location_id']] as $emp) {
                            $bullets_count_of_emp .= '<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 14px;line-height: 1.6;font-weight: normal;">'.$emp.'</li>';
                        }
                        $bullets_count_of_emp .= '</ul>';
                        $email_vars = [
                            '{%FIRST_NAME%}' => $value['first_name'],
                            '{%EMPLOYEE_NAMES%}' => $bullets_count_of_emp,
                            '{%EMPLOYEE_TERMINATION_POLICY%}' => Config::get('app.url').'/procedures-policies-forms/'.base64_encode($value['location_id']),
                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        ];
                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                        $this->sendEmail($emailTemplate->code, $html, $value['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, $value['logo'], $key, null, $delayTime);
                    }catch (\Exception $e) {
                        Log::error('EmployeeDeleteAccessUpdateReminder/handle()[employee_error] => '.$e->getMessage());
                        Log::error('EmployeeDeleteAccessUpdateReminder/handle()[employee_data] => '.json_encode($value));
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('EmployeeDeleteAccessUpdateReminder/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
