<?php

namespace App\Console\Commands;

use App\Jobs\SendLocationDataToSalesForce;
use App\Models\CronExcecution;
use App\Models\Location;
use App\Models\User;
use App\Models\UserScheduleStatusChangeEvent;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;

class UserScheduleStatusChange extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'user_schedule_status_change:status_change';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Change user status to Active/Inactive on scheduled date';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'UserScheduleStatusChange',
            'start' => now(),
        ]);
        $today_date = Carbon::now()->format('Y-m-d');
        $scheduled_list = UserScheduleStatusChangeEvent::where('scheduled_date', $today_date)->with('user')->get();
        if (count($scheduled_list) > 0) {
            foreach ($scheduled_list as $each_item) {
                try{
                    $new_status = ($each_item->user->is_active == 1 ? 0 : 1);
                    $user = User::where('id', $each_item->user->id)->update(['is_active' => $new_status]);
                    if ($user) {
                        $updated_user = User::findOrFail($each_item->user->id);
                        if (isset($updated_user->locations[0]['id'])) {
                            $main_location = Location::where('id', $updated_user->locations[0]['id'])->whereNotNull('salesforce_unique_id')->first();
                            if ($main_location) {
                                SendLocationDataToSalesForce::dispatch($main_location->id);
                            }
                        }
                    }
                } catch (\Exception $e) {
                    Log::error('UserScheduleStatusChange/handle()[scheduled_list_error] => '.$e->getMessage());
                    Log::error('UserScheduleStatusChange/handle()[scheduled_list_data] => '.json_encode($each_item));
                }
            }
            UserScheduleStatusChangeEvent::where('scheduled_date', $today_date)->delete();
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
