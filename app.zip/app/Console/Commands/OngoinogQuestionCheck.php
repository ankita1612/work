<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\OngoingRiskAnalysisQuestion;
use App\Models\RiskAnalysisAttemptedQuestion;
use App\Models\RiskAnalysisAttemptedQuestionAnswer;
use App\Models\RiskAnalysisQuestion;
use App\Models\RiskAnalysisRemindOption;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class OngoinogQuestionCheck extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'check:ongoing';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'check for onging question to ask after specific period of time';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'OngoinogQuestionCheck',
            'start' => now(),
        ]);
        $current_date = gmdate('Y-m-d');
        $check_for_ongoing = RiskAnalysisAttemptedQuestion::select(['risk_analysis_attempted_questions.id', 'risk_analysis_attempted_questions.question_id', 'risk_analysis_attempted_questions.location_id', 'module_completed_statuses.is_completed'])
            ->where('next_remind_date', $current_date)
            ->where('next_remind_date', '<>', null)
            ->leftJoin('module_completed_statuses', function ($join) {
                $join->on('risk_analysis_attempted_questions.location_id', '=', 'module_completed_statuses.location_id')
                    ->whereRaw("module_completed_statuses.module = 'risk_analysis'");
            })
            ->get();
        foreach ($check_for_ongoing as $chk) {
            try{
                if ($chk->is_completed) {
                    OngoingRiskAnalysisQuestion::where([
                        'question_id' => $chk->question_id,
                        'location_id' => $chk->location_id,
                    ])->delete();
                    $temp_data = [
                        'question_id' => $chk->question_id,
                        'location_id' => $chk->location_id,
                        'question_type' => 'ongoing',
                        'added_date' => now(),
                    ];
                    $temp_data = OngoingRiskAnalysisQuestion::create($temp_data);
                }

                $question_deltail = RiskAnalysisQuestion::where('id', $chk->question_id)->first();
                $attemted_question = RiskAnalysisAttemptedQuestion::where('id', $chk->id)->first();
                if ($question_deltail->question_answer_layout == 'radio') {
                    $attempted_answer_detail = RiskAnalysisAttemptedQuestionAnswer::where('attempted_question_id', $chk->id)->first();
                    if ($attempted_answer_detail) {
                        $remind_option = RiskAnalysisRemindOption::where('answer_option_id', $attempted_answer_detail['answer_id'])->first();
                        if (isset($remind_option) && ($remind_option->ongoing_question_id != null && $remind_option->remind_month != null)) {
                            $next_remind_date = gmdate('Y-m-d', strtotime('+'.$remind_option->remind_month.' month', strtotime($current_date)));
                            $attemted_question->update(['next_remind_date' => $next_remind_date]);
                        } elseif ($attemted_question->next_remind_date != null) {
                            $attemted_question->update(['next_remind_date' => null]);
                        }
                    }
                } else {
                    $remind_option = RiskAnalysisRemindOption::where('question_id', $chk->question_id)->first();
                    if (isset($remind_option) && ($remind_option->ongoing_question_id != null && $remind_option->remind_month != null)) {
                        $next_remind_date = gmdate('Y-m-d', strtotime('+'.$remind_option->remind_month.' month', strtotime($current_date)));
                        $attemted_question->update(['next_remind_date' => $next_remind_date]);
                    } elseif ($attemted_question->next_remind_date != null) {
                        $attemted_question->update(['next_remind_date' => null]);
                    }
                }
            } catch (\Exception $e) {
                Log::error('OngoinogQuestionCheck/handle()[check_for_ongoing_error] => '.$e->getMessage());
                Log::error('OngoinogQuestionCheck/handle()[check_for_ongoing_data] => '.json_encode($chk));
            }
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
