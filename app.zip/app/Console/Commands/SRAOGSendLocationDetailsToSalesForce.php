<?php

namespace App\Console\Commands;

use App\Jobs\SendLocationDataToSalesForce;
use App\Models\CronExcecution;
use App\Models\Location;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SRAOGSendLocationDetailsToSalesForce extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sendlocationsraog:salesforce';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'check SRA and OG attempted question and sync location data to sales force';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'SRAOGSendLocationDetailsToSalesForce',
            'start' => now(),
        ]);

        try {
            $current_timestamp = Carbon::now();
            $current_hour = $current_timestamp->format('H');
            $current_date = $current_timestamp->toDateString();
            $end_time = Carbon::parse($current_date.' '.$current_hour.':00:00');
            $start_time = Carbon::parse($current_date.' '.$current_hour.':00:00')->subHours(6);

            $locations = Location::where(function ($query) use ($start_time, $end_time) {
                return $query->whereHas('attemptedQuestion', function ($q) use ($start_time, $end_time) {
                    return $q->whereBetween('created_at', [$start_time, $end_time]);
                })->orWhereHas('attemptedQuestion.attemptedQuestionAnswer', function ($q) use ($start_time, $end_time) {
                    return $q->whereBetween('created_at', [$start_time, $end_time]);
                })->orWhereHas('ongoingRiskAnalysisQuestion', function ($q) use ($start_time, $end_time) {
                    return $q->whereBetween('created_at', [$start_time, $end_time]);
                });
            })->whereNotNull('salesforce_unique_id')->get();
            if (! empty($locations)) {
                foreach ($locations as $loc_data) {
                    SendLocationDataToSalesForce::dispatch($loc_data->id);
                }
            }
        } catch (\Exception $e) {
            Log::error('SRAOGSendLocationDetailsToSalesForce/handle() => '.$e->getMessage());
        }

        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
