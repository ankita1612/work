<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Traits\SendMail;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class GeneralReminderEmail extends Command
{
    use SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'general_reminder:email';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Email will be send every 45 days if there are open notifications';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'GeneralReminderEmail',
            'start' => now(),
        ]);
        try {
            $locations = Location::whereHas('notifications', function ($q) {
                $q->where('is_completed', 0);
            })
                ->whereHas('user', function ($query) {
                    $query->where('account_status', 'Unfrozen')->where('is_active', '1')->where('is_account_verified', '1');
                })
                ->with([
                    'user.reseller',
                    'hipaaComplianceOfficer.hco',
                    'accountLocationAccess.accountUser',
                ])
                ->get();

            $emailTemplate = EmailTemplate::where('code', 'HCE-UE26')->first();
            $delayTime = Carbon::today()->format('Y-m-d') .' '. Config::get('app.send_email_delay_time');
            foreach ($locations as $loc) {
                try {
                    $loc_created_date = Carbon::parse($loc->created_at);
                    $today_date = Carbon::now();
                    $diff_in_days = $loc_created_date->diffInDays($today_date);
                    if ($diff_in_days > 0 && ($diff_in_days % 45) == 0) {

                        $email_send_hcouser_list = [];
                        $hco = $loc->hipaaComplianceOfficer;
                        if ($hco) {
                            $email_send_hcouser_list[] = ['first_name' => $hco->hco->first_name, 'email' => $hco->hco->email];
                        }
                        $account_users_list = $loc->accountLocationAccess;
                        foreach ($account_users_list as $key => $value) {
                            try{
                                if ($hco && $value->accountUser->email != $hco->hco->email) {
                                    $email_send_hcouser_list[] = ['first_name' => $value->accountUser->first_name, 'email' => $value->accountUser->email];
                                }
                                if (! $hco) {
                                    $email_send_hcouser_list[] = ['first_name' => $value->accountUser->first_name, 'email' => $value->accountUser->email];
                                }
                            } catch (\Exception $e) {
                                Log::error('GeneralReminderEmail/handle()[account_users_list_error] => '.$e->getMessage());
                                Log::error('GeneralReminderEmail/handle()[account_users_list_data] => '.json_encode($value));
                            }
                        }
                        foreach ($email_send_hcouser_list as $key => $value) {
                            try{
                                $email_vars = [
                                    '{%FIRST_NAME%}' => $value['first_name'],
                                    '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                                    '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                ];
                                $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                $this->sendEmail($emailTemplate->code, $html, $value['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, (! empty($loc->user->partner_reseller_id) ? $loc->user->reseller->logo : null), $loc->user->id, null, $delayTime);
                            } catch (\Exception $e) {
                                Log::error('GeneralReminderEmail/handle()[email_send_osouser_list_error] => '.$e->getMessage());
                                Log::error('GeneralReminderEmail/handle()[email_send_osouser_list_data] => '.json_encode($value));
                            }
                        }
                    }
                } catch (\Exception $e) {
                    Log::error('GeneralReminderEmail/handle()[locations_error] => '.$e->getMessage());
                    Log::error('GeneralReminderEmail/handle()[locations_data] => '.json_encode($loc));
                }
            }
        } catch (\Exception $e) {
            Log::error('GeneralReminderEmail/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
