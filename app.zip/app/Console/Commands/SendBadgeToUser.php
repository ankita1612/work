<?php

namespace App\Console\Commands;
use App\Models\CronExcecution;
use App\Models\User;
use App\Models\UserBadgeEmailHistory;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use App\Models\EmailTemplate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use App\Jobs\SendBadgeEmailToUser;
use App\Traits\SendMail;

class SendBadgeToUser extends Command
{
    use SendMail;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send_email_to_user:badge';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send Badge in email with attachment link to specified user';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'SendBadgeToUser',
            'start' => now(),
        ]);

        $user_data=User::with('reseller')->where(["account_status" => 'Unfrozen',  "is_active" => 1 , "is_account_verified" => 1])->skip(0)->take(1)->orderBy('id','asc')->get();

        //read json data from file
        $json = file_get_contents(public_path('badge/user_badge.json'));              
        $badge_user_arr = json_decode($json, 1);           
                    
        $email_HCE_UE68 = EmailTemplate::where('code', 'HCE-UE68')->first();
        $email_HCE_UE69 = EmailTemplate::where('code', 'HCE-UE69')->first();
        
        foreach ($user_data as $user){  
            try {
                DB::beginTransaction();
                $email_type = in_array($user->email, $badge_user_arr) ? 'Badge' : 'MissingRequirements';
                
                $history_count = UserBadgeEmailHistory::where("user_id",$user->id)->count();
                if($history_count > 0){
                    continue;
                }

                $history_added = UserBadgeEmailHistory::create([
                    'user_id' => $user->id,
                    'is_mail_open' => false,
                    'is_attachment_open' => false,
                    'email_type'=> $email_type
                ]);         
                
                if($email_type == 'Badge'){                        
                    $email_vars = [
                        '{%USER_COMPANY_NAME%}' =>  $user->company_name,
                        '{%TRACK_MAIL_URL%}' => route('track_open.email_popup', ['email_history_id' => base64_encode($history_added->id),'open_type' => base64_encode('email')]),
                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),                        
                        '{%SUPPORT_PHONE%}' => Config::get('app.support_phone_number'),
                        '{%SUPPORT_PHONE_NUMBER_DISPLAY%}' => Config::get('app.support_phone_number_display'),
                    ];
                    $show_download_badge_link = route('track_open.attachment', ['email_history_id' => base64_encode($history_added->id),'download_type'=>base64_encode('email_attachment')]);
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars),  $email_HCE_UE68->body);
                    $html_subject = str_ireplace(['{%USER_COMPANY_NAME%}'], [ $user->company_name], $email_HCE_UE68->subject);
                    
                    $this->sendEmail($email_HCE_UE68->code, $html, $user->email, Config::get('app.from_user_email'), $html_subject, null, null, true, ($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id,$show_download_badge_link);                    
                }                        
                else{                        
                    $email_vars = [
                        '{%USER_COMPANY_NAME%}' => $user->company_name,
                        '{%TRACK_MAIL_URL%}' => route('track_open.email_popup', ['email_history_id' => base64_encode($history_added->id),'open_type' => base64_encode('email')]),                        
                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                        '{%SCHEDULE_REFRESHER_LINK%}' =>Config::get('app.calendly_url').'/ccsabyde/abyde-refresher',
                        '{%SUPPORT_PHONE%}' => Config::get('app.support_phone_number'),
                        '{%SUPPORT_PHONE_NUMBER_DISPLAY%}' => Config::get('app.support_phone_number_display'),
                    ];            
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $email_HCE_UE69->body);                                  
                    
                    $this->sendEmail($email_HCE_UE69->code, $user->email, Config::get('app.from_user_email'), $email_HCE_UE69->subject, null, null, true, ($user->partner_reseller_id != null ? $user->reseller->logo : null), $user->id);
                }    
                UserBadgeEmailHistory::where('user_id', $user->id)->update(['is_mail_send' => true]);
                Log::info("Badge email sent to user ID : {$user->id} for email : {$user->email}");
                DB::commit();   
            } catch (\Exception $e) {            
                DB::rollBack();
                Log::error("Failed to send badge email sent to user ID : {$user->id} for email : {$user->email}");
                Log::error('SendBadgeToUser/handle() [user_data_error] => '.$e->getMessage());
                Log::error('SendBadgeToUser/handle() [user_data_data] => '.json_encode($user));                                       
            }                                                              
        }
       
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
