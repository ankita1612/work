<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\Training;
use App\Models\TrainingAttempt;
use App\Models\TrainingInvite;
use App\Models\TrainingQuestion;
use App\Models\TrainingQuizAttempt;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SplitTrainingInviteScript extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'splitscript:trainingInvite';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'SplitTrainingInviteScript',
            'start' => now(),
        ]);
        try {
            $old_training_code = "HT4";
            $new_training_code_A = ($old_training_code == "HT5") ? "HT5A" : "HT4A";
            $new_training_code_B = ($old_training_code == "HT5") ? "HT5B" : "HT4B";
            $new_training_code_C = ($old_training_code == "HT5") ? "HT5C" : "HT4C";

            $training = Training::where('training_code', $old_training_code)->first();
            $new_training_1_1 = Training::where('training_code', $new_training_code_A)->first();
            $new_training_1_2 = Training::where('training_code', $new_training_code_B)->first();
            $new_training_1_3 = Training::where('training_code', $new_training_code_C)->first();

            if ($training) {
                $training_invite_list = TrainingInvite::with('trainingAttempt')->where('training_id', $training['id'])->skip(0)->take(500)->get();
                foreach ($training_invite_list as $training_invite) {
                    $new_training_invite_1_1 = TrainingInvite::create([
                        'emp_user_acntuser_student_id' => $training_invite->emp_user_acntuser_student_id,
                        'emp_user_acntuser_student_type' => $training_invite->emp_user_acntuser_student_type,
                        'training_id' => $new_training_1_1['id'],
                        'ref_token' => $training_invite->ref_token,
                        'invite_datetime' => $training_invite->invite_datetime,
                        'completed_datetime' => $training_invite->completed_datetime,
                        'completed_attempt_id' => null,
                        'reason' => $training_invite->reason,
                    ]);
                    $new_training_invite_1_2 = TrainingInvite::create([
                        'emp_user_acntuser_student_id' => $training_invite->emp_user_acntuser_student_id,
                        'emp_user_acntuser_student_type' => $training_invite->emp_user_acntuser_student_type,
                        'training_id' => $new_training_1_2['id'],
                        'ref_token' => $training_invite->ref_token,
                        'invite_datetime' => $training_invite->invite_datetime,
                        'completed_datetime' => $training_invite->completed_datetime,
                        'completed_attempt_id' => null,
                        'reason' => $training_invite->reason,
                    ]);
                    $new_training_invite_1_3 = TrainingInvite::create([
                        'emp_user_acntuser_student_id' => $training_invite->emp_user_acntuser_student_id,
                        'emp_user_acntuser_student_type' => $training_invite->emp_user_acntuser_student_type,
                        'training_id' => $new_training_1_3['id'],
                        'ref_token' => $training_invite->ref_token,
                        'invite_datetime' => $training_invite->invite_datetime,
                        'completed_datetime' => $training_invite->completed_datetime,
                        'completed_attempt_id' => null,
                        'reason' => $training_invite->reason,
                    ]);
                    if ($training_invite['ref_token'] == '' && $training_invite['completed_datetime'] != null && $training_invite['completed_attempt_id'] != null) {
                        $this->completeTraining([$new_training_invite_1_1, $new_training_invite_1_2, $new_training_invite_1_3]);
                    }
                    $training_invite->delete();
                }
            } else {
                Log::error('SplitTrainingInviteScript/handle() => Training not found');
            }
        } catch (\Exception $e) {
            Log::error('Training Invite: '.$training_invite->id);
            Log::error('SplitTrainingInviteScript/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }

    private function completeTraining($new_training_invites)
    {
        foreach ($new_training_invites as $new_training_invite) {
            $training_attempt_data = [
                'invite_id' => $new_training_invite['id'],
                'attempted_from' => 'software',
            ];
            $add_training_attempt_data = TrainingAttempt::create($training_attempt_data);
            $training_questions = TrainingQuestion::with('trainingQuestionAnswerCorrect')->where('training_id', $new_training_invite['training_id'])->get();
            foreach ($training_questions as $training_question) {
                TrainingQuizAttempt::create([
                    'training_attempt_id' => $add_training_attempt_data['id'],
                    'question_id' => $training_question['id'],
                    'answer_id' => $training_question['trainingQuestionAnswerCorrect'][0]['id'],
                    'is_given_correct' => 'yes',
                ]);
            }
            TrainingInvite::where('id', $new_training_invite['id'])->update([
                'completed_attempt_id' => $add_training_attempt_data['id'],
            ]);
        }
    }
}
