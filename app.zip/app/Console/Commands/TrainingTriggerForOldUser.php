<?php

namespace App\Console\Commands;

use App\Http\Controllers\App\TrainingController;
use App\Models\CronExcecution;
use App\Models\Location;
use App\Models\OldUserTrainingChangeLog;
use App\Models\Setting;
use App\Models\Training;
use App\Models\TrainingLocation;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class TrainingTriggerForOldUser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'trainingtrigger:olduser';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'New Training Trigger for old user';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'TrainingTriggerForOldUser',
            'start' => now(),
        ]);
        try {
            $locations = Location::with('user.reseller')
                ->with('hipaaComplianceOfficer')
                ->whereHas('hipaaComplianceOfficer')
                ->whereHas('employeePrimaryWorkLocation')
                ->whereHas('sraModuleCompleted')
                ->skip(0)
                ->take(10)
                ->get();
            $today = Carbon::today()->endOfDay();
            $training_list = Training::select(['id', 'training_code', 'who_can_train', 'trigger_month', 'parent_training_id', 'notification_code'])
                ->whereIn('who_can_train', ['hco', 'employee'])
                ->whereIn('training_code', ['HT37A', 'HT37B', 'HT37C', 'HT38A', 'HT38B', 'HT38C'])
                ->isActive()
                ->get();
            foreach ($locations as $location) {
                $old_user_training_log = OldUserTrainingChangeLog::create([
                    'user_id' => $location->user_id,
                    'location_id' => $location->id,
                    'is_completed' => 0,
                ]);
                $check_user_pause = Setting::where('user_id', $location->user_id)->where('functionality', 'training_pause')->count();
                if ($check_user_pause == 0) {
                    $renewalDate = Carbon::parse($location->user->contract_renewal_date)->endOfDay();
                    $nextRenewalDate = Carbon::parse($location->user->contract_renewal_date)->addYear()->endOfDay();
                    $before2monthDate = Carbon::parse($location->user->contract_renewal_date)->subMonths(2)->endOfDay();
                    foreach ($training_list as $training) {
                        $check_training_is_already_open_for_location = TrainingLocation::where('location_id', '=', $location->id)->where('training_id', '=', $training->id)->count();
                        if ($check_training_is_already_open_for_location == 0) {
                            $schedule_date = $training->trigger_month
                            ? Carbon::parse($location->training_anchor_date)->addMonth($training->trigger_month)->endOfDay()
                            : Carbon::now()->endOfDay();
                            if ($schedule_date->lte($renewalDate)) {
                                $temp_data = [
                                    'location_id' => $location->id,
                                    'training_id' => $training->id,
                                    'trigger_type' => 'auto',
                                    'schedule_date' => $schedule_date->format('Y-m-d'),
                                ];
                                if ($schedule_date->lte($today)) {
                                    $temp_data['is_triggered'] = 1;
                                    $temp_data['old_schedule_date'] = $schedule_date->format('Y-m-d');
                                    $temp_data['schedule_date'] = date('Y-m-d');
                                }
                                TrainingLocation::create($temp_data);
                                if (isset($temp_data['is_triggered']) && $temp_data['is_triggered'] == 1) {
                                    $training_controller = new TrainingController;
                                    $training_controller->sendInitialInvites($training, $location->id);
                                }
                            } elseif ($before2monthDate->lte($today)) {
                                if ($schedule_date->lte($nextRenewalDate)) {
                                    $temp_data = [
                                        'location_id' => $location->id,
                                        'training_id' => $training->id,
                                        'trigger_type' => 'auto',
                                        'schedule_date' => $schedule_date->format('Y-m-d'),
                                        'is_disable' => 1,
                                    ];
                                    TrainingLocation::create($temp_data);
                                }
                            }
                        }
                    }
                }
                $old_user_training_log->update([
                    'is_completed' => 1,
                ]);
            }
        } catch (\Exception $e) {
            Log::error('Training9TriggerForOldUser/handle() => ' . $e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
