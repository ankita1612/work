<?php

namespace App\Console\Commands;

use App\Models\{CronExcecution};
use Illuminate\Console\Command;
use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;

class TempDocsClear extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tempdocs:clear';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'clear temporary generated documents';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'TempDocsClear',
            'start' => now(),
        ]);
        try{
            $file_system = new Filesystem;
            $file_system->cleanDirectory('public/storage/generatedpolicydocuments');
            $file_system->cleanDirectory('public/storage/temp_zip_abyde_drive');
            $file_system->cleanDirectory('public/storage/temp_zip_abyde_drive_archive');
            $file_system->cleanDirectory('public/storage/quoter_pdf');
        }catch (\Exception $e) {
            Log::error('TempDocsClear/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
