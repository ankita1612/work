<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\Training;
use App\Models\UnassignedTraining;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SplitUnassignedTrainingScript extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'splitscript:unassignedtraining';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'SplitUnassignedTrainingScript',
            'start' => now(),
        ]);
        try {
            $old_training_code = "HT4";
            $new_training_code_A = ($old_training_code == "HT5") ? "HT5A" : "HT4A";
            $new_training_code_B = ($old_training_code == "HT5") ? "HT5B" : "HT4B";
            $new_training_code_C = ($old_training_code == "HT5") ? "HT5C" : "HT4C";
            
            $training = Training::where('training_code', $old_training_code)->first();
            $new_training_1_1 = Training::where('training_code', $new_training_code_A)->first();
            $new_training_1_2 = Training::where('training_code', $new_training_code_B)->first();
            $new_training_1_3 = Training::where('training_code', $new_training_code_C)->first();

            if ($training) {
                $unassigned_trainings = UnassignedTraining::where('training_id', $training['id'])->skip(0)->take(500)->get();
                foreach ($unassigned_trainings as $unassigned_training) {
                    $temp_data = [
                        'training_id' => $new_training_1_1['id'],
                        'location_id' => $unassigned_training->location_id,
                        'emp_user_acntuser_student_id' => $unassigned_training->emp_user_acntuser_student_id,
                        'emp_user_acntuser_student_type' => $unassigned_training->emp_user_acntuser_student_type,
                        'user_id' => $unassigned_training->user_id,
                        'is_hidden' => $unassigned_training->is_hidden,
                        'created_at' => $unassigned_training->created_at,
                        'updated_at' => $unassigned_training->updated_at,
                    ];
                    UnassignedTraining::create($temp_data);
                    $temp_data['training_id'] = $new_training_1_2['id'];
                    UnassignedTraining::create($temp_data);
                    $temp_data['training_id'] = $new_training_1_3['id'];
                    UnassignedTraining::create($temp_data);
                    $unassigned_training->delete();
                }
            } else {
                Log::error('SplitUnassignedTrainingScript/handle() => Training not found');
            }
        } catch (\Exception $e) {
            Log::error('Unassigned Training: '.$unassigned_training->id);
            Log::error('SplitUnassignedTrainingScript/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
