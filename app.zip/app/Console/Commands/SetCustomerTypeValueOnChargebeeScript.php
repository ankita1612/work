<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\User;
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Models\Customer;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class SetCustomerTypeValueOnChargebeeScript extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:set-customer-type-value-on-chargebee-script {start} {end}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Set Customer Type value on changebee script';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'SetCustomerTypeValueOnChargebeeScript',
            'start' => now(),
        ]);
        $start = 0;
        if($this->argument('start')){
            $start = $this->argument('start');
        }
        $end = 0;
        if($this->argument('end')){
            $end = $this->argument('end');
        }
        $users = User::where('chargebee_customer_id', '!=', '')
            ->whereBetween('id', [$start, $end])
            ->get();
            
        Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
        foreach($users as $user){
            try{
                if($user->partner_reseller_id != NULL){
                    $customer_type = "Reseller";
                } else {
                    $customer_type = "Normal";
                }
                Customer::update($user->chargebee_customer_id,array(
                    "cf_Customer_Type" => $customer_type,
                )); 
                Log::info('SetCustomerTypeValueOnChargebeeScript :success user id(data): '.$user->id);
            } catch (\Exception $e) {
                Log::error('SetCustomerTypeValueOnChargebeeScript : failed user id(error): '.$e->getMessage());
                Log::error('SetCustomerTypeValueOnChargebeeScript : failed user id(data): '.$user->id);
            }
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
