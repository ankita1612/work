<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\User;
use App\Models\FullUpgradeSraUserDetail;
use Carbon\Carbon;
use App\Traits\ChargebeePlan;
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Models\Subscription;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class UpdateAddonOnFirstContractEndDate extends Command
{
    use ChargebeePlan;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'addon-update:on-first-contract-end-date';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Schedule chargbee subscription addon changes at next renewal on first contract end date';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'UpdateAddonOnFirstContractEndDate',
            'start' => now(),
        ]);
        $users = User::whereDate('chargebe_first_contract_end_date', Carbon::today()->format('Y-m-d'))
            ->where('chargebee_subscription_id', '!=', '')
            ->where('is_active', 1)
            ->where('chargebe_addon_type', 'new')
            ->get();
        foreach ($users as $user) {
            try {
                Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
                $subscription_response = Subscription::retrieve($user->chargebee_subscription_id);
                $subscription = $subscription_response->subscription();
                if ($subscription->status == 'active') {
                    if ($subscription->billingPeriodUnit == "month") {
                        $plan_type = "monthly";
                        if ($subscription->billingPeriod == 3) {
                            $plan_type = "quarterly";
                        }
                        if ($subscription->billingPeriod == 6) {
                            $plan_type = "biannually";
                        }
                    } else {
                        $plan_type = "yearly";
                    }
                    if ($user->is_sra_user == 1) {
                        $chargebee_plan_ids = $this->getChargebeePlanId($plan_type, 'renewal', 'sra_only');
                        $location_limit = 0;
                        foreach ($subscription->subscriptionItems as $subscriptionItems) {
                            if ($subscriptionItems->itemType == 'plan' && str_contains($subscriptionItems->itemPriceId, 'SRA-ONLY')) {
                                $location_limit = $subscriptionItems->quantity;
                            }
                        }
                        $subscription_array = array(
                            'replaceItemsList' => true,
                            "changeOption" => "end_of_term",
                            "subscriptionItems" => array(
                                array(
                                    "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                                    "quantity" => $location_limit
                                ),
                            )
                        );
                    } else {
                        $version = 'v2';
                        foreach ($subscription->itemTiers as $item_tiers) {
                            if(str_contains($item_tiers->itemPriceId, 'Employees') && !empty($item_tiers->endingUnit) && $item_tiers->endingUnit == 5){
                                $version = 'v1';
                                break;
                            }
                        }
                        $chargebee_plan_ids = $this->getChargebeePlanId($plan_type,'renewal', 'normal', $version);
                        $transaction_fee = 0;
                        $location_limit = 0;
                        $employee_limit = 0;
                        foreach ($subscription->subscriptionItems as $subscriptionItems) {
                            if ($chargebee_plan_ids['transaction_fee_item_id'] == $subscriptionItems->itemPriceId) {
                                $transaction_fee = $subscriptionItems->unitPriceInDecimal;
                            }
                            if ($subscriptionItems->itemType == 'addon' && str_contains($subscriptionItems->itemPriceId, 'Locations')) {
                                $location_limit = $subscriptionItems->quantity;
                            }
                            if ($subscriptionItems->itemType == 'addon' && str_contains($subscriptionItems->itemPriceId, 'Employees')) {
                                $employee_limit = $subscriptionItems->quantity;
                            }
                        }

                        $subscription_array = array(
                            'replaceItemsList' => true,
                            "changeOption" => "end_of_term",
                            "subscriptionItems" => array(
                                array(
                                    "itemPriceId" => $chargebee_plan_ids['plan_item_id'],
                                    "quantity" => 1
                                ),
                                array(
                                    "itemPriceId" => $chargebee_plan_ids['location_item_id'],
                                    "quantity" => $location_limit
                                ),
                                array(
                                    "itemPriceId" => $chargebee_plan_ids['employee_item_id'],
                                    "quantity" =>  $employee_limit
                                ),
                                array(
                                    "itemPriceId" => $chargebee_plan_ids['transaction_fee_item_id'],
                                    "unitPriceInDecimal" => $transaction_fee
                                ),
                            )
                        );
                        $full_upgrade_sra_user = FullUpgradeSraUserDetail::where('user_id', $user->id)->first();
                        if ($full_upgrade_sra_user != null) {
                            $subscription_array['changeOption'] = "immediately";
                        }
                    }
                    Subscription::updateForItems($user->chargebee_subscription_id, $subscription_array);
                    Log::info("UpdateAddonOnFirstContractEndDate : user addon changes scheduled for user id:" . $user->id);
                }
            } catch (\Exception $e) {
                Log::error("UpdateAddonOnFirstContractEndDate : user addon changes failed to schedule for user id:" . $user->id);
                Log::error('UpdateAddonOnFirstContractEndDate/handle() => ' . $e->getMessage());
            }
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
