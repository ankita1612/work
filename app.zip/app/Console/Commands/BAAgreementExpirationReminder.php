<?php

namespace App\Console\Commands;

use App\Models\BusinessAssociates;
use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Traits\Notification;
use App\Traits\SendMail;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class BAAgreementExpirationReminder extends Command
{
    use Notification, SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ba_agreement_expiration_reminder:notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Notification will be send 60 days before the expiration date of BA agreement';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'BAAgreementExpirationReminder',
            'start' => now(),
        ]);
        try {
            $after60_days = Carbon::today()->addDays(60)->format('Y-m-d');
            $ba_list = BusinessAssociates::where('expired_date', $after60_days)->with('user.reseller')
                ->whereHas('user', function($query){
                    $query->where('is_sra_user', 0);
                })->get();
            $notification_HCE_AN13 = $this->getNotificationByCode('HCE-AN13');
            $delayTime = Carbon::today()->format('Y-m-d') .' '. Config::get('app.send_email_delay_time');
            foreach ($ba_list as $lst) {
                try{
                    $locations = Location::where('user_id', $lst->user_id)
                        ->whereHas('hipaaComplianceOfficer')
                        ->whereHas('businessAssociatesLocation', function ($query) use ($lst) {
                            $query->where('business_associate_id', $lst->id);
                        })
                        ->with('hipaaComplianceOfficer.hco')
                        ->get();
                    $hco_email_list = [];
                    foreach ($locations as $location) {
                        try{
                            $notification_data = [
                                'location_id' => $location['id'],
                                'notification_id' => $notification_HCE_AN13['id'],
                                'other_details' => $lst['name'],
                            ];
                            $this->createNotification($notification_data);

                            $hco = $location->hipaaComplianceOfficer;
                            if ($hco) {
                                $hco_email_list[] = ['email' => $hco->hco->email, 'first_name' => $hco->hco->first_name];
                            }
                        }catch (\Exception $e) {
                            Log::error('BAAgreementExpirationReminder/handle()[locations_error] => '.$e->getMessage());
                            Log::error('BAAgreementExpirationReminder/handle()[locations_data] => '.json_encode($location));
                        }   
                    }
                    $hco_email_list = array_unique($hco_email_list, SORT_REGULAR);
                    $emailTemplate = EmailTemplate::where('code', 'HCE-UE19')->first();
                    foreach ($hco_email_list as $hco) {
                        try{
                            $email_vars = [
                                '{%BA_NAME%}' => $lst->name,
                                '{%SIGN_UP_FIRST_NAME%}' => $hco['first_name'],
                                '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                            ];
                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                            if ($lst->user->account_status == 'Unfrozen' && $lst->user->is_active == '1' && $lst->user->is_account_verified == '1') {
                                $this->sendEmail($emailTemplate->code,$html, $hco['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($lst->user->partner_reseller_id != null ? $lst->user->reseller->logo : null), $lst->user->id, null, $delayTime);
                            }
                        } catch (\Exception $e) {
                            Log::error('BAAgreementExpirationReminder/handle()[hco_email_list_error] => '.$e->getMessage());
                            Log::error('BAAgreementExpirationReminder/handle()[hco_email_list_data] => '.json_encode($hco));
                        } 
                    }
                }catch (\Exception $e) {
                    Log::error('BAAgreementExpirationReminder/handle()[ba_list_error] => '.$e->getMessage());
                    Log::error('BAAgreementExpirationReminder/handle()[ba_list_data] => '.json_encode($lst));
                }
            }
        } catch (\Exception $e) {
            Log::error('BAAgreementExpirationReminder/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
