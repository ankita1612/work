<?php

namespace App\Console\Commands;

use App\Models\Location;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class LocationDeleteScript extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'location:delete {location_id}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This script is use to delete a location by location id';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {

        try {
            if ($this->argument('location_id')) {
                $location = Location::findOrFail((int) $this->argument('location_id'));
                $location->delete();
            }
        } catch (\Exception $e) {
            Log::error('LocationDeleteScript/handle() => '.$e->getMessage());
            Log::error('LocationDeleteScript/handle()[location_id] => '.json_encode(['location_id' => $this->argument('location_id')]));
        }
    }
}
