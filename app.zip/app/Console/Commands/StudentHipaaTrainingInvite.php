<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\Student;
use App\Models\Training;
use App\Models\TrainingInvite;
use App\Models\TrainingLocation;
use App\Traits\Notification;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class StudentHipaaTrainingInvite extends Command
{
    use Notification, SendMail;

    /**
     * The name and signature of the console command.
     * 
     * add location id as first argument
     * e.g. php artisan studenthipaa:traininginvite 1
     * 
     * add array element seperated by space if want to trigger specific training
     * e.g. php artisan studenthipaa:traininginvite 1 HT8 HT13 HT14 
     * 
     * @var string
     */
    protected $signature = 'studenthipaa:traininginvite {location_id} {training_codes?*}';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'send invite to student for given training code';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        if ((int)$this->argument('location_id') == 0) {
            $location_id = (int)$this->argument('location_id');
            $this->error('please enter location id');
            return;
        }

        if ($this->argument('training_codes')) {
            $training_arr = $this->argument('training_codes'); // get the array from argument
            if (is_string($training_arr)) {
                $training_arr = explode(' ', $training_arr); // convert string to array if needed
            }
            $diff_result = array_diff($training_arr, ["HT8", "HT13", "HT14", "HT15"]);
            if (! empty($diff_result)) {
                Log::error('StudentHipaaTrainingInvite/handle() => Invalid student training codes provided: ' . json_encode($diff_result));
                $this->error('Invalid training codes provided: ' . json_encode($diff_result));
                return;
            }
        } else {
            $training_arr = ["HT8", "HT13", "HT14", "HT15"]; // default training codes if not provided for all student trainings
        }

        $cron_excecution = CronExcecution::create([
            'name' => 'StudentHipaaTrainingInvite',
            'start' => now(),
        ]);
        try {
            $training_list = Training::select(['id', 'training_code', 'who_can_train', 'notification_code'])->whereIn('training_code', $training_arr)->isActive()->get();
            if (! empty($training_list)) 
            {
                $emailTemplate_UE42 = EmailTemplate::where('code', 'HCE-UE42')->first();
                $emailTemplate_UE43 = EmailTemplate::where('code', 'HCE-UE43')->first();
                $emailTemplate_UE44 = EmailTemplate::where('code', 'HCE-UE44')->first();
                $emailTemplate_UE45 = EmailTemplate::where('code', 'HCE-UE45')->first();

                foreach($training_list as $training)
                {
                    $location_list = Location::with('hipaaComplianceOfficer')
                    ->with(['user' => function ($que) {
                        $que->where('is_educational_account', 1)->where('is_sra_user', 0);
                    }, 'user.reseller'])
                    ->whereHas('hipaaComplianceOfficer')
                    ->whereHas('user', function ($query) {
                        $query->where('is_educational_account', 1)->where('is_sra_user', 0);
                        });

                    if ($this->argument('location_id')) {
                        $location_list = $location_list->where('id', $this->argument('location_id'));
                    }

                    $location_list = $location_list->get();

                    if (! empty($location_list)) {
                        foreach ($location_list as $loc_data) {
                            try {
                                $check_training_is_already_open_for_location = TrainingLocation::where('location_id', '=', $loc_data->id)->where('training_id', '=', $training->id)->count();                                
                                if ($check_training_is_already_open_for_location == 0) {                                    
                                    $temp_data = [
                                        'location_id' => $loc_data->id,
                                        'training_id' => $training->id,
                                        'trigger_type' => 'auto',
                                        'schedule_date' => Carbon::now(),
                                        'is_triggered' => 1,
                                    ];
                                    $trainingadd = TrainingLocation::create($temp_data);                                    
                                    if ($training->who_can_train == 'student') {
                                        $student_list = Student::where('primary_work_location_id', $loc_data->id)->with('studentPrimaryWorkLocation')->get();
                                        if (count($student_list) > 0) {
                                            foreach ($student_list as $student_data) {
                                                try {
                                                    $check_invite = TrainingInvite::where('emp_user_acntuser_student_id', $student_data['id'])->where('training_id', $training->id)->where('emp_user_acntuser_student_type', \App\Models\Student::class)->first();
                                                    if ($check_invite === null || ! $check_invite) {
                                                        $training_invite_data = [
                                                            'emp_user_acntuser_student_id' => $student_data['id'],
                                                            'emp_user_acntuser_student_type' => \App\Models\Student::class,
                                                            'training_id' => $training->id,
                                                            'ref_token' => Str::random(40),
                                                            'invite_datetime' => gmdate('Y-m-d H:i:s'),
                                                        ];                                                        
                                                        $add_training_invite = TrainingInvite::create($training_invite_data);
                                                        // send HCE-UE44
                                                        $hco = HipaaComplianceOfficer::where('location_id', $student_data->primary_work_location_id)->with('hco')->first();                                                        

                                                        $emailTemplate = ($training->training_code=='HT8' ? $emailTemplate_UE43 : $emailTemplate_UE44);                                                        
                                                        $email_vars = [
                                                            '{%FIRST_NAME%}' => $student_data['first_name'],
                                                            '{%COMPLETE_TRAINING%}' => Config::get('app.url').'/studentportal/training/'.base64_encode($student_data->id).'/'.base64_encode($add_training_invite->id),
                                                            '{%HIPAA_COMPLIANCE_OFFICER_NAME%}' => $hco->hco->first_name.' '.$hco->hco->last_name,
                                                            '{%INSTITUTION_NAME%}' => $student_data->studentPrimaryWorkLocation->location_nickname,
                                                            '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                                        ];
                                                        $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                                        $html_subject = str_ireplace(['{%INSTITUTION_NAME%}'], [$student_data->studentPrimaryWorkLocation->location_nickname], $emailTemplate->subject);
                                                        if ($loc_data['user']['account_status'] == 'Unfrozen' && $loc_data['user']['is_active'] == '1' && $loc_data['user']['is_account_verified'] == '1') {
                                                            $this->sendEmail($emailTemplate->code, $html, $student_data['email'], Config::get('app.from_user_email'), $html_subject, null, null, true, ($loc_data['user']['partner_reseller_id'] != null ? $loc_data['user']['reseller']['logo'] : null), $loc_data['user']['id']);
                                                        }                                                        
                                                        $notification = $this->getNotificationByCode($training->notification_code);
                                                        if ($this->checkNotificationAlreadyAdded($notification->code, $loc_data->id) == 0) {
                                                            $notification_data = [
                                                                'location_id' => $loc_data->id,
                                                                'notification_id' => $notification['id'],
                                                            ];
                                                            $this->createNotification($notification_data);
                                                            // send HCE-UE45 or UE42
                                                            $emailTemplate = ($training->training_code=='HT8' ? $emailTemplate_UE42 : $emailTemplate_UE45 );
                                                            $email_vars = [
                                                                '{%FIRST_NAME%}' => $hco->hco->first_name,
                                                                '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                                                                '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                                            ];
                                                            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                                            if ($loc_data['user']['account_status'] == 'Unfrozen' && $loc_data['user']['is_active'] == '1' && $loc_data['user']['is_account_verified'] == '1') {
                                                                $this->sendEmail($emailTemplate->code, $html, $hco->hco->email, Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($loc_data['user']['partner_reseller_id'] != null ? $loc_data['user']['reseller']['logo'] : null), $loc_data['user']['id']);
                                                            }                                                            
                                                        }
                                                    }
                                                } catch (\Exception $e) {
                                                    Log::error('StudentHipaaTrainingInvite/handle()[student_list_loop_error] => '.$e->getMessage());
                                                    Log::error('StudentHipaaTrainingInvite/handle()[student_list_loop_data] => '.json_encode($student_data));
                                                }
                                            }
                                        }
                                    }
                                }
                            } catch (\Exception $e) {
                                Log::error('StudentHipaaTrainingInvite/handle()[location_list_loop_error] => '.$e->getMessage());
                                Log::error('StudentHipaaTrainingInvite/handle()[location_list_loop_data] => '.json_encode($loc_data));
                            }
                        }
                    }
                }                              
            }
        } catch (\Exception $e) {
            Log::error('StudentHipaaTrainingInvite/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
