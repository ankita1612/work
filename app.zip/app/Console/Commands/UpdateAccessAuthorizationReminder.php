<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\Location;
use App\Traits\Notification;
use App\Traits\SendMail;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;

class UpdateAccessAuthorizationReminder extends Command
{
    use Notification, SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update_access_authorization_reminder:notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Notification will be send update_access_authorization_reminder:notification';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'UpdateAccessAuthorizationReminder',
            'start' => now(),
        ]);
        try {
            $today = Carbon::today()->format('Y-m-d');
            $location_list = Location::with(['employeePrimaryWorkLocation', 'employeeSecondaryWorkLocation'])
                ->whereHas('user', function($query){
                    $query->where('is_sra_user', 0);
                })->get();
            if (! empty($location_list)) {
                $notification_HCE_AN19 = $this->getNotificationByCode('HCE-AN19');
                foreach ($location_list as $loc) {
                    try{
                        if ($loc->employeePrimaryWorkLocation || $loc->employeeSecondaryWorkLocation) {
                            $prev_notification = $this->getPreviousNotificationAdded($notification_HCE_AN19->code, $loc['id']);
                            if ($prev_notification) {
                                $previous_date = $prev_notification->created_at;
                            } else {
                                $previous_date = $loc->created_at;
                            }
                            $date_after5_months = Carbon::parse($previous_date)->addMonths(5)->format('Y-m-d');
                            if ($today == $date_after5_months) {
                                $notification_data = [
                                    'location_id' => $loc['id'],
                                    'notification_id' => $notification_HCE_AN19['id'],
                                ];
                                $this->createNotification($notification_data);
                            }
                        }
                    } catch (\Exception $e) {
                        Log::error('UpdateAccessAuthorizationReminder/handle()[location_error] => '.$e->getMessage());
                        Log::error('UpdateAccessAuthorizationReminder/handle()[location_data] => '.json_encode($loc));
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('UpdateAccessAuthorizationReminder/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
