<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Traits\SendMail;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class LogFriendlyReminderEmail extends Command
{
    use SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'log_friendly_reminder:email';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Email will be send every 2 months HIPAA Logs Friendly Reminder!';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'LogFriendlyReminderEmail',
            'start' => now(),
        ]);
        try {
            $locations = Location::whereHas('user', function ($query) {
                $query->where('account_status', 'Unfrozen')->where('is_active', '1')->where('is_account_verified', '1')->where('is_sra_user', 0);
            })
                ->with(['hipaaComplianceOfficer.hco', 'accountLocationAccess.accountUser'])->get();
            $emailTemplate = EmailTemplate::where('code', 'HCE-UE37')->first();
            $delayTime = Carbon::today()->format('Y-m-d') .' '. Config::get('app.send_email_delay_time');
            foreach ($locations as $loc) {
                try {
                    if ($loc->hipaaComplianceOfficer) {
                        $loc_created_date = Carbon::parse($loc->created_at);
                        $today_date = Carbon::now();
                        $diff_in_days = $loc_created_date->diffInDays($today_date);
                        if ($diff_in_days > 0 && ($diff_in_days % 60) == 0) {
                            $email_send_hcouser_list = [];
                            $hco = $loc->hipaaComplianceOfficer;
                            if ($hco) {
                                $email_send_hcouser_list[] = ['first_name' => $hco->hco->first_name, 'email' => $hco->hco->email];
                            }
                            $account_users_list = $loc->accountLocationAccess;
                            foreach ($account_users_list as $key => $value) {
                                try{
                                    if ($hco && $value->accountUser->email != $hco->hco->email) {
                                        $email_send_hcouser_list[] = ['first_name' => $value->accountUser->first_name, 'email' => $value->accountUser->email];
                                    }
                                    if (! $hco) {
                                        $email_send_hcouser_list[] = ['first_name' => $value->accountUser->first_name, 'email' => $value->accountUser->email];
                                    }
                                } catch (\Exception $e) {
                                    Log::error('LogFriendlyReminderEmail/handle()[account_users_error] => '.$e->getMessage());
                                    Log::error('LogFriendlyReminderEmail/handle()[account_users_data] => '.json_encode($value));
                                }
                            } 
                            foreach ($email_send_hcouser_list as $key => $value) {
                                try{
                                    $email_vars = [
                                        '{%FIRST_NAME%}' => $value['first_name'],
                                        '{%LOGIN_TO_ABYDE%}' => Config::get('app.url'),
                                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                    ];
                                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                    $this->sendEmail($emailTemplate->code, $html, $value['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($loc->user->partner_reseller_id != null ? $loc->user->reseller->logo : null), $loc->user->id, null, $delayTime);
                                } catch (\Exception $e) {
                                    Log::error('LogFriendlyReminderEmail/handle()[email_send_hcouser_error] => '.$e->getMessage());
                                    Log::error('LogFriendlyReminderEmail/handle()[email_send_hcouser_data] => '.json_encode($value));
                                }
                            }
                        }
                    }
                } catch (\Exception $e) {
                    Log::error('LogFriendlyReminderEmail/handle()[locations_error] => '.$e->getMessage());
                    Log::error('LogFriendlyReminderEmail/handle()[locations_data] => '.json_encode($loc));
                }
            }
        } catch (\Exception $e) {
            Log::error('LogFriendlyReminderEmail/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
