<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\EmailTemplate;
use App\Models\Location;
use App\Models\RiskAnalysisQuestion;
use App\Traits\Notification;
use App\Traits\SendMail;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class ChangeComputerPasswordReminder extends Command
{
    use Notification, SendMail;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'change_computer_password_reminder:notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Notification will be send every 6 months if Q34=A7, every 4 months if Q34=A8, otherwise never';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $cron_excecution = CronExcecution::create([
            'name' => 'ChangeComputerPasswordReminder',
            'start' => now(),
        ]);
        try {
            $location_list = Location::with(['sraModuleCompleted', 'user.reseller', 'accountLocationAccess.accountUser', 'hipaaComplianceOfficer.hco'])
                ->whereHas('sraModuleCompleted', function ($query) {
                    $query->where('is_completed', '1');
                })
                ->get();
            if (! empty($location_list)) {
                $emailTemplate = EmailTemplate::where('code', 'HCE-UE35')->first();
                $notification_HCE_AN16 = $this->getNotificationByCode('HCE-AN16');
                $delayTime = Carbon::today()->format('Y-m-d') .' '. Config::get('app.send_email_delay_time');
                foreach ($location_list as $loc) {
                    try{
                        $email_send_hcouser_list = [];
                        $hco = $loc->hipaaComplianceOfficer;
                        if ($hco) {
                            $email_send_hcouser_list[] = ['first_name' => $hco->hco->first_name, 'email' => $hco->hco->email];
                        }
                        $account_users_list = $loc->accountLocationAccess;
                        foreach ($account_users_list as $key => $value) {
                            if ($hco && $value->accountUser->email != $hco->hco->email) {
                                $email_send_hcouser_list[] = ['first_name' => $value->accountUser->first_name, 'email' => $value->accountUser->email];
                            }
                            if (! $hco) {
                                $email_send_hcouser_list[] = ['first_name' => $value->accountUser->first_name, 'email' => $value->accountUser->email];
                            }
                        }
                        $notification_data = [
                            'location_id' => $loc['id'],
                            'notification_id' => $notification_HCE_AN16['id'],
                        ];
                        $prev_notification = $this->getPreviousNotificationAdded($notification_HCE_AN16->code, $loc['id']);
                        if ($prev_notification) {
                            $previous_date = $prev_notification->created_at;
                        } else {
                            $previous_date = $loc->created_at;
                        }
                        $today = Carbon::today()->format('Y-m-d');
                        $date_after6_months = Carbon::parse($previous_date)->addMonths(6)->format('Y-m-d');
                        $date_after4_months = Carbon::parse($previous_date)->addMonths(4)->format('Y-m-d');

                        $check_Q34_answer = RiskAnalysisQuestion::where('question_code', 'Q34')
                            ->whereHas('riskAnalysisAttemptedQuestion', function ($que) use ($loc) {
                                $que->where(['location_id' => $loc->id]);
                            })
                            ->with(
                                ['riskAnalysisAttemptedQuestion' => function ($que) use ($loc) {
                                    return $que->where('location_id', $loc->id)
                                        ->with('attemptedQuestionAnswer.answerContent');
                                }]
                            )->first();
                        $email_send_hcouser_list = array_unique($email_send_hcouser_list, SORT_REGULAR);
                        if ($check_Q34_answer['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A7') {
                            if ($date_after6_months == $today) {
                                $this->createNotification($notification_data);
                                foreach ($email_send_hcouser_list as $value) {
                                    $email_vars = [
                                        '{%FIRST_NAME%}' => $value['first_name'],
                                        '{%Q34_ANSWER%}' => $check_Q34_answer['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer'],
                                        '{%GO_TO_NOTIFICATIONS%}' => Config::get('app.url'),
                                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                    ];
                                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                    if ($loc->user->account_status == 'Unfrozen' && $loc->user->is_active == '1' && $loc->user->is_account_verified == '1') {
                                        $this->sendEmail($emailTemplate->code, $html, $value['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($loc->user->partner_reseller_id != null ? $loc->user->reseller->logo : null), $loc->user->id, null, $delayTime);
                                    }
                                }
                            }
                        } elseif ($check_Q34_answer['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer_code'] == 'A8') {
                            if ($date_after4_months == $today) {
                                $this->createNotification($notification_data);
                                foreach ($email_send_hcouser_list as $value) {
                                    $email_vars = [
                                        '{%FIRST_NAME%}' => $value['first_name'],
                                        '{%Q34_ANSWER%}' => $check_Q34_answer['riskAnalysisAttemptedQuestion'][0]['attemptedQuestionAnswer'][0]['answerContent']['answer'],
                                        '{%GO_TO_NOTIFICATIONS%}' => Config::get('app.url'),
                                        '{%SUPPORT_EMAIL%}' => Config::get('app.support_email'),
                                    ];
                                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                                    if ($loc->user->account_status == 'Unfrozen' && $loc->user->is_active == '1' && $loc->user->is_account_verified == '1') {
                                        $this->sendEmail($emailTemplate->code, $html, $value['email'], Config::get('app.from_user_email'), $emailTemplate->subject, null, null, true, ($loc->user->partner_reseller_id != null ? $loc->user->reseller->logo : null), $loc->user->id);
                                    }
                                }
                            }
                        }
                    } catch (\Exception $e) {
                        Log::error('ChangeComputerPasswordReminder/handle()[location_list_error] => '.$e->getMessage());
                        Log::error('ChangeComputerPasswordReminder/handle()[location_list_data] => '.json_encode($loc));
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error('ChangeComputerPasswordReminder/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
