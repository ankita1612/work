<?php

namespace App\Console\Commands;

use App\Models\CronExcecution;
use App\Models\User;
use ChargeBee\ChargeBee\Environment;
use ChargeBee\ChargeBee\Models\Customer;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

class RemoveSalesTaxForResellerScript extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:remove-sales-tax-for-reseller-script';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Remove sales tax for reseller script';

    /**
     * Execute the console command.
     */
    public function handle()
    {
         $cron_excecution = CronExcecution::create([
            'name' => 'RemoveSalesTaxForResellerScript',
            'start' => now(),
        ]);
        try {
            $users = User::where('partner_reseller_id','!=', NULL)->get();
            Environment::configure(Config::get('app.chargebee_site'), Config::get('app.chargebee_api_key'));
            foreach($users as $user){
                Customer::update($user->chargebee_customer_id,array(
                    "taxability" => "exempt",
                )); 
            }
        } catch (\Exception $e) {
            Log::error('RemoveSalesTaxForResellerScript/handle() => '.$e->getMessage());
        }
        $cron_excecution->update([
            'end' => now(),
        ]);
    }
}
