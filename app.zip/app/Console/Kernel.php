<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule)
    {
        /**
         * DAILY CRONJOBS
         */

        // Check next remind date for attempted questions and add those to OG section
        $schedule->command('check:ongoing')->dailyAt('01:10')->environments(['staging', 'production']);

        // check trash file and folder and delete permanently
        $schedule->command('abydedrive:trash')->dailyAt('01:20')->environments(['staging', 'production']);

        // Clear laravel cache daily for better operation
        $schedule->command('app:clear')->dailyAt('01:30')->environments(['staging', 'production']);

        // reminder 60 days before the expiration date of BA agreement
        $schedule->command('ba_agreement_expiration_reminder:notification')->dailyAt('01:40')->environments(['staging', 'production']);

        // open training for location current year & 2 months before contract renewal
        $schedule->command('add:trainingLocation')->dailyAt('01:50')->environments(['staging', 'production']);

        // send invitation for schedule training (schedule by default or set by user)
        $schedule->command('all:traininginvite')->dailyAt('14:00')->environments(['staging', 'production']);

        // send reminder to hco before one month of schedule training
        $schedule->command('send:trainingremindermail')->dailyAt('04:00')->environments(['staging', 'production']);

        // send email every 45 days if there are open notifications
        // $schedule->command('general_reminder:email')->dailyAt('04:20')->environments(['staging', 'production']);

        // clear generated temporary documents
        $schedule->command('tempdocs:clear')->dailyAt('01:00')->environments(['staging', 'production']);

        // reminder 3 days after the Breach Log submission if Breach RA has not yet been completed
        $schedule->command('complete_breach_risk_assessment_reminder:notification')->dailyAt('04:50')->environments(['staging', 'production']);

        // reminder 6 months if Q34=A7, every 4 months if Q34=A8
        $schedule->command('change_computer_password_reminder:notification')->dailyAt('05:00')->environments(['staging', 'production']);

        //Update Access Authorization for Each Employee
        $schedule->command('update_access_authorization_reminder:notification')->dailyAt('05:10')->environments(['staging', 'production']);

        // Employee delete access update reminder
        $schedule->command('employee_delete_access_update_reminder:email_notification')->dailyAt('05:20')->environments(['staging', 'production']);

        // HIPAA Logs Friendly Reminder
        $schedule->command('log_friendly_reminder:email')->dailyAt('05:30')->environments(['staging', 'production']);

        // User scheduled status change
        $schedule->command('user_schedule_status_change:status_change')->dailyAt('05:40')->environments(['staging', 'production']);

        // Send upcoming renewal reminder notification
        $schedule->command('upcoming_renewal_reminder:notification')->dailyAt('05:50')->environments(['staging', 'production']);

        // Schedule chargbee subscription addon changes at next renewal on first contract end date
        $schedule->command('addon-update:on-first-contract-end-date')->dailyAt('23:00')->environments(['staging', 'production']);

        /**
         * OTHER CRONJOBS
         */

        // Generate SRA scorecard on every last of the month
        $schedule->command('scorecard:history')->lastDayOfMonth('07:00')->environments(['staging', 'production']);

        // Generate Hipaa training report and send to hco on every last of the month
        $schedule->command('genratereport:monthlyhipaatraining')->lastDayOfMonth('08:00')->environments(['staging', 'production']);

        // Send complete ongoing compliance notification first day of every month
        $schedule->command('complete_ongoing_Compliance:notification')->monthlyOn(1, '20:00')->environments(['staging', 'production']);

        // archive current year breach log at end day of every year
        $schedule->command('archive:breachlog')->yearlyOn(12, 31, '22:00')->environments(['staging', 'production']);

        // if SRA, OG % changed then send location data to sales force
        $schedule->command('sendlocationsraog:salesforce')->everySixHours()->environments(['staging', 'production']);
    }

    /**
     * Get the timezone that should be used by default for scheduled events.
     *
     * @return \DateTimeZone|string|null
     */
    protected function scheduleTimezone()
    {
        return 'UTC';
    }

    /**
     * Register the commands for the application.
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
