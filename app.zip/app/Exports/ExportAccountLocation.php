<?php

namespace App\Exports;

use App\Http\Controllers\App\OngoingComplianceController;
use App\Http\Controllers\App\SecurityRiskAnalysisController;
use App\Models\AccountUser;
use App\Models\Employee;
use App\Models\HipaaComplianceOfficer;
use App\Models\Location;
use App\Models\Student;
use App\Models\Training;
use App\Models\User;
use App\Traits\PricingHelper;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;

class ExportAccountLocation implements FromView, ShouldAutoSize, WithBatchInserts, WithChunkReading
{
    use PricingHelper;

    public $trainings = null;

    protected $offset;

    protected $limit;

    public function __construct($offset, $limit)
    {
        $this->offset = $offset;
        $this->limit = $limit;
    }

    public function view(): View
    {
        $this->trainings = Training::select(['id', 'training_code', 'title', 'who_can_train', 'training_type'])
            ->where('is_active', true)
            ->get();

        $all_location_details = Location::with([
            'accountLocationAccess',
            'hipaaComplianceOfficer.hco',
            'sraModuleCompleted',
            'user.businessAssociates',
            'trainingLocation',
        ])
            ->withCount('companyModuleCompleted')
            ->withCount('businessAssociatesUser')
            ->withCount('high_risk')
            ->withCount('medium_risk')
            ->withCount('low_risk')
            ->withCount('employeePrimaryWorkLocation')
            ->withCount('employeeSecondaryWorkLocation')
            ->withCount('openNotificationsWithoutLogin')
            ->withCount('disasterRecoveryPlanModuleCompleted')
            ->withCount('policyVersioning')
            ->orderBy('user_id', 'asc')
            ->skip($this->offset)
            ->take($this->limit)
            ->get();

        if ($all_location_details) {
            $all_location_details = $all_location_details->map(function ($location_details) {
                $sra = new SecurityRiskAnalysisController;
                $ongoing_compliance = new OngoingComplianceController;

                $sraStatus = isset($location_details->sraModuleCompleted) && ($location_details->sraModuleCompleted->is_completed == 1);
                $location_details['sra_percentage_count'] = ($sraStatus == true) ? (object) ['percentage' => 100] : $sra->getPercentageCount($location_details->id);
                $location_details['ongoing_compliance_percentage_count'] = ($sraStatus == true) ? $ongoing_compliance->getPercentageCount($location_details->id) : ['percentage' => 0];
                $location_details['employee_count'] = 'Locked';
                if (isset($location_details->hipaaComplianceOfficer) && $location_details->hipaaComplianceOfficer->count() > 0) {
                    $location_details['employee_count'] = ($location_details->employee_primary_work_location_count ?? 0) + ($location_details->employee_secondary_work_location_count ?? 0);
                    $location_details['employee_count'] = ($location_details['employee_count'] == 0) ? 'ADD' : $location_details['employee_count'];
                }

                $location_details['disaster_recovery'] = 'Locked';
                $location_details['hipaa_logs'] = 'Locked';
                $location_details['business_associates'] = 'Locked';
                $location_details['policy'] = 'Locked';

                if ($sraStatus == true) {
                    $location_details['disaster_recovery'] = ($location_details->disaster_recovery_plan_module_completed_count == 1) ? 'Complete' : 'Not Complete';
                    $location_details['hipaa_logs'] = 'Open';
                }

                if ($sraStatus == true && $location_details->disaster_recovery_plan_module_completed_count == 1) {
                    $location_details['business_associates'] = ($location_details->user->businessAssociates->count() > 0) ? 'Used' : 'Open';
                    $location_details['policy'] = 'Used';
                }
                $location_details['training_lists'] = $this->getTrainingEmployeeCount($location_details);

                return $location_details;
            });
        }

        return view('exports.accountlocation', [
            'trainings' => $this->trainings,
            'location_details' => $all_location_details,
        ]);
    }

    public function chunkSize(): int
    {
        return 50;
    }

    public function batchSize(): int
    {
        return 100;
    }

    public function getTrainingEmployeeCount($location)
    {
        $trainings_list = [];
        foreach ($this->trainings as $training) {
            $emp_student_list = [];
            if (isset($location->trainingLocation) && $location->trainingLocation->where('training_id', $training->id)->count() > 0) {
                if ($training) {
                    if ($training['who_can_train'] == 'hco') {
                        $hco_list = HipaaComplianceOfficer::where('location_id', $location->id)->first();
                        if (isset($hco_list)) {
                            if ($hco_list->hco_type == \App\Models\AccountUser::class) {
                                $hco_data = AccountUser::select(['id', 'first_name', DB::raw("'hco' AS emp_type")])
                                    ->where('id', $hco_list->hco_id)
                                    ->with([
                                        'TrainingInvite' => function ($qry) use ($training) {
                                            $qry->where('training_id', $training['id']);
                                        },
                                    ])
                                    ->first()->toArray();
                            }
                            if ($hco_list->hco_type == \App\Models\User::class) {
                                $hco_data = User::select(['id', DB::raw("'hco' AS emp_type")])
                                    ->where('id', $hco_list->hco_id)
                                    ->with([
                                        'TrainingInvite' => function ($qry) use ($training) {
                                            $qry->where('training_id', $training['id']);
                                        },

                                    ])->first()->toArray();
                            }

                            $hco_data['is_video_quiz_completed'] = (isset($hco_data['training_invite']) && $hco_data['training_invite']['completed_attempt_id'] && $hco_data['training_invite']['completed_datetime']) ? true : false;
                            $emp_list = Employee::select(['id', 'first_name', 'primary_work_location_id'])
                                ->where('primary_work_location_id', $location->id)
                                ->get();
                            if (count($emp_list) > 0) {
                                $emp_student_list[] = $hco_data;
                            }
                        }
                    }
                    if ($training['who_can_train'] == 'employee') {
                        $emp_list = Employee::select(['id',  'first_name', 'primary_work_location_id', DB::raw('IF(primary_work_location_id = "'.$location->id.'" , "primary" , "secondary") AS emp_type')])
                            ->where('primary_work_location_id', $location->id)
                            ->orWhereHas('employeeSecondaryWorkLocation', function ($query) use ($location) {
                                return $query->where('location_id', $location->id);
                            })
                            ->with([
                                'TrainingInvite' => function ($qry) use ($training) {
                                    $qry->where('training_id', $training['id']);
                                },
                            ])
                            ->get()->toArray();
                        if (count($emp_list) > 0) {
                            foreach ($emp_list as $emp_object) {
                                $emp_object['is_video_quiz_completed'] = (isset($emp_object['training_invite']) && $emp_object['training_invite']['completed_attempt_id'] && $emp_object['training_invite']['completed_datetime']) ? true : false;
                                $emp_student_list[] = $emp_object;
                            }
                        }
                    }
                    if ($training['who_can_train'] == 'student') {
                        $student_list = Student::select(['id', 'first_name', 'last_name', 'class_id', 'email', 'primary_work_location_id'])
                            ->where('primary_work_location_id', $location->id)
                            ->with([
                                'TrainingInvite' => function ($qry) use ($training) {
                                    $qry->where('training_id', $training['id']);
                                },
                                'studentClass',
                            ])
                            ->get()->toArray();

                        if (count($student_list) > 0) {
                            foreach ($student_list as $student_object) {
                                $student_object['is_video_quiz_completed'] = (isset($student_object['training_invite']) && $student_object['training_invite']['completed_attempt_id'] && $student_object['training_invite']['completed_datetime']) ? true : false;
                                $emp_student_list[] = $student_object;
                            }
                        }
                    }
                }
                $trainings_list[$training->id] = [
                    'completed' => collect($emp_student_list)->where('is_video_quiz_completed', true)->count(),
                    'not_completed' => collect($emp_student_list)->where('is_video_quiz_completed', false)->count(),
                ];
            } else {
                $trainings_list[$training->title] = [
                    'completed' => 'NA',
                    'not_completed' => 'NA',
                ];
            }
        }

        return $trainings_list;
    }
}
