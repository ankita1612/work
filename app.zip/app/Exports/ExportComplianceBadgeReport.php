<?php

namespace App\Exports;

use App\Models\{Training, TrainingLocation, TrainingInvite, Location};
use Carbon\Carbon;
use Maatwebsite\Excel\Concerns\FromView;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class ExportComplianceBadgeReport implements FromView, ShouldAutoSize
{
    protected $requestData;
    public function __construct($requestData)
    {
        $this->requestData = $requestData;
    }
    public function view(): View
    {
        // ini_set('max_execution_time', 7200); // 3600 seconds = 60 minutes
        // set_time_limit(7200);
        
        $location_list = Location::select(['id', 'location_nickname', 'user_id'])
            ->with([
                'user' => function ($query) {
                    $query->where('is_active', '1');
                },'hipaaComplianceOfficer'
            ])
            ->whereHas('user', function ($query) {
                $query->where('is_active', '1');
            })
            ->withCount([
                'disasterRecoveryPlanModuleCompleted',
                'sraModuleCompleted',
                'hipaaComplianceOfficer',
                'activeEmployeePrimaryWorkLocation'
            ])
        ->orderBy('user_id','asc')
        ->skip(0)
        ->take(1)
        ->get();

        //dd($location_list);        

        foreach ($location_list as $key => $val) {
            try{
                $location_list[$key]['company_name'] = $val->user->company_name;
                $location_list[$key]['user_name'] = $val->user->first_name . " " . $val->user->last_name;
                $location_list[$key]['email'] = $val->user->email;

                if (($val->sra_module_completed_count == 1)) {
                    $location_list[$key]['sra'] =  "Completed";
                }
                if ($val->disaster_recovery_plan_module_completed_count == 1) {
                    $location_list[$key]['drp'] =  "Completed";
                }

                if ($val->hipaa_compliance_officer_count == 1 && $val->active_employee_primary_work_location_count > 0) {

                    $hco_training_location_list = TrainingLocation::where('location_id', $val->id)
                        ->whereHas('training', function ($query) {
                            $query->where('who_can_train', 'hco')->isActive();
                        })
                        ->where('is_triggered', 1)
                        ->where('is_disable', 0)
                        ->pluck('training_id');

                    if ($hco_training_location_list->isNotEmpty()) {
                        $start_date = '2024-01-01 00:00:00';
                        $end_date = '2025-04-08 23:59:59';
                        $hco_training_invite_completed = TrainingInvite::where([
                            'emp_user_acntuser_student_id' => $val->hipaaComplianceOfficer->hco_id,
                            'emp_user_acntuser_student_type' => $val->hipaaComplianceOfficer->hco_type,
                        ])
                        ->whereBetween('completed_datetime', [$start_date, $end_date])
                        // ->whereYear('completed_datetime', 2024)
                        ->where('completed_attempt_id', '!=', null)
                        ->whereIn('training_id', $hco_training_location_list->toArray())
                        ->orderBy('completed_datetime', 'desc')  
                        ->first();
                    }

                    if ($hco_training_location_list->isNotEmpty() && $hco_training_invite_completed != null) {
                        $location_list[$key]['training'] = "Unlocked";
                        $location_list[$key]['hco_training_last_complete_date'] = Carbon::parse($hco_training_invite_completed['completed_datetime'])->format('m/d/Y');
                    }else{
                        $location_list[$key]['hco_training_last_complete_date'] = null;
                    }
                }
            } catch (\Exception $e) {
                Log::error('ExportComplianceBadgeReport/handle()[location_error] => '.$e->getMessage());
                Log::error('ExportComplianceBadgeReport/handle()[location_data] => '.json_encode($val));
            }
        }
        return view('exports.compliancebadgereport', [
            'location_list' => $location_list
        ]);
    }
}