<?php

namespace App\Exports;

use App\Models\Location;
use App\Models\Training;
use Carbon\Carbon;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ExportTrainingReportForOldUser implements FromView, ShouldAutoSize, WithStyles
{
    public function view(): View
    {
        $training = Training::where('training_code', 'HT5')->isActive()->first();
        $locations = Location::with('user')->whereNotNull('old_hipaa_id')->whereDoesntHave('trainingLocation', function ($query) use ($training) {
            $query->where('training_id', $training['id']);
        })->get();
        $path = public_path('tbl_user_notification.json');
        $contents = File::get($path);
        $tbl_user_notification_data = collect(json_decode($contents))->values();
        $report_data = [];
        $i = 0;
        foreach ($locations as $location) {
            $verification_date = $tbl_user_notification_data->where('iReceiverID', $location['old_hipaa_id'])->first();
            if ($verification_date != null) {
                if (Carbon::createFromDate($verification_date->dNotificationDateTime)->addMonths(18)->format('Y-m-d') < '2024-01-01') {
                    $report_data[$i]['old_hipaa_id'] = $location['old_hipaa_id'];
                    $report_data[$i]['user_email'] = $location['user']['email'];
                    $report_data[$i]['location_name'] = $location['location_nickname'];
                    $report_data[$i]['trigger_date'] = Carbon::createFromDate($verification_date->dNotificationDateTime)->addMonths(18)->format('Y-m-d');
                }
            } else {
                if (Carbon::createFromDate($location['created_at'])->addMonths(18)->format('Y-m-d') < '2024-01-01') {
                    $report_data[$i]['old_hipaa_id'] = $location['old_hipaa_id'];
                    $report_data[$i]['user_email'] = $location['user']['email'];
                    $report_data[$i]['location_name'] = $location['location_nickname'];
                    $report_data[$i]['trigger_date'] = Carbon::createFromDate($location['created_at'])->addMonths(18)->format('Y-m-d');
                }
            }
            $i++;
        }

        return view('exports.trainingreportforolduser', [
            'report_data' => $report_data,
        ]);
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }
}
