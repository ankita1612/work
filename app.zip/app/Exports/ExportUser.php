<?php

namespace App\Exports;

use App\Http\Controllers\App\OngoingComplianceController;
use App\Http\Controllers\App\SecurityRiskAnalysisController;
use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ExportUser implements FromView, ShouldAutoSize, WithStyles
{
    public function __construct(string $year)
    {
        $this->year = $year;
    }

    public function view(): View
    {
        $auth_admin_data = auth()->user();
        $users = User::whereYear('created_at', $this->year)
            ->with([
                'locations' => function ($query) {
                    $query->with('hipaaComplianceOfficer.hco')
                        ->withCount('openNotificationsWithoutLogin')
                        ->withCount('companyModuleCompleted')
                        ->withCount('sraModuleCompleted')
                        ->withCount('disasterRecoveryPlanModuleCompleted')
                        ->withCount('accountLocationAccess')
                        ->withCount('employeePrimaryWorkLocation')
                        ->withCount('employeeSecondaryWorkLocation');
                },
                'lastLoginDetails', 'userTags','reseller'
            ])
            ->withCount('employees')
            ->withCount('BusinessAssociates')
            ->withCount('locations');

        if ($auth_admin_data->partner_reseller_id != null) {
            $users = $users->where('partner_reseller_id', $auth_admin_data->partner_reseller_id)->get();
        } else {
            $users = $users->get();
        }

        $sra = new SecurityRiskAnalysisController;
        $ongoing_compliance = new OngoingComplianceController;

        foreach ($users as $key_user => $user) {
            try{
                foreach ($user->locations as $key_loc => $location) {
                    try{
                        $users[$key_user]['locations'][$key_loc]['sra_percentage_count'] = $sra->getPercentageCount($location->id);
                        $users[$key_user]['locations'][$key_loc]['ongoing_compliance_percentage_count'] = $ongoing_compliance->getPercentageCount($location->id);
                    } catch (\Exception $e) {
                        Log::error('ExportUser/view()[locations_error] => '.$e->getMessage());
                        Log::error('ExportUser/view()[locations_data] => '.json_encode($location));
                    }
                }
                $tags = $user['userTags']->pluck('tag_name')->toArray();
                $users[$key_user]['userTags'] = implode(', ', $tags);
            } catch (\Exception $e) {
                Log::error('ExportUser/view()[users_error] => '.$e->getMessage());
                Log::error('ExportUser/view()[users_data] => '.json_encode($user));
            }
        }

        return view('exports.users', [
            'users' => $users,
        ]);
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }
}
