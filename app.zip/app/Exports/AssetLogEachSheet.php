<?php

namespace App\Exports;

use App\Models\AssetLog;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithTitle;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class AssetLogEachSheet implements FromView, ShouldAutoSize, WithStyles, WithTitle
{
    private $location_id;

    private $sheet_name;

    public function __construct(string $sheet_name, string $location_id)
    {
        $this->location_id = $location_id;
        $this->sheet_name = $sheet_name;
    }

    public function view(): View
    {
        $assetlogs = AssetLog::Where('location_id', $this->location_id)
            ->with([
                'deviceType:id,name',
                'operatingSystem:id,name',
                'assetEncryption:id,name',
                'ephiAccess:id,name',
                'operatingLocation:id,name',
                'assignedEmployee:id,first_name,last_name',
                'location:id,location_nickname',
                'disposalStatus:id,name',
            ]);
        if ($this->sheet_name == 'Active') {
            $assetlogs = $assetlogs->where('status', 'active');
        } else {
            $assetlogs = $assetlogs->where('status', 'inactive');
        }
        $assetlogs = $assetlogs->orderBy('created_at', 'desc')->get();

        return view('exports.assetlog', [
            'assetlogs' => $assetlogs,
            'sheet_name' => $this->sheet_name,
        ]);
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => [
                    'bold' => true,
                    'color' => ['argb' => Color::COLOR_WHITE],
                ],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'startColor' => ['argb' => '268ECD'],
                ],
            ],
        ];
    }

    public function title(): string
    {
        return $this->sheet_name.' Assets';
    }
}
