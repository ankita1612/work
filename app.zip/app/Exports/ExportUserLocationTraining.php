<?php

namespace App\Exports;

use App\Models\Location;
use App\Models\Training;
use App\Models\TrainingInvite;
use App\Models\TrainingLocation;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class ExportUserLocationTraining implements FromView, ShouldAutoSize
{
    public $trainings = null;

    protected $user;

    public function __construct($user)
    {
        $this->user = $user;
    }

    public function view(): View
    {
        $this->trainings = Training::select(['id', 'training_code', 'title', 'who_can_train', 'training_type'])
            ->where('is_active', 1)
            ->where('who_can_train', 'employee')
            ->get();
        $all_data_list = [];
        $location_list = Location::where('user_id', $this->user->id)
            ->with([
                'employeePrimaryWorkLocation',
            ])
            ->get();
        if (! empty($location_list) && count($location_list) > 0) {
            foreach ($location_list as $location) {
                foreach ($location->employeePrimaryWorkLocation as $employee) {
                    try{
                        $data['emp_name'] = $employee->first_name.' '.$employee->last_name;
                        $data['emp_email'] = $employee->email;
                        $data['location_name'] = $location->location_nickname ?? '';
                        $data['emp_trainings'] = $this->getTrainingEmployee($location->id, $employee->id);
                        $all_data_list[] = $data;
                    } catch (\Exception $e) {
                        Log::error('ExportUserLocationTraining/view()[employee_error] => '.$e->getMessage());
                        Log::error('ExportUserLocationTraining/view()[employee_data] => '.json_encode($employee));
                    }
                }
            }
        }

        return view('exports.useremployeetraining', [
            'trainings' => $this->trainings,
            'location_details' => $all_data_list,
        ]);
    }

    public function getTrainingEmployee($location_id, $employee_id)
    {
        $training_list = [];
        foreach ($this->trainings as $training) {
            $training_location = TrainingLocation::where('location_id', $location_id)
                ->where('training_id', $training->id)
                ->first();
            $training_data['training_id'] = $training->id;
            if (! empty($training_location)) {
                $training_invite = TrainingInvite::withCount('trainingAttempt')
                    ->where('emp_user_acntuser_student_id', $employee_id)->where('emp_user_acntuser_student_type', \App\Models\Employee::class)
                    ->where('training_id', $training->id)
                    ->latest()
                    ->first();
                $training_data['complete_date'] = ($training_invite && $training_invite->completed_datetime) ? date('d/m/Y', strtotime($training_invite->completed_datetime)) : '-';
            } else {
                $training_data['complete_date'] = 'NA';
            }
            $training_list[] = $training_data;
        }

        return $training_list;
    }
}
