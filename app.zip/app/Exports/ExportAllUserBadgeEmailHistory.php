<?php

namespace App\Exports;

use App\Models\UserBadgeEmailHistory;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class ExportAllUserBadgeEmailHistory implements FromCollection, WithHeadings, WithStyles, ShouldAutoSize
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return UserBadgeEmailHistory::with('user')->get()->map(function ($item) {
                return [
                    'user_name' => $item->user->first_name . ' '.$item->user->last_name ?? '',
                    'user_email' => $item->user->email ?? '',
                    'company_name' => $item->user->company_name ?? '',
                    'is_mail_send' => $item->is_mail_send ? 'Yes' : 'No',
                    'is_mail_open' => $item->is_mail_open ? 'Yes' : 'No',                    
                    'is_mail_attachment_download' =>($item->email_type == 'Badge'? $item->is_mail_attachment_download ? 'Yes' : 'No':'-'),
                    'is_popup_triggered' => $item->is_popup_triggered ? 'Yes' : 'No',
                    'is_popup_attachment_download' => ($item->email_type == 'Badge'? $item->is_popup_attachment_download ? 'Yes' : 'No':'-'),
                    'is_badge_email' => $item->email_type == 'Badge' ? 'Yes' : 'No',
                ];
            });
    }

    public function headings(): array
    {
        return [            
            'User Name', 
            'Email', 
            'Account Name', 
            'Email Received',
            'Email Opened', 
            'Email Downloaded Attachment', 
            'Popup Triggered',  
            'Popup Downloaded Attachment', 
            'Badge Email'
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]], // Row 1 = Header Row
        ];
    }
}
