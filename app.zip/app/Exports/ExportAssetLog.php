<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class ExportAssetLog implements WithMultipleSheets
{
    public function __construct(string $location_id)
    {
        $this->location_id = $location_id;
    }

    public function sheets(): array
    {
        return [
            new AssetLogEachSheet('Active', $this->location_id),
            new AssetLogEachSheet('Inactive', $this->location_id),
        ];
    }
}
