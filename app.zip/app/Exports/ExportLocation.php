<?php

namespace App\Exports;

use App\Http\Controllers\App\SecurityRiskAnalysisController;
use App\Models\User;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ExportLocation implements FromView, ShouldAutoSize, WithStyles
{
    public function view(): View
    {
        $users = User::where('account_status', 'Unfrozen')
            ->select(['id', 'email'])
            ->with(['locations'])->get();

        $sra = new SecurityRiskAnalysisController;

        foreach ($users as $key_user => $user) {
            foreach ($user->locations as $key_loc => $location) {
                $users[$key_user]['locations'][$key_loc]['sra_percentage_count'] = $sra->getPercentageCount($location->id);
            }
        }

        return view('exports.locations', [
            'users' => $users,
        ]);
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }
}
