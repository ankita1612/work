<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ExportHipaaTrainingReport implements FromView, ShouldAutoSize, WithEvents, WithStyles, WithTitle
{
    public function __construct($emp_list, $hco_data, $training_list, $location, $timezone)
    {
        $this->emp_list = $emp_list;
        $this->hco_data = $hco_data;
        $this->training_list = $training_list;
        $this->location = $location;
        $this->timezone = $timezone;
    }

    public function view(): View
    {
        return view('exports.hipaatrainingreport', [
            'emp_list' => $this->emp_list,
            'hco_data' => $this->hco_data,
            'training_list' => $this->training_list,
            'location' => $this->location,
            'timezone' => $this->timezone,
        ]);
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $lastColumn = $event->sheet->getHighestColumn();
                $lastRow = $event->sheet->getHighestRow();

                $range = 'A1:'.$lastColumn.$lastRow;

                $event->sheet->getStyle($range)->applyFromArray([
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                            'color' => ['argb' => '000000'],
                        ],
                    ],
                ]);
                $sheet = $event->sheet->getDelegate();
                // $sheet->getProtection()->setSheet(true); // Enable protection
                // $sheet->getProtection()->setPassword('Hipaa@123');
            },
        ];
    }

    public function title(): string
    {
        return $this->location->location_nickname;
    }
}
