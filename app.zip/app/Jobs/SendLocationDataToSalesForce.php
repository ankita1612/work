<?php

namespace App\Jobs;

use App\Traits\{SyncLocationDataWithSalesForce};
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Throwable;

class SendLocationDataToSalesForce implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, SyncLocationDataWithSalesForce;

    private $location_id = null;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($location_id)
    {
        $this->location_id = $location_id;
    }

    /**
     * Execute the job.
     */
    public function handle()
    {
        $sync_sales_force_data = $this->SyncLocationDataWithSalesForce($this->location_id);
    }

    /**
     * Handle a job failure.
     */
    public function failed(Throwable $exception)
    {
        Log::error('Background Job Failed(SendLocationDataToSalesForce): '.$this->location_id);
    }
}
