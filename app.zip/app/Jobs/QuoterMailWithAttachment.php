<?php

namespace App\Jobs;

use App\Http\Controllers\App\AbydeQuoterController;
use App\Models\AbydeProduct;
use App\Models\EmailTemplate;
use App\Models\Promocode;
use App\Models\Quoter;
use App\Models\SraOnlyLocationLimitPrice;
use App\Traits\PricingHelper;
use App\Traits\SendMail;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use Throwable;

class QuoterMailWithAttachment implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, PricingHelper, Queueable, SendMail, SerializesModels;

    private $quoter_id = null;

    private $show_locked_prices = null;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($quoter_id, $show_locked_prices)
    {
        $this->quoter_id = $quoter_id;
        $this->show_locked_prices = $show_locked_prices;
    }

    /**
     * Execute the job.
     */
    public function handle()
    {
        try {
            $last_id = $this->quoter_id;
            $show_locked_prices = $this->show_locked_prices;
            $quoter_data = Quoter::where('id', $last_id)
                ->with([
                    'location_limit_prices:id,limit,price',
                    'employee_limit_prices:id,limit,price',
                    'abyde_quoter_partners:id,name,logo',
                    'sale_reps:id,first_name,last_name,image,phone_number,email',
                    'quoter_abyde_product:abyde_product_id,quoter_id',
                ])->first();

            if (empty($quoter_data)) {
                throw new \Exception('Invalid quoter_id -->'.$last_id);
            }

            //calculate price                         
            $calculated_pricing= ($quoter_data['location_limit_type'] == \App\Models\SraOnlyLocationLimitPrice::class ? $this->calculateTotalPriceForSRA($quoter_data->location_limit_prices):  $this->calculateTotalPrice($quoter_data->employee_limit_prices, $quoter_data->location_limit_prices));            

            //check whether all products or not
            $total_products = AbydeProduct::count();

            //product prices calculation            
            $product_data = [];
            $product_data['product'] = [];
            $product_data['subtotal']['yearly'] = $product_data['subtotal']['monthly'] = $product_data['subtotal']['biannually'] = $product_data['subtotal']['quarterly'] = $product_data['total']['monthly'] = $product_data['total']['yearly'] =
            $product_data['total']['biannually'] = $product_data['total']['quarterly'] = $product_data['promocode_discount']['monthly'] = $product_data['promocode_discount']['yearly'] = $product_data['promocode_discount']['biannually'] = $product_data['promocode_discount']['quarterly'] = 0;

            if (count($quoter_data->quoter_abyde_product) > 0) {
                for ($i = 0; $i < count($quoter_data->quoter_abyde_product); $i++) {
                    $product_data['product'][$i]['description'] = $quoter_data->quoter_abyde_product[$i]->abyde_products->description;
                    $product_data['product'][$i]['name'] = $quoter_data->quoter_abyde_product[$i]->abyde_products->name;
                    $product_data['product'][$i]['code'] = $quoter_data->quoter_abyde_product[$i]->abyde_products->code;
                    $product_data['product'][$i]['product_category'] = $quoter_data->quoter_abyde_product[$i]->abyde_products->product_category;
                    $product_data['product'][$i]['monthly'] = $calculated_pricing['monthly_price'];
                    $product_data['product'][$i]['yearly'] = $calculated_pricing['yearly_price'];
                    $product_data['product'][$i]['biannually'] = $calculated_pricing['biannually_price'];
                    $product_data['product'][$i]['quarterly'] = $calculated_pricing['quarterly_price'];
                    $product_data['subtotal']['monthly'] += $calculated_pricing['monthly_price'];
                    $product_data['subtotal']['yearly'] += $calculated_pricing['yearly_price'];
                    $product_data['subtotal']['biannually'] += $calculated_pricing['biannually_price'];
                    $product_data['subtotal']['quarterly'] += $calculated_pricing['quarterly_price'];
                }
                $product_data['total']['monthly'] = $product_data['subtotal']['monthly'];
                $product_data['total']['yearly'] = $product_data['subtotal']['yearly'];
                $product_data['total']['biannually'] += $product_data['subtotal']['biannually'];
                $product_data['total']['quarterly'] += $product_data['subtotal']['quarterly'];

                $product_data['yearly_total']['monthly'] = $product_data['product'][0]['monthly'] * 12;
                $product_data['yearly_total']['yearly'] = $product_data['product'][0]['yearly'] * 12;
                $product_data['yearly_total']['biannually'] = $product_data['product'][0]['biannually'] * 12;
                $product_data['yearly_total']['quarterly'] = $product_data['product'][0]['quarterly'] * 12;

                $quoter_data = $quoter_data->toArray();
                $promocode_text = '';

                $file_product_name_arr = array_map(function ($value) {
                    return strtoupper($value['abyde_products']['code']);
                }, $quoter_data['quoter_abyde_product']);
                $product_category_arr = array_map(function ($value) {
                    return strtoupper($value['abyde_products']['product_category']);
                }, $quoter_data['quoter_abyde_product']);
                $code_arr = array_map(function ($value) {
                    return $value['abyde_products']['code'];
                }, $quoter_data['quoter_abyde_product']);

                $quoter_data['product_img'] = (in_array('hipaace', $code_arr) && in_array('oshahc', $code_arr) ? 'headerbg_hipaace_oshahc.png' : (in_array('hipaace', $code_arr) ? 'headerbg_hipaace.png' : (in_array('oshahc', $code_arr) ? 'headerbg_oshahc.png' : 
                (in_array('hipaacesraonly', $code_arr) ? 'headerbg_hipaacesraonly.png': 'headerbg_hipaaba.png'))));

                if ($quoter_data['promo_code'] != '') {                   

                    if (in_array('hipaace', $code_arr) || in_array('hipaacesraonly', $code_arr)) {                        
                        $promocode_data = Promocode::select('discount_percentage', 'promo_code')->where('promo_code', $quoter_data['promo_code'])->first();                        
                        $quoter_data['promocodes']['discount_percentage'] = $promocode_data->discount_percentage;
                        $quoter_data['promocodes']['promo_code'] = $promocode_data->promo_code;
                    }
                    if ((in_array('oshahc', $code_arr) && ! in_array('hipaace', $code_arr)) || in_array('hipaaba', $code_arr) && ! in_array('hipaace', $code_arr) && ! in_array('oshahc', $code_arr)) {
                        $quoter_obj = new AbydeQuoterController;
                        if (in_array('oshahc', $code_arr) && ! in_array('hipaace', $code_arr)) {
                            $result_json = $quoter_obj->fetchPromocodeDiscount('oshahc', $quoter_data['promo_code']);
                        }
                        if (in_array('hipaaba', $code_arr) && ! in_array('hipaace', $code_arr) && ! in_array('oshahc', $code_arr)) {
                            $result_json = $quoter_obj->fetchPromocodeDiscount('hipaaba', $quoter_data['promo_code']);
                        }

                        if ($result_json['status'] == 'Error') {
                            return $this->error(Config::get('constants.QUOTER.POMOCODE_NOT_VALID'), 200);
                        } else {
                            $quoter_data['promocodes']['discount_percentage'] = $result_json['promocodes']['discount_percentage'];
                            $quoter_data['promocodes']['promo_code'] = $result_json['promocodes']['promo_code'];
                        }
                    }
                    $product_data['promocode_discount']['monthly'] = $product_data['total']['monthly'] * ($quoter_data['promocodes']['discount_percentage'] / 100);
                    $product_data['promocode_discount']['yearly'] = $product_data['total']['yearly'] * ($quoter_data['promocodes']['discount_percentage'] / 100);
                    $product_data['promocode_discount']['biannually'] = $product_data['total']['biannually'] * ($quoter_data['promocodes']['discount_percentage'] / 100);
                    $product_data['promocode_discount']['quarterly'] = $product_data['total']['quarterly'] * ($quoter_data['promocodes']['discount_percentage'] / 100);
                } else {
                    $quoter_data['promocodes'] = [];
                }
                $product_data['total']['monthly'] -= $product_data['promocode_discount']['monthly'];
                $product_data['total']['yearly'] -= $product_data['promocode_discount']['yearly'];
                $product_data['total']['biannually'] -= $product_data['promocode_discount']['biannually'];
                $product_data['total']['quarterly'] -= $product_data['promocode_discount']['quarterly'];
            }

            $product_data['total']['yearly'] = $product_data['total']['yearly'];
            $product_data['total']['biannually'] = $product_data['total']['biannually'];
            $product_data['total']['quarterly'] = $product_data['total']['quarterly'];
            $product_data['subtotal']['yearly'] = $product_data['subtotal']['yearly'];
            $product_data['subtotal']['biannually'] = $product_data['subtotal']['biannually'];
            $product_data['subtotal']['quarterly'] = $product_data['subtotal']['quarterly'];
            $product_data['promocode_discount']['yearly'] = $product_data['promocode_discount']['yearly'];
            $product_data['promocode_discount']['biannually'] = $product_data['promocode_discount']['biannually'];
            $product_data['promocode_discount']['quarterly'] = $product_data['promocode_discount']['quarterly'];
            $data['show_locked_prices'] = $show_locked_prices;
            $data['quoter_data'] = $quoter_data;
            $data['calculated_pricing'] = $calculated_pricing;
            $data['product_data'] = $product_data;
            $data['product_code_arr'] = $code_arr;

            $file_name = 'Abyde_';
            $file_name .= implode('_', $file_product_name_arr);
            $file_name .= '_Quote_'.date('ymdHis');

            $pdf = PDF::loadView('reports/quoterAttachment', compact('data'));
            $attachment = $file_name = storage_path('app/public').'/quoter_pdf/'.$file_name.'.pdf';
            $pdf->save($file_name);

            $email_code = ($quoter_data['is_abyde_sale_rep'] == 'yes' ? 'HCE-UE49' : 'HCE-UE50');

            $emailTemplate = EmailTemplate::where('code', $email_code)->first();

            $selected_product = implode('/', $product_category_arr);

            $email_vars = [
                '{%QUOTER_NAME%}' => $data['quoter_data']['quote_name'],
                '{%ABYDE_URL%}' => Config::get('app.wordpress_url'),
                '{%SELECTED_PRODUCT%}' => $selected_product,                
            ];
            $email_vars['{%PARTNER_PROMOCODE_TEXT%}'] = "";
            $email_vars['{%PROMOCODE_TEXT%}']= '';
            if($quoter_data['is_abyde_sale_rep'] == 'yes')
            {                
                if (! empty($quoter_data['promo_code'])) { // yes promocdoe
                    $email_vars['{%PROMOCODE_TEXT%}'] = ' and enter your promo code to take advantage of the special pricing';
                    if ( $quoter_data['abyde_quoter_partners']['id'] == 63) { //no partner
                        $email_vars['{%PARTNER_PROMOCODE_TEXT%}'] = "Please take a moment to review the attached quote with your special discount promo code. I’ve also attached additional information on how Abyde can help make compliance stress-free for your organization.";                           
                    } 
                    else{ //other partner  
                         $email_vars['{%PARTNER_PROMOCODE_TEXT%}'] = "Please take a moment to review the attached quote with your special ".$quoter_data['abyde_quoter_partners']['name']." discount promo code. I’ve also attached additional information on how Abyde can help make compliance stress-free for your organization.";                        
                    }
                }
                else{ //no promocode                     
                    $email_vars['{%PARTNER_PROMOCODE_TEXT%}'] = "Please take a moment to review the attached quote. I’ve also attached additional information on how Abyde can help make compliance stress-free for your organization.";                    
                }                              
            }
            else
            {
                if (empty($quoter_data['promo_code'])) {                    
                    $email_vars['{%PARTNER_PROMOCODE_TEXT%}'] = "Please take a moment to review the attached quote. Also attached is additional information on how Abyde can help make compliance stress-free for your organization."; 
                    $email_vars['{%PROMOCODE_TEXT%}'] = "";                       
                } else {
                    $email_vars['{%PARTNER_PROMOCODE_TEXT%}'] = "Please take a moment to review the attached quote with your special discount promo code. Also attached is additional information on how Abyde can help make compliance stress-free for your organization.";
                    $email_vars['{%PROMOCODE_TEXT%}'] = " and enter your promo code to take advantage of the special pricing";
                }      
            }

            if (! empty($quoter_data['sale_reps'])) {
                $email_vars['{%SALES_REPRESENTATIVE%}'] = $quoter_data['sale_reps']['first_name'].' '.$quoter_data['sale_reps']['last_name'];
            } else {
                $email_vars['{%SALES_REPRESENTATIVE%}'] = 'Abyde';
                $email_vars['{%APP_URL%}'] = Config::get('app.url');
            }
            $subject_vars = [
                '{%SELECTED_PRODUCT%}' => $selected_product,
            ];

            $cc_email = [];
            if ($quoter_data['is_abyde_sale_rep'] == 'yes' && $quoter_data['sale_reps']['email'] != '') {
                $cc_email[0] = $quoter_data['sale_reps']['email'];
            } else {
                $cc_email[0] = Config::get('app.info_email');
            }
            if (! (Config::get('app.env') == 'production')) {
                $cc_email[0] = 'dev4@abyde.com';
            }
            $subject = str_ireplace(array_keys($subject_vars), array_values($subject_vars), $emailTemplate->subject);
            $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
            $this->sendEmail($emailTemplate->code, $html, $quoter_data['quote_company_email'], Config::get('app.from_user_email'), $subject, $attachment, $cc_email, false);
        } catch (\Exception $e) {
            Log::error('job/QuoterMailWithAttachment for id =>'.$last_id.'  error => '.$e->getMessage());
            Log::error('job/QuoterMailWithAttachment for Line error=> '.$e->getLine());        
        }
    }

    /**
     * Handle a job failure.
     */
    public function failed(Throwable $exception)
    {
        Log::error('Background Job Failed(QuoterMailWithAttachment): '.$this->quoter_id);
    }
}
