<?php

namespace App\Jobs;

use App\Models\AbydeDriveArchiveFile;
use App\Models\AbydeDriveArchiveFolder;
use App\Models\AbydeDriveArchiveFolderLocation;
use App\Models\Location;
use App\Models\TrainingLocation;
use App\Traits\FileUpload;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Throwable;

class MoveEmployeeCertificateToAbydeDrive implements ShouldQueue
{
    use Dispatchable, FileUpload, InteractsWithQueue, Queueable, SerializesModels;

    private $employee = null;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($employee)
    {
        $this->employee = $employee;
    }

    /**
     * Execute the job.
     */
    public function handle()
    {
        $public_path = public_path();
        $storage_path = storage_path('app/public');
        $abyde_drive_folder = AbydeDriveArchiveFolder::where('folder_name', 'Employees')->first();
        $emp_all_location_ids = [$this->employee['primary_work_location_id']];
        foreach ($this->employee['employee_secondary_work_location'] as $SWL) {
            $emp_all_location_ids[] = $SWL['location_id'];
        }
        foreach ($this->employee['training_invites'] as $training_invite) {
            try{
                DB::beginTransaction();
                if ($training_invite['ref_token'] == '' && $training_invite['completed_datetime'] != null && $training_invite['completed_attempt_id'] != null) {
                    $is_training_open = TrainingLocation::where('location_id', $this->employee['primary_work_location_id'])->where('training_id', $training_invite['training_id'])->first();
                    if ($is_training_open) {
                        $location = Location::find($this->employee['primary_work_location_id']);
                        $complete_date = date('F d,Y', strtotime($training_invite['completed_datetime']));
                        $file = public_path('policydocuments/TrainingCertificate.docx');
                        $phpword = new \PhpOffice\PhpWord\TemplateProcessor($file);
                        $phpword->setValue('EMPLOYEE_NAME', htmlspecialchars($this->employee['first_name']).' '.htmlspecialchars($this->employee['last_name']));
                        $phpword->setValue('TRAINING_MODULE_NAME', htmlspecialchars($training_invite['training']['title']));
                        $phpword->setValue('DATE', $complete_date);
                        $phpword->setValue('COMPANY_NAME', htmlspecialchars($location->company_name));
                        $employee_first_name = str_replace(' ', '_', trim($this->employee['first_name']));
                        $employee_first_name = preg_replace('/[^A-Za-z0-9\-\_]/', '', $employee_first_name);
                        $employee_last_name = str_replace(' ', '_', trim($this->employee['last_name']));
                        $employee_last_name = preg_replace('/[^A-Za-z0-9\-\_]/', '', $employee_last_name);
                        $generated_training_certificate = $storage_path.'/generatedpolicydocuments/'.$employee_first_name.'_'.$employee_last_name.'_TrainingCertificate_'.$training_invite['id'].'.docx';
                        $phpword->saveAs($generated_training_certificate);
                        $generated_certificate_directory_path = $storage_path.'/generatedpolicydocuments/';
                        if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                            // change libreoffice path as per installation path from your machine
                            exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  '.$generated_certificate_directory_path.' '.$generated_training_certificate);
                        } else {
                            exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir '.$generated_certificate_directory_path.' '.$generated_training_certificate);
                        }
                        // unlink($generated_training_certificate);
                        $contents = \File::get($storage_path.'/generatedpolicydocuments/'.$employee_first_name.'_'.$employee_last_name.'_TrainingCertificate_'.$training_invite['id'].'.pdf');
                        $new_file = '/abyde_drive_archive/employees/'.$this->employee['user_id'].'/'.$employee_first_name.'_'.$employee_last_name.'_TrainingCertificate_'.$training_invite['id'].'_'.$location->id.'.pdf';
                        Storage::disk('s3')->put($new_file, $contents);
                        $file_size = $this->getReadableFilesize(Storage::disk('s3')->size($new_file));
                        $title = $employee_first_name.'_'.$employee_last_name.'_TrainingCertificate_'.$training_invite['id'].'_'.$location->id;
                        $new_file_name = $employee_first_name.'_'.$employee_last_name.'_TrainingCertificate_'.$training_invite['id'].'_'.$location->id.'.pdf';

                        $abyde_drive_folder = AbydeDriveArchiveFolder::where('folder_name', 'Employees')->first();

                        $emp_name_folder = AbydeDriveArchiveFolder::where('folder_name', $employee_first_name.'_'.$employee_last_name.'_'.$this->employee['id'])
                            ->where('parent_folder_id', $abyde_drive_folder->id)->first();
                        if ($emp_name_folder == null) {
                            $emp_name_folder = AbydeDriveArchiveFolder::updateOrCreate([
                                'folder_name' => $employee_first_name.'_'.$employee_last_name.'_'.$this->employee['id'],
                                'parent_folder_id' => $abyde_drive_folder->id,
                            ]);
                        }
                        $certificates_folder = AbydeDriveArchiveFolder::updateOrCreate([
                            'folder_name' => 'Certificates',
                            'parent_folder_id' => $emp_name_folder->id,
                        ]);
                        $emp_name_folder_location = AbydeDriveArchiveFolderLocation::updateOrCreate([
                            'archive_folder_id' => $emp_name_folder->id,
                            'location_id' => $location->id,
                        ]);

                        $certificates_folder_location = AbydeDriveArchiveFolderLocation::updateOrCreate([
                            'archive_folder_id' => $certificates_folder->id,
                            'location_id' => $location->id,
                        ]);
                        $file_data = [
                            'file_name' => $new_file_name,
                            'title' => $title,
                            'archive_folder_id' => $certificates_folder_location->id,
                            'file_size' => $file_size,
                        ];
                        AbydeDriveArchiveFile::create($file_data);
                        // unlink(public_path('generatedpolicydocuments/' . $employee_first_name . '_' . $employee_last_name . '_TrainingCertificate_' . $training_invite['id'] . '.pdf'));
                    }
                    foreach ($this->employee['employee_secondary_work_location'] as $SecondaryWorkLocation) {
                        $is_training_open = TrainingLocation::where('location_id', $SecondaryWorkLocation['location_id'])->where('training_id', $training_invite['training_id'])->first();
                        if ($is_training_open) {
                            $location = Location::find($SecondaryWorkLocation['location_id']);
                            $complete_date = date('F d,Y', strtotime($training_invite['completed_datetime']));
                            $file = public_path('policydocuments/TrainingCertificate.docx');
                            $phpword = new \PhpOffice\PhpWord\TemplateProcessor($file);
                            $phpword->setValue('EMPLOYEE_NAME', htmlspecialchars($this->employee['first_name']).' '.htmlspecialchars($this->employee['last_name']));
                            $phpword->setValue('TRAINING_MODULE_NAME', htmlspecialchars($training_invite['training']['title']));
                            $phpword->setValue('DATE', $complete_date);
                            $phpword->setValue('COMPANY_NAME', htmlspecialchars($location->company_name));
                            $employee_first_name = str_replace(' ', '_', trim($this->employee['first_name']));
                            $employee_first_name = preg_replace('/[^A-Za-z0-9\-\_]/', '', $employee_first_name);
                            $employee_last_name = str_replace(' ', '_', trim($this->employee['last_name']));
                            $employee_last_name = preg_replace('/[^A-Za-z0-9\-\_]/', '', $employee_last_name);
                            $generated_training_certificate = $storage_path.'/generatedpolicydocuments/'.$employee_first_name.'_'.$employee_last_name.'_TrainingCertificate_'.$training_invite['id'].'.docx';
                            $phpword->saveAs($generated_training_certificate);
                            $generated_certificate_directory_path = $storage_path.'/generatedpolicydocuments/';
                            if (\Str::contains(request()->getHttpHost(), ['localhost', '127.0.0.1'])) {
                                // change libreoffice path as per installation path from your machine
                                exec('"C:/Program Files/LibreOffice/program/soffice.exe" --headless --convert-to pdf:writer_pdf_Export --outdir  '.$generated_certificate_directory_path.' '.$generated_training_certificate);
                            } else {
                                exec('libreoffice --headless "-env:UserInstallation=file:///tmp/LibreOffice_Conversion_${USER}" --convert-to pdf:writer_pdf_Export --outdir '.$generated_certificate_directory_path.' '.$generated_training_certificate);
                            }
                            // unlink($generated_training_certificate);
                            $contents = \File::get($storage_path.'/generatedpolicydocuments/'.$employee_first_name.'_'.$employee_last_name.'_TrainingCertificate_'.$training_invite['id'].'.pdf');
                            $new_file = '/abyde_drive_archive/employees/'.$this->employee['user_id'].'/'.$employee_first_name.'_'.$employee_last_name.'_TrainingCertificate_'.$training_invite['id'].'_'.$location->id.'.pdf';
                            Storage::disk('s3')->put($new_file, $contents);
                            $file_size = $this->getReadableFilesize(Storage::disk('s3')->size($new_file));
                            $title = $employee_first_name.'_'.$employee_last_name.'_TrainingCertificate_'.$training_invite['id'].'_'.$location->id;
                            $new_file_name = $employee_first_name.'_'.$employee_last_name.'_TrainingCertificate_'.$training_invite['id'].'_'.$location->id.'.pdf';

                            $abyde_drive_folder = AbydeDriveArchiveFolder::where('folder_name', 'Employees')->first();

                            $emp_name_folder = AbydeDriveArchiveFolder::where('folder_name', $employee_first_name.'_'.$employee_last_name.'_'.$this->employee['id'])
                                ->where('parent_folder_id', $abyde_drive_folder->id)->first();
                            if ($emp_name_folder == null) {
                                $emp_name_folder = AbydeDriveArchiveFolder::updateOrCreate([
                                    'folder_name' => $employee_first_name.'_'.$employee_last_name.'_'.$this->employee['id'],
                                    'parent_folder_id' => $abyde_drive_folder->id,
                                ]);
                            }
                            $certificates_folder = AbydeDriveArchiveFolder::updateOrCreate([
                                'folder_name' => 'Certificates',
                                'parent_folder_id' => $emp_name_folder->id,
                            ]);
                            $emp_name_folder_location = AbydeDriveArchiveFolderLocation::updateOrCreate([
                                'archive_folder_id' => $emp_name_folder->id,
                                'location_id' => $location->id,
                            ]);

                            $certificates_folder_location = AbydeDriveArchiveFolderLocation::updateOrCreate([
                                'archive_folder_id' => $certificates_folder->id,
                                'location_id' => $location->id,
                            ]);
                            $file_data = [
                                'file_name' => $new_file_name,
                                'title' => $title,
                                'archive_folder_id' => $certificates_folder_location->id,
                                'file_size' => $file_size,
                            ];
                            AbydeDriveArchiveFile::create($file_data);
                            // unlink(public_path('generatedpolicydocuments/' . $employee_first_name . '_' . $employee_last_name . '_TrainingCertificate_' . $training_invite['id'] . '.pdf'));
                        }
                    }
                }
                DB::commit();
            } catch (\Exception $e) {
                DB::rollBack();
                Log::error('MoveEmployeeCertificateToAbydeDrive/handle()[training_invites_error] => '.$e->getMessage());
                Log::error('MoveEmployeeCertificateToAbydeDrive/handle()[training_invites_data] => '.json_encode($training_invite));
            }
        }
    }

    /**
     * Handle a job failure.
     */
    public function failed(Throwable $exception)
    {
        Log::error('Background Job Failed(MoveEmployeeCertificateToAbydeDrive): '.$this->employee['id']);
    }
}
