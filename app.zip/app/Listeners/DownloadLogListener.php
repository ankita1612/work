<?php

namespace App\Listeners;

use App\Events\DownloadLogEvent;
use App\Models\DownloadLog;
use App\Models\EmailLog;
use App\Models\EmailTemplate;
use App\Models\EmployeeLimitPrice;
use App\Models\LocationLimitPrice;
use App\Models\User;
use App\Traits\ChargebeePlan;
use App\Traits\PricingHelper;
use App\Traits\SendMail;
use Carbon\Carbon;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Config;

class DownloadLogListener implements ShouldQueue
{
    use PricingHelper,SendMail,ChargebeePlan;

    public function handle(DownloadLogEvent $event)
    {
        DownloadLog::create([
            'user_id' => $event->user_id,
            'file_name' => $event->file,
            'location_id' => $event->location_id,
        ]);
        $currentDateTime = Carbon::now();
        $oneHourAgo = $currentDateTime->subHour();

        $count = DownloadLog::where(['user_id' => $event->user_id, 'location_id' => $event->location_id])
            ->where('created_at', '>=', $oneHourAgo)
            ->with('location')
            ->groupBy('file_name')
            ->get();
        if (count($count) > 5) {
            $user_details = User::with(['reseller'])
                ->withCount(['locations'])
                ->find($event->user_id);
            $subscription = $this->getSubscriptionDetails($user_details->chargebee_subscription_id);
            if($subscription['status'] == 'active'){
                $plan_renew_date = Carbon::createFromTimestamp($subscription['next_billing_at'])->format('m-d-Y');
                $location_pricing_current = LocationLimitPrice::where('limit', $subscription['location_limit'])->first();
                $employee_pricing_current = EmployeeLimitPrice::withTrashed()->where('max_limit', $subscription['employee_limit'])->first();    
                $calculatedPricing = $this->calculateTotalPrice($employee_pricing_current, $location_pricing_current);
                $final_payment_price = ($subscription['plan_type'] == 'monthly' ? $calculatedPricing['monthly_price'] : ($subscription['plan_type'] == 'quarterly' ? $calculatedPricing['quarterly_price'] : ($subscription['plan_type'] == 'biannually' ? $calculatedPricing['biannually_price'] : $calculatedPricing['yearly_price'])));

                $final_discount_price = 0;
                $promocode_data = '';
                // add promocode
                if (! empty($subscription['coupon'])) {
                    $promocode_data = $this->checkPromoCode($subscription['coupon'], false);
                    if (! empty($promocode_data)) {
                        $final_discount_price = round(($final_payment_price * $promocode_data->discount_percentage) / 100, 2);
                    }
                }
                $charge_price_before_sales_tax_amount = round(($final_payment_price - $final_discount_price), 2);

                $emailTemplate = EmailTemplate::where('code', 'HCE-AE20')->first();
                $checkMail = EmailLog::where('subject', 'LIKE', '%Download Warning%')
                    ->where('user_id', $event->user_id)
                    ->whereDate('created_at', Carbon::today())
                    ->first();
                if (! $checkMail) {
                    $ul_count_of_docs = '<ul>';
                    for ($i = 0; $i < 6; $i++) {
                        $ul_count_of_docs .= '<li style="margin: 0;padding: 0;font-family: &quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size: 14px;line-height: 1.6;font-weight: normal;">'.$count[$i]->file_name.'</li>';
                    }
                    $ul_count_of_docs .= '</ul>';
                    $email_vars = [
                        '{%PRIMARY_COMPLIANCE_OFFICER_FIRST_NAME%}' => $user_details->first_name,
                        '{%PRIMARY_COMPLIANCE_OFFICER_LAST_NAME%}' => $user_details->last_name,
                        '{%PRIMARY_COMPLIANCE_OFFICER_EMAIL%}' => $user_details->email,
                        '{%COMPANY_NAME%}' => $user_details->company_name,
                        '{%PROMO_CODE%}' => ! empty($subscription['coupon']) ? $subscription['coupon'] : '-',
                        '{%PRICE%}' => $this->formatPrice($charge_price_before_sales_tax_amount),
                        '{%PROMO_DISCOUNT%}' => $this->formatPrice($final_discount_price),
                        '{%NEXT_PAYMENT_DATE%}' => $plan_renew_date,
                        '{%NUMBERS_OF_LOCATIONS%}' => $user_details->locations_count,
                        '{%EMPLOYEE_RANGE%}' => $subscription['employee_limit'],
                        '{%LOCATION_NAME%}' => $count[0]['location']['location_nickname'] ?? '',
                        '{%DOCUMENT_LIST%}' => $ul_count_of_docs,
                    ];
                    $html = str_ireplace(array_keys($email_vars), array_values($email_vars), $emailTemplate->body);
                    $reseller = ! empty($user_details->partner_reseller_id) ? $user_details->reseller : null;
                    $html_subject = ! empty($reseller) ? str_ireplace(['{%RESELLER%}'], [$reseller->name], $emailTemplate->reseller_subject) : $emailTemplate->subject;

                    $this->sendEmail($emailTemplate->code, $html, Config::get('app.cs_group_email'), Config::get('app.from_admin_email'), $html_subject, null, null, true, ($user_details->partner_reseller_id != null ? $user_details->reseller->logo : null), $event->user_id);
                }
            }
        }
    }
}
