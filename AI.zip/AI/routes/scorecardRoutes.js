import express from "express";
import { marked } from "marked";
import ollama from "ollama";
import verifyToken from "../middleware/verifyToken.js";
import {
  scorecard_text_1, scorecard_text_2 
} from "../prompts/scorecardPrompt.js";

const router = express.Router();

// Convert markdown to HTML helper
const renderMarkdown = (content) => `<div>${marked.parse(content)}</div>`;

// Location-wise with mapped plain text
router.post("/sra_question", verifyToken, async (req, res) => {
  try {
    const { readableText } = req.body;
    if (!readableText || typeof readableText !== "string") {
      return res.status(400).json({ message: "Invalid or missing readableText" });
    }

    const fullPrompt = `${scorecard_text_1}\n\n${readableText}\n\n${scorecard_text_2}`;
    const response = await ollama.chat({
      model: process.env.AI_MODEL_NAME,
      temperature: 1.0, //0.0 – 0.3 Deterministic, focused, factual, consistent, 0.4 – 0.6Balanced between logic and variety, 0.7 – 1.0+Creative, varied, potentially verbose or imaginative
      top_p: 0.95, //Precise factual response 0.3 – 0.5,Balanced & natural output 0.8 – 0.95,Creative storytelling or dialogue 0.95 – 1.0 
      messages: [{ role: "user", content: fullPrompt }],
    });

    return res.json({ response: response.message.content });
  } catch (err) {
    return res.status(500).json({ message: "Failed to process sra_question." });
  }
});


export default router;
