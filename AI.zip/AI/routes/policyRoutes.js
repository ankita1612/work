import express from "express";
import { marked } from "marked";
import ollama from "ollama";
import verifyToken from "../middleware/verifyToken.js";
import fs from 'fs';
import Pdf from 'pdf-parse/lib/pdf-parse.js';
import axios from 'axios';

const router = express.Router();

// Convert markdown to HTML helper
const renderMarkdown = (content) => `<div>${marked.parse(content)}</div>`;

function splitText(text, chunkSize = 1500) {
  const chunks = [];
  let start = 0;
  while (start < text.length) {
    chunks.push(text.slice(start, start + chunkSize));
    start += chunkSize;
  }
  return chunks;
}

function cleanText(text) {
  return text
    .replace(/https:\/\/abyde\.com\/?/g, '')        // remove URLs
    .replace(/\d+\/\d+/g, '')                        // remove page numbers like "5/11"
    .replace(/Powered by:.*\n?/gi, '')               // remove footer lines
    .replace(/Abyde | abyde.com.*\n?/gi, '')               // remove footer lines    
    .replace(/\n{2,}/g, '\n')                        // collapse excessive newlines
    .trim();
}

router.post("/summarize_policy", verifyToken, async (req, res) => {
  try {      
    const { file_url, document_title, location_name, document_type } = req.body;

    if (!file_url || !document_title || !location_name || !document_type) {      
      return res.status(400).json({ message: "Invalid or missing readableText" });
    }

    const response = await axios.get(file_url, { responseType: 'arraybuffer' });
    const pdfData = await Pdf(response.data);
    const rawText = pdfData.text;        
    var cleanedText = '';
    cleanedText = cleanText(rawText).slice(0, process.env.TOTAL_TEXT_LENGTH || 10000);
    const chunks = splitText(cleanedText, process.env.SPLIT_TEXT_LENGTH || 2000);    
    
    if (chunks.length === 0) {
        return res.status(500).json({ message: "It seems document is empty. Please share valid document" });
    }
    
    let prompt = '';
    let final_prompt = '';

    if (document_type === "policy") {
      prompt = `You are a HIPAA compliance expert.
          Please analyze the following policy document: "${document_title}" from an organization based in "${location_name}".
          Summarize the content with a focus on:
          - Policy purpose and scope
          - HIPAA regulatory alignment (mention specific sections like 164.xxx if applicable)
          - Key organizational responsibilities
          - PHI or ePHI handling rules
          - Enforcement or compliance-related notes
          Use bullet points where appropriate.
          `.trim();

      final_prompt = `
          You are a HIPAA compliance expert.
          Based on the following summaries of the "${document_title}" policy from the organization located in "${location_name}", provide a clear, concise HIPAA-focused summary that:
          - Highlights its purpose and key regulatory responsibilities
          - Emphasizes safeguards, compliance, and privacy rules
          - Mentions critical actions or standards relevant to PHI
           Make the summary easy to read, using:
          - Bullet points (•)  
          - Line breaks with \\n  
          - Emojis where appropriate (✅, ⚠️, 🔒, 📊, 👥, etc.)

          Only return the result in this JSON format:
          json
          {
            "summary": "Your summary text here with \\n and bullet points. please give title in <p> tag. rest of points in bullets"
          }`.trim();

    } else if (document_type === "procedure") {
      prompt = `You are a HIPAA compliance expert.
          Please review this procedure: "${document_title}" from the organization at "${location_name}".
          Summarize the operational flow with emphasis on:
          - Step-by-step actions or responsibilities
          - Who is responsible for what and when
          - What safeguards are in place for PHI/ePHI
          - How this supports HIPAA compliance
          Use bullet points where appropriate.
          `.trim();

      final_prompt = `You are a HIPAA compliance expert.
          Based on the following summaries of the "${document_title}" procedure at "${location_name}", generate a clear summary of:
          - Key actions and roles described
          - Security or privacy protocols involved
          - How the procedure aligns with HIPAA rules
          Make the summary easy to read, using:
          - Bullet points (•)  
          - Line breaks with \\n  
          - Emojis where appropriate (✅, ⚠️, 🔒, 📊, 👥, etc.)

          Only return the result in this JSON format:
          json
          {
            "summary": "Your summary text here with \\n and bullet points. please give title in <p> tag. rest of points in bullets"
          }`.trim();

    } else {      
      return res.status(400).json({ message: "Invalid document type." });
    }

    const chunkSummaries = [];

    for (let i = 0; i < chunks.length; i++) {      
      const chunk = chunks[i];
      const chunkPrompt = `${prompt}\n\nHere is the content:\n${chunk}`.trim();
      try {
        const response = await ollama.chat({
          model: process.env.AI_MODEL_NAME,
          temperature: 1.0, //0.0 – 0.3 Deterministic, focused, factual, consistent, 0.4 – 0.6Balanced between logic and variety, 0.7 – 1.0+Creative, varied, potentially verbose or imaginative
          top_p: 0.95, //Precise factual response 0.3 – 0.5,Balanced & natural output 0.8 – 0.95,Creative storytelling or dialogue 0.95 – 1.0 
          messages: [{ role: "user", content: chunkPrompt }],
        });        
        chunkSummaries.push(response.message.content);
      } catch (err) {        
        chunkSummaries.push(`(Failed to summarize chunk ${i + 1})`);
      }
    }

    const finalPrompt = `
      ${final_prompt}
      Here are the summaries:
      ${chunkSummaries.join('\n\n')}
      `.trim();      
    
    const final_response = await ollama.chat({
      model: process.env.AI_MODEL_NAME,
      temperature: 1.0, //0.0 – 0.3 Deterministic, focused, factual, consistent, 0.4 – 0.6Balanced between logic and variety, 0.7 – 1.0+Creative, varied, potentially verbose or imaginative
      top_p: 0.95, //Precise factual response 0.3 – 0.5,Balanced & natural output 0.8 – 0.95,Creative storytelling or dialogue 0.95 – 1.0 
      messages: [{ role: "user", content: finalPrompt }],
    });        
    return res.json({ response: final_response.message.content });
  } catch (err) {    
    return res.status(500).json({ message: "Failed to process policy document." });
  }
});

export default router;