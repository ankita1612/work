import express from "express";
import { marked } from "marked";
import ollama from "ollama";
import verifyToken from "../middleware/verifyToken.js";
import {

  overall_summary_prompt_1, 
  overall_summary_prompt_3,
  overall_summary_prompt_2,
  locationwise_summary_1, 
  locationwise_summary_2
} from "../prompts/dashboardPrompt.js";

const router = express.Router();

// Location-wise with mapped plain text
router.post("/summarize_dashbaord_location_wise_map", verifyToken, async (req, res) => {
  try {    
   
    const { readableText, prompt_id } = req.body;
    if (!readableText || typeof readableText !== "string") {
      return res.status(400).json({ message: "Invalid or missing readableText" });
    }
    //const fullPrompt = `${locationwise_summary_combined}\n\n${readableText}`;  
    var fullPrompt;
    if (prompt_id == 1) {
       fullPrompt = `${locationwise_summary_1}\n\n${readableText}`;
    } else {
       fullPrompt = `${locationwise_summary_2}\n\n${readableText}`;
    }
    
    const response = await ollama.chat({
      model: process.env.AI_MODEL_NAME,
      temperature: 1.0, //0.0 – 0.3 Deterministic, focused, factual, consistent, 0.4 – 0.6Balanced between logic and variety, 0.7 – 1.0+Creative, varied, potentially verbose or imaginative
      top_p: 0.95, //Precise factual response 0.3 – 0.5,Balanced & natural output 0.8 – 0.95,Creative storytelling or dialogue 0.95 – 1.0 
      messages: [{ role: "user", content: fullPrompt }],
    });
    
    return res.json({ response: response.message.content });
  } catch (err) {
    
    return res.status(500).json({ message: "Failed to process summarize_dashbaord_location_wise_map." });
  }
});

// Full summary (text)
router.post("/full_summary_map", verifyToken, async (req, res) => {
  try {
    const { readableText, prompt_id } = req.body;
    if (!readableText || typeof readableText !== "string") {
      return res.status(400).json({ message: "Invalid input" });
    }
    var fullPrompt;;
    if (prompt_id == 1) {
      fullPrompt = `${overall_summary_prompt_1}\n\n${readableText}`;
    }
    else if (prompt_id == 2) {
      fullPrompt = `${overall_summary_prompt_2}\n\n${readableText}`;
    }
    else {
      fullPrompt = `${overall_summary_prompt_3}\n\n${readableText}`;
    }
    
    const response = await ollama.chat({
      model: process.env.AI_MODEL_NAME,
      temperature: 1.0, //0.0 – 0.3 Deterministic, focused, factual, consistent, 0.4 – 0.6Balanced between logic and variety, 0.7 – 1.0+Creative, varied, potentially verbose or imaginative
      top_p: 0.95, 
      messages: [{ role: "user", content: fullPrompt }],
    });    
    return res.json({ response: response.message.content });
  } catch (err) {
    return res.status(500).json({ message: "Failed to process full_summary_map." });
  }
});
export default router;
