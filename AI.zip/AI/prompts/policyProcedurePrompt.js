export const summarise_data11 = `You are a HIPAA compliance expert with specialized knowledge in`;
export const summarise_data22 = `Please summarise.Here is my data: `

export const summarise_data1 = `You are a HIPAA compliance expert with specialized knowledge in`;
export const summarise_data2 = `I will provide you with procedural documentation related to a Disaster Recovery Plan.
Your task is to:
Analyze the procedure data carefully.Summarize the core components of the Disaster Recovery Plan.
Provide the output in the following JSON format:
{
  "summary": "Bullet-point summary of data here, max 400 characters", 
}
Keep language clear and accessible for healthcare compliance teams.
Here is my data:`

export const summarise_data2_old = `I will provide you with procedural documentation related to a Disaster Recovery Plan.
Your task is to:
Analyze the procedure data carefully.
Summarize the core components of the Disaster Recovery Plan.
Identify any procedures relevant to HIPAA Security Rule §164.308(a)(7) – Contingency Plan.
Provide the output in the following JSON format:
{
  "summary": "📝 Bullet-point summary of key DRP items here, max 200 characters",
  "hipaa_relevance": "📋 Brief description of how the plan aligns with HIPAA §164.308(a)(7)",
  "recommendations": "✅ Optional: Suggestions to improve compliance or coverage if needed"
}
Keep language clear and accessible for healthcare compliance teams.
Do not begin response until I input the Disaster Recovery Plan procedure data. Here is my data:`
