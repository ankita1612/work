import jwt from "jsonwebtoken";
import mysql from "mysql2/promise";

function getCurrentDateTime() {
  const now = new Date();

  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const h = String(now.getHours()).padStart(2, '0');
  const i = String(now.getMinutes()).padStart(2, '0');
  const s = String(now.getSeconds()).padStart(2, '0');

  return `${y}-${m}-${d} ${h}:${i}:${s}`;
}

export default async function verifyToken(req, res, next) {
  next();
  // const authHeader = req.headers.authorization;
  // if (!authHeader) return res.status(401).json({ message: 'Missing token' });

  // const token = authHeader.split(' ')[1];
  // const db = await mysql.createConnection({
  //   host: process.env.DB_HOST,
  //   user: process.env.DB_USERNAME,
  //   password: process.env.DB_PASSWORD,
  //   database: process.env.DB_DATABASE,
  // });
  // const curr_date = getCurrentDateTime();  
  // const [rows] = await db.execute(
  //   'SELECT * FROM user_tokens WHERE token = ? AND expires_at > ? AND deleted_at IS NULL', [token, curr_date]
  // );
  
  // if (!rows.length) {
  //   return res.status(403).json({ message: 'Invalid or expired token' });
  // }

  // try {
  //   const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);
  //   req.user = decoded;
  //   next();
  // } catch (err) {
  //   return res.status(403).json({ message: 'Token verification failed' });
  // }
}
