// File: server.js
import express from "express";
import cors from "cors";
import { marked } from "marked";
import ollama from "ollama";
import dashboard_routes from "./routes/dashboardRoutes.js";
import scorecard_routes from "./routes/scorecardRoutes.js";
import policy_routes from "./routes/policyRoutes.js";
import dotenv from 'dotenv';
dotenv.config({ path: './.env' });

const app = express();

app.use(cors());
app.use(express.json());

// Preload model on startup
(async () => {
  try {
    console.log(`🔥 Preloading model "${process.env.AI_MODEL_NAME}"...`);
    await ollama.chat({
      model: process.env.AI_MODEL_NAME,
      messages: [{ role: "user", content: "warm up" }],
    });
    console.log(`✅ Model "${process.env.AI_MODEL_NAME}" loaded and ready.`);
  } catch (err) {
    console.error("❌ Failed to preload model:", err.message);
  }
})();

app.use("/", dashboard_routes);
app.use("/scorecard", scorecard_routes);
app.use("/policy", policy_routes);

const server = app.listen(process.env.PORT, () => {
  console.log("Server is running...");
});

// Graceful shutdown
const shutdown = () => {
  console.log('\nShutting down gracefully...');
  server.close(() => {
    console.log('HTTP server closed');
    process.exit(0);
  });
};

process.on('SIGINT', shutdown);   // Ctrl+C
process.on('SIGTERM', shutdown);  // kill command or PM2 shutdown
process.on('uncaughtException', (err) => {
  console.error('Uncaught exception:', err);
  shutdown();
});