import Vue from "vue";
import Vuelidate from "vuelidate";
Vue.use(Vuelidate);
import VTooltip from 'v-tooltip';
Vue.use(VTooltip);
import 'v-tooltip/dist/v-tooltip.css';
import Multiselect from 'vue-multiselect';
Vue.component('multiselect', Multiselect);
import 'vue-multiselect/dist/vue-multiselect.min.css';
import infiniteScroll from 'vue-infinite-scroll'
Vue.use(infiniteScroll)

import propertiesMain from "./propertiesMain.vue";
var property_app = new Vue({
    el: "#property_app",
    render: h => h(propertiesMain)
});
