<template>
    <div>
        <div class="property-filter flex flex-wrap justify-between items-center mb40">
            <div class="row flex-auto -mx-10">
                <div class="col-12 col-lg-12 col-xl-4 px10">
                        <div class="flex flex-wrap flex-auto items-center">
                            <h6 class="font-18 blueog--text mb0 mr6">Properties</h6>
                            <VTooltip :triggers="['hover']" :popperTriggers="['hover']" style="height: 24px;"
                                class="cursor-pointer">
                                <span><info-icon></info-icon></span>
                                <template #popper>
                                    Add Properties
                                </template>
                            </VTooltip>
                            <button v-on:click="toggleaddPropertyForm" type="button" class="plus-icon-btn ml3 mt1">
                                <plus-icon></plus-icon>
                            </button>
                            <VTooltip :triggers="['hover']" :popperTriggers="['hover']" v-if="is_refresh_btn_shown">
                                <a v-on:click="resetAndLoadLatestData()"
                                    class="font-12 blueog--text ml10 font-italic font_semibold cursor-pointer d-block text-right">
                                    <img :src="JS_APP_URL + '/images/refresh-list.png'" />
                                </a>
                                <template #popper>
                                    Refresh Property List
                                </template>
                            </VTooltip>
                        </div>
                    </div>
                <div class="col-12 col-lg-12 col-xl-8 px10">
                    <div class="flex flex-wrap flex-auto" >
                        <div class="row flex-auto -mx-10 items-center">
                            <div class="col-12 col-md-2 col-lg-2 col-xl-2 px10">
                                <div class="form-group account-filter-wrapper mb-0">
                                   <multiselect
                                        v-model="selected_owner"
                                        :options="all_owener_list"
                                        tag-placeholder=""
                                        placeholder=""
                                        :multiple="true"
                                        label="name"
                                        track-by="id"
                                        @input="onChangeFilter"
                                        :searchable="false"
                                        :showLabels="false"
                                        :taggable="false">
                                        <template slot="noResult" slot-scope="props">
                                            <div class="multiselect__noResult text-center">No results found</div>
                                        </template>
                                        <template slot="selection" slot-scope="{ values, search, isOpen }">
                                            <div class="multiselect__tags-wrap" v-if="selected_type.length > 1">
                                                <span class="multiselect__tag">
                                                    <span>{{ selected_owner.length }} Owner</span>
                                                </span>
                                            </div>
                                        </template>
                                    </multiselect>
                                    <label class="label label-select" :class="{ 'label-float': (selected_owner.length > 0) }">Owner</label>
                                </div>
                            </div>
                            <div  class="col-12 col-md-2 col-lg-2 col-xl-2 px10">
                                <div class="form-group account-filter-wrapper mb-0">
                                    <multiselect v-model="selected_type" :options="sort_by_type" tag-placeholder=""
                                            placeholder="" :multiple="true" label="text" track-by="id" @input="onChangeFilter"
                                            :searchable="false" :showLabels="false" :taggable="false">
                                            <template slot="noResult" slot-scope="props">
                                                <div class="multiselect__noResult text-center">No results found</div>
                                            </template>
                                            <template slot="selection" slot-scope="{ values, search, isOpen }">
                                                <div class="multiselect__tags-wrap" v-if="selected_type.length > 1">
                                                    <span class="multiselect__tag">
                                                        <span>{{ selected_type.length }} Type</span>
                                                    </span>
                                                </div>
                                            </template>
                                        </multiselect>
                                        <label class="label label-select"
                                            :class="{ 'label-float': (selected_type.length > 0) }">Type</label>
                                </div>
                            </div>
                             <div  class="col-12 col-md-2 col-lg-2 col-xl-2 px10">
                                    <div class="form-group account-filter-wrapper mb-0">
                                        <multiselect v-model="filter_selected_sort_by" :options="sort_by_options"
                                            :close-on-select="true" tag-placeholder="" placeholder="" label="text" track-by="id"
                                            @input="onChangeFilter" :searchable="false" :showLabels="false" :taggable="false">
                                            <template slot="noResult" slot-scope="props">
                                                <div class="multiselect__noResult text-center">No results found</div>
                                            </template>
                                        </multiselect>
                                        <label class="label label-select font-italic"
                                            :class="{ 'label-float': (filter_selected_sort_by != null) }">Sort by</label>
                                    </div>
                            </div>

                            <img v-on:click="toggleSortDir"
                                v-if="filter_selected_sort_by != null && filter_selected_sort_by_dir == 'ASC'"
                                :src="JS_APP_URL + '/images/sort-up.svg'" alt="" title=""
                                class="cursor-pointer sort-arrow ml5" />
                            <img v-on:click="toggleSortDir"
                                v-if="filter_selected_sort_by != null && filter_selected_sort_by_dir == 'DESC'"
                                :src="JS_APP_URL + '/images/sort-down.svg'" alt="" title=""
                                class="cursor-pointer sort-arrow ml5" />

                            <div class="col-12 col-md-2 col-lg-2 col-xl-2 px10">
                                <div class="form-group account-filter-wrapper mb-0">
                                     <input v-on:keyup="onChangeFilter" class="form-input form-input-search" type="text"
                                        v-model.trim="search_text">
                                    <label class="label font-italic" :class="{ 'label-float': search_text }">Search</label>
                                    <div class="search-btn-input">
                                        <img :src="JS_APP_URL + '/images/search.svg'" alt="" title="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
import importIcon from '../common/icons/importIcon';
import infoIcon from '../common/icons/infoIcon';
import plusIcon from '../common/icons/plusIcon';
import clearDropdownIcon from '../common/icons/clearDropdownIcon';

export default {
  data: function () {
    return {
        selected_type:[],
        search_text: "",
        selected_owner: [],
              selected_locations: [],

        filter_selected_sort_by: null,
        filter_selected_sort_by_dir: 'ASC',
        sort_by_options: [
            { id: 'name', text: 'Name' },
            { id: 'type', text: 'Type' },
            { id: 'size', text: 'size' },
            { id: 'owner_id', text: 'Owner' },
        ],
        sort_by_type: [
                { id: 'residential', text: 'Residential' },
                { id: 'commercial', text: 'Commercial' },
        ],
        all_location_list  : [
                { id: 'residential', location_nickname: 'residential' },
                { id: 'commercial', location_nickname: 'commercial' },
            ],
      delay_timer: "",
      search_text: "",
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL
    };
  },
  components: {importIcon, infoIcon, clearDropdownIcon,plusIcon},
    props: {

     all_owener_list: {
            type: Array,
            default: () => []
      },
      is_add_property_shown:{
        type: Boolean,
        default: () => true
      },
      is_refresh_btn_shown:{
        type: Boolean,
        default: () => true
      },
      sample_import_file_link:{
        type: String,
        default: () => ""
      },
  },
  mounted: function () {
    var vm = this;
  },
  watch: {},
  computed: {},
    methods: {
      toggleSortDir: function () {
            var vm = this;
            vm.filter_selected_sort_by_dir = (vm.filter_selected_sort_by_dir == 'ASC') ? 'DESC' : 'ASC';
            vm.onChangeFilter();
        },
    toggleaddPropertyForm: function(){
      var vm = this;
      vm.$emit('add-property-form-toggle', !vm.is_add_property_shown)
    },
    onChangeFilter: function () {
            var vm = this;
            if (vm.delay_timer) {
                clearTimeout(vm.delay_timer);
                vm.delay_timer = null;
            }
            vm.delay_timer = setTimeout(() => {
                vm.$emit('apply-filter', { search_query: vm.search_text, sort_by: (vm.filter_selected_sort_by != null) ? vm.filter_selected_sort_by.id : '', sort_by_dir: vm.filter_selected_sort_by_dir,  filter_by_type: vm.selected_type, filter_by_owner: vm.selected_owner });
            }, 800);
    },
    onPickImportFile: function(){
      var vm = this;
      vm.$refs.import_file_upload.click();
    },
    resetAndLoadLatestData: function(){
      var vm = this;
      vm.$emit("reset-all-filter");
      vm.$emit("load-all-user-list", true);
    }
  }
};
</script>
