<template>
    <div>
        <transition name="simple-fade-transition" mode="out-in">
        <div v-if="!is_property_editing" key="saved" class="user-detail-card py10 px15 light mb15">
            <div class="row flex-auto -mx-10 items-center">
                <div class="col-12 col-md-12 col-lg-5 col-xl-6 px10">
                <div class="row flex-auto -mx-10">
                  <div class="col-12 col-md-6 col-lg-6 col-xl-7 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text mb10" v-text="property_item.name"></div>
                  </div>
                  <div class="col-12 col-md-6 col-lg-6 col-xl-5 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text mb10">{{ property_item.type }}
                        <span v-if="property_item.type == 'residential'" > - {{ property_item.size }}</span>
                    </div>

                  </div>

                  <div class="col-12 col-md-6 col-lg-6 col-xl-5 px10">
                    <div class="user-detail-text font-14 gray_checkmark--text" v-text="property_item.owners.name"></div>
                  </div>
                </div>
              </div>

                <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-2 px10">
                    <div class="flex flex-wrap items-center justify-end justify-start-small-medium user-detail-action">

                        <div class="action-sept mr30 ml20"></div>
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']">
                            <button v-on:click="editPropertyDetail()" type="button" class="action-icon-btn action-btn-blueog cursor-pointer" >
                                <img :src="JS_APP_URL +'/images/pencil.svg'" alt="" title="">
                            </button>
                            <template #popper>
                                Edit
                            </template>
                        </VTooltip>
                        <VTooltip :triggers="['hover']"  :popperTriggers="['hover']" class="ml7">
                            <button v-on:click="deletePropertyToggle()" type="button" class="delete-location-btn cursor-pointer" >
                                <img :src="JS_APP_URL +'/images/bin.svg'" alt="" title="">
                            </button>
                            <template #popper>
                                Delete
                            </template>
                        </VTooltip>
                    </div>
                </div>
            </div>
        </div>
        <div v-else key="editing" class="user-detail-card pt18 pb22 px15 light mb20">
            <form @submit.prevent="editPropertySubmit"  enctype="multipart/form-data" name="my_form_edit" id="my_form_edit">
                <div class="row flex-auto -mx-10 items-start">
                    <div class="col-12 col-md-12 col-lg-9 col-xl-9 px10">
                            <div class="row flex-auto -mx-10">
                                <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                    <div class="form-group" :class="{ 'form-group--error': $v.name.$error }">
                                        <input class="form-input location-input-box" :class="{ 'form-error': $v.name.$error }" type="text" name="name" v-model.trim="$v.name.$model">
                                        <label class="label location-input-label" :class="{ 'label-float': $v.name.$model }">Name</label>
                                        <div class="form-error-text" v-if="!$v.name.required">
                                        Please enter a name
                                        </div>
                                        <div class="form-error-text" v-if="!$v.name.maxLength">
                                        Max 40 characters allowed
                                        </div>
                                        <div class="form-error-text" v-if="!$v.name.checkSpecialChars && $v.name.maxLength">
                                            {{checkSpecialCharsErrorMessage}}
                                        </div>
                                    </div>
                                </div>

                                 <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                    <div class="form-group" :class="{ 'form-group--error': $v.owner_id.$error }">
                                        <multiselect
                                            class="font-style-normal"
                                            v-model.trim="selected_owener"
                                            placeholder=""
                                            :options="all_owener_list"
                                            track-by="id"
                                            label="name"
                                            :multiple="false"
                                            :close-on-select="true"
                                            position="bottom"
                                            :showLabels="false"
                                            :taggable="false"
                                            @input="onChangeOwnerOption"
                                            :class="{ 'form-error': $v.owner_id.$error }"
                                            :allowEmpty="false">
                                            <
                                                 slot="noResult" slot-scope="props">
                                            <div class="multiselect__noResult text-center">No results found</div>
                                            </>
                                            </multiselect>
                                        <label class="label location-input-label" :class="{ 'label-float': $v.owner_id.$model }">owner</label>
                                        <div class="form-error-text" v-if="!$v.owner_id.required">
                                        Please enter an owner
                                        </div>
                                    </div>
                                </div>



                                <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                    <div class="form-group" :class="{ 'form-group--error': $v.type.$error }">
                                        <label class="checkbox-label font-14 font-light gray_checkmark--text" :class="{ 'label-float': $v.type.$model }">Type</label>
                                        <hr>
                                        <div class="col-sm-8">
                                            <div class="form-check form-radio-outline form-radio-info mb-3" v-for="type in type_arr" :key="type.id">
                                                <input class="form-check-input" type="radio" :id="'type_' + type.id" name="type" :value="type.id" v-model.trim="$v.type.$model">
                                                <label class="form-check-label" :for="'type_' + type.id">
                                                    {{ type.name }}
                                                </label>
                                            </div>
                                            <div class="form-error-text" v-if="!$v.type.required">Please select a type</div>
                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                    <div class="form-group" :class="{ 'form-group--error': $v.type.$error }">
                                    <select class="form-input location-input-box" :class="{ 'form-error': $v.type.$error }"  name="type" v-model.trim="$v.type.$model">
                                            <option value="residential">residential</option>
                                            <option value="commercial">commercial</option>
                                        </select>

                                            <input type="radio" name="type" value="residential" v-model="$v.type.$model" checked />Residential
                                            <input type="radio" name="type" value="commercial" v-model="$v.type.$model" />Commercial
                                        <label class="label location-input-label" :class="{ 'label-float': $v.type.$model }">Type</label>
                                        <div class="form-error-text" v-if="!$v.type.required">
                                        Please enter an type
                                        </div>
                                    </div>
                                </div> -->

                                <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10"  v-if="type == 'residential'">
                                    <div class="form-group" :class="{ 'form-group--error': $v.size.$error }">
                                            <select class="form-input location-input-box" :class="{ 'form-error': $v.size.$error }"  name="type" v-model.trim="$v.size.$model">
                                            <option value="2bhk">2bhk</option>
                                            <option value="3bhk">3bhk</option>
                                        </select>
                                        <label class="label location-input-label" :class="{ 'label-float': $v.size.$model }">Size</label>
                                        <div class="form-error-text" v-if="!$v.size.required">
                                        Please enter an size
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                        <div class="form-group" :class="{ 'form-group--error': $v.detail.$error }">
                                            <textarea class="form-input location-input-box" :class="{ 'form-error': $v.detail.$error }"  name="detail" v-model.trim="$v.detail.$model"></textarea>

                                            <label class="label location-input-label" :class="{ 'label-float': $v.detail.$model }">Detail</label>
                                            <div class="form-error-text" v-if="!$v.detail.required">
                                            Please enter detail
                                            </div>
                                            <div class="form-error-text" v-if="!$v.detail.maxLength">
                                            Max 400 characters allowed
                                            </div>
                                        </div>
                                    </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-2 col-20-company px10">
                                  <div class="form-group" :class="{ 'form-group--error': $v.selected_aminity.$error }">
                                    <label class="checkbox-label font-14 font-light gray_checkmark--text" :class="{ 'label-float': $v.selected_aminity.$model }">Amenity</label>
                                    <hr>
                                    <span v-for="item in all_aminity_list" >
                                                <input type="checkbox" :value="item.id" v-model="selected_aminity" :id="item.id">
                                                <span class="checkbox-label"> {{ item.name }} </span> <br>
                                            </span>

                                    <div class="form-error-text" v-if="!$v.selected_aminity.required">
                                        Please select aminity
                                    </div>
                                  </div>
                                </div>


                                <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                                    <div class="form-group" :class="{ 'form-group--error': $v.address.$error }">
                                        <textarea class="form-input location-input-box" :class="{ 'form-error': $v.address.$error }" type="text" name="address" v-model.trim="$v.address.$model"></textarea>

                                        <label class="label location-input-label" :class="{ 'label-float': $v.address.$model }">Address</label>
                                        <div class="form-error-text" v-if="!$v.address.required">
                                        Please enter an address
                                        </div>
                                        <div class="form-error-text" v-if="!$v.address.maxLength">
                                        Max 400 characters allowed
                                        </div>
                                    </div>
                                </div>

            <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                <div class="form-group" >
                    <input type="file" @change="onImageChange" class="form-input location-input-box"  id="brochure_i" name="brochure_i"  ref="brochure_i"  >

                    <label class="label location-input-label" >Brochure</label>
                    <br>
                    <a v-if="brochure_img_name != ''" :href="brochure_img" _target="_blank" download >Download</a>
                    <a v-if="brochure_img_name != ''" href="#" @click.prevent="delete_image(brochure_img_name, 'brochure')"   >Delete</a>
                </div>
            </div>

            <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                <div class="form-group" >
                    <input type="file" @change="onphotoChange" class="form-input location-input-box"  multiple id="photo_i" name="photo_i"  ref="photo_i"  >
                    <label class="label location-input-label" >Photo</label>
                </div>

                <!--  v-model= "photo_arr[index]" -->
                <span v-for="(img,key) in property_item.property_image"  :key="key">
                    <img  :src="show_image(img.image)"  width='50px' height='50px'>
                    <br><a :href="PROPERTY_IMAGES+'/'+img.image" _target="_blank" download >Download</a>
                    <a href="#" @click.prevent="delete_image_ajax(img.image, 'photo', img.id, key)" >Delete</a>
                </span>
            </div>
        </div>
    </div>

                    <div class="col-12 col-md-12 col-lg-3 col-xl-3 pl10 pr0 mt-sm-20">
                        <div class="flex items-center flex-wrap submit-cancel-buttons">
                            <button
                            type="submit"
                            class="btn-primary mlr-auto"
                            :disabled="disable_property_submit_btn"
                            >
                                <span>Submit</span>
                            </button>
                            <button
                            type="button"
                            class="btn-cancel-outline btn-cancel-form mlr-auto"
                            :disabled="disable_property_submit_btn"
                            @click="cancelEditProperty"
                            >
                                <span>Cancel</span>
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        </transition>
        <delete-property
        v-if="is_deletepropertymodal_shown"
        :property_id="deletepropertymodal_property_id"
        @close-model="deletePropertyToggle"
        @delete-property="deletePropertySubmit"
        ></delete-property>

    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
toastr.options.preventDuplicates = true;
var _ = require('lodash');
import { required, requiredIf,  maxLength , helpers } from "vuelidate/lib/validators";
import deleteProperty from "./deleteProperty";
import clearDropdownIcon from '../common/icons/clearDropdownIcon';
import infoIcon from "../common/icons/infoIcon";
import {checkSpecialChars, checkSpecialCharsErrorMessage}  from "../common/customValidation";

export default {
  data: function () {
    return {
        property_id: '',
        name: '',
        detail: '',
        type: '',
        size: '',
        owner_id: '',
        amenity_id: '',
        address: '',
        brochure: '',
        photo: [],
        selected_owener: {},
        selected_aminity:[],
        brochure_img: '',
        brochure_img_name: '',
        local_all_location_list : [{
          'select_all': 'Select All',
          'group_option_list': this.all_location_list,
        }],
       type_arr: [
                { id: 'residential', name: 'Residential' },
                { id: 'commercial', name: 'Commercial' },
            ],

      is_property_editing: false,
      disable_property_submit_btn: false,
      is_deletepropertymodal_shown: false,
      deletepropertymodal_property_id: "",
      JS_APP_URL: JS_APP_URL,
      JS_WORDPRESS_URL: JS_WORDPRESS_URL,
      AUTH_USER: AUTH_USER,
        checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage,
      PROPERTY_IMAGES: PROPERTY_IMAGES
    };
  },
  components: {
	  deleteProperty: deleteProperty,
      clearDropdownIcon,
      infoIcon
  },
  props: {
      property_item:{
        type: Object,
        default: () => {}
      },
      all_location_list:{
        type: Array,
        default: () => []
      },
        all_owener_list: {
            type: Array,
            default: () => []
        },
        all_aminity_list: {
            type: Array,
            default: () => []
        },
  },
  validations() {
    var vm = this;
    var validationArray = {
        name: {
            required,
            checkSpecialChars,
            maxLength: maxLength(40),
        },
        owner_id: {
            required
        },

        type: {
            required
        },
        size:{
            required: requiredIf(function () {
                if (vm.type == "residential")
                    return true;
                else
                    return false;
            })
        },
        detail: {
            required,
            maxLength: maxLength(400),
        },
        selected_aminity: {
            required
        },
        address: {
            required,
            maxLength: maxLength(400),
        },
    };
    return validationArray;
  },
  mounted: function () {
    var vm = this;
    vm.$root.$on('close_other_user_edit', function(property_id){
        if(property_id !== vm.property_item.id){
            vm.is_property_editing = false;
        }
    });
  },
  watch: {
  },
  computed: {},
    methods: {
        show_image(image){
            return window.location.origin + "/images/property_image/" + image;
        },
        delete_image(image_name, type, photo_id = "", i = "")
        {
             var vm = this;
            vm.brochure_img = "";
            vm.brochure_img_name = "";
            vm.property_item.brochure = "";
            vm.brochure = "";          
            return false;
        },
        delete_image_ajax(image_name, type, photo_id = "", i = "")
        {
            // var arrayImages = this.property_item.property_image;
            // var index = arrayImages.indexOf(arrayImages[i]);
            // alert(i + "==" + index);
            // arrayImages.splice(index, 1);

            // return false;

             var vm = this;
           // console.log(image_name + "======type===>" + type + "======photo_id====>" + photo_id+"=index=>"+ i);
            if (confirm("Are you sure you want to delete image?"))
            {
                axios
                .post(JS_APP_URL + "/general/delete-image", {
                    image_name: image_name,
                    type: type,
                    property_id: this.property_id,
                    photo_id:photo_id
                })
                .then(function (response) {
                    if (response["data"]["status"] == "Success") {
                        // if (type == "brochure")
                        // {
                        //     vm.brochure_img = "";
                        //     vm.brochure_img_name = "";
                        //     vm.property_item.brochure="";
                        // }
                        // else if (type == "photo")
                        // {
                        //     var arrayImages = vm.property_item.property_image;
                        //     var index = arrayImages.indexOf(arrayImages[i]);
                        //     arrayImages.splice(index, 1);
                        // }
                        // else
                        // {
                        //     alert("Wrong choice")
                        // }
                        var arrayImages = vm.property_item.property_image;
                        var index = arrayImages.indexOf(arrayImages[i]);
                        arrayImages.splice(index, 1);
                        toastr.success(response["data"]["message"], "Success");
                    }
                })
                .catch(function (error) {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(function () {
                    // vm.is_full_page_loader_shown = false;
                });
            }
        },

        onImageChange(e) {
            var vm = this;
            vm.brochure = e.target.files[0];
            var logoExtension = vm.brochure.name.split('.').pop().toLowerCase();
            var logoExtensionAllow = ['pdf'];
            if (logoExtensionAllow.includes(logoExtension)) {
                if (vm.brochure.size > 5000000) {
                    vm.brochure = '';
                    this.$refs.brochure_i.value = null;/////////////////
                    toastr.error("Please upload a brochure file less than 5 MB", "Error");
                } else {
                    // vm.brochure = URL.createObjectURL(vm.brochure);
                    // vm.$emit("get-logo-object", vm.brochure, vm.company_logo_url);///////////
                }
            } else {
                toastr.error("Allow to upload brochure with pdf!", "Error");
                vm.brochure = '';
                this.$refs.brochure_i.value = null;
            }
        },
        onphotoChange(e)
        {
            var vm = this;
            var i;
            console.log(e.target.files)
            vm.photo = e.target.files;
            console.log("Length-->"+vm.photo.length);
            console.log("Images ->"+vm.photo);
            var logoExtensionAllow = ['jpg', 'jpeg', 'png'];
            var flag = 0;

            for (i = 0; i < vm.photo.length; i++)
            {
                console.log(i);
                var logoExtension = vm.photo[i].name.split('.').pop().toLowerCase();
                console.log(logoExtension)
                if (logoExtensionAllow.includes(logoExtension))
                {
                    if (vm.photo[i].size > 5000000)
                    {
                        toastr.error("Please upload a photo file less than 5 MB", "Error");
                        flag = 1;
                        break;
                    }
                    else
                    {
                        // vm.brochure = URL.createObjectURL(vm.brochure);
                        // vm.$emit("get-logo-object", vm.brochure, vm.company_logo_url);///////////
                    }
                }
                else
                {
                    toastr.error("Allow to upload photo with jpeg,jpg,png!", "Error");
                    flag = 1;
                    break;
                }
            }
            if (flag == 1)
            {
                vm.photo = '';
                this.$refs.photo_i.value = null;
            }
        },
    //  onChangeAminityOption: function () {
    //         var vm = this;
    //         if (_.isNull(vm.selected_aminity) == false) {
    //             vm.amenity_id = vm.selected_aminity.id;
    //         } else {
    //             vm.amenity_id = null;
    //         }
    //         console.log("Amenity-->" + vm.amenity_id);
    //     },

        onChangeOwnerOption: function () {
            var vm = this;
            if (_.isNull(vm.all_owener_list) == false) {
                vm.owner_id = vm.selected_owener.id;
            } else {
                vm.owner_id = null;
            }
            console.log("owner_id-->" + vm.owner_id);
        },

      editPropertyDetail: function(){
          var vm = this;
          vm.property_id = vm.property_item.id;
          vm.name = vm.property_item.name;
          vm.detail = vm.property_item.detail;
          vm.type = vm.property_item.type;
          vm.size = vm.property_item.size;
          vm.owner_id = vm.property_item.owner_id;
          vm.brochure = vm.property_item.brochure;

          vm.selected_aminity = [];
            for (i = 0; i < vm.property_item.property_amenity.length; i++) {
                console.log("i==>" + vm.property_item.property_amenity[i].amenity_id)
                vm.selected_aminity.push(vm.property_item.property_amenity[i].amenity_id);
            }
          console.log("Aminity ids==>" + vm.selected_aminity);

        //  vm.selected_aminity = vm.property_item.amenity_id;
          vm.address = vm.property_item.address;
          //vm.brochure = vm.property_item.brochure;
          vm.brochure_img_name = "";
          vm.brochure_img = "";
          if (vm.property_item.brochure != "" && vm.property_item.brochure != null)
          {
              vm.brochure_img_name = vm.property_item.brochure;
              vm.brochure_img = window.location.origin + "/images/property_brochure/" + vm.brochure_img_name;
          }
          var i;

        vm.selected_owener = vm.property_item.owners; //Need to take care
       // vm.selected_aminity = vm.property_item.amenities; //Need to take care
        //console.log("Amenities->>>>"+vm.property_item.amenities);

          setTimeout(() => {
              vm.is_property_editing = true;
              vm.$root.$emit('close_other_user_edit', vm.property_id);
          }, 100);
      },
      editPropertySubmit: function(){
        var vm = this;
        var amenity_arr = new Array();
        vm.$v.$touch();
        if (!vm.$v.$invalid) {

            NProgress.start();
                    let currentObj = this;
            const config = {
                headers: { 'content-type': 'multipart/form-data' }
            }
            const form = document.getElementById("my_form_edit");
            let formData = new FormData(form);

            formData.append('property_id', vm.property_id);
            // formData.append('name', vm.name);
            // formData.append('detail', vm.detail);
            // formData.append('address', vm.address);
             formData.append('type', vm.type);
             formData.append('size', vm.size);
             formData.append('owner_id', vm.owner_id);
            console.log(vm.selected_aminity);
            if (vm.selected_aminity.length > 0)
            {
                _.forEach(vm.selected_aminity, function (value) 
                {                   
                    console.log("value==>"+value);
                    amenity_arr.push({"amenity_id":value });
                });
             }
            console.log("Anenity start");
            console.log(amenity_arr);
            console.log("Anenity end");
             formData.append('amenity_id', JSON.stringify(amenity_arr));

            formData.append('brochure', vm.brochure);
            for (let i = 0; i < vm.photo.length; i++) {
                //this.upload(i, this.selectedFiles[i]);
                formData.append('photo[' + i + ']', vm.photo[i]);
            }
            vm.disable_property_submit_btn = true;
            axios
            .post(JS_APP_URL + "/properties/edit-property", formData, config)
            .then(function (response) {
                if (response["data"]["status"] == "Error") {
                    if (response["data"]['data'].length > 0) {
                        toastr.error(response["data"]['data'].join('</br>'), "Error");
                    }else{
                        toastr.error(response["data"]["message"], "Error");
                    }
                } else {
                    toastr.success(response["data"]["message"], "Success");
                    setTimeout(() => {
                        vm.is_property_editing = false;
                        vm.$emit("updated-property", response["data"]['data']);
                    }, 100);
                }
            })
            .catch(function (error) {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(function () {
                NProgress.done();
                vm.disable_property_submit_btn = false;
            });
        }
      },
      deletePropertyToggle: function(status = true){
          var vm = this;
          vm.deletepropertymodal_property_id = vm.property_item.id;
          vm.is_deletepropertymodal_shown = status;
          setTimeout(() => {
            vm.$root.$emit('close_other_user_edit', vm.property_item.id);
          }, 100);
      },
      deletePropertySubmit: function(){
          var vm = this;
          if(vm.deletepropertymodal_property_id){
            NProgress.start();
            axios
            .post(JS_APP_URL + "/properties/delete-property", {
                property_id: vm.deletepropertymodal_property_id
            })
            .then(function (response) {
                if (response["data"]["status"] == "Error") {
                    if(response["data"]['data'].length > 0){
                        toastr.error(response["data"]['data'].join('</br>'), "Error");
                    }else{
                        toastr.error(response["data"]["message"], "Error");
                    }
                } else {
                    toastr.success(response["data"]["message"], "Success");
                    setTimeout(() => {
                        vm.$emit("deleted-property", vm.deletepropertymodal_property_id);
                    }, 100);
                }
            })
            .catch(function (error) {
                toastr.error(error.response["data"]["message"], "Error");
                if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                }
            })
            .then(function () {
                NProgress.done();
                vm.is_deletepropertymodal_shown = false;
            });
          }
      },
      cancelEditProperty: function(){
        var vm = this;
        vm.is_property_editing = false;
      }
  },
  created: function () {
    var vm = this;
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        vm.is_property_editing = false;
      }
    });
  }
};
</script>
