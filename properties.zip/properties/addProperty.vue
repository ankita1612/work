<template>
    <div>
        <form @submit.prevent="AddPropertySubmit" enctype="multipart/form-data" name="my_form" id="my_form">
        <div class="add-user-form mb50">
            <div class="property-add-row row items-start -mx-10">
                <div class="col-12 col-md-12 col-lg-9 col-xl-9 px10">
                    <!-- <property-logo @get-logo-object="getLogoObject" :logo_url="logo" ></property-logo> -->

                    <div class="row flex-auto -mx-10">
                        <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                            <div class="form-group" :class="{ 'form-group--error': $v.name.$error }">
                                <input class="form-input location-input-box" :class="{ 'form-error': $v.name.$error }" type="text" name="name" v-model.trim="$v.name.$model">
                                <label class="label location-input-label" :class="{ 'label-float': $v.name.$model }">Name</label>
                                <div class="form-error-text" v-if="!$v.name.required">
                                Please enter a name
                                </div>
                                <div class="form-error-text" v-if="!$v.name.maxLength">
                                Max 40 characters allowed
                                </div>
                                <div class="form-error-text" v-if="!$v.name.checkSpecialChars && $v.name.maxLength">
                                    {{checkSpecialCharsErrorMessage}}
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-lg-6 col-xl-4 col-20-company px10 company_select">
                          <div class="form-group" :class="{ 'form-group--error': $v.owner_id.$error }">
                              <multiselect
                              class="font-style-normal"
                              v-model.trim="selected_owener"
                              placeholder=""
                              :options="all_owener_list"
                              track-by="id"
                              label="name"
                              :multiple="false"
                              :close-on-select="true"
                              position="bottom"
                              :showLabels="false"
                              :taggable="false"
                              @input="onChangeOwnerOption"
                              :class="{ 'form-error': $v.owner_id.$error }"
                              :allowEmpty="false">
                              <template slot="noResult" slot-scope="props">
                                <div class="multiselect__noResult text-center">No results found</div>
                              </template>
                              </multiselect>
    <label class="label label-select" :class="{ 'label-float': ($v.owner_id.$model) }">Owner</label>
                              <div class="form-error-text" v-if="!$v.owner_id.required">
                                  Please select an owner
                              </div>
                          </div>
                      </div>
                        <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                            <div class="form-group" :class="{ 'form-group--error': $v.type.$error }">
                                <label class="checkbox-label font-14 font-light gray_checkmark--text" :class="{ 'label-float': $v.type.$model }">Type</label>
                                <hr>
                                <div class="col-sm-8">
                                    <div class="form-check form-radio-outline form-radio-info mb-3" v-for="type in type_arr" :key="type.id">
                                        <input class="form-check-input" type="radio" :id="'type_' + type.id" name="type" :value="type.id" v-model.trim="$v.type.$model">
                                        <label class="form-check-label" :for="'type_' + type.id">
                                            {{ type.name }}
                                        </label>
                                    </div>
                                    <div class="form-error-text" v-if="!$v.type.required">Please select a type</div>
                                </div>
                            </div>
                        </div>

                        <!-- <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                            <div class="form-group" :class="{ 'form-group--error': $v.type.$error }">
                                <select class="form-input location-input-box" :class="{ 'form-error': $v.type.$error }"  name="type" v-model.trim="$v.type.$model">
                                    <option value="residential">residential</option>
                                    <option value="commercial">commercial</option>
                                </select>

                                <label class="label location-input-label" :class="{ 'label-float': $v.type.$model }">Type</label>
                                <div class="form-error-text" v-if="!$v.type.required">
                                Please enter a type
                                </div>
                                <div class="form-error-text" v-if="!$v.type.maxLength">
                                Max 40 characters allowed
                                </div>
                                <div class="form-error-text" v-if="!$v.type.checkSpecialChars && $v.type.maxLength">
                                    {{ checkSpecialCharsErrorMessage }}
                                </div>
                            </div>
                         </div> -->
                        <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10" v-if="type=='residential'">
                            <div class="form-group" :class="{ 'form-group--error': $v.size.$error }">
                                 <select class="form-input location-input-box" :class="{ 'form-error': $v.size.$error }"  name="type" v-model.trim="$v.size.$model">
                                    <option value="2bhk">2bhk</option>
                                    <option value="3bhk">3bhk</option>
                                </select>
                                <label class="label location-input-label" :class="{ 'label-float': $v.size.$model }">Size</label>
                                <div class="form-error-text" v-if="!$v.size.required">
                                Please enter a size
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                            <div class="form-group" :class="{ 'form-group--error': $v.detail.$error }">
                                <textarea class="form-input location-input-box" :class="{ 'form-error': $v.detail.$error }"  name="detail" v-model.trim="$v.detail.$model" rows="3" cols="20"></textarea>
                                <label class="label location-input-label" :class="{ 'label-float': $v.detail.$model }">Detail</label>
                                <div class="form-error-text" v-if="!$v.detail.required">
                                Please enter detail
                                </div>
                                <div class="form-error-text" v-if="!$v.detail.maxLength">
                                Max 400 characters allowed
                                </div>
                            </div>
                        </div>


                    <div class="col-12 col-md-6 col-lg-6 col-xl-2 col-20-company px10">
                        <div class="form-group" :class="{ 'form-group--error': $v.selected_aminity.$error }">
                            <label class="checkbox-label font-14 font-light gray_checkmark--text" :class="{ 'label-float': $v.selected_aminity.$model }">Amenity</label>
                            <hr>
                            <span v-for="item in all_aminity_list">
                                <input type="checkbox" :value="item.id" v-model="selected_aminity" :id="item.id">
                                <span class="checkbox-label"> {{ item.name }} </span> <br>
                            </span>

                            <div class="form-error-text" v-if="!$v.selected_aminity.required">
                                Please select aminity
                            </div>
                            </div>
                    </div>

                        <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                            <div class="form-group" :class="{ 'form-group--error': $v.address.$error }">
                                <textarea class="form-input location-input-box" :class="{ 'form-error': $v.address.$error }" type="text" name="address" v-model.trim="$v.address.$model">
                                </textarea>
                                <label class="label location-input-label" :class="{ 'label-float': $v.address.$model }">Address</label>
                                <div class="form-error-text" v-if="!$v.address.required">
                                Please enter an address
                                </div>
                                <div class="form-error-text" v-if="!$v.address.maxLength">
                                Max 400 characters allowed
                                </div>

                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                            <div class="form-group">
                                <input type="file" @change="onImageChange" class="form-input location-input-box"   id="brochure_i" name="brochure_i"  ref="brochure_i">
                                <label class="label location-input-label" >Brochure</label>
                            </div>
                        </div>

                        <div class="col-12 col-md-4 col-lg-4 col-xl-4 px10">
                            <div class="form-group" >
                                <input type="file" @change="onphotoChange" class="form-input location-input-box"  multiple id="photo_i" name="photo_i"  ref="photo_i">
                                <label class="label location-input-label" >Photo</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-3 col-lg-3 col-xl-3 px10 mt-sm-20">
                    <div class="flex items-center flex-wrap submit-cancel-buttons">
                        <button
                            type="submit"
                            class="btn-primary mlr-auto"
                            :disabled="disable_addproperty_submit_btn"
                        >
                            <span>Submit</span>
                        </button>
                        <button
                            type="button"
                            class="btn-cancel-outline btn-cancel-form mlr-auto"
                            :disabled="disable_addproperty_submit_btn"
                            @click="cancelAddProperty"
                        >
                            <span>Cancel</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        </form>

    </div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";
import infoIcon from "../common/icons/infoIcon"
toastr.options.preventDuplicates = true;
import { required, requiredIf, email, minLength, maxLength } from "vuelidate/lib/validators";
import clearDropdownIcon from '../common/icons/clearDropdownIcon';
// import propertyLogo from './propertylogo.vue';

let _ = require("lodash");
import {checkSpecialChars, checkSpecialCharsErrorMessage}  from "../common/customValidation";

export default {
  data: function () {
    return {
        name: '',
        detail: '',
        logo_object:{},
        logo:'',
        type: 'residential',
        type_arr:[
        {id: 'residential', name: 'Residential' },
        {id: 'commercial', name: 'Commercial' },
        ],
        size: '',
        address: '',
        brochure: '',
        photo: [],
        amenity_id: '',
        owner_id: '',
        selected_owener: '',
        selected_aminity: [],
        local_all_location_list : [{
            'select_all': 'Select All',
            'group_option_list': this.all_location_list,
        }],
        disable_addproperty_submit_btn: false,
        JS_APP_URL: JS_APP_URL,
        JS_WORDPRESS_URL: JS_WORDPRESS_URL,
        checkSpecialCharsErrorMessage: checkSpecialCharsErrorMessage
    };
  },
  validations() {
    var vm = this;
    var validationArray = {
      name:{
          required,
          checkSpecialChars,
          maxLength: maxLength(40),
        },
       owner_id: {
            required
        },

       type: {
            required,
        },
        size:{
            required: requiredIf(function () {
                 if(vm.type=="residential")
                     return true;
                 else
                    return false;
            })
        },
       detail:{
          required,
          maxLength: maxLength(400),
        },
        selected_aminity: {
            required
        },
        address: {
            required,
            maxLength: maxLength(400),
        },
        // brochure: {
        //     required
        // },

    };
    return validationArray;
  },
  components: {clearDropdownIcon, infoIcon /*, propertyLogo */},
    props: {
        all_owener_list: {
            type: Array,
            default: () => []
        },
        all_aminity_list: {
            type: Array,
            default: () => []
        },
      all_location_list:{
        type: Array,
        default: () => []
      },
  },
  mounted: function () {
    var vm = this;
  },
  watch: {

  },
  computed: {},
    methods: {
        //  getLogoObject: function (logo_object, logo) {
        //     var vm = this;
        //     vm.logo_object = logo_object;
        //     vm.logo = logo;
        //  },
        onphotoChange(e)
        {
           var vm = this;
            var i;
            console.log(e.target.files)
            vm.photo = e.target.files;
            console.log("Length-->" + vm.photo.length);
            console.log("Images ->" + vm.photo);
            var logoExtensionAllow = ['jpg', 'jpeg', 'png'];
            var flag = 0;

            for (i = 0; i < vm.photo.length; i++)
            {
                console.log(i);
                var logoExtension = vm.photo[i].name.split('.').pop().toLowerCase();
                console.log(logoExtension)
                if (logoExtensionAllow.includes(logoExtension)) {
                    if (vm.photo[i].size > 5000000) {
                        toastr.error("Please upload a photo file less than 5 MB", "Error");
                        flag = 1;
                        break;
                    }
                    else {
                        // vm.brochure = URL.createObjectURL(vm.brochure);
                        // vm.$emit("get-logo-object", vm.brochure, vm.company_logo_url);///////////
                    }
                }
                else {
                    toastr.error("Allow to upload photo with jpeg,jpg,png!", "Error");
                    flag = 1;
                    break;
                }
            }
            if (flag == 1) {
                vm.photo = '';
                this.$refs.photo_i.value = null;
            }
        },

        onImageChange(e) {
            var vm = this;
            vm.brochure = e.target.files[0];
            var logoExtension = vm.brochure.name.split('.').pop().toLowerCase();
            var logoExtensionAllow = ['pdf'];
            if (logoExtensionAllow.includes(logoExtension)) {
                if (vm.brochure.size > 5000000) {
                    vm.brochure = '';
                    this.$refs.brochure_i.value = null;/////////////////
                    toastr.error("Please upload a brochure file less than 5 MB", "Error");
                } else {
                    // vm.brochure = URL.createObjectURL(vm.brochure);
                    // vm.$emit("get-logo-object", vm.brochure, vm.company_logo_url);///////////
                }
            } else {
                toastr.error("Allow to upload brochure with pdf!", "Error");
                vm.brochure = '';
                this.$refs.brochure_i.value = null;
            }
        },
        onChangeOwnerOption: function () {
            var vm = this;
            if (_.isNull(vm.all_owener_list) == false) {
                vm.owner_id  = vm.selected_owener.id;
            } else {
                vm.owner_id  = null;
            }
            console.log("owner_id-->" + vm.owner_id);
        },
        AddPropertySubmit: function(){
            var vm = this;
                    var amenity_arr = new Array();

            console.log("save time-->"+this.selected_aminity);
            //return false;
            vm.$v.$touch();
            if (!vm.$v.$invalid) {
                NProgress.start();

                let currentObj = this;
                const config = {
                    headers: { 'content-type': 'multipart/form-data' }
                }
                const form = document.getElementById("my_form");
                let formData = new FormData(form);
                //formData.append('detail', vm.detail);
                formData.append('type', vm.type);
                //formData.append('address', vm.address);
                formData.append('size', vm.size);
                formData.append('owner_id', vm.owner_id);
                //formData.append('amenity_id', vm.selected_aminity);
                console.log(vm.selected_aminity.length);
                if (vm.selected_aminity.length > 0) {
                    _.forEach(vm.selected_aminity, function (value) {
                        console.log("value==>" + value);
                        amenity_arr.push({ "amenity_id": value });
                    });
                }
                 console.log("Anenity start");
                console.log(amenity_arr);
                console.log("Anenity end");
               formData.append('amenity_id', JSON.stringify(amenity_arr));
                //formData.append("logo_url", vm.logo);
                formData.append('brochure', vm.brochure);
                for (let i = 0; i < vm.photo.length; i++) {
                        //this.upload(i, this.selectedFiles[i]);
                    formData.append('photo[' + i + ']', vm.photo[i]);
                }

                vm.disable_addproperty_submit_btn = true;
                axios
                .post(JS_APP_URL + "/properties/add-property", formData, config)
                .then(function (response) {
                    if (response["data"]["status"] == "Error") {
                        if(response["data"]['data'].length > 0){
                            toastr.error(response["data"]['data'].join('</br>'), "Error");
                        }else{
                            toastr.error(response["data"]["message"], "Error");
                        }
                    } else {
                        toastr.success(response["data"]["message"], "Success");
                        setTimeout(() => {
                            vm.$emit("add-property-form-toggle", false);
                            vm.$emit("reset-all-filter");
                            vm.$emit("load-all-user-list", true);
                        }, 100);
                    }
                })
                .catch(function (error) {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                    window.location = JS_APP_URL + "/login";
                    }
                })
                .then(function () {
                    NProgress.done();
                    vm.disable_addproperty_submit_btn = false;
                });
            }
        },

        cancelAddProperty: function(){
            var vm = this;
            vm.$emit("add-property-form-toggle", false);
        }
  },
  created: function () {
    var vm = this;
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27) {
        vm.$emit("add-property-form-toggle", false);
      }
    });
  }
};
</script>

<style  scoped>
.company_select {
  .multiselect{
    &.form-error{
      border: 0px !important;
      .multiselect__tags{
        border: 1px solid #ff4d4f !important;
      }
    }
  }
}
</style>
