<template>
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper animate__animated animate__zoomIn">
        <div class="modal-container Whoa-modal">
          <button v-if="!is_btn_disabled" v-on:click="closeModal" class="cursor-pointer modal-close">
            <close-icon></close-icon>
          </button>
          <div class="text-center mlr-auto mb30 pt20">
            <img :src="JS_APP_URL + '/images/warning.svg'" alt="" title="" class="warning-icon-modal" />
          </div>
          <h2
            class="
              font-24 font_semibold blueog--text line-normal text-center mb20
            "
          >
            Whoa!
          </h2>
          <p class="text-center font-16 gray_checkmark--text line-normal mb30">Are you sure you want to delete property?</p>
          <div class="flex flex-wrap items-center justify-center pb40">
              <button :disabled="is_btn_disabled" v-on:click="closeModal" class="btn-cancel-outline mx5">CANCEL</button>
              <button :disabled="is_btn_disabled" v-on:click="deletePropertySubmit" class="btn-primary btn-width-136 mx5 px30 mt-xs-20">YES DELETE!</button>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script scoped>
import closeIcon from '../common/icons/closeIcon';

export default {
  props: {
    property_id:{
      type: Number,
       default: () => 0
    }
  },
  components:{closeIcon},
  data: function () {
    return {
      is_btn_disabled: false,
      JS_APP_URL: JS_APP_URL,
    };
  },
  methods: {
    closeModal: function () {
      var vm = this;
      vm.$emit("close-model", false);
    },
    deletePropertySubmit: function () {
      var vm = this;
      vm.is_btn_disabled = true;
      vm.$emit("delete-property");
    },
  },
  created: function () {
    // document.body.classList.add('modal-open');
    var vm = this;
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && !vm.is_btn_disabled) {
        vm.$emit("close-model", false);
      }
    });
  },
  destroyed(){
    // document.body.classList.remove('modal-open');
  }
};
</script>
