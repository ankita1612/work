<template>
    <div>
    		<header-after-login></header-after-login>
    		<div class="container  pt20 pb60">
    			<h1 class="location-dashbaord-title text-center font-24 font_semibold blueog--text line-normal mb10">
    				Properties
    			</h1>

                <filter-property-list :key="filter_component_key" :sample_import_file_link="sample_import_file_link" :is_refresh_btn_shown="is_refresh_btn_shown" @apply-filter="applyFilter" @add-property-form-toggle="addPropertyFormToggle" :is_add_property_shown="is_add_property_shown" @reset-all-filter="resetAllFilter" @load-all-user-list="loadAllUserList" :all_owener_list="all_owener_list" :all_aminity_list="all_aminity_list"></filter-property-list>


    			<transition name="simple-fade-transition">
    				<add-property v-if="is_add_property_shown" @add-property-form-toggle="addPropertyFormToggle"  :all_owener_list="all_owener_list"   :all_aminity_list="all_aminity_list" @load-all-user-list="loadAllUserList" @reset-all-filter="resetAllFilter"></add-property>
    			</transition>

    			<div v-infinite-scroll="loadAllUserList" infinite-scroll-disabled="is_list_loading" infinite-scroll-distance="per_page_records">
    				<propertyItem v-for="(au_item, index) in property_list" v-bind:key="index" :property_item="au_item"  @load-all-user-list="loadAllUserList" @updated-property="updatedProperty" @deleted-property="deletedProperty"   :all_owener_list="all_owener_list" :all_aminity_list="all_aminity_list"></propertyItem>
    				<div v-if="!is_full_page_loader_shown && property_list.length === 0" class="">
    					<div class="user-detail-text font-14 gray_checkmark--text text-center">
    						<no-data-icon></no-data-icon>
    						<div class="font-14 text-center blueog--text">No properties available.</div>
    					</div>
    				</div>
    			</div>
    			 <full-page-loader v-if="is_full_page_loader_shown"></full-page-loader>
    		</div>
    	</div>
</template>

<script scoped>
import axios from "axios";
import NProgress from "nprogress";
import toastr from "toastr";
import "toastr/toastr.scss";``
toastr.options.preventDuplicates = true;
import filterPropertyList from "./filterPropertyList";
import propertyItem from "./propertyItem";
import addProperty from "./addProperty";
import fullPageLoader from '../common/fullPageLoader';
import noDataIcon from '../common/icons/noDataIcon';
import headerAfterLogin from "../common/includes/headerAfterLogin";


export default {
    data: function () {
        return {
             filter_by_access_level: '',
            filter_by_location: [],
            filter_by_type: [],
            filter_by_owner: [],
             search_query: "",
             primary_user: {},
             sample_import_file_link: "",
             property_list: [],
             is_add_property_shown: false,
             all_aminity_list: [],
             all_owener_list: [],
             is_list_loading: false,
             per_page_records: 10,
             current_page: 1,
             total_page: 1,
             filter_component_key: Math.random(),
             is_full_page_loader_shown: false,
             is_refresh_btn_shown: false,
             JS_APP_URL: JS_APP_URL,
             sort_by: '',
             sort_by_dir: '',
        };
    },
    components: {
        propertyItem: propertyItem,
        filterPropertyList: filterPropertyList,
        addProperty: addProperty,
        fullPageLoader: fullPageLoader,
        noDataIcon: noDataIcon,
        headerAfterLogin: headerAfterLogin
    },

    validations: {
    },

    mounted: function () {
        var vm = this;
        vm.loadOwenerList();
        vm.loadAminitiesList();
    },

    watch: {
    },

    computed: {},

    methods: {
        addPropertyFormToggle: function (status = true) {
            var vm = this;
            vm.is_add_property_shown = status;
        },
         loadOwenerList: function () {
            var vm = this;
            vm.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/general/get-all-owener-list")
                .then(function (response) {
                    if (response["data"]["status"] == "Success") {
                        vm.all_owener_list = response["data"]["data"];
                        console.log(vm.all_owener_list);
                    }
                })
                .catch(function (error) {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(function () {
                    // vm.is_full_page_loader_shown = false;
                });
        },
        loadAminitiesList: function () {
            var vm = this;
            vm.is_full_page_loader_shown = true;
            axios
                .get(JS_APP_URL + "/general/get-all-aminities-list")
                .then(function (response) {
                    if (response["data"]["status"] == "Success") {
                        vm.all_aminity_list = response["data"]["data"];
                        console.log(vm.all_owener_list);
                    }
                })
                .catch(function (error) {
                    toastr.error(error.response["data"]["message"], "Error");
                    if (error.response.status === 401) {
                        window.location = JS_APP_URL + "/login";
                    }
                })
                .then(function () {
                    // vm.is_full_page_loader_shown = false;
                });
        },

        loadAllUserList: function (need_pagination_reset = false) {
            var vm = this;

            if (need_pagination_reset) {
                vm.current_page = 1;
                vm.total_page = 1;
                vm.property_list = [];
            }
            if (vm.current_page <= vm.total_page)
            {
                vm.is_list_loading = true;
                vm.is_full_page_loader_shown = true;
                axios
                    .post(JS_APP_URL + "/properties/get-all-property-list", {
                        filter_by_location: _.map(vm.filter_by_location, 'id'),
                        sort_by: vm.sort_by,
                        sort_by_dir: vm.sort_by_dir,
                        search_query: vm.search_query,
                        per_page: vm.per_page_records,
                        page: vm.current_page,
                        filter_by_type: _.map(vm.filter_by_type, 'id'),
                        filter_by_owner: _.map(vm.filter_by_owner, 'id'),
                    })
                    .then(function (response) {
                        if (response["data"]["status"] == "Success") {
                           // vm.primary_user = response["data"]["data"]['primary_user'];
                           // vm.sample_import_file_link = response["data"]["data"]['sample_import_doc'];
                            var account_user_data = response["data"]["data"]['property_list'];
                            vm.property_list.push(...account_user_data.data);
                            vm.total_page = account_user_data.last_page;
                            if (vm.property_list.length == 0 && vm.search_query == '' && vm.filter_by_location.length == 0 && vm.sort_by == '') {

                                vm.is_add_property_shown = true;
                            }

                            vm.current_page = vm.current_page + 1;

                            vm.is_list_loading = false;

                            vm.is_refresh_btn_shown = false;
                        }
                    })
                    .catch(function (error) {
                        //alert("Error");
                        toastr.error(error.response["data"]["message"], "Error");
                        if (error.response.status === 401) {
                            window.location = JS_APP_URL + "/login";
                        }
                    })
                    .then(function () {
                        setTimeout(() => {
                            vm.is_full_page_loader_shown = false;
                        }, 100);
                    });
            }
        },
         applyFilter: function (search_params = {}) {
            var vm = this;
            vm.filter_by_location = search_params.filter_by_location;
            vm.sort_by = search_params.sort_by;
            vm.sort_by_dir = search_params.sort_by_dir;
             vm.search_query = search_params.search_query;
             vm.filter_by_type = search_params.filter_by_type;
             vm.filter_by_owner = search_params.filter_by_owner;
            setTimeout(() => {
                vm.loadAllUserList(true);
            }, 100);
        },
       resetAllFilter: function () {
            var vm = this;
            vm.sort_by = '';
            vm.sort_by_dir = '';
            vm.filter_by_location = [];
            vm.search_query = "";
            vm.filter_component_key = Math.random();
        },
         showRefreshListButton: function () {
            var vm = this;
            if (vm.sort_by != "" || vm.filter_by_location.length > 0 || vm.search_query != "") {
                vm.is_refresh_btn_shown = true;
            }
        },
        deletedProperty: function (property_id = '') {
            var vm = this;
            if (property_id) {
                var found_index = _.findIndex(vm.property_list, function (o) { return o.id === property_id; });
                if (found_index >= 0) {
                    vm.property_list.splice(found_index, 1);
                    if (vm.property_list.length == 0) {
                        vm.showRefreshListButton();
                    }
                }
            }
        },
        updatedProperty: function (property_updated = {}) {
            var vm = this;
            if (!_.isEmpty(property_updated)) {
                var found_index = _.findIndex(vm.property_list, function (o) { return o.id === property_updated.id; });
                if (found_index >= 0) {
                    vm.$set(vm.property_list, found_index, property_updated)
                    vm.showRefreshListButton();
                }
            }
        },
    },
};
</script>
