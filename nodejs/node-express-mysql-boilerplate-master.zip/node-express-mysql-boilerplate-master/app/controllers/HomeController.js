exports.homePage = (req, res) => {
	res.render('home');
};