-fresh install
	npm install

-existing project
	 nodemon server
	OR
	node server

-This contains all API so use latest postman collection .collection file is on root folder with name : "nodejs crud.postman_collection.json"

default port is 5000 I set so run in browser with http://localhost:5000
