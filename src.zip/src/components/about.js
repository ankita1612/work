const AboutUs = () => <h1>About Us Page</h1>;

export default AboutUs;
